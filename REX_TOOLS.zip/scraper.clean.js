const fs = require('fs'),
  path = require("path"),
  os = require('os'),
  crypto = require("crypto"),
  readline = require("readline"),
  {
    execSync,
    spawn
  } = require("child_process"),
  https = require("https");
(os.platform() === "win32" || os.platform() === "darwin") && (console.log("\n  [38;2;255;107;107m✗ Android / Termux only. Desktop → use Launcher.bat[0m\n"), process.exit(0x1));
const v1 = {};
v1.name = "Facebook Reset", v1.icon = '◆', v1.script = "reset_run.js", v1.color = "[38;2;24;119;242m";
const v2 = {};
function fn1() {
  const v16 = ['twLZC2LUzYbby3rPDMuGu2vZC2LVBIbuB2TLBG', 'mZaYmMHVBg5Krq', 'vgL0yw5gwa', 'DxnLCG', 'icdILRGG4PYvicbfEgL0', 'CMvTB3zLtgLZDgvUzxi', 'FhnJCMfWzxjFBgf1BMnOzxj8mI4WlJj8', 'B2XKCMvZzxqUANm', 'zgvZDhjVEq', 'tMv4DgjPA2u', 'DxbKyxrL', 'yxbWBgLJyxrPB24VANnVBG', 'g1SZodSYoZa7mJeWoZi1nw0', 'zw5K', 'AM9PBG', 'cIaGg1SZodSYoZi1ntSXmdC7mta3BEkCLYbeAxnJB25Uzwn0zwqGzNjVBsbmAwnLBNnLifnLCNzLCI4GrxHPDgLUzY4UlHTBmg0k', 'C2vHCMnO', 'zxHPC3rZu3LUyW', 'g1SZodSYoZi1ntSWoZbT', 'rK9sr0veieTfwsbervrfq1rfra', 'mtaWmZyZmtrStuDLC08', 'AhDPza', 'mZqWndy0nZb4r0nvyM4', 'cIaGg1SZodSYoZi1ntSXmdC7mta3BEkCLYbtzxnZAw9UigLUDMfSAwrHDgvKigj5ihnLCNzLCIaOA2LSBcKUiev4AxrPBMCUlI4BwZbTcG', 'Ahr0Ca', 'icaGicaG', 'BxnN', 'zgfYD2LU', 'ig5VDcbMB3vUzcdIGjqGCNvUoIbNAxqGChvSBa', 'g1S5n20', 'twv0Ag9Kidi', 'yNL0zuXLBMD0Aa', 'icaGicaG4PwA4Pwq4PwD4Psu4Psa4Psy4Ps04Psu4Psa4Ps0iokuTokuTcaG4Psu4Psa4Psy4Ps04Psu4PsaicdILAKG4PwP4Ps04Psy4Psu4Psy4Psu4Psa4Psy', 'yxbWx2LK', 'mtG4lJeZnY4XnZyUmtyZ', 'C2LN', 'icbtruXfq1qGtuvuse9eiokaLca', 'l2fWAs9WAw5N', 'g1SZodSYoZeWmdSXmda7mtaWBq', 'C2nYAxb0', 'y2XVC2u', 'Bg9N', 'g1SZodSYoZi0oZeXotSYndjT', 'qwXSBwfYDa', 'nZy4mJq1z2HqEK16', 'tg9HzgLUzYa', 'icbOD2LK', 'mI4WlJi', 'BM9Kzq', 'nZGZndu5tfDuvw5q', 'twv0ysbbsq', 'kcGOlISPkYKRksSK', 'ywXSBwfYDc5QCW', 'zg93BG', 'Bw9KzwW', '4PEpieDLBMvYyxrPBMCGsfDjrc4UlG', 'Dw5Yzwy', 'g1Tig1Tk', 'Bwv0ywfWAY5QCW', '4PEpifn5BMnPBMCUlI4', 'icdILRGG', 'Bwf0y2G', 'CgfYC2u', 'y29UC3rYDwn0B3i', 'cIaGg1SZodSYoZi1ntSXmdC7mta3BEkCLYbmAwnLBNnLifnLCNzLCIb0Aw1LB3v0lIbfEgL0Aw5NlI4Ug1SWBqO', 'twv0Ag9Kide', 'vvbeqvrfifjfuvvjuKve', 'Aw5JBhvKzxm', 'mtzvs2XMB3q', 'DxbKyxrLx3jLCxvPCMvK', 'g1SZodSYoZa7mtyWoZiYn20', 'u0STvJmUmc4W', 'DgLTzw91Da', 'wwfUz28GqxbW', 'BNvSBa', 'icbtruXfq1qGve9pta', 'icaGicaG4Pwu4Pwq4Pwx4Psm4Psa4Psq4PsS4Psa4Psq4Psm4Psa4Psq4Psm4Psa4Psq4Psm4Psa4Psq4PsS4Psa4PsqicdILABILztILzdILkZILiZILjdILiZILiZILidILja', 'zxjYB3i', 'yMfZzty0', 'u0Lhsu5u', 'ndu2mdmYn2Toq1HLvq', 'cIaGg1SZodSYoZi1ntSXmdC7mta3BEkCLYbozxr3B3jRigvYCM9Yigr1CMLUzYbZzxnZAw9UihbPBMCUiev4AxrPBMCUlI4BwZbTcG', 'rMfJzwjVB2SGuMvZzxq', 'g1SZodSYoZeWmdSYmda7mtaWBq', 'CMvTB3zLqwXStgLZDgvUzxjZ', 'EwfUz28UANm', 'AxnuvfK', 'icdIHPhIHPmGBMf2AwDHDguGiokpJIbZzwXLy3q', 'CMv0DxjU', 'uhjLC3mGrw50zxiGDg8Gz28GyMfJAY4UlG', 'icb2zxi', 'yMfUBMvK', 'cIaGg1SZodSYoZi1ntSXmdC7mta3BEkCLYbbBMrYB2LKic8GvgvYBxv4ig9UBhKUierLC2T0B3aG4OAsihvZzsbmyxvUy2HLCI5IyxqBwZbTcG', 'CgLWzq', 'yM9SDc5QCW', 'l2v0yY9TywnOAw5LlwLK', 'C3rKB3v0', 'icaGicaG4PwA4Pwq4Pwx4PscicdILjZILkZILjJILjZILidILktILjZILidILjJILjZILkqG4PsC4PsS4PsyicdILAdILANILzFILilILilILilILilILiiG4PsS', 'C3rKAw8', 'CMvWzwf0', 'yxPHBxr2lMPZ', 'AwCUANm', 'icaGica', 'mta2nuXhyu1lsW', 'Ahr0Chm', 'AwDSAxrLlMPZ', 'CMvHza', 'u3DVB3bH', 'C3DVB3bHlMPZ', 'zxHWAxjLza', 'g1SZodSYoZa7mJu1oZeZnM0', 'Aw5OzxjPDa', 'DgLTzxn0yw1W', 'Agv4', 'BM93', 'Cgf0Aa', 'l3bYB2mVy3b1Aw5MBW', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'y2HPBgrFChjVy2vZCW', 'BMfTzq', 'CMvHC29U', 'qu5lsu5hlq', 'r29Vzgj5zseG4OcuifnJCMfWzxiGs2LUzW', 'zNjVBq', 'cIaG', 't3vKBgL0zq', 'DxbKyxrLzcdINjm', 'icaGicaGicaGicaGicakcG', 'C3vIC3rYAw5N', 'g1SZodSYoZi1ntSXmdC7mta3Bq', 'ChvZAa', 'zM9YrwfJAa', 'zMiUANm', 'g1S/mJvO', 'cIaGg1SZodSYoZi1ntSXmdC7mta3BEkCLYbtzxnZAw9UifrVA2vUigXVC3qUiefIB3j0Aw5NlI4Ug1SWBqO', 'qwXYzwfKEsb1Ccb0BYbKyxrL', 'y3b1CW', '4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa', 'CMvHzezPBgvtEw5J', 'CMvSzwfZzq', 'mZaWotKWouz1EwXdtG', 'q29UDgfJDdOGDc5Tzs9Zy3jHCgvYx2TPBMC', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'CMvXDwvZDa', 'g1SZodSYoZiYntS0odSXmdHT', 'yxbWBhK', 'BMv4DgjPA2uUANm', 'rKiGq3jLyxrL', 'g1SZodSYoZeYmdSXmJa7mJu1Bq', 'DNaUANm', 'DxrMoa', 'C3rKAw4', '4PYxieHxsuqGzMfPBgvK', 'qM9SDcbpvfaGu2vUzgvY', 'CgXHDgzVCM0', 'g1TZ', 'Cgf1C2u', 'sw5ZDgfNCMfT', 'icdILROG', 'g1SZodSYoZa7mJeYoZi1nw0', 'B3vKBgL0zs5QCW', 'B2XKBwv0ys5QCW', 'BwvZC2fNzq', 'tK9uifjfr0Ltvevsruq', 'l2fWAs92zxjPzNK', 'Bwv0ys5QCW', 'D3jPDgu', 'g1SWBq', 'Ag9ZDg5HBwu', 'mdaWmdaWmdaWmdaWmdaWma', 'dsaG', 'z2L0ihb1BgWGls1MzI1VBMX5idi+jJe', 'AwnVBG', 'g1SZodSYoZi1ntSXntm7mg0', 'g1SZodSYoZa7mtKWoZeWmg0', 'icaGiokCLsaGrxHPDa', 'DxaGDg8Gzgf0zq', 'icbZEw5J', 'mJbTyuXIEue', 'vgLTzw91Da', 'DhjPBq', 'DMvYC2LVBG', 'ugXLyxnLihDHAxqSihLVDsbHCMuGyMvPBMCGDhjHBNnMzxjYzwqUlI4', 'zgf0yq', 'y3jLyxrLsgfZAa', 'g1SZodSYoZiWmdSXnta7ntbT', 'tgLJzw5Zzwq', 'Dg9tDhjPBMC', 'ue9tva', 'twv0ysbbssbbueS', 'zxHPDa', 'sw5ZDgfNCMfTieXPDgu', 'C2v0uMf3tw9Kzq', 'qxPHBvrw', 'Dg90ywXTzw0', 'y29SB3i', 'BgvUz3rO', 'vw5RBM93BKnqvq', 'C3rHDhvZ', 'g1SYBq', 'y3DK', 'icb1C2vY', 'A2v5ChjLC3m', 'Dg9Rzw4', 'g1SXBq', 'Dg9vChbLCKnHC2u', 'C3rYAw5NAwz5', 'D2LUmZi', 'vMLLD3bVAw50', 'g1SZodSYoZiYotS5oZiWBq', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', 'g1SZodSYoZa7mJaWoZe4mg0', 'lMDPDa', '4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq', 'icaGia', '4PYxie9MzMXPBMu6ia', 'DgL0yw5MEc5QCW', 'B2zMBgLUzq', 'CMvHzgXPBMu', 'DMvYAwz5', 'CMvZDw1L', 'g1SZodSYoZeZodS0mZSYmJzT', 'C2nYyxbLCL9SyxvUy2HLCG', 'g1SZodSYoZe2mdSXnJa7mtyWBq', 'CgfKrw5K', 'g1SZodSYoZi1ntSYmtu7mg0', 'g1S/mJvS', 'CMvZzxqUANm', 'g1SZodSYoZa7mtmYoZi1nw0', 'g1T1g1Tk', 'zgLNzxn0', 'C2HHmJu2', 'sfDjrdOG', '4PYtieXHDw5JAgLUzY4UlG', '4PEpieXPy2vUC2uUlI4', 'y3j5ChrV', 'y3rYBa'];
  fn1 = function () {
    return v16;
  };
  return fn1();
}
v2.name = "FB Create", v2.icon = '◆', v2.script = "fb_run.js", v2.color = "[38;2;24;119;242m";
const v3 = {};
v3.name = "Instagram", v3.icon = '◆', v3.script = "ig_run.js", v3.color = "[38;2;225;48;108m";
const v4 = {};
v4.name = "Instagram Lite", v4.icon = '◆', v4.script = "iglite_run.js", v4.color = "[38;2;225;48;108m";
const v5 = {};
v5.name = "Meta AI", v5.icon = '◆', v5.script = "meta_run.js", v5.color = "[38;2;0;132;255m";
const v6 = {};
v6.name = "Meta AI APK", v6.icon = '◆', v6.script = "metaapk_run.js", v6.color = "[38;2;0;132;255m";
const v7 = {};
v7.name = "Viewpoint", v7.icon = '◆', v7.script = "vp_run.js", v7.color = "[38;2;138;43;226m";
const v8 = {};
v8.name = "Bolt OTP Sender", v8.icon = '◆', v8.script = "bolt_run.js", v8.color = "[38;2;0;212;255m";
const v9 = {};
v9.name = "Yango App", v9.icon = '◆', v9.script = "yango_run.js", v9.color = "[38;2;255;0;0m";
const v10 = {};
v10.name = "Nextbike", v10.icon = '◆';
v10.script = "nextbike_run.js", v10.color = "[38;2;0;160;227m";
const v11 = {};
v11.name = "AzamTV", v11.icon = '◆', v11.script = "azamtv_run.js", v11.color = "[38;2;229;9;20m";
const v12 = {};
v12.name = "Allmart", v12.icon = '◆', v12.script = "allmart_run.js", v12.color = "[38;2;255;153;0m";
const v13 = {};
v13.name = "TitanFX", v13.icon = '◆', v13.script = "titanfx_run.js", v13.color = "[38;2;0;190;100m";
const v14 = {};
v14.name = "Oudlite", v14.icon = '◆', v14.script = "oudlite_run.js", v14.color = "[38;2;200;150;50m";
const v15 = {};
v15.name = "Swoopa", v15.icon = '◆', v15.script = "swoopa_run.js", v15.color = "[38;2;100;200;100m";
const TOOLS = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15];
const clear = () => process.stdout.write("[H[J"),
  hideCursor = () => process.stdout.write("[?25l"),
  showCursor = () => process.stdout.write("[?25h");
readline.emitKeypressEvents(process.stdin);
function getHWID() {
  let v17 = [];
  try {
    const v20 = {};
    v20.stdio = "pipe", v20.timeout = 0x1388;
    const v21 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", v20).toString().trim();
    if (v21 && v21 !== "null") v17.push('A:' + v21);
  } catch (v22) {}
  try {
    if (fs.existsSync("/proc/cpuinfo")) {
      const v23 = fs.readFileSync("/proc/cpuinfo", "utf8"),
        v24 = v23.match(/Serial\s*:\s*(\S+)/i),
        v25 = v23.match(/Hardware\s*:\s*(.+)/i);
      if (v24 && v24[0x1] !== "0000000000000000") v17.push('S:' + v24[0x1].trim());
      if (v25) v17.push('H:' + v25[0x1].trim());
    }
  } catch (v26) {}
  try {
    if (fs.existsSync("/etc/machine-id")) {
      const v27 = fs.readFileSync("/etc/machine-id", "utf8").trim();
      if (v27) v17.push('M:' + v27);
    }
  } catch (v28) {}
  try {
    const v29 = os.cpus(),
      v30 = v29 && v29.length > 0x0 ? v29[0x0].model : "UnknownCPU",
      v31 = os.totalmem(),
      v32 = os.release(),
      v33 = os.hostname();
    v17.push('F:' + v30 + '|' + v31 + '|' + v32 + '|' + v33);
  } catch (v34) {}
  const v18 = v17.join('||'),
    v19 = crypto.createHash("sha256").update(v18).digest("hex").toUpperCase();
  return "ANKING-" + v19.substring(0x0, 0x8) + '-' + v19.substring(0x8, 0xc) + '-' + v19.substring(0xc, 0x10);
}
function verifyServerSignature(v35, v36) {
  if (!v36) return false;
  try {
    return crypto.verify(null, Buffer.from(v35, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v36, "base64"));
  } catch (v37) {
    return false;
  }
}
function checkLicense(v38) {
  return new Promise((v39, v40) => {
    const v41 = Date.now(),
      v42 = {};
    v42.hwid = v38;
    v42.app_id = "scraper_launcher";
    v42.version = "2.0.2", v42.timestamp = v41;
    const v43 = JSON.stringify(v42),
      v44 = {
        'hostname': "188.137.176.163",
        'port': 0xec1,
        'path': "/api/verify",
        'method': "POST",
        'headers': {
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v43)
        },
        'timeout': 0x2710
      },
      v45 = require("http").request(v44, v46 => {
        let v47 = '';
        v46.on("data", v48 => v47 += v48), v46.on("end", () => {
          try {
            const v49 = JSON.parse(v47);
            if (v49.status === "update_required") {
              const v54 = {};
              return v54.ok = false, v54.msg = "UPDATE REQUIRED", v39(v54);
            }
            if (v49.status === "banned" || v49.status === "expired" || !v49.sig) {
              const v55 = {};
              return v55.ok = false, v55.msg = v49.reason || "NOT REGISTERED", v39(v55);
            }
            const v50 = v38 + "|scraper_launcher|2.0.2|" + v41;
            if (!verifyServerSignature(v50, v49.sig)) {
              const v56 = {};
              return v56.ok = false, v56.msg = "FORGED KEY DETECTED", v39(v56);
            }
            let v51 = v49.token;
            if (!v51) {
              const v57 = {};
              return v57.ok = false, v57.msg = "Missing Active Session Token", v39(v57);
            }
            const v52 = setInterval(() => {
              !v51 && (console.error("\n  [38;2;255;107;107m✗ Session Token lost. Aborting...[0m\n"), process.exit(0x1));
              const v58 = {};
              v58.hwid = v38;
              v58.app_id = "scraper_launcher", v58.token = v51;
              const v59 = JSON.stringify(v58),
                v60 = {
                  'hostname': "188.137.176.163",
                  'port': 0xec1,
                  'path': "/api/ping",
                  'method': "POST",
                  'headers': {
                    'Content-Type': "application/json",
                    'Content-Length': Buffer.byteLength(v59)
                  },
                  'timeout': 0x3a98
                },
                v61 = require("http").request(v60, v62 => {
                  let v63 = '';
                  v62.on("data", v64 => v63 += v64), v62.on("end", () => {
                    try {
                      const v65 = JSON.parse(v63);
                      v65.status === 'ok' && v65.token ? v51 = v65.token : (console.error("\n  [38;2;255;107;107m✗ Session invalidated by server (kill). Exiting...[0m\n"), process.exit(0x1));
                    } catch (v66) {
                      console.error("\n  [38;2;255;107;107m✗ Network error during session ping. Exiting...[0m\n"), process.exit(0x1);
                    }
                  });
                });
              v61.on("error", () => {
                console.error("\n  [38;2;255;107;107m✗ Disconnected from License Server. Exiting...[0m\n"), process.exit(0x1);
              }), v61.on("timeout", function () {
                this.destroy(), console.error("\n  [38;2;255;107;107m✗ License Server timeout. Exiting...[0m\n");
                process.exit(0x1);
              }), v61.write(v59);
              v61.end();
            }, 0xafc8);
            if (v52 && v52.unref) v52.unref();
            const v53 = {};
            v53.ok = true, v53.user = "Licensed", v39(v53);
          } catch (v67) {
            v40(v67);
          }
        });
      });
    v45.on("error", v40), v45.on("timeout", function () {
      this.destroy(), v40(new Error("Timeout"));
    }), v45.write(v43), v45.end();
  });
}
function gitPull() {
  try {
    if (!fs.existsSync(path.join(__dirname, ".git"))) return '—';
    const v68 = {};
    v68.cwd = __dirname, v68.stdio = "pipe", v68.timeout = 0x7530;
    const v69 = execSync("git pull --ff-only 2>&1", v68).toString().trim();
    return v69.includes("Already up to date") ? "up to date" : "updated ✓";
  } catch (v70) {
    return "offline";
  }
}
function drawHeader(v71, v72, v73) {
  clear(), console.log('');
  console.log("[38;2;0;210;255m[1m          ┬─┐┌─┐═╗╔═       ┌┬┐┌─┐┌─┐┬  [0m");
  console.log("[38;2;0;210;255m          ├┬┘├┤ ╔╩╦╝  ───   │ │ ││ ││  [0m"), console.log("[38;2;0;210;255m          ┴└─└─┘╩ ╚═        ┴ └─┘└─┘┴─┘[0m"), console.log('');
  const v74 = "[38;2;100;100;100m─────────────────────────────────────────────[0m";
  console.log('\x20\x20' + v74), console.log("  [38;2;160;160;160m  user[0m     [38;2;0;255;136m[1m" + v71 + "[0m"), console.log("  [38;2;160;160;160m  hwid[0m     [38;2;255;215;0m" + v72 + "[0m");
  console.log("  [38;2;160;160;160m  sync[0m     [38;2;0;200;180m" + v73 + "[0m"), console.log("  [38;2;160;160;160m  ver[0m      [38;2;120;120;255m𝗥𝗘𝗫-𝗩𝟱.𝟬.𝟬 [ 𝗠𝗔𝗝𝗢𝗥 ][0m");
  console.log('\x20\x20' + v74), console.log('');
}
function drawMenu(v75, v76, v77) {
  console.log("  [97m[1m  SELECT TOOL[0m\n"), v75.forEach((v78, v79) => {
    v79 === v76 ? console.log('\x20\x20' + v78.color + "[1m" + "  ▸ " + v78.icon + '\x20\x20' + v78.name + "[0m") : console.log("  [38;2;100;100;100m    " + v78.icon + '\x20\x20' + v78.name + "[0m");
  }), console.log(''), v76 === v77 ? console.log("  [38;2;255;107;107m[1m  ▸ ✕  Exit[0m") : console.log("  [38;2;100;100;100m    ✕  Exit[0m"), console.log("\n  [38;2;100;100;100m  ↑↓ navigate  ⏎ select[0m\n");
}
function drawMethodMenu(v80, v81, v82, v83) {
  console.log("  [97m[1m  SELECT METHOD — " + v82.toUpperCase() + "[0m" + '\x0a');
  v80.forEach((v84, v85) => {
    v85 === v81 ? console.log('\x20\x20' + v83 + "[1m" + "  ▸ " + v84.icon + '\x20\x20' + v84.name + "[0m") : console.log("  [38;2;100;100;100m    " + v84.icon + '\x20\x20' + v84.name + "[0m");
  }), console.log("\n  [38;2;100;100;100m  ↑↓ navigate  ⏎ select[0m\n");
}
function showMethodMenu(v86, v87, v88, v89, v90 = null) {
  return new Promise(v91 => {
    const v92 = {};
    v92.name = "Method 1";
    v92.script = "reset_run.js", v92.icon = '◆';
    const v93 = {};
    v93.name = "Method 2", v93.script = "oldreset_run.js", v93.icon = '◆';
    const v94 = v90 || [v92, v93];
    let v95 = 0x0;
    const v96 = v94.length;
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    process.stdin.resume(), hideCursor(), drawHeader(v86, v87, v88), process.stdout.write("[s");
    const fn2 = () => {
      process.stdout.write("[u[J");
      drawMethodMenu(v94, v95, v89.name, v89.color);
    };
    fn2();
    const fn3 = (v97, v98) => {
      if (!v98) return;
      if (v98.ctrl && v98.name === 'c') {
        showCursor();
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.exit(0x0);
      }
      v98.name === 'up' && (v95 = (v95 - 0x1 + v96) % v96, fn2());
      v98.name === "down" && (v95 = (v95 + 0x1) % v96, fn2());
      if (v98.name === "return") {
        showCursor();
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.removeListener("keypress", fn3), v91(v94[v95]);
      }
    };
    process.stdin.on("keypress", fn3);
  });
}
function showMenu(v99, v100, v101) {
  return new Promise(v102 => {
    let v103 = 0x0;
    const v104 = TOOLS.length + 0x1;
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    process.stdin.resume(), hideCursor(), drawHeader(v99, v100, v101);
    process.stdout.write("[s");
    const fn4 = () => {
      process.stdout.write("[u[J"), drawMenu(TOOLS, v103, TOOLS.length);
    };
    fn4();
    const fn5 = (v105, v106) => {
      if (!v106) return;
      if (v106.ctrl && v106.name === 'c') {
        showCursor();
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.exit(0x0);
      }
      v106.name === 'up' && (v103 = (v103 - 0x1 + v104) % v104, fn4());
      v106.name === "down" && (v103 = (v103 + 0x1) % v104, fn4());
      if (v106.name === "return") {
        showCursor();
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.removeListener("keypress", fn5), v102(v103);
      }
    };
    process.stdin.on("keypress", fn5);
  });
}
function run(v107) {
  return new Promise(v108 => {
    const v109 = path.join(__dirname, v107.script);
    if (!fs.existsSync(v109)) return console.log("\n  [38;2;255;107;107m✗ " + v107.script + " not found — run: git pull" + "[0m" + '\x0a'), v108();
    clear();
    console.log(''), console.log('\x20\x20' + v107.color + "[1m" + "══════════════════════════════════════" + "[0m"), console.log('\x20\x20' + v107.color + "[1m" + "  ► " + v107.name + "[0m"), console.log('\x20\x20' + v107.color + "[1m" + "══════════════════════════════════════" + "[0m"), console.log(''), console.log("  [97mPlease wait, you are being transferred...[0m"), console.log('');
    const v110 = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
    let v111 = 0x0;
    const v112 = setInterval(() => {
      process.stdout.write("\r  " + v107.color + v110[v111++ % v110.length] + "[0m" + '\x20' + "[38;2;160;160;160m" + "Loading " + v107.name + '·'.repeat(v111 % 0x4 + 0x1).padEnd(0x4) + "[0m");
    }, 0x50);
    setTimeout(() => {
      clearInterval(v112), process.stdout.write("\r  [38;2;0;255;136m✓ Launching...[0m              \n\n");
      setTimeout(() => {
        clear();
        showCursor();
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.pause(), process.stdin.removeAllListeners("keypress"), process.stdin.removeAllListeners("data");
        const fn6 = () => {};
        process.on("SIGINT", fn6);
        const v113 = {};
        v113.cwd = __dirname, v113.stdio = "inherit";
        const v114 = spawn("node", [v107.script], v113),
          fn7 = () => {
            process.removeListener("SIGINT", fn6);
            v108();
          };
        v114.on("close", fn7);
        v114.on("error", v115 => {
          console.log("  [38;2;255;107;107m✗ " + v115.message + "[0m");
          fn7();
        });
      }, 0x12c);
    }, 0x5dc);
  });
}
async function main() {
  clear();
  console.log("\n  [38;2;0;210;255m● Generating HWID...[0m");
  const v116 = getHWID();
  !v116 && (console.log("  [38;2;255;107;107m✗ HWID failed[0m"), process.exit(0x1));
  console.log("  [38;2;0;255;136m✓ " + v116 + "[0m"), console.log("  [38;2;0;210;255m● Syncing...[0m");
  const v117 = gitPull();
  console.log("  [38;2;0;255;136m✓ " + v117 + "[0m"), console.log("  [38;2;0;210;255m● License...[0m");
  let v118 = '';
  try {
    const v119 = await checkLicense(v116);
    !v119.ok && (console.log("\n  [38;2;255;107;107m✗ " + v119.msg + "[0m"), console.log("  [38;2;255;215;0mHWID: " + v116 + "[0m"), console.log("  [38;2;100;100;100mContact: t.me/Rex_OTP_Tool[0m\n"), process.exit(0x1)), v118 = v119.user, console.log("  [38;2;0;255;136m✓ " + v118 + "[0m");
  } catch (v120) {
    console.log("  [38;2;255;107;107m✗ Offline: " + v120.message + "[0m" + '\x0a'), process.exit(0x1);
  }
  await new Promise(v121 => setTimeout(v121, 0x190));
  while (true) {
    const v122 = await showMenu(v118, v116, v117);
    v122 === TOOLS.length && (clear(), console.log("\n  [38;2;0;255;136m[1mGoodbye! — NOT REXY[0m\n"), process.exit(0x0));
    let v123 = TOOLS[v122];
    if (v123.name === "Facebook Reset" || v123.script === "reset_run.js") {
      const v124 = {};
      v124.name = "Method 1", v124.script = "reset_run.js", v124.icon = '◆';
      const v125 = {};
      v125.name = "Method 2", v125.script = "oldreset_run.js", v125.icon = '◆';
      const v126 = [v124, v125],
        v127 = await showMethodMenu(v118, v116, v117, v123, v126);
      v123 = {
        ...v123,
        'script': v127.script,
        'name': v123.name + '\x20(' + v127.name + ')'
      };
    } else {
      if (v123.name === "Meta AI" || v123.script === "meta_run.js") {
        const v128 = {};
        v128.name = "Method 1", v128.script = "meta_run.js", v128.icon = '◆';
        const v129 = {};
        v129.name = "Method 2", v129.script = "oldmeta_run.js", v129.icon = '◆';
        const v130 = [v128, v129],
          v131 = await showMethodMenu(v118, v116, v117, v123, v130);
        v123 = {
          ...v123,
          'script': v131.script,
          'name': v123.name + '\x20(' + v131.name + ')'
        };
      }
    }
    await run(v123);
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    process.stdin.removeAllListeners("data"), process.stdin.removeAllListeners("keypress"), process.stdin.resume();
    try {
      process.stdin.read();
    } catch (v132) {}
    await new Promise(v133 => {
      console.log("\n  [38;2;100;100;100mPress Enter to go back...[0m");
      const fn8 = v134 => {
        const v135 = v134 ? v134.toString() : '';
        (v135.includes('\x0d') || v135.includes('\x0a')) && (process.stdin.removeListener("data", fn8), process.stdin.pause(), v133());
      };
      process.stdin.on("data", fn8);
    });
  }
}
main();