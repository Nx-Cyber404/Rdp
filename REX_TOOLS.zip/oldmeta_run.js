const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v1) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v2 = {};
      v2.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v2), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v3) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto");
const chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent");
const {
  SocksProxyAgent
} = require("socks-proxy-agent");
class NexaRateLimiter {
  constructor(v4) {
    this.delayMs = v4, this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v5) {
    return new Promise((v6, v7) => {
      {
        this.queue.push(async () => {
          try {
            v6(await v5());
          } catch (v8) {
            v7(v8);
          }
        });
        if (!this.processing) this._process();
      }
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      const v9 = this.queue.shift();
      await v9(), await new Promise(v10 => setTimeout(v10, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500);
function nexaFetchNumber(v11, v12, v13) {
  return new Promise((v14, v15) => {
    const v16 = {};
    v16.range = v12, v16.format = "normal";
    const v17 = JSON.stringify(v16),
      v18 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v13 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v11,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v17)
        }
      },
      v19 = http.request(v18, v20 => {
        {
          let v21 = '';
          v20.on("data", v22 => v21 += v22), v20.on("end", () => {
            try {
              {
                const v23 = JSON.parse(v21);
                if (v23.success && v23.number) {
                  v14(v23.number.replace(/[^0-9]/g, ''));
                } else {
                  v15(new Error(v23.error || "NexaOTP: No number returned"));
                }
              }
            } catch (v24) {
              v15(new Error("NexaOTP: Invalid response"));
            }
          });
        }
      });
    v19.on("error", v25 => v15(new Error("NexaOTP network: " + v25.message)));
    v19.setTimeout(10000, () => {
      v19.destroy();
      v15(new Error("NexaOTP: Timeout"));
    }), v19.write(v17), v19.end();
  });
}
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt",
  DEBUG_FILE = "debug.txt";
function debugLog(v26, v27, v28) {
  try {
    const v29 = new Date().toISOString(),
      v30 = typeof v28 === "string" ? v28 : JSON.stringify(v28, null, 2),
      v31 = '\x0a[' + v29 + "] [" + v26 + "] [" + v27 + ']\x0a' + v30 + '\x0a';
    fs.appendFileSync(DEBUG_FILE, v31);
  } catch (v32) {}
}
const B = chalk.hex("#4267B2"),
  C = chalk.hex("#1877F2"),
  Y = chalk.hex("#FFD700"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B"),
  DIM = chalk.hex("#555555");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(C("   ____                                      _  ___              "));
    console.log(C("  / ___|  ___ _ __ __ _ _ __   ___ _ __     | |/ (_)_ __   __ _  "));
    console.log(C("  \\___ \\ / __| '__/ _` | '_ \\ / _ \\ '__|    | ' <| | '_ \\ / _` | "));
    console.log(C("   ___) | (__| | | (_| | |_) |  __/ |       | . \\| | | | | (_| | "));
    console.log(C("  |____/ \\___|_|  \\__,_| .__/ \\___|_|       |_|\\_\\_|_| |_|\\__, | "));
    console.log(C("                       |_|                                |___/  \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Tool      : ") + C("REX — Meta                   ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Version   : ") + Y("REX-V5.0.0 [ MAJOR ]         ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
function sleep(v33) {
  return new Promise(v34 => setTimeout(v34, v33));
}
function normalizePhoneNumber(v35) {
  let v36 = v35.replace(/\D/g, '');
  return !v36.startsWith('+') && (v36 = '+' + v36), v36;
}
const uuid = () => crypto.randomUUID(),
  DIAL_MAP = [["1868", 'TT', "en-TT,en;q=0.9"], ["1876", 'JM', "en-JM,en;q=0.9"], ["1809", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["1829", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["1849", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["880", 'BD', "bn-BD,bn;q=0.9,en;q=0.8"], ["855", 'KH', "km-KH,km;q=0.9,en;q=0.8"], ["856", 'LA', "lo-LA,lo;q=0.9,en;q=0.8"], ["228", 'TG', "fr-TG,fr;q=0.9,en;q=0.8"], ["229", 'BJ', "fr-BJ,fr;q=0.9,en;q=0.8"], ["233", 'GH', "en-GH,en;q=0.9"], ["234", 'NG', "en-NG,en;q=0.9"], ["237", 'CM', "fr-CM,fr;q=0.9,en;q=0.8"], ["243", 'CD', "fr-CD,fr;q=0.9"], ["254", 'KE', "sw-KE,sw;q=0.9,en;q=0.8"], ["255", 'TZ', "sw-TZ,sw;q=0.9,en;q=0.8"], ["256", 'UG', "en-UG,en;q=0.9"], ["260", 'ZM', "en-ZM,en;q=0.9"], ["263", 'ZW', "en-ZW,en;q=0.9"], ["212", 'MA', "ar-MA,ar;q=0.9,fr;q=0.8"], ["213", 'DZ', "ar-DZ,ar;q=0.9,fr;q=0.8"], ["216", 'TN', "ar-TN,ar;q=0.9,fr;q=0.8"], ["218", 'LY', "ar-LY,ar;q=0.9,en;q=0.8"], ["220", 'GM', "en-GM,en;q=0.9"], ["221", 'SN', "fr-SN,fr;q=0.9"], ["222", 'MR', "ar-MR,ar;q=0.9,fr;q=0.8"], ["223", 'ML', "fr-ML,fr;q=0.9"], ["224", 'GN', "fr-GN,fr;q=0.9"], ["225", 'CI', "fr-CI,fr;q=0.9"], ["226", 'BF', "fr-BF,fr;q=0.9"], ["227", 'NE', "fr-NE,fr;q=0.9"], ["230", 'MU', "en-MU,en;q=0.9,fr;q=0.8"], ["231", 'LR', "en-LR,en;q=0.9"], ["232", 'SL', "en-SL,en;q=0.9"], ["235", 'TD', "fr-TD,fr;q=0.9,ar;q=0.8"], ["236", 'CF', "fr-CF,fr;q=0.9"], ["238", 'CV', "pt-CV,pt;q=0.9"], ["239", 'ST', "pt-ST,pt;q=0.9"], ["240", 'GQ', "es-GQ,es;q=0.9"], ["241", 'GA', "fr-GA,fr;q=0.9"], ["242", 'CG', "fr-CG,fr;q=0.9"], ["244", 'AO', "pt-AO,pt;q=0.9"], ["245", 'GW', "pt-GW,pt;q=0.9"], ["246", 'IO', "en-IO,en;q=0.9"], ["247", 'AC', "en-AC,en;q=0.9"], ["248", 'SC', "en-SC,en;q=0.9,fr;q=0.8"], ["249", 'SD', "ar-SD,ar;q=0.9,en;q=0.8"], ["250", 'RW', "rw-RW,rw;q=0.9,en;q=0.8,fr;q=0.7"], ["251", 'ET', "am-ET,am;q=0.9,en;q=0.8"], ["252", 'SO', "so-SO,so;q=0.9,ar;q=0.8,en;q=0.7"], ["253", 'DJ', "fr-DJ,fr;q=0.9,ar;q=0.8"], ["257", 'BI', "fr-BI,fr;q=0.9,rn;q=0.8"], ["258", 'MZ', "pt-MZ,pt;q=0.9"], ["261", 'MG', "mg-MG,mg;q=0.9,fr;q=0.8"], ["262", 'RE', "fr-RE,fr;q=0.9"], ["264", 'NA', "en-NA,en;q=0.9"], ["265", 'MW', "en-MW,en;q=0.9"], ["266", 'LS', "en-LS,en;q=0.9"], ["267", 'BW', "en-BW,en;q=0.9"], ["268", 'SZ', "en-SZ,en;q=0.9"], ["269", 'KM', "fr-KM,fr;q=0.9,ar;q=0.8"], ["966", 'SA', "ar-SA,ar;q=0.9,en;q=0.8"], ["971", 'AE', "ar-AE,ar;q=0.9,en;q=0.8"], ["973", 'BH', "ar-BH,ar;q=0.9,en;q=0.8"], ["974", 'QA', "ar-QA,ar;q=0.9,en;q=0.8"], ["968", 'OM', "ar-OM,ar;q=0.9,en;q=0.8"], ["965", 'KW', "ar-KW,ar;q=0.9,en;q=0.8"], ["964", 'IQ', "ar-IQ,ar;q=0.9,en;q=0.8"], ["963", 'SY', "ar-SY,ar;q=0.9,en;q=0.8"], ["962", 'JO', "ar-JO,ar;q=0.9,en;q=0.8"], ["961", 'LB', "ar-LB,ar;q=0.9,en;q=0.8,fr;q=0.7"], ["967", 'YE', "ar-YE,ar;q=0.9,en;q=0.8"], ["970", 'PS', "ar-PS,ar;q=0.9,en;q=0.8"], ["972", 'IL', "he-IL,he;q=0.9,en;q=0.8"], ["992", 'TJ', "tg-TJ,tg;q=0.9,ru;q=0.8"], ["993", 'TM', "tk-TM,tk;q=0.9,ru;q=0.8"], ["994", 'AZ', "az-AZ,az;q=0.9,ru;q=0.8"], ["995", 'GE', "ka-GE,ka;q=0.9,en;q=0.8"], ["996", 'KG', "ky-KG,ky;q=0.9,ru;q=0.8"], ["998", 'UZ', "uz-UZ,uz;q=0.9,ru;q=0.8"], ["977", 'NP', "ne-NP,ne;q=0.9,en;q=0.8"], ["975", 'BT', "dz-BT,dz;q=0.9,en;q=0.8"], ["959", 'MM', "my-MM,my;q=0.9,en;q=0.8"], ["670", 'TL', "pt-TL,pt;q=0.9,en;q=0.8"], ["673", 'BN', "ms-BN,ms;q=0.9,en;q=0.8"], ["676", 'TO', "en-TO,en;q=0.9"], ["677", 'SB', "en-SB,en;q=0.9"], ["678", 'VU', "en-VU,en;q=0.9,fr;q=0.8"], ["679", 'FJ', "en-FJ,en;q=0.9"], ["680", 'PW', "en-PW,en;q=0.9"], ["591", 'BO', "es-BO,es;q=0.9,en;q=0.8"], ["592", 'GY', "en-GY,en;q=0.9"], ["593", 'EC', "es-EC,es;q=0.9,en;q=0.8"], ["594", 'GF', "fr-GF,fr;q=0.9"], ["595", 'PY', "es-PY,es;q=0.9,en;q=0.8"], ["596", 'MQ', "fr-MQ,fr;q=0.9"], ["597", 'SR', "nl-SR,nl;q=0.9,en;q=0.8"], ["598", 'UY', "es-UY,es;q=0.9,en;q=0.8"], ['20', 'EG', "ar-EG,ar;q=0.9,en;q=0.8"], ['27', 'ZA', "en-ZA,en;q=0.9"], ['30', 'GR', "el-GR,el;q=0.9,en;q=0.8"], ['31', 'NL', "nl-NL,nl;q=0.9,en;q=0.8"], ['32', 'BE', "nl-BE,nl;q=0.9,fr;q=0.8,en;q=0.7"], ['33', 'FR', "fr-FR,fr;q=0.9,en;q=0.8"], ['34', 'ES', "es-ES,es;q=0.9,en;q=0.8"], ['36', 'HU', "hu-HU,hu;q=0.9,en;q=0.8"], ['39', 'IT', "it-IT,it;q=0.9,en;q=0.8"], ['40', 'RO', "ro-RO,ro;q=0.9,en;q=0.8"], ['41', 'CH', "de-CH,de;q=0.9,fr;q=0.8,en;q=0.7"], ['43', 'AT', "de-AT,de;q=0.9,en;q=0.8"], ['44', 'GB', "en-GB,en;q=0.9"], ['45', 'DK', "da-DK,da;q=0.9,en;q=0.8"], ['46', 'SE', "sv-SE,sv;q=0.9,en;q=0.8"], ['47', 'NO', "nb-NO,nb;q=0.9,en;q=0.8"], ['48', 'PL', "pl-PL,pl;q=0.9,en;q=0.8"], ['49', 'DE', "de-DE,de;q=0.9,en;q=0.8"], ['51', 'PE', "es-PE,es;q=0.9,en;q=0.8"], ['52', 'MX', "es-MX,es;q=0.9,en;q=0.8"], ['53', 'CU', "es-CU,es;q=0.9"], ['54', 'AR', "es-AR,es;q=0.9,en;q=0.8"], ['55', 'BR', "pt-BR,pt;q=0.9,en;q=0.8"], ['56', 'CL', "es-CL,es;q=0.9,en;q=0.8"], ['57', 'CO', "es-CO,es;q=0.9,en;q=0.8"], ['58', 'VE', "es-VE,es;q=0.9,en;q=0.8"], ['60', 'MY', "ms-MY,ms;q=0.9,en;q=0.8"], ['61', 'AU', "en-AU,en;q=0.9"], ['62', 'ID', "id-ID,id;q=0.9,en;q=0.8"], ['63', 'PH', "en-PH,en;q=0.9,fil;q=0.8"], ['64', 'NZ', "en-NZ,en;q=0.9"], ['65', 'SG', "en-SG,en;q=0.9,zh;q=0.8"], ['66', 'TH', "th-TH,th;q=0.9,en;q=0.8"], ['81', 'JP', "ja-JP,ja;q=0.9,en;q=0.8"], ['82', 'KR', "ko-KR,ko;q=0.9,en;q=0.8"], ['84', 'VN', "vi-VN,vi;q=0.9,en;q=0.8"], ['86', 'CN', "zh-CN,zh;q=0.9,en;q=0.8"], ['90', 'TR', "tr-TR,tr;q=0.9,en;q=0.8"], ['91', 'IN', "hi-IN,hi;q=0.9,en;q=0.8"], ['92', 'PK', "ur-PK,ur;q=0.9,en;q=0.8"], ['93', 'AF', "ps-AF,ps;q=0.9,en;q=0.8"], ['94', 'LK', "si-LK,si;q=0.9,en;q=0.8"], ['95', 'MM', "my-MM,my;q=0.9,en;q=0.8"], ['98', 'IR', "fa-IR,fa;q=0.9,en;q=0.8"], ['1', 'US', "en-US,en;q=0.9"], ['7', 'RU', "ru-RU,ru;q=0.9,en;q=0.8"]];
function getCountryFromPhone(v37) {
  for (const [v39, v40, v41] of DIAL_MAP) {
    if (v37.startsWith(v39)) {
      const v42 = {};
      return v42.iso = v40, v42.lang = v41, v42;
    }
  }
  const v38 = {};
  return v38.iso = 'US', v38.lang = "en-US,en;q=0.9", v38;
}
function generateRandomDOB() {
  const v43 = Math.floor(Math.random() * 25) + 18,
    v44 = new Date().getFullYear() - v43,
    v45 = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
  const v46 = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
  return {
    'day': v46,
    'month': v45,
    'year': String(v44),
    'full': v44 + '-' + v45 + '-' + v46
  };
}
function generateRandomPassword() {
  const v47 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%";
  let v48 = '';
  for (let v49 = 0; v49 < 12; v49++) v48 += v47[Math.floor(Math.random() * v47.length)];
  return v48;
}
(function () {
  let v50;
  try {
    const v51 = Function('return (function() {}.constructor("return this")( ));');
    v50 = v51();
  } catch (v52) {
    v50 = window;
  }
  v50.setInterval(fn2, 4000);
})();
function fn1() {
  const v53 = ['q1jKBG', 'vxvprW', 'x2aGFa', 'rviGua', 'ChDmBq', 'CNvLkq', 'y3jLyq', 'B3CGzG', 'mJm3', 'DejRtq', 'ywrZia', 'vgLTzq', 'AhvHzq', 'iNzqma', 'AwXLza', 'seuTuG', 'ChvJBa', 'mti2', 'y29UDa', 'B25mBW', 'wIXLBG', 'AhLgAa', 'B3DFBG', 'lxjLzW', 'mKzLyW', 'B3HPzq', 'rMLSzq', 'kue7qG', 's091Ca', 'ntzFrW', 'Bw5VCa', 't25XtG', '8j+hUVcFH7GGrw4', 'qw1UwG', 'C3rYyq', 'DKPuBW', 'mti3', 'vMTlvW', 'qufprq', 'ywrZ', 'mtnOu3zjr3m', 'icaG4Pwr', 'zMXMrW', 'oIjWCG', 'C2SGlq', 'zNiTuG', 'xsbtDa', 'swTUuG', 'BNrPDa', 'AgfIBa', 'CMvNDq', 'wwL4rq', 'EuTyta', 'zxf1Aq', 't012Ba', 'l2THza', 'uK1Kyq', 'rfrTEG', 'Dw1AzG', 'DgfYDa', 'ntKZ', 'AuPAyW', 'Aw5Kzq', 'yxbWuW', 'ANv5rW', 'B0n3zq', 'CgG9qW', 'thbtEq', 'zvnLBG', 'Dg9Wlq', 'CxbSxW', 'rNfjBG', 'C2TIsG', 'uMH6vW', 'icdILze', 'q293qG', 't0HhCq', 'xsdINiuG', 'BKnwvq', 'zg9sBG', 'otKZ', 'uK9jEG', 'zsbZDq', 'Cgf5Ba', 'rsXUBa', 'mJe4', 'Dw50xW', 't2nruG', 'idbDoG', 'yw5VDa', 'wIXZDW', 'C3jODa', 'q0XzuW', 'AwrJxW', 'mJiX', 'x2v2zq', 'tujfuG', 'ueDnBW', 'BMvFBG', 'z1bjAW', 'AwvUDa', 'BwLU', 'zxvlEG', 'Euvbsq', 'DgHLia', 'zsbSyq', 'lwLUlW', 'rw50zq', 'z3fOua', 'BNvSBa', 'sLLTDa', 'tIXHCG', 'Cg9UCW', 'zsaODa', 'EfHKwG', 'nJC4', 'vsXLBG', 'zguGyq', 'C2fstG', 'C29JAW', 'Eg1SoW', 'C3nFyq', 'B3j0zq', 'l0ePqG', 'CYbHBG', 'zYbHyW', 'BwfPBa', 'Axf6DW', 'y09LzG', 'mJm4', 'thrVAW', 'CNzLCG', 'AhjIva', 't2jyrG', 'sK5yuG', 'u3yXxW', 'tcXUBa', 'uwrMAq', 'DgvYzG', 'uxjLAq', 'y1zAsG', 'yxnZoG', 'Dcbjua', 'AwvZrG', 'ugrUzq', 'zguUAG', 'BLv6rW', 'oLaTmW', 'v0DptG', 'zxnZyq', 'BhnLjG', 'A2fXCW', 'B20Gta', 's3DOsG', 'AKXoAW', 'Dgv4Da', 'ieXPyW', 'DLDLrG', 'lMfPlW', 'y1PUDq', 'mhWXmG', 'l2v0yW', 'ChjVEa', 'sNvMEa', 'AKfKua', 'ywDL', 'sYX1CG', 'sePTza', 'CMzHBa', 'CM4Gka', 'C3DVCG', 'rMLSDa', 'mxW2Fa', 'Bxn1BG', 'u2vSzq', '4Pwq4Pwq4Pwq4Pwq', 'C3nPBG', 'zgvIDq', 'zMTqCa', 'CLfrzG', 'ouDsB2HKEa', 'qJzc', 'Aw5Nia', 'DxrOxW', 'B21WBa', 'q3zfEa', 'q1zkra', 'BhLdBW', 'EuDtEG', 'vNL2sq', 'Eg1YsW', 'zxjZia', 'igXPAW', 'otu5', 'BvrAva', 'u0vsvG', 'ssXMCG', 'BguTzG', 'Bsbozq', 'mtmY', 'AMf6BW', 'lcjSBW', 'zwzNAa', 'AenIva', 'CNn0xW', 'zM5ZqG', 'y2nVDq', 'Aw1Lia', 'jtjgyq', 'ntiYnW', 'A25uzq', 'ignOzq', 'zNiTqW', 'jMLNxW', 'yv9HyW', 'CMqGlq', 'Dg90yq', 'ucbbua', 'rcbiqq', 'Aw9UxW', 'whPsAa', 'seeZoa', 'qtyWmq', 'x29Pza', 'zwjZzG', 't1ngtq', 'l3zLCG', 'lwLK', 'Agv3', '4Pwq4Pwq4Pwx', 'q21Qsa', 'Aw9Usq', 'ywqGtq', 'uNHkta', 'BNnMua', 'CfnvyW', 'BIbMAq', 'Evn6zG', 'tKjSAG', 't1zfra', 'v0v2wq', 'twLJCG', 'mJuY', 'DMvmAq', 'ruT3DW', 'sgfYza', 'BI94Aa', 'CMvKzq', 'ugzgyq', 'zfDKCG', 'sM1Ayq', 'AxnbyG', 'ucbSAq', 'B0PAwq', 'zcb0Aa', 'ywjSzq', 'B2TQtG', 'tcXOzq', 'igvYCG', 'CdOGsq', 'qIXHCG', 'zeLnsa', 'vcXWDa', 'AuDmza', 'BMrVBq', 'AwzPyW', 'ic8GxW', 'B3n3vq', 'mtC2lG', 'rvHZAa', 'y1n4za', 'vfjTBa', 'wZmYBq', 'A2eTrW', 'vLvgrW', 'BMfSAq', 'zs1pDq', 'DwXKxW', 'rKj5BW', 'CIbUDq', 'BL9JBa', 'zw50zq', 'ruPxza', 'y0v6tW', 'ru5ujG', 'zxjUyq', 'yxDnBW', 'zvjOyG', 'ks4Gvq', 'zujltG', 'Axf3uq', 'B2fK', 'zcaOCa', 'wM52va', 'twfYDa', 'mJmW', 'j19FFa', 'ywXS', 'C29Yia', 'wMXXDW', 'DcbSzq', 'CMLJDa', 'x3WGFa', 'x3nLCW', 'DfXdCG', 'oIiR', 'DgfUDa', 'Dg9tDa', 'B2LKxW', 'qKn1AW', '8j+MIIbnBW', 'DwX0kq', 'BMiTtG', 'y2uGvW', 'CfzdEa', 'ssbRzq', 'ienYzq', 'DhjPBG', 'sfrLCa', 'Evn1uW', 'B0Tstq', 'mJm5', 'CMf0Aq', 'DgvYBG', 'DwWUDa', 'CwLStW', 'icbtsW', 'zgLZCa', 'z3PPCa', 'y2jNrW', 'vgvWEG', 'B24GDa', 'rv9ovq', 'yI1Yzq', 'CgzNtq', 'zw5JCG', 'DZ0X', 'rsXMCG', 'CYbVCG', 'ntq3mG', 'uuPXEq', 'zMXVBW', 'B3jPzW', 'D2HPDa', 'zw4Tta', 'qvbjla', 'zw50lq', 'z19PBG', 'yMLSzq', 'zw4Tvq', 'xsbuzq', 'whLAAq', 'zgvMBa', 'CgvYqW', 'x18Gxa', 'lcjPCW', 'zxmTua', 'ChnqvW', 'CwDOwq', 'zwL2zq', 'zwvhEG', 'Ag8GiG', 'AKLYqW', 'CML0Eq', 'xYWGFa', 'zxqTqW', 'A0TSuG', 'ANniva', 'Afftyq', 'tvrtrW', 'B21vvq', 'ucXQyq', 'sNfMqG', 'twjeEG', 'D2fYzq', 'lI4UcG', 'uhjVEa', 'EKeTwG', 'w0vsuG', 'zNv1DG', 'zMfSyW', 'sNfjBG', 'EMvYBW', 'y3nPpq', 'zcaTia', 'x251Bq', 'wLH0AG', 'x291Da', 'pI9Kzq', 'D29YAW', '4Pwq4Pwq4Pwq4PwD', 'D3PmyW', 'B2q9uW', 'AY1WCG', 'yxLcwa', 'DhiTva', 'lcbKzq', 's2v5ia', 'BxmUia', 'zNiTrG', 'DgfJDa', 'vcXHBq', 'EMLSBa', 'otC0', 'B1f2qG', 'rYXHCG', 'ks5tzq', 'kee7qG', 'wMPfsa', 'l3yXlW', 'EeLTwG', 'yxrMBW', 'zfLpsW', 'lvjtqq', 'x2jLAa', 'zwfZzq', 'yvnOta', 'zg93BG', 'C2uGCG', 'B29NBa', 'yxrL', 'CxjZDa', 'CMvHyW', 'icdINjCG', 'zMLSBa', 'BgHqsW', 'ugz5Eq', 'q1Dcrq', 'ze90Ea', 'iZG4oa', 'v2LSBa', 'C1zluG', 'v0vyAG', 'jMzPCG', 'A0XoEa', 'DcaOCa', 'odu1', 'zw50ia', 'rKrUEG', 'AMDYzG', 'v0vQDq', 'Bg93pq', 'zePVEa', 'v2XewG', 'tuLcBG', 'rcXMCG', 's2TNAG', 'yw1ZiG', 'y2uTCG', 'EM5dEq', 'zw1HAq', 'vMHesa', 'scXHCG', 'zgH1vG', 'zg9JDq', 'zwqGDa', 'uYXLCW', 'v29HuG', 't0Xzmq', 'BLfvqG', 'yxzPzW', 'FcbLyW', 'zw50Ba', 'D01JDq', 'B2LKia', 'Awq7ia', 'CKTxsW', 'Aw9UiG', 'uIX0CG', 'DcbKzq', 's3fiuq', 'odu2', 'mszQyq', 'jMrLDG', 'Aw9Z', 'zg9I', 'zNiTtG', 'oIjYzq', 'vMH4tq', 'zgvUyW', 'ywrLCG', 'DKLQwG', 'z19VCa', 'vgXxBq', 'yKzHzG', 'A3rmAW', 'r1PztG', 'wNHpCq', 'ruDjtW', 'AMTZvG', 'C2K9', 'x3nVDq', 'icGOja', 'vcXPDa', 'Bxrrra', 'r1bvDq', 'scX0Aa', 'mJyZ', 'x3bHCG', 'zNjWqq', 'zYbZzq', 'sMrxyW', 'Es1HzW', 'iMXVzW', 'ihnLyW', 'wK90Bq', 'zu9IAG', 'BLzZra', 'zcbMCG', 'qIXLBG', 'ica6ia', 'A3KTsW', 'y2LLCW', 'x25HBq', 'BK9NEG', 'y3bFzq', 'C3rVCa', 'Df9PBG', 'AwXLia', 'yuTzvW', 'Axn0CG', 'BNriAq', 'qw5KCG', 'Dejgva', 'Aw9Uia', 't2zuvG', 'v0LeoG', 'EYjHyW', 'z2rfCW', 'DfjtAq', 'BeHhzG', 'oIboBW', 'zwqIoG', 'CKXhBW', 'zsi6BG', 'zxiG', 'ne1xqG', 'mti4xW', 'jMzVyq', 'rKHsqq', 'zxz1uq', 'C2v0lq', 'lJaGka', 'xsdWN5seia', 'vgHVBq', 'ie51Bq', 'q3bHza', 'rMvvEG', 'yM4TqG', 'tuLosq', 'BLrUva', 'zvngza', 'qsXMCG', 'iefqsq', 'y2HHCG', 'tgLJzq', 'Dg9FzG', 'DgvZDa', 'B3C9BG', 'xsbgzq', 'zwnKsW', 't1rqoG', 'ie1fva', 'zNiTrW', 'yM5nDW', 'yKzgzq', 'zxjYBW', 'CY50Ea', 'ifDPBG', 'wungva', 'zxqP', 'uIbttW', 'BMqTCG', 'ywXZzq', 'wK9vAa', 'Ce1NDq', 'zw50xq', 'y3jHCa', 'C3CTsW', 'ns4Wia', 'iJPUDq', 'As9Ryq', 'yxrLuW', 'y3jVCW', 'x3jLBG', 'BvbxrG', 'D0nfEq', 'CMv0CG', 'ChjOtG', 'BeP5wq', 'DgvYlq', 'A2LcsW', 'yNjTEq', 'zg1JsG', 'v2v2Dq', 't1n0CG', 'DgvYia', 'luvdra', 'y2z0vq', 'ignVBG', 'mJq0', 'rujPAa', 'z2f0zq', 'quvjDW', 'zwrNzq', 'Dc4k', 'wfGPoG', 'Evrrwq', 'AeLUrW', 'CxHbCa', 'EM9zzq', 'CIbYyq', 'AvLhEG', 'ChjVzG', 'CMvUza', 'ksGGkq', 'quvtxW', 'jNrOAq', 'uuDREa', 'EhbytW', 'igfUza', 'CdmVzW', 'B21LlW', 'C2vJlq', 'zsKUtq', 'y3rYBa', 'zw50xW', 'ls0ktq', 'zxHOAa', 'iJGI', 'q2Tstq', 'x3bYzq', 'sw5ZDa', 'wvzYvG', 'CNnltG', 'v3PquG', 'v2DisW', 'CMvZDa', 'zYaGia', 'Dd10CG', 'igLUDG', 'D1bHqq', 'ihnLCG', 'kg5VBG', 'svHmvq', 'tcXWDa', 'ttPCuW', 'Aw1LBW', 'CMfnAq', 'AKLtra', 'ihjLza', 'zY4Gmq', 'DhK9', 'tuTlBG', 'wwPgqW', 'EgzQuG', 'ie1VyG', 'ChmLmW', 'D2ztrW', 'y3qP', 'thLTEq', 'BgDOtW', 'j0Hlta', 'CM94Eq', 'qwXpzG', 'tvn0Da', 'tNfMCa', 'zwjlAq', 'scXKzq', 'icboBW', 'EKHLDa', 'DxLIra', 'Exb0BW', 'mc44la', 'zLn3za', 'B2rozq', 'A2XUvW', 'Dgf0Dq', 'txv5BG', 'BMXVyq', 'oty4', 'x3DLyG', 'DMvKia', 'vvPoEq', 'r0Dosq', 'Agv4', 'su4Gua', 'vvbDia', 'ihjLyW', 'EgL0Aq', 'qvrkDa', 'zxi9ma', 'Dur5Ca', 'ALn1Ca', 'vYXYDW', 'ChqTrW', 'v0DHuW', 'zNiTra', 'zw1PDa', 'ruX4vW', 'BIbMyq', 'x191CW', 'yMfZzq', 'uMThsq', 'vffLtG', 'Aw5MBW', 'ELLzBW', 'BNnUta', 'r1Lfta', 'AMjnsa', 'zgDcua', 'qw5Kzq', 'yxbWzq', 'zxnZzG', 'icHUDq', 'Dun1sa', 'DNrbzq', 'sunRAG', 'ugnxrq', 'tsbHCG', 'q3zftG', 'rwLgsW', 'ifvoqq', 'BgvUzW', 'DhjHDa', 'Bc1VDa', 'AY1KBW', 'thL3wG', 'uhrMqq', 'seuTrq', 'AxmGyW', 'yuLAsa', 'BvneDW', 'x3WGjW', 'cIaG4PYx', 'zwn0zq', 's2zOBW', 'ntu0nW', 'vvjdrq', 'C2v0sq', 'rMvpCW', 'CML0', 'D0vgwa', 'x2LKpq', 'AfDbAW', 'zwn1CG', 'ywnOAq', 'yv9HCa', 'i0zgna', 'zvPSzq', 'zM9BCa', 'uM9VyW', 'ENPMCq', 'xsbhBW', 'AMHWtG', 'CLnfvG', 'z3vUEG', 'zxr1CG', 'Ehjmvq', 'B21cEq', 'sMfJAW', 'D2f0zq', 'EgDzEa', 'igf2yq', 'AhnP', 'zwPbDq', 'AgLUzq', 'z2jVtW', 'BuD0DG', 'EfrJEG', 'qLbqAG', 'rvbJAW', 'v2vbsa', 'DgLUDq', 'k0zUnW', 'D0fyEa', 'Ae5Szq', 'DNbjta', 'DgPHsa', 'wKXbvG', 'AwDHDa', 'y291Ba', 'C2uMBa', 'tYXHCG', 'iokuGIa', 'rg10Ca', 'uxDnEq', 'rwPTBG', 'DwXSla', 'yxzPBG', 'CNCTuG', 'qYXLBG', 'CxD4zW', 'rvriCG', 'AK5iuW', 'ChPKCq', 'C2v0Dq', 'u2vYDG', 'DgjzDq', 'ieHuva', 'iZqYnG', 'tcXLBG', 'zxqGyW', 'B3PJuq', 'r0HjsG', 'Chfqza', 'igrPCG', 'B2jAqG', 'AwqLmG', 'iZaWrG', 'r0roDa', 'zw5KCW', 'zxiGCG', 'z0rWva', 'ihLVDq', 'DgHLBG', 'zNvUyW', 'DxiGsa', 'z2DLCG', 'yMnSqG', 'Aw5Ozq', 'zNjVBq', 'y2vjra', 'rsXKzq', 'v2XXtW', 'zxmTrW', 'DgvY', 'yMXeAq', '4Pwq4PwDcG', 'xYbFia', 'Df9WBW', 'zsb8ia', 'y2SUlG', 'BYbSBW', 'w1nfva', 'C0jItG', 'rLPOEG', 'EKfRwa', 'tKv0CG', 'B2nqwa', 'y05cCW', 'AwnHDa', 'CMvJDa', 'uIXRBW', 'A3m9zG', 'ihbYBW', 'veTQzG', 'tM8GAa', 'uunzrW', 'vfDyvG', 'yxvSDa', 's0n4vq', 'vfHpAW', 'q0vqsa', 'mJy2', 'C2vYkq', 'B21PDq', 'v3DJwG', 'DgSTva', 'zxe9', 'u2znvG', 'C3rLBG', 'Cuf4Ba', 'zvPitW', 'BfbqCa', 'yxiTuq', '4PYtifrH', 'yw1XDq', 'mJq2', 'BMjiBW', 'BJTXpq', 'CgWTua', 'wvrJtq', 'q2XYAa', 'psuYqG', 'tLv6na', 'BxmTqG', 'BgLUzq', 'rgfUAq', 'mJiZ', 'zfnpCq', 'DNzLzG', 'ihWGka', 'BNrHyW', 'EwXqyG', 'EM9LCW', 'sw5ZDq', 'CgvYia', 'wLfNrq', 'v2zWDq', 'reHflq', 'x3XCxW', 'uxDUsq', 'zxy9', 'v3vqrq', 'BNHMEq', 'ChmTqq', 'AwXHyG', 'te9Ltq', 'r3LRAa', 'ywDLlW', 'vgjqEa', 'CM1HDa', 'ELr2ta', 'wZmVna', 'yxiTqG', 'uhjVyW', 'rKnMta', 'AKrLwq', 'su5hia', 'CKTyuq', 'BMrVDW', 'zv09', 'tvnADq', 'qxLWBq', 'sfLqoG', 'Awz5', 'v2fiEq', 'B2zFyG', 'ntaGva', 'zs1Yzq', 'yxiTsW', 'BgrvAq', 'B2DTrq', 'uK9sEG', 'ts1tsa', 'wgDfwq', 'x2LKzq', 'icHfCG', 'lJaMza', 'BvLTvG', 'uIXMyq', 'B1TKzq', 'u0vmrq', 're5Nra', 'ue1htq', 'y3roAa', 'vMvxDq', 'lxnHDG', 'ue9mwq', '8j+hQVcFH7GGu3a', 'CvPTCW', '8j+oSIbsyq', 'BMCSkG', 'ieHxsq', 'yM9Sza', 'y2C9rq', 'C3rHBG', 'CMrFCa', 'Axr5lG', 'BMTkuq', 'zw5Xsq', 'qMzPyG', 'EJ9FxW', 'DerduG', 'wNfYEG', 'CfzPAG', 'CMvHCW', 'AwrDpq', 'AwPVDq', 's0vzlq', 'mJu0', 'BfjKsa', 'DfrPBq', 'mtmYnMrcD0zRCG', 'z2LUia', 'y29YCW', 'EfLfrW', 'drTBsW', 'uIXWDa', 'AxvTia', 'rvDnyG', 'CK5izG', 'ywrLza', 'mtaGva', 'zcbZyq', 'B3iGka', 'x3n0yq', 'B2TLBG', 'D0HovG', 'r0zNza', 'mtGYoq', 'B1ffsq', 'tsXLBG', 'Dgviyq', 'sg93ia', 'Cg5xAq', 'z2LZDa', 'lxDgmq', 'zxjFAW', 'tgvUzW', 'pszHyW', 'tvjOuW', 'ywqGAW', 'zwnRxW', 'B3DU', 'rKfeAG', 'ywXeAq', 'qKvIBG', 'yxLSBW', 'ywXSxW', 'CgHztW', 'EgnLCa', 'rgXNqW', 'uMLJAa', 'BejZzW', 'termCq', 'vvzVuG', 'AxqTsq', 'CNnOzq', 'vcXKEG', 'Aw9U', 'BYbWCG', 'ue1vEa', 'zM91BG', 'Ehv3yq', 'sxnwAa', 'mJqZ', 'Aw9Muq', 'rwjhyW', 'ihWGia', 'm19ZzG', 'x1XFFa', 'vLzcwq', 'CL9Tzq', 'rwHSAW', 'ChrNDa', 'AcaOzq', 't0DKsW', 'uMLJtG', 'sgP0rW', 'BM1Ozq', 'uMHOAa', 'mZjFta', 'wsXLCW', 'vePIAG', 'EfP2Cq', 'wKPoAG', 'CezrEG', 'x25HDG', 'BNnmuq', 'xsbqyq', 'mJqX', 'uLnblq', '4Pwq4Pwq4Pwq4Pwx', 'rfvlyG', 'uvH5CG', 'jNjLzW', 'rYXLBG', 'Bs8/DW', 'AdTXpq', 'C3zeEG', 'DhjHCa', 'CxfXtW', 'zYbbyW', 'BgLKia', 'yMXVyW', 'ifbvqG', 'Dxn0kq', 'ANvjAG', 'BwfYEq', 'ntK0', 'rwLMvG', 'tYXYBW', 'v0XYCa', 'icOOpW', 'rLPQra', 'rvDbra', 'zMTSzq', 'ifXFxW', 'q29UDa', 'DvjvzW', 'ifrVAW', 'yMfUBG', 'Chr5ia', 'zszZBW', 'Aw5N', 'zLvzvG', 'CMvZCW', 'zcbMBW', 'BhmV', 'uLHyuW', 'xcTCkW', 'ne5tta', 'rufkwa', 'veXmua', 'A0DNuq', 'oIb0lG', 'vMPvDG', 'D3j5za', 'vgLXtG', 'ksbbCa', 'luvYCG', 'u3bQtW', 'ihnPzW', 've5ztW', 'ywXPza', 'CgXPyW', 'wZmXBq', 'DgeGCG', 'Eu9zsa', 'yMTlua', 'AxLhEG', 'lYbCxW', 'zgLJDa', 'tvvKCq', 'rKPvCa', 'B0HbtG', 'zxiGjW', 'CNrPBG', 'q2jTCW', 'Dw5RBG', 'BMqGAq', 'tMLKvG', 'DgDLEq', 'uK9gsq', 'Dg8MCG', 're9TyW', 'nJCZ', 'vMrRta', 'ywPpEG', 'zgf0zq', 'igzVDq', 'CMfUzW', 'iJT2pq', 'Df9MBa', 'lgLTyq', 'v0X4vG', 'CMqGkW', 'uMvMuW', '4PYxie5V', 'nZvHBW', 'nty6rq', 'BwvUDa', 'x3vZzq', 'CgPWDa', 'A0j4zW', 'zsbUBW', 'rxjYBW', 'z3jPDa', 'yMLOwG', 'zw4TwG', 'yxiTsq', 'iKnOCG', 'reXwBa', 'x198xW', 'v3njqG', 'DxrMoa', 'q1qGuG', 'BNLWzW', 'DgjLvW', 'tMPPwG', 'zw5Zzq', 't0zuvW', 'Bwv0yq', 'AujREa', 'uIXLCW', 'CfD0DG', 'sLfcvq', 'x25Onq', 'tKj0ta', 'su9fuW', 'D3PcCG', 'zejvEG', 'uhjgyG', 'swvRza', 'ntqZ', 'C0fqqq', 'qsXLBG', 'twLJAa', 'zgv0zq', 'vYXLBG', 'tM8Sia', 'zwrFzq', 'z3D4tq', 'yMLYDa', 'AwPzva', 'mJu1', 'DwX0oG', 'Bg8Tta', 'x2nOzq', 'x3nLBG', 'Dg9gAq', 'DhKV', 'sfDUsa', 'Cg93zq', 'B1TWyW', 'rxzLBG', 'B2z0ia', 'wgLAsG', 'CNnVBG', 'B3jTyq', 'isbqBa', 'yxjRzq', 'sKX6wG', 'z2LUlW', 'A2CUmG', 'lHTBma', 'zxmTtq', 'r3joEq', 'DtPNoa', 'otK4', 'C3nFzG', 'tMn5Ea', 'sMrpwG', 'ywzprq', 'rIXWCW', 'zwqG4OAs', 'CM9YoG', 'if9Fia', 'zxjYAq', 'yxzLza', 'q0XUva', 'Axn0zq', 'DgvUyq', 'yxrLiG', 'C3q6Ca', 'g1SYsW', 'DwzXwq', 'CMvWBa', 'DcbMBW', 'EMjisq', 'igj5ia', 'ic1fCG', 'Aej1va', 'CMvZDq', 't0zvqW', 'mJmX', 'uwnKyq', 'iIWIAq', 'kcGOlG', 'lxPblq', 'mJuX', 'uML5AW', 'zMqUqq', 'mJu0mW', 'BgvK', 'uKnktq', 'ie1PEa', 'ys1WBa', 'BxmTtq', 'zguTra', 'yNjVDW', 'nhWYFa', 'CMv1CW', 'yw5KCG', 'uYXHCG', 'suq4rq', 'ExPbqG', 'l3nJCG', 'mJi4', 'DxjPCW', 'CenYuq', 'uNLoua', 'wuP2uG', 'ANbRtq', 't0LHra', 'DMfS', 'yxboDG', 'BcbKzq', 'tdOGsq', 'ndmSiG', 'oc1hqW', 'oIjWyq', 'z2vYzq', 'z2v0rG', 'BgLyta', 'otCZ', 'y2vUCW', 'rfbbAa', 'BgX5', 'otCY', 'qNjPyq', 'BMWTuW', 'yMHZqG', 'BK5gyG', 'BhnKpq', 'BZPJyq', 'wMLjAG', 't2Pluq', 'x2LTCa', 'ywqG4OAs', 'BL9MBa', 'ChqTqq', 'uJbHtq', 'ugPKDW', 'mti5', 'Duf0Ba', 'BgX5iq', 'BKv6sG', 's2v5Ca', 's1rTDG', 'mJm2', 'Dg9mBW', 'mtmW', 'lw9Mlq', 'uxbQtW', 'ugXLyq', 'svPoqq', 'C2uGyW', 'igzVCG', 'BgfUAW', 'C2vYiq', 'rwfRyG', 'zwjWla', 'AMjbyW', 'D29Yza', 'ENLWAG', 'Aw5HBa', 'BIaGia', 'zwvK', 'x3WGia', 'AxjZDa', 'AfHpvW', 'CYbRzq', 'qNjqrW', 'zv9JAa', 'Aw50zq', 'ywqGzG', 'su91uq', 'iZu1nq', 'x3LVDq', 'r0rPvq', 'lw9YAq', 'BLfjsW', 'y3b1la', 'icHFkq', 'D109zG', 'vLfZCW', 'tYXUyG', 'odGW', 'CgfKrq', 'mwm6mW', 'BNnLza', 'zLzitW', 'uLLOAG', 'zNLPBG', 'lIbbyG', 'vtDqyW', 'x0jHCW', 'ucbMBW', 'pufFqG', 'tK1ytW', 'CJTXpq', 'BKzoCG', 'y3bSAG', 'EM9juW', 'DcbmuW', 'zw5JAq', 'mJu2lq', 'DgfSBa', 'A2v5Ca', 'yxrJAa', 'ihnHDG', 'C2uMyq', 'lJuWna', 'CKfJDa', 'vMj2Eq', 'BgWGlq', 'yK9bsW', 'ChqTqG', 'ntKX', 'zszWyq', 'v1nfuG', 'EgLLCW', 'CMPjsq', 'v3rLCG', 'ntKY', 'vMHLuW', 'zxiGmG', 'ig5VDa', 'rgDszG', 'B21LiG', 'sLnfAG', 'DujPvq', 'thzjsG', 'BMqGtW', 'CKTysa', 'iJOIkW', 'z2uIoG', 'C0vbCW', 'qvL2CG', 'cIaGgW', 'uYXLBG', 'rsXZDG', 'z2v0CW', 'svz4Ea', 'r1zmtW', 'wZqVna', 'qNjpAq', 'yxv0Aa', 'y2vFAq', 'q3j5Ea', 'Dg1SkW', 'wdi1nq', 'zw4TrW', 'Bu5Nta', 'DuTLEq', 'wxrrBq', 'r1PPsW', 'Cf9Pza', 'yv9JBa', 's0PHvW', 'z3ncrG', 'zwn0', 'tuvkrG', 'C3vICW', 'EKHvuG', 'CMq9', 'rLrNuG', 'q01FuW', 'rcXHCG', 'y2juwq', 'CMfUza', 'qvnwwq', 'CMLMEq', 'zY50Ea', 'Aw5PDa', 'B2Xnzq', 'DwXSwq', 'BNqIoG', 'Axnuva', 'D29hCG', 'odq6rq', 'CxfVDa', 'ywn0lq', 'icdINjmG', 'ue9yAW', 'mJiY', 'DNfqDW', 'id0Gka', 'vfvqxq', 'AgvHza', 'uNLHBG', 'DY1MBW', 'mtaWia', 'u1rfuG', 'A2vSEq', 'wsXLBG', 'A0DIDq', 'yKPRyq', 'A20TsW', 'AY1JBW', 'ifDOyq', 'B3iG', 'zxnWBW', 'uMPXAa', 'iIWICG', 'yM5drq', 'ihT9', 'x2LKiG', 'zNi7Cq', 'tLH3ua', 'C2uGAq', 'lJKSCG', 'yw5Jzq', 'zw4TrG', 'tIXMCG', 'v2jRCW', 'Es91BG', 'C3rFBG', 'icbCxW', 'qMngAW', 'B3v0', 't2zmvG', 'mg0k', 'rhzcEq', 'q1qGtG', 'wKftAq', 'CYbgAq', 's3zLuG', 'BNrZ', 'DKPQzW', 'u2fMyq', 'y0TKDG', 'quPuva', 'vJuG4Ocu', 'twrzzW', 'jNnOBW', 'quz2Ca', 'ys5JBW', 'u2f2zq', 'uKLArq', 'x2f1Da', 'ChrLza', 'DxzbyW', 'FdH8mW', 'C2v0Da', 'Bwv0xW', 'lIbuyq', '4PYxievY', 'yxrOia', 'uwLytq', 'q29Kzq', 'CezbvW', 'jMfJyW', 'uxfqAa', 'A0HWDa', 'qLP1tG', 'ywLSzq', 'CvfpAa', 'tundBW', 'zgvUDa', 'mJi3nG', 'ELPirG', 'DdOGBG', 'ugnhua', 'DwvZDa', 'wwvZ', 'D2LXBG', 'mJmY', 'Ct0WlG', 'Cgndzq', 'A2jRsa', 'mJmZ', 'Cci6iG', 'wK9Osa', 'Cgf1CW', 'nhvpEG', 'y2jzvq', 'C2uGuW', 'zv9Zzq', 're1oEq', 'zw4TsG', 'B25FAG', 'u25hCG', 'zxPjwG', 'vsXYDq', 'Afv3ua', 'nLnFAG', 'z2DLza', 'igj5Da', 'wwTWwa', 'Aw5NlG', 'DNDPsq', 'DMfSDq', 'y1LRrW', 'CgLLza', 'AYbMyq', 'EMLUzW', 'zNjSxW', 'sIXLBG', 'g1SWBq', 'C3bSAq', 'uIXLBa', 'Eu5Mzq', 'ifrPBq', 'ruD4EG', 'igXLyq', 'wwvZla', 'BuPpDG', 'iokgKIa', 'Dc5Tzq', 'x19FlW', 'r2v0lq', 'qsuYrG', 'B3iGAq', 'qNbmwa', 'x3rVAW', 'EKjTsq', 'C2f2zq', 'q3rvtG', 'C2vYDG', 'DuXJyG', 'uez2ta', 'sMzYva', '4PYxifLV', 'scXRBq', 'DxrOlG', 'DgL2zq', 'Cg9PBG', 'zxD0wa', 'v0Leia', 'yxHtyq', 'y3j5Ca', 'q1rHrW', 'tevova', 'zxiGka', 'CgPcsa', 'Ag9ZDa', 'zs4UlG', 'wMvUra', 'B2WGia', 'EKDNqq', 'C1npAa', 'z1vNwG', 'x2fWCa', 'ihvUza', 'ierpqG', 'kYKRkq', 'CwTdzW', 'mY9Nzq', 'zMXHDa', 'v3jPDa', 'icbFxW', 'yNP0sW', 'zNvSia', 'ls0Tlq', 'zguTqW', 'BeLftq', 'tK9uia', 'tefAva', 'tLzKAa', 'Bv9Xzq', 'yLHWBq', 'rKPYyW', 'DwvKia', 'Cxfzvq', 'CM9Tia', 'nJm4nq', 'mtG4lG', 'zM5bCa', '8j+mKcbhBW', 'CZ0Yma', 'zwXtvG', 'q1D6sW', 'DgHKyq', 'C3DPDa', 'mJuZ', 'yw1XyG', 'zw4TvG', 'AwX6ua', 'zMPkAa', 'C3nLCW', 't0S6ia', 'uLzSvG', 'D2vYqW', 'zvn5BG', 'yxiTsG', 'uKnKwq', 'lsbtqW', 'lJKSzG', 'BLHPzq', 'y2HPBa', 'z3rMzG', 'DhLWzq', 'Aen1Ea', 'qNLWyq', 'zxiGwW', 'ywLSyq', 'mJi0', 'BvDNua', 'u2rVAa', 'BhzorW', 'mtm0', 'suH0Eq', 'yxnL', 'BNqGyG', 'DLDXsa', 'CMLHBa', 'Ev9WBW', 'z3nJqG', 'q29fzW', 'C28TuW', 'AwXLxW', 'zYbjBG', 'x3n1Bq', 'zw4TuW', 'wuXbBG', 'ndi5', 'tsXTEq', 'sgr4yG', 'ie1LDa', 'Dgu9', 'D2LMDq', 'zYbSBW', 'nZeZmW', 'sxjvwq', 'BgvNCG', 'zLLmEq', 'tYXLBG', 'D3vdDG', 'vNDSrW', 'yxjNDG', 'mf9Ymq', 'q2fwqG', 'Dfznrq', 'rwHpDq', 'vuDbAG', 'igLUCW', 'turWDG', 'twv0yq', 'ptmZjG', 'uM9KCG', 'u2X2DW', 'zfPtBW', 'qun3vW', 'u2vcCG', 'CvnQtG', 'Aw9UCW', 'EMvesG', 'mJqY', 'ig9Uzq', 'EsbMCG', 'uvr6wG', 'DwrLCW', 'Dg9vCa', 's3HOEq', 'g1SZsG', 'AxnV', 'D0TqzG', 'r0zvBW', 'ANvLBG', 'BMDPzG', 'r0PzDq', 'AufQBa', 'twfRzq', 'rhnQyq', 'rMTiqq', 'sfHdtq', 'zcbUBW', 'BM1Puq', 'pxrYDq', 'mtqXnZq0rgnmC3Ld', 'BM9Uzq', 'jMnVza', 'yxrLza', 'y1L4wG', 'jL9FAG', 'yMvYCW', 'zxjZlW', 'BgD4AW', 'zw50pq', 'u09brW', 'BL9Pza', 'AxD3DW', 'suDMtG', 'q3zera', 'we9iBa', 'Df06', 'zwzHDq', 'mL9qCG', 'jL9Fyq', 'yNzvAW', 'yMHytG', 'AvjQqq', 'mdaPoG', 'ihzHBa', 'zs4k', 'Dxz3Ea', 'DguIla', 'qwDLBG', 'sfjfqq', 'CMvXpq', '8j+mIIbnAq', 'ndCYnq', 'CMXLBG', 'CMuGqq', 'mZmMxW', 'DNPrsa', 't04GCG', 'Bwf0yW', 'otC1', 'z3jHCa', 'ntyTuW', 'B21Lia', 'kcKG', 'zxmTrq', 'BezMBW', 'vhPcyq', 'AwnLBG', 'r3zZrG', 'ifnLCG', 'DKv6Da', 'ywn6Ba', 'z2HLCW', 'AhjMqq', 'DYbRzq', 'EhKGzG', 'yxn0xW', 'yxzPBW', 'wLLMDq', 'keDLDa', 'zfKWmW', 'x2LKxq', 'qwnVsq', 'ieLelG', 'CeHuEq', 'Cg9YDa', 'A2r1Ea', 'Dg9Rzq', 'C2vUDa', 'ALruDq', 'ufLWyW', 'qxrZCW', 'AxjLyW', 'xsbwzq', 'zhfUAG', 'vfLYBG', 'uKuG4Ocu', 'C2vHCG', 'rfPwvW', 'mJaGva', 'jMrHDa', 'ienptq', 'veL4vW', 'BcbYzq', 'CMvTzq', 'rfrPyW', 'oLWNjW', 'jNrVCW', 'AMDKEG', 'zw1WDa', 'r0vu', 'x2nVza', 'nY4ZnG', 'yw1Lpq', 'uIbnrq', 'lcjZDa', 'rKT0BW', 'uunWvG', 'BMv0DW', 'tg9Wzq', 'uuPbvW', 'tePisW', 'DguGCW', 'DhH0', 'vLHwta', 'qtPfqW', 'E30UyW', 'r3fxBa', 'turXzq', 'sLfzvq', 'ExbLpq', 'rMPOza', 'vMvYAq', 'CvPprq', 'qMnJBa', 'y29Tzq', 'DgHYzq', 'jNbOBW', 'ELL1vW', 'sfHxrG', 'rxLREG', 'zxvL', 'CM9Tzq', 'jNjLza', 'ywn0Ca', 'nJGW', 'sNb2uG', 'y0fPsq', 'yMPNDq', 'BwuMzq', 'igLUia', 'y29Yzq', 'B2vZDa', 'thbpCq', 'weD3vG', 'r09xtq', 'BKPQDq', 'mJu2', 'swngsG', 'tfnFqq', 'BwfPBG', 'Ewnwwa', 'shzKEG', 'y2TLza', 'u29HrW', 'AxjLza', 'DgvJDa', 'vufmCa', 'AwD1zq', 'rfDHrW', 'kev4Da', 'u0HbmW', 'iJeIFq', 'nZe3nJG3qKDNExrW', 'ieeOqG', 'yNjHxW', 'ywXSzq', 'B2rMvW', 'zYbpva', 'rxHPDa', 'x2rPCW', 'wwfpAW', 'AYWKBq', 'yMfNza', 'zNiTtq', 'zxi7ia', 'zw5JBW', 'su9TwG', 'ANHhtq', 'y2nLCW', 'xsboDq', 'rKfuqq', 'ndy2', 'D21jwq', 'vsXLCW', 'shrUwG', 'CgfKuW', 'wIXHCG', 'mJy3', 'yLPQqW', 'Bwu9', 'wNvTva', 'tsXHCG', 'shjmsq', 'wKLyCa', 'iokUNIbB', 'BfvpAq', 'qMvUzW', 'yMLKpq', 'wLnxsG', 'wvz0uq', 'zsaTqW', 'CIboDq', 'B250yq', 'DxbKyq', 'BNrSzq', 'mNW0Fa', '4PYtieXV', 'DhjHyW', 'zw5K', 'Egfpva', 'q1qGva', 'BMDLia', 'lIbqBa', 'sfrnta', 'twHXua', 'B3n0lG', 'vKzWwq', 'jL9FAa', 'rsXLCW', 'AYa9ia', 'icGVCa', 'EePKzG', 'C0PQtW', 'yxnZqa', 'tunNzq', 'BNrMjG', 'CNmGyq', 'yxbWBa', 'z2Lqvq', 'FcaGia', 'keXPBG', 'n0yY', 'u2vUDa', '8j+tGsbmBW', 'zePhEa', 'B0j6uG', 'CMvTBW', 'tLvWyW', 'u2LSzq', 'zxrLlG', 'zezoEq', 'Bg93xW', 'ug9MDa', 'yxfzsG', 'tMrivG', 'y0XjCq', 'zsbMCG', 'vevWsG', 'uNrxrG', 'qwnJBW', 'BgfZDa', 'otG2mG', 'Ag5kCa', 'ntu2qG', 'Awq9mq', 'EvnKyW', 'BMrLBG', 'ywjYyq', 'wxjQzG', 'keXLyq', 'EfDvrG', 'C3nPBW', 'DxjJzq', 'tMfpDa', 'x2fNzq', 'yKTLrq', 'khj1BG', 'DNHNua', 'Dw50ia', 'r25JEq', 'nxW0Fa', 'DgvZ', 'CuTPra', 'x3n0zq', 'Ag9JEG', 'BMCUia', 'qwv4uG', 'qYXLCW', 'CM0TDq', 'zMLNDq', 'Dc81mW', 'lxjLCW', 'BMnYEq', 'Df91CG', 'qunlCG', 'BM8GyG', 'C3qGDa', 'CY4UlG', 'z3fdAW', 'CuDWqG', 'zgvYAq', 'v3DJEq', 'zxqGzG', 'ExPPvG', 'AhPcsG', 'Dhj1yW', 'jMfSBa', 'rvLvtG', 'D21gwa', 'y2XVCW', 'yLDnta', 'BM9UyW', 'CMvMBW', 'yKHNEq', 'zYb0BW', 'BMLUzW', 'mJyY', 'z0zTrq', 'DLL2BW', 'CM9Yia', 'shfuvW', 'zhmGka', 'BMrZia', 'nZaW', 'C0jTvW', 'AwW7Cq', 'mJK5na', 'B3vYyW', 'kI8Q', 'D2n3wa', 'DwuPlG', 'yY9JCa', 'AhnrBG', 'surIrW', 'B3v0lG', 'psaOrW', 'CY1fuW', 't05fua', 'otyZ', 'mYz0CW', 'B3iGza', 'twLSBa', 'tw96Aq', 'iIWIzq', 'C1nJBa', 'yMTyzG', 'z2LUlq', 'v2zIAq', 'otG0na', 'DLrPEG', 'w2rLzG', 'D19VDG', 'uej2wq', 'AvnrBq', 'zgvSzq', 'zszZAW', 'r1DntW', 'reHrsW', 'y2jgCG', 'y29UyW', 'ywDLqW', 'qMTtyG', 'C3rHBq', 'i0zgra', 'zYbmAq', 'vgnyBG', 'uMvZCa', 'DxiTua', 'xsbtzq', 'sYXKyq', 'rxDOzq', 'icaGxW', 'DsbTDq', 'Av9Rzq', 'r0TowG', 'BcbuAq', '4PYxifnH', 'zxiHkq', '4P6ug1SZ', 'mta0ma', 'r1vguG', 'C2uMCG', 'ANvZzW', 't1bFtG', 'mJyX', 'CNnPBW', 'DvLUua', 'mJK3D2LwDLDX', 'z2fcyq', 'y3jPCa', 'C3CTva', 'ssaGlq', 'zu9qtG', 'D09hCa', 'BuTNDq', 'wenfta', 'B25FBq', 'yKjfCW', 'zguTqq', 'DgfTCa', 'jMHHCW', 'BhfTta', 'tNLtsq', 'ibTBoq', 'zMLSDa', 'otC3', 'CMvJBW', 'zxmUia', 'AgL0ia', 'A19TBq', 'CgLWzq', 'zY4UlG', 'zMLYBq', 'zNiTuW', 'sef6rq', 'Df90Aq', 'BNrFzG', 'AxjTzq', 'y29VAW', 'Ee9M', 'DLj1vG', 'zxH0tq', 'D1Dtvq', 'nNWXma', 'vwTmsq', 'igHHCW', 'mJm1', 'o3e9ma', 'x3bYBW', 'zuX3AG', 'qti1nG', 'yxbPsW', 'B25Zzq', 'yxzPzG', 'DgvNCG', 'lJKSEG', 'kc4UlG', 'BM5jEq', 'ANvUBa', 'ihrOAq', 'ntaWkq', 'yMvYxq', 'z2vLCa', 'Dw5N', 'C291CG', 'BNqVCW', 'CKXlva', 'zxj2zq', 'zxi6Ca', 'Bg9Jyq', 'zuvQqW', 'suv2yG', 'Axr5pq', 'CxvPCW', 'DMfPBa', 'ze5osG', 'jNbOpq', 'vLHuwa', 'DxG7ia', 'jsdILiiG', 'Eg1Sla', 'tw1RCG', 'B1rTCW', 'ie5Via', 'Aw5WDq', 'wMvJuq', 'ChqTva', 'u2PTsa', 'BMnLia', 'yxbLCG', 'twzRyG', 'ruqGlW', 'lw9WDa', 'vwPkAq', 'CMv0Dq', '4Psa4Psa4Psa4Psa', 'ihn1yW', 'lIbfEa', 'Bxj0rG', 'vgLTBW', 'x3vYAq', 'usXMCG', 'FdD8mW', 'uYbtyq', 'vg9Via', 'v2LSCW', 'otK2', 'ifjftq', 'suTYua', 'uIXMCG', 'zfzPzq', 'wevqrq', 'AhvdBG', 'BgvKia', 'zv9TDa', 't1rqia', 'mJyW', 'oIbUDq', '4Psa4Psa4Psa4Psy', 'mIiSiG', 'Euvmsq', 'zguIoG', 'cLTtrq', 'rc9kyq', 'Bsi6zG', 'BNfhAW', 'yMLSAq', 'D0TNyG', 'nJC2', 'zM9Yrq', 'sNnKuq', 'BNvTyG', 'wcXLCW', 'BNvHvq', 'y3qTtW', 'wNzhuW', 'yxrPBW', 'y2HYBW', 'ywTHCW', 'BgvtEq', 't2DjCG', 'DNn1Ca', 'mJq1', 'rcaGia', 'uePOCq', 'mJm0', 'CNr5ia', 'zxqTsq', 'B3fhAW', 'zxLZoG', 'z01mCq', 'ChjVzW', 'B25FzG', 'icb8xW', 'zsbdAa', 'mtmX', 'ifnnuW', 'ptaUnW', 'ywXLEG', 'cIaGia', 'y1PKvq', 'mtj8oq', 'x0jstW', 'CYb1BG', 'l3bPBG', 'EsbMBW', 'zw91Da', 'BNrPyq', 'oty0', 'oIbnzq', 'ihrVia', 'zsbPBG', 'DeHgBW', 'ExfrqG', 'qtiWlq', 'yNL0zq', 'yM9KEq', 'B3CIoG', 'y2TZlq', 'ueKSia', 'x2zVCG', 'B3nVzG', 'u0DACa', 'A2v5ia', 'DMvUDa', 'wvbIrG', 'shLnua', 'CLDvza', 'shPOta', 'CJ0LmG', 'vvv0Da', 'zxjZ', 'Dd0LmG', 'DgvTua', 'EKLJCq', 'zwqUDa', 'ANvJyG', 'AwDFzq', 'zwP1EG', 'CMvZBW', 'EgnWsG', 'Aw50pq', 'C2vJDq', 'ntu1', 'jMrPCW', 'yxiTrq', 'yxiTuW', 't1bruG', 'CdiVzW', 'rcXIBG', 'CuzMwa', 'r0fvCW', 'qu5xwG', 'zeX3wq', 'oxWXma', 'u0vjEq', 'zxrHia', 'u1nmxW', 'BgPQrW', 'mtm1', 'C2KTta', 'x2TPBG', 't25xwa', 't3rLCW', 'A3D0sW', 'DgyMza', 'zsbPDa', 'su1HDG', 'zu5wDG', 'qLrNuG', 'BgjHyW', 'ANfNyW', 'zg9qAG', 'x2LUzG', 'Dg9juW', 'rhvnEG', 'sePoEG', 'zxj2Aq', 'z05ICW', 'B3aG4OAs', 'weftrG', 'qK5SAG', 't1HzAq', 'wufmuq', 'zMPrsa', 'DwLUzG', 'odG4', 'yLnhuq', 'CMTLDa', 'uLrYza', 'lujfrW', 'wYjvuW', '4PYtienV', 'Bun4zq', 'AwvZlG', 'oIbnAq', 'kdS7kq', 'mxWWFa', 'CJ0WjG', 'tfnpwq', 'yKfZDW', 'sLHSEG', 'lMfPjq', 'A0zZDW', 'u1njtW', 'ywn0xW', 'wMjeCW', 'z25PEG', 'zxHPCW', 'C3rPBG', 'v29YAW', 'B25Lia', 'CZOVlW', 'A28TsW', 'zMjFBW', 'vMHqyG', 'Du9jvW', 'Bca3yq', 'jtjc', 'B2HRwa', 'y2j0Aq', 'AfbpBa', 'vhrtEG', 'Cwn3wG', 'B19Tyq', 'uMvNAq', 'r3ryDG', 'Bwf5Dq', 'oNbVCG', 'sunYuW', 'EMvNwa', 'v3HKtW', 'ruLvtq', 'y2fSBa', 'zwvKzq', 'sefdsa', 'ywPwBa', 'q1vcrW', 'zhniCa', 'EvHfyW', 'C3nMDq', 'zu1grW', 'lwLZCW', 'zgfICG', 'B1H5yq', 'tKjbvq', 'yxrLzW', 'yw5PCW', 'zwqGka', 'qxb0AW', 'rM91BG', 'lI4k', 'rvrqrq', 'EffrsW', 'DMuGyG', 'AxnFyG', 'rJq1', 'uhjV', 'phWGFa', 'A0XorW', 'mJq3', 'AY1Wyq', 'zgf5', 'CezjyW', 'psz3yq', 'CKLKoW', 'mtm2', 'Dhb1Da', 'DKTvEa', 'x19JyW', 'iezPCG', 'BxvNCW', 'teftsa', 'x2nSAq', 'lJaUma', 'B25LxW', 'wZiVna', 't1j6CW', 'oLTHlq', 'whnMrG', 'ucbtzq', 'uvLlvG', 'CMDLDa', 'z2jzzW', 'sMHxzG', 'BerMra', 'vM9SDq', 'icHLlG', 'D0ncsq', 'D3jPDa', 'B3jbyW', 'AhjLyq', 'BM9YBq', 'n0iY', 'As9LBa', 'jMLZzG', 'Axr5ia', 'ru1UvG', 'zxjNBW', 'q0vmta', 'y2PYsa', 'BhzL', 'quvtmG', 'Cwfkza', 'ALr2uW', 'tMLOza', 'ntK3', 'y2HPBG', 'BNn0yq', 'x0eGqG', 'DNPfqG', 'C2vZCW', 'zsaO', 'igjSBW', 'DgvKlG', 'BcXHCa', 'uMjPAW', 'ucdIHPiG', 'AxjJAG', 'zw4Ttq', 'sMvMzG', 'CMLUzW', 'Fdf8mq', 'v3H2AW', 'vcXLBG', 'v2L0Aa', 'q2XeAG', 'zwqGza', 'BwvZCW', 'CIbPBG', 'EgvK', 'EfjvsW', 'uKLAtG', 'yxiTta', 'y2vWDa', 'C1DKsW', 'B3DFDq', 'tM9qCG', 'CMvHza', 'Dff0Ba', 'BKfuDq', 'CYbSBW', 'wwD3qW', 'BNrFCG', 'vejYwa', 'sMfrDG', 'mZCUmW', 'C3vIBq', 'vMTHBq', 'BwP2rq', 'C3nFDa', 'ihrHCG', 'iYqL', 'uLzYvG', 'y29Wzq', 'zw5LCG', 'Ee13ta', 'Eer0BG', 'B25ZDa', 'y05Zsq', 'EMnysa', 'B20GCW', 'sKDTqW', 'jMXZza', 'x2rHDa', 'yxjLza', 'mtmZ', 'q3PZBa', 'wffrBG', 'vLbnwq', 'zw4Tua', 'C2f2vq', 'iNjLzW', 'vgHYzq', 'sM9ZAa', 'BxKTtq', 'ihrYEq', 'Bxn1EG', 'tcXMCG', 'zLzRza', 'zwqGCW', 'tIX6Aa', 'A2LSBa', 'AgvJAW', 'uwnryG', 'igzPBa', 'Bf9Pza', 'lxjLCq', 'BMrStG', 'wZmZBq', 'icaG', 'CZOG', 'mJeZ', 'x2zLDa', 'BMuTtG', 'Dvbgsa', 'u1zcsW', 'ENrSCG', 'v0ndzW', 'CvbIra', 'sLnSuG', 'vuvNuq', 'ifn0yq', 'ChjVyW', 'zMfSBa', 'v1HzwG', 'CMnLpq', 'r2TZqG', 'r2fYyW', 'mZv0rfndvhm', 'Bca4ia', 'mxW1Fa', 'kfjLCW', 'B290CW', 'ig9Uia', 'igDLDa', 'DhLqyG', 'icdILztILza', 'As9JAa', 'tI9b', 'DLHVDW', 'C2vY', 'AxrPBW', 'zenPqq', 'y29UCW', 'AxnFyW', 'Be1Zrq', 'DuH3ta', 'EMPHDa', 'sMPZAa', 'D2LUmW', 'zxrPBG', 'AfrvrG', 'zNPyza', 'zxjZlG', 'ywDLBG', 'tuH5AG', 'B2jItG', 'rvrbra', 'zxP5uW', 'CMvKAq', 'Ec13DW', 'wgzgDW', 'ALHvyG', 'BePnqG', 'rsXRyq', 'ndG1wa', 'igzHAq', 'DxndBW', 'BMv3xW', 'jg1Nia', 'rMfPBa', 't1f5tW', 'u01IDG', 'mJu3', 'q1bUsa', 'Dg8G', 'rvmXmG', 'sMPLuq', 'ruXHrq', 'iev4Aq', 'sIX0zW', 'jNDHDa', 'AKPcDq', 'wvfovG', 'Dw1LBG', 'mI4WlG', 'CNbwAq', 'otiXqG', 'ywjJza', 'B2jQzq', 'zxmP', 'AwvYiG', 'icaTlq', 'vNLNsa', 'q2zvqG', 'CM0TDG', 'mtuYmG', 'Ahr0Ca', 'B1TYzq', 'nJr1CG', 'r0nnxW', 'thjita', 'C3rUDa', 'pwnVza', 'wZeVna', 'u3LUyW', 'ChqTuW', 'qvjlqW', 'C2LVBG', 'yxbWxW', 'su9RDG', 'x19FFa', 'Cxf3zG', 'BxzytG', 's0nmtG', 'Dw50lG', 'zMfSCW', 'ywvS', 'qxblvq', 'y2vFBW', 'mJiW', 'ugroDa', 'q2HYBW', 'nhW1Fa', 'Efj3Da', 'shLIrW', 'Dg8Gzq', 'zsbhzq', 'uLnKuG', 'ysbgAq', 'ws0Tlq', 'vNDMwG', 'A2X6rq', 'ueXfva', 'yxGVyG', 'yxiTtW', 'BMrPBG', 'r0LwDq', 'Ahz3va', 'A2jSzq', 'CKr1Ba', 'BNq9zG', 'DKHdyq', 'DgLUzW', 'nNWZFa', 'ucbMBa', '8j+nJIbPtW', 'Cc9Zzq', 'vIXWDa', 'ugnirW', 'q0rtqq', 'sfzeta', 'icHiAq', 'oty3', 'sMXmBq', 'BgfUzW', 'yvLpta', 'A3bYEG', 'BMfIBa', 'DMvYia', 'C3yTuW', 'Chi9mq', 'yxiTra', 'z3vJAq', 'nZGYnG', 'tfvtia', 'DK11qq', 'z3jLzq', 'u00Tqq', 'yNzoua', 'y2uIoG', 'vw5vDa', 'revcvq', 'otCW', 'v25uqG', 'D0TnuW', 'x3jLzW', 'DhvYzq', 'qM1Atq', 'zgPLuG', 'mJy5', 'u3vJyW', 'C01Hza', 'u1PTDa', 'CIiSiG', 'AM9PBG', 'vg90yq', 'iefIBW', 'rhzgwq', 'zgeTra', 'DcbuCG', 'BgvUDa', 'v21Xuq', 'tfnqyW', 'AvHPwa', 'icD8jW', 'rhnQva', 'BIbVCG', 'xsbZzq', 'DMLKzq', 'tLD1CW', 'CIbqCG', 'C3vJyW', 'otK0', 'mtyYna', 'DcbUzq', 'sM9OBG', 'zYaG4OAs', 'D2L0Aa', 'x19JBW', 'Aw51zq', 'xsdIMQdVUi8G', 'CIbUzq', 'zY4GmG', 'B2DPyW', 'zMLJyq', 'pteMxW', 'zxn0', 'DwXHDa', 'uejzAG', 'CIbMDq', 'B25Lxq', 'icaGgW', 'kue9qG', 'De1ura', 'tYXWDa', 'A3bVAq', 'yMLgDW', 'CZu6lW', 'zvfSBq', 'q2H3wG', 'ys1TBW', 'zY1VCa', 'vMv0sq', 'u0TjtG', 'zxmPia', 'zw4Tva', 'lMPZBW', 'yxiTqq', 'y2ndCG', 'ANHVuG', 'seLNra', 'AwvZ', 'v0HMAG', 'x2f2yq', 'q3HSrq', 'BgXHlW', 'yt0XjG', 'zc4BwW', 'uK9xuW', 'AvDmzW', 'lJaU', 'jMzIxW', 'zgLYzq', 'C3rKAq', 'o0e9qG', 'BKTXua', 'icPCka', 'y2TVkq', 'zwn0BW', 'vMrRsa', 'qNjVDW', 'B2XMyG', 'BMTsvG', 'rs1jra', 'mZGYnJr6EKzezuy', 'mLz3qq', 'u3yX', 'zMLYCW', 'r1HjDW', 'AxjTyq', 'y3LHBG', 'BwfUEq', 'Bezhua', 'tfPsDa', 'DcbZBW', 'C2HHmG', 'rxjPyW', 'wIX1EG', 'tM8GBG', 'cIaG4Pwu', 'BguGua', 'BMCGAq', 'AwPRBa', 'zw49jG', 't1fgrq', 'wfzmDW', 'iMv2zq', 'AurdtW', 'zMLYzq', 'yw5Kzq', 'zxb0Aq', 'AhjwsG', 'DMrUra', 'mti4', 'qu1bDa', 'z21pva', 'Bs9VAq', 'A2LUzW', 'ienVBG', 'xcaVia', 't3rzAa', 'wgPwwq', 'zxiGmq', 'yLDABG', 'B3jRoG', 'wMPbsG', 'DxjLCW', 'DwfrEq', 't19uta', 'A19UDa', 'AdK5yq', 'rhzpDG', 'AgLZiG', 'zwq6ia', 'BLHPyG', 'vhDprW', 'B3j0oG', 'v3n2Aq', 'y3DKDG', 'Aw5NCW', 'C2vUza', 'BI1vuW', 'vvrArG', 'EgjgCG', 'iJOICG', 'z0LvCW', 'AxbFEa', 's0HxsW', 'ywn0Aq', 'D0TyBG', 'A0DxAW', 'tMzluW', 'B211ra', 'Dg8GCG', 'DxjLia', 'zMD1za', 'ignSzq', 'BhqTBq', 'zYbYzq', 'uhPtBW', 'BNrZxW', 'nxWXFa', 'BwjLCG', 'BMDFza', 'BhveuG', 'zxjFDa', 'zszZyW', 'twvetq', 'mc05yq', 'oKvdra', 'mIaGia', 'CM9Yqq', 'vxjP', 'zhPVwq', 'jMPHEG', 'qKLvBa', 'zwjyBq', 'Dd1Myq', 'scXLBG', 'Ag9Uzq', 'BNrYEq', 'qLjMyW', 'CgXHDa', 'rgfMqW', 's3jtBa', 'Bw9Kzq', 'wffzqW', 'DM1bzW', 'DMnjzG', 'y2vFCW', 'AgjHDq', 'uLzZDW', 'l21HyW', 'mJi5', 'Bxjuva', 'FdD8mG', 't1jwwG', 'EKzNqG', 'wL8Kxq', 'CMvNAq', 'tNbOuW', 'BNrLCG', 'DhK9jG', 'icHWDq', 'zMzPyW', 'CgXLvW', 'thyZ', 'Aw1jBG', 'CI1Zyq', 'tKDlzq', 'ihWGFa', 'zwqGCa', 'ufnqta', 'ChvUta', 'B3rWCW', 'wgL5AW', 'BwfW', 'wvLSAW', 'lM5LEa', 'D0v4BG', 'wxjyAq', 'z3D0BG', 'AwXLlW', 'vg5NCG', 'AfPkvW', '8j+mKcbbDq', 'BciSiG', 'B2DSzq', '8j+tSsbtyq', 'Dw5Uzq', 'zuzPBa', 'DKXwuW', 'suTryq', 'tfjjuW', 'sMfZBW', 'B2zPBa', 'sMfTzq', 'FcaNia', 'q2rHvG', 'yvDJsW', 'y2vFBG', 'B1TSyq', 'vYXHCG', 'Bgv2zq', 'if8Gia', 'CKPIwq', 'tM9Ulq', 'DMvYCW', 'D3rKta', 'rgf2Aq', 'zunYrq', 'CMvZCa', 'nNWXFa', 'BgLLBG', 'CI4Grq', 'v1bVrq', 'mJu4', 'Cg9OEq', 'vNjNuW', 'whr2rG', 'DMT3DG', 'CMvVCW', 'C1jfBW', 'wfzjAG', 'jMLZxW', 'y2XHAq', 'lcjLEa', 'tsX0AW', 'D2vkra', 're9cia', 'A0a0', 'EhL0tW', 'l3bYBW', 'uIXHCG', 'BIbpva', 'DxjPBG', 'z2v0', 'jNbPyW', 'ru9YqG', 'zxiGmW', 'zxrJAa', 'ywrKta', 'C3rLCG', 'oIbLBq', 'B25Jzq', 'ks4Grq', 'CxfYDW', 'Ev09', 'EMPSBW', 'u0eTqq', 'otCX', 'rY1vsq', 'zhnurW', 'AgTTDa', 'CgHVBG', 's1z5za', 'nJaYlG', 'zwHdAG', 'v2rwCq', 'yMPLyW', 'jM9WDa', 'BuLkzW', 'wKHqzG', 'zgLOCa', 'DgHFyW', 'i0zgnG', 'jM50yq', 'CMvXDq', 'Df9Yzq', 'r3nHza', 'AxbtEq', 'wvHyAG', 'mJi2', 'zf9HyW', 'BNnLoG', 'A1jJEq', 'uuHAqG', 'AMrNwa', 'wMfnsq', 'ksdIHPiG', 'vwzWuq', 'ienVDq', 'C2v0va', 'ruPQvG', 'CM93CW', 'rKXuuq', 'Dw1Izq', 'pszPzW', 'D2HPBa', 'mJy1', 'DK1suG', 'ifnPBa', 'tIa9pq', 'AguTsq', 'vhbWuW', 'Dhj1zq', 'zxHPDa', 'zv9VzG', 'rNv6BW', 'svvkDW', 'BcbLCG', 'C3rHBa', 'i0zdqq', 'BIbtAq', 'As9SBW', 'yxn0ia', 'Bf9JBa', 'rgDbwG', 'oNSIzq', 'ugL4zq', 'B2nNqG', 'q2HYAq', 'CMvKia', 'zhbVAq', 'r0fIza', 'zxnZ', 'B3iOiG', 'Dc1HDG', 's256ra', 'ruLYrG', 'Axq9Da', 'DtTXpq', 'C3vgAG', 'icaGFa', 'wZm2Bq', 'BNrPzG', 'Bs9HAG', 'tJbzBq', 'CLLtta', 't0WGia', 'rcbHCW', 'oI8V', 'icdILzRILza', 'pxCMxW', 'zwfY', 'qNDoDa', 'C3n3BW', 'pszMAq', 'wePZyW', 'DvLnva', 'luHbuG', 'vfHnBW', 'qLzlyq', 'Dgf5zq', 'icGVzW', 'C2fTzq', 'A2zPrW', 'y3rLza', 'rxbwzG', 'EK9nra', 'ufPotW', 'BYbPBG', 'ueHptG', 'BKnJAq', 'xYbCia', 'sLnptG', 'C1H6uW', 'CvrvrG', 'De5OtW', 'luffuW', 'xYbFxW', 'jgnWDq', 'zLK9cG', 'zgvSyq', 'txrWvG', 'C2LrEG', 'tKCT', 'q1D5uW', 'z05mzW', 'CIaOCa', 'Ew9yua', 'g1Ti', 'x18GxW', 'ufjIAG', 'twjWyG', 'zgrqCW', 'qvn2DW', 'oNbHCW', 'C29SDq', 'C19WAa', 'zsi6iG', 'BNrPBG', 'vhjPzW', 'qxmZBW', 'lsb1CW', 'Bwzhzq', 'nhWWFa', 'ANP1tW', 'D0DbCG', 'ug9KsW', 'C2uMyW', 'tfvvDG', 'DhntEq', 'DhjPBq', 'lJeUlG', 'zwDPCW', 'wKv3sq', 'Aw9UlW', 'ntK1', 'mtGWoq', 'q29UzG', 'BMvS', 'D0nxra', 'CMvNsq', 'BMTtEq', 'rgvMyq', 'jMnZAq', 'CMrFCW', 'Ev9Jnq', 'swnezW', 'Dcb0BW', 'BMvhDq', 'zxmTqW', 'v1rjCW', 'wvnABq', 'u19dsa', 'CMvK', 'icbqBa', 'rgrdyq', 'q3HrvG', 'igzYBW', 'l2H0Bq', 's0TPAq', 'whLKwq', 'BIbWAq', 'BI1kuW', 'uKrxqq', 'jNn0yq', 'AeHvsW', 'uhjABG', 'rNfmCa', 'BL9VDa', 'zgf0yq', 'AeLwuG', 'vMPLzW', 'rJG4', 'q1DJrW', 'B3j0xW', 'BMv4yq', '4Psa4Psa4Psa4Psq', 'ywnO', 'twf0Da', 'zgrPyG', 'Dg9Y', 'ifvWza', 'lJKSzq', 'u21PDa', 'A2v5CW', 'AhKNia', 'iJOXnq', 'rcbPBG', 'mI1WCa', 'Aw5JBa', 'rxncsG', 'ic5FxW', 'yxjLia', 'DKDWzq', 'tKTwDG', 'u3fgDG', 'qLPrrq', 'pszJBW', 't3j3CG', 'oJa6', 'Dureza', 'sMXlEG', 'mJq5', 'ihjLCW', 'tIXOAq', 'iN19', 'r2fYEq', 'oty2', 'v1rVsq', 'rxjYoG', 'ChqTtq', 'v3rRqG', 'CNjuAW', 'sg1pEG', 'vvritW', 'x3XFFa', 'zxjMyq', 'iIWICW', 'r1r5zG', 'zgmVpW', 'jM5HBq', 'ucXUzq', 'C2z1Ba', 'zfzMuW', 'CKrIAa', 'DxjYzq', 'mJy0', 'Ee5dtq', 'rgv2Aq', 'Dw9xva', 'yLfyAq', 'DgvKkq', 'BMqGiG', 'DhvZia', 'zMXVDW', 'sM5OyG', 'DgnOAq', 'thD1tW', 'icHlsa', 'Bca4', 'x29MxW', 'iK5VDa', 'Aw1HzW', 'ucbJBW', 'ysaGia', 'iM50zG', 'Ehq/', 'Fdv8na', 'CNvJDa', 'BxfPBq', 'C1rSzG', 'C2fTCW', 'A015Ca', 'qLbgsa', 'igfYzW', 'Aw5LEG', 'ssblzq', 'C2v0uG', 'ihzLCG', 'DxDOtG', 'uMvZzq', 'B3vdsG', 'yxrLia', 'zNiTva', 'teLdia', 'kgv4Aq', 'C3rHDa', 'u0zxsa', 't19tuW', 'EK9LDa', 'Bu1Rtq', 'B21LDa', 'x3jLCq', 'sMvQBq', 'vvrRCW', 'B3DUqW', 'ihn1CG', 'Aw5ZDa', 'zs9HCa', 'DgH5', 'y2uUyW', 'C2rPyW', 'yKPdCW', 'AKzjCa', 'CIbozq', 'CMv5', 'lM1LDa', 'uM5YDa', 'zKD5za', 'uLbxCa', 'yujszG', 'otK1', 'z3LwDq', 'B21L', 'wuLVqG', 'Eu1Z', 'yw9TqW', 'A2fKyq', 'CfH0Aa', 'rMf0yq', 'sxPRvq', 'zxjZrG', 'BNrSEq', 'BMCGDa', 'uvLVzq', 'B24G', 'jgrPCW', 'yu1jrW', 'EwzeCW', 'jNbHCW', 'uvHdsa', 'BwCTtq', 'zM9YBq', 'y29UBG', 'qNzq', 'rM1JEq', 'Aw5FAa', 'BMfSia', 'ueDUCG', 'mxDnuG', 'C2v0uW', 'qMPovG', 'BMCGqW', 'whPqyG', 'B2zgBa', 'BuzJAq', 'ysdILiiG', 'ugHVBG', 'mZa1xW', 'zxnZAq', 'BM93', 'v3Pqzq', '4PscifVIGki', 'sLf5uG', 'tez1ra', 'Bw9UDa', 'zsboBW', 'rgG3sG', 'sKXjBa', 'zv9HCa', 'rsXZDW', 'BMf2Aq', 'iJK5iG', 'ndPuta', 'DgG9', 'vgTrtq', 'ig9Mia', 'qwn0rW', 'AuDMsG', 'ihXFkq', 'DLzhBa', 'sw52yq', 'icaG4PYx', 'CwnIEq', 'C2Dlta', 'zw50CG', 'EgDxqW', 'iefJyW', 'uwHUwG', 'zM94', 'AM9XCa', 'qMXPBG', 'zMLSzq', 'AvPLDq', 'ywXSia', 'Bg9JAW', 'icaVia', 'otyY', 'v1DAwq', 'svbIsW', 'mtK6ua', 'u2P5yq', 'Ew5J', 'vMHlsW', 'CKLyCW', 'mZeYjG', 'uIXUBa', 'otu3nW', 'nZKP', 'BL9Yzq', 'EMXPyG', 'qNv4za', 'tI9bia', 'yxiTtq', 'mJeY', 'tKTxua', 'Bsi7DG', 'u1rvvG', 'ywnJzq', 'ptaUoa', 'uKvhsq', 'BhPItG', 'zwrYzW', 'weDdnW', 'y3b1CW', 'rfbRrW', 'tezxsa', 'Dw4GBW', 'sgvYBG', 'uLPxEq', 'CNbUra', 'zhPdAa', 'Bwv0Aa', 'DMKTvG', 'zxnZpW', 'iMv4yW', 'nty6va', 'CM4GDa', 'wgvKqW', 'nta0mW', 'AgfXBW', 'C3vWCa', 'BgXPBG', 'CuLcsG', 'AeHtrq', 'rgvSzq', 'yu9gwq', 'C195BW', 'zxmTqq', 'lcaIrW', 'qsbutW', 'yw1PBa', 'mJi1', 'ierPCW', 'C3rKBW', 'qvnQCq', 'sfbxtq', 'uuTAuW', 's1DOBW', 'ue9tva', 'zeLKzq', 'DcaTrG', 'CwXrtq', 'rMfZDa', 'BMvK', 'icbqCG', 'qKXHyq', 'yxnLza', 'y25wra', 'zw4Uia', 'u3vrsq', 'zvj1zW', 'C3rYAq', 'yuzowa', 'ndu2nW', 'zNiTsW', 'zeDRuG', 'vcXKzq', 'BMzVwW', 'Cg5ZBq', 'y1bMrG', 'DgvFCG', 'DgLVBG', 'qvDUsa', 'qsXSBW', 'Dc1Yzq', 'AwjQvW', 'mtG3nG', 'BwuVCW', 'twHtEG', 'rNrstW', 'zwrQBa', 'tMv4yq', 'zwDFAq', 'tg9NAq', 'CgfNzq', 'tg9xza', 'zgvZDa', 'Bg93lG', 'seLPCa', 'AwXL', 'B3j0', 'y3rFCa', 'DcaO', 'zMfYAq', 'AK54uW', 'y09wEa', 'y2XPzq', 'x2PVAq', 'zsbUDq', 'B21Tyq', 'Ehbtsq', 'Afb5tW', 'ig5Via', 'zujVyq', 'Fg1LDa', 'C3nHzW', 'wNzNEa', 'mxWZFa', 'zxjSEq', 'D3D3lG', 'BgXFAq', 'yxjK', 'wMzmDq', 'zY4k', 'zM9Yia', 'q2rtBW', 'FcaUia', 'tKDrwq', 'zwWTrW', 'wIXHEG', 'vM9PqG', 'y1bTzq', 'idePlG', 'xYrDwW', 'EsbZyq', 'qxLnvG', 'Bg9N', 'ihWGsa', 'vLDsuW', 'B3H5lq', 'y2HLyW', 'twTfta', 'yxj0Eq', 'zMPyBW', 'zhOTqG', 'ruzcrG', 't1jDia', 'DxvArW', 'thforG', 'BuvbCa', 'AwnLxW', 'wtLnuG', 'DwnJzq', 'Bs9HCa', 'jNnVDq', 'Bwvtzq', 'C2XPyW', 'ieLUDG', 'r1LOyq', 'C3bPBG', 'wejlsW', 'vLHZtW', 'iKfUza', 'zLHxqG', 'ucb0BW', 've1mla', 'BgWGFa', 'C3qGCa', 'B3bLBG', 'AwqGmG', 'rhLyuG', 'tNjpAa', 'icDFia', 'wfzOEa', 'zxnZBW', 'Dg8GzG', 'Aw4GBa', 'DhzMvW', 'AuLHvW', 'rYbtrq', 'z2LU', 'u2H4vW', 'sfjLvq', 'zhHpDq', 'uIXLBG', 'FdH8mG', 's0XntG', 'ywPetG', 'y2vZCW', 'q1qGqG', 'v1vbBW', 'Exb0zq', 'B3iTza', 'i1bxra', 'Bcbtzq', 'DLPYuG', 'ww1Mvq', 'BKryEG', 'icaGia', 'Evf2Bq', 'BgWSiG', 'zxzLBG', 'u3rLDG', 'pszYzq', 'A1PpqW', 'zxHWAq', 'u0eTqW', 'ifTKzq', 'CgrzCW', 'zgvMyq', 'tLDusG', 'A2fZzG', 'u2P4za', 'mM0G', 'rMziwG', 'jL9FCG', 'CxvLDq', 'CMvZ', 'BNqGCW', 'rfjyEq', 'CgvUza', 'BvLMCW', 'u3DmsG', 'BNbTia', 'CxvPCG', 'vvDRDG', 'zw4GBa', 'mtG2oa', 'odKHqa', 'tvbrrW', 'B2LKyW', 'sNHxrq', 'ihnLBG', 'sgjura', 'vujmsq', 'DgndsG', 'l2nHBa', 'BMWTtG', 'wM9wva', 'z0n4vG', 'zeXsDq', 'nJC5', 'oc1tsa', 'FcaOxW', 'ntqZjG', 'BgqGBG', 'BgvKoG', 'lcjYzq', 'Dg9yqG', 'u0SG4Ocu', 'D0TnrW', 'uNnnAW', 'DMLJzq', 'xYXFFa', 'Aw1LCW', 'Ff98xa', 'pwzHBa', 'BML0Aq', 'tNzeEa', 'DgXNsG', 'zwDFBG', 'txzZyq', 'CgXHEq', 'z2H0', 'AMeTsG', 'ChjVCa', 'CKrLCW', 'ls0k', 'Af9Ozq', 'q0rfrG', 'ELDUwa', 'lJm3oq', 'y2XNBW', 'iN0SiG', 'jL9FyW', 'DgLTzq', 's3zPra', 'EgD2CG', 'rYXREq', 'BfHqva', 'qLjIwq', 'AK9gzq', 'u1fQuq', 'zMrtDa', 'vu1crq', 'veT2vW', 'ienOCG', 'wfr4Bq', 'ugzlBW', 'Bg1LBq', 'wM1ZDW', 'mJe2', 'qwrKia', 'BMfTzq', 'BIbxAq', 'sMjfyG', 'qxzdsq', 'BKTssa', 'q29VAW', 'y1zZDW', 'BKjYAq', 'jNe9', 'Cgf0Aa', 'BNrFDa', 'BMvKia', 'u1b2Eq', 'vw1zBa', 's0jpta', 'B1HHvG', 'ys9JAa', 'mc4YFa', 'sLfQta', 'Be51Bq', 'zwX5ia', 'iJi0iG', 'AwqGCa', 'x2jPCG', 'ChnNua', 'tgHUvq', 's2HOBa', 'x2nTCW', 'EwvZ', 'Bwf4', 'yxr1CW', 's05HsG', 'CuvzAW', 'rKHrvW', 'u2zQyW', 'mdeYmW', 'DI9UDq', 'CM9Pza', 'uePKBG', 'yxOTqq', 'zxvsCW', 'BhnK', 'tvHdEa', 'x3zLCG', 'Evb1vq', 'swrvtG', 'AfDqBG', 'sNbrqW', 'EgLZDa', 'icdILAdILza', 'zgLUzW', 'otKY', 'qvbjia', 'x2zSBW', 'w2jPCG', 'vhP1sa', 'BMrgAq', 'BenfDW', 'z3zfDG', 'Dw5SAq', 'zxjPwq', 'oti4qG', 'AwqTsq', 'lunPBq', 'yxrHxq', 'vMDTAG', 'zwqGAW', 'zw47Cq', 'CgfZCW', 'zKrXsG', 'vwP3zG', 'BenVDq', 'nJC3', 'xhWGFa', 'rgrNEG', 'CgLUxW', 'yxjOqq', 'u0vZsa', 'BKjXuG', 'iZe4nW', 'BMDLpq', 'DxOTvq', 'lti1nG', 'B2LUDa', 'A2vUCW', 'AKDnBG', '4PYtifrO', 'EwvHCG', 'BMrrsG', 'u1Lnyq', 'AKnVyG', 'mJi3', 'Bevwqq', 'zcbpva', 'CMvZzq', 'BNnLia', 'ie5LDa', 'rNjXyW', 'vLn1tW', 'CvjYDa', 'ufrkuG', 'BM8GCa', 'sMLyzW', 'z2uVDW', 'rNbRwa', 'jL9FCW', 'ENvstq', 'B2zItW', 'xcjDiG', 'CgvMqq', 'EsbeCG', 'tcXLCW', 'CLbHCq', 'BMDLxW', 'sevOvG', 'v1DrAW', 'r016Da', 'AgvYia', 'DcbZzq', 'C2LN', 'zxmTra', 'DgHFCa', 'ywnJBW', 'zxjZAq', 'ELDAEq', 'mI9Nzq', 'vM1jDG', 'EMGTqW', 'CeDssG', 'thDYBq', 'BwvKia', 'yxrLCG', 'm3WYFa', 'quvlyq', 'xsbB', 'wsXHCG', 'AMPOCq', 'CKnwtW', 'EhPmBa', 'qsXHCG', 'wNHkAG', 'sIXMCG', 'BNm9Da', 'DxnLCG', 'BMnVBG', 'r2nwyW', 'wsXTCW', 'lsbOBW', 'vgf5Ba', 'CY1WCG', 'CMvNxW', 'DMuTyW', 'CgfYCW', 'y2GTDq', 'B2PpCq', 'zw4Tqq', 'Dw5KoG', 'sLv5Aq', 'veeGqq', 'zw4TtG', 'yxiTva', 'jMnHyq', 'Aw5Npq', 'Cgz1Da', 'DxvcEa', 'BL9OBW', 'l2fWAq', 'BNrLzW', 'yxrLxW', 'yxjKDW', 'jNfWBa', 'zhbYpq', 'r290ia', 'Bu14BW', 'zMvPCq', 'x18Pia', 'uLz3Ea', 'vYXWDa', 'wuzXsW', 'C29U', 'B2nLCW', 'mJy4', 'q2LTsq', 'A3nNqq', '4Psu4Psa4Psa4Psa', 'CMv2', 'r28Gsa', 'z2XLBa', 'qu5lsq', 'zwqGBW', 'D3LLvW', 'B3bLpq', 'tNrdEq', 'y29Kzq', 'v1PUBW', 'EfrpDW', 'rKD5qG', 'DgCTva', 't1P0CW', 'ntK2', 'vvbJsW', 'B25Uzq', 'mJbFua', 'z2XPCW', 'Bhfhzq', 'CfzYqW', 'kYKRja', 'CM92Aq', 'usXHCG', 'rYXTzW', 'wuXIuW', 't1ryvW', 'qMLZBW', 'vfbZEq', 'ntK4', 'veXtxW', 'jMv2zq', 'zw4Tsq', 'CxvWua', 'EwjUrG', 'wffTDa', 'pt09ia', 'wvDTAq', 'A05MAa', 'A3vRyq', 'mtmWnq', 'rsaGia', 'zZ1fwa', 'B3j5iG', 'rKzrrG', 'xsbzBW', 'ueXZCG', 'zNnisW', 'AhDPza', 'u00TuW', 'rYXMCG', 'BxPeDa', 'zw5Klq', 'lYO7Cq', 'zxH0CG', 'CMnLxW', 'u01qAa', 'rhbMDa', '4PYtiefq', 'tw9VCG', 'sw9IvW', 'reH6DG', 'y2HHAq', 'zxjfBG', 'yxr2AW', 'tNvTyG', 'yxiTwq', 't290tG', 'nde0mtbPuKvkBM4', 'y291BG', 'uKnAvq', 'o0ePqG', 'iJP7iG', 'CKDxwG', 'swX2vW', 'mJqW', 'vMLfCW', 'C2HPzG', 'y2HHBa', 'sNvmAa', 'xsbgAq', 'y0j4uG', 'Fcb8lW', 'mtG0oq', 'CffwDa', 'AxrPBG', 'ievYCG', 'txmToa', 'x3bVAq', 'swPHwq', 'BxrZzq', 'tLvlra', 'DuHkCG', 'tKrerG', 'BMWTqG', 'pue/qG', 'xsbuBW', 'rhjNCG', 'AwfTCW', 'CKnizG', 'uuT3sW', 'jg1Iia', 'rfDbuG', 'EMrWta', 'mJuW', 'ChqTqW', 'Bgf0Aq', 'vKHTwa', 'igfNyq', 's2v2Aq', 'iJOI', '4Psm4Psa4Psa4Psa', 'sM9Uzq', 'BMzPCG', 'y3rPBW', 'yxrVCG', 'rvnFmG', 'tMHzqG', 'CNuTuG', 'y2uTyG', 'DMvYAq', 'uvnNvW', 'B1nIyq', 'wgfdsG', 'qvvdAa', 'ueXQEG', 'svHlrG', 'zxnZzq', 'DvLgzq', 'r0fIBq', 't2zusa', 'Awq9', 'r0nnlq', 'DKXytq', 'igv4Aq', 'v2LUmW', 'jMnVBG', 'vfzrta', 'AgKTsq', 'surosW', 'BxbLCG', 'y2fHxW', 'yIKGlq', 'CNvLjG', 's3jQtW', 'u0HbmG', 'Df9HDq', 'lI4U', 'quniqq', 'ufnptG', 'wIXWDa', 'Bg9NAq', 'BuDZwa', 'zxmTvq', 'x18Via', 'g1SYsG', 'zMeTsq', 'zf9WCG', 'tIXTCW', 'p0fFqG', 'rgvWzq', 'tYXLCW', 'B2jeCq', 'tsXMCG', 'wMfoEa', 'BwCSja', 'rwrNzq', 'mKXNBq', 'te1XCW', 'igjHBa', 'rIXMCG', 'y2v6Bq', 'yxWYlG', 'mZG1nq', 'zwnRlq', 'zxmTvG', 'BxjpzG', 'uhjLBq', 'zcboua', 'qvjfxa', '4Pwq4Pwq4Pwq4PwJ', 'DNDgyW', 'icdILzeG', 'AwT1qq', 'B1DpBa', 'mhWYFa', 'ks4UlG', 'igrVDW', 'zw4TqG', 'y2f0yW', 'q09XrG', 'qMvgAW', 'y29UzG', 'EgL6zG', 'tNnwvG', 'icPCkq', 'oty1', 'zuzUsW', 'zcaOBG', 'mc44', 'Aw5MBa', 'C3rHCG', 'ysi6EW', 'CM8TuG', 'qwjVCG', 'C2PfuW', 'u2TlDq', 'y19HyW', 'AgjrEq', 'osXPBq', 'tvPjtq', 'mtyZ', 'ChvmDG', 'yw0Trq', 'vsXODq', 'pvWNqW', 'AwfSCW', 'BNzHBa', 'B1TOyq', 'EunVBG', 'ywnL', 'qYblrq', 't0PmrG', 'z1DWAq', 'ChvZAa', 'zNiTqG', 'DufRwa', 'ANnVBG', 'rvHbia', 'CYaOCa', 'sYXZAq', 'BNjota', 'su5dCq', 'rsXHCG', 'EMPOzq', 'te1nsW', 'ig51Bq', 'otyX', 'svrqBW', 'EgXXza', 'yLboua', 'zxfkCq', 'iIWG', 'CMqTCG', 'zfLZBG', 'mhW0Fa', 'q0jvEq', 'zejSzq', 'D09SDG', 'rgvOCW', 'AvvRsG', 'uvLesW', 'yKnADW', 'pwH0Da', 'B0ztDG', 'Axj0Aa', 'qwr2yG', 'AwPzvW', 'zwn0kq', 'r0nnyG', 'z1bTvW', 'ifnLCW', 'Ag9Tzq', 'mJiXode2EuPzyuHu', 'mtq0', 'zxmTqG', 'z0jOAG', 'ywWGCW', 'ucbqyq', 'q0rirq', 'nJCW', 'BuHSzG', 'sgjOAq', 'rMXTwa', 'r29UEG', 'BMj6Bq', 'r1r0rW', 'BYbLEa', 'rgf3wG', 'CvL2Cq', 'lw5VBG', 'q3r3tW', 'y3HevW', 'ANvYAq', 'u0STvG', 'z3jHEq', 'zwjiEa', 'yxiTua', 'nda5mZjwtvnAEu0', 'rcXPza', 's3vUwa', 'Bu9Wtq', 'zMfPBa', 'yw0Gia', 'sLv4va', 't0Doua', 'q0jpAq', 'DwuP', 'uK1RzW', 'AKvhqW', 'v1nQAW', 'wMHLtq', 'BNnLxW', 'C3jmDW', 'CM95', 'Aw4ZmG', 'nZyZoa', 'tYXZBW', 'uKfqrq', 'ihvZzq', 'BMqTBG', 'x2nYzq', 'x2LUDa', 'DMvKlG', 'DMD1AW', 'oIjBxa', 'AgnHCq', 'A0zhzq', 'uMv1CW', 'zMf1Ba', 'CLn1Bq', 'D21SsW', 'u0rjuq', 'x19Fia', 'DKfwrW', 'zgLNzq', 'zw5XDq', 'q3Hmva', 'tvLstW', 'ANHjDW', 'Cu1Uva', 'yw1Lxq', 'yKTnuq', 'B3vUDa', 'ucaO', 'ieLUDa', 'n2u2oa', 'BwfYAW', 'zxbLBG', 'DgGTva', 'sKHRrG', 'CNblDW', 'DwP2va', 'CvzlBG', 'BMrZ', 'tcXWBa', 'BMCUlG', 'wwvKrG', 'DhnxAq', 'z1vtsW', 'zNvSBa', 'tIX2Aq', 'CMvSzq', 'AhuTsa', 'mdaWma', 'sMzZDq', 'BNrFyW', 'usXLCW', 'n0zHwePzuW', 'AwDPyG', 'zwDYAq', 'B3qGzW', 'lJKSyq', 'mJq4', 'zgv2Aq', 'zM9BzG', 'yv9UDa', 'BK9wuW', 'qLHRAG', 'CM9Wzq', 'B3j0Aq', 'luvora', 'EeLwvW', 'mZmZmdK2D1jqBMro', 'Ag9ryq', 'igTLEq', 't1HoCq', 'Bs9SBW', 'EvH0BG', 'mtm3lG', 'vw5RBG', 'CMKVnq'];
  fn1 = function () {
    return v53;
  };
  return fn1();
}
function generateRandomName() {
  const v54 = ["John", "David", "Michael", "Chris", "James", "Daniel", "Matthew", "Andrew", "Joshua", "Kevin", "Brian", "Jason", "Eric", "Steven", "Thomas", "Timothy", "Richard", "Ryan", "Jeffrey", "Gary"],
    v55 = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin"],
    v56 = v54[Math.floor(Math.random() * v54.length)],
    v57 = v55[Math.floor(Math.random() * v55.length)],
    v58 = {};
  v58.first = v56, v58.last = v57, v58.full = v56 + '\x20' + v57;
  return v58;
}
function getRandomClient(v59 = "random") {
  const v60 = Math.floor(Math.random() * 11) + 126,
    v61 = Math.floor(Math.random() * 200) + 6400,
    v62 = Math.floor(Math.random() * 150) + 50,
    v63 = ["Pixel 8 Pro", "Pixel 8", "Pixel 7a", "ONEPLUS A6013", "SM-S928B", "SM-S921B", "SM-A556B"],
    v64 = ['11', '12', '13', '14', '15'],
    v65 = v64[Math.floor(Math.random() * v64.length)],
    v66 = v63[Math.floor(Math.random() * v63.length)],
    v67 = {};
  v67["126"] = "\"Not/A)Brand\";v=\"8\"", v67["127"] = "\"Not)A;Brand\";v=\"99\"", v67["128"] = "\"Not;A=Brand\";v=\"8\"", v67["129"] = "\"Not=A?Brand\";v=\"8\"", v67["130"] = "\"Not?A_Brand\";v=\"99\"", v67["131"] = "\"Not_A Brand\";v=\"24\"", v67["132"] = "\"Not A(Brand\";v=\"8\"", v67["133"] = "\"Not(A;Brand\";v=\"99\"", v67["134"] = "\"Not;A)Brand\";v=\"24\"", v67["135"] = "\"Not)A=Brand\";v=\"8\"", v67["136"] = "\"Not=A_Brand\";v=\"99\"";
  const v68 = v67,
    v69 = v68[v60] || "\"Not A(Brand\";v=\"24\"",
    v70 = {};
  v70.name = "Android Chrome", v70.userAgent = "Mozilla/5.0 (Linux; Android " + v65 + ';\x20' + v66 + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v60 + ".0." + v61 + '.' + v62 + " Mobile Safari/537.36", v70.clientHints = {}, v70.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v60 + "\", " + v69 + ", \"Google Chrome\";v=\"" + v60 + '\x22', v70.clientHints["sec-ch-ua-mobile"] = '?1';
  v70.clientHints["sec-ch-ua-platform"] = "\"Android\"";
  return v70.clientHints["sec-ch-ua-platform-version"] = '\x22' + v65 + ".0.0\"", v70;
}
function rotateSessionId(v71) {
  if (!v71 || !v71.user) return v71;
  const v72 = {
      ...v71
    },
    v73 = v72,
    v74 = [/-ssid-[A-Za-z0-9_]+/, /-session-[A-Za-z0-9_]+/, /_session_[A-Za-z0-9_]+/, /-sess-[A-Za-z0-9_]+/];
  for (const v75 of v74) {
    {
      if (v73.user && v75.test(v73.user)) {
        const v76 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v73.user = v73.user.replace(v75, '' + v75.source.split('[')[0].replace(/\\/g, '') + v76);
        break;
      }
      if (v73.pass && v75.test(v73.pass)) {
        {
          const v77 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
          v73.pass = v73.pass.replace(v75, '' + v75.source.split('[')[0].replace(/\\/g, '') + v77);
          break;
        }
      }
    }
  }
  return v73;
}
function parseProxy(v78) {
  if (!v78) return null;
  if (typeof v78 === "object") return v78;
  v78 = v78.trim();
  if (!v78) return null;
  let v79, v80, v81, v82;
  if (v78.includes("://")) v78 = v78.split("://")[1];
  if (v78.includes('@')) {
    const v84 = v78.split('@'),
      v85 = v84[0].split(':'),
      v86 = v84[1].split(':');
    v81 = v85[0], v82 = v85[1], v79 = v86[0], v80 = parseInt(v86[1]);
  } else {
    const v87 = v78.split(':');
    if (v87.length === 2) v79 = v87[0], v80 = parseInt(v87[1]);else {
      if (v87.length === 4) {
        {
          if (!isNaN(parseInt(v87[3])) && isNaN(parseInt(v87[1]))) {
            v81 = v87[0], v82 = v87[1], v79 = v87[2], v80 = parseInt(v87[3]);
          } else v79 = v87[0], v80 = parseInt(v87[1]), v81 = v87[2], v82 = v87[3];
        }
      } else v87.length === 3 && (v79 = v87[0], v80 = parseInt(v87[1]), v81 = v87[2]);
    }
  }
  if (!v79 || !v80) return null;
  const v83 = {};
  v83.type = "http", v83.host = v79, v83.port = v80, v83.user = v81, v83.pass = v82;
  return v83.original = v78, v83;
}
function createProxyAgent(v88) {
  if (!v88) return null;
  let v89 = '';
  if (v88.type === "socks5" || v88.type === "socks4") {
    return v89 = "socks5://" + (v88.user ? v88.user + ':' + v88.pass + '@' : '') + v88.host + ':' + v88.port, new SocksProxyAgent(v89);
  } else {
    return v89 = "http://" + (v88.user ? v88.user + ':' + v88.pass + '@' : '') + v88.host + ':' + v88.port, new HttpsProxyAgent(v89);
  }
}
function sendRequest(v90, v91, v92, v93, v94 = null, v95 = 15000, v96 = 0) {
  return new Promise((v97, v98) => {
    {
      if (v96 > 5) return v98(new Error("Too many redirects"));
      const v99 = new URL(v90),
        v100 = {
          ...v92
        };
      let v101 = v100;
      if (v93) {
        v101["Content-Length"] = Buffer.byteLength(v93);
      }
      const v102 = {
        'hostname': v99.hostname,
        'path': v99.pathname + v99.search,
        'method': v91,
        'headers': v101,
        'timeout': v95,
        'ciphers': "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-RSA-AES128-SHA:ECDHE-RSA-AES256-SHA",
        'ecdhCurve': "X25519:P-256:P-384",
        'honorCipherOrder': false,
        'secureOptions': require("crypto").constants.SSL_OP_NO_SSLv3 | require("crypto").constants.SSL_OP_NO_TLSv1 | require("crypto").constants.SSL_OP_NO_TLSv1_1
      };
      let v103 = v94 ? parseProxy(v94) : null;
      if (v94) {
        if (!v103 || isNaN(v103.port) || v103.port <= 0) return v98(new Error("FATAL: Invalid proxy. Aborting to prevent IP leak."));
        v102.agent = createProxyAgent(v103);
      }
      const v104 = https.request(v102, v105 => {
        const v106 = [];
        v105.on("data", v107 => v106.push(v107));
        v105.on("error", v98), v105.on("end", () => {
          let v108 = Buffer.concat(v106);
          const v109 = v105.headers["content-encoding"];
          if (v109 === "gzip") try {
            v108 = zlib.gunzipSync(v108);
          } catch (v111) {} else {
            if (v109 === "deflate") try {
              v108 = zlib.inflateSync(v108);
            } catch (v112) {}
          }
          const v110 = v105.headers["set-cookie"] || [];
          if (v105.statusCode >= 300 && v105.statusCode < 400 && v105.headers.location) {
            {
              let v113 = v105.headers.location;
              if (!v113.startsWith("http")) v113 = v99.origin + v113;
              const v114 = {
                ...v92
              };
              let v115 = v114,
                v116 = v115.Cookie || '',
                v117 = v110.map(v119 => v119.split(';')[0]).join(';\x20');
              if (v117) v115.Cookie = v116 ? v116 + ';\x20' + v117 : v117;
              const v118 = v91 === "POST" && v105.statusCode === 303 ? "GET" : v91;
              v97(sendRequest(v113, v118, v115, v118 === "GET" ? null : v93, v94, v95, v96 + 1).then(v120 => {
                const v121 = {
                  ...v120
                };
                return v121.cookies = [...v110, ...v120.cookies], v121;
              }));
              return;
            }
          }
          v97({
            'status': v105.statusCode,
            'data': v108.toString("utf8"),
            'headers': v105.headers,
            'cookies': v110
          });
        });
      });
      v104.on("error", v98), v104.on("timeout", () => {
        v104.destroy(), v98(new Error("timeout"));
      });
      if (v93) v104.write(v93);
      v104.end();
    }
  });
}
function parseTokensFromHtml(v122) {
  const v123 = {},
    fn3 = v125 => {
      const v126 = v122.match(v125);
      return v126 ? v126[1] : null;
    };
  v123.lsd = fn3(/name="lsd" value="([^"]+)"/) || fn3(/"token":"([^"]+)"/), v123.jazoest = fn3(/name="jazoest" value="([^"]+)"/) || fn3(/"jazoest":"([^"]+)"/) || fn3(/jazoest=(\d+)/), v123.hsi = fn3(/"hsi":"([^"]+)"/), v123.spin_r = fn3(/"__spin_r":(\d+)/);
  v123.spin_b = fn3(/"__spin_b":"([^"]+)"/), v123.spin_t = fn3(/"__spin_t":(\d+)/), v123.rev = fn3(/"server_revision":(\d+)/) || fn3(/server_revision":(\d+)/);
  const v124 = v122.match(/"regulation_jurisdiction":\s*(\[[^\]]+\])/);
  v123.regulation_jurisdiction = v124 ? v124[1] : "[\"US\"]";
  if (!v123.jazoest && v123.lsd) {
    {
      let v127 = 0;
      for (let v128 = 0; v128 < v123.lsd.length; v128++) v127 += v123.lsd.charCodeAt(v128);
      v123.jazoest = '2' + v127;
    }
  }
  return v123;
}
async function createAccount(v129, v130 = {}) {
  const {
      onStatus = () => {},
      proxy = null,
      timeout = 15000,
      workerId = 0,
      browserPref = "random",
      regionPref = "random"
    } = v130,
    v131 = normalizePhoneNumber(v129),
    v132 = v131.replace('+', ''),
    v133 = uuid(),
    v134 = "https://auth.meta.com/?waterfall_id=" + v133 + "&source_app_id=1522763855472543";
  onStatus("[1/4] Fetching initial session tokens...");
  const v135 = getCountryFromPhone(v132);
  let v136 = v135.lang;
  try {
    const v137 = getRandomClient(browserPref),
      v138 = generateRandomDOB(),
      v139 = generateRandomPassword(),
      v140 = generateRandomName(),
      v141 = Date.now();
    onStatus("[1/4] Fetching tokens (pure API, no browser)...");
    const v142 = {
        'User-Agent': v137.userAgent,
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        'Accept-Language': v136,
        'Accept-Encoding': "gzip, deflate",
        'Sec-Fetch-Site': "none",
        'Sec-Fetch-Mode': "navigate",
        'Sec-Fetch-Dest': "document",
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        ...v137.clientHints
      },
      v143 = v142,
      v144 = await sendRequest(v134, "GET", v143, null, proxy, timeout);
    if (!v144.data) throw new Error("Failed to load Meta page: empty response");
    let v145 = parseTokensFromHtml(v144.data);
    if (!v145.lsd || !v145.jazoest) throw new Error("Failed to extract LSD/Jazoest tokens.");
    const v146 = Date.now() - v141;
    onStatus("[1/4] Tokens in " + v146 + "ms. Bypassing reg_integrity...");
    let v147 = {};
    const fn4 = v187 => {
      {
        if (!v187) return;
        v187.forEach(v188 => {
          const v189 = v188.split(';')[0].split('=');
          if (v189.length >= 2) v147[v189[0].trim()] = v189.slice(1).join('=').trim();
        });
      }
    };
    fn4(v144.cookies);
    const fn5 = v190 => "__user=0&__a=1&__req=" + v190 + "&__hs=20602.HYP:frl_comet_auth_pkg.2.1...0&dpr=1&__ccg=EXCELLENT&__rev=" + (v145.rev || 1040404884) + "&__hsi=" + (v145.hsi || '') + "&__comet_req=33&lsd=" + v145.lsd + "&jazoest=" + (v145.jazoest || '') + "&__spin_r=" + (v145.spin_r || '') + "&__spin_b=" + (v145.spin_b || '') + "&__spin_t=" + (v145.spin_t || '') + "&__jssesw=1",
      fn6 = () => ({
        'User-Agent': v137.userAgent,
        'Accept': "*/*",
        'Accept-Language': v136,
        'Accept-Encoding': "gzip, deflate",
        'Content-Type': "application/x-www-form-urlencoded",
        'Origin': "https://auth.meta.com",
        'Referer': v134,
        'X-FB-LSD': v145.lsd,
        'Sec-Fetch-Site': "same-origin",
        'Sec-Fetch-Mode': "cors",
        'Sec-Fetch-Dest': "empty",
        'Cookie': Object.entries(v147).map(([v191, v192]) => v191 + '=' + v192).join(';\x20'),
        ...v137.clientHints
      });
    onStatus("[2/4] Verifying phone number...");
    const v148 = Array(24).fill(0).map(() => "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(Math.floor(Math.random() * 62))).join(''),
      v149 = "account_reg_info[birthday]=" + v138.full + "&account_reg_info[device_id]=&account_reg_info[first_name]=" + encodeURIComponent(v140.first) + "&account_reg_info[has_youth_consent]=false&account_reg_info[is_bootstrap_flow]=false&account_reg_info[last_name]=" + encodeURIComponent(v140.last) + "&account_reg_info[pc_rendering_data]=&account_reg_info[phone_number]=%2B" + v132 + "&account_reg_info[registration_flow_id]=&allow_unconfirmed_email=false&check_for_pre_registration_restrictions=true&check_mma_account=false&contact_point=%2B" + v132 + "&contact_point_type=PHONE_NUMBER&reg_integrity=&check_ntm_qe=true&skip_xapp_checks=false&caa_event_flow=&csi=" + v148 + "&event_client_time=" + Math.floor(Date.now() / 1000) + "&waterfall_id=" + v133 + "&source_app_id=1522763855472543&qpl_join_id=&" + fn5('h');
    debugLog(v132, "check-contact-req", {
      'url': "https://auth.meta.com/api/check-contact-point-availability/",
      'method': "POST",
      'headers': fn6(),
      'payload': v149
    });
    const v150 = await sendRequest("https://auth.meta.com/api/check-contact-point-availability/", "POST", fn6(), v149, proxy, timeout),
      v151 = {};
    v151.status = v150.status, v151.headers = v150.headers, v151.body = v150.data, debugLog(v132, "check-contact-res", v151);
    if (v150.status !== 200) throw new Error("Invalid response: " + v150.status);
    fn4(v150.cookies);
    let v152 = '',
      v153 = '',
      v154 = null;
    try {
      const v193 = JSON.parse(v150.data.replace("for (;;);", ''));
      if (v193.error === 3571123 || v193.error === 3571188) v154 = v193.error, onStatus("[2/4] Number has existing account (" + (v193.error === 3571123 ? "registered" : "pending") + ") → switching to reset flow...");else {
        if (v193.error) throw new Error(v193.errorDescription || v193.errorSummary || "Verification failed");else {
          if (v193.payload && v193.payload.is_contact_point_available === false) throw new Error(v193.payload.error_message || "Phone number not available");
          const v194 = v193.payload && (v193.payload.regIntegrity || v193.payload.reg_integrity);
          v194 && (v152 = encodeURIComponent(v194), onStatus("[2/4] ✅ Got reg_integrity from server (pure API, no browser!)"));
          if (v193.payload && v193.payload.restrictions && v193.payload.restrictions.restriction_data && v193.payload.restrictions.restriction_data.account_reg_info) {
            v153 = v193.payload.restrictions.restriction_data.account_reg_info.device_id || '';
          }
        }
      }
    } catch (v195) {
      {
        if (!(v195 instanceof SyntaxError)) throw v195;
      }
    }
    if (v154) {
      onStatus("[3/4] Sending login OTP to existing account...");
      const v196 = "contact_point=%2B" + v132 + "&caa_event_flow=ntf&csi=" + v148 + "&source_app_id=1522763855472543&waterfall_id=" + v133 + "&qpl_join_id=&" + fn5('r');
      debugLog(v132, "send-nonce-req", {
        'url': "https://auth.meta.com/api/login-email-otp/send-nonce/",
        'method': "POST",
        'headers': fn6(),
        'payload': v196
      });
      const v197 = await sendRequest("https://auth.meta.com/api/login-email-otp/send-nonce/", "POST", fn6(), v196, proxy, timeout),
        v198 = {};
      v198.status = v197.status, v198.headers = v197.headers, v198.body = v197.data, debugLog(v132, "send-nonce-res", v198), fn4(v197.cookies);
      let v199 = false,
        v200 = '';
      try {
        {
          const v201 = JSON.parse(v197.data.replace("for (;;);", ''));
          if (v201.error) onStatus("[4/4] send-nonce error " + v201.error + ':\x20' + (v201.errorDescription || v201.errorSummary || "unknown")), v200 = v201.errorDescription || v201.errorSummary || "Error " + v201.error;else {
            if (v201.payload && (v201.payload.nonce_sent === true || v201.payload.nonceSent === true)) v199 = true, v200 = "Login OTP confirmed (nonce_sent=true)", onStatus("[4/4] ✅ " + v200);else {
              if (v201.payload && Object.keys(v201.payload).length > 0) {
                v199 = true, v200 = "Login OTP likely sent (payload keys: " + Object.keys(v201.payload).join(',\x20') + ')', onStatus("[4/4] ✅ " + v200);
              } else v200 = "Silent block on login OTP → " + JSON.stringify(v201).substring(0, 200), onStatus("[4/4] ⚠️ " + v200);
            }
          }
        }
      } catch (v202) {
        v200 = "Non-JSON response from send-nonce (" + (v197.data || '').length + " bytes)", onStatus("[4/4] ⚠️ " + v200);
      }
      if (v199) {
        for (let v203 = 0; v203 < (v130.resends || 0); v203++) {
          {
            await new Promise(v208 => setTimeout(v208, 2000));
            if (v130.onLog) v130.onLog("Resending OTP to +" + v132 + '\x20(' + (v203 + 1) + '/' + v130.resends + ')', "retry");
            onStatus("[4/4] 🔄 Resending OTP (" + (v203 + 1) + '/' + v130.resends + ")...");
            let v204 = (parseInt('r', 36) + v203 + 1).toString(36),
              v205 = "contact_point=%2B" + v132 + "&caa_event_flow=ntf&csi=" + v148 + "&source_app_id=1522763855472543&waterfall_id=" + v133 + "&qpl_join_id=&" + fn5(v204);
            debugLog(v132, "resend-nonce-req", {
              'url': "https://auth.meta.com/api/login-email-otp/send-nonce/",
              'method': "POST",
              'headers': fn6(),
              'payload': v205
            });
            let v206 = await sendRequest("https://auth.meta.com/api/login-email-otp/send-nonce/", "POST", fn6(), v205, proxy, timeout);
            const v207 = {};
            v207.status = v206.status, v207.headers = v206.headers, v207.body = v206.data, debugLog(v132, "resend-nonce-res", v207), fn4(v206.cookies);
          }
        }
        return {
          'success': true,
          'message': "Login OTP Sent successfully",
          'phone': v131,
          'type': "login_otp",
          'password': "N/A (existing)",
          'dob': v138,
          'browser': v137.name,
          'lang': v136.substring(0, 5)
        };
      } else throw new Error("Login OTP flow failed - could not send OTP");
    }
    onStatus("[3/4] Password + DOB check...");
    const v155 = "akash99ak",
      v156 = "#PWD_BROWSER:0:" + Math.floor(Date.now() / 1000) + ':' + v155,
      v157 = "contact_point=%2B" + v132 + "&date_of_birth=" + v138.full + "&name=" + encodeURIComponent(v140.full) + "&password=" + encodeURIComponent(v156) + "&contact_pointless_account=false&qpl_join_id=&" + fn5('r');
    debugLog(v132, "check-password-req", {
      'url': "https://auth.meta.com/api/check-password/",
      'method': "POST",
      'headers': fn6(),
      'payload': v157
    });
    const v158 = await sendRequest("https://auth.meta.com/api/check-password/", "POST", fn6(), v157, proxy, timeout),
      v159 = {};
    v159.status = v158.status, v159.headers = v158.headers, v159.body = v158.data, debugLog(v132, "check-password-res", v159), fn4(v158.cookies);
    const v160 = "caa_event_flow=ntf&date_of_birth=" + v138.full + "&first_name=" + encodeURIComponent(v140.first) + "&has_youth_consent=false&isf=false&last_name=" + encodeURIComponent(v140.last) + "&phone_number=%2B" + v132 + "&qpl_join_id=&reg_integrity=" + v152 + "&source_app_id=1522763855472543&" + fn5('t');
    debugLog(v132, "check-dob-req", {
      'url': "https://auth.meta.com/api/check-date-of-birth/",
      'method': "POST",
      'headers': fn6(),
      'payload': v160
    });
    const v161 = await sendRequest("https://auth.meta.com/api/check-date-of-birth/", "POST", fn6(), v160, proxy, timeout),
      v162 = {};
    v162.status = v161.status, v162.headers = v161.headers, v162.body = v161.data, debugLog(v132, "check-dob-res", v162), fn4(v161.cookies);
    try {
      {
        const v209 = JSON.parse(v161.data.replace("for (;;);", ''));
        if (v209.error) throw new Error(v209.errorDescription || v209.errorSummary || "DOB check failed");
        v209.payload && v209.payload.regIntegrity && (v152 = encodeURIComponent(v209.payload.regIntegrity), onStatus("[3/4] Got server-issued regIntegrity (pure API, no browser!)..."));
      }
    } catch (v210) {
      {
        if (!(v210 instanceof SyntaxError)) throw v210;
      }
    }
    const v163 = "date_of_birth=" + v138.full + '&' + fn5('u');
    debugLog(v132, "marketing-opt-req", {
      'url': "https://auth.meta.com/api/eligible-for-default-marketing-opt-in/",
      'method': "POST",
      'headers': fn6(),
      'payload': v163
    });
    const v164 = await sendRequest("https://auth.meta.com/api/eligible-for-default-marketing-opt-in/", "POST", fn6(), v163, proxy, timeout),
      v165 = {};
    v165.status = v164.status, v165.headers = v164.headers, v165.body = v164.data, debugLog(v132, "marketing-opt-res", v165), fn4(v164.cookies);
    let v166 = 'US';
    try {
      v166 = JSON.parse(v145.regulation_jurisdiction)[0];
    } catch (v211) {}
    const v167 = {};
    v167.appScopedIdentity = '0', v167.claim = '';
    const v168 = "ph=C3&ts=" + Date.now() + "&q=" + encodeURIComponent(JSON.stringify([{
        'app_id': "713378262994144",
        'posts': [["falco:caa_acquisition_client_events_rl", {
          'e': "{\"acquisition_client_params\":{\"entry_point\":\"login_home\",\"is_feta_ntm\":false,\"reg_instance\":\"vP0bagdOXYi6S_j4MWBYYlk2\",\"regulation_jurisdiction\":\"[\\\"" + v166 + "\\\"]\",\"state\":\"password_saving_opt_in\"},\"core\":{\"access_flow_version\":\"pre_mt_behavior\",\"contactpoint\":\"+" + v132 + "\",\"event\":\"registration_flow_state\",\"event_category\":\"registration_funnel\",\"event_flow\":\"ntf\",\"event_step\":\"profile_creation\",\"exception_code\":null,\"exception_message\":null,\"exception_type\":null,\"extra_client_data\":{\"reg_navigation_flow_name\":\"new_to_family_c50_r1\",\"is_phone_cp_enabled\":true,\"is_web_flow_override\":\"1\"},\"logged_out_identifier\":\"+" + v132 + "\",\"rl_client_session_id\":\"" + v148 + "\",\"source_app_id\":1522763855472543,\"waterfall_id\":\"" + v133 + "\",\"event_request_id\":\"" + uuid() + "\"}}",
          'r': 0x1,
          'd': "fd.ARsMk_nh5dY03YVrV-wF1ID8EjSupWWZYNUz4Y9MRR0aM4uOzvsupjNHS2-ppMs-8FeUzjucb3_sf1wMRcOefBvP",
          's': "pjpt1c:3ectou:g87e68",
          't': Date.now() / 1000,
          'a': "1040.504.379.0 (1040504379)",
          'b': [1, 128],
          'id': v167
        }, Date.now(), 0, 1227]],
        'trigger': "falco:caa_acquisition_client_events_rl",
        'user': '0',
        'webSessionId': ''
      }])) + '&' + fn5('w'),
      v169 = await sendRequest("https://auth.meta.com/ajax/bz?__a=1&__ccg=EXCELLENT&__comet_req=33&__req=w&__user=0&dpr=1&jazoest=" + v145.jazoest + "&lsd=" + v145.lsd + "&ph=C3", "POST", fn6(), v168, proxy, timeout);
    fn4(v169.cookies), onStatus("[4/4] Finalizing profile to dispatch SMS...");
    const v170 = v140.first.toLowerCase() + v140.last.toLowerCase() + Math.floor(Math.random() * 9999),
      v171 = "client_consent_timestamp=" + Math.floor(Date.now() / 1000) + "&display_name=" + encodeURIComponent(v140.full) + "&foa_import_source_name=&foa_import_source_obid=&nta_disclosures_summary_cms_id=&picture_source=&tos_cms_id=957798449862312&username=" + v170 + "&caa_event_flow=ntf&csi=" + v148 + "&source_app_id=1522763855472543&waterfall_id=" + v133 + "&is_submit=true&" + fn5('17');
    debugLog(v132, "check-profile-req", {
      'url': "https://auth.meta.com/api/kadabra/check_profile/",
      'method': "POST",
      'headers': fn6(),
      'payload': v171
    });
    const v172 = await sendRequest("https://auth.meta.com/api/kadabra/check_profile/", "POST", fn6(), v171, proxy, timeout),
      v173 = {};
    v173.status = v172.status, v173.headers = v172.headers, v173.body = v172.data, debugLog(v132, "check-profile-res", v173), fn4(v172.cookies);
    const v174 = {
        'csrf_token': crypto.randomBytes(32).toString("base64url"),
        'redirect_to': "https://www.meta.ai/oidc/callback",
        'waterfall_id': v133
      },
      v175 = Buffer.from(JSON.stringify(v174)).toString("base64"),
      v176 = crypto.randomBytes(32).toString("base64url");
    let v177 = 'US';
    try {
      v177 = JSON.parse(v145.regulation_jurisdiction)[0];
    } catch (v212) {}
    const v178 = encodeURIComponent("https://auth.meta.com/oidc/?app_id=1522763855472543&redirect_uri=https%3A%2F%2Fauth.meta.ai%2Fecto&response_type=code&scope=openid%2Blinking&state=" + v175 + "&waterfall_id=" + v133 + "&code_challenge=" + v176 + "&code_challenge_method=S256"),
      v179 = encodeURIComponent(JSON.stringify([v177])),
      v180 = "client_consent_timestamp=" + Math.floor(Date.now() / 1000) + "&display_name=" + encodeURIComponent(v140.full) + "&foa_import_source_name=&foa_import_source_obid=&nta_disclosures_summary_cms_id=&picture_source=&tos_cms_id=957798449862312&username=" + v170 + "&consent_version=&contact_point=%2B" + v132 + "&contact_point_type=PHONE_NUMBER&csi=" + v148 + "&date_of_birth=" + v138.full + "&device_id=" + v153 + "&fb_encrypted_access_token=&fb_oidc_access_token=&first_name=" + encodeURIComponent(v140.first) + "&has_youth_consent=false&ig_encrypted_access_token=&ig_encrypted_auth_header=&ig_oidc_access_token=&last_name=" + encodeURIComponent(v140.last) + "&opt_into_marketing=false&password=" + encodeURIComponent(v156) + "&redirect_uri=" + v178 + "&reg_integrity=" + v152 + "&should_save_credentials=true&source_app_id=1522763855472543&third_party_age_verification_id=&waterfall_id=" + v133 + "&caa_event_flow=ntf&entry_point=login_home&event_client_time=" + Math.floor(Date.now() / 1000) + "&is_kadabra_zero=false&reg_navigation_flow_name=new_to_family_c50_r1&regulation_jurisdiction=" + v179 + "&qpl_join_id=&" + fn5('18');
    debugLog(v132, "register-save-req", {
      'url': "https://auth.meta.com/login/device-based/kadabra-register-save-credentials/",
      'method': "POST",
      'headers': fn6(),
      'payload': v180
    });
    const v181 = await sendRequest("https://auth.meta.com/login/device-based/kadabra-register-save-credentials/", "POST", fn6(), v180, proxy, timeout),
      v182 = {};
    v182.status = v181.status, v182.headers = v181.headers, v182.body = v181.data, debugLog(v132, "register-save-res", v182), fn4(v181.cookies);
    if (v181.status !== 200) throw new Error("Meta API failed with HTTP " + v181.status);
    const v183 = v181.data || '';
    let v184 = false,
      v185 = '';
    try {
      const v213 = JSON.parse(v183.replace("for (;;);", ''));
      if (v213.error) {
        throw new Error(v213.errorDescription || v213.errorSummary || "Registration blocked (Error " + v213.error + ')');
      }
      if (v213.payload && v213.payload.error_message) throw new Error(v213.payload.error_message);
      if (v213.payload) {
        if (v213.payload.redirect_uri || v213.payload.redirectUri || v213.payload.redirect) v184 = true, v185 = "Registration confirmed (redirect received)";else {
          if (v213.payload.nonce_sent === true || v213.payload.nonceSent === true) {
            v184 = true, v185 = "OTP confirmed (nonce_sent=true)";
          } else {
            if (v213.payload.session_id || v213.payload.sessionId || v213.payload.confirmation_code) v184 = true, v185 = "Registration confirmed (session created)";else {
              {
                const v214 = Object.keys(v213.payload);
                if (v214.length > 0 && !v213.payload.error_message) v184 = true, v185 = "Registration likely succeeded (payload keys: " + v214.join(',\x20') + ')';else {
                  throw new Error("Silent block: Meta returned empty/unrecognized payload → " + JSON.stringify(v213.payload).substring(0, 200));
                }
              }
            }
          }
        }
      } else {
        if (v213.redirect_uri || v213.redirectUri) v184 = true, v185 = "Registration confirmed (top-level redirect)";else throw new Error("Silent block: Meta returned no payload → " + JSON.stringify(v213).substring(0, 300));
      }
    } catch (v215) {
      if (v215 instanceof SyntaxError) {
        {
          if (v183.includes("checkpoint") || v183.includes("security_check")) {
            throw new Error("Account hit checkpoint/security block");
          } else {
            if (v183.includes("auth.meta.com/oidc") || v183.includes("confirmation") || v183.includes("verify")) v184 = true, v185 = "Registration confirmed (HTML redirect to verification)";else {
              throw new Error("Silent block: Non-JSON response (" + v183.length + " bytes) → " + v183.substring(0, 200));
            }
          }
        }
      } else {
        throw v215;
      }
    }
    if (!v184) throw new Error("Registration failed: no confirmation signal from Meta");
    let v186 = Math.max(0, v130.resends || 0);
    for (let v216 = 0; v216 < v186; v216++) {
      {
        await new Promise(v221 => setTimeout(v221, 3000));
        if (v130.onLog) v130.onLog("Resending OTP to +" + v132 + '\x20(' + (v216 + 1) + '/' + v186 + ')', "retry");
        onStatus("[4/4] 🔄 Resending OTP (" + (v216 + 1) + '/' + v186 + ")...");
        let v217 = (parseInt('18', 36) + v216 + 1).toString(36),
          v218 = v180.replace(/&__req=18&/, "&__req=" + v217 + '&'),
          v219 = await sendRequest("https://auth.meta.com/login/device-based/kadabra-register-save-credentials/", "POST", fn6(), v218, proxy, timeout);
        const v220 = {};
        v220.status = v219.status, v220.headers = v219.headers, v220.body = v219.data, debugLog(v132, "resend-register-res", v220), fn4(v219.cookies);
      }
    }
    return onStatus("[4/4] ✅ " + v185), {
      'success': true,
      'message': v185,
      'phone': v131,
      'type': "registration",
      'password': v139,
      'dob': v138,
      'browser': v137.name,
      'lang': v136.substring(0, 5)
    };
  } catch (v222) {
    {
      const v223 = {};
      return v223.success = false, v223.message = "Failed: " + v222.message, v223.phone = v131, v223;
    }
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v224) {
      {
        this.totalNumbers = v224;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v225, v226) {
      let v227 = '';
      const v228 = v225.match(/\d{8,}/),
        v229 = v228 ? v228[0] : '';
      if (v226 === "success") v227 = chalk.hex("#00FF88")("REX — Meta │ OTP Sent → ") + chalk.hex("#FCAF45").bold(v229 || v225);else {
        if (v226 === "error" || v226 === "failed") {
          {
            let v230 = v225.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
            v230.toLowerCase().includes("proxy") ? v227 = chalk.hex("#FF4466")("REX — Meta │ Proxy Drop → ") + chalk.hex("#888888")(v230) : v227 = chalk.hex("#FF4466")("REX — Meta │ Failed → ") + chalk.hex("#FCAF45").bold(v229) + chalk.hex("#888888")('\x20(' + v230 + ')');
          }
        } else {
          if (v226 === "retry") {
            {
              let v231 = v225.includes('(') ? v225.substring(v225.indexOf('(')) : '';
              v227 = chalk.hex("#FCAF45")("REX — Meta │ Resending  → ") + chalk.hex("#FCAF45").bold(v229) + chalk.hex("#888888")('\x20' + v231);
            }
          } else return;
        }
      }
      process.stdout.write("\r[K" + v227 + '\x0a'), this.render();
    }
    ["setStatus"](v232) {}
    ["update"]() {}
    ["render"]() {
      const v233 = (this.processed / Math.max(this.totalNumbers, 1) * 100).toFixed(1),
        v234 = '\x20\x20' + W.bold("REX-V5") + " ⮞ [" + this.processed + '/' + this.totalNumbers + ']\x20' + v233 + "% │ " + B("OK: " + this.successful) + " │ " + R("Err: " + this.failed);
      process.stdout.write("\r[K" + v234);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v235 = Math.floor((Date.now() - this.startTime) / 1000),
        v236 = Math.floor(v235 / 60),
        v237 = v235 % 60,
        v238 = v236 + 'm\x20' + v237 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  REX V5                                    ") + C('║'));
      console.log(C("  ╠════════════════════════════════════════════╣"));
      console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v238.padEnd(6)) + "                       ") + C('║'));
      console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v239, v240) {
    return new Promise(v241 => {
      let v242 = 0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn7 = () => {
        process.stdout.write("[2J[H"), printHeader(), console.log("   [33m" + v239 + "[0m\n"), v240.forEach((v243, v244) => {
          v244 === v242 ? console.log("   [36m➔[32m " + v243.name + "[0m") : console.log("     [90m" + v243.name + "[0m");
        });
      };
      fn7();
      const fn8 = (v245, v246) => {
        if (v246.ctrl && v246.name === 'c') {
          process.exit(0);
        }
        if (v246.name === 'up') v242 = (v242 - 1 + v240.length) % v240.length, fn7();else {
          if (v246.name === "down") v242 = (v242 + 1) % v240.length, fn7();else v246.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn8), v241(v240[v242].value));
        }
      };
      process.stdin.on("keypress", fn8);
    });
  }
  async function promptText(v247, v248) {
    return new Promise(v249 => {
      {
        process.stdout.write("   [33m" + v247 + "[0m ");
        let v250 = '';
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.resume();
        const fn9 = v251 => {
          {
            const v252 = v251.toString();
            if (v252.includes('\x0a') || v252.includes('\x0d')) {
              process.stdin.removeListener("data", fn9), v250 += v252.split(/[\r\n]/)[0];
              let v253 = v250.trim();
              if (v253.startsWith('\x22') && v253.endsWith('\x22')) v253 = v253.slice(1, -1);else v253.startsWith('\x27') && v253.endsWith('\x27') && (v253 = v253.slice(1, -1));
              v249(v253 || v248);
            } else v250 += v252;
          }
        };
        process.stdin.on("data", fn9);
      }
    });
  }
  async function interactiveWizard() {
    process.stdout.write("[2J[H"), printHeader(), console.log(W.bold("  --- REX META AI  ---\n"));
    const v254 = await selectOption("SELECT NUMBER SOURCE", [{
      'name': "📁 Load from file (numbers.txt)",
      'value': "file"
    }, {
      'name': "🌐 Auto fetch from NexaOTP Panel",
      'value': "nexa"
    }]);
    let v255 = "numbers.txt",
      v256 = null;
    if (v254 === "nexa") {
      let v263 = '';
      const v264 = path.join(__dirname, ".nexa_api_key");
      if (fs.existsSync(v264)) {
        const v271 = fs.readFileSync(v264, "utf8").trim(),
          v272 = await selectOption("Found saved API Key (..." + v271.slice(-4) + "). Use it?", [{
            'name': "Yes, use saved key",
            'value': "yes"
          }, {
            'name': "No, enter new key",
            'value': 'no'
          }, {
            'name': "Delete saved key",
            'value': "delete"
          }]);
        if (v272 === "yes") v263 = v271;else v272 === "delete" && (fs.unlinkSync(v264), console.log(G("\n   ✗ Saved key deleted.\n")));
      }
      if (!v263) {
        {
          v263 = await promptText("Enter NexaOTP API Key:", '');
          const v273 = {};
          v273.name = 'No', v273.value = 'no';
          const v274 = await selectOption("Save this key for future use?", [{
            'name': "Yes, save it",
            'value': "yes"
          }, v273]);
          v274 === "yes" && (fs.writeFileSync(v264, v263, "utf8"), console.log(G("\n   ✓ API key saved.\n")));
        }
      }
      let v265 = [],
        v266 = true;
      while (v266) {
        const v275 = await promptText("Enter range #" + (v265.length + 1) + " (e.g. 21624485XXX):", '');
        if (v275) v265.push(v275);
        const v276 = await selectOption("Add another range?", [{
          'name': "Yes",
          'value': "yes"
        }, {
          'name': "No, proceed",
          'value': 'no'
        }]);
        if (v276 === 'no') v266 = false;
      }
      v265.length === 0 && (console.log(R("\n   ✗ You must provide at least one range.\n")), process.exit(1));
      const v267 = await promptText("How many numbers to process? (e.g. 100):", '50'),
        v268 = parseInt(v267) || 50,
        v269 = await selectOption("SELECT NEXA SERVER", [{
          'name': "Server 1 (/get)",
          'value': "/api/v1/numbers/get"
        }, {
          'name': "Server 2 (/p2/get)",
          'value': "/api/v1/numbers/p2/get"
        }, {
          'name': "Server 3 (/p3/get)",
          'value': "/api/v1/numbers/p3/get"
        }]),
        v270 = {};
      v270.apiKey = v263, v270.ranges = v265, v270.totalCount = v268, v270.serverEndpoint = v269, v256 = v270;
    } else {
      {
        v255 = await promptText("Enter Numbers File Path [default: numbers.txt]:", "numbers.txt");
        if (!fs.existsSync(v255)) fs.writeFileSync(v255, '');
      }
    }
    let v257 = await promptText("Enter Proxies File Path (Leave blank for direct) [default: none]:", "none");
    if (v257 === "none" || v257 === '') v257 = '';
    const v258 = await selectOption("SELECT THREADS", [{
        'name': "10 Threads",
        'value': 0xa
      }, {
        'name': "20 Threads (Default)",
        'value': 0x14
      }, {
        'name': "50 Threads (Fast)",
        'value': 0x32
      }, {
        'name': "100 Threads (Extreme)",
        'value': 0x64
      }]),
      v259 = await selectOption("SELECT REGION", [{
        'name': "🎲 Random",
        'value': "random"
      }, {
        'name': "🇺🇸 English (en-US)",
        'value': "en-US"
      }, {
        'name': "🇪🇸 Spanish (es-ES)",
        'value': "es-ES"
      }]),
      v260 = await selectOption("SELECT BROWSER PROFILE", [{
        'name': "🍎 iOS Safari (Highest Trust)",
        'value': "ios"
      }, {
        'name': "🎲 Random Mix",
        'value': "random"
      }, {
        'name': "🌐 Google Chrome",
        'value': "chrome"
      }, {
        'name': "📱 Samsung Internet",
        'value': "samsung"
      }, {
        'name': "🦊 Mozilla Firefox",
        'value': "firefox"
      }, {
        'name': "🌊 Microsoft Edge",
        'value': "edge"
      }]),
      v261 = await promptText("Enter number of OTP resends per number [default: 0]:", '0');
    const v262 = parseInt(v261) || 0;
    return process.stdin.pause(), {
      'numbersFile': v255,
      'threads': String(v258),
      'proxiesFile': v257,
      'region': v259,
      'browser': v260,
      'resends': String(v262),
      'nexaConfig': v256
    };
  }
  function generateHWID() {
    const v277 = require('os'),
      v278 = v277.platform();
    try {
      {
        if (v278 === "win32") {
          const v279 = execSync('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
            'stdio': "pipe",
            'timeout': 0x3a98
          }).toString().trim();
          if (!v279) throw new Error("No hardware data");
          const v280 = crypto.createHash("sha256").update(v279).digest("hex").toUpperCase();
          return "SKING-" + v280.substring(0, 8) + '-' + v280.substring(8, 12) + '-' + v280.substring(12, 16);
        } else {
          {
            let v281 = [];
            try {
              const v284 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
                'stdio': "pipe",
                'timeout': 0x1388
              }).toString().trim();
              if (v284 && v284 !== "null") v281.push('A:' + v284);
            } catch (v285) {}
            try {
              {
                if (fs.existsSync("/proc/cpuinfo")) {
                  {
                    const v286 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                      v287 = v286.match(/Serial\s*:\s*(\S+)/i),
                      v288 = v286.match(/Hardware\s*:\s*(.+)/i);
                    if (v287 && v287[1] !== "0000000000000000") v281.push('S:' + v287[1].trim());
                    if (v288) v281.push('H:' + v288[1].trim());
                  }
                }
              }
            } catch (v289) {}
            try {
              if (fs.existsSync("/etc/machine-id")) {
                const v290 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                if (v290) v281.push('M:' + v290);
              }
            } catch (v291) {}
            try {
              {
                const v292 = v277.cpus(),
                  v293 = v292 && v292.length > 0 ? v292[0].model : "UnknownCPU",
                  v294 = v277.totalmem(),
                  v295 = v277.release(),
                  v296 = v277.hostname();
                v281.push('F:' + v293 + '|' + v294 + '|' + v295 + '|' + v296);
              }
            } catch (v297) {}
            const v282 = v281.join('||'),
              v283 = crypto.createHash("sha256").update(v282).digest("hex").toUpperCase();
            return "ANKING-" + v283.substring(0, 8) + '-' + v283.substring(8, 12) + '-' + v283.substring(12, 16);
          }
        }
      }
    } catch (v298) {
      return '';
    }
  }
  function verifyServerSignature(v299, v300) {
    if (!v300) return false;
    const v301 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v299, "utf8"), v301, Buffer.from(v300, "base64"));
    } catch (v302) {
      return false;
    }
  }
  async function start() {
    const v303 = generateHWID();
    !v303 && (console.error(R("\n  ✗ Could not generate Hardware ID.")), console.error(R("  ✗ Please run on Windows or provide HWID as argument.\n")), process.exit(1));
    const v304 = generateHWID();
    if (v304 !== v303) {
      console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1);
    }
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + C("Meta Account Creator         ") + W('│')), console.log(W("│ [•] Your HWID : ") + Y(v303.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v305 = false,
      v306 = "Licensed";
    const v307 = Date.now();
    try {
      const v318 = "188.137.176.163",
        v319 = require("http"),
        v320 = await new Promise((v321, v322) => {
          {
            const v323 = {};
            v323.hwid = v303, v323.app_id = "meta", v323.version = "2.0.2", v323.timestamp = v307;
            const v324 = JSON.stringify(v323),
              v325 = {
                'hostname': v318,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v324)
                },
                'timeout': 0x2710
              },
              v326 = v319.request(v325, v327 => {
                {
                  let v328 = '';
                  v327.on("data", v329 => v328 += v329), v327.on("end", () => {
                    try {
                      v321(JSON.parse(v328));
                    } catch (v330) {
                      v322(v330);
                    }
                  });
                }
              });
            v326.on("error", v322), v326.on("timeout", function () {
              this.destroy();
              v322(new Error("Timeout"));
            }), v326.write(v324), v326.end();
          }
        });
      if (v320) {
        {
          v320.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v320.status === "banned" || v320.status === "expired" || !v320.sig) {
            {
              await new Promise(v334 => setTimeout(v334, 2000));
              let v333 = String(v320.reason || "NOT REGISTERED");
              if (!v320.reason && !v320.sig) v333 = "NOT REGISTERED / REMOVED";
              console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — META TOOL     ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v303.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v333.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
            }
          }
          const v331 = v303 + "|meta|2.0.2|" + v307;
          !verifyServerSignature(v331, v320.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
          v305 = true;
          let v332 = v320.token;
          !v332 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1)), setInterval(() => {
            !v332 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
            const v335 = {};
            v335.hwid = v303;
            v335.app_id = "meta", v335.token = v332;
            const v336 = JSON.stringify(v335),
              v337 = {
                'hostname': v318,
                'port': 0xec1,
                'path': "/api/ping",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v336)
                },
                'timeout': 0x1388
              },
              v338 = v319.request(v337, v339 => {
                let v340 = '';
                v339.on("data", v341 => v340 += v341), v339.on("end", () => {
                  try {
                    {
                      const v342 = JSON.parse(v340);
                      v342.status === 'ok' && v342.token ? v332 = v342.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                    }
                  } catch (v343) {
                    console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                  }
                });
              });
            v338.on("error", () => {
              console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n")), process.exit(1);
            }), v338.on("timeout", function () {
              this.destroy(), console.error(R("\n  ✗ License Server timeout. Exiting...\n")), process.exit(1);
            }), v338.write(v336);
            v338.end();
          }, 45000);
        }
      }
    } catch (v344) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    !v305 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    const v308 = process.argv.slice(2).filter(v345 => !v345.startsWith('--'));
    let v309 = v308,
      v310 = null;
    if (v309.length === 0) {
      {
        const v346 = await interactiveWizard();
        v309 = [v346.numbersFile, v346.threads, v346.proxiesFile, v346.region, v346.browser, "SKING-UI-HARDWARE-ID", v346.resends], v310 = v346.nexaConfig;
      }
    }
    v309 = v309.map(v347 => {
      {
        if (typeof v347 === "string") {
          {
            if (v347.startsWith('\x22') && v347.endsWith('\x22')) return v347.slice(1, -1);
            if (v347.startsWith('\x27') && v347.endsWith('\x27')) return v347.slice(1, -1);
          }
        }
        return v347;
      }
    });
    let v311 = path.resolve(v309[0] || "numbers.txt"),
      v312 = parseInt(v309[1]) || 20,
      v313 = v309[2] !== undefined ? v309[2] : "proxies.txt";
    if (v313.toLowerCase() === "none" || v313 === "false") v313 = '';
    let v314 = v309[3] || "random",
      v315 = v309[4] || "random",
      v316 = parseInt(v309[6]) || 0;
    v313 && !v313.includes(':') && !path.isAbsolute(v313) && (v313 = path.resolve(v313));
    printHeader(), console.log(B("  ✓ License: " + v306) + G(" | HWID: " + v303));
    let v317 = true;
    while (v317) {
      let v348 = [];
      if (!v310) {
        !fs.existsSync(v311) && (console.error(R("✗ Error: Numbers file not found: " + v311)), process.exit(1));
        v348 = fs.readFileSync(v311, "utf8").split(/\r?\n/).map(v362 => v362.trim()).filter(v363 => v363 && v363.replace(/\D/g, '').length >= 7);
        if (v348.length === 0) {
          console.error(R("✗ No valid phone numbers found in file")), process.exit(1);
        }
      }
      let v349 = [];
      v313 && fs.existsSync(v313) && (v349 = fs.readFileSync(v313, "utf8").split('\x0a').map(v364 => v364.trim()).filter(v365 => v365.length > 0));
      let v350 = [];
      for (const v366 of v349) {
        {
          const v367 = parseProxy(v366);
          if (!v367) {
            {
              {
                console.error(R("\n  ✗ Invalid proxy format detected: \"" + v366 + '\x22'));
                console.error(R("  Please use one of the supported formats:"));
                console.error(R("    - host:port"));
                console.error(R("    - user:pass@host:port"));
                console.error(R("    - host:port:user:pass"));
                console.error(R("    - user:pass:host:port\n"));
                process.exit(1);
              }
            }
          }
          v350.push(v367);
        }
      }
      v310 ? console.log(C("✓ Target  : NexaOTP API (" + v310.totalCount + " numbers)")) : console.log(Y("✓ Loaded " + v348.length + " targets"));
      if (v350.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v350.length));
      console.log(C("✓ Threads: " + v312 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, ''), fs.writeFileSync(DEBUG_FILE, "=== DEBUG SESSION ===\n");
      const v351 = new Dashboard(v310 ? v310.totalCount : v348.length);
      let v352 = [],
        v353 = [],
        v354 = 0,
        v355 = false;
      v310 && (async () => {
        try {
          for (let v368 = 0; v368 < v310.totalCount; v368++) {
            try {
              const v369 = v310.ranges[Math.floor(Math.random() * v310.ranges.length)],
                v370 = await nexaLimiter.enqueue(() => nexaFetchNumber(v310.apiKey, v369, v310.serverEndpoint));
              if (v370) {
                {
                  v354++;
                  if (v353.length > 0) v353.shift()(v370);else {
                    v352.push(v370);
                  }
                }
              }
            } catch (v371) {
              {
                if (v371.message.includes("Insufficient balance") || v371.message.includes("No numbers available")) {
                  break;
                }
              }
            }
          }
        } finally {
          {
            v355 = true;
            while (v353.length > 0) v353.shift()(null);
          }
        }
      })();
      const v356 = v310 ? () => {
        if (v352.length > 0) return Promise.resolve(v352.shift());
        if (v355) return Promise.resolve(null);
        return new Promise(v372 => v353.push(v372));
      } : () => {
        if (v348.length === 0) return Promise.resolve(null);
        const v373 = Math.floor(Math.random() * v348.length);
        return Promise.resolve(v348.splice(v373, 1)[0]);
      };
      let v357 = 0;
      const fn10 = () => {
        {
          if (v350.length === 0) return null;
          const v374 = v350[v357 % v350.length];
          return v357++, rotateSessionId(v374);
        }
      };
      function fn11(v375) {
        try {
          {
            const v376 = fs.readFileSync(v311, "utf8"),
              v377 = v376.split(/\r?\n/).filter(v378 => v378.trim() !== v375.trim()).join('\x0a');
            fs.writeFileSync(v311, v377);
          }
        } catch (v379) {}
      }
      const v358 = v310 ? Math.min(v312, v310.totalCount) : Math.min(v312, v348.length),
        v359 = [],
        v360 = setInterval(() => v351.render(), 500);
      async function fn12(v380) {
        while (true) {
          const v381 = await v356();
          if (!v381) break;
          try {
            {
              const v383 = await createAccount(v381, {
                'onStatus': v384 => v351.setStatus("Worker " + v380 + ':\x20' + v384),
                'onLog': (v385, v386) => v351.addLog(v385, v386),
                'proxy': fn10(),
                'workerId': v380,
                'browserPref': v315,
                'regionPref': v314,
                'resends': v316
              });
              if (v383.success) {
                v351.successful++, v351.processed++, fn11(v381);
                const v387 = v383.dob ? v383.dob.month + '/' + v383.dob.day + '/' + v383.dob.year : "N/A";
                fs.appendFileSync(SUCCESSFUL_FILE, v383.phone + '|' + (v383.password || "N/A") + '|' + v387 + '\x0a'), v351.addLog("Triggered OTP for " + v383.phone, "success");
              } else v351.failed++, v351.processed++, fs.appendFileSync(FAILED_FILE, v383.phone + '|' + v383.message + '\x0a'), !v383.message.includes("429") && v351.addLog("Failed on " + v383.phone + ':\x20' + v383.message, "error");
            }
          } catch (v388) {
            {
              v351.failed++, v351.processed++;
              if (!v388.message.includes("429")) {
                v351.addLog("Fatal error on " + v381 + ':\x20' + v388.message, "error");
              }
            }
          }
          const v382 = Math.floor(Math.random() * 3000) + 1500;
          await sleep(v382);
        }
      }
      for (let v389 = 0; v389 < v358; v389++) {
        v359.push(fn12(v389));
      }
      await Promise.all(v359), clearInterval(v360), v351.render(), v351.stop();
      const v361 = await selectOption("Processing Complete. What next?", [{
        'name': "Reuse successful numbers (" + SUCCESSFUL_FILE + ')',
        'value': "reuse"
      }, {
        'name': "Go Home (Restart)",
        'value': "home"
      }, {
        'name': "Exit",
        'value': "exit"
      }]);
      if (v361 === "reuse") {
        {
          if (fs.existsSync(SUCCESSFUL_FILE)) {
            {
              let v390 = fs.readFileSync(SUCCESSFUL_FILE, "utf8").split('\x0a').map(v391 => v391.split('|')[0].trim()).filter(v392 => v392.length > 5);
              fs.writeFileSync(v311, v390.join('\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), console.log("\n  [32m✓ Copied " + v390.length + " successful numbers to " + v311 + " and cleared " + SUCCESSFUL_FILE + ".[0m\n");
            }
          } else {
            console.log("\n  [31m✗ No successful numbers found.[0m\n"), v317 = false;
          }
        }
      } else {
        if (v361 === "home") {
          const v393 = await interactiveWizard();
          v309 = [v393.numbersFile, v393.threads, v393.proxiesFile, v393.region, v393.browser, "SKING-UI-HARDWARE-ID", v393.resends], v310 = v393.nexaConfig, v311 = path.resolve(v309[0] || "numbers.txt"), v312 = parseInt(v309[1]) || 20, v313 = v309[2] !== undefined ? v309[2] : "proxies.txt";
          if (v313.toLowerCase() === "none" || v313 === "false") v313 = '';
        } else {
          v317 = false;
        }
      }
    }
  }
  start()["catch"](v394 => {
    console.error(R("Fatal error: " + v394.message));
    process.exit(1);
  });
}
function fn2(v395) {
  function fn13(v396) {
    {
      fn13(++v396);
    }
  }
  try {
    {
      if (v395) return fn13;else fn13(0);
    }
  } catch (v397) {}
}