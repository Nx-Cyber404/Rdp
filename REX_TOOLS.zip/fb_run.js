const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require('child_process'),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ['https-proxy-agent', "socks-proxy-agent", "chalk", "xlsx"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v304) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v305 = {};
      v305.stdio = "inherit", execSync('npm\x20install\x20https-proxy-agent\x20socks-proxy-agent\x20chalk@4\x20xlsx', v305), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v306) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(0x1);
    }
  }
}
const https = require('https'),
  http = require("http"),
  zlib = require('zlib'),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  os = require('os'),
  {
    HttpsProxyAgent
  } = require('https-proxy-agent'),
  {
    SocksProxyAgent
  } = require('socks-proxy-agent');
let SUCCESSFUL_FILE = 'successful.txt',
  FAILED_FILE = 'failed.txt',
  DEBUG_FILE = 'debug.txt';
function debugLog(v307, v308, v309) {}
function cleanErrMsg(v310) {
  if (!v310) return "Unknown error";
  const v311 = String(v310).trim();
  if (/EPROTO|packet length|SSL|TLS|tls_get_more_records/i.test(v311)) return "Proxy TLS drop";
  if (/ECONNRESET|ECONNREFUSED|ETIMEDOUT|socket disconnected/i.test(v311)) return "Proxy connection drop";
  if (/An error occurred during your registration|Si è verificato un errore|Bei deiner Registrierung|Terjadi kesalahan/i.test(v311)) return "Registration error";
  if (/Missing Email|Missing email address/i.test(v311)) return "Missing Email";
  if (/Facebook Checkpoint|Identity\/Human verification/i.test(v311)) return "Checkpoint";
  if (v311.length > 0x3c) return v311.substring(0x0, 0x39) + '...';
  return v311;
}
const B = chalk.hex('#1877F2'),
  C = chalk.hex("#42B72A"),
  Y = chalk.hex('#FFD700'),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B");
function printHeader() {
  process.stdout.write("[2J[3J[H"), console.log(B("  _____ ____     ____ ____  _____    _ _____ _____ ")), console.log(B(" |  ___| __ )   / ___|  _ \\| ____|  / \\_   _| ____|")), console.log(C(" | |_  |  _ \\  | |   | |_) |  _|   / _ \\ | | |  _|  ")), console.log(C('\x20|\x20\x20_|\x20|\x20|_)\x20|\x20|\x20|___|\x20\x20_\x20<|\x20|___\x20/\x20___\x20\x5c|\x20|\x20|\x20|___\x20')), console.log(Y(" |_|   |____/   \\____|_| \\_\\_____/_/   \\_\\_| |_____|")), console.log(W('\x0a┌──────────────────────────────────────────────┐')), console.log(W("│ [•] Author    : ") + B('NOT\x20REXY\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20') + W('│')), console.log(W('│\x20[•]\x20Telegram\x20\x20:\x20') + C("t.me/Rex_OTP_Tool            ") + W('│')), console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
  console.log(W("│ [•] Target    : ") + Y("Facebook Web                 ") + W('│')), console.log(W("│ [•] Version   : ") + B("FB-V2.0.1+                    ") + W('│')), console.log(W('└──────────────────────────────────────────────┘\x0a'));
}
const uuid = () => crypto.randomUUID(),
  NEXA_KEY_FILE = path.join(__dirname, "nexa_key.txt"),
  VOLTX_KEY_FILE = path.join(__dirname, 'voltx_key.txt'),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v312) {
  return new Promise((v313, v314) => {
    const v315 = {};
    v315.Accept = "text/plain", v315.Connection = 'close';
    const v316 = {};
    v316.hostname = "smsbower.page";
    v316.port = 0x1bb, v316.path = "/stubs/handler_api.php?" + v312, v316.method = "GET", v316.headers = v315;
    const v317 = v316,
      v318 = https.request(v317, v319 => {
        let v320 = '';
        v319.on("data", v321 => v320 += v321), v319.on("end", () => v313(v320.trim()));
      });
    v318.on('error', v322 => v314(new Error("SmsBower net: " + v322.message))), v318.setTimeout(0x3a98, () => {
      v318.destroy(), v314(new Error("SmsBower timeout"));
    }), v318.end();
  });
}
function smsBowerFetchNumber(v323, v324, v325, v326) {
  let v327 = 'api_key=' + encodeURIComponent(v323) + "&action=getNumber&service=" + encodeURIComponent(v324 || 'fb');
  v325 && String(v325).trim() !== '0' && String(v325).trim() !== '' && (v327 += "&country=" + encodeURIComponent(v325));
  v326 && parseFloat(v326) > 0x0 && (v327 += "&maxPrice=" + encodeURIComponent(v326));
  return smsBowerRequest(v327).then(v328 => {
    if (v328.startsWith("ACCESS_NUMBER:")) {
      const v329 = v328.split(':');
      return {
        'activationId': v329[0x1],
        'phoneNumber': v329[0x2].replace(/[^0-9]/g, '')
      };
    }
    throw new Error('SmsBower:\x20' + v328);
  });
}
function smsBowerPollOtp(v330, v331, v332 = 0x927c0) {
  return new Promise(v333 => {
    const v334 = Date.now() + v332;
    const fn3 = () => {
      smsBowerRequest('api_key=' + encodeURIComponent(v330) + '&action=getStatus&id=' + v331).then(v335 => {
        if (v335.startsWith("STATUS_OK:")) {
          v333(v335.replace('STATUS_OK:', '').trim());
          return;
        }
        if (v335.startsWith("STATUS_WAIT_RETRY:")) {
          const v336 = v335.replace("STATUS_WAIT_RETRY:", '').trim();
          if (v336 && /^\d{4,8}$/.test(v336)) {
            v333(v336);
            return;
          }
        }
        if (v335 === "STATUS_CANCEL" || v335 === "NO_ACTIVATION") {
          v333(null);
          return;
        }
        if (Date.now() < v334) setTimeout(fn3, 0xfa0);else v333(null);
      }).catch(() => {
        if (Date.now() < v334) setTimeout(fn3, 0xfa0);else v333(null);
      });
    };
    fn3();
  });
}
function smsBowerSetStatus(v337, v338, v339) {
  return smsBowerRequest("api_key=" + encodeURIComponent(v337) + '&action=setStatus&id=' + v338 + "&status=" + v339).catch(() => null);
}
const ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v340, v341) {
  return new Promise((v342, v343) => {
    const v344 = {};
    v344.range = v341, v344.is_national = false, v344.remove_plus = false;
    const v345 = JSON.stringify(v344),
      v346 = {
        'hostname': "api.zenexnetwork.com",
        'port': 0x1bb,
        'path': "/v1/getnum",
        'method': "POST",
        'headers': {
          'mapikey': v340,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v345)
        }
      };
    const v347 = https.request(v346, v348 => {
      let v349 = '';
      v348.on("data", v350 => v349 += v350), v348.on("end", () => {
        try {
          const v351 = JSON.parse(v349);
          if (v351?.['meta']?.["code"] === 0xc8 && v351?.['data']?.["full_number"]) v342(v351.data.full_number.replace(/[^0-9]/g, ''));else v343(new Error(v351?.["message"] || "Zenex: no number"));
        } catch (v352) {
          v343(new Error("Zenex: invalid JSON"));
        }
      });
    });
    v347.on("error", v353 => v343(new Error("Zenex net: " + v353.message))), v347.setTimeout(0x3a98, () => {
      v347.destroy();
      v343(new Error('Zenex\x20timeout'));
    }), v347.write(v345), v347.end();
  });
}
function zenexPollOtp(v354, v355, v356 = 0x927c0) {
  return new Promise(v357 => {
    const v358 = String(v355).replace(/[^0-9]/g, ''),
      v359 = Date.now() + v356,
      v360 = new Set(),
      fn4 = () => {
        const v361 = {};
        v361.mapikey = v354;
        const v362 = {};
        v362.hostname = "api.zenexnetwork.com";
        v362.port = 0x1bb, v362.path = "/v1/numsuccess/info", v362.method = "GET", v362.headers = v361;
        const v363 = v362,
          v364 = https.request(v363, v365 => {
            let v366 = '';
            v365.on("data", v367 => v366 += v367);
            v365.on("end", () => {
              try {
                const v368 = JSON.parse(v366),
                  v369 = Array.isArray(v368?.["data"]?.['otps']) ? v368.data.otps : Array.isArray(v368?.["data"]) ? v368.data : [];
                for (const v370 of v369) {
                  const v371 = String(v370.number || v370.copy || '').replace(/[^0-9]/g, '');
                  if (!v371) continue;
                  const v372 = v371.length >= 0x6 && v358.length >= 0x6 ? v371.slice(-8) === v358.slice(-8) || v371.endsWith(v358) || v358.endsWith(v371) : false;
                  if (v372) {
                    const v373 = v370.nid || v371 + '_' + (v370.otp || '');
                    if (!v360.has(v373)) {
                      const v374 = String(v370.otp || '').match(/\b(\d{4,8})\b/);
                      if (v374) {
                        v357(v374[0x1]);
                        return;
                      }
                    }
                  }
                }
              } catch (v375) {}
              if (Date.now() < v359) setTimeout(fn4, 0xfa0);else v357(null);
            });
          });
        v364.on('error', () => {
          if (Date.now() < v359) setTimeout(fn4, 0xfa0);else v357(null);
        }), v364.end();
      };
    fn4();
  });
}
function parseOutlookFile(v376) {
  if (!fs.existsSync(v376)) return [];
  const v377 = fs.readFileSync(v376, "utf8").split(/\r?\n/).map(v379 => v379.trim()).filter(v380 => v380.length > 0x5);
  const v378 = [];
  for (const v381 of v377) {
    const v382 = v381.includes('|') ? v381.split('|') : v381.split(':');
    if (v382.length >= 0x3) {
      const v383 = v382[0x0].trim(),
        v384 = v382[0x1].trim(),
        v385 = v382[0x2].trim(),
        v386 = v382[0x3] ? v382[0x3].trim() : "9e5f94bc-e8a4-4e73-b8be-63364c29d753";
      if (v383.includes('@') && v385.length > 0xa) {
        const v387 = {};
        v387.email = v383, v387.pass = v384, v387.refreshToken = v385, v387.clientId = v386, v387.rawLine = v381, v378.push(v387);
      }
    }
  }
  return v378;
}
function fetchOutlookOtp({
  email: v388,
  pass: v389,
  refreshToken: v390,
  clientId = '9e5f94bc-e8a4-4e73-b8be-63364c29d753',
  timeoutMs = 0xea60,
  excludeCodes = []
}) {
  return new Promise(v391 => {
    const v392 = Date.now() + timeoutMs,
      v393 = {};
    v393.email = v388, v393.pass = v389;
    v393.refresh_token = v390, v393.client_id = clientId;
    const v394 = JSON.stringify(v393),
      fn5 = v395 => {
        if (!v395 || !excludeCodes || excludeCodes.length === 0x0) return false;
        return excludeCodes.map(String).some(v396 => String(v396).trim() === String(v395).trim());
      };
    debugLog(v388, "outlook-otp-start", {
      'deadline': new Date(v392).toISOString(),
      'excludeCodes': excludeCodes
    });
    const fn6 = () => {
      const v397 = {
          'hostname': "tools.dongvanfb.net",
          'port': 0x1bb,
          'path': '/api/get_messages_oauth2',
          'method': "POST",
          'headers': {
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v394),
            'Origin': 'https://dongvanfb.net',
            'Referer': "https://dongvanfb.net/"
          }
        },
        v398 = https.request(v397, v399 => {
          let v400 = '';
          v399.on("data", v401 => v400 += v401), v399.on('end', () => {
            try {
              const v402 = JSON.parse(v400),
                v403 = {};
              v403.status = v402.status, v403.topCode = v402.code, v403.msgCount = (v402.messages || []).length, debugLog(v388, 'outlook-poll-response', v403);
              if (v402.status) {
                if (v402.code && /^\d{5,8}$/.test(String(v402.code).trim()) && !fn5(v402.code)) return debugLog(v388, "outlook-otp-found-direct", v402.code), v391(String(v402.code).trim());
                const v404 = Array.isArray(v402.messages) ? v402.messages : [];
                for (const v405 of v404) {
                  const v406 = (v405.from || '').toLowerCase(),
                    v407 = v405.subject || '',
                    v408 = v405.message || '',
                    v409 = v405.code ? String(v405.code).trim() : '';
                  if (v409 && /^\d{5,8}$/.test(v409) && !fn5(v409)) return debugLog(v388, "outlook-otp-found-msg-code", v409), v391(v409);
                  const v410 = (v406 + '\x20' + v407 + '\x20' + v408).toLowerCase();
                  if (v410.includes("facebook") || v410.includes("meta") || v410.includes("fb-") || v410.includes("confirmemail")) {
                    const v411 = v407.match(/FB-(\d{5,8})/i) || v407.match(/(?:[?&]c=|[?&]code=)(\d{5,8})/i) || v407.match(/(?:code|código|kod|pin|is|to|kodas|hasło)\D{1,15}(\d{5,8})/i) || v407.match(/\b(\d{5,8})\b/);
                    if (v411 && !fn5(v411[0x1])) return debugLog(v388, "outlook-otp-found-subj", v411[0x1]), v391(v411[0x1]);
                    const v412 = v408.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '\x20').replace(/<[^>]+>/g, '\x20'),
                      v413 = v412.match(/FB-(\d{5,8})/i) || v412.match(/(?:[?&]c=|[?&]code=)(\d{5,8})/i) || v412.match(/(?:code|código|kod|pin|is|to|kodas|hasło)\D{1,15}(\d{5,8})/i) || v412.match(/\b(\d{5,8})\b/);
                    if (v413 && !fn5(v413[0x1])) return debugLog(v388, 'outlook-otp-found-body', v413[0x1]), v391(v413[0x1]);
                  }
                }
              }
            } catch (v414) {
              debugLog(v388, "outlook-poll-parse-err", v414.message);
            }
            Date.now() < v392 ? setTimeout(fn6, 0x9c4) : (debugLog(v388, "outlook-otp-timeout", "Deadline reached (" + timeoutMs / 0x3e8 + 's)'), v391(null));
          });
        });
      v398.on("error", v415 => {
        debugLog(v388, "outlook-poll-net-err", v415.message);
        if (Date.now() < v392) setTimeout(fn6, 0x9c4);else v391(null);
      });
      v398.setTimeout(0x2710, () => {
        v398.destroy();
        if (Date.now() < v392) setTimeout(fn6, 0x9c4);else v391(null);
      }), v398.write(v394), v398.end();
    };
    fn6();
  });
}
const MAILSINK_KEY_FILE = path.join(__dirname, "mailsink_key.txt"),
  MAILCX_KEY_FILE = path.join(__dirname, 'mailcx_key.txt');
function mailsinkCreateInbox(v416) {
  return new Promise((v417, v418) => {
    if (!v416 || v416.trim().length === 0x0) return v418(new Error("Mailsink: API key is empty. Please enter your Mailsink API key in mailsink_key.txt or the prompt."));
    const v419 = https.request({
      'hostname': "api.mailsink.dev",
      'port': 0x1bb,
      'path': "/v1/inboxes",
      'method': "POST",
      'headers': {
        'Authorization': "Bearer " + v416.trim(),
        'Content-Type': "application/json",
        'Content-Length': Buffer.byteLength('{}'),
        'Accept': "application/json",
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
      }
    }, v420 => {
      let v421 = '';
      v420.on("data", v422 => v421 += v422);
      v420.on("end", () => {
        try {
          const v423 = JSON.parse(v421);
          if (v423.address && v423.id) v417(v423);else {
            const v424 = v423.message || v423.error || (v423.errors ? JSON.stringify(v423.errors) : '') || "HTTP " + v420.statusCode + ':\x20' + v421.substring(0x0, 0x96);
            v418(new Error("Mailsink: " + v424));
          }
        } catch (v425) {
          v418(new Error("Mailsink (HTTP " + v420.statusCode + '):\x20' + (v421.substring(0x0, 0x96) || "invalid response")));
        }
      });
    });
    v419.on("error", v426 => v418(new Error("Mailsink network: " + v426.message))), v419.setTimeout(0x2ee0, () => {
      v419.destroy(), v418(new Error("Mailsink timeout"));
    }), v419.write('{}');
    v419.end();
  });
}
function mailsinkPollOtp(v427, v428, v429 = 0xea60) {
  return new Promise(v430 => {
    const v431 = Date.now() + v429,
      fn7 = () => {
        const v432 = https.request({
          'hostname': "api.mailsink.dev",
          'port': 0x1bb,
          'path': "/v1/inboxes/" + encodeURIComponent(v428) + '/latest-code',
          'method': "GET",
          'headers': {
            'Authorization': "Bearer " + v427.trim(),
            'Accept': "application/json",
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
          }
        }, v433 => {
          let v434 = '';
          v433.on("data", v435 => v434 += v435);
          v433.on('end', () => {
            try {
              const v436 = JSON.parse(v434);
              if (v436.code && /^\d{5,8}$/.test(String(v436.code).trim())) return v430(String(v436.code).trim());
            } catch (v437) {}
            if (Date.now() < v431) setTimeout(fn7, 0x9c4);else v430(null);
          });
        });
        v432.on('error', () => {
          if (Date.now() < v431) setTimeout(fn7, 0x9c4);else v430(null);
        }), v432.setTimeout(0x2710, () => {
          v432.destroy();
          if (Date.now() < v431) setTimeout(fn7, 0x9c4);else v430(null);
        }), v432.end();
      };
    fn7();
  });
}
function temptfGetAccount(v438 = '') {
  return new Promise((v439, v440) => {
    const v441 = "dot=1&plus=1" + (v438 ? "&providers=" + encodeURIComponent(v438) : ''),
      v442 = {};
    v442.Accept = 'application/json', v442["User-Agent"] = 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/124.0.0.0\x20Safari/537.36';
    const v443 = {};
    v443.hostname = "temp.tf", v443.port = 0x1bb, v443.path = "/api/account?" + v441;
    v443.method = "GET", v443.headers = v442;
    const v444 = https.request(v443, v445 => {
      let v446 = '';
      v445.on("data", v447 => v446 += v447), v445.on("end", () => {
        try {
          const v448 = JSON.parse(v446);
          if (v448.email) v439(v448.email);else v440(new Error(v448.error || v448.message || "Temp.tf (HTTP " + v445.statusCode + "): no email returned"));
        } catch (v449) {
          v440(new Error("Temp.tf (HTTP " + v445.statusCode + "): invalid JSON"));
        }
      });
    });
    v444.on("error", v450 => v440(new Error("Temp.tf network: " + v450.message))), v444.setTimeout(0x2ee0, () => {
      v444.destroy(), v440(new Error("Temp.tf timeout"));
    }), v444.end();
  });
}
function temptfPollOtp(v451, v452 = 0x15f90) {
  return new Promise(v453 => {
    const v454 = Date.now() + v452,
      v455 = v451.trim(),
      v456 = {};
    v456.email = v455;
    const v457 = JSON.stringify(v456),
      fn8 = v458 => {
        if (!v458) return null;
        const v459 = String(v458);
        const v460 = v459.match(/FB-(\d{5,8})/i);
        if (v460) return v460[0x1];
        const v461 = v459.match(/(?:[?&]c=|[?&]code=)(\d{5,8})/i);
        if (v461) return v461[0x1];
        const v462 = v459.match(/(?:code|código|kod|pin|is|to|kodas|hasło)\D{1,15}(\d{5,8})/i);
        if (v462) return v462[0x1];
        const v463 = v459.match(/\b(\d{5,8})\b/);
        if (v463) return v463[0x1];
        return null;
      };
    const fn9 = () => {
      const v464 = https.request({
        'hostname': 'temp.tf',
        'port': 0x1bb,
        'path': "/api/check",
        'method': "POST",
        'headers': {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(v457),
          'Accept': "application/json",
          'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
      }, v465 => {
        let v466 = '';
        v465.on("data", v467 => v466 += v467), v465.on('end', () => {
          try {
            const v468 = JSON.parse(v466),
              v469 = Array.isArray(v468.data) ? v468.data : [];
            v469.length > 0x0 && debugLog(v455, "temptf-messages-received", {
              'count': v469.length,
              'subjects': v469.map(v470 => v470.subject)
            });
            for (const v471 of v469) {
              const v472 = v471.subject || '',
                v473 = v471.body || '',
                v474 = fn8(v472);
              if (v474) return v453(v474);
              const v475 = v473.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '\x20').replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '\x20'),
                v476 = fn8(v475);
              if (v476) return v453(v476);
            }
          } catch (v477) {}
          if (Date.now() < v454) setTimeout(fn9, 0xbb8);else v453(null);
        });
      });
      v464.on("error", () => {
        if (Date.now() < v454) setTimeout(fn9, 0xbb8);else v453(null);
      });
      v464.setTimeout(0x2ee0, () => {
        v464.destroy();
        if (Date.now() < v454) setTimeout(fn9, 0xbb8);else v453(null);
      }), v464.write(v457), v464.end();
    };
    fn9();
  });
}
let _mailtmDomainsCache = [],
  _mailtmActiveHost = "api.mail.tm";
async function mailtmGetDomains() {
  if (_mailtmDomainsCache.length > 0x0) return _mailtmDomainsCache;
  const v478 = ["api.mail.tm", "api.mailgw.net"];
  for (const v480 of v478) {
    try {
      const v481 = await new Promise((v482, v483) => {
        const v484 = https.request({
          'hostname': v480,
          'port': 0x1bb,
          'path': "/domains",
          'method': "GET",
          'headers': {
            'Accept': "application/ld+json, application/json",
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            'Origin': "https://" + v480.replace('api.', ''),
            'Referer': "https://" + v480.replace("api.", '') + '/'
          }
        }, v485 => {
          let v486 = '';
          v485.on("data", v487 => v486 += v487), v485.on("end", () => {
            try {
              const v488 = JSON.parse(v486),
                v489 = (v488["hydra:member"] || []).filter(v490 => v490.isActive !== false).map(v491 => v491.domain);
              v489 && v489.length > 0x0 ? (_mailtmActiveHost = v480, v482(v489)) : v483(new Error("No active domains"));
            } catch (v492) {
              v483(v492);
            }
          });
        });
        v484.on("error", v483), v484.setTimeout(0x1f40, () => {
          v484.destroy(), v483(new Error("Domain timeout"));
        });
        v484.end();
      });
      if (v481 && v481.length > 0x0) return _mailtmDomainsCache = v481, v481;
    } catch (v493) {}
  }
  const v479 = ["vwh.me", "mepost.net", "somelora.com", "bugfoo.com", "bupkes.org", 'txcct.com', "mohmal.im", 'roobie.com', "cxnxs.com"];
  return _mailtmDomainsCache = v479, v479;
}
function mailtmCreateAccount(v494) {
  return new Promise(async (v495, v496) => {
    const v497 = _mailtmActiveHost || "api.mail.tm";
    try {
      const v498 = "fb_" + crypto.randomBytes(0x4).toString('hex') + Date.now().toString(0x24).slice(-3),
        v499 = v498 + '@' + v494,
        v500 = "Pwd" + crypto.randomBytes(0x4).toString("hex") + "!9A",
        v501 = {};
      v501.address = v499, v501.password = v500;
      const v502 = JSON.stringify(v501);
      await new Promise((v507, v508) => {
        const v509 = https.request({
          'hostname': v497,
          'port': 0x1bb,
          'path': "/accounts",
          'method': "POST",
          'headers': {
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v502),
            'Accept': "application/json",
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
          }
        }, v510 => {
          let v511 = '';
          v510.on("data", v512 => v511 += v512), v510.on('end', () => {
            try {
              const v513 = JSON.parse(v511);
              if (v513.address || v510.statusCode === 0xc9 || v510.statusCode === 0xc8) v507(v513);else v508(new Error(v513.message || v513.error || "HTTP " + v510.statusCode + ':\x20' + v511.substring(0x0, 0x64)));
            } catch (v514) {
              v508(v514);
            }
          });
        });
        v509.on("error", v508);
        v509.setTimeout(0x2710, () => {
          v509.destroy();
          v508(new Error("Timeout creating account"));
        }), v509.write(v502), v509.end();
      });
      const v503 = {};
      v503.address = v499, v503.password = v500;
      const v504 = JSON.stringify(v503),
        v505 = await new Promise((v515, v516) => {
          const v517 = https.request({
            'hostname': v497,
            'port': 0x1bb,
            'path': "/token",
            'method': 'POST',
            'headers': {
              'Content-Type': "application/json",
              'Content-Length': Buffer.byteLength(v504),
              'Accept': "application/json",
              'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
            }
          }, v518 => {
            let v519 = '';
            v518.on('data', v520 => v519 += v520);
            v518.on("end", () => {
              try {
                const v521 = JSON.parse(v519);
                if (v521.token) v515(v521.token);else v516(new Error(v521.message || v521.error || "No token returned"));
              } catch (v522) {
                v516(v522);
              }
            });
          });
          v517.on("error", v516), v517.setTimeout(0x2710, () => {
            v517.destroy(), v516(new Error("Timeout getting token"));
          });
          v517.write(v504), v517.end();
        }),
        v506 = {};
      v506.address = v499, v506.password = v500, v506.token = v505, v506.host = v497, v495(v506);
    } catch (v523) {
      v496(v523);
    }
  });
}
function mailtmPollOtp(v524, v525 = 0x15f90, v526 = "api.mail.tm") {
  const v527 = v526 || _mailtmActiveHost || "api.mail.tm";
  return new Promise(v528 => {
    const v529 = Date.now() + v525;
    const fn10 = v530 => {
        if (!v530) return null;
        const v531 = String(v530),
          v532 = v531.match(/FB-(\d{5,8})/i);
        if (v532) return v532[0x1];
        const v533 = v531.match(/(?:[?&]c=|[?&]code=)(\d{5,8})/i);
        if (v533) return v533[0x1];
        const v534 = v531.match(/(?:code|código|kod|pin|is|to|kodas|hasło)\D{1,15}(\d{5,8})/i);
        if (v534) return v534[0x1];
        const v535 = v531.match(/\b(\d{5,8})\b/);
        if (v535) return v535[0x1];
        return null;
      },
      fn11 = () => {
        const v536 = https.request({
          'hostname': v527,
          'port': 0x1bb,
          'path': "/messages",
          'method': "GET",
          'headers': {
            'Authorization': "Bearer " + v524.trim(),
            'Accept': "application/json",
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
          }
        }, v537 => {
          let v538 = '';
          v537.on("data", v539 => v538 += v539), v537.on("end", async () => {
            try {
              const v540 = JSON.parse(v538),
                v541 = Array.isArray(v540["hydra:member"]) ? v540["hydra:member"] : [];
              v541.length > 0x0 && debugLog("mailtm", "messages-received", {
                'count': v541.length,
                'subjects': v541.map(v542 => v542.subject)
              });
              for (const v543 of v541) {
                const v544 = v543.subject || '',
                  v545 = v543.intro || '',
                  v546 = fn10(v544);
                if (v546) return v528(v546);
                const v547 = fn10(v545);
                if (v547) return v528(v547);
                if (v543.id) try {
                  const v548 = await new Promise(v549 => {
                    const v550 = https.request({
                      'hostname': v527,
                      'port': 0x1bb,
                      'path': '/messages/' + encodeURIComponent(v543.id),
                      'method': 'GET',
                      'headers': {
                        'Authorization': "Bearer " + v524.trim(),
                        'Accept': "application/json",
                        'User-Agent': 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)'
                      }
                    }, v551 => {
                      let v552 = '';
                      v551.on("data", v553 => v552 += v553);
                      v551.on("end", () => {
                        try {
                          v549(JSON.parse(v552));
                        } catch (v554) {
                          v549(null);
                        }
                      });
                    });
                    v550.on("error", () => v549(null)), v550.setTimeout(0x1f40, () => {
                      v550.destroy(), v549(null);
                    }), v550.end();
                  });
                  if (v548) {
                    const v555 = (v548.text || '') + '\x20' + (Array.isArray(v548.html) ? v548.html.join('\x20') : v548.html || ''),
                      v556 = fn10(v555);
                    if (v556) return v528(v556);
                  }
                } catch (v557) {}
              }
            } catch (v558) {}
            if (Date.now() < v529) setTimeout(fn11, 0xbb8);else v528(null);
          });
        });
        v536.on("error", () => {
          if (Date.now() < v529) setTimeout(fn11, 0xbb8);else v528(null);
        });
        v536.setTimeout(0x2ee0, () => {
          v536.destroy();
          if (Date.now() < v529) setTimeout(fn11, 0xbb8);else v528(null);
        }), v536.end();
      };
    fn11();
  });
}
let _mailcxDomainsCache = [];
async function mailcxGetDomains(v559 = '') {
  if (_mailcxDomainsCache.length > 0x0) return _mailcxDomainsCache;
  const fn12 = v560 => {
    if (!v560) return [];
    let v561 = [];
    if (Array.isArray(v560)) v561 = v560;else {
      if (typeof v560 === "object") {
        if (Array.isArray(v560.domains)) v561 = v560.domains;else {
          if (Array.isArray(v560.system_domains)) v561 = v560.system_domains;else {
            if (Array.isArray(v560.allowed_domains)) v561 = v560.allowed_domains;else {
              if (Array.isArray(v560.data)) v561 = v560.data;else {
                if (Array.isArray(v560.results)) v561 = v560.results;
              }
            }
          }
        }
      }
    }
    const v562 = [];
    for (const v563 of v561) {
      if (typeof v563 === "string" && v563.includes('.')) v562.push(v563.trim());else {
        if (v563 && typeof v563 === "object") {
          const v564 = v563.domain || v563.name || v563.host || v563.domain_name || v563.address;
          if (typeof v564 === 'string' && v564.includes('.')) v562.push(v564.trim());
        }
      }
    }
    return [...new Set(v562)];
  };
  try {
    const v565 = await new Promise((v566, v567) => {
      const v568 = {};
      v568.Accept = 'application/json', v568['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36";
      const v569 = {};
      v569.hostname = "api.mail.cx", v569.port = 0x1bb;
      v569.path = "/v1/config", v569.method = "GET", v569.headers = v568;
      const v570 = https.request(v569, v571 => {
        let v572 = '';
        v571.on("data", v573 => v572 += v573);
        v571.on("end", () => {
          try {
            const v574 = JSON.parse(v572),
              v575 = fn12(v574);
            if (v575.length > 0x0) v566(v575);else v567(new Error("No domains in config"));
          } catch (v576) {
            v567(v576);
          }
        });
      });
      v570.on("error", v567), v570.setTimeout(0x1f40, () => {
        v570.destroy();
        v567(new Error("Timeout"));
      }), v570.end();
    });
    if (v565 && v565.length > 0x0) return _mailcxDomainsCache = v565, v565;
  } catch (v577) {}
  if (v559 && v559.trim().length > 0x0) try {
    const v578 = await new Promise((v579, v580) => {
      const v581 = https.request({
        'hostname': 'api.mail.cx',
        'port': 0x1bb,
        'path': '/v1/domains',
        'method': "GET",
        'headers': {
          'x-api-token': v559.trim(),
          'Accept': "application/json",
          'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
      }, v582 => {
        let v583 = '';
        v582.on("data", v584 => v583 += v584), v582.on("end", () => {
          try {
            const v585 = JSON.parse(v583),
              v586 = fn12(v585);
            if (v586.length > 0x0) v579(v586);else v580(new Error("No custom domains"));
          } catch (v587) {
            v580(v587);
          }
        });
      });
      v581.on("error", v580);
      v581.setTimeout(0x1f40, () => {
        v581.destroy();
        v580(new Error("Timeout"));
      });
      v581.end();
    });
    if (v578 && v578.length > 0x0) return _mailcxDomainsCache = v578, v578;
  } catch (v588) {}
  return _mailcxDomainsCache = ["9k3r.com", "mail.cx"], _mailcxDomainsCache;
}
const _usedMailcxHandles = new Set();
function mailcxCreateAccount(v589 = "9k3r.com", v590 = 'US') {
  let v591 = '9k3r.com';
  if (typeof v589 === 'string' && v589.includes('.')) v591 = v589.trim();else v589 && typeof v589 === "object" && (v591 = v589.domain || v589.name || v589.host || "9k3r.com");
  let v592 = v590 || 'US';
  if (v592 === "RANDOM" || v592 === "GLOBAL") {
    const v597 = ['US', 'GB', 'ES', 'MX', 'FR', 'DE', 'IT', 'BR', 'SA', 'ID', 'VN', 'IN'];
    v592 = v597[Math.floor(Math.random() * v597.length)];
  }
  let v593 = 0x0;
  while (v593 < 0x32) {
    v593++;
    const v598 = generateRandomName(v592),
      v599 = (v598.first || "alex").normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, ''),
      v600 = (v598.last || 'miller').normalize("NFD").replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, ''),
      v601 = ['.', '_', ''],
      v602 = v601[Math.floor(Math.random() * v601.length)],
      v603 = Math.floor(Math.random() * 0x15f90) + 0x3e8,
      v604 = '' + v599 + v602 + v600 + v603,
      v605 = v604 + '@' + v591;
    if (!_usedMailcxHandles.has(v605)) {
      _usedMailcxHandles.add(v605);
      const v606 = {};
      return v606.email = v605, v606.domain = v591, v606.isMailcx = true, v606.firstName = v598.first, v606.lastName = v598.last, v606;
    }
  }
  const v594 = 'user.' + crypto.randomBytes(0x3).toString("hex") + (Math.floor(Math.random() * 0x2328) + 0x3e8),
    v595 = v594 + '@' + v591;
  _usedMailcxHandles.add(v595);
  const v596 = {};
  return v596.email = v595, v596.domain = v591, v596.isMailcx = true, v596;
}
function mailcxPollOtp(v607, v608, v609 = 0x15f90) {
  return new Promise(v610 => {
    const v611 = Date.now() + v609,
      v612 = v608.trim();
    const fn13 = v614 => {
      if (!v614) return null;
      const v615 = String(v614),
        v616 = v615.match(/FB-(\d{5,8})/i);
      if (v616) return v616[0x1];
      const v617 = v615.match(/(?:[?&]c=|[?&]code=)(\d{5,8})/i);
      if (v617) return v617[0x1];
      const v618 = v615.match(/(?:code|código|kod|pin|is|to|kodas|hasło)\D{1,15}(\d{5,8})/i);
      if (v618) return v618[0x1];
      const v619 = v615.match(/\b(\d{5,8})\b/);
      if (v619) return v619[0x1];
      return null;
    };
    const fn14 = v620 => {
      return new Promise(v621 => {
        const v622 = https.request({
          'hostname': "api.mail.cx",
          'port': 0x1bb,
          'path': "/v1/email/" + encodeURIComponent(v620),
          'method': "GET",
          'headers': {
            ...(v607 && {
              'x-api-token': v607.trim()
            }),
            'Accept': 'application/json',
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
          }
        }, v623 => {
          let v624 = '';
          v623.on("data", v625 => v624 += v625);
          v623.on('end', () => {
            try {
              const v626 = JSON.parse(v624),
                v627 = v626?.["text"] || v626?.["html"] || v626?.["body"] || v624;
              v621(v627);
            } catch (v628) {
              v621(v624);
            }
          });
        });
        v622.on("error", () => v621('')), v622.setTimeout(0x1f40, () => {
          v622.destroy(), v621('');
        });
        v622.end();
      });
    };
    let v613 = '';
    const fn15 = () => {
      const v629 = "/v1/inbox/" + encodeURIComponent(v612) + (v613 ? '?since=' + encodeURIComponent(v613) : ''),
        v630 = https.request({
          'hostname': "api.mail.cx",
          'port': 0x1bb,
          'path': v629,
          'method': "GET",
          'headers': {
            ...(v607 && {
              'x-api-token': v607.trim()
            }),
            'Accept': "application/json",
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
          }
        }, v631 => {
          let v632 = '';
          v631.on("data", v633 => v632 += v633);
          v631.on("end", async () => {
            if (v631.statusCode === 0xc8) try {
              const v634 = JSON.parse(v632);
              if (v634?.['next_since']) v613 = v634.next_since;
              const v635 = Array.isArray(v634?.['emails']) ? v634.emails : Array.isArray(v634) ? v634 : [];
              for (const v636 of v635) {
                const v637 = fn13(v636.subject || '');
                if (v637) return v610(v637);
                const v638 = fn13(v636.preview_text || v636.preview || '');
                if (v638) return v610(v638);
                if (v636.id) {
                  const v639 = await fn14(v636.id),
                    v640 = fn13(v639);
                  if (v640) return v610(v640);
                }
              }
            } catch (v641) {}
            Date.now() < v611 ? setTimeout(fn15, 0x3e8) : v610(null);
          });
        });
      v630.on("error", () => {
        if (Date.now() < v611) setTimeout(fn15, 0x9c4);else v610(null);
      });
      v630.setTimeout(0x7530, () => {
        v630.destroy();
        if (Date.now() < v611) setTimeout(fn15, 0x3e8);else v610(null);
      }), v630.end();
    };
    fn15();
  });
}
class NexaRateLimiter {
  constructor(v642) {
    this.delayMs = v642, this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v643) {
    return new Promise((v644, v645) => {
      this.queue.push(async () => {
        try {
          v644(await v643());
        } catch (v646) {
          v645(v646);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0x0) {
      const v647 = this.queue.shift();
      await v647(), await new Promise(v648 => setTimeout(v648, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(0x1f4),
  twoOoLimiter = new NexaRateLimiter(0x1f4);
function twoOoPollOtp(v649, v650, v651, v652, v653 = 0x1f40) {
  return new Promise(v654 => {
    const v655 = String(v651).replace(/[^0-9]/g, ''),
      v656 = Date.now() + v653,
      fn16 = () => {
        const v657 = {};
        v657.mauthapi = v649, v657.Accept = "application/json";
        const v658 = {};
        v658.hostname = "api.2oo9.cloud", v658.port = 0x1bb;
        v658.path = v650, v658.method = "GET", v658.headers = v657;
        const v659 = v658,
          v660 = require("https").request(v659, v661 => {
            let v662 = '';
            v661.on("data", v663 => v662 += v663), v661.on('end', () => {
              try {
                const v664 = JSON.parse(v662),
                  v665 = v664?.["data"]?.["otps"] || [];
                for (const v666 of v665) {
                  const v667 = String(v666.number || '').replace(/[^0-9]/g, '');
                  if (v667.endsWith(v655) || v655.endsWith(v667)) {
                    if (!v652 || v666.time && v666.time >= v652 - 0x1388) {
                      const v668 = String(v666.message || '').match(/\b(\d{4,8})\b/);
                      if (v668) {
                        v654(v668[0x1]);
                        return;
                      }
                    }
                  }
                }
              } catch (v669) {}
              if (Date.now() < v656) setTimeout(fn16, 0x3e8);else v654(null);
            });
          });
        v660.on("error", () => {
          if (Date.now() < v656) setTimeout(fn16, 0x3e8);else v654(null);
        }), v660.end();
      };
    fn16();
  });
}
function nexaFetchNumber(v670, v671, v672) {
  return new Promise((v673, v674) => {
    const v675 = {};
    v675.range = v671, v675.format = "normal";
    const v676 = JSON.stringify(v675),
      v677 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v672 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v670,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v676)
        }
      };
    const v678 = require("http").request(v677, v679 => {
      let v680 = '';
      v679.on("data", v681 => v680 += v681);
      v679.on("end", () => {
        try {
          const v682 = JSON.parse(v680);
          if (v682.success && v682.number) v673(v682.number.replace(/[^0-9]/g, ''));else v674(new Error(v682.error || "NexaOTP: No number returned"));
        } catch (v683) {
          v674(new Error("NexaOTP: Invalid response"));
        }
      });
    });
    v678.on("error", v684 => v674(new Error("NexaOTP network: " + v684.message))), v678.setTimeout(0x2710, () => {
      v678.destroy();
      v674(new Error("NexaOTP: Timeout"));
    }), v678.write(v676), v678.end();
  });
}
function stripRid(v685) {
  return v685.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v686, v687, v688) {
  return new Promise((v689, v690) => {
    const v691 = stripRid(v687);
    const v692 = {};
    v692.rid = v691;
    const v693 = JSON.stringify(v692),
      v694 = {
        'hostname': "api.2oo9.cloud",
        'port': 0x1bb,
        'path': v688,
        'method': "POST",
        'headers': {
          'mauthapi': v686,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(v693)
        }
      };
    const v695 = https.request(v694, v696 => {
      let v697 = '';
      v696.on("data", v698 => v697 += v698);
      v696.on('end', () => {
        try {
          const v699 = JSON.parse(v697);
          if (v699?.["meta"]?.["code"] === 0xc8 && v699?.["data"]?.["no_plus_number"]) v689(v699.data.no_plus_number);else v690(new Error(v699?.["message"] || v699?.["meta"]?.['status'] || "2oo9: No number"));
        } catch (v700) {
          v690(new Error('2oo9:\x20Invalid\x20JSON'));
        }
      });
    });
    v695.on("error", v701 => v690(new Error('2oo9\x20network:\x20' + v701.message))), v695.setTimeout(0x2710, () => {
      v695.destroy(), v690(new Error("2oo9: Timeout"));
    }), v695.write(v693), v695.end();
  });
}
function twoOoFetchConsole(v702, v703) {
  return new Promise((v704, v705) => {
    const v706 = {};
    v706.mauthapi = v702;
    const v707 = {};
    v707.hostname = "api.2oo9.cloud", v707.port = 0x1bb, v707.path = v703, v707.method = "GET", v707.headers = v706;
    const v708 = v707,
      v709 = https.request(v708, v710 => {
        let v711 = '';
        v710.on("data", v712 => v711 += v712), v710.on("end", () => {
          try {
            const v713 = JSON.parse(v711);
            if (v713?.["meta"]?.["code"] === 0xc8 && Array.isArray(v713?.["data"]?.["hits"])) v704(v713.data.hits);else v705(new Error(v713?.["message"] || "Console fetch failed"));
          } catch (v714) {
            v705(new Error("Console: Invalid JSON"));
          }
        });
      });
    v709.on("error", v715 => v705(new Error("Console network: " + v715.message)));
    v709.setTimeout(0x2710, () => {
      v709.destroy(), v705(new Error("Console timeout"));
    }), v709.end();
  });
}
const DIAL_MAP = [["1868", 'TT', "en-TT,en;q=0.9"], ["1876", 'JM', "en-JM,en;q=0.9"], ["1809", 'DO', 'es-DO,es;q=0.9,en;q=0.8'], ["1829", 'DO', 'es-DO,es;q=0.9,en;q=0.8'], ["1849", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["880", 'BD', "bn-BD,bn;q=0.9,en;q=0.8"], ["855", 'KH', "km-KH,km;q=0.9,en;q=0.8"], ["856", 'LA', 'lo-LA,lo;q=0.9,en;q=0.8'], ["228", 'TG', "fr-TG,fr;q=0.9,en;q=0.8"], ['229', 'BJ', "fr-BJ,fr;q=0.9,en;q=0.8"], ["233", 'GH', "en-GH,en;q=0.9"], ['234', 'NG', 'en-NG,en;q=0.9'], ['237', 'CM', 'fr-CM,fr;q=0.9,en;q=0.8'], ["243", 'CD', "fr-CD,fr;q=0.9"], ["254", 'KE', "sw-KE,sw;q=0.9,en;q=0.8"], ["255", 'TZ', "sw-TZ,sw;q=0.9,en;q=0.8"], ["256", 'UG', 'en-UG,en;q=0.9'], ["260", 'ZM', "en-ZM,en;q=0.9"], ["263", 'ZW', "en-ZW,en;q=0.9"], ["212", 'MA', "ar-MA,ar;q=0.9,fr;q=0.8"], ["213", 'DZ', "ar-DZ,ar;q=0.9,fr;q=0.8"], ["216", 'TN', "ar-TN,ar;q=0.9,fr;q=0.8"], ["218", 'LY', 'ar-LY,ar;q=0.9,en;q=0.8'], ["220", 'GM', "en-GM,en;q=0.9"], ['221', 'SN', "fr-SN,fr;q=0.9"], ["222", 'MR', "ar-MR,ar;q=0.9,fr;q=0.8"], ["223", 'ML', 'fr-ML,fr;q=0.9'], ["224", 'GN', "fr-GN,fr;q=0.9"], ["225", 'CI', "fr-CI,fr;q=0.9"], ["226", 'BF', "fr-BF,fr;q=0.9"], ["227", 'NE', "fr-NE,fr;q=0.9"], ['230', 'MU', "en-MU,en;q=0.9,fr;q=0.8"], ['231', 'LR', "en-LR,en;q=0.9"], ["232", 'SL', "en-SL,en;q=0.9"], ["235", 'TD', "fr-TD,fr;q=0.9,ar;q=0.8"], ['236', 'CF', "fr-CF,fr;q=0.9"], ["238", 'CV', "pt-CV,pt;q=0.9"], ['239', 'ST', 'pt-ST,pt;q=0.9'], ['240', 'GQ', "es-GQ,es;q=0.9"], ['241', 'GA', "fr-GA,fr;q=0.9"], ["242", 'CG', "fr-CG,fr;q=0.9"], ["244", 'AO', "pt-AO,pt;q=0.9"], ["245", 'GW', "pt-GW,pt;q=0.9"], ["246", 'IO', "en-IO,en;q=0.9"], ["247", 'AC', "en-AC,en;q=0.9"], ["248", 'SC', "en-SC,en;q=0.9,fr;q=0.8"], ["249", 'SD', "ar-SD,ar;q=0.9,en;q=0.8"], ['250', 'RW', "rw-RW,rw;q=0.9,en;q=0.8,fr;q=0.7"], ["251", 'ET', "am-ET,am;q=0.9,en;q=0.8"], ["252", 'SO', "so-SO,so;q=0.9,ar;q=0.8,en;q=0.7"], ["253", 'DJ', 'fr-DJ,fr;q=0.9,ar;q=0.8'], ["257", 'BI', "fr-BI,fr;q=0.9,rn;q=0.8"], ["258", 'MZ', "pt-MZ,pt;q=0.9"], ["261", 'MG', "mg-MG,mg;q=0.9,fr;q=0.8"], ['262', 'RE', "fr-RE,fr;q=0.9"], ["264", 'NA', 'en-NA,en;q=0.9'], ["265", 'MW', "en-MW,en;q=0.9"], ["266", 'LS', "en-LS,en;q=0.9"], ['267', 'BW', "en-BW,en;q=0.9"], ["268", 'SZ', "en-SZ,en;q=0.9"], ["269", 'KM', "fr-KM,fr;q=0.9,ar;q=0.8"], ["966", 'SA', 'ar-SA,ar;q=0.9,en;q=0.8'], ["971", 'AE', "ar-AE,ar;q=0.9,en;q=0.8"], ["973", 'BH', "ar-BH,ar;q=0.9,en;q=0.8"], ["974", 'QA', "ar-QA,ar;q=0.9,en;q=0.8"], ["968", 'OM', "ar-OM,ar;q=0.9,en;q=0.8"], ["965", 'KW', 'ar-KW,ar;q=0.9,en;q=0.8'], ["964", 'IQ', "ar-IQ,ar;q=0.9,en;q=0.8"], ["963", 'SY', "ar-SY,ar;q=0.9,en;q=0.8"], ["962", 'JO', "ar-JO,ar;q=0.9,en;q=0.8"], ["961", 'LB', "ar-LB,ar;q=0.9,en;q=0.8,fr;q=0.7"], ["967", 'YE', "ar-YE,ar;q=0.9,en;q=0.8"], ["970", 'PS', 'ar-PS,ar;q=0.9,en;q=0.8'], ["972", 'IL', 'he-IL,he;q=0.9,en;q=0.8'], ["992", 'TJ', "tg-TJ,tg;q=0.9,ru;q=0.8"], ["993", 'TM', 'tk-TM,tk;q=0.9,ru;q=0.8'], ["994", 'AZ', "az-AZ,az;q=0.9,ru;q=0.8"], ["995", 'GE', 'ka-GE,ka;q=0.9,en;q=0.8'], ['996', 'KG', "ky-KG,ky;q=0.9,ru;q=0.8"], ['998', 'UZ', 'uz-UZ,uz;q=0.9,ru;q=0.8'], ['977', 'NP', "ne-NP,ne;q=0.9,en;q=0.8"], ["975", 'BT', "dz-BT,dz;q=0.9,en;q=0.8"], ["959", 'MM', 'my-MM,my;q=0.9,en;q=0.8'], ["670", 'TL', "pt-TL,pt;q=0.9,en;q=0.8"], ["673", 'BN', 'ms-BN,ms;q=0.9,en;q=0.8'], ["676", 'TO', 'en-TO,en;q=0.9'], ['677', 'SB', 'en-SB,en;q=0.9'], ["678", 'VU', "en-VU,en;q=0.9,fr;q=0.8"], ["679", 'FJ', "en-FJ,en;q=0.9"], ["680", 'PW', "en-PW,en;q=0.9"], ["591", 'BO', "es-BO,es;q=0.9,en;q=0.8"], ["592", 'GY', "en-GY,en;q=0.9"], ["593", 'EC', "es-EC,es;q=0.9,en;q=0.8"], ["594", 'GF', "fr-GF,fr;q=0.9"], ["595", 'PY', "es-PY,es;q=0.9,en;q=0.8"], ["596", 'MQ', "fr-MQ,fr;q=0.9"], ["597", 'SR', "nl-SR,nl;q=0.9,en;q=0.8"], ["598", 'UY', 'es-UY,es;q=0.9,en;q=0.8'], ["380", 'UA', "uk-UA,uk;q=0.9,ru;q=0.8,en;q=0.7"], ['381', 'RS', "sr-RS,sr;q=0.9,en;q=0.8"], ["382", 'ME', "sr-ME,sr;q=0.9,en;q=0.8"], ["383", 'XK', "sq-XK,sq;q=0.9,sr;q=0.8,en;q=0.7"], ["385", 'HR', "hr-HR,hr;q=0.9,en;q=0.8"], ["386", 'SI', 'sl-SI,sl;q=0.9,en;q=0.8'], ["387", 'BA', "bs-BA,bs;q=0.9,hr;q=0.8,sr;q=0.7,en;q=0.6"], ["389", 'MK', "mk-MK,mk;q=0.9,en;q=0.8"], ['370', 'LT', "lt-LT,lt;q=0.9,en;q=0.8"], ['371', 'LV', "lv-LV,lv;q=0.9,ru;q=0.8,en;q=0.7"], ["372", 'EE', "et-EE,et;q=0.9,en;q=0.8"], ["373", 'MD', 'ro-MD,ro;q=0.9,ru;q=0.8,en;q=0.7'], ["374", 'AM', "hy-AM,hy;q=0.9,ru;q=0.8,en;q=0.7"], ["375", 'BY', "be-BY,be;q=0.9,ru;q=0.8,en;q=0.7"], ["376", 'AD', "ca-AD,ca;q=0.9,es;q=0.8,fr;q=0.7"], ['377', 'MC', "fr-MC,fr;q=0.9,en;q=0.8"], ["378", 'SM', "it-SM,it;q=0.9,en;q=0.8"], ["350", 'GI', "en-GI,en;q=0.9,es;q=0.8"], ["351", 'PT', "pt-PT,pt;q=0.9,en;q=0.8"], ["352", 'LU', "lb-LU,lb;q=0.9,fr;q=0.8,de;q=0.7"], ['353', 'IE', 'en-IE,en;q=0.9'], ["354", 'IS', "is-IS,is;q=0.9,en;q=0.8"], ["355", 'AL', "sq-AL,sq;q=0.9,en;q=0.8"], ["356", 'MT', 'mt-MT,mt;q=0.9,en;q=0.8'], ["357", 'CY', "el-CY,el;q=0.9,en;q=0.8"], ["358", 'FI', "fi-FI,fi;q=0.9,sv;q=0.8,en;q=0.7"], ['359', 'BG', "bg-BG,bg;q=0.9,en;q=0.8"], ["420", 'CZ', "cs-CZ,cs;q=0.9,sk;q=0.8,en;q=0.7"], ["421", 'SK', "sk-SK,sk;q=0.9,cs;q=0.8,en;q=0.7"], ["423", 'LI', "de-LI,de;q=0.9,en;q=0.8"], ["850", 'KP', "ko-KP,ko;q=0.9"], ["852", 'HK', "zh-HK,zh;q=0.9,en;q=0.8"], ["853", 'MO', "zh-MO,zh;q=0.9,pt;q=0.8"], ['20', 'EG', "ar-EG,ar;q=0.9,en;q=0.8"], ['27', 'ZA', "en-ZA,en;q=0.9"], ['30', 'GR', "el-GR,el;q=0.9,en;q=0.8"], ['31', 'NL', "nl-NL,nl;q=0.9,en;q=0.8"], ['32', 'BE', "nl-BE,nl;q=0.9,fr;q=0.8,en;q=0.7"], ['33', 'FR', "fr-FR,fr;q=0.9,en;q=0.8"], ['34', 'ES', "es-ES,es;q=0.9,en;q=0.8"], ['36', 'HU', 'hu-HU,hu;q=0.9,en;q=0.8'], ['39', 'IT', "it-IT,it;q=0.9,en;q=0.8"], ['40', 'RO', "ro-RO,ro;q=0.9,en;q=0.8"], ['41', 'CH', "de-CH,de;q=0.9,fr;q=0.8,en;q=0.7"], ['43', 'AT', 'de-AT,de;q=0.9,en;q=0.8'], ['44', 'GB', "en-GB,en;q=0.9"], ['45', 'DK', "da-DK,da;q=0.9,en;q=0.8"], ['46', 'SE', "sv-SE,sv;q=0.9,en;q=0.8"], ['47', 'NO', "nb-NO,nb;q=0.9,en;q=0.8"], ['48', 'PL', "pl-PL,pl;q=0.9,en;q=0.8"], ['49', 'DE', "de-DE,de;q=0.9,en;q=0.8"], ['51', 'PE', "es-PE,es;q=0.9,en;q=0.8"], ['52', 'MX', 'es-MX,es;q=0.9,en;q=0.8'], ['53', 'CU', "es-CU,es;q=0.9"], ['54', 'AR', "es-AR,es;q=0.9,en;q=0.8"], ['55', 'BR', "pt-BR,pt;q=0.9,en;q=0.8"], ['56', 'CL', 'es-CL,es;q=0.9,en;q=0.8'], ['57', 'CO', "es-CO,es;q=0.9,en;q=0.8"], ['58', 'VE', "es-VE,es;q=0.9,en;q=0.8"], ['60', 'MY', 'ms-MY,ms;q=0.9,en;q=0.8'], ['61', 'AU', "en-AU,en;q=0.9"], ['62', 'ID', "id-ID,id;q=0.9,en;q=0.8"], ['63', 'PH', 'en-PH,en;q=0.9,fil;q=0.8'], ['64', 'NZ', "en-NZ,en;q=0.9"], ['65', 'SG', "en-SG,en;q=0.9,zh;q=0.8"], ['66', 'TH', "th-TH,th;q=0.9,en;q=0.8"], ['81', 'JP', 'ja-JP,ja;q=0.9,en;q=0.8'], ['82', 'KR', "ko-KR,ko;q=0.9,en;q=0.8"], ['84', 'VN', "vi-VN,vi;q=0.9,en;q=0.8"], ['86', 'CN', "zh-CN,zh;q=0.9,en;q=0.8"], ['90', 'TR', "tr-TR,tr;q=0.9,en;q=0.8"], ['91', 'IN', 'hi-IN,hi;q=0.9,en;q=0.8'], ['92', 'PK', "ur-PK,ur;q=0.9,en;q=0.8"], ['93', 'AF', "ps-AF,ps;q=0.9,en;q=0.8"], ['94', 'LK', 'si-LK,si;q=0.9,en;q=0.8'], ['95', 'MM', 'my-MM,my;q=0.9,en;q=0.8'], ['98', 'IR', "fa-IR,fa;q=0.9,en;q=0.8"], ['1', 'US', "en-US,en;q=0.9"], ['7', 'RU', "ru-RU,ru;q=0.9,en;q=0.8"]];
function getCountryFromPhone(v716) {
  const v717 = {};
  v717.iso = 'US', v717.lang = 'en-US,en;q=0.9';
  if (!v716) return v717;
  const v718 = v716.replace(/\D/g, '');
  for (const [v720, v721, v722] of DIAL_MAP) {
    if (v718.startsWith(v720)) {
      const v723 = {};
      return v723.iso = v721, v723.lang = v722, v723;
    }
  }
  const v719 = {};
  return v719.iso = 'US', v719.lang = "en-US,en;q=0.9", v719;
}
const v1 = {};
v1.iso = 'US', v1.lang = "en-US,en;q=0.9";
const v2 = {};
v2.iso = 'US', v2.lang = 'en-US,en;q=0.9';
const v3 = {};
v3.iso = 'GB', v3.lang = "en-GB,en;q=0.9";
const v4 = {};
v4.iso = 'GB', v4.lang = "en-GB,en;q=0.9";
const v5 = {};
v5.iso = 'CA', v5.lang = 'en-CA,en;q=0.9,fr-CA;q=0.8';
const v6 = {};
v6.iso = 'CA', v6.lang = "en-CA,en;q=0.9,fr-CA;q=0.8";
const v7 = {};
v7.iso = 'AU', v7.lang = "en-AU,en;q=0.9";
const v8 = {};
v8.iso = 'AU', v8.lang = "en-AU,en;q=0.9";
const v9 = {};
v9.iso = 'DE', v9.lang = 'de-DE,de;q=0.9,en;q=0.8';
const v10 = {};
v10.iso = 'DE', v10.lang = "de-DE,de;q=0.9,en;q=0.8";
const v11 = {};
v11.iso = 'FR', v11.lang = "fr-FR,fr;q=0.9,en;q=0.8";
const v12 = {};
v12.iso = 'FR', v12.lang = "fr-FR,fr;q=0.9,en;q=0.8";
const v13 = {};
v13.iso = 'IT', v13.lang = "it-IT,it;q=0.9,en;q=0.8";
const v14 = {};
v14.iso = 'IT', v14.lang = "it-IT,it;q=0.9,en;q=0.8";
const v15 = {};
v15.iso = 'ES', v15.lang = "es-ES,es;q=0.9,en;q=0.8";
const v16 = {};
v16.iso = 'ES', v16.lang = "es-ES,es;q=0.9,en;q=0.8";
const v17 = {};
v17.iso = 'NL', v17.lang = "nl-NL,nl;q=0.9,en;q=0.8";
const v18 = {};
v18.iso = 'NL', v18.lang = "nl-NL,nl;q=0.9,en;q=0.8";
const v19 = {};
v19.iso = 'BR', v19.lang = "pt-BR,pt;q=0.9,en;q=0.8";
const v20 = {};
v20.iso = 'BR', v20.lang = "pt-BR,pt;q=0.9,en;q=0.8";
const v21 = {};
v21.iso = 'ID', v21.lang = "id-ID,id;q=0.9,en;q=0.8";
const v22 = {};
v22.iso = 'ID', v22.lang = "id-ID,id;q=0.9,en;q=0.8";
const v23 = {};
v23.iso = 'TR', v23.lang = "tr-TR,tr;q=0.9,en;q=0.8";
const v24 = {};
v24.iso = 'TR', v24.lang = "tr-TR,tr;q=0.9,en;q=0.8";
const v25 = {};
v25.iso = 'TR', v25.lang = 'tr-TR,tr;q=0.9,en;q=0.8';
const v26 = {};
v26.iso = 'RU', v26.lang = "ru-RU,ru;q=0.9,en;q=0.8";
const v27 = {};
v27.iso = 'RU', v27.lang = 'ru-RU,ru;q=0.9,en;q=0.8';
const v28 = {};
v28.iso = 'IN', v28.lang = "hi-IN,hi;q=0.9,en;q=0.8";
const v29 = {};
v29.iso = 'IN', v29.lang = "hi-IN,hi;q=0.9,en;q=0.8";
const v30 = {};
v30.iso = 'PK', v30.lang = 'ur-PK,ur;q=0.9,en;q=0.8';
const v31 = {};
v31.iso = 'PK', v31.lang = "ur-PK,ur;q=0.9,en;q=0.8";
const v32 = {};
v32.iso = 'BD', v32.lang = 'bn-BD,bn;q=0.9,en;q=0.8';
const v33 = {};
v33.iso = 'BD', v33.lang = "bn-BD,bn;q=0.9,en;q=0.8";
const v34 = {};
v34.iso = 'VN', v34.lang = "vi-VN,vi;q=0.9,en;q=0.8";
const v35 = {};
v35.iso = 'VN', v35.lang = "vi-VN,vi;q=0.9,en;q=0.8";
const v36 = {};
v36.iso = 'TH', v36.lang = "th-TH,th;q=0.9,en;q=0.8";
const v37 = {};
v37.iso = 'TH', v37.lang = 'th-TH,th;q=0.9,en;q=0.8';
const v38 = {};
v38.iso = 'PH', v38.lang = "en-PH,en;q=0.9,fil;q=0.8";
const v39 = {};
v39.iso = 'PH', v39.lang = "en-PH,en;q=0.9,fil;q=0.8";
const v40 = {};
v40.iso = 'MY', v40.lang = "ms-MY,ms;q=0.9,en;q=0.8";
const v41 = {};
v41.iso = 'MY', v41.lang = 'ms-MY,ms;q=0.9,en;q=0.8';
const v42 = {};
v42.iso = 'PL', v42.lang = "pl-PL,pl;q=0.9,en;q=0.8";
const v43 = {};
v43.iso = 'PL', v43.lang = "pl-PL,pl;q=0.9,en;q=0.8";
const v44 = {};
v44.iso = 'RO', v44.lang = "ro-RO,ro;q=0.9,en;q=0.8";
const v45 = {};
v45.iso = 'RO', v45.lang = 'ro-RO,ro;q=0.9,en;q=0.8';
const v46 = {};
v46.iso = 'UA', v46.lang = "uk-UA,uk;q=0.9,ru;q=0.8,en;q=0.7";
const v47 = {};
v47.iso = 'UA', v47.lang = "uk-UA,uk;q=0.9,ru;q=0.8,en;q=0.7";
const v48 = {};
v48.iso = 'SE', v48.lang = "sv-SE,sv;q=0.9,en;q=0.8";
const v49 = {};
v49.iso = 'SE', v49.lang = "sv-SE,sv;q=0.9,en;q=0.8";
const v50 = {};
v50.iso = 'NO', v50.lang = "nb-NO,nb;q=0.9,en;q=0.8";
const v51 = {};
v51.iso = 'NO', v51.lang = "nb-NO,nb;q=0.9,en;q=0.8";
const v52 = {};
v52.iso = 'DK', v52.lang = 'da-DK,da;q=0.9,en;q=0.8';
const v53 = {};
v53.iso = 'DK', v53.lang = "da-DK,da;q=0.9,en;q=0.8";
const v54 = {};
v54.iso = 'FI', v54.lang = 'fi-FI,fi;q=0.9,en;q=0.8';
const v55 = {};
v55.iso = 'FI', v55.lang = "fi-FI,fi;q=0.9,en;q=0.8";
const v56 = {};
v56.iso = 'GR', v56.lang = "el-GR,el;q=0.9,en;q=0.8";
const v57 = {};
v57.iso = 'GR', v57.lang = 'el-GR,el;q=0.9,en;q=0.8';
const v58 = {};
v58.iso = 'IE', v58.lang = "en-IE,en;q=0.9";
const v59 = {};
v59.iso = 'IE', v59.lang = "en-IE,en;q=0.9";
const v60 = {};
v60.iso = 'CH', v60.lang = 'de-CH,de;q=0.9,fr;q=0.8,en;q=0.7';
const v61 = {};
v61.iso = 'CH', v61.lang = "de-CH,de;q=0.9,fr;q=0.8,en;q=0.7";
const v62 = {};
v62.iso = 'AT', v62.lang = "de-AT,de;q=0.9,en;q=0.8";
const v63 = {};
v63.iso = 'AT', v63.lang = "de-AT,de;q=0.9,en;q=0.8";
const v64 = {};
v64.iso = 'BE', v64.lang = "nl-BE,nl;q=0.9,fr;q=0.8,en;q=0.7";
const v65 = {};
v65.iso = 'BE', v65.lang = "nl-BE,nl;q=0.9,fr;q=0.8,en;q=0.7";
const v66 = {};
v66.iso = 'CZ', v66.lang = "cs-CZ,cs;q=0.9,en;q=0.8";
const v67 = {};
v67.iso = 'CZ', v67.lang = "cs-CZ,cs;q=0.9,en;q=0.8";
const v68 = {};
v68.iso = 'CZ', v68.lang = "cs-CZ,cs;q=0.9,en;q=0.8";
const v69 = {};
v69.iso = 'HU', v69.lang = "hu-HU,hu;q=0.9,en;q=0.8";
const v70 = {};
v70.iso = 'HU', v70.lang = "hu-HU,hu;q=0.9,en;q=0.8";
const v71 = {};
v71.iso = 'PT', v71.lang = "pt-PT,pt;q=0.9,en;q=0.8";
const v72 = {};
v72.iso = 'PT', v72.lang = "pt-PT,pt;q=0.9,en;q=0.8";
const v73 = {};
v73.iso = 'BH', v73.lang = 'ar-BH,ar;q=0.9,en;q=0.8';
const v74 = {};
v74.iso = 'BH', v74.lang = "ar-BH,ar;q=0.9,en;q=0.8";
const v75 = {};
v75.iso = 'AE', v75.lang = 'ar-AE,ar;q=0.9,en;q=0.8';
const v76 = {};
v76.iso = 'AE', v76.lang = "ar-AE,ar;q=0.9,en;q=0.8";
const v77 = {};
v77.iso = 'SA', v77.lang = "ar-SA,ar;q=0.9,en;q=0.8";
const v78 = {};
v78.iso = 'SA', v78.lang = 'ar-SA,ar;q=0.9,en;q=0.8';
const v79 = {};
v79.iso = 'EG', v79.lang = "ar-EG,ar;q=0.9,en;q=0.8";
const v80 = {};
v80.iso = 'EG', v80.lang = "ar-EG,ar;q=0.9,en;q=0.8";
const v81 = {};
v81.iso = 'ZA', v81.lang = "en-ZA,en;q=0.9";
const v82 = {};
v82.iso = 'ZA', v82.lang = "en-ZA,en;q=0.9";
const v83 = {};
v83.iso = 'NG', v83.lang = "en-NG,en;q=0.9";
const v84 = {};
v84.iso = 'NG', v84.lang = "en-NG,en;q=0.9";
const v85 = {};
v85.iso = 'KE', v85.lang = "sw-KE,sw;q=0.9,en;q=0.8";
const v86 = {};
v86.iso = 'KE', v86.lang = "sw-KE,sw;q=0.9,en;q=0.8";
const v87 = {};
v87.iso = 'NZ', v87.lang = "en-NZ,en;q=0.9";
const v88 = {};
v88.iso = 'NZ', v88.lang = "en-NZ,en;q=0.9";
const v89 = {};
v89.iso = 'MX', v89.lang = "es-MX,es;q=0.9,en;q=0.8";
const v90 = {};
v90.iso = 'MX', v90.lang = "es-MX,es;q=0.9,en;q=0.8";
const v91 = {};
v91.iso = 'AR', v91.lang = 'es-AR,es;q=0.9,en;q=0.8';
const v92 = {};
v92.iso = 'AR', v92.lang = "es-AR,es;q=0.9,en;q=0.8";
const v93 = {};
v93.iso = 'CO', v93.lang = "es-CO,es;q=0.9,en;q=0.8";
const v94 = {};
v94.iso = 'CO', v94.lang = 'es-CO,es;q=0.9,en;q=0.8';
const v95 = {};
v95.iso = 'CL', v95.lang = 'es-CL,es;q=0.9,en;q=0.8';
const v96 = {};
v96.iso = 'CL', v96.lang = "es-CL,es;q=0.9,en;q=0.8";
const v97 = {};
v97.iso = 'PE', v97.lang = "es-PE,es;q=0.9,en;q=0.8";
const v98 = {};
v98.iso = 'PE', v98.lang = "es-PE,es;q=0.9,en;q=0.8";
const v99 = {};
v99.iso = 'JP', v99.lang = 'ja-JP,ja;q=0.9,en;q=0.8';
const v100 = {};
v100.iso = 'JP', v100.lang = "ja-JP,ja;q=0.9,en;q=0.8";
const v101 = {};
v101.iso = 'KR', v101.lang = "ko-KR,ko;q=0.9,en;q=0.8";
const v102 = {};
v102.iso = 'KR', v102.lang = "ko-KR,ko;q=0.9,en;q=0.8";
const v103 = {};
v103.iso = 'KR', v103.lang = 'ko-KR,ko;q=0.9,en;q=0.8';
const v104 = {};
function fn1() {
  const v724 = ['q2fYDMfSAg8', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', '8j+tSsbttvmGqM93zxi', 'twfUy2LUAq', 'twfJifnHzMfYAsa', 'u2vSyw0', 'C2HVDwXKx3nOB3DFyMrHEv9HzNrLCL9Uyw1Lx3n1z2DLC3rPB25Z', 'nZm2', 'rhvIzq', 'qxjNzw50Aw5H', 'mZCZ', 'C3rKzxjY', 'uM9ZAgfU', 's3vYBMLHD2fU', 'qwLZAge', 'qwr3B2e', '8j+uTsbfzgDLicaGicHKzxnRDg9Wig9UBhKP', 'vw5RBM93BIbLCNjVCG', 'qMvUC291zge', 'wMHLBG', 'u2TPChbLza', 'zMLYzwzVEf9HBMrYB2LK', 'nZqW', 'uM94yw5H', 'CMv0DxjUicHMDw5JDgLVBIGPia', 'CMvWBgfJzq', 'jNn0yxr1CZ0', 'iokuGIa', 'icdILzeGieHxsuqGica6ia', 'vMLSBgfUDwv2yq', 'l2fWAs92ms9UDw1IzxjZl2DLDa', 'zw4TvLuSzw47Ct0WlJKSzNi7Ct0WlJG', 's2HTzxi', 'sgvYBwf3yw4', 'qwLRyxrLCMLUAq', 'q29UDgvUDc1mzw5NDgG', 'tgvVBMLL', 's2fWB29Y', 'y2XPzw50x3rPBwv6B25L', 'shvZC2fPBG', 'u2v5BMfIB3u', 'rMf0Dq', 'mMzHlxn0zxa2lxjLC3vSDa', 'sMvHBG', 'tMfIAwXHAa', 'tMLUyq', 'u2LUqG', 'DMKTvK4SDMK7Ct0WlJKSzw47Ct0WlJG', 'qwLUDxi', 'CgfYyw1Z', 'mMzHlxn0zxaZlxjLyxv0Aa', 'qxPLCMnLBgW', 'y29UC29SzvbHDgG', 'zMjFzw5JCNLWDgvKx3bHCNrPywXFBMv3x2fJy291BNrFChjVCgvYDgLLCW', 'qwWTu2fHzgK', 'nJGW', 'ue9tva', 'Cgf1C2u', 'CgfYC2u', 'tM9RDwTOyw55yq', 'u2vSzwn0ie1HAwWUDg0Grg9TywLUie1Vzgu6', 'v296BMLHAW', '4PQHief1Dg8GkcmXihrVCcbYyw5NzsK', 'mJi1', 'qwjKDwXSyxLLDG', 'twfYAwfUAq', 'txLHBM1HCG', 's291Ewf0zq', 'zxmTq1uSzxm7Ct0WlJK', 'cIaG4PA2ienOzwnRAw5Nia', 'u3vYyxLH', 'uM93zw5H', 'ChjVDMLKzxjoyw1L', 'BMWTtKWSBMW7Ct0WlJKSzw47Ct0WlJG', 'C3iTuLmSC3i7Ct0WlJKSzw47Ct0WlJG', 'rxjNyxnOzxy', 'rNjLEwe', 'q3jPC3rPBMe', 'u2fRAq', 'ntK3', 'uMvOzw1H', 'wZmVnf0Gu3vIBwL0DgLUzYbYzwDPC3rYyxrPB24GzM9YBsb0BYbgywnLyM9VAY4UlG', 'vgvSA29TC2vS', 'mJe2', 'twvZC2fVDwrP', 'txxdSw96', 'sMvUC2vU', 'yxbPlJjVBZKUy2XVDwq', 'mtGWoq', 'q29SB21IBW', 'yxiTtviSyxi7Ct0WlJKSzNi7Ct0WlJG', '4QYf77IpieDViejHy2SGDg8GugfZC3DVCMqGtw9Kzq', 'Bwf0y2G', 'twfYA292Awm', 'Ahr0Chm6lY9Hy2nVDw50C2nLBNrLCI5MywnLyM9VAY5JB20VCgfZC3DVCMrFyw5Kx3nLy3vYAxr5l3r3B19Mywn0B3i', 'BgvUz3rO', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSkI8Qo3e9mc44', 'zgvSyxLnCW', 'tMT1CNvUEML6yq', 'q29UDgvUDc1uExbL', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29Tl2XVz2LUlZ9UzxH0pszSD3y9mtaX', 's29Sywi', 'tM8Gzg9TywLUCYbPBIbJB25MAwC', 'rw50zxiGt1rqiezPBguGugf0AdO', 'vgHPyw0', 'AxnFC3bLy3rYyv9YzwC', 'zgvZy3jPChrPB25FCMf3', 'ie9uuca', 'tw92Axn0yxiGq2HPBgu', 'u2vJDxjLzefJDgLVBKLUDgvYywn0v2L0Afr3B0zHy3rVCKnHDgvNB3j5', 'rMLSAxbH', 'vhjHyMvSC2K', 'qMvYDgHPBMu', 'DxnLCM5HBwu', 'yxbPs2v5', 'sg9ZC2fPBG', 'Dw5Oyw5KBgvKuMvQzwn0Aw9U', 'twvLBMe', 'Cg9RCMheJw92yxq', 'q2XHCM8GugfYywD1yxK', 'B3v0Bg9VAY1VDhaTC3rHCNq', '8j+tPYba', 'uM9ZC2K', 'yxbWBhK', 'AxnFD2fUDgvKx3n1BwfFDxnLCG', '4PQHief1Dg8GzMv0y2GGzNjVBsbwB2X0EcaOmM9VosK', 'mta0ntmWmtKWnG', 'Bw90B3jVBgeGzwrNzsa0ma', 'EMGTseSSEMG7Ct0WlJKSzw47Ct0WlJG', 'C3vTBwfYEq', 'zgvIDq', 'u2L0Aq', 'rMLZy2HLCG', 'BMf2AwDHDgu', 'rMfO', 'q2HHBG', 'rg9YB3rH', 'C2HVDwXKx3vZzv9UzxH0x3vYAq', 'tNvYBwf0B3y', 'jM1HEfbYAwnLpq', 'qwXPDMuGkeXPDMuP', 'kI8Q', 'yNvWA2vZlM9YzW', 'zw4Tq0eSzw47Ct0WlJKSzNiTq0e7Ct0WlJG', 'uM9Izxj0yq', '4PYtiefqstOGicaGica', 'zw1WDhKGCMvZCg9UC2u', 'vJiZmdLb', 'EMGTq04SEMG7Ct0WlJKSzw47Ct0WlJG', 'mtKUmc4W', 'nJq4', 'C2TPChbLza', 'uhjPEwe', 'uMLJy2K', 'sM9YzgfU', 'oduZ', 'icdILzeGienVBNrHy3q6ihqUBwuVC2nYyxbLCL9RAw5NihrVihjLz2LZDgvYicaGicdILze', 'oIdIJ7mGug9SBgLUzYbnywLSlMn4ie9uucbMB3iG', 'u2vUyw5HEwfRzq', 'cIaGw1rLBxaUDgzDifn0CMvHBwLUzYa', 'Aw52ywXPzcbYzxnWB25Zzq', 'BwfPBhrT', 'q2HPCgvNBW', 'nZiW', 's2fTAw5ZA2K', 'ihjLzgLYzwn0x2nWpq', 'zgvJ', 'qxLZzq', 'yxbPx2TLEt0', 'sgfZyw5VDG', 'tw9YB2nJBW', 'sw5KywG', 'shvHBMC', 'qMfOyxi', 'tMLRB2XHB3u', 'CMvMCMvZAfrVA2vU', 'tgf5Bge', 'ywXLEa', 't2TVBMT3BW', 'ndiZ', 'verd', 'zw1HAwXFB2f1DgHFDg9Rzw5FBM9Fy29UDgfJDf9WzxjT', 'u2fKzwDOAq', 'DMfSDwu', 'oYbxAw42ndSGEdy0', 'vNvVBMC', 'zgrRzxiUy29T', 'txbVzNu', 'xsbqCM94EtOG', 'Dw5JyxvNAhrfEgnLChrPB24', 'FeXVz2LUigzHAwXLzdOG', 'tgvUA2e', 'icdINjCGtM8GBgL2zsbWCM94AwvZigzVDw5KisbbBgWG', 'tM8Gywn0AxzLigrVBwfPBNm', 'B3rWrMLSzq', 'sxLLCG', 'AxnpDxrSB29R', 'zg9JDw1LBNq', 'wNvSDq', 'shLHy2LUDgHL', 'u2HPBG', 'AxmTsvmSAxm7Ct0WlJKSzw47Ct0WlJG', 'twvYEwvT', 't25LugX1CYaXmG', 'txDHBwjH', 'yMCTqKCSyMC7Ct0WlJKSzw47Ct0WlJG', 'AxnFBMf0Aw9UywW', 'qwD1AwXHCG', 'rM9Myw5H', 'Bwf1DgHHCgK', 'rgXHBwLUAq', 'twfPBw91BMe', 't3vTywLTyq', 'rMf0B3u', 'rgfZ', 'mJyZ', 'rMf0zw1H', 'CMvXDwvZDa', 'ugLSBgfP', 'mJmW', 's2fYB2XPBMe', 'AwDFCgfYDgLHBgX5x2nYzwf0zwrFywnJB3vUDf91C2vYx2LK', 'txL0zwW', 'n3HLvw13BevUD244sZjxBwGWBM82DtvvnguWEw9xm3eZmJm2menfyM8XBKvODZjUvKu0vZa5oxC4rZfeEJGXCZHOD25vmMX3DJG5AZjdmuz3yZyWrdG1BtfTELH3ywu0vwffvZbmB2nVnuCWEKSXC3DHltbYywf6BZD1mhPfmLP3CLvKvwnVyLuZq3DYodzdmtn4ztfkD2jLn0u1EtbQvZbLB3DsEM8', 'y29VA2LL', 'wZuVn10Gts1dB250ywn0oIbtDwjTAxr0Aw5NignVBNrHy3qGCg9PBNqUlI4', 'rgLNAwnLBcbqyw5HBwe', 'wxvSAq', 'AhrTBa', 'ihrLBxbVCMfYEsbPBMjVEgvZlI4U', 'DwSTvueSDwS7Ct0WlJKSCNu7Ct0WlJGSzw47Ct0WlJC', 'ntiW', 'oduW', 'BgfZDa', 'C3rHDhvZlwnOzwnR', 'cIaG4PYxierPC2nVBM5Ly3rLzcbMCM9TieXPy2vUC2uGu2vYDMvYlIbfEgL0Aw5NlI4UcG', 'twvUC2fO', 'r3jPDhnHBMe', 'Aw5JBhvKzxm', 'igfJy291BNrZkq', 'C291CMnLx2fJy291BNrFDhLWzv90B19YzwDFAw5MBW', 'Dg90ywXTzw0', 'u2fUyq', 'mZu2', 'Bwf4uhjPy2u', 'u293', 'C3rKB3v0', 'q1bimJm1nW', 'wwLSBwe', 'y191C2vYpq', 'tMLSDwzHCG', 'zNiTqKySzNi7Ct0WlJK', 'twfJAw50B3nOoYbjBNrLBcbnywmGt1mGwcaXmf8Xnv8', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncK', 'tZiGq3PLy2GGuMvWDwjSAwm', '8j+tHcbVDhaUDhH0icHezwzHDwX0kq', 'ywnJB3vUDhm', 'twvTDw5H', 'swnLBgfUza', 'mJm1', 's2fUzW', 'rgLSAw5P', 'y29UzMLYBwf0Aw9Ux2nVzgu', 'cIaGrxHWzwn0zwqGzM9YBwf0oIbLBwfPBhXWyxnZD29YzhXYzwzYzxnOx3rVA2vUFgnSAwvUDf9PzaO', 's2HHBMfT', 'uM9ZzwXPBMu', 'uMfTyxrH', 'vgLTzw91DcbJCMvHDgLUzYbHy2nVDw50', 'rgvLCge', 'BwfW', 'l2PZB24/zMLLBgrZpxn0yxr1CYXJB3vUDhj5lgnVDw50CNLdB2rL', 'y2HLy2TWB2LUDa', 'C2v0uMf3tw9Kzq', 'ugL4zwWGocbqCM8', 'AwDFCgfYDgLHBgX5x2nYzwf0zwrFywnJB3vUDf9UB25Jzv9LEhbPCNK', 'r2v0DgLUzYbLBMnYExb0Aw9Uihb1yMXPyYbRzxKGzM9YihbHC3n3B3jKihjLyxv0Ac4UlG', 'rMXVCMvUy2u', 'C291CMnLx2fJy291BNrFCMvNx2LUzM8', 's2fYBge', 'tw9UAwTH', 'zxLkm0LQB3HpveL3tenkB0LQB3HnrgD3tenkAgr5stznvgT5tun3AvLxz2LpAKv3tKrbC0LTtwLpAKKWzLe9pq', 'ywnJB3vUDf90ExbL', 'u2fUzhvUAq', 'y3jLyxrL', 'yxiTu1KSyxi7Ct0WlJKSzw47Ct0WlJG', 'otC0', 'BMWTu1iSBMW7Ct0WlJKSzw47Ct0WlJG', 'sxrHBhK', 't29YzwrVBYbnEwfUBwfY', 'DxnLq0fbrKjdB25MAxjTyxrPB25gB3jTu3vIBwL0txv0yxrPB24', 'tw9IAwXPCW', 'ugLLCNjL', 'y2HLy2TWB2LUDc50Ehq', 'wZmVnf0Gu0vmrunuie5btuuGuKvhsu9oic8Gq09vtLrswsbgt1iGru1bsuXt', 'q3j1EG', 'mJa2nZmUsfLqoMnVBwv0x3bSyxrFzgvMyxvSDf9WA2CUmI4XlI4Uma', 'thvSD2e', 'tgLTyq', 'y3HUEhmUy29T', 'q29TzxrgywnLyM9VA0neu1DPDgHmB2DNzwrpDxrjwfrozxH0txv0yxrPB24', 'cIaG4PYxie5VihzHBgLKihjHBMDLCYbMB3vUzc4k', 'AwDFBwfJAgLUzv9Pza', 'twf6ywHLCMK', 'mJuWmZyWmdaYlduXnJC1otGWmq', 'cIaGw01HAwWUDg1Difn0CMvHBwLUzYa', 'rhvTAxrYDq', 'oty2', 'wwfH', 'twvNyuzVBG', 'vgLTzw91Da', 't2THzM9Y', 'AhDPza', 'B3rWlxrVA2vUCW', 'C3vJy2vZCW', 'sgfU', 'mJm4', 'ywrKtg9N', 'DgLTzq', 'AxnFDg9Vx3LVDw5NiJP0CNvL', 'rwXPEMfIzxrO', 'AhuTsfuSAhu7Ct0WlJKSzw47Ct0WlJG', 'iJeWlJaUmci', 'otK0', 'mJu4', 'y2fHx3jLz19MBg93x3nVDxjJzq', '8j+mGcbsyw5KB20GkenOCM9TzsaXntaGlYbtyw1ZDw5Nic8GrMLYzwzVEcK', 'ntK4', 'uMfUzg9TicH3D3CGkYbTlMzHy2vIB29RlMnVBsK', 'ywXYzwfKEsbYzwDPC3rLCMvK', 'mtaZ', 'zw4TqLCSzw47Ct0WlJK', 'vxnLihnHDMvKie1HAwXZAw5RigTLEq', 'mZGY', 'ww91C2vM', 'otGZnZe3mJmXmJK5nti0oa', 'AxnFzwfYBhLFDgvLBG', 'mJCXmZC4nZq2mJi0nJyXodK', 'ihbYB3HPzxmGyxjLierfquqUcG', 'Bg9NAw5FzM9YBv9ZAxDNx2vTywLS', 'u3LHzMLXywG', 'Axnuzw1WDgy', 'rwXSyq', 'tgvPBge', 'y29TlMjSB2TZlND3DY5IBg9RCY5JyweUCMvNlNrVCW', 'DxrMoa', 'mZC1', 'y3LHBG', 'rMfPBgvKia', 'qwWTqxP6yxDP', 'qwHTywrP', 'iLnHBxn1BMCGsw50zxjUzxqIo3y9iG', 'oduY', 'AwC0yv9Xzv9KzxzPy2vFAwq', 'mJq5', 'C2vUC2L0AxzLx3n0CMLUz192ywX1zq', 'zMLUywXvCMW', 'B3rWlxnVDxjJzq', 'tM8GAgfYzhDHCMuGzgf0yq', 'mJCWmJK0mty3nZK5nZCZndm', 'tNrVA296BW', 'zgvJB2rLx3jHBMDL', 'zgf0zq', 'uhjVy2HHEMTH', 'u3jP', 'AxnFDg9Vx3LVDw5N', 'zw4Tr0KSzw47Ct0WlJKSzxm7Ct0WlJG', 'mtvFoa', 'mJyY', 'y2fHx3bSyxLFAw50zwDYAxr5x2f0DgvZDgf0Aw9Ux3jLC3vSDa', 'u0vmrunuiefqssbuqvjhrvq', 'tvrtiejLBgfYDxm', 'iejYyxzLia', 'y2XPzw50x2TUB3DUx2TLEv9OyxnO', 'FgfSCMvHzhLFCMvNAxn0zxjLzaO', 'icaGifbSzwfZzsbJAgvJAYb5B3vYigLUDgvYBMv0ignVBM5Ly3rPB24GB3iGDhj5igfNywLUigXHDgvYlGO', 'ChjVDMLKzxi', 'zMjFywnJzxnZx3rVA2vU', 'Dg90ywXjBNn0yw5Jzxm', 'ugfWywrPBwL0CMLVDq', 'rgfYyq', 'tNvNCM9OBW', 'u2fOAw4', 'ugfYAxnH', 'cIaG4PYxieXPy2vUC2uGDMvYAwzPy2f0Aw9UigzHAwXLzc4GrxHPDgLUzY4k', 'wMvUzxGGBMv0oIa', 'uMvNAxn0CMf0Aw9UigvYCM9Y', 'u2H3zxrH', 't3jHBMDL', 'sxzHBM92', 'vw5RBM93BKnqvq', 'twfZAgHHzgK', 'ChjLzMvYCMvKx3bYB25VDw4', 'twfRyq', 'icdILzO', 'qw5KCMvH', 'v2LKywq', '4PYtifbHC3n3B3jKoIa', 'rwXZyq', 'C2vJlwnOlxvH', 'C3rHCNrZv2L0Aa', 'CMv0DxjU', 'qNjPz2L0Dgu', 'y29WEq', 'otC1', 's2vPDge', 'u0vmrunuifjfr0LtvfjbveLptIbtt1vsq0u', 'twTYDgnOEwfU', 'ugvYC29UywWGugfYywD1yxK', 'C2vZC2LVBKvYCM9Y', 'wwfTywD1y2HP', 'q0vv', 'ueftu1DpuKq', 'rwD5Chq', 'sfqGrxjVBMv0', 'qwWTwMfOCMfUAq', 'tMf6yxjVDG', 'tMfPBwe', 'iokgKIa', 'u21HCNq', 'AxnnB2jPBgu', 'qwWTsMfUywjP', 'Bg9NAw5Fy29UDgfJDhbVAw50x3r5Cgu', 'Bg9NAw5nB2rL', 'ndiY', 'qw5HC3rHC2LH', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29Tl2nVBMzPCM1LBwfPBc5WAha/zt0', 'BMiTtK8SBMi7Ct0WlJKSzw47Ct0WlJG', 'rxzP', 'z2DLCG', 'zgLNzxn0', 'BwfJAgLUzv9Pza', 'mZu3', 'DxnLrLHtzxr0Aw5NC1r3B0zHy3rVCKDLBMvYyxrLve9uueTLEu11Dgf0Aw9U', 'rwfTDgHHAq', 'cIaG4PYtief1Dg8GuMfUz2u6ia', 'icaGienOzwnRihLVDxiGChjVEhKGzMLSztOG', 'y2HLy2TWB2LUDc5WAha', 'uMLTyq', 'tMv4yu9uudOGvgLTzw91Da', 'tgfYC2vU', 'vgvSzti', 'Bg9PC190B2TLBG', 'uMvSyxLnB2rLCM4', '4PYtie1Vzgu6ipcFK6WGtwfPBhnPBMSGqxv0BYbuzw1WBwfPBcaO', 'cIaG4PYxiefSBca', 'weWGqxHPyxrH', 'vgLU', 'sxjPBMe', 'ugHYB21Tyq', 'q2vJAwXL', 'ntKZ', 'revbra', 'q2HPBgu', 'yxbPlNPLBMv4BMv0D29YAY5JB20', 'qMf1zxi', 'uhjVEhKGy29UBMvJDgLVBIbKCM9W', 'uMvKzhK', 'ihbYB3HPzxmGyxjLierfquqG4Ocuig5VigXPDMuGChjVEgLLCYbMB3vUzc4', 'v0fg', 'qxn0B3u', 'icbgqIbduKvbveuG4OcuifjvtIbdt01qtevursaGicaGicaGicaGicaGicaGicaG', 'tgLUzgL3zq', 'oIdIJ7mGu01tiejVD2vYiokaLcb3ywL0Aw5Nie9uucbMB3iG', 'zw4TtfiSzw47Ct0WlJK', 't2TLBgXV', 'CgfZC3DVCMq', '8j+FOIbhB29NBguGq2HYB21L', 'lJaGrMLYzwzVEc8', 'zMXVD190ExbL', 'r3jHy2u', 'qw5KzxjZB24', 'uhDK', 'wZCVn10Gts1ut1m6iefJy2vWDgLUzYbuB1mGjIbMAw5HBgL6Aw5NihjLz2LZDhjHDgLVBI4UlG', 'lJaUmc4WlcaIq2HYB21PDw0Io3y9iG', 'tw92Axn0yxiGr3vHDgvTywXH', 'C2fTzs1VCMLNAw4', 'qwWTtwf6CM91zwK', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl3n1y2nLC3mTB3rW', 'CMfUzg9Tvvvjra', 'uK1ymZC2ma', 'tMvNyxi', 'tg9WzxO', 'q2HLyMjP', 'vML2yq', 'qw50B25LBgXH', 'vw1QAq', '4PUuie5VicdIGjqGsNvZDcb0CMLNz2vYie9uucWGC2f2zsb0BYbZDwnJzxnZzNvSlNr4Da', 'C3vIC3rYAw5N', 's2HVCMfZyw5P', 'r2HVC2G', 'DgHYzwfKCW', 'qxbWAwfO', 'q2XHCM8Gr3vHDgvTywXH', 'mJuW', 'uMfOAw0', 'sxnYywvS', 'AxnFDxnPBMDFDw5PzMLLzf9JCa', 'B3v0Bg9VAY1VDhaTzM91BMqTBxnNlwnVzgu', 'u3vIBwL0DgLUzYaYrKeGzw1HAwWGt1rqia', 'qwWTuMf3ywHP', '4PQHief1Dg8Gzgv0zwn0icyGC2vUzcaOiZeGCMfUz2uP', 'qvaZqs4YndeXmduUmda3', 'iNn0yxr1CYi6iLnvq0nfu1mI', 'zxjYB3jZ', 'yxnZAwDU', 'wMv5BMvW', 'mtaWifrOCMvHzhm', 'mZGW', 'rwWGu2fSDMfKB3i', 'rwTHDgvYAw5H', 'C3rYAw5N', 'mM9VotOGtM8GBNvTyMvY', 'CMf3u291CMnLtgLUzq', 'jMfJDgLVBJ1NzxroDw1IzxiMC2vYDMLJzt0', 'qMfLAW', 'C2HVD195B3v0Af9YzwDFAw5FAwDFC3bJ', 'y2TFAwq', 'ihrLBxbVCMfYEsbHy2nVDw50CYaOChjVDMLKzxjZoIa', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlZeYnc4WlJaUmcbtywzHCMKVntm3lJm2', 'sgfKzgfK', 'nJuY', 'nJC4', 'iMrVy19Pzci6iIHCzhSXncWYnh0PiLTEE31DkJ8I', 'vgfUywTH', 'ihjLBwfPBMLUzYbHy2nVDw50CYbMCM9Tia', 'AxnFy3bFyxv0B19JB25MAxjTzwq', 'uM9IAq', 'sMLOEw8', 't3bLCMeG', 'twfNBNvZC29U', 'ihrLBxbVCMfYEsbHy2nVDw50CYaOuMvNAw9UoIa', 'u2XVDMvUAwe', 'igXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGq3jPt1mV', 'mdaWmdaWmdaWmdaWmdaWma', 'CgWTueWSCgW7Ct0WlJKSzw47Ct0WlJG', 'DhDVt29dB25MAwC', 'zMfJzwjVB2S', 'yMXVA3mUy2fHlNjLzY5IAxj0AgrHEq', 'idOG', 'uM95', 'FeXHBMD1ywDLoG', 'thL1zg1PBge', 'yxiTt00Syxi7Ct0WlJKSzw47Ct0WlJG', 'iLTEo117mcWXmdaWFt8IkfXKEZe1ldi0FsKI', 'txLPBNq', 'u2vYDMvYidiGkc9WmI9NzxqP', 'sw52ywXPzcbpvfa', 'twvZzxjLDa', 'Bg9N', 'Ahr0Chm6lY9TlMzHy2vIB29RlMnVBs9JB25MAxjTzw1HAwWUCgHWp2u9', 'AxnFB25Fy29Szf9ZDgfYDa', 'qwWTsgfIC2K', '4QYf77IpieDViejHy2SGDg8GrMLSzsbtzwXLy3rPB24', 'B3v0Bg9VAY1VDhaTzM91BMqTzgLYzwn0', 'uM9KCMLNDwvZ', 'lI4UcG', 'v2LZBMLLD3nRAq', 's29Uzq', 't3jHBMDLie1HBgK', 'wezbq19vtKLwrvjtquXFru5uuLLFt1jhqu5jq19tru5tsvrjvKvFqunusu9ouW', 'vMLLDg5HBq', 'ywLYD2f2zv9YzwDPC3rYyxrPB25Fy29Kzq', 'mMzHlxn0zxaYlwDLDc1LBMnYExb0Aw9UlwTLEq', 'mMzHlxn0zxaXlxnLBgvJDc1TzxrOB2q', 'igjVzhK9', 'Dg9gAxHLza', '8j+wPE+4JYaGD3D3lMzHy2vIB29RlMnVBsaOrgvZA3rVCcbhCMfWAffmkq', '8j+tMezcka', 'zgLYzwn0lNr4Da', 'q2HHCMXVDhrL', 'qNv0Da', 'tM9RD2fUzge', 'mZG3', 's2f0yxjPBMe', 'cIaG4PYxiezHAwXLzcb0BYbMzxrJAcbnywLSlNrTigrVBwfPBNm6ia', 'twfZzwTV', 'wYjXCgXFywn0AxzLx2zSB3DFAwrZpti1mdm2mdaWmIW1mty3ntK4mdeIxq', 'u293B24', 'Cgf0Aa', 'tw96AwXSys81lJaGkeXPBNv4oYbvoYbbBMrYB2LKia', 'tM9YEMfOCMe', 'Ec1HC2jKlwLK', 'otqXnMrMD2zbDG', 'q2HHBMrH', 'Dg90ywXdB3vUDa', 'jM5LEhq9Ahr0ChmLm0eLmKyLmKz3D3CUzMfJzwjVB2SUy29Tjtjg', 'z2v0vgLTzq', 'qwWTs2fSyMfUAq', 'qxnSyw4', 'u2HHBxnH', 'u2fPBNqTtg91Axm', 'r2XVyMu', 'yxnKAwrFyxzHAwXHyMXLx29Ux3n0yxj0', 'nJq1', 'twfSAg90CMe', 'tevw', 'wwLUzW', 'rM91CM5Pzxi', 'zxHPC3rPBMDFywnJB3vUDhm', 'Cg9YDa', 'q291BgqGBM90igv4DhjHy3qGzMjFzhrZzYbMCM9TiefJy291BNrZienLBNrLCG', 'D29YA2vYswq', 'dsaG', 'wwvTzw4Gtw9IAwXL', 'zwWTq1KSzwW7Ct0WlJKSzw47Ct0WlJG', 'y2XPzw50x25VDf9ZDxbWB3j0zwq', 'DgvZDa', 'tw9Yzwf1', 'qwrYAwfUyq', 'tw92Axn0yxi', 'r2vVCMDPywrPCW', 'y29TlMjSB2TZlND3DY5IBg9RCY5JyweUCMvNlNbHC3n3B3jKlMfZEw5J', 'u2L6D2u', 'D3D3lMzHy2vIB29RlMnVBq', 'C2vYDMvYx3bHCMfTCW', 'ugvYzxjH', 'C2XPy2u', 'CMvUzgvY', 'qwrQB2e', 'sxnSyw0', 'ug9YDhvNywW', 'mtvFnW', 'rMvYDxPH', 'zw5K', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29T', 'icbFx19FxYbFx19FicaGicbFx19Fif9Fx18Gif9Fx19FicaGif8Gx19Fx18Gx19Fx18G', 'oYbnB2jPBgu7ihj2oG', 'uMfOyxL1', 'ChqTqLiSChq7Ct0WlJKSzw47Ct0WlJG', 'y29UzMLYBs1WywDLlwvYCG', 'oty4', 'zMLSzq', 'y2TFzxjYB3i', 'u3vKyw5P', 'cIaG4PYxie5VigHPDhmGAw4Gy29UC29SzsbMzwvKlGO', 'y29VA2LLCW', 'u2fPzgK', 'ywXS', 'DxnLCL9Pza', 'u3DLzgvU', 'mMzHlxn0zxa1lwDLDc1JB2rL', 'twfPBc5JEa', 'vM9KywnVBsbuyw56yw5Pyq', 'ktOGAw52ywXPzcbku09o', 'mZGZ', 'vMvYAwz5Aw5NigfJy291BNqGCgfZC3DVCMqGzM9Yidjgqs4UlG', 'C3vIBwL0w0nVBNrPBNvLxq', 'vvaXqs4YmZeWmduUmda3', 'ntaY', 'y2XPzw50x2LK', 'sM92yw5H', 'twL5Dq', 'otyX', 'yMLYDgHKyxLFBw9UDgG', 'DxnLCKLK', 'cIaG4PYxieLUDMfSAwqGu2vYDMvYifjLC3bVBNnLoIbnAxnZAw5NiefJDgL2zsbtzxnZAw9UifrVA2vUlIbbyM9YDgLUzY4k', 'qNvPifrOAq', 'igfJy291BNrZlcbszwDPB246ia', 'txLV', 'qwXLEgv5zxy', 'wMH1', '4PscifVIGkjDifzLCNnPB24Gica6ia', 'twfKDxnOyw5P', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVnJa1lJeUmtuGkeTive1mlcbSAwTLieDLy2TVksbwzxjZAw9UlW', 'nJjMognLowy3ngiXmMy4ngmXmJnJyZiZndm3ytrHmZi', 'sw5KB3nHDa', 'BgfZDg5HBwu', 'Dg9Zx2fJy2vWDgvKx29Ux3bYB2zPBgvFAw5MBW', 'id0G', 'tvbu', 'ChjLDMLLD190zxH0', 'r3vYz2vUAwr6zq', 'mJy4', 'C2vZC2LVBL9JB29RAwvZ', 'oYb3DIKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGvMvYC2LVBI80lJaGq2HYB21LlW', 'sMfPzgvL', 'twvYAwvT', 'qMvNDw0', 'Bg9NAw5FzM9YBq', 'zMiT', 'C3eTweSSC3e7Ct0WlJKSC3i7Ct0WlJGSzw47Ct0WlJC', 'DxbKyxrL', 'yxbWBgLJyxrPB24VBgqRANnVBIWGyxbWBgLJyxrPB24VANnVBG', 'zMjFzhrZzW', 'y29UzMLYBsb5B3uGyxjLigH1BwfU', 'wdi1nte5oLaTmJu2oLaTmZG0', 'twfQyq', 'Bwv0yuLUzM8', 'q2HHBwfYAq', 'zNvSBf9Uyw1L', 'AxnFy2fHx3bLCMzFzw5HyMXLza', 'mtDFma', 'zMjFBwfJAgLUzv9Pza', 'swXRBNvY', 'q0fguG', 'y29TlMjSB2TZlND3DY5IBg9RCY5JyweUCMvNlMjPCNrOzgf5lMfZEw5J', 'zw1HAwXFB2f1DgHFDg9Rzw4', 'rMLSywXP', 'nJm0', 'zNiTs00SzNi7Ct0WlJKSyxi7Ct0WlJG', 'tNrZAgfSAw50C2HHBgK', 'sM9ZzxbO', 'y2XVDwrFDhj1C3rFDg9Rzw4', 'icdIJ7eG', 'yNvPBgq', 'tufjtfrnx0vnquLm', 'DMvY', 'cIaG4PYxie5VihzHBgLKihjHBMDLCY4k', 'u2f0BW', 'Cg90DNleJ3rL', 'BxnNq291BNq', 't3jPz2LU', 'r3vHDgvTywXH', 'tg9NAw4GzMfPBgvKia', 'qwWTr2HHBwrP', 'qwjYywHHBxLHBG', 'C3rYAw5NAwz5', 'tw9Yzw5V', 'CMvZ', '4PYtie1Vzgu6ia', 'Bw9IAwXLlwXVz2LUlwvYCG', 'wc1gqI1ivfrqluvUz2LUzq', 's29YB21H', 'u3vYEwfKAq', 'uMLUAq', 'qwX0AwnL', 'rvjst1i', 'r3jPz29YEwfU', 'zw4TsK0Szw47Ct0WlJK', 'ttiXmdflnKC', 'ts1jBML0igzHAwXLzdOGy2fUBM90igv4DhjHy3qGC2vZC2LVBIb0B2TLBNmGkhbYB3H5igjSB2nRpYK', 'quXcDgvSzwnVBq', '8j+tPYbmB2fKie91DgXVB2SGqwnJB3vUDhmGkg91DgXVB2SGlYbpqxv0AdiP', '8j+MIIbnB3PPBgXHiezPCMvMB3G', 'q2XHCM8Gsg9UzhvYyxm', 'Aw5WDxq', '4PYxievYCM9YoIbuyxjNzxrZigzPBguGBM90igzVDw5KoIa', 'BMv4Df91CMK', 'Bw9KzwW', 'mtiWndiWmfbysgTsAW', 'qM90C3DHBMe', 'x3bYB2nLC3m', 'ugHPCMK', 'lcbJB3vUDhj5oIa', 'cIaG4PA2iezLDgnOAw5NigfJDgL2zsbnywLSlNrTigrVBwfPBNmUlI4', 'mJuZ', 'C3iTtuuSC3i7Ct0WlJKSzw47Ct0WlJG', 'qxj1EMHHBG', 'ywXYzwfKEq', 'ugv0Axq', 'ChjVEgLLCY50Ehq', 'y29UzMLYBwvKlNHSC3G', 'mdnqrtfcvtjIEM8Ws2eWmK9hmgKYmhyTmgi5DZj3rtjTD2zpmdrgodb5DtbYuZbsrtnrDZjPodbUsxCYs0uWouS4mhf1DZnFrwffmdLMvtjnDZbbExCXDJiXENDKEtfmDZGYmg1dmdeXqxCXqum', 'BNrM', 'cIaG4PYxiezPBguGBM90igzVDw5KoIa', 'twfYEwfT', 'nde2', 'mJu1', 'shvP', 'u0vmrunuierjuKvdvcbgsuXficHWAg9UzxXVDhb8CgfZC3DVCMr8y29VA2LLkq', 'zNiTtKuSzNi7Ct0WlJK', 'u3DHDgK', 'rxzH', 'i0fbqufbqq', 'C3vNz2vZDgvKx2zPCNn0x25HBwu', 'sM9OBNnVBG', 'z29Vz2XLx2LKx2vTywLS', 'B3v0Bg9VAY1WB2XSlxbHCNnLlwvYCG', 'Bw9IAwXLlwXVz2LUlxn1y2nLC3m', '4QYf77IpieDViejHy2SGDg8GvgHYzwfKienVDw50', 'r09prdSGCt0WlJCSihj0Dd03nsWGCNr4ptaSigm9otaSig1ZCZ0XmJmYlcb0yNC9mtaYndaSihrWpteXmIWGDhbSptaSihvWBgf0ptuWmcWGDwXSyxq9mtiW', 'u2L0AgvTyMLSzq', 'vmo8CMTPEwu', 'wxvTzq', 'rgfYEwe', 's29PDge', 'qwj1yMfRyxi', 'vgHHyM8', 'uMvSAwfUy2uGsMLV', 'nJCW', 'B3rWx2zHAwXLzc50Ehq', 'u21PDgG', 'twfKAhvYAq', 'CMvHzezPBgvtEw5J', 'BM9FCgX1C19UDw1Izxi', 'icaGg1SZnM3INPqBwZm1Bsa', 'B3rWugf0Aa', 'DgLTzxn0yw1W', 'tgL1', 'z21Zx2LUy29TAw5Nx2nHBgXFCMv0CMLLDMvYx2vSAwDPyMLSAxr5', 'mZu5mZqX', 'q2vSBcbd', 'rwXLBMK', 'rLHqyxnZD29YzfjLyxv0AgvUDgLJyxrPB25nDxrHDgLVBG', 'y2XPzw50x2LUChv0x3bHCMfTCW', 'y3jLyxrLx25LD190B19HChbFywnJB3vUDa', 'z2uXmK5hr3fPyMDWsZrfChf3yM0WsKH3nNLNmvDTodz3mfL5DZDFDZf1ztaXztL3mdHPuZaYAweWn2jV', 'twfOBMf6', 'u3rLzMfUAwe', 'ugfSBgf2Aq', 'qwX2yxjLEG', 'mM9VotOGvgLTzw91Da', 'iokVRIa', 't3rPzw5V', 'q29ZDge', 'rxzHBNm', 'z3jHEq', 'q2HHDhrLCMPLzq', 'qMvSyxj1CW', 'r3jHCgGGqvbjoIbqCM9MAwXLigrVzxmGBM90igv4Axn0ig9YigLZigrPC2fIBgvK', 'wMf3', 'y3bFy29UzMLYBwvKx2j5x2f1Dg9Fy29UzG', 'r3vV', 'qu5lsu5hlq', 'q3PLy2HPyq', 'qxjPyq', 'tMLNzxjPyq', 'q29UC29SzsbUzxr3B3jRoIa', 'wMfTyMLH', 'mhD6Cgf3Beu3mMzezZLWCg81uZeYD0f4DteZD3fVyKu2DtDfmZL4nJDVmwC4AhCYm0u1mNeXzxCYAw8Wrdi0BZfnvwffmurVmxu4mxG4mMv3BKuZzND3DZvoEuuYnxC4vZbmBZyTmun3t3C1ANC0sND6sZb6BZnQD2vH', 'zxHJzwWTD3jPDguTzxjY', 'y29Uy2f0', 'DgLTzw91Da', 'uM9Zzq', 'qwWTtwfZCMK', 'zw5XDwv1zq', 'vgfYz2v0igfSCMvHzhKGCMvNAxn0zxjLzcbVBIbgywnLyM9VAW', 'mJi0', 'wwv0Dw5Kzq', 'mtaW', 'r2vTyxLLBa', 'EgfWCf9Hy2nVDw50CW', 'tMrLEwu', 'sM9Tywe', 'zMvI', 'l3yXl2DLDg51Bq', 'B3rWlNr4Da', 'EMvUzxHFA2v5lNr4Da', 'y2HYB21L', 'wwLSzgL6', 'DJ0I', 'tgL2ztO', 'w0zclunsrufurv0Gw0zbsuWG4PYxif0', 'DgGTveGSDgG7Ct0WlJKSzw47Ct0WlJG', 'y2XPzw50swq', 'otCY', 'tMf0ywXPyq', 'sgvYBMfUzgv6', 'qwzNAgfUAxn0yw4', 'mtaY', 'otCZ', 'icdINjCGtM8GDMfSAwqGzw50CMLLCYbMB3vUzcbPBIbMAwXLlIbfEhbLy3rLzdOGCgHVBMv8B3rWFhbHC3n3B3jK', 'qMvUywXP', 'u2fYCG', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'rMLSDgvYigj5igfWCcaOzNjVBsbTzxnZywDLigjVzhKPoG', 'zNiTq0CSzNi7Ct0WlJK', 'uNvIyq', 'u2LUAge', 'q29UC29Szsb0Aw1LB3v0', 'icbdAgvJA2vKoIa', 'ntKX', 'C2LNBL9PBL93AxrOx2DVB2DSzv9LBwfPBa', 'uMfOAw1VDG', 'zw4TtLOSzw47Ct0WlJK', 'l2fWAs9Hy2nVDw50pW', 'mJqZ', 'rwz1yq', 'uMf6yq', 'tM9TC2e', 'cGRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzaGtKvxifjvtJOG', 'igTLEsbMB3vUzcaO', 'vgHVBxbZB24', 'DgfYz2v0q29UzMLYBvvYBa', 'u291DgGGs29Yzwe', 'ndm0', 'icbqCM94AwvZigXVywrLzdOG', 't1rqihn1yM1PC3nPB24GzMfPBgvKiokaLcbJB2rLig1HEsbIzsbLEhbPCMvKig9YihDYB25N', 'qwWTvgfTAw1P', 'u3rHCKH1yG', 'BhnK', 'CgfUzwW', 'ihrHCMDLDhm', 'igHPDhmPica', 'q0Hfq0Tqt0Lova', 'mZu1', 'wMfPBIbkB3jKyw4', 'rMfJzwjVB2SGCMvQzwn0zwqGve9uucb2zxjPzMLJyxrPB24Gy29Kzq', 'qNjHEMLS', 'y2XVC2u', 'uMvTB3zLihnHDMvKigTLEq', 'rw1Tyq', 'Bg9JyxrPB24', 'CMfUzg9Tx3rLBxbTywLS', 'vhj1zu1VDMu', 'g1SYsW0k', 'uM9Tyw5Pyq', 'vw5PDgvKifn0yxrLCW', 'C3vIAMvJDa', 'wgLHBW', 'lJaUmc4WiIWG', 'u2LYAxbVCM4', 'uMfIAwe', 'D3jPDgu', 'zw4Tu0WSzw47Ct0WlJK', 'u21HCNrMCMvU', 'AgfZx3nLzw5Fy29UzMLYBwf0Aw9Ux3nJCMvLBG', 'BxmTtvKSBxm7Ct0WlJKSzw47Ct0WlJG', 'odu2', 'twvOD2LZAa', 'nJqW', 'C29HCf9JCMvHDgLVBL9ZB3vYy2u', 'y29VA2LLtwfW', 'qxDH', 'tM8Gt1rqihjLy2vPDMvKigLUidyWCYbMB3iG', 'mJyYnZC3nteZode4nZCYnZa', 'mJq3', 'BxnWBgL0x2nYzwf0B3jFBM9Uy2u', 'tgvUyq', 'mJq1nW', 'tM9VCG', 's2vUEwe', 'mMzHlxn0zxaXlxHMywmTDhjPz2DLCG', 's2H2zwrLBgLKEMu', 'zw4TqvuSzw47Ct0WlJK', 'uNvPEG', 'sMLTzw5LEG', '8j+hQVcFH7GGu3bHAw4GlYbmyxrPBIbbBwvYAwnHicHtCgfUAxnOkq', 'Awq9iMnOzwnRCg9PBNrZDwjTAxrIDxr0B24I', 'BMG9iG', 'u0vmrunuienptKzjuK0Gtuvuse9e', 'qw5HAgL0', 'vgfIyxrHyMfLAq', 'C2nYzwvU', 'runptK5sruzvu0ve', 'sgvIyq', 'mJqY', 'ihbYB3HPzxmGyxjLigrLywqUcG', 'BM9szxrYEq', 'ugvYC29UywW', 'ug9Wyq', 'icHYyxC6ia', 'iZu1ntu1nq', 'vM8GvgHP', 'tgvVBM9Yyq', 'wMLU', 'r2vUzxjHDgLUzYaYrKeGve9uucbZzwnYzxqGA2v5lI4U', 'tMv0D29YAYbKCM9Wig9Uia', 'w0zclunsrufurv0Gw1nlsvaG4O+Tif0', 'ifn0CMvHBwLUzYaO', 'tMLWyq', 'zhrZzW', 'DgvTChrMlw1LC3nHz2vZlxjLy2vPDMvK', 'ugvYzwLYyq', 'mtuUmc4W', 'mJyX', 'vgLNBYbiB25KDxjHCW', 'uM9KCMLNDwv6', 'Bw9IAwXLlwXVz2LU', 'qvqMva', 'sgvUzhjV', 'vxnLihnHDMvKihrVA2vU', 'rw50zxiGqwnJB3vUDhmGrMLSzsbqyxrOoG', 'wZeVmL0GrMv0y2HPBMCGAw5PDgLHBcbZzxnZAw9UihrVA2vUCYbMCM9TiezclI4U', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'rgfSAwe', 'u2nOD2fYEG', 'rgfPC3K', 'q2fZDgLSBg8', 'tMLRAxrPBG', 'ywfJ', 'z3PPCa', 'CgXHDgzVCM0', 've9uucbtzwnYzxqGz2vUzxjHDgvKoIa', 'C3rKAw8', 'oIdIJ7mGv2fPDgLUzYbpvfaGzM9Yia', 'u0vmrunuieXpr0LoiezjteuGkhbOB25LFg90ChXWyxnZD29YzcK', 'u0Trms4YmteWmdyUmdaX', 'tMDVEMK', 'q2XHCM8Grfi', 'rw50zxiGwMvUzxGGqvbjieTLEsaOBwfWAwTLEsK6', 'vMvYAwz5Aw5NieXPy2vUC2uUlI4GicaGicaGica', 'mJmWndLsquq4rW', 'qMvRzwXL', 'yMuTqLKSyMu7Ct0WlJKSCNu7Ct0WlJGSzw47Ct0WlJC', 'AxnmAxzL', 'rgLYzwn0', 'BM9YBwfSAxPL', 'icaGidOG', 'rM9UDgfUyq', 'zMjF', 'qwjKDwXSywG', 'C2v0vgLTzw91Da', 'tvroifLLBwvU', 'rxnP', 'uwLUzW', 'yMfUBMvK', 'ntK0', 'rw50zxiGBMv3ihrVA2vU', 'qwnJzxb0luvUy29KAw5N', 'u2LKAwjL', 'u29IAxjVDG', 'u3jLEq', 'AxnuvfK', 'zMrPzf9YAwrFyxzHAwXHyMXLx29Ux3n0yxj0', 'mJq0', 'sM92yw5VDMLJ', 'ksbqCMvZDg8VmI4XmI40mdCGvMvYC2LVBI8', 'zNvSBf9UDw1Izxi', 'twvODge', '8j+tRcbbDxrVifrLBxbTywLSifnLCNzPy2vZicHnywLSlMn4lcbnywLSC2LUAYWGvgvTCc50zIWGtwfPBc50BsK', 'vgvSzwnLBcbnywXP', 'tMf6yw5PBG', 'rw50zxiGu01tiejVD2vYiefqssblzxK6', 'zgf0yq', 'C29JA3m0', 'txvSBgvY', 'uhjVEhKGveXtigrYB3a', 'nti1', 'vgHPBgLUAq', 'BM90AwzPy2f0Aw9Ux2nHBgXIywnRx2LK', 'yxvN', '8j+tPIbbBgWGkezck0Lhk01LDgeP', 'u01tiejVD2vY', 'tgvMzwj2CMu', 'icdINjCGtM8GBwf0y2HPBMCGBNvTyMvYCYbMB3vUzcbIzxr3zwvUihrOzsb0D28GzMLSzxmUifjLDhj5igzPBguGC2vSzwn0Aw9UlG', 'DxnLzc50Ehq', 'tw9Oyw1Lza', 'ChjVy2vZC2vK', 'zw4TtvCSzw47Ct0WlJK', 'mZG1', 'u2LTzwXHBMu', 'vxj1z3vHEq', 'DwLK', 'lcaIr29Vz2XLienOCM9Tzsi7DJ0I', 'zNiTr0eSzNi7Ct0WlJK', 'Aw9Zx3nHzMfYAq', 'D3jVBMCGy29Kzq', 'Aw9Z', 'vgf0AwfUzq', '4PYtie1Vzgu6ipcFK6CGt3v0Bg9VAYbpqxv0AdiGka', 'qwXLEgLVDq', 'l3n0DwjZl2HHBMrSzxjFyxbPlNbOCd8', 'zwWTr1iSzwW7Ct0WlJKSzw47Ct0WlJG', 'qMfQD2e', 'u0vmrunuifbst1HjrvmGrKLmrq', 'sw5NCMLK', 'i0zgndq2nG', '4QYf77IpieDViejHy2SGDg8Gq29UzMLYBsbnzxrOB2q', 'u1rd', 'zMLSzvbHDgG', 'u0zs', 'cIaG4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4PwG', 'zgLKx3vZzv9Hz2u', 'ugfRAxn0yw4', 'ANnVBG', 'rw50zxiGCMfUz2uGiW', 'qMfOCMfPBG', 'nJu1', 'q2HLCMLM', 's2fWBgfU', 'rxrPC2fSyxqGqwzNAgfUAxn0yw4', 'Dg9Rzw4', 'q29UDgK', 'u2LSDMe', 'zg50y2HLy2TWB2LUDa', 'BwfUDwfS', 'DxnLCM5HBwvFChjLzMLSBa', 'DMvYAwz5', '8j+hU/cFH7mGvMLLDg5HBq', 'r3vSyMfOB3i', 'yxbPlM1HAwXZAw5RlMrLDG', 'tM9TDgHHBMrHEM8', 'ugfYAW', 'BwfPBhnPBMTFA2v5lNr4Da', 'w0zclunsrufurv0Gw09uucdINivD', 'mtiZ', 'twfYDgLUzxO', 'BMv3q29VA2LL', 'rMf0Dw1H', 've9uucb2zxjPzMLJyxrPB24Gy29KztOG', 'twfYEq', 'sxnSyq', 'mtmU', 'uMvZCg9UC2u6ia', 'qwXPy2u', 'ndiW', 'cIaG4PYxie91DgXVB2SGzMLSzsbUB3qGzM91BMq6ia', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', '8j+gLsbozxCGq3jLyxrLicaGiokaLcbszwDPC3rLCIbUzxCGrMfJzwjVB2SGywnJB3vUDhm', 'wMfPBIbtDwrHBG', '8j+tHsbsyw5KB20GCgfZCYaRierHDguGkguUzY4Gu2nYyxbLCMS5mMOJmtDHDwCP', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29Tl3jLzY8/zw50CNLFCg9PBNq9Bg9NAw4MBMv4Dd0', 'yMLYDgHKyxLFDgLTzxn0yw1W', 'CMvXlwzVCM0TC3vIBwL0', 'icaGicaGoIa', 'qw5KCMvLyq', 'tM92ywS', 'qwzNAgfUifDPCMvSzxnZ', 'tM91CG', 'tvroifn1zgfU', 'D2fFDg9FAwDFBwvYz2vKx3rVC192yxjPyw50', 'qMvUywjKywXSywG', 'sMfWyw4', 'qxLHCMK', 'wxvZB2y', 'iKfUzhjVAwqI', 'u291C2e', 'ntKY', 'sNvSAwe', 'yxbPlM1HAwWUDg0', 'CgfKrw5K', 'C2STu0SSC2S7Ct0WlJKSy3m7Ct0WlJGSzw47Ct0WlJC', 'CMfUzg9TqNL0zxm', 'ugvYzxO', 'tgLJzw5Zzwq', 'iZaWrdHgrG', 'mc41', 'yMXVy2TFC3rVCMvFBwfJAgLUzv9Pza', 'zgvZDhjVEq', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'C2HVDwXKx3nOB3DFCMvSx2vYCM9Y', 'twfYAwu', 'sgfZAw5P', 'u2fSyw0', 'iokvKokvKokvKokvKokvKokvKokvKokvKokvKokvKaO', 'sM9HBMe', 'uMfTB3m', 'v2LU', '4PYp77IpicbvC2uGy3vZDg9TihbHC3n3B3jKigzVCIbHBgWGywnJB3vUDhm', 'BM92', 'zNiTr0ySzNi7Ct0WlJK', 'CMvZzw5K', 'rw1PBgLH', 'zw5JB2rLx3jHBMDL', 'qwXP', 'A3KTs0CSA3K7Ct0WlJKSCNu7Ct0WlJG', 'tMfPBge', 'r3vLCMXPBMu', 'B2n0', 'q0fv', 'yxiTteiSyxi7Ct0WlJKSzw47Ct0WlJGSzNi7Ct0WlJC', 'rw50zwWGqM9SAxzPyq', 'uMfOBwfU', 'yw5KCM9Pza', 'BM93', 'r1vmrG', 'AxnV', 's3jPC3rPBMe', 'sxjLBgfUza', 'sg92AgfUBMLZEwfU', 'DgvTChrM', 'mJG2', 'vgHYzwuGvuS', 'mJqXotG5ue9cqxb0', 'mZy0mZuZm29bEgH6sW', 'nZeY', 'BMfTztOI', 'u2LUz2fWB3jL', 'C21ZqM93zxjdB25MAwC', 'x3nLC3nPB25F', 'jNbYB3zPzgvYCZ0', 'q2vYBNK', 'ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbdAhjVBwuV', 'vgvTCc50zIbUzxr3B3jRoIa', 'q2HPA2fPzhPL', 'ugfYywD1yxK', 's2HHzgLQyq', 'CMfUzg9T', 'CMvNx3bHC3n3zf9F', 'vM9KywnVBq', 'sM9Oyw5Zzw4', 'mZCY', 'Aw50zxjMywnL', 'qMfTyMe', 'u3DPDhPLCMXHBMq', 's2fUzq', 'u0Trms4YmJeXmtKUmdaX', 'yxbPlG', 'q2vSAwS', 'i0zgnJyWma', 'ugfZC3DVCMq', 'CMvKAxjLy3q', 'Au9tifnHzMfYAsaO', 'mZC2', 'twfYAwe', 'q2HHzxj5zw9UzW', 'Bg9NAw4UDhH0', 's2fTyxu', 'nZi0', 's2fYBhnZB24', 'qteGvgvSzwTVBq', 'r29UEMfSzxO', 'yxbWBgLJyxrPB24VANnVBG', 'twfUC2fYyxK', 'q29UC29SztOGsw52ywXPzcbku09o', 'otCX', 'rMvYCMvPCMe', 'qwWTuwfODgfUAq', 'wwvQAq', 'mMzHlxn0zxa0lwDLBMvYyxrLlxrVDha', 'vML2BW', 'DwnFyNjVD3nLCG', 'tMv4yu9uua', 'qw1H', 'q0fbuMvNAxn0CMf0Aw9UrM9YBvn1yM1PDa', 'ChqTufqSChq7Ct0WlJKSzw47Ct0WlJG', 'y29UzMLYBq', 'u0TjtKCT', 'ignVB2TPzxm9', 's2v0BW', 'mZC0', 't25LifrLBgvJB21TDw5Py2f0Aw9UCW', 'mJy1', 'sML5zw9U', 'mJi2', 'u1nmx09qx05px1rmu3yXxZe', 'sg9UzhvYyxm', 'r29Tzxm', 'u3vZyw50BW', 'q2XVDgLSzgu', 'r0XpqKfm', 'cIaGw01HAwWUy3HDifn0CMvHBwLUzYa', 'mJy2', 'rw5HyMXPBMCGmKzbihDPDgGGve9uucbJB2rLia', 'qw5P', 'wMHHBMC', 'yxiTuueSyxi7Ct0WlJKSzw47Ct0WlJG', 'DgHLBG', 'qxvZDhjHBgLH', 'DMLLD19TB2rLBa', 'vM9KywzVBMuGqvu', 'qNjHDw4', 'qxjZBgfU', 'tMD1EwvUifrOAq', 's29Yzwe', 'sfruuca', 'iokaLcbJB25MAxjTAw5NlI4U', 'BgfZDf9Uyw1L', 'qxv0BY1Nzw5LCMf0zq', 'rLvmte5btuu', 'igrVBwfPBNmP', 's2HHBG', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'vg9YCMvZ', 'vgvSAweGrgvUBwfYAW', 'w0vsuL0', 'z2OTEK9bowW4BhzpotrRsMPbAtHrqvfcyuO1rK9MBufkDwPNtJLSyxbKsfn0wfnbAurWoeC4quDhsuTWA0jiouDwywPrwezhCdu0nuy0q1D5nfeTrMjFz0S4uuDPuKXPr2XFC0DjqNzrAM9tvLfiu2PlrKHOtf95CwLNng0Xz3DPwef3ENHtDtiYohDTB2y4z3DeAxGTmZiXzhCTDY13BKu4odq2mfu4mLnbELvPD3bwrtq2neu1uZb3oeS0sZn1AtbjB0DfDxDFBZmXD2DwvtfvrtfmrtbesZvvy0uWAwz3nfL3DM9XEgKWqZGWmNbQDZbRzgSWmg5qltaXBhv3CfuWzgi4mdi4wwCXAM0', 'zNvSBf9ZAgvLDf9MBg93', 's2HHBgLS', 'z3vUEMLWu3LUyW', 'thvJAwe', 'AxnbCNjHEq', 'uMfOBwfUAq', 'icaGifjLCgXHy2uGD2L0Acb3B3jRAw5NihbYB3HPzxmGyw5KihrYEsbHz2fPBI4k', 'mtuWmta5mJGYmZuYnti4mG', 'DhjPBq', 'Bwq1', 'C3bSAxq', 'EMGTtu8SEMG7Ct0WlJKSChq7Ct0WlJG', 'vxnOyq', 'u2TPCca', 'tKfg', 'uMf0BMe', 'CMvHzgXPBMu', 'rKfuquW6ieLUDMfSAwqGChjVEhKUiefIB3j0Aw5NihrVihbYzxzLBNqGsvaGBgvHAY4', '4PQHifPLBMv4', 'mJmY', 'zNiTtumSzNi7Ct0WlJKSzw47Ct0WlJG', 'u2fYDMLUB3O', 'v2LSywLWB3jU', 'uKfore9n', 'nduW', 'tgLZyq', 'iK5VDcLbo0jYyw5KiJT2psi5osi', 'tMD1EwvU', 'ueHptKvFquXsrufewq', 'uMuTCxvLDwLUzYa', 'mtiWoda4wND3D21Y', 'B3v0Bg9VAY1WB2XSlw5LDc1LCNi', 'sNvSAwu', 'qwWTqw1YAq', 'u2HHAgLKyq', 'Bw9IAwXL', 'u2HYzxLH', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psy', 'u2vSzwn0icHLlMCUideGig9YicaXldmGig9YicaXltmPoG', 'u2v2z2K', 'zwrNzq', 'tw9YB3PVDG', 'u291DgGGqwzYAwnH', 'qw9P', 'rxn0B25Pyq', 'BwfY', 'cIaGw01HAwXZAw5RxsdINjCGqwjVCNrPBMC6ia', 'zMfSBgjHy2TeDhnN', 'twfNzw50ysbuzwXLA29T', 'y29UzMLYBv9MywLSzwqUDhH0', 'ugvYBwfUyq', 's2fYz2jV', 'qwDUAwvZEMTH', 'wMvUzxGGA2v5igzVDw5KicG', 'twf4ihbYAwnLihbLCIbUDw1IzxiGkguUzY4Gmc41ksbBzgvMyxvSDdOGmc41xtO', 'sg93ig1HBNKGywnJB3vUDhmGDg8Gy3jLyxrLpYbBzgvMyxvSDdOGntbDoG', 'mtqUns4W', 'yxbPlMnVDw50CNKUAxm', 'CMvSzwfZzq', 'rgLTyq', '8j+tHcbZDwnJzxnZzNvSlNr4DcaOrgvMyxvSDcK', 'Fe1LDgHVzdO', 'wMfPBG', 'sxnHyMvS', 'mtDFnf8X', 'sg9ZC2vPBMK', 'CNCTuLCSCNC7Ct0WlJKSzw47Ct0WlJGSzNi7Ct0WlJC', 'qxPPEMfO', 'y2HHBgS', 'veXt', 'sw5ZDwzMAwnPzw50igjHBgfUy2u', 'u2fUDg9ZBW', 'CMvHzezPBgu', 'rw1LBhLUzq', 'q2XHCMLZC2u', 'zxmTre8Szxm7Ct0WlJKSzw47Ct0WlJG', 'tgf0DMLH', 'tw92Axn0yxiGugfUyw1H', 'qMfO', 'y29UDhjVBa', 'tw9VCMu', 'y3jLyxrLzf91C2vYx2LK', 'sgfUyq', '8j+uJsbbDxrVifjHBMDLiezPBMrLCIaOC2nHBIbJB25ZB2XLkq', 'iIWG', 'mJiZ', 'r3vHzgfSDxbL', 'yxbWzw5KrMLSzvn5BMm', 'sgfZC2fU', 'icbtsY1gqG', 'twvRB25Uzw4', 'yxiTve4Syxi7Ct0WlJKSzNi7Ct0WlJG', 'rgvTAxnZzq', 'ifnHzMfYAs82mdqUmq', 'vxnLihnHDMvKie1HAwWUy3GGDg9Rzw4', 'rMfPDgG', 'mJm0', '8j+tHcbWCM94AwvZlNr4DcaOrgvMyxvSDcK', 'qM91yxP6yq', 'ig51BwjLCNmGkhnLCNzPy2u6ia', 'r2vYBwfUEq', 'tgLUzhf2Axn0', 'AgvHzgvYC19Syxn0x2LUzNjHx2zSB3DFAwrFC2fMzxr5BMv0', 's2HHDhvUyq', 's2HHzhK', 'cIaG4PYxienVDwXKig5VDcbNzw5LCMf0zsbiyxjKD2fYzsbjrc4GuNvUig9UifDPBMrVD3mUcG', 'drTBsW', 'twLZAhjH', 'tMvIAwvYAwr6zq', 'mJKXnJqXntG2mtmYmZeZmJC', 'ig51BwjLCNmP', 'DxnLq0fbrKjdB25MAxjTyxrPB25gB3jTu3vIBwL0', 'uxvHBNnHAa', 'CMvZlwzVCM0TC3vIBwL0', 'u3vSDgfUyq', 'twf4Axm', 'sgf5yq', 'u2vYDMvYidmGkc9WmY9NzxqP', 'sgLKyxLHAa', 'vM9SDhGVu3rLEa', 'q29YyxPVBG', 'u2fYAq', 'ugfZy3vHBa', 'uM9UzW', 'tuLtu0LorW', 'tM8GDg9Rzw4GCMv0DxjUzwq', 'sMf6EG', 'uNvRAhnHBMe', 'twLH', 't3PKzw1PCG', 'vw1UAwfO', 'qMfUz2XHzgvZAa', 'qwWTqMfSDxnOAq', 'tNPLEwLTyw5H', 'tMfZCMLU', 'vgHHBMrP', 'iK5VDf9biejYyw5KiJT2psiYnci', 'icaGiezVCM1HDdOGAg9ZDdPWB3j0icbVCIaGAg9ZDdPWB3j0oNvZzxi6CgfZCYaGkg9UzsbWzxiGBgLUzsKk', 'AgKTsu4SAgK7Ct0WlJKSzw47Ct0WlJG', 'v2LSC29U', '4PQHief1Dg8GzMv0y2GGzNjVBsbAzw5LEa', 'AM9PBG', 'wwfUzW', 'qMvUBMfUAq', 'qMvUEwfOAwe', 'BNrHx2nVBNrYB2XFCMvHC29U', 'twfYDgLUyq', 'uhjVEhK', 'C3vNz2vZDgvKx2XHC3rFBMfTzq', 'y2XPzw50', 's2fKAwf0B3u', 'sgfUBMfO', 'uM9Tyw5V', 'tgvIyw5VBG', 'DxnLq0fbuMvNAxn0CMf0Aw9UrM9YBvn1yM1PDe11Dgf0Aw9U', 'vM9KywzVBMuGswrLyq', 'DgfYz2v0', 'yxv0BW', 'B2jQzwn0', 'qMf1DgLZDge', '8j+hQ/cFH7CGrNjHBMnLicHgCMvUy2GP', 'zw4TvvmSzw47Ct0WlJK', 'rMvYBMfUzgvZ', 'q2fTAwXSzq', 'oty3', 'ywXYzwfKEsbLEgLZDhm', 'CgHVBMvFChjLzMv0y2HFB3v0y29Tzq', 'qwWTu291CMK', 'A2vLCefSAxzL', 'BNvSBa', 'DxnLCL9Pzf9VzL9TC3bSAxrFy3jLyxrVCG', '8j+tGsbmB2fKigzYB20GugHVBMuGtNvTyMvYCYbMAwXLicHUDw1IzxjZlNr4DcK', 'C2LK', 'wMvUzxG6ig5Vig51BwjLCG', 'wMHHBW', 'uhjVEgLTDxm', 'Dg9VBhmUzg9Uz3zHBMzIlM5LDa', 'ihjHBMDLkhmPks4UlG', 'mJe4', 'vMvYAxPVBG', 'owu1zJK0yMmTztHHnc00ztCZlwi4yMuTnJmZnJrJmJLKnZuZ', 'cIaG4PYuieXVywrLzca', 'u00Tqtu1nKi', 'AxnFChjLzM9YBq', 'sgfRAxPPBwfUyq', 'wxvRAq', 'cIaG4PYtifnLBgvJDgvKoIa', 't2XPDMLH', 'Ahr0Chm6lY9TlMzHy2vIB29RlMnVBq', '8j+mGcbsyw5KB20GlYbnAxHLzcbuzw1WBwfPBcaOtwfPBc5JEcaRie1HAwXZAw5RicSGvgvTCc50zIaRie1HAwWUDg0P', 'cIaGw1jHBMrVBsbuzw1WBwfPBf0Gu3rYzwfTAw5Nia', 'y3j5ChrV', 'sgfSBa', 'sMLRAwe', 'Axnszwf1DgHtDwnJzxnZ', 'q29Uzgu', 'rKjFv0vc', 'mtG4lJeZnY4XnZyUmtyZ', 'tw95BW', 'qMvJA2vY', 'Cgf0Ag5HBwu', 'mtG2oa', 'Ec1MyI1SC2q', '8j+hRVcFH7mGsw5KAweGkeHPBMrPl0vUz2XPC2GP', 'r3v0AwvYCMv6', 'lJaGq2HYB21LlW', 'vgf5Bg9Y', 'zg9TywLU', 'tgf1CMe', 'qwX2zxm', 'rwXLBMe', 'C2v0', 'cIaG4Pwu4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwx', 'zxjYB3i', 'mJuY', 'ueHptKu', 'rxjYB3iG', 'tMfKAwe', 'mtaWifrOCMvHzhmGkev4DhjLBwuP', 'rw50zxiGBMv3ie1HAwWUy3GGDg9Rzw4', 'l3rVA2vU', 'CMvNAw9U', 'C2HHmJu2', 'sgfIAw1HBMe', 'qMfUz3vYyq', 'otKZ', 'u2fUDg9Z', 'rguGthvJyq', 'rw50zxiGy3vZDg9TihrOCMvHzcbJB3vUDcaOms0YmdaSihr5CguGj2jHy2SNihrVigDVigjHy2SPoG', 'rxjSAw5Kyq', 'qwXMyq', '8j+KLIbbvvrpienptKzjuK0Gt1rqpYbB', 'rhvWB250', 'qw1PBMe', 'ndi0', 'tM93ywS', 'rgfSywW', 'C3CTvfOSC3C7Ct0WlJKSzw47Ct0WlJG', 'yNL0zuXLBMD0Aa', 'lJaUmc4W', 'sg9YywS', 'u2HLzxrZ', 'u00T', 'sw5VDwu', 'odu0', 'vsbnB2jPBgu', 'vMvUzxP1zwXH', 'rhvIzxK', 'txvZyq', 'zw4TvfqSzw47Ct0WlJK', 'A2v5swq', 'lIbszxrYEwLUzYbKAxjLy3rSEs4UlG', 'zg9TywLUx25HBwu', 'sxzHBMe', 'rgPLBMvIyq', 'tMLHEMK', 'u291EMe', 'yNmTqKeSyNm7Ct0WlJKSAhi7Ct0WlJGSC3i7Ct0WlJCSzw47Ct0WlJy', 'q0vmtfvmqvi', 'Ag9ZDg5HBwu', 'q29UzMLYBwf0Aw9UihjLAMvJDgvKigj5iezHy2vIB29R', 'q2fYBwvU', 'cIaG4PYxifnLC3nPB24GAw52ywXPzgf0zwqGyNKGC2vYDMvYicHRAwXSks4GrxHPDgLUzY4UlGO', 'q2HHAw1Hzq', 's2f5yq', 'q2HVChjH', 'u1nmx09qx05px1ntthyZ', 'q2HPyxjH', 'uMvLBq', 'qwnJzxb0luXHBMD1ywDL', 'u0vmrunuie9vveXpt0SGqundt1vovfmGrKLmrq', 'ChqTq1ySChq7Ct0WlJK', 'cIaGw1jHBMrVBsbuzw1WBwfPBf0G4PYxiefIB3j0Aw5NoIa', 'rw50zxiGuhjVEgLLCYbgAwXLifbHDgG6', 'zMjFC3vTyv9PC19MCM9Tx2vTywLSx2XVz2LUx3vWC2vSBa', 'vgL3yxjP', 'sw1HBMu', 'lIbbzgqGyw5VDgHLCJ8', 'wZeVnf0Grw50zxiGtwfPBc5JEcbbueKGvg9Rzw4Gkg9WDgLVBMfSlcbWCMvZCYbfBNrLCIb0BYbZA2LWktO', 's3vTyxi', 'C29JA3m1', 'cIaGw1nnuYbcB3DLCL0Gu3rYzwfTAw5Nia', 'qM91CMD1AwjH', 'tw9IAwXLifnLC3nPB24GzgvHza', 'ugf1BgLUzq', 'ChjLx210x2jLAgf2Aw9Y', 'qw1HBMrH', '8j+tIIbtAg93ihrVCca1igfUzcbZzwXLy3q', 'rMvYBMfUzge', 'qwLYDgvSie5Pz2vYAwe', 'v2HPDgu', 'Aw5PDa', 'zMv0y2HFDxnLCM5HBwvFC3vNz2vZDgLVBNm', 'DxnLCKfNzw50', 'u2v0Awf3yw4', 'rgL2Ewe', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'vgHHBNq', 'tLruierVy29TBW', 'mMzHlxn0zxa2lwvUywjSzs10B3rW', '4QYf77IpieDViejHy2SGDg8GuMvZzw5KienVDw50', 'rwn1ywrVCG', 'tgvLBgfWB3jU', 'r2HLB3jNAgu', 'zgv2AwnLx2LKx2zLDgnOx2rHDhi', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlgLTywDLl2fWBMCSkI8Qo3e9mc44', 'u2LIB25NAwXL', 'rKiTvJiUmc4XkYaGicaGicaGicaGicaGicaGicaG', 'mZC4', 'CMvTB3zLlxvZzwqTzxjY', 'jL9FyMT2pq', 'q2HYywLIAq', 'C3yTu0uSC3y7Ct0WlJKSzw47Ct0WlJG', 'u29MDejHBMS', 'BMv4Df9ZAw5Jzq', '8j+uKsbmB2DPBIaGicaGicaG4Ocuief1Dg8TBg9NAw4GD2L0AcbUDw1Izxj8B3rWFhbHC3n3B3jKicHUBYbJB29RAwuGBMvLzgvKkq', 'w0XjvKuG4PYfxq', 'g1SYsHTBsa', 'Bg9Jpsi', 'u29TyMf0', 'qMvHDhjPEG', 'oI8V', 'D2HPDgu', 'r3jLy28', 'icdINjCGtM8GDMfSAwqGzw50CMLLCYbMB3vUzcbPBIbMAwXLlIbfEhbLy3rLzdOGCgHVBMv8B3rWFhbHC3n3B3jKFgnVB2TPzq', 'CMvKDwnL', 'sgfKAwPH', 'AxqTsvqSAxq7Ct0WlJKSzw47Ct0WlJG', 'twvLCMe', 'u00TqtuZnKi', 'yxbPlM1HAwWUy3G', 'uNvTyq', 'BgfUzW', 'twfYAwfT', 's3vZDw1H', 'q2XHCM8Gq29SB21IAwe', 'q29VA2LL', 'u3zLBNnZB24', 'thvUyq', 'zw1HAwW', 'iefqssblzxKGkg1HDxrOyxbPktO', 'ntK1', 'rw50zxiGrgLYzwn0iezPBguGugf0AdO', 'z29Vz2XLx29HDxrOx2fJy291BNq', 'qw5Uyq', 'tw96AwXSys81lJaGkeXPBNv4oYbbBMrYB2LKia', 'jNr5Cgu9', 'C2HVDwXKx3bYzwzPBgXFy3bFAw5Fyxi', 'AgvHzgvYCW', 'u29R', 's2HVDxj5', 'tMTVC2K', 's2fKAwPH', 'ANvU', 'r2HHzge', 's2f0zxjPBMe', 'tMv2zxm', 'uNv0zw5KBW', 'Ahr0Ca', 'C3eTquWSC3e7Ct0WlJKSzw47Ct0WlJG', 'rg9TywLUihrPBwvVDxq', 'v2fPDgLUzYbMB3iGmKzbigvTywLSihzLCMLMAwnHDgLVBIbpvfaGAw4Gt3v0Bg9VAY4UlG', 'AvbOB25LmtiSmq', 'zxHPC3rPBMDFywnJB3vUDf9LEgfJDf9TyxrJAf9JAgvJA2vK', 's2fZC2LT', 'su5wquXjrf9qse9orq', 'ienOCM9Tzsa', 'ugf2Bg92', 'wZiVn10Gts1oyw1LoIbtDwjTAxr0Aw5Nig5HBwuUlI4', 'tw96AwXSys81lJaGkgLqAg9UztSGq1bvigLqAg9UzsbpuYa', 'vgfRywHHC2HP', 'DxnLq0fbuMvNAxn0CMf0Aw9UrMLLBgrwywXPzgf0Aw9UuxvLCNK', 'BwvZC2fNzxmTCMvJzwL2zwq', 'nda1', 'tMv4yu9uudOGsw52ywXPzcbYzxnWB25Zzq', 'qwXIyw5Pyq', 'zM9Yy2vFC2vZC2LVBMXLC3nFBNv4x2v4CgvYAwvUy2u', 'u2HLCMLMzG', 'rMfUzW', 'mta0mtGZmJa3na', 'rhzVCMfR', 'z3PPCcWGzgvMBgf0zsWGyNi', 'ANvS', 'otG4ndi0mJi5odi4mdy2na', 'yMLYDgHKyxLFEwvHCG', 'AxnnywLSC2LUAW', 'r3jLzw4', 's3jPC3rPyw5Zzw4', 'ndCW', 'vgf6Aq', 'ntC2meTfsw9HEa', 'Aw52ywXPzf9WAg9Uzq', 'y29UzL9IB3vUy2LUz19JBgLMzL9Zy3jLzw5FDhLWzq', 'zMjFAwDFzgv2AwnLx2LK', 'mJq2', 'vgvZzMf5zq', 'nteW', 'oIbmB2DNAw5NigLUia', 't21HBG', 'vwTYywLUzq', 'icHJAgvJA2LUzYbSAxzLlI4Ukq', 'twfTzq', 'C3bSAwnL', 'nJC2', 'qw5NzwW', 'D3jPDgvgAwXL', 'zg1Hx2rHDgfFy29TyMLUyxrPB25Fy29UC2vUDf9NAxzLBG', 'twfYDge', 'uhjLC3mGrw50zxiGDg8Gy29UDgLUDwu6', 'u29WAgLH', 'ihbYB3HPzxmGywDHAw5ZDcbgywnLyM9VAY4UlG', 'ignFDxnLCJ0', 'vgLNBYbcB2XPDMLH', 'rgLHEG', 'Bw9UDgG', 'iK5VDc9bkujYyw5KiJT2psi4iG', 'tM9YD2f5', 'C2vHCMnO', 'sM9Uzxm', 'icHLlMCUidq0nZm4ndvywfGPig9YicDIywnRjZO', 'icb8icbty2fUBMvKoIa', 'AxnFzNjVBv9YzwDPC3rYyxrPB25FCMvTAw5Kzxi', 'nJaY', 'CMfUz2u', 'otK1', 'icbgywLSzwqGicaGica', 'ugHHBsbuAgK', 'icbBtwfPBc5JEf0Gqwn0AxzLigrVBwfPBNm6ia', 'ifnHzMfYAs81mZCUmZyGrwrNlW', 'C291CMnLx2n1Awq', 'zw4TtfmSzw47Ct0WlJK', 'qundrvntx05vtujfuJO', 'EgzIx2nHyv9YzwDPC3rYyxrPB25Fy29UzMLYBwf0Aw9Ux3n1yM1PDa', 'vhjPz2DLCMLUzYbLBwfPBcb2zxjPzMLJyxrPB24Gt1rqicHyrKfdks4UlG', 'thvUza', 'tM9Yyq', 'oIdIJ7mGug9SBgLUzYbnywLSlNrTie9uucbMB3iG', 'v29SzG', 's3vTyMe', 'v2vP', 'rgLZC2fUyxLHA2u', 'zMLSDgvY', 'uMfUz2uGrMLUzgvYig1Vzgu6', 'CMvK', 'zNiTrLiSzNi7Ct0WlJKSzw47Ct0WlJG', 'C2vJlwnOlxvHlxbSyxrMB3jTlxzLCNnPB24', 'sxP6yxrP', 'v2fOExvKAq', 'C2fFChjLzMv0y2HFy2fSBgjHy2TFAwq', 'BwSTtuSSBwS7Ct0WlJKSzw47Ct0WlJG', 'u1rbvfvtx0nbtKnfta', 'mZCW', 'sw5KB25LC2LH', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'tguGvgHP', 'vhjPz2DLCMvKie9uucbMB3iG', 'B3nFC2HHCMvKx2fNzv9Yyw5Nzq', 'u2fSBgvO', 'y29UC3rYDwn0B3i', 'vwnVBq', 'cIaG4PYxie9uucbMAwXLig5VDcbMB3vUzdOG', 'vgfIyMfYyq', 'C21ZyM93zxjFA2v5lNr4Da', 'tMLSC3nVBG', 'ChjVzMLSzv9WAg90BW', 'tMv0t25L', 'uMvOyw5H', 'zMLLBgrFBMfTzq', 'r3jHBwvLBNbOB25L', 'tgLSAwfUyq', 'u3rHBMTVDMLJ', 'tMTVBw8', 'vM9KywzVBMuGvfi', 'nJaZ', 'yM9VA19HChbLBMrFC2HLzxq', 'qwT0zxi', 'CM91BMq', 'DxnLCG', 'Bwf5', 'yxbWx2LK', 'ifnHzMfYAs81mZCUmZy', 'zMLYC3rFBMfTzq', 'qMvSAgfKAG', 'zgvIDwCUDhH0', 'ndqW', 'quLt', 'rgvYEwe', 'qMvSAgfQ', 'u2fYz3n5yw4', 'C3vNz2vZDgvKx2z1BgXFBMfTzq', 'ChqTveWSChq7Ct0WlJKSzw47Ct0WlJG', 'BwfPBhnPBMTlzxK', '4PscifVIGkjDifLVDxiGsfDjrca6ia', 'ywnJB3vUDf9Zzxr1Cf93yxrLCMzHBgXFAwq', 'ug9ZCgLZAwW', 'vuLe', 'oty1', 'sgfUBMe', 'uMLJAhrLCG', 'yNjHDMu', 'sw52ywXPzcbpvfaGy29Kzq', 'BgfZDe5HBwu', 'yxjNDG', 'C3rVCa', 'mZeW', 'sw5N', 'ugL4zwWGoa', 'zNiTtveSzNi7Ct0WlJK', 'tMrSB3z1', 'AwDUB3jLx2v4Axn0Aw5Nx2XVz2LU', 'tgfSAq', 'ugH5Dq', 'icaGoIa', 'u2LTAw4', 'u2HLAwTO', 'u2f2zsbRzxK/', 's3LHDW', 'twfUyw5H', 'zxmTq08Szxm7Ct0WlJKSzw47Ct0WlJG', 'uMfKAge', 'tw9Oza', 'q3LUDgHPyq', 'q2XHCM8Gq29ZDgeGuMLJyq', 'C29JA3mTChjVEhKTywDLBNq', 'y2HYB21Lx2fUzhjVAwq', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2', 'q2fTAwXH', 'cIaG4PYxie5VigHPDhmGzM9YihnLBgvJDgvKigfWCc4k', 'uMfTBgfO', 'y2eTquqSy2e7Ct0WlJKSzxm7Ct0WlJGSzNi7Ct0WlJC', 'v2f3zxj1', 'CMvXDwvZDf9KyxrHx2fUzf9JAgfSBgvUz2vFBM9Uy2vFC3rYAw5N', 'yxiTwuuSyxi7Ct0WlJKSzw47Ct0WlJG', 'qM91zgLHzG', 'qxrVBsaOvgvSzw5VCIK', 'AxnFCMvNx3jLCxvLC3rFzNjVBv9Pz19ZDw1H', 'zNiTveCSzNi7Ct0WlJKSzw47Ct0WlJG', 'veLn', 'uM9Tyw5VDG', 'CMfUzg9TvgvTCg1HAwXdB25MAwC', 'qwLYDgvSifrHBNPHBMLH', 'BM9Uzq', 'AgfZx3nLzw5FC3vTyv9Syw5KAw5Nx3bHz2vFChjLx2nVBMy', 'tNH1BwfSBW', 'tM96Aw1H', 'tMfZC2fY', 'q29UzMLYBwvK', 'z2v0mKzbq29Kzq', 'y3vZDg9T', 'rMvKzxjPy2e', 'ChvIBgLJx2TLEv9HBMrFAwrFzM9Yx2vUy3j5ChrPB24', 'zw4TrKOSzw47Ct0WlJK', 'BgLMztOP', 'sgfYDxr5Dw55yw4', 'su5msu5figLUigXVz2LUifbpu1qGyM9KEq', 'y29UzMLYBs1WB3n0lxjLDhj5', 'u3P5BwfUC2TP', 'runptK5srvnfva', 'CMvZB2X2zq', 'Aw5MBgf0zvn5BMm', 'u29WAgLL', 'twfPBhnPBMS6ia', 'BMLK', 'ChjVzMLSzv9WAg90B191CgXVywrFAwq', 'vgHPyw1ZDwS', 'rxnWAxjPDhu', 'zNjVBq', 'sNvYAwm', 'rxDH', 'wMLUzwi', 'uNL1', 't2XNyq', 'qMfUzge', 'C2fMyxjP', 'otu5', 'uMvNAxn0CMf0Aw9UihjLAMvJDgvKigj5iezHy2vIB29R', 'zMfPBgvK', 'rMfJzwjVB2SGq3jLyxrLifDLyIaGicaGicaGica', 'tMLSDwTH', 'CMvNAxn0CMf0Aw9Ux2zHAwXLza', 'u2HHBwe', 'mJeZ', 'ugvYDq', 'u2HHyMfUz3u', 'ywrKCMvZCW', 'C3CTs0uSC3C7Ct0WlJKSzw47Ct0WlJG', 'vM9KywzVBMuGqwXIyw5Pyq', '4P2miev4AxqGuhjVz3jHBq', 'yxbPtw9Kzq', 'CgHVBMu', 'qMvYAwr6zq', 'u291BwfYzq', 'C3bLy3rYyv9Yzxf1zxn0zxjFDxnLCL9Pza', 's292ywm', 'sxfIywW', 'cIaG4PYxieLUDgvYBMfSifnLCNzLCIbfCNjVCIaOntaWks4GugXLyxnLihrYEsbHz2fPBIbSyxrLCI4k', 'ndiX', 'yxbPlM1HAwXNDY5Uzxq', 'sM9JzwX5BMu', 'qxLKXlfU', 'tKze', 'zw4TufCSzw47Ct0WlJK', 'mJC5nZuZnJe1mZu0ntuYodK', 'q2fYDxnV', 'AxnFAw5Fz21Zx2v4CgvYAwvUy2u', 'zxHWAxjLza', 'y3jLyxrPB25FzxjYB3jZ', 'BwfPBhrTq29UzMLN', 'AMfU', 'qwXLEgfUzhjH', 'rxjPA3nZB24', 'twfPBhnPBMSGDgLTzw91Da', 'qMHHDhrP', 'qxPHCG', 's2fKAwf0Dq', 'zxjYB3jFy29Kzq', 'D3jPDgvgAwXLu3LUyW', 'C2TPCf9ZBg93x3jLBf9JAgvJAW', 'vgvYzxnPDge', 'C2vYDMvYrw5KCg9PBNq', 'zxHPC3rZu3LUyW', 'v2LQyxLH', 'qMLYDwS', 'oIdWN5snifzHBgLKyxrPBMCGtgL2zsbtDgf0DxmGzM9Yia', '8j+hP/cFH7CGqNjHEMLSicHqB3j0DwD1zxnLkq', 't3D1C3u', 'rxHWCMvZC28Gu2vUzwDHBa', 'twfSAwS', 'vMvYB25PA2e', 'C2v0u3rHDhvZ', 'DgCTveOSDgC7Ct0WlJKSCNu7Ct0WlJG', 'tMrPyxLL', 'yxOTqvOSyxO7Ct0WlJKSCNu7Ct0WlJG', 'twLSAwnH', 'qwn0AxzLicyGvMvYAwzPzwq', 'icaGicaBwZKWBq', 'cIaG4PYxienssvrjq0fmifnfq1vssvrziefmrvjuoIbsDw50Aw1Lig1LBw9YEsbPBMPLy3rPB24Gzgv0zwn0zwqU', 'CgfZCW', 'rMfPDgHPCa', 'Dhj1BMS', 'nde1', 'ie1VyMLSzsbtywzHCMKVntm3lJm2', 'tg9Wzxm', 'rMf0zw1LAa', 'q09ovefdvfbpsu5ux0vysvnuuW', '4PYtie1Vzgu6ipcFK7eGu01tiejVD2vYicG', 'ChjVEgLLC0zPBgu', 'CgfZC2TLEv9LBgLNAwjSzv9KzxzPy2u', 'q29UBMvJDgLVBG', 'shvUz2fYEq', 'qMLNAxjPBwfUyq', 'qxzH', 'mtG0oq', 'oIdIJ7mGug9SBgLUzYbpDxrSB29Rie9uucbMB3iG', 'vdntuvmZmY43mY0XnW', '4QYf77IpieDViejHy2SGDg8GqvbjifrHCMDLDa', 'r3jHCgHnzxrOB2rfEgnLChrPB24', 'ywDLBNq', 'AxH0x3HMywnFDw5PDMvYC2fSx3rYAwDNzxi', 'quXsrufewv9fweLtvfm', 'sg9HBMCGvgHP', 'odGYytG0otaZnJfKytK4nZaYyMy5n2eWmJfKzgmXngq', 'sgvZC2e', 'sgfKAG', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'w1DbuK5DifvUy2f1z2H0oIa', 'u3vWyxDHBG', 'ywDLx3jHBMDL', 'tMv4yu9uudOGtM8GBNvTyMvYihjLDhvYBMvK', 'ywjJzgvMz2HPAMTSBw5VChfYC3r1DND4ExPbqKneruzhseLks0XntK9quvjtvfvwv1HzwJaXmJm0nty3odKHqcmKjq', 'BMv0D29YA19IC3nPza', 'y3b1CW', 'CMvTB3zL', '4PYxiezHAwXLzdOG', 'rgPLENP5', 'CMvKAxjLy3riB3bZ', 'yxbWBgLJyxrPB24VEc13D3CTzM9YBs11CMXLBMnVzgvK', 'qLnota', 'zw4Tsu8Szw47Ct0WlJK', 'sg9HBMC', 'C2vJCMv0', 'A28Ts1aSA287Ct0WlJK', 'rgfYA28', 'C2vSzwn0', 'y2XPzw50t2jQ', 'AwqTsuqSAwq7Ct0WlJKSzw47Ct0WlJG', 'sxnTB2LSB3y', 'cIaG4PYxifbYB3H5igzPBguGz2L2zw4GyNv0ignVBNrHAw5Zig5VihzHBgLKihbYB3HPzxm6ia', 'nsbuAhjLywrZ', 'vgLNBYboAwnHCMfNDwe', 'Bw5J', 'l3yXl2nVBMzPzW', 'zwXPz2LIBgvFDg9FBw9FC21Zx2LUx2LNnge', 'vgvUzgfP', 'AwDFCgfYDgLHBgX5x2nYzwf0zwrFywnJB3vUDf9UB25Jzq', 'lIbsB3rHDgLUzYbWCM94Es4UlG', 't29YzwrVBYbpBwfU', 'ie1VyMLSzs8XnuuXndGGu2fMyxjPlZyWnc4X', 'q2XHCM8Gq2HPBgu', 'r2fYy2LH', 'twfPBhnPBMS6iefqssbRzxKGAxmGzw1WDhKUifbSzwfZzsbLBNrLCIb5B3vYie1HAwXZAw5RiefqssbRzxKGAw4GBwfPBhnPBMTFA2v5lNr4DcbVCIb0AguGChjVBxb0lG', 'ms4WlJe', 'cIaGiYaGifjHBMDLicaGicaGicaGicaGicbiAxrZ', 'B3bLCMfFBwLUAq', 'Bwv0Ag9K', 'y2f0y2G', 'sevbra', 'ksbPCYa', 'qteGq3jVyxrPyq', 'y29UDgvUDc1LBMnVzgLUzW', 'C291CMnLx2nYzwrLBNrPywXZx3r5Cgu', 'quXsrufewq', 'zNiTu04SzNi7Ct0WlJK', 'ywXPDMu', 'y29UzMLYBsb5B3vYigLKzw50Axr5', 'DgvTCc50zG', 'zw5JCNLWDgvKx2nVBNrLEhq', 'sgXVCgHL', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'vgHVBwfZ', 'odu1', 'zw4TtKCSzw47Ct0WlJK', 'qMfUzxjQzwu', 'teLwrq', 's2fUAMfUyq', 'DxnLrLHtzxr0Aw5NC1r3B0zHy3rVCKvUywjSzvrpvfbnDxrHDgLVBG', 'AxnFBxnWBgL0x25LDxrYywXFy2HVAwnL', 'BMv3', 'y3j5ChrLzf91C2vYx2LK', 'mtjsyuzSwNy', 'qwXVBNnV', 'Dw5SAw5Ru3LUyW', 'u2vYDMLJzsbJB2rLicHLlMCUigzIlcbPzYWGD2ePifTKzwzHDwX0oIbMyL06', 'wMfTDgvS', 'twLU', 'rMf0Aw1H', 'q2HSB2u', '8j+FOIbbBgL2ztOG', '4PYtifrOCMvHzhm6ica', 'qxbVC3rVBg91', 's2f0yxj6Ew5H', 'mtGYoq', 'vgLTzw91DcbNzxr0Aw5NihrVA2vU', 'zMLYC3q', 'mMzHlxn0zxaXlxn1yM1PDc1LBwfPBc1VDha', 'CxvLDwu', 'cIaG4Pwu', 'u21ZqM93zxiGBMv0oIa', 'qw5H', 'zgv2AwnLx25LDhDVCMTFAw5MBW', 'twfPBhnPBMSGA2v5igzVDw5KicG', 'DNDOlM1L', 'cIaGqxbWoIa', 'tMLJB2XL', 'zw1HAwXFB2f1DgHFDg9Rzw5Z', 'r2fLDW', 'v2fUAMLYDq', 'q29UzMLYBwvKia', 'D29YA2vYx3rOCMvHzhm', 'u2fIyMfNAa', 'qwWTrhvSywLTAq', 'tw91C2f2Aq', 'yMLYDgHKyxK', 'qMfUz2XHBgLUAW', 'nte1', 'ywnJB3vUDf9Pza', 'iIbSC2q9iG', 'u2HPCMf6Aq', 'u25LAge', 'qwXNzxjPyq', 'vxbLBMrV', 'l3yXl2vTywLSlW', 'zgvHza', 'rhjHz2fUyq', 'tMn1yMu', 'u2LUz2G', 'r3vSBMfYyq', 'twfUC29Y', 'tMLUBW', 'qxvTyq', '4PscifVIGkjDifrVB2WGicaGica6ia', 'qNj1BM8', 'q29YCMvPyq', 'rgvHzcaOq1aP', '8j+uTsbnAwnYB3nVzNqGrwrNzq', 'sMfUzW', 'ChvIBgLJs2v5sgv4', 'reLutW', 'wMfUzwXL', 'tMfUyq', 'y29UzL9HBgXVD19IywnRx25HDL9HzNrLCL9JAgfUz2vFy3a', 'sNvHBG', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqUlI4', '4QYf77IpieDViejHy2SGDg8Gt1rqiezPBgu', '4PYtie1Vzgu6ipcFK6KGvgvTCc50zIbbDxrVifrLBxbTywLSicG', 'iezPCMvMB3GG', 'tvroifPHBwjPyq', 'yxiTtueSyxi7Ct0WlJKSzNi7Ct0WlJG', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlcOVkJTXptaUoa', 'nda0', 'zgv2AwnLx3PLCM9FyMfSyw5Jzv9ZDgf0zq', 'mJy5', 'otyY', 'twfSAwTH', 'ihWGsfDjrdOG', 'Awq6iIHCzhSXncWYnh0PiLTEE31DkJ9Uyw1LoIi', 'uMfTAxjLEG', 'DgvTChrMq29UzMLN', 'igXPDMuGChjVEgLLCYbYzwfKEs4G', 'u0vmrunuiejst1DtrviGufjprKLmrq', 'u2vUzwDHBa', 'C2TPCa', 'zMfPBgvKlNr4Da', 'tMDV', 'qKGGvgvSzwnVBq', 'ugv0CM9ZEwfU', 'tZiGr2vYBwfUEq', 's2LTDxjH', 'zw4Tu1OSzw47Ct0WlJK', 'twvUB24', 'tMv1BwfUBG', 'zw4Tu0CSzw47Ct0WlJKSEMG7Ct0WlJG', 'mZG5', 'otKY', 'sgLYyq', 'qwWTsNvIB3vYAq', 'q291BwjH', 'Cg9ZDf9MB3jTx2vYCM9YCW', 'sgvSzw5H', 'qwWTuMfZAgrP', 'uM9RAgf5yq', 'mJyZodCXotaXndC1ntCWmdC', 'BNvTyMvY', 'BwfPBhnPBMS', 'y29TlMjSB2TZlND3DY5IBg9RCY5JyweUCMvNlMfZEw5JlMnVBNrHy3rWB2LUDf9LBwfPBc5HC3LUyW', 'ywnJB3vUDhnFBgLZDa', 'ru1bsuW', 'C2HVDwXKx3nRAxbFAgvHzgvYC19ZywzLDhLUzxq', 'qMvSBa', 'yxr0zw1WDgvKx2vTChr5x2XHC3rFBMfTzq', 'cIaG4PYxieHxsuqGAw50zwDYAxr5ignOzwnRigzHAwXLzc4GvgfTCgvYAw5NigrLDgvJDgvKlGO', 'rMfYywG', 'yxiTsK8Syxi7Ct0WlJKSzw47Ct0WlJG', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29TlW', 'C21ZyM93zxiUCgfNzq', 'uM9Izxj0', 'v2fMyq', 'otCW', 'u2f2zsbnywLSlMn4ihrVA2vUpW', 'vxnLihnHDMvKigTLEq', 'Au9tienOCM9TzsaO', 'l3bPy3r1CMu/DhLWzt1UB3jTywW', 'B3jPz2LU', 'B3v0Bg9VAW', 'q2HHBMLKyq', 'mteUma', 'tvroiefMz2HHBMLZDgfU', '8j+hQFcFH6OGr2vYBwfUEsaOr2vYBwfUkq', 'DgvTCg1HAwW', 'u0fg', 'rgv5', 'mta0ndC4otiXmq', 'uKvesvjfq1qGDg8G', 'zxqTruuSzxq7Ct0WlJKSzw47Ct0WlJG', 't2XPDMvPCMe', 'nZeW', 'u2fTyxi', 'Ahr0Chm6lY9Hy2nVDw50C2nLBNrLCI5MywnLyM9VAY5JB20', 'C2TFCgLWyv9JB25Zzw50x2DPDMvU', 'tvrt', 'cIaGw01HAwWUy3HDifn0CMvHBwLUzYbLCNjVCJOG', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6iduWxtO', 'tMv0AgvYBgfUzhm', 'q2fSAxnRyw4', 'C3vJy2vZC2z1Ba', 'uMfXDwvS', 'u0SGvgvSzwnVBq', 'rgvUBwfYAW', 'vMfSzxjPzq', 'AxnFy3bFy2XHAw1Lza', 'v3vSyw5KyxjP', 'Aw5FC293yv9LEhbLCMLTzw50', 's29UC3rHBNrPBMe', 'uMv6ywvP', '8j+FOIbbBMrYB2LKienOCM9TzsaXnta', 'xsdINjCGqwjVCNrPBMCG4OcuiduGy29UC2vJDxrPDMuGzMfPBhvYzxmUieXHC3qGzxjYB3i6ia', 'zMKTrKKSzMK7Ct0WlJKSC3y7Ct0WlJGSzw47Ct0WlJC', 'mMzHlxn0zxaZlxjLyxv0Ac1Yzxn1Bhq', '8j+tHcbKAxjLy3qUDhH0icHezwzHDwX0kq', 'zw4TqumSzw47Ct0WlJK', 'z3jLzw4', 'cIaGwW', 'qw5KzxjZzw4', 'yw0TrvqSyw07Ct0WlJKSzw47Ct0WlJG', 's2LTyw5P', '8j+uTcbpCgvYyq', 'C3rHDhvZpq', 'itLb', 'DxnLx2n1C3rVBv9Nzw5Kzxi', 'C3vJy2vZC2z1Bc50Ehq', 'BMv4yq', 'twf0AgLSzgu', 'rMfPEMe', 'zxmTrumSzxm7Ct0WlJKSzw47Ct0WlJG', 's2fUyq', 'twfYAwfTyq', 'nJC5', 'u1rbvfvtx1DbsvrFuKvuuLK6', 'DgHFChjVzMLSzv9WAg90B190B2TLBG', 't3vTyq', 'zw4Tr0GSzw47Ct0WlJK', 'ru5pvezpvu5e', 'sg9YDMf0', 'CMLK', 'zgvZy3jPChrPB24', 'iK5VDcHbo0jYyw5KiJT2psi5osi', '8j+AQYboB25LicHeAxjLy3qGq29UBMvJDgLVBIK', 'tMfKzxPOzge', 'rMfYAwrH', 'Aw5KzxHpzG', 'BNrHx3jPC2TFDhLWzq', '4PYp77Ipien1C3rVBsbgAwXLifbHDgG', 'rw50zxiGBMv3ie1HAwXZAw5RigTLEq', 'Dg9ju09tDhjPBMC', 'r2LYyxjK', 'mZaY', 'twL0Dq', 'AxnFAw5FBNrHx3nPBMDSzv9MB3jT', 'icaGicaGidOG', 'yM9Sza', 'qxnHBNrL', 'y2HLy2TWB2LUDf90AxrSzq', 'z2vUzgvY', 'u2vSzwn0ie5LEgfpvfaGu2vYDMvYoG', 'tg91yM5H', 'qwLYDgvS', 'rMfJzwjVB2SGv2vIicaGicaGicaGicaGicaGica', 'vgvTCc50zG', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'rvbst1rp', 'q0fbx1jfr19qqvntv09sra', 'yxbY', 'Dhj1zq', 'u2HHyM5HBq', 'EgXZEa', 'icboBYbWCM94AwvZignVBMzPz3vYzwqGkhj1BM5PBMCGzgLYzwn0kq', 'zMLYzwzVEa', 'tMfVBwK', 'B3rW', 'ywXYzwfKEvjLz2LZDgvYzwq', 'tgv3yw5KB3DZA2K', 'y29UzMLYBs1Yzxn1Bhq', 'qMfKzwe', 'vMLQyxLH', 'q2HLBG', 'BtP0zwW', 'icdINjqG', 'Bwf4', '4PscifVIGkjDief1DgHVCIaGica6ia', 'y3jLyxrLsgfZAa', 'u29UzW', 'C2v4', 'tgLU', 'Cg9W', 'lI9MyL9JCNLWDg8', 'ug9VAMe', 'qM9HDgvUzW', 'l3yXl2LUyM94lW', 'rNjLzsbtzw5Lz2fS', 'zNiTq0KSzNi7Ct0WlJK', 'C291CMnLx2fJy291BNrFAw1Hz2vFyxnZzxrFAwq', 'C21ZyM93zxi', 'ie91DgXVB2SGywnJB3vUDcHZks4k', 'u2HVCMvUyq', 'qM9ZBMLHigfUzcbizxj6zwDVDMLUyq', 'BwfPBc5JEa', 'AgL0CW', 's29TywW', 'twfYDgLU', 'uMf0y2HHBMvL', 'AgfZu2vYAwfSAxPLzfn0yxrL', 'twfKAw5H', 'tw9UzgfS', 'sNvUzW', 'vg91y2G', 'xsbBv1DxxtOG', 'C29Tzq', 'otyZ', 'ifTtzw5Kia', 'vxPTB2jPBgu', 'zMrPzf9HDMfPBgfIBgvFB25FC3rHCNq', 'twvYB24', 'u2fYAwm', 'BxnNx3bYzxzPB3vZx2nW', 'qw1LBgLH', 'uMvMzxjLCG', 'lJaU', 'zMfTAwX5x2rLDMLJzv9Pza', 'zgv2AwnLx3bOB25Lx251BwjLCNm', 'zguTqvqSzgu7Ct0WlJKSzw47Ct0WlJG', 'qwnOAwvUzW', 'Aw5ZDgfUy2u', 'mJa2', 'tMfVBwLL', 'CMvWzwf0', 'tg9TyMfYzgK', 'EwvSBg93', 'oIdIJ7mGwMvUzxGG4OcuihDHAxrPBMCGt1rqigzVCIa', 'qMfYyw4', 'w0Xpr0LoiezbsuXD', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'CMvZlxn1yM1PDa', 'u2HLzxroyw1LCW', 'qMLUDg91', 'uMfUyq', 'EgzIx3bHC3n3B3jKx3jLyxv0Af9MyL9VBMX5', 'C2vZC2LVBI1JAgvJAY1LCNi', 'mJeY', 'DxnLzf9Pz19IAxj0AgrHEq', 'y2fHx3jLz2LZDhjHDgLVBL9MAwvSzf92ywXPzgf0Aw9U', 'qxnPys9sAxLHzgG', 'AxnnywLSDg0', 'twfP', 'DMvYC2LVBG', 'rgvHzgXPBMuGCMvHy2HLzcaO', 'iMLKiJOIkfXKEZe0ldi0FsKIw157Fv0QpYi', 'Dg90ywXoDw1IzxjZ', 'ywnJB3vUDhnqzxjfBwfPBa', 'ntaGvgHYzwfKCW', 'rgLUAa', 'tw9YAw4', 'mJeYmwj4vhLeCW', 'zM9YrwfJAa', 'yMXVA3nFy29UDhjVBgXLCL9ZB3vYy2u', 'mJu0', 'thvV', 'vwnLBgW', 'uMvRAge', 'y2fJAgvKx2HLywrLCNnFC2fMzxr5BMv0x2LUzM8', 'mJu2', 'vwzVBMu', 'cIaGw01HAwWUDg1DiokCLYbbyM9YDgLUzZOG', 'rw50zxiGtwfPBhnPBMSGqvbjieTLEtO', 'AwDFzgv2AwnLx2LK', 'uMfUAwe', 'zgv2AwnLx2LK', 'mtaGvgHYzwfKCW', 'cIaG4PYxie5VigfJy291BNrZihrVignVBMzPCM0UcG', 'AxaTyxbPlMnVBq', 'DhDVx2zHy3rVCL9LBMfIBgu', 'qwrs', 'vgvSzw5VCIbqywTPC3rHBG', 'sMfUEwe', 'nJCZ', 'y2fHx3jLz2LZDhjHDgLVBL9OB21LCgfNzv9ZDwjTAxq', 'BhqTtfqSBhq7Ct0WlJKSzw47Ct0WlJG', 'qwWTtwfUC29VCMK', 'w0zclunsrufurv0Gw0fmsvzfipcFN6jD', 'EgzIx2nHyv9YzwDPC3rYyxrPB25FzMLLBgrFDMfSAwrHDgLVBG', 'AhiTsfiSAhi7Ct0WlJKSzw47Ct0WlJG', 'q2f0yxjPBMe', 'rwTRyxjHDa', 'ig1PEgvKihrLBxbVCMfYEsbHy2nVDw50CYaOtwfPBc5JEcaVifrLBxaUDgyGlYbnywLSlNrTic8GtwfPBhnPBMSSifjLz2LVBJOG', 'tw9UAwnH', 'vxPIzwTPC3rHBG', 'ignVBMzPCM0GzxjYB3iG', 'rgfSDMLRlZiUms4WicHmAw51EdSGvtSGqw5KCM9Pzca5oYbtts1hotyWrIbcDwLSzc9qufiXlJe4mdyXmc4WmteP', 'v2LSBgLHBxm', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29Tl2XVz2LUl2nOzwnRCg9PBNqV', 'nJiX', 'uxvYzxnOAq', 'nta1', 'vgvSDxm', 'v29YA2vYia', 'u2TPCcbnywLSlMn4icH1C2uGB3rOzxiGChjVDMLKzxjZkq', 'vgfUEMfUAwe', 'sgfPBgu', 'rxzLBhLU', 'Bs5MywnLyM9VAY5JB20Gke1VyMLSzsbxyMXVA3mP', 'zNiTq0qSzNi7Ct0WlJK', 'q29TzxrjwfrgywnLyM9VA0neu1HMywnvBML2zxjZywXuCMLNz2vYuM9VDff1zxj5', 'BMv4yv9RzxKUDhH0', 'ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbtyw1ZDw5NqNjVD3nLCI8', 'twHSyw5Nyq', 'wMDOywW', 'CM8TuK8SCM87Ct0WlJKSzw47Ct0WlJG', 'C2vYAwfSAxPLzf9ZDgf0zq', 'tMfRyw11CMe', 'AgvHzgvYC19MBg93x2LK', 'tufjtfnjtKTFru1bsuW', 'u2vSzwn0ie1Vzgu', 'nZmY', '8j+mKe1LDgeO', 'qMfWDgLZDgu', '8j+FOcbtyw1ZDw5NiejYB3DZzxiGkg1VyMLSzsbVBMX5kq', 'qMXLC3nPBMC', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'sMfTAwXH', 'ignVBMzPCM0GzMfPBgvKia', 'q2HLy2TPBMCGmKzbig1LDgHVzcbZDgf0DxmUlI4', 'tMLJyxjHz3vH', 'sMvSzw5H', 'n3HLvw13BevUD244sZjxBwGWBM82DtvvnguWEw9xm3eZmJm2menfyM8XBKvODZjUvKu0vZa5oxC4rZfeEJGXCZHOD0D3uxC5BtfzD0jNyw82qZbnBZjZD2fpzKSWrvvQD0D6rtjAD053BuuYzvvSD2HfmKX3nK95rvmXvhC4vZbmBZyTmuz3ng13CJG2qZfUD3fvofH3BNf3sxD0vtfMrtbwEtnTzhC', 'qwWTsgLUywK', 'twLZC2LUzYbfBwfPBa', 'tgfTAwe', 't3jHBMDLiePVCMrHBG', 'ugfVBge', 't3vTB3u', 'qxvYB3jH', 'y3mTq1OSy3m7Ct0WlJKSzw47Ct0WlJG', 's293ywXZA2K', 'q29UC29SzsbMzxrJAcbMywLSzwq', 'Bs1JB25MAxjTlwvYCG', 'Bg9NAw4', 'wYjXCgXFywn0AxzLx2zSB3DFAwrZpti1mdm1ota0ncW1mty3ntK4mdeIxq', 'mJyXmJeXota2nta4mJm4ntG', 'zhOTqLqSzhO7Ct0WlJKSzw47Ct0WlJG', 'wwfZBwLUzq', 'AxnFEw91DgHFCMvNDwXHDgLVBL9MBg93x2nVBxbSzxrL', 'A28Ts1iSA287Ct0WlJKSzw47Ct0WlJG', 'zw5Fvvm', 'yw5KCM9PzfzLCG', 'vg9ZAg1HDg92', 'icaGg1SZm20', 'C2v0sw50zxj2ywW', 'q29UzMLYBwf0Aw9UihjLDhvYBMvKig51BgWGkeLUDMfSAwqGB3iGCMvQzwn0zwqGt1rqkq', 'qwWTqwHTywq', 'l3bYB2mVy3b1Aw5MBW', 'tgfYyq', 'ts1szwDPC3rYyxrPB24GzMfPBgvKicH3yMXVA3mGve9tihn0zxaGzgLKig5VDcbJB25MAxjTkq', 'sMfMyxjP', 'C2TPCf9ZDgvWx3DPDgHVDxrFzxjYB3jZ', 'CMf3u3rY', 'sw5LCW', 'CgfJA2v0igXLBMD0Aa', 'AwDFzM9VDgvYx3zHCMLHBNq', 'uM91Ea', 'txDHBMDP', 'rgvTyMvSzq', 'C2v0lwnVB2TPzq', 'vhvUAxnPyq', 'qw1LBgLL', 'zNvUy3rPB24', 'u3rLEcdWN5sL', 'oIdIJ7mGug9SBgLUzYbuzw1WlNrMie9uucbMB3iG', 'l2fJy291BNrZ', '8j+hUpcFH6yGu2f1zgKGqxjHyMLHic8GtwLKzgXLievHC3qGkefYywjPyYK', 'icHLlMCUidi2mtm0wfHyksbVCIaNyMfJAYC6', 'zgeTreSSzge7Ct0WlJKSzw47Ct0WlJG', '4PYfifLLCYdIGjqGqxv0BYbWB2XSie9uucaMignVBMzPCM0GywnJB3vUDa', 'ChjVDMLKzxjZ', 'AMeTsLaSAMe7Ct0WlJKSzw47Ct0WlJG', 'yw9Hx3rVx3nOzwv0', 'u2f1zgKGqxjHyMLH', 'u29UAwe', 'zw4TwLCSzw47Ct0WlJK', 'sMvZC2LJyq', 'tgL5Dq', 'u2fYywG', 'qwnJB3vUDca', 'CNuTuLuSCNu7Ct0WlJKSzw47Ct0WlJG', 'iIbPBMXPBMvFB3rWpq', 'yxv0B0nVBMzPCM0', 'vhvYA2v5', 'txDHBgu', 'u2TPCcbnywLSC2LUAW', 'qLrdie1VyMLSzq', 'u0vmrunuifrftvbnquLmifbst1zjrevs', 'vM9SDhGG4PQH', 'yxbWCM92ywXZx2nVzgu', 'tMv4yu9uucbUzxr3B3jRoIa', 's2HHy2HHDhj5yw4', 'iZqYqJCYqq', '8j+mKcbhBg9IywWGlYbnAxHLzcbsyw5KB20GkefSBcbszwDPB25Zkq', 'u2nYyxbLCG', 'q2XHCM8GtMLJyxjHz3vH', 'vw5ZDxbWB3j0zwqGz2v0ihjLCxvLC3q', 'tNvZCMf0', 'C3rLEf9RzxKUDhH0', 'zw1WDhK', 'Ec1MyI1MCMLLBMrSEs1Uyw1L', 'mJi3', 'tNvY', '8j+mGcbsyw5KB20GkgfSBca', 'rvHdruXmru5uoYbXptaUosWGCNr0ptm3lcbYDhG9mcWGyZ0XmtqSig1ZCZ0XmJmYlcb0yNC9mtu2mtm2lcb0Cd0YmJKSihrWBd0Wlcb1CgXHDd0YotySihvSBgf0ptu1', 'q2HHAxLHCMf0', 'uMfMzMfLBgXH', 'C2fTC3vUzW', 'vgvYzxPH', 'g1SYsHTBm0OBw0G', 'EgzIx3r3B19Mywn0B3jFzw5HyMXLx3rVDha', 'C28Tu08SC287Ct0WlJKSyxi7Ct0WlJGSzw47Ct0WlJC', 'sxnHDge', 'tNvYDwW', 'sg9Wzq', 'sg9SBq', 'tw9Oyw1TywrP', 'BMv4yunVBMzPzW', 'vgvTyM8', 'sg93ihrVihnLBgvJDcbYyw5Nzxm/', 'qMv0AgXLAgvT', 'cIaG4PYxienVBNnVBguGzMv0y2GGzMfPBgvKoIa', 'rMfPBgvK', 'sMLUzW', 'rg8GvgHP', 'u00TrZK5oei', 'mJuWmZu5mdq0lduXnJC1otGWmq', 'u3v6DwTP', 'rNjHBMnL', 'Ag9ZDa', 't2XH', 'DhiTvfiSDhi7Ct0WlJKSzw47Ct0WlJG', 'vg90ywWGvgLTzq', 'uM9NzxjZ', 'q3vUAge', 'vgvRBge', 'u2f2zsbnywLSC2LUAYbRzxK/', 'twfYA2v0yq', 'r29TzxO', 'q2XHCM8', 'mZeX', 'Aw9Zx2nOCM9Tzq', 's293ywXJENLR', 'rMLYzwzVEcbbBMrYB2LKia', 'twfYA28', 'B3bLCMe', 'C2fMzxr5BMv0x3jLC3bVBNnL', 'yxjFy29UDgfJDhbVAw50', 'rvrjtuvet1vu', 'wM9UzW', 's3v6BMv0C292', 't3nLAq', '8j+tUcbjBNn0ywDYyw0', 'ug9Syxq', 'sg93ig1HBNKGywnJB3vUDhmGDg8Gy3jLyxrLpYbBzgvMyxvSDdOGntbDicH0ExbLigjHy2SGDg8GCMv0DxjUktO', 'uM9Izxj0CW', 'u2vJluzLDgnOlu1Vzgu', 'Bwf0y2HLza', 'quXsrufewv9sruDju1rfuKve', 'v2LJA3jHBwfZAw5NAgu', 'ugfUzgv5', 'igXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGvMvYC2LVBI8', 'CMvZDw1L', 'tNvTyMvYigfSCMvHzhKGCMvNAxn0zxjLzcbVBIbgywnLyM9VAW', 'q05u', 'ywrK', 'swXPyW', 'u2nODwX6', 'zg90pteMCgX1CZ0X', 'twfPBc50Bq', 'mJaGvgHYzwfKCYaOrgvMyxvSDcK', 'rhvVBMC', 'rwWGswrYAxnZAq', '8j+hUVcFH7GGvw5PDgvKifn0yxrLCYaVievUz2XPC2G', 't2XZC29U', 't3jHBMDLiejLBgDPDw0', 'iZe4nZDgmG', 'cIaG4PYxieXPy2vUC2uGC2vYDMvYigLZign1CNjLBNrSEsb1BMrLCMDVAw5Nig1HAw50zw5HBMnLig9YigLZihvUCMvHy2HHyMXLlG', 'ksbPCYbmsvzficyGqunusvzfiq', 's2XLAw4', 's2fLD2THBq', 'r2LYBwe', 'v0Lgsq', 'owSZCI5JB20', 'AwDFywDLx2jSB2nRx2rHDge', 'zxmTr1eSzxm7Ct0WlJK', 'u29TAMfP', 'twfYDgLUCW', 't3b0Dxm', 'mtmUnI4W', 'yxiTsveSyxi7Ct0WlJKSzw47Ct0WlJG', 'qxf1Aw5V', 'rMfPBgvKihrVigv4DhjHy3qGtfneihrVA2vUicHqCM94EsbIBg9JAZ8P', 'qwWTsgfYyMK', 'tMD1z2K', 'zw4TtvuSzw47Ct0WlJKSzNi7Ct0WlJG', 'tMvWywW', 'C29JA2v0', 'rw50zxiGy3vZDg9TihbHC3n3B3jKicHTAw4GnIbJAgfYCYWGDhLWzsaNyMfJAYCGDg8Gz28GyMfJAYK6', 'zxmTqK8Szxm7Ct0WlJKSzw47Ct0WlJG', 'ugv0CMe', 'u2vSAw4', 'rNjLzsbnB2jPBgu', 'iK5VDdTbpujYyw5KiJT2psi4iG', 'qxL1', 'qwWTtwfYCMK', 'ugL4zwWGnW', 'qM9Uz2L3zq', 'rgf2AwvZ', 'C3bJx2jPCNrOzgf5x2LUChv0', 'tMvLBwe', '4PYp77IpicbfBNrLCIbTyw51ywXSEq', 'y2fSBa', '4PQG77Ipia', 'wMfPBMfI', 's3DVBG', 'wMvUzxG6igLUDMfSAwqGsLnptG', 'ChjVy2vZC2LUzW', 'cLTtrvrvuf0GrMLYC3qGDgLTzsbZzxr1CdOGsw5ZDgfSBgLUzYbYzxf1AxjLzcbKzxbLBMrLBMnPzxmUlI4', 'sMfUyq', 'zxmTufKSzxm7Ct0WlJKSzw47Ct0WlJG', 'igfJy291BNrZlca', 'zw5JCNLWDezHy2vIB29RugfZC3DVCMq', 'u3bHAw4', 'rgfUyq', 's2fTAwXH', 'nJeW', 'ugf1Bge', 'Cg90DNjKDgu', 'wNvSzML5yq', 'twfYAxrLCW', 'zM9YBufJDgLVBG', 'wZqVn10Gts1hzw5Kzxi6ifn1yM1PDhrPBMCGz2vUzgvYlI4U', 'BMfTzvjLz2LVBG', 'g1SWBqO', 'xsdINjCGtM8GBNvTyMvYCYbMzxrJAgvKlIbmyxn0igvYCM9YoIa', 'zw5KC1DPDgG', 'sgfTBwfTAq', 'uhjPBwfYEsbMywLSzwq6ia', 'tgLT', 'tgL0AhvHBMLH', 'cIaG4PYxie5VigHPDhmGzM9YihnLBgvJDgvKigfWCc4Gvhj5icjbBgWIig9YigvUDgvYihjHBMDLig1HBNvHBgX5lGO', 'vgvTCc50zIaOsfruuca', 'uM9IAw5ZB24', 'sgLUyxrH', 'txvZDgfMyq', '8j+MIIbgAxjLzM94icHKzxnRDg9WiezPCMvMB3GGlYbgAxjLzM94iefUzhjVAwqP', 'u2vYDMvYideGkc9NzxqP', 'xsbtDhjLyw1PBMCG', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlZeYns4WlJaUmcbtywzHCMKVntm3lJm2', 'y29UzL9ZAg93x2jVDw5JAw5Nx2nSAwzM', 'icaJicaGuMfUz2uGicaGicaGicaGicaGieHPDhmGiefWChm', 'tw96AwXSys81lJaGkefUzhjVAwqG', 'ue9dtYbgnIbqCM8', 'u2HHAa', 'y29UzMLYBwf0Aw9Ux2nVzgvFC2vUzf9LCNjVCG', 'rMLUBgfUza', 'lcaIt3bLCMeIo3y9iG', 'uMLZyq', 'igHPDhmPcG', 'qwjLBMe', 'lxnZAwqT', 'yxv0Ac5SB2DPBG', 'CMfUz2vZ', 'zgf5', 'mJGZ', 't3jHBMDLievNExb0', 'AxnFDg9Hx3jLzW', 'y2HHCKnVzgvbDa', 'w0zbsuXD', 'tI9b', 'zxmTq0WSzxm7Ct0WlJKSzw47Ct0WlJG', 'iZaWrKy4oa', 'iokgKIbbBhjLywr5ihjLz2LZDgvYzwq', 'wwvZAgK', 'C2LN', 'tw92Axn0yxiGrwn1ywrVCG', 'ywXSB3DLzf9KB21HAw5Z', 'A2v5x3rLEhq', 'swXOyw0', 'v2f0yw5HyMu', 'rw50zxiGtg9NAw4GrMLSzsbqyxrOoG', 'sMf2zwq', 'rMvKB3jVDG', 'zMfPBgvKx2jPCNrOzgf5x3LLyxjFy291BNq', 'AxnFBxnWBgL0x3jLzW', 'iIbKDhnNpsi', 'q29UDgvO', 'zguTreuSzgu7Ct0WlJKSzw47Ct0WlJG', 'ugfUyw1H', 'qwrLEwvTAq', '8j+tIIbtAg93ihrVCca1icyGC2vSzwn0', 'iK5VDd1bp0jYyw5KiJT2psi4iG', 'zMjFzgv2AwnLx2LK', 'cIaG4PYxie5VihzHBgLKihnLBgvJDgLVBI4k', 'yxr0zxn0yxrPB25FCMvZDwX0', 'thvJAwu', 'twLV', 'ug9WB3y', 'Agv4', 'vhjPz2DLCMLUzYaYrKeGzw1HAwWGDMvYAwzPy2f0Aw9Uie9uuc4UlG', 'cIaGw01HAwXZAw5RxsbtDhjLyw1PBMCG', 'C2nYzwvUx3zPC2L0zwq', 'wMHVDq', 'Ahr0Chm6lY9NCMfWAc5MywnLyM9VAY5JB20V', 'rw1PBhK', '4PQG77IpierLywq6ia', 'mJiY', 'ihWGFf8GihWGif8GxcaGFcb8icaGFcb8xYKGFcaGx3WGicaVif8Gxcb8ihWGFcaGx3WGia', 'tMfYie1VyMLSzq', 'sg9MzM1HBM4', 'Dg9vChbLCKnHC2u', 'twLYEMe', 'mZG2', 'icaO', 'mJu3', 'mtaUmtuUnW', 'thLUzge', 'twfYAw4', 'u2f2zwX5zxy', 'qxLHBMrH', 'q2XHDwrPyq', 'BwvZC2fNzq', 'txrOzxrOD2e', 'tgfPBge', 'igjVzhLFC25PChbLDd0', 'z2v0rgf0zq', 'qMvLBgLUzsbbCM1LBMLH', 'q2XHCM8GrwWGu2fSDMfKB3i', 'zgfYAW', 'BwnJ', 'Bg9PC19Zzxr0Aw5NCW', 'vxPTyq', 'yxiTu0qSyxi7Ct0WlJKSzw47Ct0WlJG', 'rg9TAw5Py2fUifjLChvIBgLJ', 'twfYzxm', 'C2vJlwnOlxvHlw1VzgvS', 'sw52ywXPzcbvsuqGB3iGBwLZC2LUzYbHy3rPDMuGDxnLCIbZzxnZAw9U', 'rgLZCgXHEu5HBwvZ', 'rMvYCMfYAq', 'tw9IAwX5', 'w+kCHsbmt0DjtITpvfbD', 'zM9YicG7oYK7', 'oty0', 'rxPL', 'wc1gqI1dyxjYAwvY', '8j+hRVcFH7KGsxrHBhKGkeL0ywXPyw4P', 'r2fIAxnVBMLH', 't2TZyw5H', 'mtaGvgHYzwfKCYaOrgvMyxvSDcK', 'y29UzMLYBwvKlNr4Da', 'qxj6Dq', 'l3yXl251Bxn1y2nLC3mVAw5MBW', 'rwXPC2e', 'uMf0yw5H', 'Dg90Cf9RzxK', 'zguTteKSzgu7Ct0WlJKSzw47Ct0WlJG', 'uM9Qyxm', 'uMfOzwW', 'sxzH', 'nJqX', 'u2fJAgLUAq', 's2f2AxrOyq', '4PYtie1Vzgu6ipcFJiaGuMfUzg9Tic8GtwL4zwqGvgvTCg1HAwWGka', 'odGW', 'w1DbuK5DifvUAgfUzgXLzcbYzwPLy3rPB246ia', 'vw1HCM92', 'q2fTyxjH', 'mtK1odC2nKXpDfvbrq', 'BgLUA2LUz19LBNrYEv9WB2LUDa', 'tMrHEwLZAgLTAxLL', 'y29UzMLYBwvTywLSlNbOCa', 'Dw5PzMLLzf9JCf9Zy3jLzw5FDMfYAwfUDa', 'qwrKzwqG', 'Cg9ZDc1YzwCTCgfNzq', 'r2vVCMDPyq', 'qwWTs3v3yxjP', 'zw5JCNLWDgvKx3bHC3n3B3jK', 'q2HLy2TWB2LUDa', 'C2nHBgu', 'u2fTC3vUzYbcCM93C2vYia', 'u1rbvfvtx09loG', 'EMvYB19IywXHBMnLx3n0yxrL', 'C2TPCf9ZzxnZAw9Ux2LUzM8', 'r2fSAw5H', 'q2f2yxi', 'twLUAMK', 'nJa4', 'qxn0CMLK', 'l2fWAs92ms9UDw1IzxjZl3aZl2DLDa', 's2f0AgfYAw5H', 'iIWGiKDVB2DSzsbdAhjVBwuIo3y9iG', 'C3rKAw4', 'C2vZC2LVBL9RzxK', 'yxzHDgfY', 'icdILia', 'u2HHAwTOyq', 'rgfUAwvSyq', 'rgv3Aq', 'y3mTq1OSy3m7Ct0WlJKSC2S7Ct0WlJGSzw47Ct0WlJC', 'Ahr0Chm6lY9KB25NDMfUzMiUBMv0lW', 'C3rHDhvZ', 'C2vZC2LVBI1SAxzLlwnOzwnR', 'AxqTu00SAxq7Ct0WlJKSzw47Ct0WlJG', 'zMjFC3vTyv9PC19MCM9Tx3bOB25Lx2XVz2LUx3vWC2vSBa', 'tgLH', 'rw50zxiG', 'C29YDa', 'nZa2', 'lcaIqNjHDMuIo3y9iG', 'C2vJlwnOlxvHlw1VyMLSzq', 'qMXHEMvR', 'C29JA3m', 'nde0', 'zw4TsuuSzw47Ct0WlJK', 'C3LZDgvTx2rVBwfPBNm', 'B3v0Bg9VAY1VDhaTDgLTzw91Da', 'yMfZzty0', 'tgfYAxnZyq', 'CMvTB3zLtgLZDgvUzxi', 'u1vdq0vtuW', 'zxjYB3jFBwvZC2fNzq', 'rxnWB3nPDg8', 'B3v0Bg9VAY1VDhaTzM91BMqTC3vIAG', 'tMf0C3vRAq', 'y2XPzw50sgLUDhm', 'ndeY', 'oIbdB25MAxjTAw5Nia', 'u2fUz2fYzq', 'BNrWx2LTCg9YDf9ZB3vYy2vFAw5MBW', 'wYjXCgXFywn0AxzLx2zSB3DFAwrZptuXnJC1otGWmsjD', 'yxiTquuSyxi7Ct0WlJKSzw47Ct0WlJG', 'r3jLzwnL', 'wZeVnf0GtwfPBc5JEcbbueKGvg9Rzw4GzM91BMqGka', '4PQHie1HAwWUy3GGkgfWAs5TywLSlMn4iokaLcbmB25NlxbVBgWSifvUBgLTAxrLzcK', 'wZmVn10Gts1cAxj0AgrHEtOGu3vIBwL0DgLUzYbIAxj0AgrHEs4UlG', 'y29Kzq', '8j+tHcbeAxjLy3qGicaGicaG4OcuifnPBMDSzsbMAwXLihDPDgGGywXSigrLDgfPBhmGywXYzwfKEsbJB21IAw5Lza', 'veXtx0ffu18XmJHFr0nnx1niqti1nJPutfnFquvtxZi1nL9hq01Fu0HbmZG0oLrmu19dsefdseeYmf9qt0XzmtmWnv9tseeYnty6runeseuTruneu0eTquvtmti4luDdts1tseeYnty6runeseuTuLnbluffuZeYoc1hq00Tu0HbmJu2oKvdreHfluvdrfnbluffuZi1nI1hq00Tu0HbmZG0oKvdreHflvjtqs1brvmYntyTr0nnlvniqtm4na', 'v2fNBMvY', 's2LSAwm', 'uML2zxjH', 'y3vZDg9TugfZC3DVCMq', 'B3rWCW', 'zw4Tvvm', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'Axnby3rPDMu', 'q2XHCM8Grwn1ywrVCG', 'mJmZ', 'Ahr0CdOVl25LEgfVDhbZzxj2AwnLlMnVBs9HCgKVDJe', 'uMfRDxrLBIbnB2jPBgu', 'vgHLyq', 'Ahr0CdOVlW', 'twLYEMfLDG', 'vhjHBIbuAgK', 'twfPDgHH', 'cIaG4PYxiefJy291BNrZigzPBguGBM90igzVDw5KoIa', 'wNvODxjH', 'cIaG4PYxie5VihzHBgLKie91DgXVB2SGywnJB3vUDhmGzM91BMqGAw4GzMLSztOG', 'vw5RBM93BG', 'q0fbx1jfr19hru5ervi', 'u2fSzwHP', 'q0fbx1jfr19xruXdt01fx1nduKvftG', 'u2vJDxjLzefJDgLVBKnOywXSzw5Nzuneu1bHC3n3B3jKrgLHBg9NuxvLCNK', 'mJa4', 'txv0Ag9UAq', 'rKfdrujpt0S', 'FejYB3DZzxi6', 'mZuX', 'qw1HA2e', 'uMLJAgfYza', 'tgfRC2HTAq', 'mJq5mZu', 'x3nPzf8', 'vw5PDgvKiefYywiGrw1PCMf0zxm', 'Bw9OBwfSlMLT', 'vMfZAwXPA2K', 'lJaPieDLy2TVlW', 'r3vZDgfMC3nVBG', 'jMm9', 'C2HVDwXKx3nRAxbFEw91DgHFDg9Z', 'yxiTu0eSyxi7Ct0WlJKSzw47Ct0WlJG', 'tMLTDwjVBMe', 'v29Qy2LLy2HVD3nRAq', 'tvroifvNyw5Kyq', 'vevnufrgx0vnquLm', 'wgfZyw5VDG', 'zw50CMLLCW', 'AxnFDgHYzwfKC19WDwjSAwm', 'q291BNrYEsbJB2rLicGWid0Gyw55ksbBzgvMyxvSDdOGmf06', 'C3rHCNrLCL9WywnRx2nYzwf0B3jFDxnLCL9Pzhm', 'vM9KywzVBMuGuwf0yxi', 'ugv0CM92', 'u0vmrunuifrbuKDfvcbovu1crvjtiezjteu', 'AvbOB25LmtmSmG', 'vgHPzge', 'uMfQyxbHA3nH', 'tw9SzwzL', 'vhvYAW', 'zgvZA3rVCa', 'zw4TueGSzw47Ct0WlJKSzMLSo3e9mc44', 'wMfOCMe', 'u0vmrunuifriuKvbrcbdt1vova', 'ugHPBgLWCgLUzxm', 'ntK2', 'vMfYz2fZ', 'vu5ltK9xtL9fuLjpuG', 't21HCG', 'qwWTvgHHBMK', 'vgTLC2HLBgfZAhzPBgK', 'tMv3ifPLywXHBMq', 'mZu0', 'rxrPC2fSyxq', '8j+FOIbdAhjVBwuGicHKzxnRDg9WienOCM9TzsaViefUzhjVAwqGq2HYB21Lkq', 'wwvZ', 'mZu4', 'rLHby2nVDw50C0nLBNrLCLr3B0zHy3rVCLnLBgvJDe1LDgHVzerPywXVz1f1zxj5', 'zNvSBg5HBwu', 'g1SWBq', 'ug9Syw5K', 'u2LUz3rLBa', 'ChqTqu8SChq7Ct0WlJK', 'mMzHlxn0zxa1lwnVzguTCMvZDwX0', 'DxiTueSSDxi7Ct0WlJKSzw47Ct0WlJG', 'r2HPEMXHBMu', 'lI4U', 'qxnTyq', 'u2fWDxrYyq', 'mJq4', 'lI4Ukq', 'yxiTruCSyxi7Ct0WlJKSzw47Ct0WlJG', 'qMfIAwm', 'C3rHDgvpyMPLy3q', 't3jHBMDLiejVDhn3yw5H', 'zMXVD19Uyw1L', 'uM95yq', 'mJa2odeUsfLqoMnVBwv0x3bSyxrFzgvMyxvSDf9WA2CUmI4XlI4Uma', 'ts1pvfaGvhjPz2DLCMvK', 'icdILzeGifn0yxr1CYa6ia', 'twfSyxLZAwe', 'qw5KCM9PzcbdAhjVBwuG', 's2fWyw5HzhPL', 'vMvYBwe', 'tg91Axm', 'w0nirunlue9jtLrD', 'Cg9RCMfJB3zHDa', 'mJe5', 'qMvYBMfYza', 'ruvv', 'cIaG4PYxie5VihrHCMDLDhmGzM91BMqGAw46ia', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 't3jHBMDLifnLBMvNywW', 'qMLHBMnOAq', 'r3vSzxi', 'ihWGvuLeoIa', 'nZa0', 'DxrPBhm', '4QYf77IpieDViejHy2SGDg8GuhjVEgLLCYbtzwXLy3rPB24', 'y29UDgfJDhbVAw50x3r5Cgu', 'qM9SAxzPyq', 'vgL6AxrH', 'lcaIq2HYB21PDw0Io3y9iG', 'qwLYDgvSifvNyw5Kyq', 'rxzPzq', 'ifnHzMfYAs81mZCUmZyGt1bslW', 'jMnVDw50CNK9', 'shj2yxrZA2KGvgvSzwTVBq', 'rwTH', 'Ahr0Chm6lY9Hy2nVDw50C2nLBNrLCI5MywnLyM9VAY5JB20VyxbPl2DYyxbOCwWV', 'ywn0Aw9U', 'sMfJA3nVBG', 'AgfZ', 'sM9ZAgK', 'twvUzg96yq', 'nZiY', 's2HLBgLS', 'twfNzgfSzw5H', 'Bw90B3jVBgeGzwrNzsa1ma', 'qwTVC3vH', 'tw96AwXSys81lJaGka', 'uM9TzxjV', 'u2nOBwLKDa', 'u2fICMLUyq', 'AvbOB25LmtuSmW', 'tw96yq', 'vgLNAxn0', 'u2fHza', 'ndi3', 'Dg9tDhjPBMC', 'twfYD2e', 'Dg9mB3DLCKnHC2u', 'yNvNzM9VlMnVBq', 'yM9KEq', 'u2fIyq', 'zxmTtvGSzxm7Ct0WlJKSzw47Ct0WlJG', 'qMHHDM5H', 'vgLNBYbdB2XVBwjPyq', '8j+tPcbpvfa6ia', 'twLSBgvY', 'q2HPB21H', 'nZq0', 'sw50yxj1AW', 'mJyW', 'rNjHBMnLC2nH', 'yMfJAW', 'ChjVEhK', 's2f0BW', 'twfYz2fYAwrH', 'mZuW', 'u2fSBwe', 'q09ovefdvf9qt0Lovf9btfjfqurz', 'y3bFC3vTyv9Yzxn1BhrZx21HCa', 'AwDFyxv0Ag9YAxPHDgLVBL90B2TLBG', '8j+tSsbqyw5LBcbnyxrJAcaG4Ocuie1HDgnOie9uucbMAwXLicHWyw5LBcKGkYbZDwnJzxnZzNvSlNr4DcaOy29VA2LLCYK', 'twLSB3zHBM92Awm', 'ugfWywDLB3jNAw91', 'mJi4', 'txDHCgu', 'uhjLBwL1BsbmAwnLBNnLicaGicaGicaGicaGica', 'q2fUywrH', 'twfPBhnPBMSGkeHuvfaG', 'C3nVx2vUywjSzwq', 'u3vKyw4', 'mJC2', 'u00Tqte1nKu', 'C2HVDwXKx3nRAxbFDhDVx3n0zxbFy29UzG', 'tM92AwTVDG', 'qMvHCMvYia', 'igrLywqGChjVEgLLCYbYzw1VDMvKlGO', 'rw50zxiGtMv4yu9uucbbueKGs2v5oG', 'zw4Tr00Szw47Ct0WlJK', 'B3rWu2vUDa', 'rvHdruXmru5u', 'u0vmrunuiefdq09vtLrtiezjteuGkezst00Gq1jfqvrfifjvtIK', 'tgLUyq', 'uNL1AMLU', 'rMfJzwjVB2SGq2HLy2TWB2LUDdOGmtuWmta5mJGYmZuYnti4mIaOswrLBNrPDhKVshvTyw4GDMvYAwzPy2f0Aw9UihjLCxvPCMvKkq', '8j+mGcbsyw5KB20GkhjVDgf0zxmGzxzLCNKGBNvTyMvYkq', 'q09ovefdvfbpsu5u', 'rMfPBgvKig9Uia', 'lxnLC3mT', 'tufjtenyx0vnquLm', 'yxiTrfOSyxi7Ct0WlJKSzNi7Ct0WlJG', 'qMvSBg8', 'A20Ts0GSA207Ct0WlJKSzw47Ct0WlJG', 'uMfKB3zHBM92Awm', 'y291BNrYEq', 'l2rVBwfPBNm', 'twfYAw5H', 'twfPBhnPBMS', 'zxmTqviSzxm7Ct0WlJKSzw47Ct0WlJG', 'l2fWAs92zxjPzNK', 'yMLYDgHKyxLFzgf5', 'iej1AwXKlW', 'ChmTquySChm7Ct0WlJKSzw47Ct0WlJG', 'vw5PDgvKieTPBMDKB20', 'y3vZDg9Tx2DLBMrLCG', 'twfTBwfKB3y', 'q2HVAq', 'mtaUmc4W', 'B3jPz2LUywW', 'i1bxrf9cuK9xu0vsoJa6', 'v0ff', 'C3bJx2LTCg9YDf9MBg93', 'qw1PBMf0yq', 'vgLNBYbuyw56yw5Pyq', 'lJaGtw9IAwXLlZe1rte0ocbtywzHCMKVnJa0lJe', 'r2XVCMLH', 'BNvTyMvYCY50Ehq', 'wxvUyq', 'tMfYz2vZ', 't1jhqu5jq19tru5tsvrjvKvFqunusu9ouW', 'AxnFzNjVBv93zwjFBgL0zv9YzwDFy29UDhjVBgXLCG', 'BwfPBhnPBMTdB25MAwC', 'zMLYC3rUyw1L', 'EMvUzxHdB25MAwC', 'q3jVyxrPyq', 'BMWTqKuSBMW7Ct0WlJKSzNi7Ct0WlJGSzw47Ct0WlJC', 'qMLSAwm', '8j+tQsbuzw1WlNrMicHhBwfPBcaVie91DgXVB2SGqwXPyxnLCYK', 'sMfSBg9O', 'ChjVzMLSzv9WAg90B19Pza', 'g1SWBsa', 'wwvTzw4', 'y29UC2vUDf9QDxjPC2rPy3rPB25FyxrFz2f0zq', 'D3D3lMzHy2vIB29RlMnVBsaOrgvZA3rVCcbhCMfWAffmkq', 'EwvZ', 'qwXIyq', 'CMfUzg9Tx2rHDgu', 'u2vZyxK', 'uML5yq', 'AMf6B2vZDa', 'mtG3nG', 'icdINjmGtgLJzw5ZztOG', 'qwXPBw92', 'qwjPz2fPBa', 'C3rLEa', 'q0fbx1jfr19dt05uqunux1bpsu5ux1bit05f', 'v2fSA2vY', 'AwDFz2vUzgvY', 'tMPLCNu', 'twfJ', 'CMvXlxn1yM1PDa', 'vMvYB25Py2e', 'wwfTywrH', 'zw1HAwXFChjLzMLSBgvK', 'ChqTr1CSChq7Ct0WlJK', 'u2LKzgLXDwK', 'BZe4', 'ChjVEgLLCW', 'C3vTyv9VBL9JB25Mx3rOCMvZAg9Sza', 'rw50zxiGtwfPBc5JEcbbueKGvg9Rzw4GkhGTyxbPlxrVA2vUlcbLlMCUihrTx2XPDMvFlI4UktO', 'vg90ywWGvgfYz2v0CW', 'r2vYBwfPBMu', 'u2nOyxr6', 'rgfUzW', 'ugHPBMrPBgu', 'tMfYzq', 'DgfYz2v0CW', 'CMvHC29U', 'z2v0', 'z2v0ugf0Aa', 'zxHPDa', 'z21HAwWSB3v0Bg9VAW', 'sgLKyxLHDa', 'yNjVD3nLCG', 'Bg9NAw5FAg9Tzv9UyxrPDMvFAw50zwDYyxrPB25FCg9PBNq', 'BM9YBwfS', 'sgfUC2vU', 'u3vIBwL0DgLUzYbut1rqignVzguG', 'uMvTB3zLihnHDMvKihrVA2vU', 'tMfQBge', 'zxmTueuSzxm7Ct0WlJKSzw47Ct0WlJG', 'icHvsuq6ia', 'zNiTveqSzNi7Ct0WlJKSyxi7Ct0WlJG', 'vgHHAwXHBMq', 'mJq1', 'ugL4zwWGoq', 'u291BwLH', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'twfSAq', 'uMvNAxn0CMf0Aw9UihzHBgLKyxrPB24GzMfPBgvK', 'vgLNBYbqyxjHz3vHEq', 'ywnJB3vUDhnFBgLZDf9JBgLLBNq', 'r3vSAxLLDG', 'B3v0Bg9VA0nVBMzPzW', 'tgvYB3K', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'tMfQywzP', 'uhv0CMK', 'w0vsuK9sxsbgywLSzwqGDg8GAw5ZDgfSBcbKzxbLBMrLBMnPzxmUie1HA2uGC3vYzsboB2rLlMPZigfUzcboue0GyxjLigLUC3rHBgXLzcbWCM9WzxjSEs4', 'uNvZC2LH', 'tMfYDwvTB24', 'wZqVnf0GuMvNAxn0CMf0Aw9Uihn1yM1PDhrLzceGq2HLy2TPBMCGy29UzMLYBwf0Aw9UihnLC3nPB24UlI4', 'l2fWAs9JAgvJAW', 'tgf3ywW', 'D2LUmZi', 'icdINjqGy29UzMLYBwvKlNr4DcbZyxzLzcb0BZOG', 'y3vYCMvUDfbYB3H5', 'qwL6yxq', 's29UC3rHBNrPBMLKAxm', 'ihXFFcaGihXFx19FlYaGifXFx19FFf98ifXFxf9Fx19Fl18VicaGxf9Cx3WGFf9Fx19FFa', 'vwv3rhDLBvvqownZnMzuvhPhwJyWra', 'AgfUzYb1Ca', 'ugf0CMLJAwe', 'zMfSBgjHy2TmC2q', 't3jHDgHHAq', 'zxmTrvmSzxm7Ct0WlJKSzw47Ct0WlJG', 'C2HVDwXKx3nHDMvFCgfZC3DVCMq', 'C3rHDhvZq29Kzq', 'txvRAgvYAMvL', 'l3yXl2LUyM94zxm', 'ChvZAa', 'qwXHB3vP', 'sNvSAwv0Dgu', 'l2fWAs9WAw5N', 'rfrbqW', '8j+MIIbgAxjLzM94iefUzhjVAwq', 'AwDUB3jLx2v4Axn0Aw5Nx2XVz2LUx2zYB21FC3vTyq', 'icdINjCGsfDjrcbTAxnTyxrJAcbKDxjPBMCGzxHLy3v0Aw9UihnLCxvLBMnLlIbbyM9YDgLUzY4UlGO', 'y29UzMLYBwvTywLS', 'vgvSzw5LDc9cyxnL', 'qxjTzw5Pyq', 'u2XVDMfRAwe', 'Aw5ZDgfNCMfT', 'twfYAw5V', 'v2vIzxi', 'u2fSAw1HDge', 'Aw5OzxjPDa', 'vgvTCc50zIb0Aw1LB3v0', 'qwHTzwq', 'DhLWzq', 'mJuX', 'mMzHlxn0zxaXlxHMywmTDhjPz2DLCMvK', 'twf5yq', 'q2HLy2TWB2LUDca', 'twfPBhnPBMSGBMv0D29YAZOG', 'DxnL', 'q2HHywjHBMu', 'y191C2vY', '4PYtie1Vzgu6iokAOsbnywLSlMn4ief1Dg8GvgvTCg1HAwWGka', 'vML2ysbcB2XPDMLH', '8j+tUeLhka', 'vgLNBYbhDwf0zw1HBge', 'zMXVB3i', 'wwfU', 'q2HVD2rODxj5', 'igHPDhmk', 'u2vVEwvVBG', 'qNj1BMe', 'BwfPBgn4q29UzMLN', 'zg9TywLUCW', 'qw1PBMfO', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29Tl2nVBMzPCM1LBwfPBc5WAha/BMv4Dd1ODhrWCYuZqsuYrIuYrND3DY5MywnLyM9VAY5JB20LmKy', 'Ahr0Chm6lY8', 'u0vmrunuiefdq09vtLqGueftu1DpuKqGtu9erq', 'nZe0', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6ntbDoG', 'tw92Axn0yxiGrwWGu2fSDMfKB3i', 'zw4Tu0mSzw47Ct0WlJKSzNi7Ct0WlJG', 'u3rHBG', 'cIaGw1nnuYbcB3DLCL0G4PYxiefIB3j0Aw5NoIa', 'l2fWAs92ms9UDw1IzxjZl3aYl2DLDa', '8j+tMcbgywnLyM9VAW', 'u2fZywTP', 'D2HHDhnHChbFAw5ZDgfSBgvKx29Ux2nSAwvUDa', 'y29YCW', 'tMLZAge', 'qNjVD24', 'sgf3yq', 'ug9WzxnJDq', 'iIbHy3rPB249iG', 'wwfTyw1VDg8', 'iMvYCM9YCYi6', 't29YzwrVBYbryxrHCG', 'mZuY', 'v2fUzW', 'Dgv4Da', 'qwnJzxb0', 'y29UDgfJDhbVAw50', 'BwvZC2fNzxm', 'y2TFBM9Uy2u', 'mJiW', 'vMfSzw50Aw5H', 'tK9uifjfr0LtvevsruqGlYbsru1pvKve', 'u2vJluzLDgnOlvnPDgu', 'vgHHBMrPD2u', 'swrH', 'zw4Tr1KSzw47Ct0WlJK', 'q2XHCM8GugfUyw1H', 'uwf0yxi', 'BgiTtfuSBgi7Ct0WlJKSzNi7Ct0WlJGSzgu7Ct0WlJC', 'zguTq0GSzgu7Ct0WlJKSzNi7Ct0WlJGSzw47Ct0WlJC', 'qxjHEwe', 'vgfUAwe', 'u2vJluzLDgnOlurLC3q', 'qwrQyq', 'C3rHCNruAw1L', 'v2LIB3DV', 'vM9KywzVBMuGrwD5Chq', 'sgfTAwq', 'zNjSx2f1DgHVCML6yxrPB25FDg9Rzw4', 'qwWTsgfZC2fU', 'ugf0zwW', 'tw9Uz2TVBa', 'CgnFzw5MB3jJzw1LBNrFB3v0y29Tzq', 'zNiTqKKSzNi7Ct0WlJKSCM47Ct0WlJG', 'yM9VA19UzxC', 'qwT1yq', 'Dgv4Dc9WBgfPBG', 'qMvSz2L1Bq', 'ww9ZAgLKyq', 'qMfYyMfYyq', 'rgLHBgXV', 'vgvSzwnLBcbAAw1Iywj3zq', 'r2L6zw0', 'q291BgLIywX5', 'u2fUzhjH', 'BMfTzq', 'Bwv0yq', 'vc1nB2jPBgu', 'C2vW', 'EwvHCG', 'tw96AwXSys81lJaGkeXPBNv4oYbbBMrYB2LKideWoYbnB2jPBguPiefWCgXLv2vIs2L0lZuZnY4ZnIaOs0HutuWSigXPA2uGr2vJA28PienOCM9Tzs8XmJqUmc4WlJaGtw9IAwXLifnHzMfYAs81mZCUmZy', 'i0zgnKi2qG', 'B3rWq29Kzq', 'tgLUzgjLCMC', 'FgzIFdeUmc4XFa', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29Tl2fWAs9NCMfWAhfSlW', 'qxjPzG', 'C2HVDwXKx3nOB3DFC3bPx2jLzM9Yzv9JB25M', 'tMf0Aa', 'AhKTqu0SAhK7Ct0WlJKSCNu7Ct0WlJGSzw47Ct0WlJC', 'qw5JAgfSAq', 'icdILze', 'vfaXqs4YmJa2mJqUmde0', 'vgLUzW', 'q0fbx1jfr19ut1m', 'q2HV', 'tK9sra', 'ndeW', 'sg9UzW', 'ktOGBM8Gzw1HAwWGCMv0DxjUzwq', 'ugfWywTVC3rHCW', 'whvL', 'CMf3tgLUzq', 'qwjLzxi', 'zw5HyMXLx3n1CNzLEq', 'qMLZD2fZ', 'tvroie5Pz2vYAwe', 'rMf0B3vTyxrH', 't21HBNrLBa', 'zNiTqKOSzNi7Ct0WlJKSzw47Ct0WlJG', 'yM4TqKqSyM47Ct0WlJKSzw47Ct0WlJG', 'wxvZDxbVDG', 'uM9Oyw5P', 'qw1Uyq', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqGzNjVBsa', 'oIdWN5sria', '8j+mKcbnzxrH', 'lJaI', 's3nLBMLH', 'AxnnywLSy3G', 'uhjLC3mGrw50zxiGDg8GCMv0CNK6', 'tM8Gy3vZDg9TigrVBwfPBNm', 'tMv0D29YAYbYzxnLDcbVBIa', 'Cg9ZDc1YzwCTCgfNzs1LCNi', 'ugvKzxjZzw4', 'sgf5zgfYB3y', 'tK9uifjfr0Ltvevsruq', 'icdINjqGrM91BMqG', 'Bg9NAw4UCgHW', 'r29SBMf6', 't1rqifrYAwDNzxjLzcbZDwnJzxnZzNvSBhK', 'rMXVCMvZ', 'mtvYC0vLDeG', 'C2vYDMLJzq', 'tMfRAg9U', 'nte2nZu5odaX', 't3bLCMeVos44mcaOqw5KCM9PzdSGtw9IAwXLoYa', 'zw4TwK0Szw47Ct0WlJK', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'vgfTyxjH', 'Ahr0Chm', 'rufg', 'mJy0', 'uNvKBW', 'lcaItwLJCM9ZB2z0ievKz2uIo3y9iG', 'ChqTtvOSChq7Ct0WlJK', 'u2HHAgXV', 'tg92zq', 'zw1HAwXFB2f1DgHFzxHPC3rZ', 'w1nfvfvqxsbezxbLBMrLBMnPzxmGAw5ZDgfSBgvKihn1y2nLC3nMDwXSEsek', 'mtzFnG', 'AxnFCMvHDxrOx3n1y2nLC3nMDwW', 'C3bLy3rYyv9YzwDFDg9Rzw4', 'ihWGif9Fx3WGx18GksaGic8Gx19FFcaGxYbCFcbFx19FFcaGlYbCxYaGif98if9Fx198', 'rNjHBSoNB2LZ', 'BwLU', 'zgLYBMfTzq', 'zMjeDhnN', 'CMvQzwn0vw5HDxrOB3jPEMvK', 'qwWTrg9ZyxjP', 'iLDPBMrVD3mI', 'sgvLBMe', 'qxPLCMjHAwPHBG', 'ugv0CM92Awm', 'r0vu', 'u2HPCMLU', 'rgfUCg9YBG', 'y29UzMLYBwvK', 'zxmTvKuSzxm7Ct0WlJKSzw47Ct0WlJG', 'zNiTr04SzNi7Ct0WlJK', 'q29SB21IAwe', 'BwvWB3n0lM5LDa', 'u25LEMfUyq', 'zNiTq0ySzNi7Ct0WlJK', 'zMKTrKKSzMK7Ct0WlJKSzw47Ct0WlJG', 'igvTywLSCYddLYa', 'u2fYyq', 'sw5KAwe', 'tMfMAxnZyxrVDq', 'BgL2zq', 'u29MAwe', 'vgvSC3rYyq', 'qw1PCMe', 'BMuTtLaSBMu7Ct0WlJKSzw47Ct0WlJG', 'vgvSzxrHBgS', 'y29UzMLYBwf0Aw9Ux21LzgL1Bq', 'wwvYAw4', 'twfOBgfUz3u', 'sxnHyMvSBge', 'tgLNzxi', 'u2fUy2HLEG', 'q2vSy29TrgLNAq', 'twv6AwfUzq', 'A2v5CW', 'tMfKyq', 'qwWTs2HHBgLK', 'tM9VCMe', 'cIaG4PYxifvWzgf0zsbYzxf1AxjLzceGugXLyxnLigrVD25SB2fKihrOzsbSyxrLC3qGDMvYC2LVBI4k', 'ugHHBq', '8j+uKIbbDxrVlwDLBMvYyxrLihjHBMrVBsbWyxnZD29YzcaOzs5NlIbty3jHCgvYAZKYAImP', 'sM9HBM5H', 'u2fIywzVBG', 'uMLUyq', 'oIdIJ7mGug9SBgLUzYbnywLSC2LUAYbpvfaGzM9Yia', 'rgf2Awq', 'zNiTuKuSzNi7Ct0WlJK', 'ks4UlG', 'BwfWAwTLEq', 'CMvZDwX0CW', 'DxbKyxrLx3jLCxvPCMvK', '8j+nJIbbChbSzsbtywzHCMK', 'rw50zxiGvgfYz2v0CYbgAwXLifbHDgG6', 'BMv4yw90ChnLCNzPy2uUy29T', 'D2fZx2HLywrLCNnFChjLzMLSBf9HDMfPBgfIBgu', 's3v3ywL0', 'rgLHBG', 'tM8Gt1rqihjLy2vPDMvKigLUidKWCYbMB3iG', 'sxnTywLS', 'vxnLCI1bz2vUDa', 'swjYywHPBq', '4OYO77Ipien1C3rVBs4UlG', 'ig51BwjLCNmGka', 'zw5JCNLWDgvKx21ZAxnKBL9MB3jFC2fMzxr5BMv0', 'mZqYmJuYmdK2nta0ntKWntC', 'v2fOExu', 'ixjLzG', 'qMvYDhjHBMq', 'uMvHDxrOzw50AwnHDgLUzYbWyxnZD29Yzcb3AxrOigTLEv9Pzd0', 'qM91EwD1zxm', 'twvOCM5HEG', 'zMeTsviSzMe7Ct0WlJKSzw47Ct0WlJG', 'vc1nB2jPBguGq1O', 'rxn0zwXSzq', 'u21ZqM93zxiGDgLTzw91Da', 'cIaG4PYxiezHDgfSigvYCM9YoIa', 'qNvSDxq', 'CgfKu3rHCNq', 'q291BgqGBM90igv4DhjHy3qGBhnKigzYB20GBg9NAw4GCgfNzq', 'l2v0yY9TywnOAw5LlwLK', 'BMv3x3rVx2zHBwLSEv9MyL9KzwzHDwX0', 'u2LTB24', 'qwWTsgfTywq', 'vMfSAxLLDG', 'wNDHBMu', 'iKnOCM9TAxvTiJT2psi', 'Ahr0Chm6lY9TyMfZAwmUzMfJzwjVB2SUy29Tl2HVBwuUCgHW', 'zM9YBwf0', 'twfYAwfUyq', 'wMLLBgLUC2TP', 'yMfZzw5HBwu', 'rgfUzYbuAgK', 'rxrPC2fSyxqGrwD5Chq', '4QYf77IpiejHy2S', 'r2vUzxjHDgLUzYbut1rqihnLy3jLDcbRzxKUlI4', 'qKfmsW', 'BhyTtfySBhy7Ct0WlJKSCNu7Ct0WlJGSzw47Ct0WlJC', 'tK9FqunusvzbveLptG', 'twfPBc5JEcbbueKGvg9Rzw4GzM91BMqGka', 'r2XV', 'iM1Hy09tiG', 'rgPVCMrQzxzPyW', 'uhjHC2v0Ew8', 'sgf0AwnL', 'C2HPzNq', 'twvP', 'icbgqIbdt05gsvjniokaLcbsvu4Gq09nueXfveuGicaGicaGicaGicaGicaGicaGia', 'ugHVzwjL', 'zgLYzwn0', 'txv0Dwe', 'u3rHDNjVDwXH', 'EMvUzxG', 'C29TzwXVCMeUy29T', 'u2vSzwn0ihjHBMDLCZO', 'mta0mZm2nJuYnq', 'Ew91DgHFy29UC2vUDf9KzwnPC2LVBL90Aw1L', 'qZPCv2LUzg93C1XtExn0zw0ZmLXxAw5KB3DZug93zxjtAgvSBfX2ms4WxhbVD2vYC2HLBgWUzxHLic1oB1bYB2zPBguGlunVBw1HBMqGiG', 'twLUyq', 'C3bLy3rYyv9YzwDFz3vHCMrPyw5FAwq', 'ugfWywrVCg91Bg9Z', 't1rqifrYAwDNzxjLza', 't1vute9ps19ftufjta', 'Aw5IB3Hjza', 'rw50zxiGBMv3igTLEq', 'zNvSBenVB2TPzq', 'BwfPBgn4', 'sgLUza', 'BwCTtuCSBwC7Ct0WlJKSzNi7Ct0WlJG', 'mJe1mtjdr3vqr0O', 'vgf0AwfUyq', 'zw5JCNLWDgvKx21ZAxnKBG', 'C2vJlwnOlxvHlxbSyxrMB3jT', 'vhvYAYbuzwXLA29T', 'zw4TwKeSzw47Ct0WlJK', 'DxnLCL9VChrLzf9VDxrFB2zFBNrW', 'AhLKCMe6BwvTyMvY', 'twfZy29T', 'zw4Tr0iSzw47Ct0WlJK', 'uMLRBW', 'qxvZDhjPyq', 'l3yXl2LUyM94zxmV', 'u3vIBwL0DgLUzYaYrKeGzw1HAwWGt1rqoIa', 'nZmW', 'qwWTt2jLAwrP', 'y29UC3rHBNrZ', 'cIaGw1PLBMv4xsbtDhjLyw1PBMCG', 'vxbNCMfKzs1jBNnLy3vYzs1szxf1zxn0CW', 'vhnPDhnP', 'l21LC3nHz2vZ', 'yxiTqKGSyxi7Ct0WlJKSzw47Ct0WlJG', 'mtqUmc4W', 'ug9YBNbHBG', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl3n1y2nLC3mTB3rW', 'zg93BG', 'ugfWywrHA2LZ', 'qwXLBxu', 'qxvYzwXPzq', 'ndaW', 'vM9KywzVBMuGvuS', 'qwLNDwW', 'ugf1Ba', 'DM9SDhG', 's0ressbbvq', 'yxbPx2TLEq'];
  fn1 = function () {
    return v724;
  };
  return fn1();
}
v104["United States"] = v1, v104.US = v2, v104['United\x20Kingdom'] = v3, v104.GB = v4, v104.Canada = v5, v104.CA = v6, v104.Australia = v7, v104.AU = v8, v104.Germany = v9, v104.DE = v10, v104.France = v11, v104.FR = v12, v104.Italy = v13, v104.IT = v14, v104.Spain = v15, v104.ES = v16, v104.Netherlands = v17, v104.NL = v18, v104.Brazil = v19, v104.BR = v20, v104.Indonesia = v21, v104.ID = v22, v104.Turkey = v23, v104["Türkiye"] = v24, v104.TR = v25, v104.Russia = v26, v104.RU = v27, v104.India = v28, v104.IN = v29, v104.Pakistan = v30, v104.PK = v31, v104.Bangladesh = v32, v104.BD = v33, v104.Vietnam = v34, v104.VN = v35, v104.Thailand = v36, v104.TH = v37, v104.Philippines = v38, v104.PH = v39, v104.Malaysia = v40, v104.MY = v41, v104.Poland = v42, v104.PL = v43, v104.Romania = v44, v104.RO = v45, v104.Ukraine = v46, v104.UA = v47, v104.Sweden = v48, v104.SE = v49, v104.Norway = v50, v104.NO = v51, v104.Denmark = v52, v104.DK = v53, v104.Finland = v54, v104.FI = v55, v104.Greece = v56, v104.GR = v57, v104.Ireland = v58, v104.IE = v59, v104.Switzerland = v60, v104.CH = v61, v104.Austria = v62, v104.AT = v63, v104.Belgium = v64, v104.BE = v65, v104['Czech\x20Republic'] = v66, v104.Czechia = v67, v104.CZ = v68, v104.Hungary = v69, v104.HU = v70, v104.Portugal = v71, v104.PT = v72, v104.Bahrain = v73, v104.BH = v74, v104["United Arab Emirates"] = v75, v104.AE = v76, v104["Saudi Arabia"] = v77, v104.SA = v78, v104.Egypt = v79, v104.EG = v80, v104["South Africa"] = v81, v104.ZA = v82, v104.Nigeria = v83, v104.NG = v84, v104.Kenya = v85, v104.KE = v86, v104["New Zealand"] = v87, v104.NZ = v88, v104.Mexico = v89, v104.MX = v90, v104.Argentina = v91, v104.AR = v92, v104.Colombia = v93, v104.CO = v94, v104.Chile = v95, v104.CL = v96, v104.Peru = v97, v104.PE = v98, v104.Japan = v99, v104.JP = v100, v104["South Korea"] = v101, v104.Korea = v102, v104.KR = v103;
const COUNTRY_TO_GEO = v104;
function getGeoFromCountry(v725) {
  if (!v725 || v725 === "Unknown" || v725 === 'Direct') {
    const v728 = {};
    return v728.iso = 'US', v728.lang = "en-US,en;q=0.9", v728.name = "United States", v728;
  }
  const v726 = v725.trim();
  if (COUNTRY_TO_GEO[v726]) {
    const v729 = {
      ...COUNTRY_TO_GEO[v726]
    };
    return v729.name = v726, v729;
  }
  for (const [, v730, v731] of DIAL_MAP) {
    if (v730.toUpperCase() === v726.toUpperCase()) {
      const v732 = {};
      return v732.iso = v730, v732.lang = v731, v732.name = v726, v732;
    }
  }
  const v727 = {};
  v727.iso = 'US';
  return v727.lang = "en-US,en;q=0.9", v727.name = v726, v727;
}
const v105 = {};
v105.name = "Grameenphone", v105.mcc = "470", v105.mnc = '01';
const v106 = {};
v106.name = "Robi", v106.mcc = "470", v106.mnc = '02';
const v107 = {};
v107.name = "Banglalink", v107.mcc = "470", v107.mnc = '03';
const v108 = {};
v108.name = "Teletalk", v108.mcc = '470', v108.mnc = '04';
const v109 = {};
v109.name = "MPT", v109.mcc = "414", v109.mnc = '01';
const v110 = {};
v110.name = "Ooredoo Myanmar", v110.mcc = "414", v110.mnc = '05';
const v111 = {};
v111.name = "Atom (Telenor)", v111.mcc = "414", v111.mnc = '06';
const v112 = {};
v112.name = "Mytel", v112.mcc = "414", v112.mnc = '09';
const v113 = {};
v113.name = "Reliance Jio", v113.mcc = "405", v113.mnc = "854";
const v114 = {};
v114.name = "Airtel", v114.mcc = "404", v114.mnc = '45';
const v115 = {};
v115.name = "Vodafone Idea", v115.mcc = "404", v115.mnc = '86';
const v116 = {};
v116.name = "BSNL", v116.mcc = '404', v116.mnc = '34';
const v117 = {};
v117.name = "Jazz", v117.mcc = '410', v117.mnc = '01';
const v118 = {};
v118.name = "Zong", v118.mcc = "410", v118.mnc = '04';
const v119 = {};
v119.name = "Telenor Pakistan", v119.mcc = "410", v119.mnc = '06';
const v120 = {};
v120.name = "Ufone", v120.mcc = "410", v120.mnc = '03';
const v121 = {};
v121.name = "AT&T", v121.mcc = '310', v121.mnc = "410";
const v122 = {};
v122.name = "T-Mobile", v122.mcc = "310", v122.mnc = "260";
const v123 = {};
v123.name = "Verizon", v123.mcc = "311", v123.mnc = '480';
const v124 = {};
v124.name = 'EE', v124.mcc = "234", v124.mnc = '30';
const v125 = {};
v125.name = 'O2', v125.mcc = "234", v125.mnc = '10';
const v126 = {};
v126.name = "Vodafone UK", v126.mcc = "234", v126.mnc = '15';
const v127 = {};
v127.name = "Three UK", v127.mcc = "234", v127.mnc = '20';
const v128 = {};
v128.name = 'Telekom', v128.mcc = "262", v128.mnc = '01';
const v129 = {};
v129.name = 'Vodafone', v129.mcc = '262', v129.mnc = '02';
const v130 = {};
v130.name = "O2 Germany", v130.mcc = "262", v130.mnc = '07';
const v131 = {};
v131.name = "Orange", v131.mcc = "208", v131.mnc = '01';
const v132 = {};
v132.name = "SFR", v132.mcc = '208', v132.mnc = '10';
const v133 = {};
v133.name = "Bouygues", v133.mcc = "208", v133.mnc = '20';
const v134 = {};
v134.name = "Free Mobile", v134.mcc = '208';
v134.mnc = '15';
const v135 = {};
function fn2(v733, v734) {
  v733 = v733 - 0xcc;
  const v735 = fn1();
  let v736 = v735[v733];
  if (fn2.ANVwEi === undefined) {
    var fn17 = function (v740) {
      let v741 = '',
        v742 = '',
        v743 = v741 + fn17,
        v744 = ('' + function () {
          return 0x0;
        }).indexOf('\x0a') !== -1;
      for (let v745 = 0x0, v746, v747, v748 = 0x0; v747 = v740.charAt(v748++); ~v747 && (v746 = v745 % 0x4 ? v746 * 0x40 + v747 : v747, v745++ % 0x4) ? v741 += v744 || v743.charCodeAt(v748 + 0xa) - 0xa !== 0x0 ? String.fromCharCode(0xff & v746 >> (-2 * v745 & 0x6)) : v745 : 0x0) {
        v747 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(v747);
      }
      for (let v749 = 0x0, v750 = v741.length; v749 < v750; v749++) {
        v742 += '%' + ('00' + v741.charCodeAt(v749).toString(0x10)).slice(-2);
      }
      return decodeURIComponent(v742);
    };
    fn2.ClMAzK = fn17, fn2.kHlGhc = {}, fn2.ANVwEi = true;
  }
  const v737 = v735[0x0],
    v738 = v733 + v737,
    v739 = fn2.kHlGhc[v738];
  if (!v739) {
    const fn18 = function (v751) {
      this.QXyeyI = v751, this.Lpjgjx = [0x1, 0x0, 0x0], this.wGMrZW = function () {
        return 'newState';
      }, this.kztqwK = '\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*', this.DViFXS = '[\x27|\x22].+[\x27|\x22];?\x20*}';
    };
    fn18.prototype.ToHyQK = function () {
      const v752 = new RegExp(this.kztqwK + this.DViFXS),
        v753 = v752.test(this.wGMrZW.toString()) ? --this.Lpjgjx[0x1] : --this.Lpjgjx[0x0];
      return this.NqmETi(v753);
    }, fn18.prototype.NqmETi = function (v754) {
      if (!Boolean(~v754)) return v754;
      return this.pJEAkn(this.QXyeyI);
    }, fn18.prototype.pJEAkn = function (v755) {
      for (let v756 = 0x0, v757 = this.Lpjgjx.length; v756 < v757; v756++) {
        this.Lpjgjx.push(Math.round(Math.random())), v757 = this.Lpjgjx.length;
      }
      return v755(this.Lpjgjx[0x0]);
    }, ('' + function () {
      return 0x0;
    }).indexOf('\x0a') === -1 && new fn18(fn2).ToHyQK(), v736 = fn2.ClMAzK(v736), fn2.kHlGhc[v738] = v736;
  } else v736 = v739;
  return v736;
}
v135.name = "Etisalat", v135.mcc = '424', v135.mnc = '02';
const v136 = {};
v136.name = 'du', v136.mcc = "424", v136.mnc = '03';
const v137 = {};
v137.name = "STC", v137.mcc = "420", v137.mnc = '01';
const v138 = {};
v138.name = "Mobily", v138.mcc = "420", v138.mnc = '03';
const v139 = {};
v139.name = "Zain", v139.mcc = "420", v139.mnc = '04';
const v140 = {};
v140.name = "Telkomsel", v140.mcc = "510", v140.mnc = '10';
const v141 = {};
v141.name = "Indosat", v141.mcc = "510", v141.mnc = '01';
const v142 = {};
v142.name = "XL Axiata", v142.mcc = "510", v142.mnc = '11';
const v143 = {};
v143.name = "Smartfren", v143.mcc = '510', v143.mnc = '09';
const v144 = {};
v144.name = "Globe", v144.mcc = "515", v144.mnc = '02';
const v145 = {};
v145.name = "Smart", v145.mcc = "515", v145.mnc = '03';
const v146 = {};
v146.name = "DITO", v146.mcc = '515', v146.mnc = '66';
const v147 = {};
v147.name = "AIS", v147.mcc = "520", v147.mnc = '01';
const v148 = {};
v148.name = "TrueMove", v148.mcc = "520", v148.mnc = '05';
const v149 = {};
v149.name = "DTAC", v149.mcc = "520", v149.mnc = '18';
const v150 = {};
v150.name = "Maxis", v150.mcc = "502", v150.mnc = '12';
const v151 = {};
v151.name = "CelcomDigi", v151.mcc = "502", v151.mnc = '16';
const v152 = {};
v152.name = "U Mobile", v152.mcc = "502", v152.mnc = '18';
const v153 = {};
v153.name = "Singtel", v153.mcc = "525", v153.mnc = '01';
const v154 = {};
v154.name = "StarHub", v154.mcc = "525", v154.mnc = '05';
const v155 = {};
v155.name = 'M1', v155.mcc = "525", v155.mnc = '03';
const v156 = {};
v156.name = "Telstra", v156.mcc = "505", v156.mnc = '01';
const v157 = {};
v157.name = "Optus", v157.mcc = '505', v157.mnc = '02';
const v158 = {};
v158.name = "Vodafone AU", v158.mcc = "505", v158.mnc = '03';
const v159 = {};
v159.name = "Rogers", v159.mcc = '302', v159.mnc = "720";
const v160 = {};
v160.name = "Bell", v160.mcc = '302', v160.mnc = '610';
const v161 = {};
v161.name = "Telus", v161.mcc = "302", v161.mnc = "220";
const v162 = {};
v162.name = "Vivo", v162.mcc = '724', v162.mnc = '06';
const v163 = {};
v163.name = "Claro", v163.mcc = "724", v163.mnc = '05';
const v164 = {};
v164.name = "TIM", v164.mcc = "724", v164.mnc = '04';
const v165 = {};
v165.name = "Vodacom", v165.mcc = "655", v165.mnc = '01';
const v166 = {};
v166.name = 'MTN', v166.mcc = "655", v166.mnc = '10';
const v167 = {};
v167.name = "Cell C", v167.mcc = "655", v167.mnc = '07';
const v168 = {};
v168.name = "MTN Nigeria", v168.mcc = '621', v168.mnc = '30';
const v169 = {};
v169.name = "Airtel Nigeria", v169.mcc = "621", v169.mnc = '20';
const v170 = {};
v170.name = "Glo", v170.mcc = "621", v170.mnc = '50';
const v171 = {};
v171.name = '9mobile', v171.mcc = "621", v171.mnc = '60';
const v172 = {};
v172.name = "Orange Egypt", v172.mcc = "602", v172.mnc = '01';
const v173 = {};
v173.name = "Vodafone Egypt", v173.mcc = "602", v173.mnc = '02';
const v174 = {};
v174.name = "Etisalat Egypt", v174.mcc = '602', v174.mnc = '03';
const v175 = {};
v175.name = 'WE', v175.mcc = "602", v175.mnc = '04';
const v176 = {};
v176.name = 'Turkcell', v176.mcc = "286", v176.mnc = '01';
const v177 = {};
v177.name = "Vodafone TR", v177.mcc = "286", v177.mnc = '02';
const v178 = {};
v178.name = "Turk Telekom", v178.mcc = "286", v178.mnc = '03';
const v179 = {};
v179.name = "MTS", v179.mcc = "250", v179.mnc = '01';
const v180 = {};
v180.name = "MegaFon", v180.mcc = "250", v180.mnc = '02';
const v181 = {};
v181.name = 'Beeline', v181.mcc = "250", v181.mnc = '99';
const v182 = {};
v182.name = "Tele2", v182.mcc = "250", v182.mnc = '20';
const v183 = {};
v183.name = "NTT Docomo", v183.mcc = "440", v183.mnc = '10';
const v184 = {};
v184.name = "KDDI AU", v184.mcc = "440", v184.mnc = '50';
const v185 = {};
v185.name = "SoftBank", v185.mcc = "440", v185.mnc = '20';
const v186 = {};
v186.name = "Rakuten Mobile", v186.mcc = '440', v186.mnc = '11';
const v187 = {};
v187.name = "SK Telecom", v187.mcc = "450", v187.mnc = '05';
const v188 = {};
v188.name = 'KT', v188.mcc = "450", v188.mnc = '08';
const v189 = {};
v189.name = 'LG\x20U+', v189.mcc = "450", v189.mnc = '06';
const v190 = {};
v190.name = "Afghan Wireless", v190.mcc = "412", v190.mnc = '01';
const v191 = {};
v191.name = "Roshan", v191.mcc = "412", v191.mnc = '20';
const v192 = {};
v192.name = "Etisalat Afghanistan", v192.mcc = "412", v192.mnc = '50';
const v193 = {};
v193.name = "MTN Afghanistan", v193.mcc = "412", v193.mnc = '40';
const v194 = {};
v194.name = "Vodafone Albania", v194.mcc = "276", v194.mnc = '02';
const v195 = {};
v195.name = "One Telecommunications", v195.mcc = '276', v195.mnc = '01';
const v196 = {};
v196.name = "ALBtelecom", v196.mcc = "276", v196.mnc = '03';
const v197 = {};
v197.name = "Djezzy", v197.mcc = "603", v197.mnc = '02';
const v198 = {};
v198.name = "Mobilis", v198.mcc = "603", v198.mnc = '01';
const v199 = {};
v199.name = 'Ooredoo\x20Algeria', v199.mcc = "603", v199.mnc = '03';
const v200 = {};
v200.name = "Movistar", v200.mcc = '722', v200.mnc = '07';
const v201 = {};
v201.name = "Claro", v201.mcc = "722", v201.mnc = "310";
const v202 = {};
v202.name = "Personal", v202.mcc = "722", v202.mnc = '34';
const v203 = {};
v203.name = 'Viva-MTS', v203.mcc = "283", v203.mnc = '01';
const v204 = {};
v204.name = "Beeline Armenia", v204.mcc = "283", v204.mnc = '04';
const v205 = {};
v205.name = "Ucom", v205.mcc = '283', v205.mnc = '05';
const v206 = {};
v206.name = "A1 Telekom", v206.mcc = "232", v206.mnc = '01';
const v207 = {};
v207.name = "Magenta Telekom", v207.mcc = '232', v207.mnc = '03';
const v208 = {};
v208.name = 'Drei', v208.mcc = "232", v208.mnc = '05';
const v209 = {};
v209.name = "Azercell", v209.mcc = '400', v209.mnc = '01';
const v210 = {};
v210.name = 'Bakcell', v210.mcc = "400", v210.mnc = '02';
const v211 = {};
v211.name = "Nar Mobile", v211.mcc = "400", v211.mnc = '04';
const v212 = {};
v212.name = "MTS Belarus", v212.mcc = "257", v212.mnc = '02';
const v213 = {};
v213.name = 'A1\x20Belarus', v213.mcc = "257", v213.mnc = '01';
const v214 = {};
v214.name = "life:)", v214.mcc = "257", v214.mnc = '04';
const v215 = {};
v215.name = "Proximus", v215.mcc = '206', v215.mnc = '01';
const v216 = {};
v216.name = "Orange Belgium", v216.mcc = "206", v216.mnc = '10';
const v217 = {};
v217.name = "Telenet/Base", v217.mcc = "206", v217.mnc = '20';
const v218 = {};
v218.name = "Entel Bolivia", v218.mcc = "736", v218.mnc = '01';
const v219 = {};
v219.name = "Tigo Bolivia", v219.mcc = "736", v219.mnc = '02';
const v220 = {};
v220.name = "Viva Bolivia", v220.mcc = "736", v220.mnc = '03';
const v221 = {};
v221.name = "BH Telecom", v221.mcc = "218", v221.mnc = '90';
const v222 = {};
v222.name = "HT Eronet", v222.mcc = "218", v222.mnc = '03';
const v223 = {};
v223.name = "m:tel", v223.mcc = '218', v223.mnc = '05';
const v224 = {};
v224.name = "Mascom", v224.mcc = "652", v224.mnc = '01';
const v225 = {};
v225.name = "Orange Botswana", v225.mcc = "652", v225.mnc = '02';
const v226 = {};
v226.name = "BTC Mobile", v226.mcc = "652", v226.mnc = '04';
const v227 = {};
v227.name = 'Entel\x20Chile', v227.mcc = '730', v227.mnc = '01';
const v228 = {};
v228.name = "Movistar Chile", v228.mcc = '730', v228.mnc = '02';
const v229 = {};
v229.name = "Claro Chile", v229.mcc = "730", v229.mnc = '03';
const v230 = {};
v230.name = "Claro Colombia", v230.mcc = "732", v230.mnc = '101';
const v231 = {};
v231.name = 'Movistar\x20Colombia', v231.mcc = "732", v231.mnc = "123";
const v232 = {};
v232.name = "Tigo Colombia", v232.mcc = "732", v232.mnc = "103";
const v233 = {};
v233.name = 'Kolbi\x20ICE', v233.mcc = "712", v233.mnc = '01';
const v234 = {};
v234.name = "Claro Costa Rica", v234.mcc = "712", v234.mnc = '03';
const v235 = {};
v235.name = 'Movistar\x20Costa\x20Rica', v235.mcc = "712", v235.mnc = '04';
const v236 = {};
v236.name = "Hrvatski Telekom", v236.mcc = '219', v236.mnc = '01';
const v237 = {};
v237.name = "A1 Croatia", v237.mcc = "219", v237.mnc = '10';
const v238 = {};
v238.name = 'Telemach', v238.mcc = "219", v238.mnc = '02';
const v239 = {};
v239.name = "T-Mobile CZ", v239.mcc = "230", v239.mnc = '01';
const v240 = {};
v240.name = "O2 Czech Republic", v240.mcc = "230", v240.mnc = '02';
const v241 = {};
v241.name = 'Vodafone\x20CZ', v241.mcc = '230', v241.mnc = '03';
const v242 = {};
v242.name = "TDC", v242.mcc = "238", v242.mnc = '01';
const v243 = {};
v243.name = 'Telenor\x20Denmark', v243.mcc = "238", v243.mnc = '02';
const v244 = {};
v244.name = "Telia Denmark", v244.mcc = '238', v244.mnc = '20';
const v245 = {};
v245.name = "Claro DR", v245.mcc = "370", v245.mnc = '02';
const v246 = {};
v246.name = "Altice", v246.mcc = "370", v246.mnc = '01';
const v247 = {};
v247.name = "Viva", v247.mcc = '370', v247.mnc = '04';
const v248 = {};
v248.name = "Claro Ecuador", v248.mcc = "740", v248.mnc = '01';
const v249 = {};
v249.name = "Movistar Ecuador", v249.mcc = "740", v249.mnc = '00';
const v250 = {};
v250.name = "CNT", v250.mcc = '740', v250.mnc = '02';
const v251 = {};
v251.name = "Claro El Salvador", v251.mcc = "706", v251.mnc = '01';
const v252 = {};
v252.name = 'Tigo\x20El\x20Salvador', v252.mcc = "706", v252.mnc = '02';
const v253 = {};
v253.name = "Movistar El Salvador", v253.mcc = "706", v253.mnc = '04';
const v254 = {};
v254.name = "Tigo Guatemala", v254.mcc = "704", v254.mnc = '01';
const v255 = {};
v255.name = "Claro Guatemala", v255.mcc = "704", v255.mnc = '02';
const v256 = {};
v256.name = "Movistar Guatemala", v256.mcc = "704", v256.mnc = '03';
const v257 = {};
v257.name = "Tigo Honduras", v257.mcc = '708', v257.mnc = '01';
const v258 = {};
v258.name = "Claro Honduras", v258.mcc = '708', v258.mnc = '02';
const v259 = {};
v259.name = "Zain Jordan", v259.mcc = "416", v259.mnc = '01';
const v260 = {};
v260.name = "Orange Jordan", v260.mcc = "416", v260.mnc = '77';
const v261 = {};
v261.name = "Umniah", v261.mcc = "416", v261.mnc = '03';
const v262 = {};
v262.name = "Touch", v262.mcc = '415', v262.mnc = '03';
const v263 = {};
v263.name = "Alfa", v263.mcc = "415", v263.mnc = '01';
const v264 = {};
v264.name = "Orange Mali", v264.mcc = "610", v264.mnc = '02';
const v265 = {};
v265.name = 'Malitel', v265.mcc = "610", v265.mnc = '01';
const v266 = {};
v266.name = "Telecel Mali", v266.mcc = "610", v266.mnc = '03';
const v267 = {};
v267.name = "Claro Nicaragua", v267.mcc = '710', v267.mnc = '21';
const v268 = {};
v268.name = "Tigo Nicaragua", v268.mcc = "710", v268.mnc = '73';
const v269 = {};
v269.name = "Ooredoo Oman", v269.mcc = "422", v269.mnc = '02';
const v270 = {};
v270.name = "Omantel", v270.mcc = '422', v270.mnc = '03';
const v271 = {};
v271.name = "Claro Panama", v271.mcc = "714", v271.mnc = '03';
const v272 = {};
v272.name = "Digicel Panama", v272.mcc = "714", v272.mnc = '04';
const v273 = {};
v273.name = "Movistar Panama", v273.mcc = "714", v273.mnc = '02';
const v274 = {};
v274.name = "Tigo Paraguay", v274.mcc = "744", v274.mnc = '04';
const v275 = {};
v275.name = "Claro Paraguay", v275.mcc = "744", v275.mnc = '02';
const v276 = {};
v276.name = "Personal Paraguay", v276.mcc = "744", v276.mnc = '01';
const v277 = {};
v277.name = "Ooredoo Qatar", v277.mcc = "427", v277.mnc = '01';
const v278 = {};
v278.name = "Vodafone Qatar", v278.mcc = '427', v278.mnc = '02';
const v279 = {};
v279.name = "Orange Senegal", v279.mcc = "608", v279.mnc = '01';
const v280 = {};
v280.name = "Free Senegal", v280.mcc = "608", v280.mnc = '02';
const v281 = {};
v281.name = "Expresso Senegal", v281.mcc = "608", v281.mnc = '03';
const v282 = {};
v282.name = "Zain Sudan", v282.mcc = "634", v282.mnc = '01';
const v283 = {};
v283.name = "MTN Sudan", v283.mcc = "634", v283.mnc = '02';
const v284 = {};
v284.name = "Sudani", v284.mcc = "634", v284.mnc = '07';
const v285 = {};
v285.name = "Vodacom Tanzania", v285.mcc = "640", v285.mnc = '04';
const v286 = {};
v286.name = "Airtel Tanzania", v286.mcc = "640", v286.mnc = '03';
const v287 = {};
v287.name = "Tigo Tanzania", v287.mcc = "640", v287.mnc = '02';
const v288 = {};
v288.name = 'Halotel', v288.mcc = '640', v288.mnc = '08';
const v289 = {};
v289.name = "MTN Uganda", v289.mcc = "641", v289.mnc = '10';
const v290 = {};
v290.name = "Airtel Uganda", v290.mcc = "641", v290.mnc = '14';
const v291 = {};
v291.name = "Ucell", v291.mcc = "434", v291.mnc = '05';
const v292 = {};
v292.name = 'Beeline\x20UZ', v292.mcc = "434", v292.mnc = '04';
const v293 = {};
v293.name = "Uzmobile", v293.mcc = "434", v293.mnc = '01';
const v294 = {};
v294.name = "Yemen Mobile", v294.mcc = '421', v294.mnc = '02';
const v295 = {};
v295.name = "Sabafon", v295.mcc = "421", v295.mnc = '01';
const v296 = {};
v296.name = "MTN Yemen", v296.mcc = "421", v296.mnc = '03';
const v297 = {};
v297.name = "MTN Zambia", v297.mcc = "645", v297.mnc = '01';
const v298 = {};
v298.name = 'Airtel\x20Zambia', v298.mcc = "645", v298.mnc = '02';
const v299 = {};
v299.name = "Zamtel", v299.mcc = "645", v299.mnc = '03';
const v300 = {};
v300.name = 'Econet\x20Zimbabwe', v300.mcc = "648", v300.mnc = '04';
const v301 = {};
v301.name = "NetOne", v301.mcc = "648", v301.mnc = '01';
const v302 = {};
v302.name = "Telecel Zimbabwe", v302.mcc = "648", v302.mnc = '03';
const v303 = {};
v303.Bangladesh = [v105, v106, v107, v108], v303.Myanmar = [v109, v110, v111, v112], v303.India = [v113, v114, v115, v116], v303.Pakistan = [v117, v118, v119, v120], v303["United States"] = [v121, v122, v123], v303["United Kingdom"] = [v124, v125, v126, v127], v303.Germany = [v128, v129, v130], v303.France = [v131, v132, v133, v134], v303.UAE = [v135, v136], v303["Saudi Arabia"] = [v137, v138, v139], v303.Indonesia = [v140, v141, v142, v143], v303.Philippines = [v144, v145, v146], v303.Thailand = [v147, v148, v149], v303.Malaysia = [v150, v151, v152], v303.Singapore = [v153, v154, v155], v303.Australia = [v156, v157, v158], v303.Canada = [v159, v160, v161], v303.Brazil = [v162, v163, v164], v303["South Africa"] = [v165, v166, v167], v303.Nigeria = [v168, v169, v170, v171], v303.Egypt = [v172, v173, v174, v175], v303.Turkey = [v176, v177, v178], v303.Russia = [v179, v180, v181, v182], v303.Japan = [v183, v184, v185, v186], v303["South Korea"] = [v187, v188, v189], v303.Afghanistan = [v190, v191, v192, v193], v303.Albania = [v194, v195, v196], v303.Algeria = [v197, v198, v199], v303.Argentina = [v200, v201, v202], v303.Armenia = [v203, v204, v205], v303.Austria = [v206, v207, v208], v303.Azerbaijan = [v209, v210, v211], v303.Belarus = [v212, v213, v214], v303.Belgium = [v215, v216, v217], v303.Bolivia = [v218, v219, v220], v303["Bosnia and Herzegovina"] = [v221, v222, v223], v303.Botswana = [v224, v225, v226], v303.Chile = [v227, v228, v229], v303.Colombia = [v230, v231, v232], v303['Costa\x20Rica'] = [v233, v234, v235], v303.Croatia = [v236, v237, v238], v303.Czechia = [v239, v240, v241], v303.Denmark = [v242, v243, v244], v303["Dominican Republic"] = [v245, v246, v247], v303.Ecuador = [v248, v249, v250], v303["El Salvador"] = [v251, v252, v253], v303.Guatemala = [v254, v255, v256], v303.Honduras = [v257, v258], v303.Jordan = [v259, v260, v261], v303.Lebanon = [v262, v263], v303.Mali = [v264, v265, v266], v303.Nicaragua = [v267, v268], v303.Oman = [v269, v270], v303.Panama = [v271, v272, v273], v303.Paraguay = [v274, v275, v276], v303.Qatar = [v277, v278], v303.Senegal = [v279, v280, v281], v303.Sudan = [v282, v283, v284], v303.Tanzania = [v285, v286, v287, v288], v303.Uganda = [v289, v290], v303.Uzbekistan = [v291, v292, v293], v303.Yemen = [v294, v295, v296], v303.Zambia = [v297, v298, v299], v303.Zimbabwe = [v300, v301, v302];
const CARRIERS_BY_COUNTRY = v303;
function getRandomCarrier(v758) {
  const v759 = {};
  v759.BD = "Bangladesh", v759.MM = "Myanmar", v759.IN = 'India', v759.PK = "Pakistan", v759.US = 'United\x20States', v759.GB = "United Kingdom", v759.DE = "Germany", v759.FR = 'France', v759.AE = 'UAE', v759.SA = "Saudi Arabia", v759.ID = "Indonesia", v759.PH = "Philippines", v759.TH = 'Thailand', v759.MY = "Malaysia", v759.SG = "Singapore", v759.AU = 'Australia', v759.CA = "Canada", v759.BR = "Brazil", v759.ZA = "South Africa", v759.NG = "Nigeria", v759.EG = "Egypt", v759.TR = "Turkey", v759.RU = 'Russia', v759.JP = "Japan", v759.KR = "South Korea", v759.AF = "Afghanistan", v759.AL = "Albania", v759.DZ = "Algeria", v759.AR = "Argentina", v759.AM = "Armenia", v759.AT = 'Austria', v759.AZ = "Azerbaijan", v759.BY = "Belarus", v759.BE = "Belgium";
  v759.BO = "Bolivia", v759.BA = "Bosnia and Herzegovina", v759.BW = "Botswana", v759.CL = 'Chile', v759.CO = 'Colombia', v759.CR = 'Costa\x20Rica', v759.HR = "Croatia", v759.CZ = "Czechia", v759.DK = 'Denmark', v759.DO = 'Dominican\x20Republic', v759.EC = "Ecuador", v759.SV = "El Salvador", v759.EE = "Estonia", v759.FI = "Finland", v759.GH = 'Ghana', v759.GR = "Greece", v759.GT = "Guatemala", v759.HU = 'Hungary', v759.IS = "Iceland", v759.IE = "Ireland", v759.IL = "Israel", v759.KZ = 'Kazakhstan';
  v759.KE = "Kenya", v759.KW = "Kuwait", v759.LV = "Latvia", v759.LT = "Lithuania", v759.LU = 'Luxembourg', v759.MA = "Morocco", v759.NP = "Nepal", v759.NZ = "New Zealand", v759.NO = "Norway", v759.PE = "Peru", v759.PL = "Poland", v759.PT = "Portugal", v759.RO = "Romania", v759.RS = 'Serbia', v759.SK = "Slovakia", v759.SI = "Slovenia", v759.LK = 'Sri\x20Lanka', v759.SE = "Sweden", v759.CH = "Switzerland", v759.TN = "Tunisia", v759.UA = "Ukraine", v759.UY = "Uruguay", v759.VE = "Venezuela", v759.VN = "Vietnam";
  const v760 = v759,
    v761 = v760[v758] || 'United\x20States',
    v762 = CARRIERS_BY_COUNTRY[v761] || CARRIERS_BY_COUNTRY['United\x20States'],
    v763 = {};
  v763.name = 'AT&T', v763.mcc = "310", v763.mnc = '410';
  if (!v762 || v762.length === 0x0) return v763;
  return v762[Math.floor(Math.random() * v762.length)];
}
function generateRandomDOB() {
  const v764 = Math.floor(Math.random() * 16) + 0x7c6;
  const v765 = Math.floor(Math.random() * 0xc) + 0x1;
  const v766 = Math.floor(Math.random() * 0x1c) + 0x1;
  return {
    'day': v766,
    'month': v765,
    'year': v764,
    'full': v764 + '-' + String(v765).padStart(0x2, '0') + '-' + String(v766).padStart(0x2, '0')
  };
}
function generateRandomPassword(v767 = 'auto') {
  let v768 = '';
  for (let v769 = 0x0; v769 < 0x5; v769++) v768 += "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%"[Math.floor(Math.random() * "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%".length)];
  if (v767 === 'random_date' || v767 === "date") {
    const v770 = new Date(),
      v771 = String(v770.getDate()),
      v772 = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"],
      v773 = v772[v770.getMonth()] || "aug",
      v774 = '' + v771 + v773;
    return "Rex" + v768 + v774;
  }
  return 'Rex' + v768;
}
function generateRandomName(v775 = 'US') {
  const v776 = {};
  v776.f = ['Aminata', "Fatou", "Mariama", 'Aissatou', "Rokhaya", "Khady", "Seynabou", "Coumba", "Fatoumata", "Kadiatou", "Awa", "Bintou", "Ramata", "Oumou", "Djeneba", "Adja", "Mame", "Astou", "Ndeye", "Maimouna", "Mariam", "Salimata", 'Haby', "Kadija", "Nafissatou"], v776.l = ["Diallo", "Ndiaye", "Sow", 'Ba', 'Diop', "Thiam", "Sarr", 'Fall', "Kane", 'Cisse', "Coulibaly", 'Traore', "Keita", "Sangare", "Camara", "Bah", 'Barry', 'Sylla', "Kouyate", "Conde", "Kone", 'Ouattara', "Bamba", 'Toure', "Dembele", "Koita", "Soumare", "Fofana", 'Doumbia', "Sidibe"];
  const v777 = {};
  v777.f = ["Ngozi", "Amaka", "Chioma", "Blessing", "Grace", 'Folake', 'Aisha', "Fatima", 'Kemi', "Yetunde", "Ama", "Akua", "Abena", "Adwoa", "Efua", "Esi", "Abena", "Akosua", "Yaa", "Adjoa", "Isata", "Fatu", "Aminata", "Mariama", "Hawa", "Kumba", 'Adama', "Kadiatu", 'Sia', "Memuna"], v777.l = ["Okonkwo", "Adeyemi", "Ibrahim", "Musa", "Bello", "Okafor", "Eze", "Abubakar", "Lawal", "Osei", "Mensah", "Asante", "Boateng", "Owusu", 'Amoah', "Darko", 'Amponsah', "Quansah", 'Antwi', "Appiah", 'Kamara', "Koroma", "Sesay", "Bangura", "Conteh", 'Turay', "Jalloh", "Sheriff", "Kargbo", "Mansaray"];
  const v778 = {};
  v778.f = ["Wanjiru", "Achieng", "Fatuma", "Grace", "Faith", "Mary", "Amina", "Naomi", "Rahel", "Tigist", "Meseret", 'Hiwot', "Bethlehem", "Selam", "Biruk", "Liyu", "Meron", "Yeshi", "Tizita", 'Almaz', 'Zawadi', "Neema", "Upendo", "Rehema", "Zuhura", "Hadija", "Salma", "Fatuma", 'Mwanaidi', "Jamila"], v778.l = ["Kamau", 'Odhiambo', "Muthoni", "Waweru", "Otieno", 'Njoroge', "Kimani", 'Mwangi', "Njeru", 'Karanja', "Tesfaye", "Bekele", "Haile", 'Tadesse', "Girma", "Mekonnen", "Alemu", 'Wolde', "Yilma", "Demisse", "Mwamba", "Mwangi", "Ouma", "Auma", 'Onyango', "Okello", 'Mbeki', "Mutua", 'Kariuki', "Ngugi"];
  const v779 = {};
  v779.f = ["Tendai", "Rudo", 'Chipo', "Tsitsi", "Rutendo", "Blessing", "Thabo", "Nomsa", "Zanele", "Lindiwe", "Sizwe", "Nokwanda", 'Nompumelelo', "Ayanda", "Sibongile", 'Mutinta', "Mwape", 'Namakau', "Chanda", "Chipego", "Thandiwe", "Phindile", "Nokukhanya", "Nomthandazo", "Bongiwe", 'Lungelo', 'Khosi', "Ntokozo", "Thandi", "Sithembile"], v779.l = ['Mutasa', "Ncube", "Moyo", "Ndlovu", "Mpofu", "Dube", 'Sibanda', "Mhlanga", "Nkomo", 'Khumalo', "Banda", "Tembo", "Phiri", "Mwale", "Zulu", 'Dlamini', "Nkosi", "Mahlangu", 'Khoza', "Molefe", "Dlamini", "Zwane", "Simelane", "Nxumalo", "Shabangu", "Maseko", "Hlophe", "Mthethwa", 'Mswati', "Ntshalintshali"];
  const v780 = {};
  v780.f = ["Fatima", "Nadia", "Khadija", "Imane", "Zineb", "Amina", "Sara", "Meriem", "Yasmine", "Lynda", "Nour", "Soumia", 'Hanane', "Lamia", 'Hajar', 'Siham', "Ghizlane", "Salma", "Oumaima", "Rania", "Sana", "Ilham", "Sabrina", "Naima", "Wafa", "Loubna", "Meryem", "Hind", "Chaimae", 'Nisrine'], v780.l = ["Bennani", "El Idrissi", "Chraibi", "Benali", "Bouazza", "Alaoui", "Filali", "Tazi", 'Berrada', "Bensouda", "Benali", "Boudiaf", "Khelil", "Meziane", "Hadj", "Belhadj", "Benyahia", "Messaoudi", "Benabdallah", "Saidi", "Zghal", "Trabelsi", "Bourguiba", "Ayari", "Belhaj", "Chaabane", "Jomaa", "Hammami", "Chebbi", "Cherif"];
  const v781 = {};
  v781.f = ["Sara", "Nora", "Reem", "Haya", "Lina", 'Maryam', "Fatima", 'Mariam', "Shaikha", "Hessa", "Noora", 'Latifa', "Maitha", "Shamsa", "Meera", "Dana", "Moza", "Ghada", 'Afra', 'Wadha', "Rana", 'Hind', "Aisha", "Layla", "Najla", "Dalal", "Lulwa", "Amira", "Shama", 'Lubna'], v781.l = ["Al-Ghamdi", "Al-Harbi", 'Al-Otaibi', 'Al-Shehri', "Al-Zahrani", "Al-Qahtani", "Al-Dosari", "Al-Khalid", "Al-Mansoori", 'Al-Shamsi', "Al-Mazrouei", 'Al-Rashidi', "Al-Hamad", "Al-Kuwari", "Al-Thani", "Al-Marri", "Al-Balushi", "Al-Habsi", "Al-Hinai", "Al-Rawahi", "Al-Rashdi", "Al-Kalbani", "Al-Amri", 'Al-Saidi'];
  const v782 = {};
  v782.f = ['Sara', "Rima", "Nada", 'Mona', 'Hala', "Zahra", "Noor", "Lara", "Rana", "Dima", "Maya", "Lina", "Farah", "Ruba", "Sana", "Jana", "Nadia", "Reem", "Dalia", 'Noura', "Marwa", "Heba", "Ola", "Amira", "Samar", "Abeer", 'Ghada', "Yasmine", "Salam", "Widad"], v782.l = ["Al-Hassan", "Al-Ahmad", "Khalil", "Ibrahim", "Mustafa", "Hassan", "Mohamed", "Abdullah", 'Mahmoud', "Yousef", 'Al-Hashimi', "Al-Azzawi", "Al-Saadi", "Al-Jubouri", "Al-Dulaimi", "Al-Janabi", "Al-Obeidi", "Al-Tamimi", "Al-Masri", "Al-Souri", "Tabbara", "Khoury", 'Makhoul', "Haddad", "Nassar", "Azar", "Gemayel", "Sabbagh"];
  const v783 = {};
  v783.f = ["Maryam", "Zahra", 'Sara', "Fatemeh", "Narges", "Shirin", 'Nasrin', "Leila", "Mahnaz", "Parisa", "Nazanin", "Bahar", "Baran", "Golnaz", "Shabnam", "Simin", "Azar", "Mehrnaz", "Roya", "Negar"], v783.l = ["Ahmadi", "Hosseini", "Mohammadi", "Rezaei", 'Karimi', 'Moradi', "Najafi", "Sadeghi", "Mousavi", 'Tehrani', "Jafari", "Shirazi", 'Esfahani', "Mashhadi", "Tabatabaei", "Khorasani", "Mazaheri", "Rahmani", 'Ghorbani', "Salehi"];
  const v784 = {};
  v784.f = ["Ayse", 'Fatma', "Zeynep", 'Elif', 'Emine', "Hatice", 'Meryem', "Rabia", 'Esra', "Selin", 'Nisa', "Yildiz", 'Gulsum', "Sevgi", "Nur", "Arzu", "Derya", 'Ebru', "Gizem", "Ilknur"], v784.l = ['Yilmaz', "Kaya", 'Demir', "Celik", "Sahin", 'Ozturk', "Arslan", 'Dogan', "Kilic", "Aslan", 'Koc', "Caliskan", "Ozdemir", "Turk", "Kaplan", "Aydın", "Guler", "Polat", "Yildiz", "Bulut"];
  const v785 = {};
  v785.f = ["Priya", "Pooja", 'Anjali', 'Neha', 'Sunita', "Kavitha", "Divya", "Rekha", 'Ananya', "Deepa", 'Asha', "Lakshmi", "Meena", "Nisha", "Radha", 'Savitha', "Usha", "Vijaya", "Swati", 'Preeti', "Shreya", 'Ritika', "Pallavi", "Sneha", "Shweta", "Madhuri", "Komal", "Heena", "Bhavna", 'Reena'], v785.l = ['Sharma', "Singh", "Kumar", "Patel", "Verma", 'Nair', "Reddy", 'Gupta', 'Rao', "Joshi", "Mehta", "Shah", "Pillai", "Menon", "Iyer", "Mukherjee", "Banerjee", "Chatterjee", "Das", "Roy", "Chopra", "Kapoor", "Malhotra", 'Bose', "Ghosh", "Sinha", "Tiwari", "Dubey", "Pandey", "Mishra"];
  const v786 = {};
  v786.f = ["Fatima", "Aisha", "Zainab", 'Sara', "Nadia", "Sana", "Hira", "Noor", 'Maria', "Rabia", "Amna", "Mehwish", "Saba", 'Bushra', "Asma", "Faiza", "Naila", "Uzma", 'Samina', "Rukhsana"], v786.l = ["Khan", "Ahmed", "Ali", "Hassan", "Malik", 'Sheikh', "Iqbal", "Hussain", "Qureshi", 'Chaudhry', "Raza", "Mirza", "Siddiqui", "Butt", 'Cheema', "Bajwa", "Niazi", "Bhatti", "Javed", 'Dar'];
  const v787 = {};
  v787.f = ["Fatema", "Nasrin", "Sonia", "Ruma", "Mitu", "Tania", "Nipa", "Riya", 'Mumu', 'Bristy', 'Sumaiya', "Farida", 'Salma', "Rehana", "Laila", "Asma", "Nusrat", "Shahida", 'Moriam', "Rina"], v787.l = ["Rahman", "Islam", "Hossain", 'Ahmed', "Ali", "Khan", "Begum", "Akter", "Khanam", "Sultana", "Chowdhury", 'Sarkar', "Mondal", "Sheikh", "Mia", "Biswas", "Dey", "Paul", "Nath", "Roy"];
  const v788 = {};
  v788.f = ["Chamari", "Dilini", 'Nadeeka', "Sachini", "Thilini", "Sanduni", "Niluka", "Madushani", 'Ishara', "Hasini"], v788.l = ["Perera", "Silva", 'Fernando', 'Jayasinghe', "Wickramasinghe", 'Gunasekara', "Rajapaksa", "Dissanayake", "Senanayake", 'Jayawardena'];
  const v789 = {};
  v789.f = ['Aye', 'Khin', 'Ma', "Myint", 'Ni', "Phyu", 'Su', "Thida", 'Win', "Zin", 'Chomnan', "Dara", "Ratana", "Srey", "Kolab"], v789.l = ['Aung', "Kyaw", "Min", "Myo", 'Naing', 'Oo', "Thant", "Tin", 'Win', "Zaw", "Sok", "Chan", "Lim", 'Peng', "Khmer"];
  const v790 = {};
  v790.f = ["Nurul", "Siti", 'Nur', "Farah", 'Aisyah', "Nabilah", "Izzati", "Hidayah", 'Amirah', "Syafiqah", "Zainab", "Ramlah", 'Hasnah', 'Noraini', "Aminah", "Rohani", "Norzahra", "Suraya", "Azizah", 'Hamidah'], v790.l = ['Ahmad', "Ismail", "Abdullah", "Ibrahim", 'Rahmat', 'Hashim', 'Osman', 'Aziz', "Rahim", "Hamid", "Yusof", "Kassim", "Mohd", "Omar", "Mansor", "Salleh", "Noor", "Saad", "Arif", 'Razali'];
  const v791 = {};
  v791.f = ["Siti", "Nur", "Dewi", "Rina", 'Fitri', 'Lestari', "Wulandari", "Rahayu", "Indah", "Wahyu", "Putri", "Sari", "Ayu", "Ratna", "Evi", "Dian", "Sri", 'Nita', "Rini", "Yuli"], v791.l = ["Susanto", "Wijaya", "Santoso", "Hidayat", "Rahayu", "Saputra", "Kurniawan", "Permana", "Nugroho", "Wahyudi", 'Purnama', "Setiawan", 'Gunawan', "Hermawan", "Prasetyo", "Suryadi", "Wibowo", "Kusuma", 'Sutrisno', "Hendro"];
  const v792 = {};
  v792.f = ["Maria", 'Ana', "Rose", "Grace", 'Joy', "Love", "Angel", "Faith", "Hope", 'Liza', "Marites", "Cynthia", "Rowena", "Cecile", 'Shirley', "Leonora", "Erlinda", "Gloria", "Teresita", "Corazon"], v792.l = ["Santos", 'Reyes', "Cruz", "Garcia", "Flores", "Torres", "Gomez", "Ramos", "Lopez", "Perez", 'Dela\x20Cruz', "Villanueva", "Bautista", "Castillo", "Mendoza", "Espiritu", "Aquino", 'Vergara', "Aguilar", "Pascual"];
  const v793 = {};
  v793.f = ["Nguyen Thi", "Tran Thi", "Le Thi", "Pham Thi", "Hoang Thi", "Vo Thi", "Dang Thi", "Bui Thi", "Do Thi", 'Ha\x20Thi'], v793.l = ["Nguyen", 'Tran', 'Le', "Pham", "Hoang", 'Vo', "Dang", 'Bui', 'Do', "Ngo", 'Ho', "Dinh", "Duong", "Vuong", "Mai"];
  const v794 = {};
  v794.f = ['Nipa', "Anchali", "Somjai", "Siriporn", "Wilaiporn", "Naruemon", "Pornpan", "Supawan", 'Jiranan', "Ratchanee", "Araya", "Chanida", 'Duanpen', "Ekkarat", "Fah", "Gaew", 'Hathai', "Ing", "Janya", "Kanjana"], v794.l = ['Srisai', 'Boonma', "Chaiyarat", "Danporn", "Eamthai", "Faithip", "Gritsana", 'Hongsri', "Intaruk", "Jaidee", "Kaewkam", "Leelaporn", "Mongkol", "Nakhon", "Orathai", "Phromma", "Ratana", "Sombat", "Thiamsuk", 'Ubon'];
  const v795 = {};
  v795.f = ["Wei", "Fang", "Min", 'Li', 'Na', "Juan", "Ting", "Jing", "Hong", "Ying", "Xue", "Lin", "Xiao", "Yan", "Hui", "Mei", 'Ping', "Rong", "Qing", "Zhen"], v795.l = ["Wang", 'Li', "Zhang", "Liu", "Chen", "Yang", "Huang", "Zhao", 'Wu', "Zhou", 'Xu', 'Sun', 'Ma', "Zhu", 'Hu', "Guo", 'He', 'Gao', "Lin", "Luo"];
  const v796 = {};
  v796.f = ["Yuki", "Hana", 'Sakura', "Aoi", 'Rin', 'Akane', "Miyu", "Nana", "Yuna", "Saki", "Riko", 'Koharu', "Hinata", "Yume", "Natsuki", "Risa", 'Honoka', "Mio", "Kana", 'Ai'], v796.l = ["Sato", "Suzuki", "Takahashi", "Tanaka", "Watanabe", 'Ito', "Yamamoto", "Nakamura", 'Kobayashi', "Kato", "Yoshida", "Yamada", "Sasaki", "Yamaguchi", 'Saito', 'Matsumoto', "Inoue", "Kimura", 'Hayashi', 'Shimizu'];
  const v797 = {};
  v797.f = ["Jiyeon", "Minji", "Seoyeon", 'Jisoo', 'Chaeyoung', 'Nayeon', "Jihyo", "Sana", "Mina", 'Dahyun', "Yeji", "Ryujin", "Chaeryeong", "Yuna", "Lia", "Sowon", "Yerin", 'Eunha', "SinB", "Umji"], v797.l = ['Kim', 'Lee', "Park", "Choi", "Jung", "Han", 'Yoon', "Shin", 'Oh', "Kwon", "Jang", "Lim", "Cho", "Baek", "Song", "Kang", "Ryu", 'Jeon', 'Ko', "Hong"];
  const v798 = {};
  v798.f = ["Aigul", "Ainur", "Aizat", "Aruzhan", 'Dana', 'Dinara', "Gulnara", "Kamila", "Madina", "Malika", "Nilufar", "Nozima", 'Ozoda', "Sarvinoz", "Shahlo", 'Sitora', "Zulfiya", "Gulbahor", 'Muazzam', "Feruza"], v798.l = ['Karimov', "Rahimov", "Umarov", "Toshmatov", "Yusupov", "Nazarov", "Mirzaev", "Ismoilov", "Xasanov", 'Qodirov', "Nurmatov", "Haydarov", "Ergashev", "Sobirov", "Abdullayev", "Alimov", "Hasanov", "Mammadov", "Valiyev", "Guliyev"];
  const v799 = {};
  v799.f = ["Ani", "Nare", "Mariam", "Anahit", 'Lusine', 'Narineh', 'Arevik', 'Tamar', "Nino", "Manana", 'Salome', "Maka", "Tekla", "Keto", "Shorena", "Leila", "Lali", "Nana", "Eka", "Khatuna"], v799.l = ["Mkrtchyan", "Grigoryan", "Petrosyan", "Harutyunyan", 'Gevorgyan', "Sargsyan", "Hovhannisyan", 'Vardanyan', "Khachatryan", "Abrahamyan", "Beridze", "Kapanadze", "Chikaidze", "Gabisonia", "Khvedelidze", "Gurgenidze", "Nebieridze", 'Tevdoradze', "Jikia", "Tkeshelashvili"];
  const v800 = {};
  v800.f = ["Anastasia", "Ekaterina", "Olga", "Natalia", "Irina", "Maria", "Elena", "Anna", "Tatiana", "Oksana", 'Victoria', 'Yulia', "Darya", "Ksenia", 'Alina', 'Veronika', 'Svetlana', "Galina", "Lyudmila", "Nadezhda"], v800.l = ["Ivanov", 'Smirnov', "Petrov", 'Sokolov', 'Volkov', 'Lebedev', 'Kozlov', "Novikov", "Morozov", "Popov", "Romanov", "Kuznetsov", "Fedorov", 'Mikhailov', "Alexeyev", 'Frolov', "Nikitin", "Pavlov", "Savelyev", 'Zaitsev'];
  const v801 = {};
  v801.f = ["Katarzyna", "Magdalena", 'Anna', "Agnieszka", 'Marta', "Karolina", "Joanna", 'Monika', "Natalia", 'Barbara', 'Ioana', "Maria", "Elena", 'Ana', "Alexandra", "Cristina", 'Mihaela', "Andreea", "Roxana", "Claudia"], v801.l = ["Kowalski", "Nowak", 'Wisniewski', "Wojciechowski", "Kowalczyk", "Kaminski", "Lewandowski", "Zielinski", "Szymanski", "Wozniak", "Popescu", 'Ionescu', "Popa", 'Constantin', "Gheorghe", "Dumitru", "Stan", 'Stoica', "Marin", "Badea"];
  const v802 = {};
  v802.f = ["Camille", "Emma", 'Lea', 'Manon', "Chloe", "Julie", "Marie", "Sophie", "Laura", "Pauline", "Alice", "Mathilde", 'Lucie', "Charlotte", 'Clementine', "Juliette", 'Margot', "Amelie", "Aurelie", "Estelle"], v802.l = ["Martin", "Bernard", "Thomas", "Petit", "Robert", "Richard", 'Durand', "Dupont", "Moreau", 'Laurent', "Simon", 'Michel', "Lefebvre", "Leroy", "Roux", "David", "Bertrand", "Morin", "Fournier", "Girard"];
  const v803 = {};
  v803.f = ['Emma', "Hannah", "Mia", 'Sofia', 'Lena', "Anna", "Leonie", "Emilia", 'Clara', 'Laura', "Lisa", "Marie", "Sarah", "Julia", "Katharina", "Sabrina", "Sandra", "Nicole", "Claudia", 'Stephanie'], v803.l = ["Muller", "Schmidt", 'Schneider', "Fischer", "Weber", 'Meyer', "Wagner", "Becker", "Schulz", "Hoffmann", "Schatz", 'Koch', "Bauer", "Richter", "Klein", "Wolf", 'Schroeder', "Neumann", "Schwarz", "Braun"];
  const v804 = {};
  v804.f = ["Maria", "Carmen", 'Ana', "Isabel", "Laura", 'Marta', "Sofia", "Lucia", "Alba", "Paula", "Elena", "Sara", "Andrea", "Natalia", "Patricia", 'Cristina', 'Raquel', "Monica", "Beatriz", 'Alicia'], v804.l = ["Garcia", "Martinez", "Lopez", "Sanchez", "Gonzalez", "Rodriguez", 'Fernandez', "Perez", "Gomez", "Martin", "Jimenez", "Ruiz", "Hernandez", "Diaz", "Moreno", "Muñoz", "Alvarez", "Romero", "Alonso", "Gutierrez"];
  const v805 = {};
  v805.f = ["Ana", "Maria", "Margarida", "Joana", 'Beatriz', "Catarina", 'Carolina', "Ines", "Filipa", "Raquel", 'Gabriela', 'Juliana', "Larissa", "Camila", 'Leticia', "Fernanda", "Bruna", "Amanda", "Tatiane", 'Renata'], v805.l = ["Silva", "Santos", "Oliveira", "Souza", "Lima", "Rodrigues", "Ferreira", "Carvalho", "Alves", "Lopes", "Pereira", "Martins", 'Ribeiro', "Gomes", "Fernandes", "Costa", "Correia", "Neves", "Sousa", "Cunha"];
  const v806 = {};
  v806.f = ['Giulia', 'Sofia', "Aurora", "Alice", "Chiara", "Sara", "Valentina", 'Martina', "Federica", "Francesca", "Elisa", "Roberta", "Claudia", 'Silvia', 'Laura', 'Paola', "Monica", "Stefania", "Antonella", "Raffaella"], v806.l = ["Rossi", "Ferrari", "Esposito", "Bianchi", "Romano", "Colombo", "Ricci", "Marino", "Greco", "Bruno", 'Gallo', "Conti", "De Luca", "Costa", "Mancini", "Fontana", "Caruso", "Lombardi", "Mariani", 'Barbieri'];
  const v807 = {};
  v807.f = ["Amelia", "Olivia", "Isla", "Ava", "Emily", 'Sophie', "Grace", 'Lily', "Isabella", 'Ella', "Charlotte", 'Mia', "Evie", 'Hannah', 'Lucy', "Daisy", "Phoebe", "Chloe", "Alice", "Florence"], v807.l = ["Smith", "Jones", "Williams", "Taylor", "Brown", "Davies", "Evans", "Wilson", "Thomas", "Roberts", "Johnson", "Walker", "White", "Martin", "Thompson", "Robinson", "Hall", "Green", 'Wood', "Jackson"];
  const v808 = {};
  v808.f = ["Emma", "Maja", "Astrid", "Elsa", "Ingrid", 'Sigrid', "Freya", "Thea", 'Sara', 'Anna', "Sofia", 'Emilia', "Ida", "Lena", "Hanna", "Karolina", 'Johanna', "Helena", "Kristina", "Maria"], v808.l = ["Andersen", "Hansen", "Jensen", "Larsen", 'Nielsen', "Pedersen", "Kristiansen", "Johansen", "Eriksson", "Olsson", "Lindqvist", 'Bergstrom', "Gustafsson", "Magnusson", "Holm", "Lindberg", "Svensson", "Nilsson", "Karlsson", "Lund"];
  const v809 = {};
  v809.f = ["Katarzyna", "Magdalena", "Agnieszka", "Karolina", 'Joanna', "Monika", "Barbara", "Dorota", "Ewa", 'Malgorzata', "Tereza", "Jana", "Petra", "Veronika", "Lucie", "Marketa", "Lenka", "Martina", "Katerina", "Eva"], v809.l = ["Kowalski", "Nowak", "Wisniewski", "Wojciechowski", "Kaminski", "Lewandowski", "Zielinski", 'Szymanski', 'Wozniak', 'Jankowski', "Novak", "Dvorak", "Cerny", "Blazek", "Prochazka", "Horak", "Pospisil", 'Kadlec', 'Krejci', "Mares"];
  const v810 = {};
  v810.f = ["Ana", "Maja", "Ivana", "Milica", "Jovana", "Marina", "Tamara", "Snezana", "Dragana", "Jelena", "Marta", 'Petra', "Andrea", "Sara", "Nina", 'Lana', "Iva", "Martina", 'Barbara', "Katarina"], v810.l = ["Jovanovic", "Petrovic", 'Nikolic', "Markovic", "Djordjevic", 'Stojanovic', "Ilic", "Stankovic", "Milovanovic", "Radovanovic", "Horvat", "Kovac", "Babic", "Cavar", "Juric", "Marko", "Novak", "Petrovic", "Bilic", "Saric"];
  const v811 = {};
  v811.f = ["Maria", "Eleni", "Georgia", "Katerina", "Konstantina", 'Dimitra', "Stavroula", "Aikaterini", "Vasiliki", "Aikaterini"], v811.l = ["Papadopoulos", "Papadimitriou", "Papageorgiou", "Papakostas", "Papadakis", "Georgiadis", "Apostolou", "Nikolaou", "Konstantinidis", "Alexiou"];
  const v812 = {};
  v812.f = ['Emma', "Olivia", "Ava", "Sophia", "Isabella", "Charlotte", "Amelia", 'Mia', "Luna", 'Harper', "Evelyn", "Abigail", "Emily", "Ella", "Elizabeth", "Camila", "Luna", "Sofia", "Aria", 'Scarlett'], v812.l = ["Smith", "Johnson", "Williams", "Brown", "Jones", 'Garcia', "Miller", 'Davis', "Martinez", "Hernandez", 'Lopez', "Wilson", "Anderson", "Taylor", 'Thomas', "Moore", "Jackson", 'Martin', 'Lee', "Thompson"];
  const v813 = {};
  v813.f = ['Maria', "Guadalupe", "Sofia", 'Valentina', "Fernanda", 'Alejandra', "Daniela", "Paola", 'Camila', "Mariana", "Monica", "Veronica", "Patricia", "Adriana", "Claudia", "Liliana", "Jessica", "Sandra", "Karla", 'Diana'], v813.l = ["Garcia", 'Martinez', 'Lopez', 'Hernandez', 'Gonzalez', "Rodriguez", "Perez", "Sanchez", "Ramirez", "Torres", "Flores", "Rivera", "Gomez", "Diaz", 'Cruz', 'Morales', "Jimenez", 'Reyes', "Rojas", "Vargas"];
  const v814 = {};
  v814.f = ['Marie', "Roseline", 'Claudette', "Guerline", 'Mireille', 'Nadine', "Naomie", "Emelyne", "Jocelyne", 'Yanick'], v814.l = ["Joseph", "Jean", "Pierre", "Baptiste", "Louis", 'Paul', "François", 'Augustin', 'Duval', "Saint-Louis"];
  const v815 = {};
  v815.f = ["Marie", 'Pauline', "Valerie", 'Christelle', "Berthine", "Brigitte", "Clarisse", "Clotilde", "Germaine", "Hyacinthe"], v815.l = ["Nkurunziza", "Ndayishimiye", 'Ntibantunganya', 'Ntibazonkiza', "Nzeyimana", 'Nduwimana', "Nimubona", "Bigirimana", "Hakizimana", "Habimana"];
  const v816 = {};
  v816.WAF = v776, v816.WAE = v777, v816.EAF = v778, v816.SAF = v779, v816.NAF = v780, v816.GULF = v781, v816.LEV = v782, v816.IR = v783, v816.TR = v784, v816.IN = v785, v816.PK = v786, v816.BD = v787, v816.LK = v788, v816.MM = v789, v816.MY = v790, v816.ID = v791, v816.PH = v792, v816.VN = v793, v816.TH = v794, v816.CN = v795, v816.JP = v796, v816.KR = v797, v816.CA = v798, v816.CAU = v799, v816.RU = v800, v816.EEU = v801, v816.FR = v802, v816.DE = v803, v816.ES = v804, v816.PT = v805, v816.IT = v806, v816.GB = v807, v816.NORD = v808, v816.CEU = v809, v816.BALK = v810, v816.GR = v811, v816.EN = v812, v816.MX = v813, v816.HT = v814, v816.CAFR = v815;
  const v817 = v816,
    v818 = {};
  v818.SN = "WAF", v818.ML = "WAF", v818.GN = 'WAF', v818.CI = "WAF", v818.BF = "WAF", v818.NE = "WAF", v818.TG = "WAF", v818.BJ = "WAF", v818.MR = 'WAF', v818.GW = "WAF", v818.CV = "WAF", v818.ST = "WAF", v818.NG = "WAE", v818.GH = 'WAE', v818.SL = "WAE", v818.LR = 'WAE', v818.GM = "WAE", v818.KE = "EAF", v818.TZ = "EAF", v818.UG = "EAF", v818.ET = "EAF", v818.RW = "EAF", v818.BI = "EAF", v818.DJ = 'EAF', v818.SO = "EAF", v818.ER = "EAF", v818.SS = "EAF", v818.SD = "NAF", v818.ZW = "SAF", v818.ZM = "SAF", v818.MW = "SAF", v818.NA = "SAF", v818.BW = 'SAF', v818.SZ = "SAF", v818.LS = "SAF", v818.ZA = "SAF", v818.MZ = "SAF", v818.MG = "SAF", v818.MU = "SAF", v818.SC = "SAF", v818.KM = 'SAF', v818.RE = "SAF", v818.YT = "SAF", v818.CD = "CAFR", v818.CG = 'CAFR', v818.CF = "CAFR", v818.GA = "CAFR", v818.GQ = "CAFR", v818.AO = "CAFR", v818.EG = "NAF", v818.MA = "NAF", v818.DZ = "NAF", v818.TN = "NAF", v818.LY = 'NAF', v818.CM = "WAF", v818.SA = 'GULF', v818.AE = "GULF", v818.KW = 'GULF', v818.QA = "GULF", v818.BH = "GULF", v818.OM = "GULF", v818.JO = "LEV", v818.LB = 'LEV', v818.SY = "LEV", v818.IQ = "LEV", v818.PS = "LEV", v818.YE = "LEV", v818.IR = 'IR', v818.TR = 'TR', v818.IN = 'IN', v818.LK = 'LK', v818.NP = 'IN', v818.BT = 'IN', v818.PK = 'PK', v818.AF = 'PK', v818.BD = 'BD', v818.MM = 'MM', v818.KH = 'MM', v818.LA = 'MM', v818.MY = 'MY', v818.BN = 'MY', v818.TL = 'MY', v818.ID = 'ID', v818.PH = 'PH', v818.VN = 'VN', v818.TH = 'TH', v818.SG = 'TH', v818.CN = 'CN', v818.TW = 'CN', v818.HK = 'CN', v818.MO = 'CN', v818.JP = 'JP', v818.KR = 'KR', v818.MN = 'CN', v818.KZ = 'CA', v818.UZ = 'CA', v818.KG = 'CA', v818.TJ = 'CA', v818.TM = 'CA', v818.AM = "CAU", v818.GE = 'CAU', v818.AZ = "CAU", v818.RU = 'RU', v818.BY = 'RU', v818.MD = 'RU', v818.UA = "EEU", v818.PL = "CEU", v818.CZ = "CEU", v818.SK = 'CEU', v818.HU = "CEU", v818.RO = "EEU", v818.BG = "EEU", v818.RS = "BALK", v818.HR = 'BALK', v818.BA = "BALK", v818.ME = "BALK", v818.SI = "BALK", v818.MK = "BALK", v818.XK = "BALK", v818.AL = "BALK", v818.GR = 'GR', v818.CY = 'GR', v818.SE = "NORD", v818.NO = "NORD", v818.DK = "NORD", v818.FI = "NORD", v818.IS = "NORD", v818.DE = 'DE', v818.AT = 'DE', v818.CH = 'DE', v818.LI = 'DE', v818.LU = 'FR', v818.FR = 'FR', v818.BE = 'FR', v818.MC = 'FR', v818.ES = 'ES', v818.AD = 'ES', v818.PT = 'PT', v818.IT = 'IT', v818.SM = 'IT', v818.VA = 'IT', v818.GB = 'GB', v818.IE = 'GB', v818.MT = 'GB', v818.NL = 'DE', v818.LV = 'EEU', v818.LT = "EEU", v818.EE = "EEU", v818.SK = "CEU", v818.US = 'EN', v818.CA = 'EN', v818.AU = 'EN', v818.NZ = 'EN', v818.MX = 'MX', v818.GT = 'MX', v818.BZ = 'MX', v818.HN = 'MX', v818.SV = 'MX', v818.NI = 'MX', v818.CR = 'MX', v818.PA = 'MX', v818.CO = 'MX', v818.VE = 'MX', v818.PE = 'MX', v818.EC = 'MX', v818.BO = 'MX', v818.PY = 'MX', v818.UY = 'MX', v818.AR = 'MX', v818.CL = 'MX', v818.BR = 'PT', v818.CU = 'MX', v818.DO = 'MX', v818.PR = 'MX', v818.JM = 'EN', v818.TT = 'EN', v818.BB = 'EN', v818.BS = 'EN', v818.GY = 'EN', v818.SR = 'EN', v818.HT = 'HT', v818.MQ = 'FR', v818.GP = 'FR', v818.GF = 'FR', v818.FJ = 'EN', v818.PG = 'EN', v818.SB = 'EN', v818.VU = 'EN', v818.WS = 'EN', v818.TO = 'EN', v818.KI = 'EN', v818.TV = 'EN', v818.NR = 'EN', v818.PW = 'EN', v818.MH = 'EN', v818.FM = 'EN', v818.MV = 'IN', v818.AX = 'NORD', v818.AS = 'EN', v818.AI = 'EN', v818.AQ = 'EN', v818.AG = 'EN', v818.AW = 'MX', v818.BM = 'EN', v818.BQ = 'MX', v818.BV = "NORD", v818.IO = 'EN', v818.CX = 'EN', v818.CC = 'EN', v818.CK = 'EN', v818.CW = 'MX', v818.DM = 'EN', v818.FK = 'EN', v818.FO = 'NORD', v818.GI = 'GB', v818.GL = "NORD", v818.GD = 'EN', v818.GU = 'EN', v818.GG = 'GB', v818.HM = 'EN', v818.IM = 'GB', v818.IL = "LEV", v818.JE = 'GB', v818.KP = 'CN', v818.KY = 'EN', v818.LC = 'EN', v818.KN = 'EN', v818.VC = 'EN', v818.BL = 'FR', v818.MF = 'FR', v818.PM = 'FR', v818.SH = 'EN', v818.MS = 'EN', v818.NC = 'FR', v818.NU = 'EN', v818.NF = 'EN', v818.MP = 'EN', v818.PN = 'EN', v818.SX = 'MX', v818.GS = 'EN', v818.SJ = "NORD", v818.TC = 'EN', v818.TK = 'EN', v818.VG = 'EN', v818.VI = 'EN', v818.WF = 'FR', v818.EH = "NAF", v818.UM = 'EN', v818.TD = "CAFR", v818.PF = 'FR', v818.TF = 'FR';
  const v819 = v818,
    v820 = v819[v775] || 'EN',
    v821 = v817[v820] || v817.EN,
    v822 = Math.floor(Math.random() * v821.f.length),
    v823 = Math.floor(Math.random() * v821.l.length),
    v824 = v821.f[v822],
    v825 = v821.l[v823],
    v826 = {};
  return v826.first = v824, v826.last = v825, v826.full = v824 + '\x20' + v825, v826;
}
function getRandomClient(v827 = "random", v828 = "random") {
  const v829 = Math.floor(Math.random() * 26) + 0x7e,
    v830 = Math.floor(Math.random() * 0x7d0) + 0x1770,
    v831 = Math.floor(Math.random() * 0x12c) + 0x32,
    v832 = Math.floor(Math.random() * 13) + 0x78,
    v833 = Math.floor(Math.random() * 4) + 0xf,
    v834 = Math.floor(Math.random() * 0xc8) + 0x258,
    v835 = Math.floor(Math.random() * 11) + 0x64;
  const v836 = ["\"Not/A)Brand\";v=\"8\"", '\x22Not)A;Brand\x22;v=\x2299\x22', "\"Not;A=Brand\";v=\"8\"", '\x22Not=A?Brand\x22;v=\x228\x22', '\x22Not?A_Brand\x22;v=\x2299\x22', "\"Not_A Brand\";v=\"24\"", '\x22Not\x20A(Brand\x22;v=\x228\x22', "\"Not(A;Brand\";v=\"99\""],
    v837 = v836[Math.floor(Math.random() * v836.length)];
  let v838;
  if (v828 === "desktop") v838 = true;else {
    if (v828 === "mobile") v838 = false;else v838 = Math.random() > 0.4;
  }
  if (v838) {
    const v859 = Math.random() > 0.45,
      v860 = v859 ? "Macintosh; Intel Mac OS X 10_15_" + (Math.floor(Math.random() * 0x5) + 0x3) : 'Windows\x20NT\x20' + (Math.random() > 0.2 ? '10.0' : "11.0") + "; Win64; x64",
      v861 = v859 ? "\"macOS\"" : "\"Windows\"",
      v862 = v859 ? '\x22' + ["10.15.7", "14.0.0", "13.6.0", "14.5.0"][Math.floor(Math.random() * 0x4)] + '\x22' : '\x22' + ["10.0.0", "15.0.0", "19.0.0"][Math.floor(Math.random() * 0x3)] + '\x22';
    let v863 = v827;
    if (v827 === "random") {
      const v865 = ["chrome", "chrome", 'chrome', "firefox", "edge", 'safari', 'opera', 'brave'];
      v863 = v865[Math.floor(Math.random() * v865.length)];
    }
    if (v863 === "firefox") {
      const v866 = {};
      return v866.name = (v859 ? 'Mac' : 'Win') + " Firefox " + v832, v866.isMobile = false, v866.userAgent = 'Mozilla/5.0\x20(' + v860 + ';\x20rv:' + v832 + '.0)\x20Gecko/20100101\x20Firefox/' + v832 + '.0', v866.clientHints = {}, v866;
    }
    if (v863 === "safari" && v859) return {
      'name': "Mac Safari " + v833,
      'isMobile': false,
      'userAgent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/" + v833 + '.' + Math.floor(Math.random() * 0x5) + '.' + Math.floor(Math.random() * 0x5) + " Safari/604.1",
      'clientHints': {}
    };
    if (v863 === "edge") {
      const v867 = {};
      return v867.name = 'Win\x20Edge\x20' + v829, v867.isMobile = false, v867.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v829 + ".0." + v830 + '.' + v831 + " Safari/537.36 Edg/" + v829 + ".0." + v830 + '.' + v831, v867.clientHints = {}, v867.clientHints['sec-ch-ua'] = "\"Chromium\";v=\"" + v829 + "\", " + v837 + ", \"Microsoft Edge\";v=\"" + v829 + '\x22', v867.clientHints["sec-ch-ua-mobile"] = '?0', v867.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v867.clientHints["sec-ch-ua-platform-version"] = "\"10.0.0\"", v867;
    }
    if (v863 === "opera") {
      const v868 = {};
      return v868.name = "Opera " + v835, v868.isMobile = false, v868.userAgent = "Mozilla/5.0 (" + v860 + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v829 + ".0." + v830 + '.' + v831 + " Safari/537.36 OPR/" + v835 + ".0.0.0", v868.clientHints = {}, v868.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v829 + "\", " + v837 + ", \"Opera\";v=\"" + v835 + '\x22', v868.clientHints["sec-ch-ua-mobile"] = '?0', v868.clientHints["sec-ch-ua-platform"] = v861, v868.clientHints["sec-ch-ua-platform-version"] = v862, v868;
    }
    if (v863 === "brave") {
      const v869 = {};
      return v869.name = (v859 ? "Mac" : 'Win') + " Brave " + v829, v869.isMobile = false, v869.userAgent = v859 ? "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v829 + '.0.' + v830 + '.' + v831 + " Safari/537.36" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v829 + ".0." + v830 + '.' + v831 + '\x20Safari/537.36', v869.clientHints = {}, v869.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v829 + "\", " + v837 + ", \"Brave\";v=\"" + v829 + '\x22', v869.clientHints["sec-ch-ua-mobile"] = '?0', v869.clientHints["sec-ch-ua-platform"] = v861, v869.clientHints["sec-ch-ua-platform-version"] = v862, v869;
    }
    const v864 = {};
    return v864.name = (v859 ? 'Mac' : "Win") + " Chrome " + v829, v864.isMobile = false, v864.userAgent = v859 ? "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v829 + ".0." + v830 + '.' + v831 + " Safari/537.36" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v829 + ".0." + v830 + '.' + v831 + " Safari/537.36", v864.clientHints = {}, v864.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v829 + "\", " + v837 + ", \"Google Chrome\";v=\"" + v829 + '\x22', v864.clientHints["sec-ch-ua-mobile"] = '?0', v864.clientHints["sec-ch-ua-platform"] = v861, v864.clientHints["sec-ch-ua-platform-version"] = v862, v864;
  }
  const v839 = {};
  v839.model = "SM-G998B", v839.build = "TP1A.220624.014", v839.ver = '13';
  const v840 = {};
  v840.model = "SM-A536B", v840.build = "TP1A.220624.014", v840.ver = '13';
  const v841 = {};
  v841.model = "SM-A156E", v841.build = 'UP1A.231005.007', v841.ver = '14';
  const v842 = {};
  v842.model = "Pixel 7", v842.build = 'TP1A.220624.021', v842.ver = '13';
  const v843 = {};
  v843.model = "Pixel 8", v843.build = 'UP1A.231005.007', v843.ver = '14';
  const v844 = {};
  v844.model = "M2101K6G", v844.build = "SKQ1.211006.001", v844.ver = '12';
  const v845 = {};
  v845.model = "CPH2357", v845.build = 'TP1A.220624.014', v845.ver = '13';
  const v846 = {};
  v846.model = 'RMX3363', v846.build = 'TP1A.220624.014', v846.ver = '12';
  const v847 = {};
  v847.model = "V2309A", v847.build = 'TP1A.220624.014', v847.ver = '13';
  const v848 = {};
  v848.model = "motorola edge 40", v848.build = "T3SQS33.73-17", v848.ver = '13';
  const v849 = [v839, v840, v841, v842, v843, v844, v845, v846, v847, v848],
    v850 = {};
  v850.model = 'iPhone16,2', v850.ios = "17_4_1";
  const v851 = {};
  v851.model = "iPhone15,3", v851.ios = "17_0";
  const v852 = {};
  v852.model = 'iPhone14,2', v852.ios = "16_6";
  const v853 = {};
  v853.model = "iPhone13,2", v853.ios = "15_8";
  const v854 = {};
  v854.model = "iPhone12,1", v854.ios = "15_7";
  const v855 = [v850, v851, v852, v853, v854];
  let v856 = v827;
  if (v827 === "random") {
    const v870 = ["chrome_android", "chrome_android", "chrome_android", "ios_safari", "ios_safari", 'samsung', "firefox_android", "ios_chrome", 'uc_browser'];
    v856 = v870[Math.floor(Math.random() * v870.length)];
  } else {
    if (["chrome", "safari"].includes(v827)) v856 = Math.random() > 0.5 ? 'chrome_android' : "ios_safari";else {
      if (v827 === "firefox") v856 = "firefox_android";else {
        if (v827 === "edge") v856 = "chrome_android";else v827 === "opera" && (v856 = "opera_mini");
      }
    }
  }
  if (v856 === "ios_safari" || v856 === "safari") {
    const v871 = v855[Math.floor(Math.random() * v855.length)],
      v872 = Math.floor(Math.random() * 0xc8) + 0x258,
      v873 = {};
    return v873.name = "iOS Safari (" + v871.model + ')', v873.isMobile = true, v873.userAgent = 'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x20' + v871.ios + " like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/" + v833 + ".0 Mobile/15E148 Safari/604.1", v873.clientHints = {}, v873;
  }
  if (v856 === "ios_chrome") {
    const v874 = v855[Math.floor(Math.random() * v855.length)],
      v875 = {};
    return v875.name = "iOS Chrome (" + v874.model + ')', v875.isMobile = true, v875.userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS " + v874.ios + " like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/" + v829 + ".0." + v830 + '.' + v831 + " Mobile/15E148 Safari/604.1", v875.clientHints = {}, v875;
  }
  if (v856 === 'samsung') {
    const v876 = v849.filter(v879 => v879.model.startsWith("SM-"))[Math.floor(Math.random() * 0x4)],
      v877 = Math.floor(Math.random() * 7) + 0x14,
      v878 = {};
    return v878.name = "Samsung Browser " + v877 + '\x20(' + v876.model + ')', v878.isMobile = true, v878.userAgent = "Mozilla/5.0 (Linux; Android " + v876.ver + ';\x20' + v876.model + ") AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/" + v877 + ".0 Chrome/" + v829 + ".0." + v830 + '.' + v831 + '\x20Mobile\x20Safari/537.36', v878.clientHints = {}, v878.clientHints["sec-ch-ua"] = "\"Samsung Internet\";v=\"" + v877 + "\", " + v837 + ',\x20\x22Chromium\x22;v=\x22' + v829 + '\x22', v878.clientHints['sec-ch-ua-mobile'] = '?1', v878.clientHints['sec-ch-ua-platform'] = "\"Android\"", v878.clientHints["sec-ch-ua-platform-version"] = '\x22' + v876.ver + '.0\x22', v878;
  }
  if (v856 === "firefox_android") {
    const v880 = v849[Math.floor(Math.random() * v849.length)],
      v881 = {};
    return v881.name = "Firefox Android " + v832 + '\x20(' + v880.model + ')', v881.isMobile = true, v881.userAgent = "Mozilla/5.0 (Android " + v880.ver + "; Mobile; rv:" + v832 + '.0)\x20Gecko/' + v832 + ".0 Firefox/" + v832 + '.0', v881.clientHints = {}, v881;
  }
  if (v856 === "uc_browser") {
    const v882 = v849[Math.floor(Math.random() * v849.length)],
      v883 = "13." + Math.floor(Math.random() * 0x5) + '.' + Math.floor(Math.random() * 0x9) + '.' + (Math.floor(Math.random() * 0x4b0) + 0x3e8),
      v884 = {};
    return v884.name = 'UC\x20Browser\x20(' + v882.model + ')', v884.isMobile = true, v884.userAgent = "Mozilla/5.0 (Linux; U; Android " + v882.ver + ';\x20en-US;\x20' + v882.model + " Build/" + v882.build + ')\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Version/4.0\x20UCBrowser/' + v883 + " Mobile Safari/537.36", v884.clientHints = {}, v884;
  }
  if (v856 === "opera_mini") {
    const v885 = v849[Math.floor(Math.random() * v849.length)],
      v886 = {};
    return v886.name = 'Opera\x20Mini\x20(' + v885.model + ')', v886.isMobile = true, v886.userAgent = "Opera/9.80 (Android; Mobile; " + v885.model + '/' + v885.build + ") Presto/2.12.407 Version/" + v835 + '.0', v886.clientHints = {}, v886;
  }
  const v857 = v849[Math.floor(Math.random() * v849.length)],
    v858 = {};
  return v858.name = "Android Chrome " + v829 + '\x20(' + v857.model + ')', v858.isMobile = true, v858.userAgent = "Mozilla/5.0 (Linux; Android " + v857.ver + ';\x20' + v857.model + " Build/" + v857.build + "; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/" + v829 + '.0.' + v830 + '.' + v831 + " Mobile Safari/537.36", v858.clientHints = {}, v858.clientHints["sec-ch-ua"] = '\x22Chromium\x22;v=\x22' + v829 + '\x22,\x20' + v837 + ", \"Google Chrome\";v=\"" + v829 + '\x22', v858.clientHints["sec-ch-ua-mobile"] = '?1', v858.clientHints["sec-ch-ua-platform"] = "\"Android\"", v858.clientHints["sec-ch-ua-platform-version"] = '\x22' + v857.ver + ".0\"", v858;
}
function parseProxy(v887) {
  if (!v887) return null;
  if (typeof v887 === 'object') return v887;
  v887 = v887.trim();
  if (!v887) return null;
  let v888, v889, v890, v891;
  v887.includes("://") && (v887 = v887.split("://")[0x1]);
  if (v887.includes('@')) {
    const v892 = v887.split('@'),
      v893 = v892[0x0].split(':'),
      v894 = v892[0x1].split(':');
    v890 = v893[0x0], v891 = v893[0x1], v888 = v894[0x0], v889 = parseInt(v894[0x1]);
  } else {
    const v895 = v887.split(':');
    if (v895.length === 0x2) v888 = v895[0x0], v889 = parseInt(v895[0x1]);else {
      if (v895.length === 0x4) {
        if (!isNaN(parseInt(v895[0x1])) && parseInt(v895[0x1]).toString() === v895[0x1]) v888 = v895[0x0], v889 = parseInt(v895[0x1]), v890 = v895[0x2], v891 = v895[0x3];else !isNaN(parseInt(v895[0x3])) && parseInt(v895[0x3]).toString() === v895[0x3] ? (v890 = v895[0x0], v891 = v895[0x1], v888 = v895[0x2], v889 = parseInt(v895[0x3])) : (v888 = v895[0x0], v889 = parseInt(v895[0x1]), v890 = v895[0x2], v891 = v895[0x3]);
      } else v895.length === 0x3 && (v888 = v895[0x0], v889 = parseInt(v895[0x1]), v890 = v895[0x2]);
    }
  }
  if (!v888 || !v889 || isNaN(v889)) return null;
  return {
    'type': v887.includes("socks") ? 'socks5' : 'http',
    'host': v888,
    'port': v889,
    'user': v890,
    'pass': v891,
    'original': v887
  };
}
function rotateSessionId(v896) {
  if (!v896 || !v896.user) return v896;
  const v897 = {
      ...v896
    },
    v898 = v897;
  if (v898.user.includes("-ssid-")) {
    const v899 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
    v898.user = v898.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v899);
  } else {
    if (v898.user.includes('-session-')) {
      const v900 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
      v898.user = v898.user.replace(/-session-[A-Za-z0-9_]+/, '-session-' + v900);
    } else {
      if (v898.user.includes("-sess-")) {
        const v901 = crypto.randomBytes(0x6).toString('base64').replace(/[+/=]/g, '').substring(0x0, 0xa);
        v898.user = v898.user.replace(/-sess-[A-Za-z0-9_]+/, '-sess-' + v901);
      } else {
        if (v898.user.includes("_session_")) {
          const v902 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
          v898.user = v898.user.replace(/_session_[A-Za-z0-9_]+/, "_session_" + v902);
        } else {
          if (v898.user.includes('_sid_')) {
            const v903 = Math.floor(0x989680 + Math.random() * 0x55d4a80).toString();
            v898.user = v898.user.replace(/_sid_\d+/, "_sid_" + v903);
          }
        }
      }
    }
  }
  return v898;
}
function createProxyAgent(v904, v905 = 0x88b8) {
  if (!v904) return null;
  const v906 = typeof v904 === "string" ? parseProxy(v904) : v904;
  if (!v906) return null;
  let v907 = '';
  if (v906.type === "socks5" || v906.type === "socks4") {
    v907 = 'socks5://' + (v906.user ? encodeURIComponent(v906.user) + ':' + encodeURIComponent(v906.pass || '') + '@' : '') + v906.host + ':' + v906.port;
    const v908 = {};
    return v908.timeout = v905, new SocksProxyAgent(v907, v908);
  } else {
    v907 = "http://" + (v906.user ? encodeURIComponent(v906.user) + ':' + encodeURIComponent(v906.pass || '') + '@' : '') + v906.host + ':' + v906.port;
    const v909 = {};
    return v909.timeout = v905, v909.keepAlive = false, v909.rejectUnauthorized = false, new HttpsProxyAgent(v907, v909);
  }
}
async function checkProxy(v910, v911 = 0x1770) {
  return new Promise(v912 => {
    let v913 = false;
    const fn19 = v916 => {
      if (v913) return;
      v913 = true, clearTimeout(v915), v912(v916);
    };
    let v914;
    const v915 = setTimeout(() => {
      if (v914) try {
        v914.destroy();
      } catch (v917) {}
      fn19(false);
    }, v911);
    try {
      if (!v910 || !v910.host || !v910.port) return fn19(false);
      const v918 = createProxyAgent(v910, v911);
      if (!v918) return fn19(false);
      const v919 = {};
      v919["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)", v919.Connection = "close";
      const v920 = {};
      v920.hostname = "www.facebook.com", v920.port = 0x1bb, v920.path = '/', v920.method = "HEAD", v920.headers = v919, v920.agent = v918, v920.timeout = v911, v920.rejectUnauthorized = false, v914 = https.request(v920, v921 => {
        fn19(v921.statusCode >= 0xc8 && v921.statusCode < 0x1f4), v921.resume();
      }), v914.on("error", () => fn19(false)), v914.on("timeout", () => {
        if (v914) try {
          v914.destroy();
        } catch (v922) {}
        fn19(false);
      }), v914.end();
    } catch (v923) {
      fn19(false);
    }
  });
}
async function filterLiveProxies(v924, v925 = 0x14) {
  if (v924.length === 0x0) return [];
  console.log(Y("\n  ▶ Checking " + v924.length + " proxies against Facebook..."));
  let v926 = 0x0,
    v927 = 0x0;
  const v928 = [];
  let v929 = 0x0;
  const fn20 = async () => {
      while (v929 < v924.length) {
        const v931 = v929++,
          v932 = v924[v931],
          v933 = await checkProxy(v932);
        if (v933) v926++, v928.push(v932);else v927++;
        process.stdout.write("\r  " + B("Live:") + '\x20' + v926 + '\x20\x20' + R('Dead:') + '\x20' + v927 + "  Checked: " + (v926 + v927) + '/' + v924.length + '\x20\x20');
      }
    },
    v930 = Array.from({
      'length': Math.min(v925, v924.length)
    }, () => fn20());
  return await Promise.all(v930), process.stdout.write('\x0a'), v926 === 0x0 ? console.log(R("  ✗ No live proxies found! All " + v927 + " proxies are dead.\n")) : console.log(B("  ✔ " + v926 + " live proxies ready. " + v927 + " dead proxies removed.\n")), v928;
}
const _proxyCountryCache = new Map();
async function getProxyCountry(v934) {
  if (!v934) return 'Direct';
  const v935 = (v934.split(':')[0x0] || v934).trim();
  if (_proxyCountryCache.has(v935)) return _proxyCountryCache.get(v935);
  try {
    const v936 = createProxyAgent(parseProxy(v934), 0x1388);
    let v937 = await new Promise(v939 => {
      let v940 = false;
      const fn21 = v943 => {
        if (v940) return;
        v940 = true, clearTimeout(v942), v939(v943);
      };
      let v941;
      const v942 = setTimeout(() => {
        if (v941) try {
          v941.destroy();
        } catch (v944) {}
        fn21(null);
      }, 0x1388);
      try {
        const v945 = {};
        v945["User-Agent"] = 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)', v945.Accept = "application/json", v945.Connection = "close";
        const v946 = {};
        v946.hostname = "ip-api.com", v946.port = 0x50, v946.path = "/json?fields=status,country,countryCode", v946.method = "GET", v946.headers = v945, v946.agent = v936, v946.timeout = 0x1194;
        const v947 = v946;
        v941 = http.request(v947, v948 => {
          let v949 = '';
          v948.on("data", v950 => v949 += v950);
          v948.on("end", () => {
            try {
              const v951 = JSON.parse(v949);
              v951.status === "success" && (v951.country || v951.countryCode) ? fn21(v951.country || v951.countryCode) : fn21(null);
            } catch (v952) {
              fn21(null);
            }
          }), v948.resume();
        }), v941.on('error', () => fn21(null)), v941.on("timeout", () => {
          if (v941) try {
            v941.destroy();
          } catch (v953) {}
          fn21(null);
        }), v941.end();
      } catch (v954) {
        fn21(null);
      }
    });
    (!v937 || v937 === 'Unknown') && (v937 = await new Promise(v955 => {
      const v956 = {};
      v956["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)";
      v956.Accept = "application/json", v956.Connection = "close";
      const v957 = {};
      v957.hostname = "api.country.is", v957.port = 0x50, v957.path = '/', v957.method = "GET", v957.headers = v956, v957.agent = v936, v957.timeout = 0xfa0;
      const v958 = http.request(v957, v959 => {
        let v960 = '';
        v959.on('data', v961 => v960 += v961);
        v959.on("end", () => {
          try {
            const v962 = JSON.parse(v960),
              v963 = v962.country;
            let v964 = v963;
            if (v963) try {
              const v965 = {};
              v965.type = "region", v964 = new Intl.DisplayNames(['en'], v965).of(v963) || v963;
            } catch (v966) {}
            v955(v964 || null);
          } catch (v967) {
            v955(null);
          }
        });
      });
      v958.on("error", () => v955(null)), v958.on("timeout", () => {
        v958.destroy();
        v955(null);
      }), v958.end();
    }));
    const v938 = v937 && v937 !== "null" ? v937 : 'Unknown';
    return _proxyCountryCache.set(v935, v938), v938;
  } catch (v968) {
    return "Unknown";
  }
}
function sendRequest(v969, v970, v971, v972, v973 = null, v974 = 0x3a98, v975 = true) {
  return new Promise((v976, v977) => {
    const v978 = new URL(v969),
      v979 = {
        ...v971
      };
    let v980 = v979;
    !v980["Accept-Encoding"] && (v980["Accept-Encoding"] = "gzip, deflate, br");
    !v980.Connection && (v980.Connection = "close");
    v972 && (v980["Content-Length"] = Buffer.byteLength(v972));
    const v981 = {
      'hostname': v978.hostname,
      'path': v978.pathname + v978.search,
      'method': v970,
      'headers': v980,
      'timeout': v974,
      'rejectUnauthorized': false,
      'ciphers': "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384",
      'ecdhCurve': "X25519:P-256:P-384",
      'honorCipherOrder': false,
      'secureOptions': require("crypto").constants.SSL_OP_NO_SSLv3 | require("crypto").constants.SSL_OP_NO_TLSv1 | require("crypto").constants.SSL_OP_NO_TLSv1_1
    };
    let v982 = v973 ? parseProxy(v973) : null;
    if (v973) {
      if (!v982 || isNaN(v982.port) || v982.port <= 0x0) return v977(new Error("FATAL: Invalid proxy. Aborting to prevent IP leak."));
      v981.agent = createProxyAgent(v982, v974);
    }
    const v983 = https.request(v981, v984 => {
      const v985 = [];
      v984.on("data", v986 => v985.push(v986)), v984.on("error", v977), v984.on("end", () => {
        let v987 = Buffer.concat(v985);
        const v988 = v984.headers["content-encoding"];
        if (v988 === "gzip") try {
          v987 = zlib.gunzipSync(v987);
        } catch (v990) {} else {
          if (v988 === 'deflate') try {
            v987 = zlib.inflateSync(v987);
          } catch (v991) {} else {
            if (v988 === 'br') try {
              v987 = zlib.brotliDecompressSync(v987);
            } catch (v992) {}
          }
        }
        const v989 = v984.headers["set-cookie"] || [];
        if (v984.statusCode >= 0x12c && v984.statusCode < 0x190 && v984.headers.location) {
          let v993 = v984.headers.location;
          if (!v993.startsWith("http")) v993 = v978.origin + v993;
          if (!v975) {
            const v999 = {};
            v999.status = v984.statusCode, v999.data = '', v999.headers = v984.headers, v999.cookies = v989, v999.redirect = v993, v999.finalUrl = v993, v976(v999);
            return;
          }
          const v994 = {
            ...v971
          };
          let v995 = v994,
            v996 = v995.Cookie || '',
            v997 = v989.map(v1000 => v1000.split(';')[0x0]).join(';\x20');
          if (v997) v995.Cookie = v996 ? v996 + ';\x20' + v997 : v997;
          const v998 = v970 === "POST" && v984.statusCode === 0x12f ? "GET" : v970;
          v976(sendRequest(v993, v998, v995, v998 === "GET" ? null : v972, v973, v974, v975).then(v1001 => {
            const v1002 = [v993, ...(v1001.redirectHops || [])],
              v1003 = {
                ...v1001
              };
            v1003.redirect = v993, v1003.finalUrl = v1001.finalUrl || v993;
            return v1003.redirectHops = v1002, v1003.cookies = [...v989, ...v1001.cookies], v1003;
          }));
          return;
        }
        v976({
          'status': v984.statusCode,
          'data': v987.toString("utf8"),
          'headers': v984.headers,
          'cookies': v989,
          'finalUrl': v969
        });
      });
    });
    v983.on("error", v977), v983.on("timeout", () => {
      v983.destroy(), v977(new Error("timeout"));
    });
    if (v972) v983.write(v972);
    v983.end();
  });
}
async function createAccount(v1004, v1005 = {}) {
  const {
    onStatus = () => {},
    proxy = null,
    timeout = 0x88b8,
    workerId = 0x0,
    browserPref = "random",
    customPassword = null,
    deviceType = 'random',
    customGeo = null
  } = v1005;
  let v1006 = v1004.includes('@');
  let v1007 = v1004;
  !v1006 && (v1007 = '+' + v1004.replace(/\D/g, ''));
  const v1008 = v1006 ? '' : v1007.replace('+', '');
  onStatus("[1/2] Fetching initial session tokens from FB...");
  try {
    const v1009 = getRandomClient(browserPref, deviceType),
      v1010 = customGeo || (v1006 ? getGeoFromCountry('US') : getCountryFromPhone(v1008)),
      v1011 = v1010.lang,
      v1012 = generateRandomDOB(),
      v1013 = generateRandomName(v1010.iso),
      v1014 = customPassword && customPassword !== 'random_date' ? customPassword : generateRandomPassword(customPassword === 'random_date' ? "random_date" : "auto"),
      v1015 = "#PWD_BROWSER:0:" + Math.floor(Date.now() / 0x3e8) + ':' + v1014;
    let v1016 = {};
    const fn22 = v1074 => {
        if (!v1074) return;
        v1074.forEach(v1075 => {
          const v1076 = v1075.split(';')[0x0].split('=');
          if (v1076.length >= 0x2) v1016[v1076[0x0].trim()] = v1076.slice(0x1).join('=').trim();
        });
      },
      v1017 = Math.random() > 0.5,
      v1018 = getRandomCarrier(v1010.iso),
      v1019 = v1017 ? "WIFI" : "CELLULAR",
      v1020 = {};
    v1020["X-FB-Carrier"] = v1018.name;
    const v1021 = {
        'User-Agent': v1009.userAgent,
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        'Accept-Language': v1011,
        'Sec-Fetch-Dest': "document",
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'X-FB-Connection-Type': v1019,
        ...(!v1017 && v1020),
        ...v1009.clientHints
      },
      v1022 = v1021,
      v1023 = await sendRequest('https://www.facebook.com/reg/?entry_point=login&next=', "GET", v1022, null, proxy, timeout);
    fn22(v1023.cookies);
    const v1024 = v1023.data,
      v1025 = v1024.match(/\["LSD",\[\],\{"token":"([^"]+)"\}\]/) || v1024.match(/"LSD",\[\],\{"token":"([^"]+)"\}/) || v1024.match(/name="lsd" value="([^"]+)"/) || v1024.match(/"lsd":"([^"]+)"/),
      v1026 = v1024.match(/name="jazoest" value="([^"]+)"/),
      v1027 = v1024.match(/"__spin_r":(\d+)/),
      v1028 = v1024.match(/"__spin_b":"([^"]+)"/),
      v1029 = v1024.match(/"__spin_t":(\d+)/),
      v1030 = v1024.match(/"hsi":"([^"]+)"/),
      v1031 = v1024.match(/"server_revision":(\d+)/),
      v1032 = v1024.match(/"__dyn":"([^"]+)"/),
      v1033 = v1024.match(/"__csr":"([^"]+)"/),
      v1034 = v1024.match(/"__sjsp":"([^"]+)"/),
      v1035 = v1024.match(/"__s":"([^"]+)"/) || v1024.match(/__s=([a-z0-9:]+)/),
      v1036 = v1024.match(/"__hs":"([^"]+)"/) || v1024.match(/"has_account":/),
      v1037 = v1024.match(/"__hsdp":"([^"]+)"/),
      v1038 = v1024.match(/"__hblp":"([^"]+)"/),
      fn23 = v1077 => {
        const v1078 = [new RegExp('\x22' + v1077 + '\x22[^{}]*?\x22id\x22:\x22(\x5cd{14,24})\x22', 'i'), new RegExp("\"id\":\"(\\d{14,24})\"[^{}]*?\"" + v1077 + '\x22', 'i'), new RegExp('\x22' + v1077 + '\x22[^{}]*?\x22doc_id\x22:\x22(\x5cd{14,24})\x22', 'i'), new RegExp("\"doc_id\":\"(\\d{14,24})\"[^{}]*?\"" + v1077 + '\x22', 'i'), new RegExp("name:\"" + v1077 + '\x22[^{}]*?id:\x22(\x5cd{14,24})\x22', 'i'), new RegExp("id:\"(\\d{14,24})\"[^{}]*?name:\"" + v1077 + '\x22', 'i'), new RegExp('\x22' + v1077 + "\"[^;]{0,1000}?\"(\\d{15,24})\"", 'i')];
        for (const v1079 of v1078) {
          const v1080 = v1024.match(v1079);
          if (v1080 && v1080[0x1]) return v1080[0x1];
        }
        return null;
      },
      v1039 = fn23("useCAARegistrationFieldValidationQuery") || "26387190147557007",
      v1040 = fn23("useCAARegistrationFormSubmitMutation") || fn23("CAARegistrationFormSubmit") || "27029416779977343",
      v1041 = v1032 ? v1032[0x1] : '',
      v1042 = v1033 ? v1033[0x1] : '',
      v1043 = v1034 ? v1034[0x1] : '',
      v1044 = v1025 ? v1025[0x1] : '',
      v1045 = v1026 ? v1026[0x1] : v1044 ? '2' + Array.from(v1044).reduce((v1081, v1082) => v1081 + v1082.charCodeAt(0x0), 0x0) : '',
      fn24 = () => crypto.randomBytes(0x4).toString("hex").substring(0x0, 0x6),
      v1046 = v1035 ? v1035[0x1] : fn24() + ':' + fn24() + ':' + fn24(),
      v1047 = v1036 ? v1036[0x1] : "20673.HYP:comet_plat_default_pkg.2.1...0",
      v1048 = v1037 ? v1037[0x1] : "ge12NGGqibgpK4Epqwbm0JHw6yg1Wm86w0Yyw7_w1ue01e9w08iS02ia07bo",
      v1049 = v1038 ? v1038[0x1] : "03PE1BU2bzo0Ka02OG0i20v-0b9w2wE2mwfO04F80yu0rS0RE3Qw2i80nIw2KE09K80quw3_EaE09fU2Mw0Ayw1v21zwdy1Lw820mC011Aw1AC",
      v1050 = v1017 ? "EXCELLENT" : 'GOOD';
    if (!v1044) {
      debugLog(v1007, 'html-dump-no-lsd', v1024.substring(0x0, 0x1388));
      const v1083 = new Error("Failed to extract LSD token (Proxy block?)");
      v1083.sessionError = true;
      throw v1083;
    }
    onStatus('[2/4]\x20Submitting\x20Registration\x20Mutation...');
    const v1051 = v1041 || "7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo1nEhw2nVE4W099w8G1Dz81s8hwGwQw9m1YwBgao6C0Mo2swaOfK0EUjwGzE2ZwNwmE2eUlwhE2Lw6OyES1Tw8W0Lo6-1Fw4mwr86C1nwqU8XwnqwIwtU1fE0Vy3mdw",
      v1052 = v1042 || "gj-zOA9l8lvO94kJjAi8QAQBaJ5FOfmAJujgN9lapdHStXSAiDp8G8AGGIKpkBH9GVajQXFGp545F4CWy4Q-Fb_gK8QGiRLiGl_sGIBvQjoSVQHSjKFHhL_yqig4m1gwiXAwzxSu228wmof8gwDix-321dw-w-wnE88460U82SAzUiwpVE464E5S0w8K4K3ui0IoGEuw_o31wgVU1UE1LE0DK5UcE0ifw4Ywvoqxi0C802pjw0kdk00nP-01luwpU0db8028Yg1jm",
      v1053 = v1043 || 'ge17POGFF8J1CUixBG0Jo2SK0q907Fowq',
      v1054 = v1030 ? v1030[0x1] : '7671622214982630808',
      v1055 = v1031 ? v1031[0x1] : "1044789211",
      v1056 = v1027 ? v1027[0x1] : '1044789211',
      v1057 = (v1024.match(/"waterfall_id":"([a-f0-9\-]+)"/) || v1024.match(/"waterfallId":"([a-f0-9\-]+)"/))?.[0x1] || uuid(),
      v1058 = {
        'av': '0',
        '__user': '0',
        '__a': '1',
        '__hs': v1047,
        'dpr': '1',
        '__ccg': v1050,
        '__rev': v1055,
        '__s': v1046,
        '__hsi': v1054,
        '__dyn': v1051,
        '__csr': v1052,
        '__hsdp': v1048,
        '__hblp': v1049,
        '__sjsp': v1053,
        '__comet_req': "102",
        'lsd': v1044,
        'jazoest': v1045,
        '__spin_r': v1056,
        '__spin_b': v1028 ? v1028[0x1] : "trunk",
        '__spin_t': v1029 ? v1029[0x1] : Math.floor(Date.now() / 0x3e8).toString(),
        'qpl_active_flow_ids': "516759801",
        'fb_api_caller_class': "RelayModern",
        'fb_api_req_friendly_name': 'useCAARegistrationFieldValidationQuery',
        'server_timestamps': "true",
        'doc_id': v1039,
        'fb_api_analytics_tags': "[\"qpl_active_flow_ids=516759801\"]"
      },
      v1059 = {
        'User-Agent': v1009.userAgent,
        'Accept': "*/*",
        'Accept-Language': v1011,
        'Content-Type': "application/x-www-form-urlencoded",
        'Origin': "https://www.facebook.com",
        'Referer': "https://www.facebook.com/reg/?entry_point=login&next=",
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': "cors",
        'Sec-Fetch-Site': 'same-origin',
        'x-asbd-id': '359341',
        'x-fb-lsd': v1044,
        'x-fb-friendly-name': "useCAARegistrationFieldValidationQuery",
        'Cookie': Object.entries(v1016).map(([v1084, v1085]) => v1084 + '=' + v1085).join(';\x20'),
        ...v1009.clientHints
      };
    try {
      const v1086 = {};
      v1086.sensitive_string_value = '';
      const v1087 = {};
      v1087.sensitive_string_value = v1013.first;
      const v1088 = {};
      v1088.sensitive_string_value = '';
      const v1089 = {};
      v1089.sensitive_string_value = v1013.last;
      const v1090 = {};
      v1090.contactpoint = v1086, v1090.contactpoint_type = 'ANY', v1090.fetch_username_suggestions = true, v1090.field_name = "FULLNAME", v1090.firstname = v1087, v1090.fullname = v1088, v1090.lastname = v1089, v1090.machine_id = '';
      const v1091 = {};
      v1091.input = v1090, v1091.scale = 0x1;
      const v1092 = new URLSearchParams({
        ...v1058,
        '__req': '5',
        'variables': JSON.stringify(v1091)
      }).toString();
      await sendRequest("https://www.facebook.com/api/graphql/", "POST", v1059, v1092, proxy, timeout), await new Promise(v1100 => setTimeout(v1100, 0xc8 + Math.floor(Math.random() * 0x12c)));
      const v1093 = {};
      v1093.sensitive_string_value = v1007;
      const v1094 = {};
      v1094.sensitive_string_value = v1013.first;
      const v1095 = {};
      v1095.sensitive_string_value = '';
      const v1096 = {};
      v1096.sensitive_string_value = v1013.last;
      const v1097 = {};
      v1097.contactpoint = v1093, v1097.contactpoint_type = v1006 ? "EMAIL" : 'PHONE', v1097.fetch_username_suggestions = true, v1097.field_name = "CONTACTPOINT", v1097.firstname = v1094, v1097.fullname = v1095, v1097.lastname = v1096, v1097.machine_id = '';
      const v1098 = {};
      v1098.input = v1097, v1098.scale = 0x1;
      const v1099 = new URLSearchParams({
        ...v1058,
        '__req': '6',
        'variables': JSON.stringify(v1098)
      }).toString();
      await sendRequest("https://www.facebook.com/api/graphql/", "POST", v1059, v1099, proxy, timeout), await new Promise(v1101 => setTimeout(v1101, 0x96 + Math.floor(Math.random() * 0xfa)));
    } catch (v1102) {}
    const v1060 = {};
    v1060.sensitive_string_value = v1007;
    const v1061 = {};
    v1061.sensitive_string_value = v1013.first;
    const v1062 = {};
    v1062.sensitive_string_value = '';
    const v1063 = {};
    v1063.sensitive_string_value = v1013.last;
    const v1064 = {};
    v1064.sensitive_string_value = v1015;
    const v1065 = {};
    v1065.sensitive_string_value = '';
    const v1066 = {};
    v1066.birthday_day = v1012.day, v1066.birthday_month = v1012.month, v1066.birthday_year = v1012.year, v1066.contactpoint = v1060, v1066.contactpoint_type = v1006 ? "EMAIL" : "PHONE", v1066.fetch_username_suggestions = true, v1066.field_name = "PASSWORD", v1066.firstname = v1061, v1066.fullname = v1062, v1066.lastname = v1063, v1066.reg_passwd__ = v1064, v1066.username = v1065;
    const v1067 = {};
    v1067.input = v1066, v1067.scale = 0x1;
    const v1068 = v1067,
      v1069 = new URLSearchParams({
        'av': '0',
        '__user': '0',
        '__a': '1',
        '__req': 't',
        '__hs': v1047,
        'dpr': '1',
        '__ccg': v1050,
        '__rev': v1055,
        '__s': v1046,
        '__hsi': v1054,
        '__dyn': v1051,
        '__csr': v1052,
        '__hsdp': v1048,
        '__hblp': v1049,
        '__sjsp': v1053,
        '__comet_req': "102",
        'lsd': v1044,
        'jazoest': v1045,
        '__spin_r': v1027 ? v1027[0x1] : "1041832074",
        '__spin_b': v1028 ? v1028[0x1] : "trunk",
        '__spin_t': v1029 ? v1029[0x1] : Math.floor(Date.now() / 0x3e8).toString(),
        'qpl_active_flow_ids': '516759801',
        'fb_api_caller_class': "RelayModern",
        'fb_api_req_friendly_name': "useCAARegistrationFieldValidationQuery",
        'server_timestamps': 'true',
        'variables': JSON.stringify(v1068),
        'doc_id': v1039,
        'fb_api_analytics_tags': "[\"qpl_active_flow_ids=516759801\"]"
      }).toString(),
      v1070 = {};
    v1070["X-FB-Carrier"] = v1018.name;
    const v1071 = {
      'User-Agent': v1009.userAgent,
      'Accept': "*/*",
      'Accept-Language': v1011,
      'Content-Type': "application/x-www-form-urlencoded",
      'Origin': "https://www.facebook.com",
      'Referer': 'https://www.facebook.com/reg/?entry_point=login&next=',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': "cors",
      'Sec-Fetch-Site': 'same-origin',
      'x-asbd-id': "359341",
      'x-fb-connection-quality': v1017 ? "EXCELLENT; q=0.9, rtt=37, rtx=0, c=114, mss=1232, tbw=156136, tp=229, tpl=0, uplat=296, ullat=55" : "GOOD; q=0.7, rtt=75, rtx=0, c=90, mss=1232, tbw=10240, tp=112, tpl=0, uplat=500, ullat=120",
      'X-FB-Connection-Type': v1019,
      ...(!v1017 && v1070),
      'x-fb-lsd': v1044,
      'x-fb-friendly-name': "useCAARegistrationFieldValidationQuery",
      'Cookie': Object.entries(v1016).map(([v1103, v1104]) => v1103 + '=' + v1104).join(';\x20'),
      ...v1009.clientHints
    };
    debugLog(v1007, "req-submit", v1069);
    const v1072 = await sendRequest("https://www.facebook.com/api/graphql/", 'POST', v1071, v1069, proxy, timeout);
    fn22(v1072.cookies), debugLog(v1007, "res-submit", v1072.data);
    let v1073 = false;
    try {
      const v1105 = JSON.parse(v1072.data),
        v1106 = v1105.data && (v1105.data.xfb_caa_registration_field_validation || v1105.data.caa_registration_field_validation);
      if (v1106) {
        if (v1106.status === "SUCCESS") v1073 = true;else {
          if (v1106.status === "ERROR" || v1106.status === "UNKNOWN_ERROR") {
            const v1107 = (v1106.errors && v1106.errors.creation_errors || []).map(v1109 => (v1109.code || '').toUpperCase()),
              v1108 = ['CONTACT_POINT_ALREADY', "PHONE_ALREADY", "ALREADY_REGISTERED", "ALREADY_EXISTS", "CONTACTPOINT_EXISTS"];
            if (v1107.some(v1110 => v1108.some(v1111 => v1110.includes(v1111)))) {
              const v1112 = {};
              v1112.noRetry = true, v1112.alreadyRegistered = true;
              throw Object.assign(new Error("Number already registered on Facebook"), v1112);
            }
            v1073 = true;
          }
        }
      } else v1105.data && (v1073 = true);
    } catch (v1113) {
      if (v1113.noRetry) throw v1113;
      if (v1072.data.includes("SUCCESS")) v1073 = true;else {
        if (v1072.data.includes("already") || v1072.data.includes("ALREADY")) {
          const v1114 = {};
          v1114.noRetry = true, v1114.alreadyRegistered = true;
          throw Object.assign(new Error("Number already registered on Facebook"), v1114);
        } else v1073 = true;
      }
    }
    if (v1073) {
      onStatus("[3/4] Submitting registration form to Facebook...");
      const v1115 = {};
      v1115.sensitive_string_value = v1007;
      const v1116 = {};
      v1116.sensitive_string_value = v1013.first;
      const v1117 = {};
      v1117.sensitive_string_value = '';
      const v1118 = {};
      v1118.sensitive_string_value = v1013.last;
      const v1119 = {};
      v1119.sensitive_string_value = v1015;
      const v1120 = {};
      v1120.sensitive_string_value = '';
      const v1121 = {};
      v1121.birthday_day = v1012.day, v1121.birthday_month = v1012.month, v1121.birthday_year = v1012.year, v1121.contactpoint = v1115, v1121.contactpoint_type = v1006 ? "EMAIL" : 'PHONE', v1121.custom_gender = '', v1121.did_use_age = false, v1121.firstname = v1116, v1121.fullname = v1117, v1121.ig_age_block_data = null, v1121.lastname = v1118, v1121.preferred_pronoun = null, v1121.reg_passwd__ = v1119, v1121.sex = 'MALE', v1121.use_custom_gender = false, v1121.username = v1120;
      const v1122 = {
          'input': {
            'actor_id': '0',
            'client_mutation_id': uuid(),
            'machine_id': '',
            'reg_data': v1121,
            'sk_pipa_consent_given': null,
            'waterfall_id': v1057
          }
        },
        v1123 = new URLSearchParams({
          'av': '0',
          '__user': '0',
          '__a': '1',
          '__req': 'u',
          '__hs': v1047,
          'dpr': '1',
          '__ccg': v1050,
          '__rev': v1055,
          '__s': v1046,
          '__hsi': v1054,
          '__dyn': v1051,
          '__csr': v1052,
          '__hsdp': v1048,
          '__hblp': v1049,
          '__sjsp': v1053,
          '__comet_req': "102",
          'lsd': v1044,
          'jazoest': v1045,
          '__spin_r': v1027 ? v1027[0x1] : "1045301906",
          '__spin_b': v1028 ? v1028[0x1] : "trunk",
          '__spin_t': v1029 ? v1029[0x1] : Math.floor(Date.now() / 0x3e8).toString(),
          'qpl_active_flow_ids': "250359044,516759801",
          'fb_api_caller_class': 'RelayModern',
          'fb_api_req_friendly_name': "useCAARegistrationFormSubmitMutation",
          'server_timestamps': 'true',
          'variables': JSON.stringify(v1122),
          'doc_id': "27029416779977343",
          'fb_api_analytics_tags': "[\"qpl_active_flow_ids=250359044,516759801\"]"
        }).toString(),
        v1124 = {
          ...v1071,
          'x-fb-friendly-name': 'useCAARegistrationFormSubmitMutation',
          'Cookie': Object.entries(v1016).map(([v1131, v1132]) => v1131 + '=' + v1132).join(';\x20')
        };
      debugLog(v1007, "req-form-submit", v1123);
      const v1125 = await sendRequest("https://www.facebook.com/api/graphql/", "POST", v1124, v1123, proxy, timeout);
      fn22(v1125.cookies), debugLog(v1007, "res-form-submit", v1125.data);
      let v1126 = v1016.c_user || '',
        v1127 = false;
      try {
        const v1133 = JSON.parse(v1125.data),
          v1134 = v1133?.["data"]?.["caa_registration_homepage_submit"];
        if (v1134?.["status"] === 'SUCCESS' || v1134?.["created_user_id"] || v1016.c_user) {
          v1127 = true;
          if (v1134?.['created_user_id']) v1126 = v1134.created_user_id;
          if (!v1126 && v1016.c_user) v1126 = v1016.c_user;
        } else {
          if (v1134?.["errors"]?.["creation_errors"]?.["length"] > 0x0) {
            const v1135 = v1134.errors.creation_errors[0x0];
            if ((v1135.code || '').includes("ALREADY") || (v1135.message || '').includes("already")) {
              const v1137 = {};
              v1137.noRetry = true, v1137.alreadyRegistered = true;
              throw Object.assign(new Error("Target already registered on Facebook"), v1137);
            }
            const v1136 = {};
            v1136.noRetry = false;
            throw Object.assign(new Error(v1135.message || "Registration rejected by Facebook"), v1136);
          } else {
            if (v1133?.["errors"]?.["length"] > 0x0) {
              const v1138 = {};
              v1138.noRetry = false;
              throw Object.assign(new Error(v1133.errors[0x0].message || "Registration rejected by Facebook"), v1138);
            } else {
              const v1139 = {};
              v1139.noRetry = false;
              throw Object.assign(new Error("Registration rejected by Facebook"), v1139);
            }
          }
        }
      } catch (v1140) {
        if (v1140.noRetry || v1140.alreadyRegistered) throw v1140;
        throw v1140;
      }
      onStatus("[4/4] Registration submitted! Checking confirmation session...");
      let v1128 = '',
        v1129 = 'https://www.facebook.com/confirmemail.php?next=https%3A%2F%2Fwww.facebook.com%2F';
      try {
        const v1141 = typeof v1125.data === "string" ? JSON.parse(v1125.data) : v1125.data,
          v1142 = v1141?.['data']?.["caa_registration_homepage_submit"]?.['redirect_uri'];
        if (v1142 && v1142.startsWith("http")) v1129 = v1142;
      } catch (v1143) {}
      try {
        const v1144 = {};
        v1144["X-FB-Carrier"] = v1018.name;
        const v1145 = await sendRequest(v1129, "GET", {
          'User-Agent': v1009.userAgent,
          'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          'Accept-Language': v1011,
          'Referer': 'https://www.facebook.com/reg/?entry_point=login&next=',
          'Sec-Fetch-Dest': "document",
          'Sec-Fetch-Mode': "navigate",
          'Sec-Fetch-Site': "same-origin",
          'Upgrade-Insecure-Requests': '1',
          'X-FB-Connection-Type': v1019,
          ...(!v1017 && v1144),
          'Cookie': Object.entries(v1016).map(([v1150, v1151]) => v1150 + '=' + v1151).join(';\x20'),
          ...v1009.clientHints
        }, null, proxy, timeout, false);
        fn22(v1145.cookies);
        const v1146 = v1145.data || '',
          v1147 = v1146.match(/"USER_ID":"(\d+)"/) || v1146.match(/"ACCOUNT_ID":"(\d+)"/) || v1146.match(/"actor_id":"(\d+)"/);
        if (v1147 && !v1126) v1126 = v1147[0x1];
        if (!v1126 && v1016.c_user) v1126 = v1016.c_user;
        const v1148 = v1145.headers && v1145.headers.location || v1145.redirect || '',
          v1149 = {};
        v1149.status = v1145.status, v1149.targetConfirmUrl = v1129, v1149.redirect = v1148, v1149.userId = v1126, debugLog(v1007, "post-reg-page", v1149), v1128 = v1148 || v1129;
      } catch (v1152) {
        debugLog(v1007, "post-reg-page-err", v1152.message);
      }
      const v1130 = {};
      return v1130.success = true, v1130.message = "OTP Triggered successfully", v1130.phone = v1007, v1130.redirect = v1128 || "confirmemail.php", v1130.password = v1014, v1130.userId = v1126, v1130.cookieMap = v1016, v1130.lsd = v1044, v1130.fbDtsg = '', v1130;
    } else {
      let v1153 = "Registration validation failed";
      try {
        const v1155 = JSON.parse(v1072.data),
          v1156 = v1155.data && (v1155.data.xfb_caa_registration_field_validation || v1155.data.caa_registration_field_validation);
        if (v1156 && v1156.errors && v1156.errors.creation_errors) v1153 = v1156.errors.creation_errors.map(v1157 => v1157.message || v1157.code).join(',\x20');else v1155.errors && v1155.errors.length > 0x0 && (v1153 += ':\x20' + v1155.errors.map(v1158 => v1158.message).join(',\x20'));
      } catch (v1159) {}
      const v1154 = new Error(v1153);
      v1154.sessionError = true;
      throw v1154;
    }
  } catch (v1160) {
    const v1161 = {};
    return v1161.success = false, v1161.message = '' + v1160.message, v1161.phone = v1007, v1161.sessionError = !!v1160.sessionError, v1161.noRetry = !!v1160.noRetry, v1161.alreadyRegistered = !!v1160.alreadyRegistered, v1161;
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v1162) {
      this.totalNumbers = v1162, this.processed = 0x0, this.otpSent = 0x0, this.alive = 0x0, this.dead = 0x0, this.successful = 0x0, this.failed = 0x0, this.confirmed = 0x0;
      this.skipped = 0x0, this.startTime = Date.now();
    }
    ["addLog"](v1163, v1164, v1165 = '') {
      const v1166 = v1165 ? G('\x20[' + v1165 + ']') : '';
      let v1167, v1168;
      if (v1164 === 'success') {
        this.otpSent++, this.successful = this.otpSent, v1167 = B("[FB-CREATE] [OTP ✅]");
        const v1169 = v1163.replace(/Triggered OTP for /, '').replace(/ \[.*\]/, '');
        v1168 = B(v1169);
      } else {
        if (v1164 === "confirmed" || v1164 === 'live') this.alive++, this.confirmed = this.alive, v1167 = chalk.hex("#00FF88").bold("[FB-CREATE] [ALIVE 🟢]"), v1168 = chalk.hex("#00FF88")(v1163.replace(/\[LIVE 🟢\] /, '').replace(/\[OUTLOOK ✅\] /, ''));else {
          if (v1164 === "dead" || v1164 === 'checkpoint') this.dead++, v1167 = chalk.hex("#FF6600").bold('[FB-CREATE]\x20[DEAD\x20⚠️]'), v1168 = chalk.hex('#FF6600')(v1163);else {
            if (v1164 === "skip") this.skipped++, v1167 = Y("[FB-CREATE] [SKIP ⏭ ]"), v1168 = Y(v1163);else {
              this.failed++, v1167 = R("[FB-CREATE] [FAIL ✗ ]");
              const v1170 = v1163.split(':\x20'),
                v1171 = v1170[0x0].replace("Failed on ", '').replace("Skip ", ''),
                v1172 = v1170.slice(0x1).join(':\x20');
              v1168 = R(v1171) + G(v1172 ? " → " + v1172 : '');
            }
          }
        }
      }
      process.stdout.write("\r[K" + v1167 + '\x20' + v1168 + v1166 + '\x0a'), this.render();
    }
    ["setStatus"](v1173) {}
    ["render"]() {
      const v1174 = Math.min(0x64, this.processed / Math.max(this.totalNumbers, 0x1) * 0x64).toFixed(0x1),
        v1175 = Math.max(0x0, Math.min(0x12, Math.round(this.processed / Math.max(this.totalNumbers, 0x1) * 0x12))),
        v1176 = Math.max(0x0, 0x12 - v1175),
        v1177 = chalk.hex('#1877F2')('█'.repeat(v1175)) + chalk.hex('#2a2a2a')('░'.repeat(v1176)),
        v1178 = Math.floor((Date.now() - this.startTime) / 0x3e8);
      const v1179 = Math.floor(v1178 / 0x3c),
        v1180 = v1178 % 0x3c,
        v1181 = v1179 + 'm' + v1180 + 's',
        v1182 = chalk.hex("#1877F2").bold("  REX-FB") + chalk.hex("#555555")(" ⯮ ") + v1177 + chalk.hex('#888888')('\x20' + v1174 + '%') + chalk.hex("#555555")(" │ ") + chalk.hex("#00D8FF")("📤 OTP: " + this.otpSent) + chalk.hex("#555555")('\x20\x20') + chalk.hex('#00FF88').bold("🟢 Alive: " + this.alive) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF6600").bold("⚠️ Dead: " + this.dead) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold("✗ Failed: " + this.failed) + (this.skipped > 0x0 ? chalk.hex("#555555")('\x20\x20') + chalk.hex('#FFCC00')('⏭\x20Skip:\x20' + this.skipped) : '') + chalk.hex("#555555")(" │ ") + chalk.hex("#AAAAAA")('[' + this.processed + '/' + this.totalNumbers + ']') + chalk.hex("#555555")("  ⏱ " + v1181);
      process.stdout.write("\r[K" + v1182);
    }
    ['stop']() {
      process.stdout.write("[2K\r\n");
      const v1183 = Math.floor((Date.now() - this.startTime) / 0x3e8),
        v1184 = Math.floor(v1183 / 0x3c),
        v1185 = v1183 % 0x3c,
        v1186 = v1184 + 'm\x20' + v1185 + 's';
      console.log(B("\n  ╔" + '═'.repeat(0x2e) + '╗')), console.log(B('\x20\x20║') + W.bold("  FB CREATE — RUN COMPLETE                    ") + B('║'));
      console.log(B('\x20\x20╠' + '═'.repeat(0x2e) + '╣')), console.log(B("  ║") + ('\x20\x20' + chalk.cyan("Total Targets") + " : " + chalk.white(String(this.totalNumbers).padEnd(0x1c))) + B('║')), console.log(B("  ║") + ('\x20\x20' + chalk.hex("#AAAAAA")('Processed') + '\x20\x20\x20\x20\x20:\x20' + chalk.white(String(this.processed).padEnd(0x1c))) + B('║')), console.log(B("  ║") + ('\x20\x20' + chalk.hex("#00D8FF")("OTP Triggered") + '\x20:\x20' + chalk.hex("#00D8FF")(String(this.otpSent).padEnd(0x1c))) + B('║')), console.log(B("  ║") + ('\x20\x20' + chalk.hex("#00FF88").bold("Alive (Live)") + "   : " + chalk.hex("#00FF88").bold(String(this.alive).padEnd(0x1c))) + B('║')), console.log(B("  ║") + ('\x20\x20' + chalk.hex("#FF6600").bold("Dead (CP)") + "      : " + chalk.hex("#FF6600").bold(String(this.dead).padEnd(0x1c))) + B('║')), console.log(B('\x20\x20║') + ('\x20\x20' + chalk.red("Failed") + '\x20\x20\x20\x20\x20\x20\x20\x20:\x20' + chalk.red(String(this.failed).padEnd(0x1c))) + B('║'));
      if (this.skipped > 0x0) console.log(B("  ║") + ('\x20\x20' + chalk.yellow("Skipped") + "       : " + chalk.yellow(String(this.skipped).padEnd(0x1c))) + B('║'));
      console.log(B("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "    : " + chalk.cyan(v1186.padEnd(0x1c))) + B('║')), console.log(B("  ╚" + '═'.repeat(0x2e) + '╝\x0a'));
    }
  }
  async function selectOption(v1187, v1188) {
    return new Promise(v1189 => {
      let v1190 = 0x0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn25 = () => {
        process.stdout.write("[2J[H");
        printHeader(), console.log("   [33m" + v1187 + "[0m\n"), v1188.forEach((v1191, v1192) => {
          v1192 === v1190 ? console.log("   [36m➔[35m " + v1191.name + "[0m") : console.log("     [90m" + v1191.name + "[0m");
        });
      };
      fn25();
      const fn26 = (v1193, v1194) => {
        if (v1194.ctrl && v1194.name === 'c') process.exit(0x0);
        if (v1194.name === 'up') v1190 = (v1190 - 0x1 + v1188.length) % v1188.length, fn25();else {
          if (v1194.name === "down") v1190 = (v1190 + 0x1) % v1188.length, fn25();else v1194.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener('keypress', fn26), v1189(v1188[v1190].value));
        }
      };
      process.stdin.on('keypress', fn26);
    });
  }
  async function promptText(v1195, v1196) {
    return new Promise(v1197 => {
      process.stdout.write('\x20\x20\x20\x1b[33m' + v1195 + "[0m ");
      let v1198 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn27 = v1199 => {
        const v1200 = v1199.toString();
        if (v1200.includes('\x0a') || v1200.includes('\x0d')) {
          process.stdin.removeListener('data', fn27), v1198 += v1200.split(/[\r\n]/)[0x0];
          let v1201 = v1198.trim();
          if (v1201.startsWith('\x22') && v1201.endsWith('\x22')) v1201 = v1201.slice(0x1, -1);
          v1197(v1201 || v1196);
        } else v1198 += v1200;
      };
      process.stdin.on("data", fn27);
    });
  }
  function generateHWID() {
    const v1202 = os.platform();
    try {
      if (v1202 === "win32") {
        const v1203 = {};
        v1203.stdio = 'pipe', v1203.timeout = 0x3a98;
        const v1204 = execSync("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command \"$mg = (Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Cryptography' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter 'DeviceID=\\'C:\\'' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join '|')\"", v1203).toString().trim();
        if (!v1204) throw new Error("No hardware data");
        const v1205 = crypto.createHash("sha256").update(v1204).digest("hex").toUpperCase();
        return "SKING-" + v1205.substring(0x0, 0x8) + '-' + v1205.substring(0x8, 0xc) + '-' + v1205.substring(0xc, 0x10);
      } else {
        let v1206 = [];
        try {
          const v1210 = {};
          v1210.stdio = 'pipe', v1210.timeout = 0x1388;
          const v1211 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", v1210).toString().trim();
          if (v1211 && v1211 !== 'null') v1206.push('A:' + v1211);
        } catch (v1212) {}
        try {
          if (fs.existsSync("/proc/cpuinfo")) {
            const v1213 = fs.readFileSync('/proc/cpuinfo', "utf8"),
              v1214 = v1213.match(/Serial\s*:\s*(\S+)/i),
              v1215 = v1213.match(/Hardware\s*:\s*(.+)/i);
            if (v1214 && v1214[0x1] !== "0000000000000000") v1206.push('S:' + v1214[0x1].trim());
            if (v1215) v1206.push('H:' + v1215[0x1].trim());
          }
        } catch (v1216) {}
        try {
          if (fs.existsSync("/etc/machine-id")) {
            const v1217 = fs.readFileSync("/etc/machine-id", "utf8").trim();
            if (v1217) v1206.push('M:' + v1217);
          }
        } catch (v1218) {}
        try {
          const v1219 = os.cpus(),
            v1220 = v1219 && v1219.length > 0x0 ? v1219[0x0].model : "UnknownCPU",
            v1221 = os.totalmem(),
            v1222 = os.release(),
            v1223 = os.hostname();
          v1206.push('F:' + v1220 + '|' + v1221 + '|' + v1222 + '|' + v1223);
        } catch (v1224) {}
        const v1207 = v1206.join('||'),
          v1208 = crypto.createHash('sha256').update(v1207).digest('hex').toUpperCase(),
          v1209 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
        return v1209 + v1208.substring(0x0, 0x8) + '-' + v1208.substring(0x8, 0xc) + '-' + v1208.substring(0xc, 0x10);
      }
    } catch (v1225) {
      return '';
    }
  }
  function verifyServerSignature(v1226, v1227) {
    if (!v1227) return false;
    try {
      return crypto.verify(null, Buffer.from(v1226, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v1227, "base64"));
    } catch (v1228) {
      return false;
    }
  }
  async function interactiveWizard() {
    let v1229 = 0x1,
      v1230 = "numbers.txt",
      v1231 = '20',
      v1232 = 'proxies.txt',
      v1233 = "random",
      v1234 = 'random',
      v1235 = '1',
      v1236 = null,
      v1237 = null,
      v1238 = null,
      v1239 = null,
      v1240 = null,
      v1241 = null,
      v1242 = null,
      v1243 = null,
      v1244 = null,
      v1245 = null;
    let v1246 = null,
      v1247 = 'file';
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v1229 === 0x1) {
        const v1249 = {};
        v1249.name = "📁 Load from Phone Numbers file (numbers.txt)", v1249.value = "file";
        const v1250 = {};
        v1250.name = "📧 Load Outlook Accounts (outlook / OAuth2)", v1250.value = "outlook";
        const v1251 = {};
        v1251.name = "📬 Auto Tempmail Services (Mail.cx, Mailsink, Temp.tf, Mail.tm)", v1251.value = "tempmail";
        const v1252 = {};
        v1252.name = '🌐\x20Auto\x20fetch\x20from\x20NexaOTP\x20Panel', v1252.value = "nexa";
        const v1253 = {};
        v1253.name = "⚡ Auto fetch from Voltx (2oo9)", v1253.value = "voltx";
        const v1254 = {};
        v1254.name = '🔥\x20Auto\x20fetch\x20from\x20Stex\x20(2oo9)', v1254.value = "stex";
        const v1255 = {};
        v1255.name = '📱\x20Auto\x20fetch\x20from\x20SMS\x20Bower', v1255.value = 'smsbower';
        const v1256 = {};
        v1256.name = "⚡ Auto fetch from Zenex", v1256.value = "zenex";
        const v1257 = {};
        v1257.name = "❌ Exit Program", v1257.value = "exit";
        const v1258 = await selectOption("SELECT REGISTRATION SOURCE", [v1249, v1250, v1251, v1252, v1253, v1254, v1255, v1256, v1257]);
        if (v1258 === 'exit') process.exit(0x0);
        v1247 = v1258;
        if (v1247 === "tempmail") {
          const v1259 = {};
          v1259.name = "🌀 Random / Mixed Tempmail (Mail.cx + Mailsink + Temp.tf + Mail.tm)", v1259.value = "random_tempmail";
          const v1260 = {};
          v1260.name = "⚡ Mail.cx (api.mail.cx — Long-poll, Unlimited)", v1260.value = "mailcx";
          const v1261 = {};
          v1261.name = '📬\x20Mailsink\x20(api.mailsink.dev)', v1261.value = 'mailsink';
          const v1262 = {};
          v1262.name = "📩 Temp.tf (Gmail / Outlook Aliases)", v1262.value = "temptf";
          const v1263 = {};
          v1263.name = '📫\x20Mail.tm\x20(api.mail.tm)', v1263.value = "mailtm";
          const v1264 = {};
          v1264.name = '⬅️\x20Back', v1264.value = "back";
          const v1265 = await selectOption("SELECT TEMPMAIL PROVIDER", [v1259, v1260, v1261, v1262, v1263, v1264]);
          if (v1265 === "back") continue;
          v1247 = v1265;
        }
        if (v1247 === "file") {
          const v1266 = {};
          v1266.name = "✏️ Custom File Path", v1266.value = "custom";
          const v1267 = {};
          v1267.name = '📄\x20numbers.txt\x20(Default)', v1267.value = "numbers.txt";
          const v1268 = {};
          v1268.name = "❌ Exit Program", v1268.value = 'exit';
          const v1269 = await selectOption("SELECT TARGET NUMBERS FILE", [v1266, v1267, v1268]);
          if (v1269 === "exit") process.exit(0x0);
          if (v1269 === "custom") {
            const v1271 = await promptText("Enter Targets File Path:", "numbers.txt");
            if (v1271.toLowerCase() === "back") continue;
            v1230 = v1271;
          } else v1230 = v1269;
          const v1270 = path.resolve(v1230);
          if (!fs.existsSync(v1270)) fs.writeFileSync(v1270, '');
          v1237 = null, v1238 = null, v1239 = null, v1240 = null, v1241 = null, v1242 = null, v1243 = null, v1244 = null, v1245 = null, v1229 = 0x2;
        } else {
          if (v1247 === 'outlook') {
            let v1272 = [],
              v1273 = false,
              v1274 = 0x1,
              v1275 = "outlook";
            while (v1274 <= 0x2 && !v1273) {
              process.stdout.write("[2J[H"), printHeader();
              if (v1274 === 0x1) {
                const v1276 = {};
                v1276.name = "✏️ Custom File Path", v1276.value = "custom";
                const v1277 = {};
                v1277.name = "⬅️ Back", v1277.value = "back";
                const v1278 = await selectOption("SELECT OUTLOOK ACCOUNTS FILE", [v1276, v1277]);
                if (v1278 === "back") {
                  v1273 = true;
                  break;
                }
                if (v1278 === "custom") {
                  const v1280 = await promptText('Enter\x20Outlook\x20File\x20Path:', "outlook");
                  if (v1280.toLowerCase() === "back") continue;
                  v1275 = v1280;
                } else v1275 = v1278;
                const v1279 = path.resolve(v1275);
                if (!fs.existsSync(v1279)) {
                  console.log(chalk.red("\n  ✗ Outlook file not found: " + v1279 + '\x0a')), await new Promise(v1281 => setTimeout(v1281, 0x5dc));
                  continue;
                }
                v1272 = parseOutlookFile(v1279);
                if (v1272.length === 0x0) {
                  console.log(chalk.red("\n  ✗ No valid Outlook accounts found in file: " + v1279 + "\n  Expected format: email|password|refresh_token|client_id\n")), await new Promise(v1282 => setTimeout(v1282, 0x7d0));
                  continue;
                }
                console.log(chalk.green("\n  ✔ Loaded " + v1272.length + " Outlook account(s).\n")), await new Promise(v1283 => setTimeout(v1283, 0x320)), v1241 = {
                  'filePath': path.resolve(v1275),
                  'accounts': v1272,
                  'accountsPerEmail': 0x1,
                  'totalCount': v1272.length,
                  'autoConfirm': true
                }, v1230 = path.resolve(v1275), v1237 = null, v1238 = null, v1239 = null, v1240 = null, v1242 = null, v1243 = null, v1244 = null, v1245 = null, v1274 = 0x3;
              }
            }
            if (v1273) continue;
            v1229 = 0x2;
          } else {
            if (v1247 === "mailcx") {
              let v1284 = '',
                v1285 = 0x32,
                v1286 = 'US',
                v1287 = 0x1,
                v1288 = false;
              while (v1287 <= 0x3 && !v1288) {
                process.stdout.write("[2J[H"), printHeader();
                if (v1287 === 0x1) {
                  if (fs.existsSync(MAILCX_KEY_FILE)) {
                    v1284 = fs.readFileSync(MAILCX_KEY_FILE, "utf8").trim();
                    const v1289 = {};
                    v1289.name = "Use saved token", v1289.value = "use";
                    const v1290 = {};
                    v1290.name = "Enter new token", v1290.value = "new";
                    const v1291 = {};
                    v1291.name = "Remove saved token", v1291.value = 'remove';
                    const v1292 = {};
                    v1292.name = "⬅️ Back", v1292.value = "back";
                    const v1293 = await selectOption("Mail.cx API Token found (" + v1284.substring(0x0, 0xa) + '...)', [v1289, v1290, v1291, v1292]);
                    if (v1293 === "back") {
                      v1288 = true;
                      break;
                    }
                    if (v1293 === "remove") fs.existsSync(MAILCX_KEY_FILE) && fs.unlinkSync(MAILCX_KEY_FILE), v1284 = '';else {
                      if (v1293 === "new") v1284 = '';
                    }
                  }
                  if (!v1284) {
                    v1284 = await promptText("Enter Mail.cx API Token (x-api-token, e.g. tm_live_...):", '');
                    if (v1284.toLowerCase() === "back") {
                      v1288 = true;
                      break;
                    }
                    if (v1284) {
                      const v1294 = {};
                      v1294.name = 'Yes', v1294.value = "yes";
                      const v1295 = {};
                      v1295.name = 'No', v1295.value = 'no';
                      const v1296 = await selectOption('Save\x20token?', [v1294, v1295]);
                      if (v1296 === 'yes') fs.writeFileSync(MAILCX_KEY_FILE, v1284, "utf8");
                    }
                  }
                  v1287 = 0x2;
                } else {
                  if (v1287 === 0x2) {
                    const v1297 = {};
                    v1297.name = "🌐 Global / Mixed Random (All Regions)", v1297.value = "RANDOM";
                    const v1298 = {};
                    v1298.name = '🇺🇸\x20United\x20States\x20/\x20English', v1298.value = 'US';
                    const v1299 = {};
                    v1299.name = "🇪🇸 Spain / Latin America (Spanish)", v1299.value = 'ES';
                    const v1300 = {};
                    v1300.name = "🇫🇷 France (French)", v1300.value = 'FR';
                    const v1301 = {};
                    v1301.name = "🇩🇪 Germany (German)", v1301.value = 'DE';
                    const v1302 = {};
                    v1302.name = "🇮🇹 Italy (Italian)", v1302.value = 'IT';
                    const v1303 = {};
                    v1303.name = "🇧🇷 Brazil (Portuguese)", v1303.value = 'BR';
                    const v1304 = {};
                    v1304.name = '🇸🇦\x20Saudi\x20Arabia\x20/\x20Middle\x20East\x20(Arabic)', v1304.value = 'SA';
                    const v1305 = {};
                    v1305.name = '🇮🇩\x20Indonesia\x20/\x20Southeast\x20Asia', v1305.value = 'ID';
                    const v1306 = {};
                    v1306.name = "🇻🇳 Vietnam", v1306.value = 'VN';
                    const v1307 = {};
                    v1307.name = "🇮🇳 India (Hindi/English)", v1307.value = 'IN';
                    const v1308 = {};
                    v1308.name = "⬅️ Back", v1308.value = "back";
                    const v1309 = await selectOption('SELECT\x20NAME\x20REGION\x20/\x20COUNTRY\x20FOR\x20EMAILS', [v1297, v1298, v1299, v1300, v1301, v1302, v1303, v1304, v1305, v1306, v1307, v1308]);
                    if (v1309 === "back") {
                      v1287 = 0x1;
                      continue;
                    }
                    v1286 = v1309, v1287 = 0x3;
                  } else {
                    if (v1287 === 0x3) {
                      const v1310 = await promptText("How many accounts to create? [default: 50]:", '50');
                      if (v1310.toLowerCase() === "back") {
                        v1287 = 0x2;
                        continue;
                      }
                      v1285 = parseInt(v1310) || 0x32;
                      const v1311 = {};
                      v1311.apiKey = v1284, v1311.domain = "mail.cx", v1311.nameRegion = v1286, v1311.totalCount = v1285, v1311.autoConfirm = true, v1245 = v1311, v1237 = null, v1238 = null, v1239 = null, v1240 = null, v1241 = null, v1242 = null, v1243 = null, v1244 = null, v1287 = 0x4;
                    }
                  }
                }
              }
              if (v1288) continue;
              v1229 = 0x2;
            } else {
              if (v1247 === "random_tempmail") {
                let v1312 = '',
                  v1313 = '',
                  v1314 = 0x32,
                  v1315 = "RANDOM",
                  v1316 = 0x1,
                  v1317 = false;
                while (v1316 <= 0x4 && !v1317) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v1316 === 0x1) {
                    if (fs.existsSync(MAILCX_KEY_FILE)) {
                      v1312 = fs.readFileSync(MAILCX_KEY_FILE, 'utf8').trim();
                      const v1318 = {};
                      v1318.name = "Use saved Mail.cx token", v1318.value = "use";
                      const v1319 = {};
                      v1319.name = "Enter new Mail.cx token", v1319.value = "new";
                      const v1320 = {};
                      v1320.name = "Skip Mail.cx (use other providers)", v1320.value = 'skip';
                      const v1321 = {};
                      v1321.name = "⬅️ Back", v1321.value = "back";
                      const v1322 = await selectOption("[1/4] Mail.cx API Token found (" + v1312.substring(0x0, 0xa) + "...)", [v1318, v1319, v1320, v1321]);
                      if (v1322 === "back") {
                        v1317 = true;
                        break;
                      }
                      if (v1322 === "skip") v1312 = '';else {
                        if (v1322 === "new") v1312 = '';
                      }
                    }
                    if (!v1312 && fs.existsSync(MAILCX_KEY_FILE) === false) {
                      v1312 = await promptText("[1/4] Enter Mail.cx API Token (optional, press Enter to skip):", '');
                      if (v1312.toLowerCase() === "back") {
                        v1317 = true;
                        break;
                      }
                      if (v1312) {
                        const v1323 = {};
                        v1323.name = "Yes", v1323.value = "yes";
                        const v1324 = {};
                        v1324.name = 'No', v1324.value = 'no';
                        const v1325 = await selectOption("Save Mail.cx token?", [v1323, v1324]);
                        if (v1325 === 'yes') fs.writeFileSync(MAILCX_KEY_FILE, v1312, "utf8");
                      }
                    }
                    v1316 = 0x2;
                  } else {
                    if (v1316 === 0x2) {
                      if (fs.existsSync(MAILSINK_KEY_FILE)) {
                        v1313 = fs.readFileSync(MAILSINK_KEY_FILE, "utf8").trim();
                        const v1326 = {};
                        v1326.name = "Use saved Mailsink key", v1326.value = 'use';
                        const v1327 = {};
                        v1327.name = "Enter new Mailsink key", v1327.value = "new";
                        const v1328 = {};
                        v1328.name = "Skip Mailsink", v1328.value = "skip";
                        const v1329 = {};
                        v1329.name = "⬅️ Back", v1329.value = "back";
                        const v1330 = await selectOption('[2/4]\x20Mailsink\x20API\x20Key\x20found\x20(' + v1313.substring(0x0, 0xa) + "...)", [v1326, v1327, v1328, v1329]);
                        if (v1330 === "back") {
                          v1316 = 0x1;
                          continue;
                        }
                        if (v1330 === "skip") v1313 = '';else {
                          if (v1330 === 'new') v1313 = '';
                        }
                      }
                      if (!v1313 && fs.existsSync(MAILSINK_KEY_FILE) === false) {
                        v1313 = await promptText('[2/4]\x20Enter\x20Mailsink\x20API\x20Key\x20(optional,\x20press\x20Enter\x20to\x20skip):', '');
                        if (v1313.toLowerCase() === "back") {
                          v1316 = 0x1;
                          continue;
                        }
                        if (v1313) {
                          const v1331 = {};
                          v1331.name = "Yes", v1331.value = "yes";
                          const v1332 = {};
                          v1332.name = 'No', v1332.value = 'no';
                          const v1333 = await selectOption("Save Mailsink key?", [v1331, v1332]);
                          if (v1333 === "yes") fs.writeFileSync(MAILSINK_KEY_FILE, v1313, "utf8");
                        }
                      }
                      v1316 = 0x3;
                    } else {
                      if (v1316 === 0x3) {
                        const v1334 = {};
                        v1334.name = "🌐 Global / Mixed Random (All Regions)", v1334.value = "RANDOM";
                        const v1335 = {};
                        v1335.name = "🇺🇸 United States / English", v1335.value = 'US';
                        const v1336 = {};
                        v1336.name = '🇪🇸\x20Spain\x20/\x20Latin\x20America\x20(Spanish)', v1336.value = 'ES';
                        const v1337 = {};
                        v1337.name = '🇫🇷\x20France\x20(French)', v1337.value = 'FR';
                        const v1338 = {};
                        v1338.name = '🇩🇪\x20Germany\x20(German)', v1338.value = 'DE';
                        const v1339 = {};
                        v1339.name = "🇮🇹 Italy (Italian)", v1339.value = 'IT';
                        const v1340 = {};
                        v1340.name = "🇧🇷 Brazil (Portuguese)", v1340.value = 'BR';
                        const v1341 = {};
                        v1341.name = "🇸🇦 Saudi Arabia / Middle East (Arabic)", v1341.value = 'SA';
                        const v1342 = {};
                        v1342.name = '🇮🇩\x20Indonesia\x20/\x20Southeast\x20Asia', v1342.value = 'ID';
                        const v1343 = {};
                        v1343.name = "🇻🇳 Vietnam", v1343.value = 'VN';
                        const v1344 = {};
                        v1344.name = "🇮🇳 India (Hindi/English)", v1344.value = 'IN';
                        const v1345 = {};
                        v1345.name = "⬅️ Back", v1345.value = "back";
                        const v1346 = await selectOption("[3/4] SELECT NAME REGION / COUNTRY FOR EMAILS", [v1334, v1335, v1336, v1337, v1338, v1339, v1340, v1341, v1342, v1343, v1344, v1345]);
                        if (v1346 === "back") {
                          v1316 = 0x2;
                          continue;
                        }
                        v1315 = v1346, v1316 = 0x4;
                      } else {
                        if (v1316 === 0x4) {
                          const v1347 = await promptText('[4/4]\x20How\x20many\x20accounts\x20to\x20create?\x20[default:\x2050]:', '50');
                          if (v1347.toLowerCase() === 'back') {
                            v1316 = 0x3;
                            continue;
                          }
                          v1314 = parseInt(v1347) || 0x32;
                          const v1348 = {};
                          v1348.apiKey = v1312, v1348.mailsinkKey = v1313, v1348.totalCount = v1314, v1348.nameRegion = v1315, v1348.autoConfirm = true, v1246 = v1348, v1237 = null, v1238 = null, v1239 = null, v1240 = null, v1241 = null, v1242 = null, v1243 = null, v1244 = null, v1245 = null, v1316 = 0x5;
                        }
                      }
                    }
                  }
                }
                if (v1317) continue;
                v1229 = 0x2;
              } else {
                if (v1247 === "mailsink") {
                  let v1349 = '',
                    v1350 = 0x32,
                    v1351 = 0x1,
                    v1352 = false;
                  while (v1351 <= 0x2 && !v1352) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v1351 === 0x1) {
                      if (fs.existsSync(MAILSINK_KEY_FILE)) {
                        v1349 = fs.readFileSync(MAILSINK_KEY_FILE, "utf8").trim();
                        const v1353 = {};
                        v1353.name = "Use saved key", v1353.value = "use";
                        const v1354 = {};
                        v1354.name = 'Enter\x20new\x20key', v1354.value = "new";
                        const v1355 = {};
                        v1355.name = "Remove saved key", v1355.value = "remove";
                        const v1356 = {};
                        v1356.name = "⬅️ Back", v1356.value = "back";
                        const v1357 = await selectOption("Mailsink key found (" + v1349.substring(0x0, 0xa) + "...)", [v1353, v1354, v1355, v1356]);
                        if (v1357 === "back") {
                          v1352 = true;
                          break;
                        }
                        if (v1357 === "remove") fs.existsSync(MAILSINK_KEY_FILE) && fs.unlinkSync(MAILSINK_KEY_FILE), v1349 = '';else {
                          if (v1357 === "new") v1349 = '';
                        }
                      }
                      if (!v1349) {
                        v1349 = await promptText("Enter Mailsink API Key:", '');
                        if (v1349.toLowerCase() === 'back') {
                          v1352 = true;
                          break;
                        }
                        const v1358 = {};
                        v1358.name = "Yes", v1358.value = "yes";
                        const v1359 = {};
                        v1359.name = 'No', v1359.value = 'no';
                        const v1360 = await selectOption("Save key?", [v1358, v1359]);
                        if (v1360 === 'yes' && v1349) fs.writeFileSync(MAILSINK_KEY_FILE, v1349, "utf8");
                      }
                      if (v1349) v1351 = 0x2;
                    } else {
                      if (v1351 === 0x2) {
                        const v1361 = await promptText("How many accounts to create? [default: 50]:", '50');
                        if (v1361.toLowerCase() === 'back') {
                          v1351 = 0x1;
                          continue;
                        }
                        v1350 = parseInt(v1361) || 0x32;
                        const v1362 = {};
                        v1362.apiKey = v1349, v1362.totalCount = v1350, v1362.autoConfirm = true, v1242 = v1362, v1237 = null, v1238 = null, v1239 = null, v1240 = null, v1241 = null, v1243 = null, v1244 = null, v1245 = null, v1351 = 0x3;
                      }
                    }
                  }
                  if (v1352) continue;
                  v1229 = 0x2;
                } else {
                  if (v1247 === 'temptf') {
                    let v1363 = 0x32;
                    process.stdout.write('\x1b[2J\x1b[H'), printHeader();
                    const v1364 = await promptText("How many accounts to create? [default: 50] (type back to return):", '50');
                    if (v1364.toLowerCase() === "back") continue;
                    v1363 = parseInt(v1364) || 0x32;
                    const v1365 = {};
                    v1365.providers = '', v1365.totalCount = v1363, v1365.autoConfirm = true, v1243 = v1365, v1237 = null, v1238 = null, v1239 = null, v1240 = null, v1241 = null, v1242 = null, v1244 = null, v1245 = null, v1229 = 0x2;
                  } else {
                    if (v1247 === "mailtm") {
                      let v1366 = 0x32,
                        v1367 = 0x1,
                        v1368 = false,
                        v1369 = [];
                      while (v1367 <= 0x2 && !v1368) {
                        process.stdout.write("[2J[H"), printHeader();
                        if (v1367 === 0x1) {
                          console.log(Y("\n  ▶ Fetching active Mail.tm domains..."));
                          try {
                            const v1370 = await mailtmGetDomains();
                            console.log(B("  ✔ Found " + v1370.length + '\x20active\x20domains:\x20' + v1370.join(',\x20') + '\x0a'));
                            const v1371 = {};
                            v1371.name = "🌀 Random (all " + v1370.length + " domains)", v1371.value = "all";
                            const v1372 = {};
                            v1372.name = "⬅️ Back", v1372.value = "back";
                            const v1373 = await selectOption("Select Mail.tm Domain Mode:", [v1371, ...v1370.map(v1374 => ({
                              'name': "📧 @" + v1374,
                              'value': v1374
                            })), v1372]);
                            if (v1373 === 'back') {
                              v1368 = true;
                              break;
                            }
                            v1369 = v1373 === "all" ? v1370 : [v1373], v1367 = 0x2;
                          } catch (v1375) {
                            console.log(R("\n  ✗ Failed to fetch Mail.tm domains: " + v1375.message + '\x0a')), await new Promise(v1376 => setTimeout(v1376, 0x7d0)), v1368 = true;
                            break;
                          }
                        } else {
                          if (v1367 === 0x2) {
                            const v1377 = await promptText("How many accounts to create? [default: 50]:", '50');
                            if (v1377.toLowerCase() === "back") {
                              v1367 = 0x1;
                              continue;
                            }
                            v1366 = parseInt(v1377) || 0x32;
                            const v1378 = {};
                            v1378.domains = v1369, v1378.totalCount = v1366, v1378.autoConfirm = true, v1244 = v1378, v1237 = null, v1238 = null, v1239 = null, v1240 = null, v1241 = null, v1242 = null, v1243 = null, v1245 = null, v1367 = 0x3;
                          }
                        }
                      }
                      if (v1368) continue;
                      v1229 = 0x2;
                    } else {
                      if (v1247 === "nexa") {
                        let v1379 = '',
                          v1380 = [],
                          v1381 = 0x32,
                          v1382 = "/api/v1/numbers/get",
                          v1383 = false,
                          v1384 = 0x1;
                        while (v1384 <= 0x4 && !v1383) {
                          process.stdout.write("[2J[H"), printHeader();
                          if (v1384 === 0x1) {
                            if (fs.existsSync(NEXA_KEY_FILE)) {
                              v1379 = fs.readFileSync(NEXA_KEY_FILE, "utf8").trim();
                              const v1385 = {};
                              v1385.name = "Use saved key", v1385.value = "use";
                              const v1386 = {};
                              v1386.name = 'Enter\x20new\x20key', v1386.value = "new";
                              const v1387 = {};
                              v1387.name = "Remove saved key", v1387.value = "remove";
                              const v1388 = {};
                              v1388.name = '⬅️\x20Back', v1388.value = "back";
                              const v1389 = await selectOption('NexaOTP\x20key\x20found\x20(' + v1379.substring(0x0, 0xa) + "...)", [v1385, v1386, v1387, v1388]);
                              if (v1389 === "back") {
                                v1383 = true;
                                break;
                              }
                              if (v1389 === 'remove') fs.existsSync(NEXA_KEY_FILE) && fs.unlinkSync(NEXA_KEY_FILE), v1379 = '';else v1389 === 'new' && (v1379 = '');
                            }
                            if (!v1379) {
                              const v1390 = await promptText("Enter NexaOTP API Key:", '');
                              if (v1390.toLowerCase() === "back") {
                                v1383 = true;
                                break;
                              }
                              v1379 = v1390;
                              const v1391 = {};
                              v1391.name = "Yes", v1391.value = 'yes';
                              const v1392 = {};
                              v1392.name = 'No', v1392.value = 'no';
                              const v1393 = await selectOption('Save\x20key?', [v1391, v1392]);
                              if (v1393 === 'yes' && v1379) fs.writeFileSync(NEXA_KEY_FILE, v1379, "utf8");
                            }
                            if (v1379) v1384 = 0x2;
                          } else {
                            if (v1384 === 0x2) {
                              v1380 = [];
                              let v1394 = true;
                              while (v1394) {
                                const v1395 = await promptText("Enter range #" + (v1380.length + 0x1) + " (e.g. 26134XXX) or 'back':", '');
                                if (v1395.toLowerCase() === "back") {
                                  if (v1380.length === 0x0) {
                                    v1384 = 0x1;
                                    break;
                                  } else {
                                    v1380.pop();
                                    continue;
                                  }
                                }
                                if (v1395) v1380.push(v1395);
                                const v1396 = {};
                                v1396.name = "Yes", v1396.value = 'yes';
                                const v1397 = {};
                                v1397.name = 'No', v1397.value = 'no';
                                const v1398 = await selectOption("Added " + v1380.length + '.\x20Add\x20another?', [v1396, v1397]);
                                if (v1398 === 'no') v1394 = false;
                              }
                              if (v1380.length > 0x0) v1384 = 0x3;
                            } else {
                              if (v1384 === 0x3) {
                                const v1399 = await promptText("How many numbers? [default:50]:", '50');
                                if (v1399.toLowerCase() === "back") {
                                  v1384 = 0x2;
                                  continue;
                                }
                                v1381 = parseInt(v1399) || 0x32, v1384 = 0x4;
                              } else {
                                if (v1384 === 0x4) {
                                  const v1400 = {};
                                  v1400.name = "Server 1 (/get)", v1400.value = "/api/v1/numbers/get";
                                  const v1401 = {};
                                  v1401.name = "Server 2 (/p2/get)", v1401.value = "/api/v1/numbers/p2/get";
                                  const v1402 = {};
                                  v1402.name = "Server 3 (/p3/get)", v1402.value = "/api/v1/numbers/p3/get";
                                  const v1403 = {};
                                  v1403.name = "⬅️ Back", v1403.value = 'back';
                                  const v1404 = await selectOption("Select NexaOTP Server:", [v1400, v1401, v1402, v1403]);
                                  if (v1404 === "back") {
                                    v1384 = 0x3;
                                    continue;
                                  }
                                  v1382 = v1404;
                                  const v1405 = {};
                                  v1405.apiKey = v1379, v1405.ranges = v1380, v1405.totalCount = v1381, v1405.serverEndpoint = v1382, v1237 = v1405, v1238 = null, v1384 = 0x5;
                                }
                              }
                            }
                          }
                        }
                        if (v1383) continue;
                        v1229 = 0x2;
                      } else {
                        if (v1247 === "voltx" || v1247 === "stex") {
                          const v1406 = v1247 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
                            v1407 = v1247 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
                            v1408 = v1247 === 'voltx' ? "/MXS47FLFX0U/tnevs/@public/api/getnum" : "/MXS47FLFX0U/tness/@public/api/getnum",
                            v1409 = v1247 === "voltx" ? '/MXS47FLFX0U/tnevs/@public/api/console' : "/MXS47FLFX0U/tness/@public/api/console";
                          let v1410 = '',
                            v1411 = [],
                            v1412 = 0x32,
                            v1413 = false,
                            v1414 = 0x1;
                          while (v1414 <= 0x3 && !v1413) {
                            process.stdout.write("[2J[H"), printHeader();
                            if (v1414 === 0x1) {
                              if (fs.existsSync(v1407)) {
                                v1410 = fs.readFileSync(v1407, 'utf8').trim();
                                const v1415 = {};
                                v1415.name = "Use saved key", v1415.value = "use";
                                const v1416 = {};
                                v1416.name = "Enter new key", v1416.value = "new";
                                const v1417 = {};
                                v1417.name = "Remove saved key", v1417.value = 'remove';
                                const v1418 = {};
                                v1418.name = "⬅️ Back", v1418.value = 'back';
                                const v1419 = await selectOption(v1406 + " key found (" + v1410.substring(0x0, 0xa) + "...)", [v1415, v1416, v1417, v1418]);
                                if (v1419 === "back") {
                                  v1413 = true;
                                  break;
                                }
                                if (v1419 === "remove") fs.existsSync(v1407) && fs.unlinkSync(v1407), v1410 = '';else v1419 === "new" && (v1410 = '');
                              }
                              if (!v1410) {
                                const v1420 = await promptText("Enter " + v1406 + " API Key (mauthapi):", '');
                                if (v1420.toLowerCase() === 'back') {
                                  v1413 = true;
                                  break;
                                }
                                v1410 = v1420;
                                const v1421 = {};
                                v1421.name = "Yes", v1421.value = "yes";
                                const v1422 = {};
                                v1422.name = 'No', v1422.value = 'no';
                                const v1423 = await selectOption('Save\x20key?', [v1421, v1422]);
                                if (v1423 === "yes" && v1410) fs.writeFileSync(v1407, v1410, "utf8");
                              }
                              if (v1410) v1414 = 0x2;
                            } else {
                              if (v1414 === 0x2) {
                                const v1424 = {};
                                v1424.name = "🔍 Auto Range Finder (scan console)", v1424.value = "auto";
                                const v1425 = {};
                                v1425.name = "✏️  Enter manually", v1425.value = "manual";
                                const v1426 = {};
                                v1426.name = "⬅️ Back", v1426.value = "back";
                                const v1427 = await selectOption("How to select ranges?", [v1424, v1425, v1426]);
                                if (v1427 === "back") {
                                  v1414 = 0x1;
                                  continue;
                                }
                                if (v1427 === "auto") {
                                  process.stdout.write("[2J[H"), printHeader(), console.log(chalk.gray("\n  [Range Finder] Fetching live console feed from " + v1406 + "...\n"));
                                  let v1428 = [],
                                    v1429 = '';
                                  try {
                                    v1428 = await twoOoFetchConsole(v1410, v1409);
                                  } catch (v1444) {
                                    v1429 = v1444.message;
                                  }
                                  if (v1429 || v1428.length === 0x0) {
                                    console.log(chalk.red("\n  ✗ Console fetch failed: " + (v1429 || 'No\x20data') + '\x0a')), await promptText('Press\x20Enter\x20to\x20try\x20again\x20or\x20type\x20back:', '');
                                    continue;
                                  }
                                  const v1430 = v1428.slice(0x0, 0x64),
                                    v1431 = {};
                                  v1431.name = "📘 Facebook", v1431.value = "facebook";
                                  const v1432 = {};
                                  v1432.name = "📸 Instagram", v1432.value = "instagram";
                                  const v1433 = {};
                                  v1433.name = "🌐 Meta", v1433.value = "meta";
                                  const v1434 = {};
                                  v1434.name = "📦 All (FB+IG+Meta)", v1434.value = "all";
                                  const v1435 = await selectOption('Filter\x20by\x20app:', [v1431, v1432, v1433, v1434]),
                                    v1436 = {};
                                  v1436.facebook = ["facebook", 'fb'], v1436.instagram = ["instagram", 'ig'], v1436.meta = ["meta"], v1436.all = ["facebook", 'fb', "instagram", 'ig', "meta"];
                                  const v1437 = v1436[v1435],
                                    v1438 = v1430.filter(v1445 => {
                                      const v1446 = (v1445.sid || '').toLowerCase(),
                                        v1447 = (v1445.message || '').toLowerCase();
                                      return v1437.some(v1448 => v1446.includes(v1448) || v1447.includes(v1448));
                                    });
                                  if (v1438.length === 0x0) {
                                    console.log(chalk.red("\n  ✗ No hits for selected app. Try \"All\" or enter range manually.\n")), await promptText("Press Enter to continue:", '');
                                    continue;
                                  }
                                  const v1439 = {};
                                  for (const v1449 of v1438) {
                                    const v1450 = v1449.range || '';
                                    if (!v1450) continue;
                                    v1439[v1450] = (v1439[v1450] || 0x0) + 0x1;
                                  }
                                  const v1440 = Object.entries(v1439).sort((v1451, v1452) => v1452[0x1] - v1451[0x1]).slice(0x0, 0x5);
                                  if (v1440.length === 0x0) {
                                    console.log(chalk.red("\n  ✗ No valid ranges found.\n")), await promptText("Press Enter to continue:", '');
                                    continue;
                                  }
                                  const v1441 = {};
                                  v1441.name = "⚡ Auto (#1 top range)", v1441.value = "auto";
                                  const v1442 = {};
                                  v1442.name = "📊 Show top 5 and select", v1442.value = "select";
                                  const v1443 = await selectOption('Range\x20Finder\x20mode:', [v1441, v1442]);
                                  if (v1443 === "auto") v1411 = [v1440[0x0][0x0]], process.stdout.write("[2J[H"), printHeader(), console.log(chalk.green('\x0a\x20\x20✓\x20Auto-selected\x20range:\x20' + v1411[0x0] + "  (" + v1440[0x0][0x1] + " hits)\n")), await new Promise(v1453 => setTimeout(v1453, 0x4b0)), v1414 = 0x3;else {
                                    process.stdout.write("[2J[H"), printHeader(), console.log(chalk.yellow("\n  #   Range              Hits")), console.log(chalk.gray('\x20\x20' + '─'.repeat(0x1e))), v1440.forEach(([v1457, v1458], v1459) => {
                                      console.log(chalk.cyan('\x20\x20' + String(v1459 + 0x1).padEnd(0x3) + '\x20') + chalk.green(v1457.padEnd(0x12)) + chalk.yellow(String(v1458).padEnd(0x5)) + chalk.gray('█'.repeat(Math.min(v1458, 0xf))));
                                    }), console.log('');
                                    const v1454 = await promptText("Select (e.g. 1  or  1,3  or  1-3):", '1');
                                    if (v1454.toLowerCase() === "back") continue;
                                    const v1455 = new Set();
                                    for (const v1460 of v1454.split(/[\s,]+/).filter(v1461 => v1461)) {
                                      const v1462 = v1460.match(/^(\d+)-(\d+)$/);
                                      if (v1462) for (let v1463 = +v1462[0x1]; v1463 <= +v1462[0x2]; v1463++) {
                                        if (v1463 >= 0x1 && v1463 <= v1440.length) v1455.add(v1463 - 0x1);
                                      } else {
                                        const v1464 = parseInt(v1460);
                                        if (!isNaN(v1464) && v1464 >= 0x1 && v1464 <= v1440.length) v1455.add(v1464 - 0x1);
                                      }
                                    }
                                    const v1456 = [...v1455].sort((v1465, v1466) => v1465 - v1466);
                                    if (v1456.length === 0x0) {
                                      console.log(chalk.red("\n  ✗ No valid selection.\n")), await promptText("Press Enter to retry:", '');
                                      continue;
                                    }
                                    v1411 = v1456.map(v1467 => v1440[v1467][0x0]), console.log(chalk.green('\x0a\x20\x20✓\x20Selected:\x20' + v1411.join(',\x20') + '\x0a')), await new Promise(v1468 => setTimeout(v1468, 0x3e8)), v1414 = 0x3;
                                  }
                                } else {
                                  v1411 = [];
                                  let v1469 = true;
                                  while (v1469) {
                                    const v1470 = await promptText('Enter\x20range\x20#' + (v1411.length + 0x1) + " (e.g. 26134XXX) or 'back':", '');
                                    if (v1470.toLowerCase() === "back") {
                                      if (v1411.length === 0x0) break;else {
                                        v1411.pop();
                                        continue;
                                      }
                                    }
                                    if (v1470) v1411.push(v1470);
                                    const v1471 = {};
                                    v1471.name = 'Yes', v1471.value = "yes";
                                    const v1472 = {};
                                    v1472.name = 'No', v1472.value = 'no';
                                    const v1473 = await selectOption("Added " + v1411.length + ". Add another?", [v1471, v1472]);
                                    if (v1473 === 'no') v1469 = false;
                                  }
                                  if (v1411.length > 0x0) v1414 = 0x3;
                                }
                              } else {
                                if (v1414 === 0x3) {
                                  const v1474 = await promptText("How many numbers? [default:50]:", '50');
                                  if (v1474.toLowerCase() === 'back') {
                                    v1414 = 0x2;
                                    continue;
                                  }
                                  v1412 = parseInt(v1474) || 0x32;
                                  const v1475 = {};
                                  v1475.provider = v1247, v1475.apiKey = v1410, v1475.getPath = v1408, v1475.consolePath = v1409, v1475.ranges = v1411, v1475.totalCount = v1412, v1238 = v1475, v1237 = null, v1414 = 0x4;
                                }
                              }
                            }
                          }
                          if (v1413) continue;
                          v1229 = 0x2;
                        } else {
                          if (v1247 === "smsbower") {
                            let v1476 = '',
                              v1477 = 'fb',
                              v1478 = '0',
                              v1479 = "0.5",
                              v1480 = 0x32,
                              v1481 = 0x1,
                              v1482 = false;
                            while (v1481 <= 0x4 && !v1482) {
                              process.stdout.write('\x1b[2J\x1b[H'), printHeader();
                              if (v1481 === 0x1) {
                                if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                                  v1476 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                                  const v1483 = {};
                                  v1483.name = "Use saved key", v1483.value = "use";
                                  const v1484 = {};
                                  v1484.name = "Enter new key", v1484.value = "new";
                                  const v1485 = {};
                                  v1485.name = "Remove saved key", v1485.value = "remove";
                                  const v1486 = {};
                                  v1486.name = "⬅️ Back", v1486.value = "back";
                                  const v1487 = await selectOption('SMS\x20Bower\x20key\x20found\x20(' + v1476.substring(0x0, 0xa) + "...)", [v1483, v1484, v1485, v1486]);
                                  if (v1487 === 'back') {
                                    v1482 = true;
                                    break;
                                  }
                                  if (v1487 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v1476 = '';else {
                                    if (v1487 === 'new') v1476 = '';
                                  }
                                }
                                if (!v1476) {
                                  v1476 = await promptText("Enter SMS Bower API Key:", '');
                                  if (v1476.toLowerCase() === 'back') {
                                    v1482 = true;
                                    break;
                                  }
                                  const v1488 = {};
                                  v1488.name = "Yes", v1488.value = 'yes';
                                  const v1489 = {};
                                  v1489.name = 'No', v1489.value = 'no';
                                  const v1490 = await selectOption("Save key?", [v1488, v1489]);
                                  if (v1490 === "yes" && v1476) fs.writeFileSync(SMSBOWER_KEY_FILE, v1476, 'utf8');
                                }
                                if (v1476) v1481 = 0x2;
                              } else {
                                if (v1481 === 0x2) {
                                  v1477 = await promptText("Service code (e.g. fb, ig, wa) [default: fb]:", 'fb');
                                  if (v1477.toLowerCase() === "back") {
                                    v1481 = 0x1;
                                    continue;
                                  }
                                  v1477 = v1477 || 'fb', v1481 = 0x3;
                                } else {
                                  if (v1481 === 0x3) {
                                    v1478 = await promptText("Country code (0 = any) [default: 0]:", '0');
                                    if (v1478.toLowerCase() === "back") {
                                      v1481 = 0x2;
                                      continue;
                                    }
                                    v1478 = v1478 || '0';
                                    const v1491 = await promptText("Max price per number (e.g. 0.5) [default: 0.5]:", "0.5");
                                    v1479 = v1491 || "0.5", v1481 = 0x4;
                                  } else {
                                    if (v1481 === 0x4) {
                                      const v1492 = await promptText("How many numbers? [default: 50]:", '50');
                                      if (v1492.toLowerCase() === "back") {
                                        v1481 = 0x3;
                                        continue;
                                      }
                                      v1480 = parseInt(v1492) || 0x32;
                                      const v1493 = {};
                                      v1493.apiKey = v1476, v1493.service = v1477, v1493.country = v1478, v1493.maxPrice = v1479, v1493.totalCount = v1480, v1239 = v1493, v1237 = null, v1238 = null, v1240 = null, v1481 = 0x5;
                                    }
                                  }
                                }
                              }
                            }
                            if (v1482) continue;
                            v1229 = 0x2;
                          } else {
                            if (v1247 === "zenex") {
                              let v1494 = '',
                                v1495 = [],
                                v1496 = 0x32,
                                v1497 = 0x1,
                                v1498 = false;
                              while (v1497 <= 0x3 && !v1498) {
                                process.stdout.write("[2J[H"), printHeader();
                                if (v1497 === 0x1) {
                                  if (fs.existsSync(ZENEX_KEY_FILE)) {
                                    v1494 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                                    const v1499 = {};
                                    v1499.name = 'Use\x20saved\x20key', v1499.value = "use";
                                    const v1500 = {};
                                    v1500.name = "Enter new key", v1500.value = "new";
                                    const v1501 = {};
                                    v1501.name = "Remove saved key", v1501.value = "remove";
                                    const v1502 = {};
                                    v1502.name = "⬅️ Back", v1502.value = "back";
                                    const v1503 = await selectOption("Zenex key found (" + v1494.substring(0x0, 0xa) + "...)", [v1499, v1500, v1501, v1502]);
                                    if (v1503 === "back") {
                                      v1498 = true;
                                      break;
                                    }
                                    if (v1503 === 'remove') fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v1494 = '';else {
                                      if (v1503 === 'new') v1494 = '';
                                    }
                                  }
                                  if (!v1494) {
                                    v1494 = await promptText("Enter Zenex API Key (mapikey):", '');
                                    if (v1494.toLowerCase() === "back") {
                                      v1498 = true;
                                      break;
                                    }
                                    const v1504 = {};
                                    v1504.name = 'Yes', v1504.value = 'yes';
                                    const v1505 = {};
                                    v1505.name = 'No', v1505.value = 'no';
                                    const v1506 = await selectOption("Save key?", [v1504, v1505]);
                                    if (v1506 === "yes" && v1494) fs.writeFileSync(ZENEX_KEY_FILE, v1494, "utf8");
                                  }
                                  if (v1494) v1497 = 0x2;
                                } else {
                                  if (v1497 === 0x2) {
                                    v1495 = [];
                                    let v1507 = true;
                                    while (v1507) {
                                      const v1508 = await promptText("Enter range #" + (v1495.length + 0x1) + " (e.g. 4473845XXX) or 'back':", '');
                                      if (v1508.toLowerCase() === "back") {
                                        if (v1495.length === 0x0) {
                                          v1497 = 0x1;
                                          break;
                                        } else {
                                          v1495.pop();
                                          continue;
                                        }
                                      }
                                      if (v1508) v1495.push(v1508);
                                      const v1509 = {};
                                      v1509.name = "Yes", v1509.value = "yes";
                                      const v1510 = {};
                                      v1510.name = 'No', v1510.value = 'no';
                                      const v1511 = await selectOption("Added " + v1495.length + '.\x20Add\x20another?', [v1509, v1510]);
                                      if (v1511 === 'no') v1507 = false;
                                    }
                                    if (v1495.length > 0x0) v1497 = 0x3;
                                  } else {
                                    if (v1497 === 0x3) {
                                      const v1512 = await promptText('How\x20many\x20numbers?\x20[default:\x2050]:', '50');
                                      if (v1512.toLowerCase() === "back") {
                                        v1497 = 0x2;
                                        continue;
                                      }
                                      v1496 = parseInt(v1512) || 0x32;
                                      const v1513 = {};
                                      v1513.apiKey = v1494, v1513.ranges = v1495, v1513.totalCount = v1496, v1240 = v1513, v1237 = null, v1238 = null, v1239 = null, v1497 = 0x4;
                                    }
                                  }
                                }
                              }
                              if (v1498) continue;
                              v1229 = 0x2;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if (v1229 === 0x2) {
          const v1514 = {};
          v1514.name = "10 Threads", v1514.value = '10';
          const v1515 = {};
          v1515.name = "20 Threads (Default)", v1515.value = '20';
          const v1516 = {};
          v1516.name = '50\x20Threads\x20(Fast)', v1516.value = '50';
          const v1517 = {};
          v1517.name = "100 Threads (Extreme)", v1517.value = '100';
          const v1518 = {};
          v1518.name = "⌨️ Custom...", v1518.value = "custom";
          const v1519 = {};
          v1519.name = '⬅️\x20Go\x20Back\x20to\x20Targets\x20Selection', v1519.value = "back";
          const v1520 = await selectOption("SELECT THREAD COUNT", [v1514, v1515, v1516, v1517, v1518, v1519]);
          if (v1520 === "back") {
            v1229 = 0x1;
            continue;
          }
          if (v1520 === 'custom') {
            const v1521 = await promptText("Enter custom thread count (1-200, type 'back' to go back):", '20');
            if (v1521.toLowerCase() === "back") continue;
            v1231 = String(Math.max(0x1, parseInt(v1521) || 0x14));
          } else v1231 = v1520;
          v1229 = 0x3;
        } else {
          if (v1229 === 0x3) {
            const v1522 = {};
            v1522.name = "✏️ Custom File Path", v1522.value = "custom";
            const v1523 = {};
            v1523.name = "🚫 None (Direct Connection)", v1523.value = "none";
            const v1524 = {};
            v1524.name = "⬅️ Go Back to Thread Count", v1524.value = "back";
            const v1525 = await selectOption("SELECT PROXIES FILE", [v1522, v1523, v1524]);
            if (v1525 === "back") {
              v1229 = 0x2;
              continue;
            }
            if (v1525 === "custom") {
              const v1526 = await promptText("Enter Proxies File Path:", "proxies.txt");
              if (v1526.toLowerCase() === "back") continue;
              v1232 = v1526;
            } else v1525 === "none" ? v1232 = "none" : v1232 = v1525;
            v1229 = 0x4;
          } else {
            if (v1229 === 0x4) {
              const v1527 = {};
              v1527.name = "🖥️  www.facebook.com (Desktop GraphQL)", v1527.value = "desktop";
              const v1528 = {};
              v1528.name = "⬅️ Go Back to Proxies Selection", v1528.value = "back";
              const v1529 = await selectOption("SELECT API TARGET", [v1527, v1528]);
              if (v1529 === 'back') {
                v1229 = 0x3;
                continue;
              }
              v1233 = "desktop", v1229 = 0x5;
            } else {
              if (v1229 === 0x5) {
                let v1530;
                if (v1233 === "desktop") {
                  const v1532 = {};
                  v1532.name = "🌀 Random (rotates every number)", v1532.value = "random";
                  const v1533 = {};
                  v1533.name = "🟢 Google Chrome", v1533.value = "chrome";
                  const v1534 = {};
                  v1534.name = "🦊 Mozilla Firefox", v1534.value = 'firefox';
                  const v1535 = {};
                  v1535.name = "🔵 Microsoft Edge", v1535.value = "edge";
                  const v1536 = {};
                  v1536.name = "🍎 Apple Safari", v1536.value = "safari";
                  const v1537 = {};
                  v1537.name = "🔴 Opera", v1537.value = 'opera';
                  const v1538 = {};
                  v1538.name = '🦁\x20Brave', v1538.value = "brave";
                  const v1539 = {};
                  v1539.name = "⬅️ Go Back to API Target", v1539.value = 'back', v1530 = [v1532, v1533, v1534, v1535, v1536, v1537, v1538, v1539];
                } else {
                  if (v1233 === "mobile") {
                    const v1540 = {};
                    v1540.name = "🌀 Random (Chrome 150 / Samsung / Firefox)", v1540.value = "random";
                    const v1541 = {};
                    v1541.name = "🟢 Android Chrome 150", v1541.value = "chrome";
                    const v1542 = {};
                    v1542.name = '🟠\x20Samsung\x20Browser', v1542.value = "samsung";
                    const v1543 = {};
                    v1543.name = "🦊 Firefox Android", v1543.value = "firefox_android";
                    const v1544 = {};
                    v1544.name = "⬅️ Go Back to API Target", v1544.value = "back", v1530 = [v1540, v1541, v1542, v1543, v1544];
                  } else {
                    const v1545 = {};
                    v1545.name = '🌀\x20Random\x20(all\x20browsers)', v1545.value = 'random';
                    const v1546 = {};
                    v1546.name = "🟢 Chrome  (desktop Chrome / Android Chrome)", v1546.value = "chrome";
                    const v1547 = {};
                    v1547.name = "🦊 Firefox (desktop Firefox / Firefox Android)", v1547.value = "firefox";
                    const v1548 = {};
                    v1548.name = "🔵 Edge    (desktop only)", v1548.value = "edge";
                    const v1549 = {};
                    v1549.name = "🟠 Samsung Browser (mobile only)", v1549.value = 'samsung';
                    const v1550 = {};
                    v1550.name = "⬅️ Go Back to API Target", v1550.value = "back", v1530 = [v1545, v1546, v1547, v1548, v1549, v1550];
                  }
                }
                const v1531 = await selectOption("SELECT BROWSER PROFILE", v1530);
                if (v1531 === "back") {
                  v1229 = 0x4;
                  continue;
                }
                v1234 = v1531, v1229 = 0x6;
              } else {
                if (v1229 === 0x6) {
                  const v1551 = await promptText('Enter\x20Resend\x20Count\x20per\x20number\x20(type\x20\x27back\x27\x20to\x20go\x20back)\x20[default:\x201]:', '1');
                  if (v1551.toLowerCase() === "back") {
                    v1229 = 0x5;
                    continue;
                  }
                  v1235 = String(Math.max(0x1, parseInt(v1551) || 0x1)), v1229 = 0x7;
                } else {
                  if (v1229 === 0x7) {
                    const v1552 = {};
                    v1552.name = "🔒 Auto-generate random password (e.g. Rexk92j#)", v1552.value = "auto";
                    const v1553 = {};
                    v1553.name = "📅 Random pass + Date (e.g. Rexk92j#17aug)", v1553.value = "random_date";
                    const v1554 = {};
                    v1554.name = "✏️  Use custom password for all accounts", v1554.value = 'custom';
                    const v1555 = {};
                    v1555.name = "⬅️ Go Back to Resend Count", v1555.value = 'back';
                    const v1556 = await selectOption("SELECT ACCOUNT PASSWORD MODE", [v1552, v1553, v1554, v1555]);
                    if (v1556 === "back") {
                      v1229 = 0x6;
                      continue;
                    }
                    if (v1556 === "custom") {
                      const v1557 = await promptText("Enter custom password (min 6 chars, type 'back' to go back):", '');
                      if (v1557.toLowerCase() === "back") continue;
                      !v1557 || v1557.length < 0x6 ? v1236 = null : v1236 = v1557;
                    } else v1556 === "random_date" ? v1236 = 'random_date' : v1236 = null;
                    v1229 = 0x8;
                  } else {
                    if (v1229 === 0x8) {
                      const v1558 = !!(v1238 || v1239 || v1240);
                      if (v1558) {
                        const v1559 = v1238 ? v1238.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v1239 ? "📱 SMS Bower" : "⚡ Zenex",
                          v1560 = {};
                        v1560.name = "✅ Yes — Auto poll OTP & confirm account", v1560.value = "yes";
                        const v1561 = {};
                        v1561.name = "⛔ No  — Just trigger OTP, save to successful.txt", v1561.value = 'no';
                        const v1562 = {};
                        v1562.name = "⬅️ Go Back to Password Mode", v1562.value = "back";
                        const v1563 = await selectOption("🤖 AUTO CONFIRM OTP? [" + v1559 + ']', [v1560, v1561, v1562]);
                        if (v1563 === "back") {
                          v1229 = 0x7;
                          continue;
                        }
                        if (v1563 === "yes") {
                          if (v1238) {
                            const v1564 = v1238.provider === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/success-otp" : "/MXS47FLFX0U/tness/@public/api/success-otp";
                            v1238.autoConfirm = true, v1238.otpPath = v1564;
                          } else {
                            if (v1239) v1239.autoConfirm = true;else v1240 && (v1240.autoConfirm = true);
                          }
                        } else {
                          if (v1238) v1238.autoConfirm = false;
                          if (v1239) v1239.autoConfirm = false;
                          if (v1240) v1240.autoConfirm = false;
                        }
                      }
                      v1229 = 0x9;
                    } else {
                      if (v1229 === 0x9) break;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    process.stdin.pause();
    const v1248 = {};
    v1248.targets = v1230;
    return v1248.threads = v1231, v1248.proxies = v1232, v1248.apiMode = v1233, v1248.browser = v1234, v1248.resend = v1235, v1248.customPassword = v1236, v1248.nexaConfig = v1237, v1248.twoOoConfig = v1238, v1248.smsBowerConfig = v1239, v1248.zenexConfig = v1240, v1248.outlookConfig = v1241, v1248.mailsinkConfig = v1242, v1248.temptfConfig = v1243, v1248.mailtmConfig = v1244, v1248.mailcxConfig = v1245, v1248.randomTempmailConfig = v1246, v1248;
  }
  async function confirmWizard() {
    const fn28 = v1572 => v1572.replace(/[^0-9]/g, '');
    let v1565 = 0x1,
      v1566 = "panel",
      v1567 = [],
      v1568 = '',
      v1569 = 0xa,
      v1570 = "none";
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v1565 === 0x1) {
        const v1573 = {};
        v1573.name = "📱 Panel Match  — Match OTP file (panel) + successful.txt (cookies)", v1573.value = 'panel';
        const v1574 = {};
        v1574.name = "📄 Direct       — Single file with all details already combined", v1574.value = "direct";
        const v1575 = {};
        v1575.name = "🔑 Login        — Auto-login with number|otp|password (no cookie needed)", v1575.value = "login";
        const v1576 = {};
        v1576.name = "❌ Exit Program", v1576.value = 'exit', v1566 = await selectOption("SELECT CONFIRM METHOD", [v1573, v1574, v1575, v1576]);
        if (v1566 === "exit") process.exit(0x0);
        v1565 = 0x2;
      } else {
        if (v1565 === 0x2) {
          v1567 = [];
          if (v1566 === "panel") {
            const v1577 = {};
            v1577.name = "📄 otp.txt (Default)", v1577.value = "otp.txt";
            const v1578 = {};
            v1578.name = "✏️ Custom File Path", v1578.value = "custom";
            const v1579 = {};
            v1579.name = '⬅️\x20Go\x20Back\x20to\x20Confirm\x20Method', v1579.value = 'back';
            const v1580 = await selectOption('SELECT\x20OTP\x20FILE\x20(FROM\x20SMS\x20PANEL)', [v1577, v1578, v1579]);
            if (v1580 === 'back') {
              v1565 = 0x1;
              continue;
            }
            let v1581 = v1580;
            if (v1580 === 'custom') {
              const v1593 = await promptText("Enter OTP File Path:", 'otp.txt');
              if (v1593.toLowerCase() === "back") continue;
              v1581 = v1593;
            }
            const v1582 = path.resolve(v1581);
            if (!fs.existsSync(v1582)) {
              console.error(R("\n  ✗ OTP file not found: " + v1582 + '\x0a')), await new Promise(v1594 => setTimeout(v1594, 0x5dc));
              continue;
            }
            v1568 = v1582;
            const v1583 = {};
            v1583.name = "📄 successful.txt (Default)", v1583.value = "successful.txt";
            const v1584 = {};
            v1584.name = "✏️ Custom File Path", v1584.value = "custom";
            const v1585 = {};
            v1585.name = "⬅️ Go Back to OTP File", v1585.value = "back";
            const v1586 = await selectOption("SELECT ACCOUNTS FILE (FROM CREATE RUN)", [v1583, v1584, v1585]);
            if (v1586 === "back") continue;
            let v1587 = v1586;
            if (v1586 === 'custom') {
              const v1595 = await promptText("Enter Accounts File Path:", "successful.txt");
              if (v1595.toLowerCase() === "back") continue;
              v1587 = v1595;
            }
            const v1588 = path.resolve(v1587);
            if (!fs.existsSync(v1588)) {
              console.error(R("\n  ✗ Accounts file not found: " + v1588 + '\x0a')), await new Promise(v1596 => setTimeout(v1596, 0x5dc));
              continue;
            }
            const v1589 = fs.readFileSync(v1582, "utf8").split(/\r?\n/).map(v1597 => v1597.trim()).filter(v1598 => v1598.length > 0x3),
              v1590 = new Map();
            for (const v1599 of v1589) {
              let v1600 = '',
                v1601 = '';
              if (v1599.includes('|')) [v1600, v1601] = v1599.split('|');else {
                if (v1599.includes('\x09')) [v1600, v1601] = v1599.split('\x09');else {
                  const v1602 = v1599.split(/\s+/);
                  v1600 = v1602[0x0], v1601 = v1602[0x1] || '';
                }
              }
              if (v1600 && v1601) v1590.set(fn28(v1600), v1601.trim());
            }
            const v1591 = fs.readFileSync(v1588, "utf8").split(/\r?\n/).map(v1603 => v1603.trim()).filter(v1604 => v1604.length > 0x5),
              v1592 = new Map();
            for (const v1605 of v1591) {
              const v1606 = v1605.split('|');
              if (v1606.length >= 0x3) {
                const v1607 = v1606[0x0].trim(),
                  v1608 = v1606[0x1].trim(),
                  v1609 = v1606.slice(0x2).join('|').replace(/\|?UID:[0-9]+$/, '').trim();
                v1592.set(fn28(v1607), {
                  'phone': v1607,
                  'password': v1608,
                  'cookie': v1609
                });
              }
            }
            for (const [v1610, v1611] of v1590) {
              if (v1592.has(v1610)) {
                const v1612 = v1592.get(v1610),
                  v1613 = {};
                v1613.phone = v1612.phone, v1613.otp = v1611, v1613.password = v1612.password, v1613.cookie = v1612.cookie, v1567.push(v1613);
              }
            }
            if (v1567.length === 0x0) {
              console.error(R("  ✗ No matching numbers found between the two files. Retry file selection.")), await new Promise(v1614 => setTimeout(v1614, 0x7d0));
              continue;
            }
            v1565 = 0x3;
          } else {
            if (v1566 === "login") {
              const v1615 = {};
              v1615.name = '📄\x20login.txt\x20(Default)', v1615.value = "login.txt";
              const v1616 = {};
              v1616.name = '✏️\x20Custom\x20File\x20Path', v1616.value = 'custom';
              const v1617 = {};
              v1617.name = "⬅️ Go Back to Confirm Method", v1617.value = "back";
              const v1618 = await selectOption("SELECT LOGIN FILE (phone|otp|password)", [v1615, v1616, v1617]);
              if (v1618 === "back") {
                v1565 = 0x1;
                continue;
              }
              let v1619 = v1618;
              if (v1618 === "custom") {
                const v1622 = await promptText("Enter Login File Path:", "login.txt");
                if (v1622.toLowerCase() === 'back') continue;
                v1619 = v1622;
              }
              const v1620 = path.resolve(v1619);
              if (!fs.existsSync(v1620)) {
                console.error(R("\n  ✗ File not found: " + v1620 + '\x0a')), await new Promise(v1623 => setTimeout(v1623, 0x5dc));
                continue;
              }
              v1568 = v1620;
              const v1621 = fs.readFileSync(v1620, "utf8").split(/\r?\n/).map(v1624 => v1624.trim()).filter(v1625 => v1625.length > 0x5);
              for (const v1626 of v1621) {
                const v1627 = v1626.split('|');
                if (v1627.length >= 0x3) {
                  const v1628 = v1627[0x0].trim(),
                    v1629 = v1627[0x1].trim(),
                    v1630 = v1627[0x2].trim();
                  if (v1628 && v1629 && v1630) v1567.push({
                    'phone': v1628,
                    'otp': v1629,
                    'password': v1630,
                    'cookie': null,
                    'loginMode': true
                  });
                }
              }
              if (v1567.length === 0x0) {
                console.error(R("  ✗ No valid entries found in file. Expected: phone|otp|password")), await new Promise(v1631 => setTimeout(v1631, 0x7d0));
                continue;
              }
              v1565 = 0x3;
            } else {
              const v1632 = {};
              v1632.name = "📄 direct.txt (Default)", v1632.value = "direct.txt";
              const v1633 = {};
              v1633.name = "✏️ Custom File Path", v1633.value = "custom";
              const v1634 = {};
              v1634.name = "⬅️ Go Back to Confirm Method", v1634.value = "back";
              const v1635 = await selectOption("SELECT DIRECT FILE (phone|otp|password|cookie)", [v1632, v1633, v1634]);
              if (v1635 === "back") {
                v1565 = 0x1;
                continue;
              }
              let v1636 = v1635;
              if (v1635 === "custom") {
                const v1639 = await promptText("Enter Direct File Path:", "direct.txt");
                if (v1639.toLowerCase() === "back") continue;
                v1636 = v1639;
              }
              const v1637 = path.resolve(v1636);
              if (!fs.existsSync(v1637)) {
                console.error(R("\n  ✗ File not found: " + v1637 + '\x0a')), await new Promise(v1640 => setTimeout(v1640, 0x5dc));
                continue;
              }
              v1568 = v1637;
              const v1638 = fs.readFileSync(v1637, "utf8").split(/\r?\n/).map(v1641 => v1641.trim()).filter(v1642 => v1642.length > 0x5);
              for (const v1643 of v1638) {
                const v1644 = v1643.split('|');
                if (v1644.length >= 0x4) {
                  const v1645 = v1644[0x0].trim(),
                    v1646 = v1644[0x1].trim(),
                    v1647 = v1644[0x2].trim(),
                    v1648 = v1644.slice(0x3).join('|').trim();
                  if (v1646 && v1648) v1567.push({
                    'phone': v1645,
                    'otp': v1646,
                    'password': v1647,
                    'cookie': v1648
                  });
                }
              }
              if (v1567.length === 0x0) {
                console.error(R("  ✗ No valid entries found in file. Expected: phone|otp|password|cookie")), await new Promise(v1649 => setTimeout(v1649, 0x7d0));
                continue;
              }
              v1565 = 0x3;
            }
          }
        } else {
          if (v1565 === 0x3) {
            const v1650 = {};
            v1650.name = "5 Threads", v1650.value = '5';
            const v1651 = {};
            v1651.name = "10 Threads (Default)", v1651.value = '10';
            const v1652 = {};
            v1652.name = '20\x20Threads', v1652.value = '20';
            const v1653 = {};
            v1653.name = "50 Threads", v1653.value = '50';
            const v1654 = {};
            v1654.name = "100 Threads", v1654.value = "100";
            const v1655 = {};
            v1655.name = '⌨️\x20Custom...', v1655.value = "custom";
            const v1656 = {};
            v1656.name = "⬅️ Go Back to File Selection", v1656.value = "back";
            const v1657 = await selectOption("SELECT THREAD COUNT", [v1650, v1651, v1652, v1653, v1654, v1655, v1656]);
            if (v1657 === "back") {
              v1565 = 0x2;
              continue;
            }
            if (v1657 === "custom") {
              const v1658 = await promptText('Enter\x20custom\x20thread\x20count\x20(type\x20\x27back\x27\x20to\x20go\x20back):', '10');
              if (v1658.toLowerCase() === "back") continue;
              v1569 = Math.max(0x1, parseInt(v1658) || 0xa);
            } else v1569 = parseInt(v1657) || 0xa;
            v1565 = 0x4;
          } else {
            if (v1565 === 0x4) {
              const v1659 = {};
              v1659.name = "📄 proxies.txt (Default)", v1659.value = "proxies.txt";
              const v1660 = {};
              v1660.name = "🚫 None (Direct Connection)", v1660.value = "none";
              const v1661 = {};
              v1661.name = "✏️ Custom File Path", v1661.value = 'custom';
              const v1662 = {};
              v1662.name = "⬅️ Go Back to Thread Count", v1662.value = "back";
              const v1663 = await selectOption("SELECT PROXIES FILE", [v1659, v1660, v1661, v1662]);
              if (v1663 === "back") {
                v1565 = 0x3;
                continue;
              }
              if (v1663 === "custom") {
                const v1664 = await promptText("Enter Proxies File Path:", "proxies.txt");
                if (v1664.toLowerCase() === "back") continue;
                v1570 = v1664;
              } else v1663 === "none" ? v1570 = "none" : v1570 = v1663;
              v1565 = 0x5;
            } else {
              if (v1565 === 0x5) break;
            }
          }
        }
      }
    }
    process.stdin.pause();
    const v1571 = {};
    v1571.otpFile = v1568;
    return v1571.matched = v1567, v1571.threads = v1569, v1571.proxiesFile = v1570, v1571;
  }
  async function loginWithPassword({
    phone: v1665,
    password: v1666,
    otp: v1667,
    proxy: v1668
  }) {
    const v1669 = '+' + v1665.replace(/\D/g, ''),
      v1670 = getRandomClient("android", "mobile") || getRandomClient("random", "mobile");
    let v1671 = {};
    const fn29 = v1693 => {
        for (const v1694 of v1693 || []) {
          const v1695 = v1694.split(';')[0x0].trim(),
            v1696 = v1695.indexOf('=');
          if (v1696 > 0x0) v1671[v1695.slice(0x0, v1696)] = v1695.slice(v1696 + 0x1);
        }
      },
      fn30 = () => Object.entries(v1671).map(([v1697, v1698]) => v1697 + '=' + v1698).join(';\x20'),
      fn31 = v1699 => {
        const v1700 = v1699.match(/"LSD"[^}]+"token":"([^"]+)"/) || v1699.match(/name="lsd" value="([^"]+)"/),
          v1701 = v1699.match(/name="nh" value="([^"]+)"/) || v1699.match(/"nh":"([^"]+)"/),
          v1702 = v1699.match(/"DTSGInitData"[^}]+"token":"([^"]+)"/) || v1699.match(/name="fb_dtsg" value="([^"]+)"/) || v1699.match(/"dtsg":\{"token":"([^"]+)"/),
          v1703 = v1699.match(/name="jazoest" value="([^"]+)"/),
          v1704 = v1699.match(/action="(\/(?:login\/)?checkpoint\/[^"]+)"/i) || v1699.match(/action="(https?:\/\/www\.facebook\.com\/(?:login\/)?checkpoint\/[^"]+)"/i),
          v1705 = {};
        v1705.lsd = v1700 ? v1700[0x1] : '', v1705.nh = v1701 ? v1701[0x1] : '', v1705.dtsg = v1702 ? v1702[0x1] : '';
        v1705.jazoest = v1703 ? v1703[0x1] : '', v1705.formAction = v1704 ? v1704[0x1] : '';
        return v1705;
      },
      v1672 = {};
    v1672.email = v1669, v1672.password = v1666, v1672.login = '1', v1672.api_key = "882a8490361da98702bf97a021ddc14d", v1672.format = "json", v1672.generate_session_cookies = '1', v1672.locale = "en_US", v1672.method = "auth.login";
    const v1673 = v1672,
      v1674 = require("crypto"),
      v1675 = Object.keys(v1673).sort(),
      v1676 = v1675.map(v1706 => v1706 + '=' + v1673[v1706]).join('') + "62f8ce9f74b12f84c123cc23437a4a32";
    v1673.sig = v1674.createHash("md5").update(v1676).digest("hex");
    const v1677 = new URLSearchParams(v1673).toString();
    let v1678;
    try {
      const v1707 = {};
      v1707["User-Agent"] = v1670.userAgent || "Dalvik/2.1.0 (Linux; U; Android 9; SM-G960F Build/PPR1.180610.011)", v1707["Content-Type"] = "application/x-www-form-urlencoded", v1707.Accept = "application/json", v1707["Accept-Language"] = "en-US", v1707["X-FB-HTTP-Engine"] = "Liger", v1678 = await sendRequest('https://b-api.facebook.com/method/auth.login', 'POST', v1707, v1677, v1668, 0x3a98), fn29(v1678.cookies || []);
      const v1708 = typeof v1678.data === 'string' ? v1678.data : JSON.stringify(v1678.data || {});
      debugLog(v1665, "mobile-login", "status=" + v1678.status + " cookies=" + Object.keys(v1671).join(',') + " body=" + v1708.substring(0x0, 0x1f4));
      let v1709;
      try {
        v1709 = typeof v1678.data === "object" ? v1678.data : JSON.parse(v1708);
      } catch (v1710) {
        v1709 = null;
      }
      if (v1709 && v1709.uid && v1709.session_key) {
        v1671.c_user = String(v1709.uid);
        if (v1709.session_cookies) {
          for (const v1711 of v1709.session_cookies) v1671[v1711.name] = v1711.value;
        }
        return debugLog(v1665, "mobile-login-success", 'uid=' + v1709.uid), fn30();
      }
      v1709 && (v1709.error_code === 0x196 || v1708.includes("checkpoint")) && debugLog(v1665, 'mobile-checkpoint', v1708.substring(0x0, 0x12c));
    } catch (v1712) {
      debugLog(v1665, "mobile-login-err", v1712.message);
    }
    const v1679 = {};
    v1679['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36", v1679.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", v1679["Accept-Language"] = "en-US,en;q=0.9", v1679["Accept-Encoding"] = "gzip, deflate, br", v1679["Sec-Fetch-Mode"] = "navigate", v1679["Sec-Fetch-Site"] = "none", v1679['Sec-Fetch-Dest'] = "document";
    const v1680 = await sendRequest("https://www.facebook.com/login/?next=&lwv=101", "GET", v1679, null, v1668, 0x3a98);
    fn29(v1680.cookies || []);
    const v1681 = fn31(v1680.data || '');
    if (!v1681.lsd) throw new Error("Could not extract lsd from login page");
    const v1682 = new URLSearchParams({
        'lsd': v1681.lsd,
        'jazoest': v1681.jazoest || "2457",
        'email': v1669,
        'pass': v1666,
        'login': '1',
        'default_persistent': '0',
        'timezone': '-300',
        'lgndim': "eyJ3IjoxOTIwLCJoIjoxMDgwLCJhdyI6MTkyMCwiYWgiOjEwNDAsImMiOjI0fQ==",
        'lgnrnd': Math.random().toString(0x24).substring(0x2, 0xc).toUpperCase(),
        'lgnjs': Math.floor(Date.now() / 0x3e8).toString()
      }).toString(),
      v1683 = await sendRequest("https://www.facebook.com/login/?next=&lwv=101", "POST", {
        'User-Agent': 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/125.0.0.0\x20Safari/537.36',
        'Content-Type': "application/x-www-form-urlencoded",
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        'Accept-Language': "en-US,en;q=0.9",
        'Accept-Encoding': "gzip, deflate, br",
        'Origin': "https://www.facebook.com",
        'Referer': "https://www.facebook.com/login/?next=&lwv=101",
        'Cookie': fn30(),
        'Sec-Fetch-Mode': "navigate",
        'Sec-Fetch-Site': "same-origin",
        'Sec-Fetch-Dest': "document",
        'x-fb-lsd': v1681.lsd
      }, v1682, v1668, 0x3a98);
    fn29(v1683.cookies || []);
    if (fn30().includes('c_user=')) return fn30();
    const v1684 = v1683.headers && v1683.headers.location || '',
      v1685 = v1683.data || '',
      v1686 = v1685.includes("approvals_code") || v1685.includes('name=\x22nh\x22'),
      v1687 = v1684.includes("checkpoint") || v1684.includes("confirmemail");
    debugLog(v1665, 'desktop-login-post', "loc=\"" + v1684 + "\" inline_otp=" + v1686 + " redirect_cp=" + v1687 + " cookies=" + Object.keys(v1671).join(',') + " body_snippet=" + v1685.substring(0x0, 0xc8));
    if (!v1686 && !v1687) throw new Error('Login\x20failed\x20—\x20wrong\x20password\x20or\x20account\x20suspended');
    if (!v1667) throw new Error('OTP\x20gate\x20detected\x20but\x20no\x20OTP\x20provided');
    let v1688 = '',
      v1689 = "https://www.facebook.com/login/checkpoint/";
    if (v1686) v1688 = v1685, debugLog(v1665, "otp-source", "INLINE in login POST body");else {
      const v1713 = v1684.startsWith("http") ? v1684 : "https://www.facebook.com" + v1684,
        v1714 = await sendRequest(v1713, "GET", {
          'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
          'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          'Accept-Language': "en-US,en;q=0.9",
          'Accept-Encoding': "gzip, deflate, br",
          'Cookie': fn30(),
          'Referer': 'https://www.facebook.com/login/',
          'Sec-Fetch-Mode': "navigate",
          'Sec-Fetch-Site': "same-origin",
          'Sec-Fetch-Dest': "document"
        }, null, v1668, 0x3a98);
      fn29(v1714.cookies || []), v1688 = v1714.data || '', v1689 = v1713, debugLog(v1665, 'otp-source', "REDIRECT to " + v1713);
    }
    const v1690 = fn31(v1688);
    v1690.formAction && (v1689 = v1690.formAction.startsWith("http") ? v1690.formAction : 'https://www.facebook.com' + v1690.formAction);
    debugLog(v1665, "otp-tokens", "nh=\"" + v1690.nh + "\" dtsg=\"" + v1690.dtsg + "\" lsd=\"" + v1690.lsd + "\" action=\"" + v1689 + '\x22');
    const v1691 = new URLSearchParams();
    if (v1690.nh) v1691.set('nh', v1690.nh);
    if (v1690.dtsg) v1691.set("fb_dtsg", v1690.dtsg);
    v1691.set('lsd', v1690.lsd || v1681.lsd), v1691.set("approvals_code", String(v1667).trim()), v1691.set("submit[Continue]", '');
    const v1692 = await sendRequest(v1689, "POST", {
      'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
      'Content-Type': "application/x-www-form-urlencoded",
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
      'Accept-Encoding': "gzip, deflate, br",
      'Origin': 'https://www.facebook.com',
      'Referer': v1689,
      'Cookie': fn30(),
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': "same-origin",
      'Sec-Fetch-Dest': "document"
    }, v1691.toString(), v1668, 0x3a98);
    fn29(v1692.cookies || []), debugLog(v1665, 'otp-result', "status=" + v1692.status + " cookies=" + Object.keys(v1671).join(',') + " c_user=" + (v1671.c_user || "MISSING"));
    if (!fn30().includes("c_user=")) throw new Error("OTP submission failed — code may be expired or wrong");
    return fn30();
  }
  async function confirmAccount({
    phone: v1715,
    otp: v1716,
    cookie: v1717,
    proxy: v1718,
    uid: v1719,
    fallbackDtsg: v1720,
    fallbackLsd: v1721,
    client: v1722
  }) {
    let v1723 = '';
    const v1724 = (v1717 || '').match(/c_user=([0-9]+)/);
    if (v1724) v1723 = v1724[0x1];else {
      if (v1719 && /^\d+$/.test(String(v1719))) v1723 = String(v1719);
    }
    const v1725 = v1722 || getRandomClient('random', "desktop"),
      v1726 = {};
    v1726["User-Agent"] = v1725.userAgent, v1726.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", v1726["Accept-Language"] = "en-US,en;q=0.9", v1726['Accept-Encoding'] = "gzip, deflate, br", v1726.Cookie = v1717 || '', v1726.Referer = 'https://www.facebook.com/reg/?entry_point=login&next=', v1726["Sec-Fetch-Dest"] = "document", v1726["Sec-Fetch-Mode"] = "navigate", v1726['Sec-Fetch-Site'] = "same-origin", v1726["Upgrade-Insecure-Requests"] = '1';
    const v1727 = v1726;
    let v1728 = '',
      v1729 = null;
    try {
      v1729 = await sendRequest("https://www.facebook.com/confirmemail.php?next=https%3A%2F%2Fwww.facebook.com%2F", "GET", v1727, null, v1718, 0x61a8, true), v1728 = v1729?.["data"] || '';
    } catch (v1759) {
      debugLog(v1715, "confirm-page-err", v1759.message);
    }
    if (!v1723 && v1729) {
      const v1760 = (v1729.cookies || []).map(v1761 => v1761.split(';')[0x0]).join(';\x20').match(/c_user=([0-9]+)/);
      if (v1760) v1723 = v1760[0x1];else {
        const v1762 = v1728.match(/"USER_ID":"(\d+)"/) || v1728.match(/"ACCOUNT_ID":"(\d+)"/) || v1728.match(/"actor_id":"(\d+)"/);
        if (v1762) v1723 = v1762[0x1];
      }
    }
    if (!v1723 && v1719 && /^\d+$/.test(String(v1719))) v1723 = String(v1719);
    if (!v1723 || v1723 === '0') {
      try {
        const v1763 = await sendRequest("https://www.facebook.com/confirmemail.php?e=" + encodeURIComponent(v1715) + "&c=" + encodeURIComponent(v1716) + "&next=https%3A%2F%2Fwww.facebook.com%2F", "GET", v1727, null, v1718, 0x4e20, true);
        if (v1763 && (v1763.cookies || []).some(v1764 => v1764.includes('c_user='))) {
          const v1765 = (v1763.cookies || []).map(v1766 => v1766.split(';')[0x0]).join(';\x20').match(/c_user=([0-9]+)/);
          v1765 && (v1723 = v1765[0x1], v1729 = v1763, v1728 = v1763.data || '');
        }
      } catch (v1767) {}
      if (!v1723 || v1723 === '0') try {
        const v1768 = {};
        v1768["User-Agent"] = 'Mozilla/5.0\x20(Linux;\x20Android\x2014;\x20Mobile)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/120.0.0.0\x20Mobile\x20Safari/537.36', v1768.Accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', v1768["Accept-Language"] = "en-US,en;q=0.9", v1768.Cookie = v1717 || '';
        const v1769 = await sendRequest("https://m.facebook.com/confirmemail.php?e=" + encodeURIComponent(v1715) + "&c=" + encodeURIComponent(v1716) + '&next=https%3A%2F%2Fm.facebook.com%2F', "GET", v1768, null, v1718, 0x4e20, true);
        if (v1769 && (v1769.cookies || []).some(v1770 => v1770.includes("c_user="))) {
          const v1771 = (v1769.cookies || []).map(v1772 => v1772.split(';')[0x0]).join(';\x20').match(/c_user=([0-9]+)/);
          if (v1771) return v1723 = v1771[0x1], {
            'success': true,
            'phone': v1715,
            'otp': v1716,
            'uid': v1723,
            'newCookie': (v1769.cookies || []).map(v1773 => v1773.split(';')[0x0]).join(';\x20'),
            'error': null
          };
        }
      } catch (v1774) {
        debugLog(v1715, "m-confirm-err", v1774.message);
      }
    }
    let v1730 = '';
    const v1731 = v1728.match(/"DTSGInitData"[^}]+"token":"([^"]+)"/) || v1728.match(/"DTSGInitialData",\[\],\{"token":"([^"]+)"\}/) || v1728.match(/"dtsg":\{"token":"([^"]+)"/) || v1728.match(/"token":"([^"]+)"[^{}]*?"async_get_token"/) || v1728.match(/name="fb_dtsg" value="([^"]+)"/);
    if (v1731) v1730 = v1731[0x1];
    if (!v1730 && v1720) v1730 = v1720;
    let v1732 = '';
    const v1733 = v1728.match(/"LSD"[^}]+"token":"([^"]+)"/) || v1728.match(/\["LSD",\[\],\{"token":"([^"]+)"\}\]/) || v1728.match(/"lsd":"([^"]+)"/) || v1728.match(/name="lsd" value="([^"]+)"/);
    if (v1733) v1732 = v1733[0x1];
    if (!v1732 && v1721) v1732 = v1721;
    if (!v1732) v1732 = "AdR" + crypto.randomBytes(0x10).toString("base64").replace(/[^a-zA-Z0-9]/g, '').substring(0x0, 0x14);
    let v1734 = "1045301906";
    const v1735 = v1728.match(/"__spin_r":(\d+)/) || v1728.match(/"server_revision":(\d+)/);
    if (v1735) v1734 = v1735[0x1];
    const v1736 = v1728.match(/"__hs":"([^"]+)"/),
      v1737 = v1728.match(/"__s":"([^"]+)"/) || v1728.match(/__s=([a-z0-9:]+)/),
      v1738 = v1728.match(/"hsi":"([^"]+)"/),
      v1739 = v1728.match(/"__dyn":"([^"]+)"/),
      v1740 = v1728.match(/"__csr":"([^"]+)"/),
      v1741 = v1728.match(/"__hsdp":"([^"]+)"/),
      v1742 = v1728.match(/"__hblp":"([^"]+)"/),
      v1743 = v1728.match(/"__sjsp":"([^"]+)"/),
      v1744 = v1728.match(/"__spin_b":"([^"]+)"/),
      v1745 = v1728.match(/"__spin_t":(\d+)/),
      v1746 = JSON.stringify({
        'input': {
          'actor_id': v1723,
          'client_mutation_id': uuid(),
          'conf_code': {
            'sensitive_string_value': String(v1716).trim()
          },
          'ig_reg_data': null,
          'machine_id': null
        }
      }),
      v1747 = new URLSearchParams({
        'av': v1723,
        '__user': v1723,
        '__a': '1',
        '__req': '3',
        '__hs': v1736 ? v1736[0x1] : "20681.HYP:comet_plat_default_pkg.2.1...0",
        'dpr': '1',
        '__ccg': "EXCELLENT",
        '__rev': v1734,
        '__s': v1737 ? v1737[0x1] : '',
        '__hsi': v1738 ? v1738[0x1] : '',
        '__dyn': v1739 ? v1739[0x1] : '',
        '__csr': v1740 ? v1740[0x1] : '',
        '__hsdp': v1741 ? v1741[0x1] : '',
        '__hblp': v1742 ? v1742[0x1] : '',
        '__sjsp': v1743 ? v1743[0x1] : '',
        '__comet_req': '102',
        'fb_dtsg': v1730,
        'jazoest': String(0x61a8 + Math.floor(Math.random() * 0x3e8)),
        'lsd': v1732,
        '__spin_r': v1734,
        '__spin_b': v1744 ? v1744[0x1] : 'trunk',
        '__spin_t': v1745 ? v1745[0x1] : Math.floor(Date.now() / 0x3e8).toString(),
        'qpl_active_flow_ids': "250360002,516759801",
        'fb_api_caller_class': "RelayModern",
        'fb_api_req_friendly_name': 'useCAAFBConfirmationFormSubmitMutation',
        'server_timestamps': 'true',
        'variables': v1746,
        'doc_id': '24050931851170558',
        'fb_api_analytics_tags': "[\"qpl_active_flow_ids=250360002,516759801\"]"
      }).toString();
    const v1748 = (v1729?.["cookies"] || []).map(v1775 => v1775.split(';')[0x0]).filter(Boolean),
      v1749 = fn33(v1717 || '');
    for (const v1776 of v1748) {
      const v1777 = v1776.indexOf('=');
      if (v1777 > 0x0) v1749[v1776.slice(0x0, v1777).trim()] = v1776.slice(v1777 + 0x1).trim();
    }
    const v1750 = fn34(v1749);
    let v1751;
    try {
      const v1778 = {};
      v1778["User-Agent"] = v1725.userAgent, v1778["Content-Type"] = 'application/x-www-form-urlencoded', v1778.Accept = '*/*', v1778['Accept-Language'] = "en-US,en;q=0.9", v1778.Cookie = v1750, v1778.Origin = "https://www.facebook.com", v1778.Referer = "https://www.facebook.com/confirmemail.php?next=https%3A%2F%2Fwww.facebook.com%2F", v1778["x-fb-lsd"] = v1732, v1778["x-asbd-id"] = "359341", v1778["x-fb-friendly-name"] = "useCAAFBConfirmationFormSubmitMutation", v1778["Sec-Fetch-Dest"] = "empty", v1778['Sec-Fetch-Mode'] = "cors", v1778["Sec-Fetch-Site"] = "same-origin", v1751 = await sendRequest("https://www.facebook.com/api/graphql/", "POST", v1778, v1747, v1718, 0x61a8);
    } catch (v1779) {
      debugLog(v1715, "confirm-post-retry", "Primary failed: " + v1779.message + ". Retrying directly...");
      const v1780 = {};
      v1780["User-Agent"] = v1725.userAgent, v1780['Content-Type'] = "application/x-www-form-urlencoded", v1780.Accept = "*/*", v1780["Accept-Language"] = "en-US,en;q=0.9", v1780.Cookie = v1750, v1780.Origin = "https://www.facebook.com", v1780.Referer = "https://www.facebook.com/confirmemail.php?next=https%3A%2F%2Fwww.facebook.com%2F", v1780['x-fb-lsd'] = v1732, v1780["x-asbd-id"] = "359341", v1780["x-fb-friendly-name"] = "useCAAFBConfirmationFormSubmitMutation", v1780["Sec-Fetch-Dest"] = "empty", v1780["Sec-Fetch-Mode"] = "cors", v1780["Sec-Fetch-Site"] = "same-origin", v1751 = await sendRequest('https://www.facebook.com/api/graphql/', "POST", v1780, v1747, null, 0x61a8);
    }
    const v1752 = v1751.data || '';
    let v1753 = false,
      v1754 = "Unknown error",
      v1755 = v1719 || v1723 || '',
      v1756 = v1752.trim();
    v1756.startsWith("for (;;);") && (v1756 = v1756.replace(/^for\s*\(\s*;\s*;\s*\)\s*;\s*/, '').trim());
    if (v1756.includes('\x0a')) {
      const v1781 = v1756.split(/\r?\n/).find(v1782 => v1782.trim().startsWith('{'));
      if (v1781) v1756 = v1781.trim();
    }
    try {
      const v1783 = JSON.parse(v1756),
        v1784 = v1783?.['data']?.['caa_fb_confirmation_form_submit'] || v1783?.['data']?.["useCAAFBConfirmationFormSubmit"] || v1783?.["data"]?.["xfb_caa_registration_confirmation_submit"];
      if (v1783.errors && v1783.errors.length > 0x0) v1753 = false, v1754 = v1783.errors[0x0]?.["message"] || v1783.errors[0x0]?.["summary"] || v1783.errors[0x0]?.['description'] || "Confirmation rejected by Facebook";else {
        if (v1783?.["data"]?.["xfb_caa_registration_confirmation_submit"] !== undefined && v1783?.['data']?.["xfb_caa_registration_confirmation_submit"] !== null) {
          v1753 = true;
          const v1785 = v1783.data.xfb_caa_registration_confirmation_submit;
          if (v1785?.["created_user_id"]) v1755 = v1785.created_user_id;
          if (v1785?.['user_id']) v1755 = v1785.user_id;
        } else {
          if (v1784 && (v1784.status === "SUCCESS" || v1784.created_user_id || v1784.user_id)) {
            v1753 = true;
            if (v1784.created_user_id) v1755 = v1784.created_user_id;
            if (v1784.user_id) v1755 = v1784.user_id;
          } else {
            if (v1756.includes("\"status\":\"SUCCESS\"") && !v1756.includes("\"errors\":")) v1753 = true;else {
              if (v1756.includes('invalid_code') || v1756.includes("wrong code")) v1754 = "Invalid OTP code";else {
                if (v1756.includes("expired")) v1754 = 'OTP\x20expired';else {
                  if (v1784 === null && v1783.errors) v1753 = false, v1754 = "Confirmation returned null (Invalid or rejected OTP)";else v1751.status === 0xc8 && v1784 && typeof v1784 === 'object' ? v1753 = true : v1754 = v1784?.["error_message"] || "Confirmation rejected by Facebook";
                }
              }
            }
          }
        }
      }
    } catch (v1786) {
      const v1787 = [...(v1751.cookies || []), ...(v1729?.['cookies'] || [])],
        v1788 = v1787.map(v1789 => v1789.split(';')[0x0]).join(';\x20').match(/c_user=([0-9]+)/);
      if (v1788) v1753 = true, v1755 = v1788[0x1], v1754 = null;else v1752.includes("c_user=") || v1752.includes("checkpoint") || v1752.includes("confirmemail.php") ? (v1753 = true, v1754 = null) : v1754 = "Response: " + (v1752.substring(0x0, 0x64) || "empty response");
    }
    debugLog(v1715, "confirm-result", {
      'status': v1751.status,
      'isSuccess': v1753,
      'errorMsg': v1754,
      'confirmedUid': v1755,
      'raw': v1752.substring(0x0, 0x190)
    });
    function fn32(v1790) {
      const v1791 = {};
      for (const v1792 of v1790 || []) {
        const v1793 = v1792.split(';')[0x0].trim(),
          v1794 = v1793.indexOf('=');
        if (v1794 > 0x0) v1791[v1793.slice(0x0, v1794)] = v1793.slice(v1794 + 0x1);
      }
      return v1791;
    }
    function fn33(v1795) {
      const v1796 = {};
      for (const v1797 of v1795.split(';').map(v1798 => v1798.trim()).filter(Boolean)) {
        const v1799 = v1797.indexOf('=');
        if (v1799 > 0x0) v1796[v1797.slice(0x0, v1799)] = v1797.slice(v1799 + 0x1);
      }
      return v1796;
    }
    function fn34(v1800) {
      return Object.entries(v1800).map(([v1801, v1802]) => v1801 + '=' + v1802).join(';\x20');
    }
    let v1757 = v1717;
    if (v1753) try {
      let v1803 = fn33(v1717);
      Object.assign(v1803, fn32(v1729?.['cookies'] || [])), Object.assign(v1803, fn32(v1751?.['cookies'] || []));
      const v1804 = fn34(v1803),
        v1805 = {};
      v1805["User-Agent"] = v1725.userAgent, v1805.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", v1805["Accept-Language"] = "en-US,en;q=0.9", v1805['Accept-Encoding'] = "gzip, deflate, br", v1805.Cookie = v1804, v1805['Sec-Fetch-Mode'] = "navigate", v1805['Sec-Fetch-Site'] = 'none', v1805["Sec-Fetch-Dest"] = "document";
      const v1806 = await sendRequest('https://www.facebook.com/', "GET", v1805, null, v1718, 0x3a98, true);
      Object.assign(v1803, fn32(v1806?.["cookies"] || [])), v1757 = fn34(v1803);
      if (!v1755 || v1755 === '0') {
        const v1807 = v1757.match(/c_user=(\d+)/);
        if (v1807) v1755 = v1807[0x1];
      }
    } catch (v1808) {}
    const v1758 = {};
    return v1758.success = v1753, v1758.phone = v1715, v1758.otp = v1716, v1758.uid = v1755, v1758.newCookie = v1757, v1758.error = v1753 ? null : v1754, v1758;
  }
  async function runConfirmMode({
    otpFile: v1809,
    matched: v1810,
    threads: v1811,
    proxiesFile: v1812
  }) {
    const v1813 = path.dirname(v1809),
      v1814 = path.join(v1813, "confirmed.txt");
    const v1815 = path.join(v1813, "confirm_failed.txt");
    fs.writeFileSync(v1814, ''), fs.writeFileSync(v1815, '');
    const v1816 = v1810;
    v1816.length === 0x0 && (console.error(R("\n  ✗ No accounts to confirm.\n")), process.exit(0x1));
    let v1817 = [];
    if (v1812 && v1812.toLowerCase() !== 'none' && fs.existsSync(v1812)) {
      v1817 = fs.readFileSync(v1812, "utf8").split('\x0a').map(v1824 => v1824.trim()).filter(v1825 => v1825.length > 0x0).map(parseProxy).filter(Boolean);
      if (v1817.length > 0x0) {
        const v1826 = v1817.length;
        v1817 = await filterLiveProxies(v1817, 0x14), v1817.length === 0x0 && (console.error(R("\n  ✗ All " + v1826 + " proxies are DEAD.\n")), process.exit(0x1));
      }
    }
    const fn35 = () => v1817.length === 0x0 ? null : rotateSessionId(v1817[Math.floor(Math.random() * v1817.length)]),
      v1818 = new Dashboard(v1816.length);
    let v1819 = [...v1816],
      v1820 = 0x0,
      v1821 = 0x0;
    async function fn36(v1827) {
      while (true) {
        const v1828 = v1819.shift();
        if (!v1828) break;
        const v1829 = fn35();
        v1818.setStatus("Worker " + v1827 + ": Confirming " + v1828.phone + "...");
        try {
          let v1830 = v1828.cookie;
          if (v1828.loginMode) {
            v1818.setStatus("Worker " + v1827 + ": Logging in " + v1828.phone + '...');
            try {
              const v1833 = {};
              v1833.phone = v1828.phone, v1833.password = v1828.password, v1833.otp = v1828.otp, v1833.proxy = v1829, v1830 = await loginWithPassword(v1833);
            } catch (v1834) {
              v1821++, v1818.failed++, v1818.processed++, fs.appendFileSync(v1815, v1828.phone + "|Login failed: " + v1834.message + '\x0a'), v1818.addLog("Login failed " + v1828.phone + ':\x20' + v1834.message, "error", "[LOGIN FAIL]");
              continue;
            }
          }
          if (v1828.loginMode) {
            const v1835 = v1830.match(/c_user=([0-9]+)/),
              v1836 = v1835 ? v1835[0x1] : '';
            v1820++, v1818.successful++, v1818.processed++, fs.appendFileSync(v1814, v1836 + '|' + v1828.password + '|' + v1830 + '\x0a'), v1818.addLog("Confirmed " + v1828.phone + " | UID: " + v1836, "success", "[✅ LOGIN+OTP]");
            continue;
          }
          const v1831 = {};
          v1831.phone = v1828.phone, v1831.otp = v1828.otp, v1831.cookie = v1830, v1831.proxy = v1829;
          const v1832 = await confirmAccount(v1831);
          if (v1832.success && v1832.uid && v1832.uid !== '0') {
            let v1837 = v1832.newCookie || v1830;
            const v1838 = {};
            v1838.cookie = v1837, v1838.proxy = v1829, v1838.uid = v1832.uid, v1838.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
            const v1839 = await checkAccountStatus(v1838);
            if (!v1839.isLive) {
              v1821++, v1818.failed++, v1818.processed++;
              const v1840 = path.join(path.resolve(__dirname), "checkpoint.txt");
              fs.appendFileSync(v1840, v1832.uid + '|' + v1828.password + '|' + v1837 + '|' + v1839.status + '|' + v1828.phone + '\x0a'), v1818.addLog("Checkpoint " + v1828.phone + " | UID: " + v1832.uid + '\x20(' + v1839.reason + ')', "error", "[CHECKPOINT]");
            } else v1820++, v1818.successful++, v1818.processed++, fs.appendFileSync(v1814, v1832.uid + '|' + v1828.password + '|' + v1837 + '\x0a'), v1818.addLog('Confirmed\x20LIVE\x20' + v1828.phone + " | UID: " + v1832.uid, 'success', "[LIVE ✅]");
          } else v1821++, v1818.failed++, v1818.processed++, fs.appendFileSync(v1815, v1828.phone + '|' + v1832.error + '\x0a'), v1818.addLog("Failed " + v1828.phone + ':\x20' + v1832.error, "error", "[FAIL]");
        } catch (v1841) {
          v1821++, v1818.failed++, v1818.processed++, fs.appendFileSync(v1815, v1828.phone + '|' + v1841.message + '\x0a'), v1818.addLog("Error " + v1828.phone + ':\x20' + v1841.message, 'error', "[ERR]");
        }
      }
    }
    const v1822 = setInterval(() => v1818.render(), 0x1f4),
      v1823 = Array.from({
        'length': Math.min(v1811, v1816.length)
      }, (v1842, v1843) => fn36(v1843));
    await Promise.all(v1823), clearInterval(v1822), v1818.render(), v1818.stop(), console.log(B("\n  ════════════════════════════════════════════╠")), console.log(B("  ║") + W("  FB CONFIRM — RUN COMPLETE                    ") + B('║')), console.log(B("  ║") + C('\x20\x20Confirmed\x20\x20\x20') + G(('' + v1820).padEnd(0x24)) + B('║')), console.log(B("  ║") + R("  Failed      ") + G(('' + v1821).padEnd(0x24)) + B('║')), console.log(B("  ╚════════════════════════════════════════════╝\n")), console.log(G("  ✔ confirmed.txt saved to: " + v1814)), process.exit(0x0);
  }
  async function start() {
    process.on("uncaughtException", v1891 => {
      const v1892 = v1891.message || '';
      if (v1892.includes("ECONNRESET") || v1892.includes("ECONNREFUSED") || v1892.includes("ETIMEDOUT") || v1892.includes("socket") || v1892.includes('TLS') || v1892.includes('network') || v1892.includes("ENOTFOUND") || v1892.includes('HPE_') || v1892.includes('read\x20ECONNRESET')) return;
      process.stderr.write("\r[K" + R("[WARN] Uncaught: " + v1892) + '\x0a');
    }), process.on("unhandledRejection", v1893 => {
      const v1894 = v1893 && v1893.message ? v1893.message : String(v1893);
      if (v1894.includes('ECONNRESET') || v1894.includes("ECONNREFUSED") || v1894.includes("ETIMEDOUT") || v1894.includes("socket") || v1894.includes("TLS") || v1894.includes("ENOTFOUND")) return;
      process.stderr.write('\x0d\x1b[K' + R("[WARN] Unhandled rejection: " + v1894) + '\x0a');
    });
    const v1844 = generateHWID();
    !v1844 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(0x1));
    const v1845 = generateHWID();
    v1845 !== v1844 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(0x1));
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Tool      : ") + B("Facebook Create Web          ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v1844.padEnd(0x1d)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v1846 = false,
      v1847 = "Licensed";
    const v1848 = Date.now();
    try {
      const v1895 = require("http"),
        v1896 = await new Promise((v1897, v1898) => {
          const v1899 = {};
          v1899.hwid = v1844, v1899.app_id = 'fb', v1899.version = "1.0.1";
          v1899.timestamp = v1848;
          const v1900 = JSON.stringify(v1899),
            v1901 = {
              'hostname': "188.137.176.163",
              'port': 0xec1,
              'path': "/api/verify",
              'method': "POST",
              'headers': {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(v1900)
              },
              'timeout': 0x2710
            },
            v1902 = v1895.request(v1901, v1903 => {
              let v1904 = '';
              v1903.on("data", v1905 => v1904 += v1905), v1903.on("end", () => {
                try {
                  v1897(JSON.parse(v1904));
                } catch (v1906) {
                  v1898(v1906);
                }
              });
            });
          v1902.on('error', v1898);
          v1902.on('timeout', function () {
            this.destroy();
            v1898(new Error('Timeout'));
          }), v1902.write(v1900), v1902.end();
        });
      if (v1896) {
        v1896.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(0x1));
        if (v1896.status === "banned" || v1896.status === "expired" || !v1896.sig) {
          await new Promise(v1910 => setTimeout(v1910, 0x7d0));
          let v1909 = String(v1896.reason || "NOT REGISTERED");
          if (!v1896.reason && !v1896.sig) v1909 = "NOT REGISTERED / REMOVED";
          console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R('\x20\x20║\x20\x20\x20\x20✗\x20UNAUTHORIZED\x20HARDWARE\x20—\x20FB\x20TOOL\x20\x20\x20\x20\x20\x20\x20\x20║')), console.error(R('\x20\x20╠══════════════════════════════════════════════╣')), console.error(R("  ║  HWID   : ") + Y(v1844.padEnd(0x21)) + R('║')), console.error(R("  ║  Status : " + v1909.padEnd(0x1a) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(0x1);
        }
        const v1907 = v1844 + "|fb|1.0.1|" + v1848;
        !verifyServerSignature(v1907, v1896.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(0x1));
        v1846 = true;
        if (v1896.user) v1847 = v1896.user;
        let v1908 = v1896.token;
        !v1908 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(0x1)), setInterval(() => {
          !v1908 && (console.error(R('\x0a\x20\x20✗\x20Session\x20Token\x20lost.\x20Aborting...\x0a')), process.exit(0x1));
          const v1911 = {};
          v1911.hwid = v1844, v1911.app_id = 'fb', v1911.token = v1908;
          const v1912 = JSON.stringify(v1911);
          const v1913 = {
              'hostname': "188.137.176.163",
              'port': 0xec1,
              'path': "/api/ping",
              'method': "POST",
              'headers': {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(v1912)
              },
              'timeout': 0x1388
            },
            v1914 = v1895.request(v1913, v1915 => {
              let v1916 = '';
              v1915.on("data", v1917 => v1916 += v1917);
              v1915.on("end", () => {
                try {
                  const v1918 = JSON.parse(v1916);
                  v1918.status === 'ok' && v1918.token ? v1908 = v1918.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(0x1));
                } catch (v1919) {
                  console.error(R('\x0a\x20\x20✗\x20Network\x20error\x20during\x20session\x20ping.\x20Exiting...\x0a')), process.exit(0x1);
                }
              });
            });
          v1914.on('error', () => {
            console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
            process.exit(0x1);
          }), v1914.on("timeout", function () {
            this.destroy();
            console.error(R('\x0a\x20\x20✗\x20License\x20Server\x20timeout.\x20Exiting...\x0a')), process.exit(0x1);
          }), v1914.write(v1912), v1914.end();
        }, 0xafc8);
      }
    } catch (v1920) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(0x1);
    }
    !v1846 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(0x1));
    printHeader(), console.log(B("  ✓ License: " + v1847) + G(" | HWID: " + v1844 + '\x0a'));
    const v1849 = {};
    v1849.name = "🆕 New Create    — Register new Facebook accounts", v1849.value = "create";
    const v1850 = {};
    v1850.name = '✅\x20Confirm\x20\x20\x20\x20\x20\x20\x20\x20—\x20Confirm\x20OTP\x20for\x20created\x20accounts', v1850.value = "confirm";
    const v1851 = await selectOption("Select Mode", [v1849, v1850]);
    if (v1851 === "confirm") {
      const v1921 = await confirmWizard();
      await runConfirmMode(v1921);
      return;
    }
    const v1852 = process.argv.slice(0x2).filter(v1922 => !v1922.startsWith('--'));
    let v1853 = v1852,
      v1854 = null;
    let v1855 = null,
      v1856 = null,
      v1857 = null,
      v1858 = null,
      v1859 = null,
      v1860 = null,
      v1861 = null,
      v1862 = null,
      v1863 = null;
    if (v1853.length === 0x0) {
      const v1923 = await interactiveWizard();
      v1854 = v1923.nexaConfig || null, v1855 = v1923.twoOoConfig || null, v1856 = v1923.smsBowerConfig || null, v1857 = v1923.zenexConfig || null, v1858 = v1923.outlookConfig || null, v1859 = v1923.mailsinkConfig || null, v1860 = v1923.temptfConfig || null, v1861 = v1923.mailtmConfig || null, v1862 = v1923.mailcxConfig || null, v1863 = v1923.randomTempmailConfig || null, v1853 = [v1923.targets, v1923.threads, v1923.proxies, v1923.browser, v1923.resend, v1923.customPassword, v1923.apiMode];
    }
    v1853 = v1853.map(v1924 => typeof v1924 === "string" ? v1924.replace(/^["']|["']$/g, '').trim() : v1924);
    const v1864 = generateHWID();
    v1864 !== v1844 && (console.error(R("\n  ✗ CRITICAL SECURITY ALERT: Runtime memory injection detected.")), console.error(R("  ✗ HWID mismatch during execution sequence. Aborting...\n")), process.exit(0x1));
    let v1865 = path.resolve(v1853[0x0] || "numbers.txt"),
      v1866 = parseInt(v1853[0x1]) || 0x14,
      v1867 = v1853[0x2] !== undefined ? v1853[0x2] : '';
    if (typeof v1867 === "string" && v1867.toLowerCase() === 'none') v1867 = '';
    let v1868 = v1853[0x3] || 'random',
      v1869 = Math.max(0x1, parseInt(v1853[0x4]) || 0x1),
      v1870 = v1853[0x5] || null,
      v1871 = v1853[0x6] || "random";
    const v1872 = path.dirname(v1865);
    SUCCESSFUL_FILE = path.join(v1872, "successful.txt"), FAILED_FILE = path.join(v1872, "failed.txt"), DEBUG_FILE = path.join(v1872, "debug.txt"), console.log(C('✓\x20Resend\x20per\x20target:\x20' + v1869 + 'x'));
    let v1873 = [];
    !v1854 && !v1855 && !v1856 && !v1857 && !v1858 && !v1859 && !v1860 && !v1861 && !v1862 && !v1863 && (!fs.existsSync(v1865) && (console.error(R("✗ Error: Targets file not found: " + v1865)), process.exit(0x1)), v1873 = fs.readFileSync(v1865, "utf8").split(/\r?\n/).map(v1925 => v1925.trim()).filter(v1926 => v1926.length > 0x5));
    let v1874 = [];
    v1867 && fs.existsSync(v1867) && (v1874 = fs.readFileSync(v1867, 'utf8').split('\x0a').map(v1927 => v1927.trim()).filter(v1928 => v1928.length > 0x0).map(parseProxy).filter(Boolean));
    const v1875 = v1871 === "desktop" ? "www.facebook.com (Desktop GraphQL)" : v1871 === "mobile" ? "m.facebook.com (Mobile Wbloks)" : "Random (www + m.facebook.com)";
    if (v1858) console.log(Y("✓ Mode: 📧 Outlook OAuth2 (" + v1858.accounts.length + " emails × " + v1858.accountsPerEmail + " = " + v1858.totalCount + " accounts)"));else {
      if (v1863) console.log(Y("✓ Mode: 🌀 Random / Mixed Tempmail (" + v1863.totalCount + " accounts, Region: " + (v1863.nameRegion || 'RANDOM') + ')'));else {
        if (v1862) console.log(Y("✓ Mode: ⚡ Mail.cx Auto Tempmail (" + v1862.totalCount + " accounts)"));else {
          if (v1859) console.log(Y("✓ Mode: 📬 Mailsink Auto Tempmail (" + v1859.totalCount + '\x20accounts)'));else {
            if (v1860) console.log(Y("✓ Mode: 📩 Temp.tf Auto Tempmail (" + v1860.totalCount + " accounts, " + v1860.providers + ')'));else {
              if (v1861) console.log(Y('✓\x20Mode:\x20📫\x20Mail.tm\x20Auto\x20Tempmail\x20(' + v1861.totalCount + '\x20accounts)'));else {
                if (v1854 || v1855) {
                  const v1929 = v1854 || v1855,
                    v1930 = v1854 ? 'NexaOTP' : v1855.provider === "voltx" ? "Voltx ⚡" : 'Stex\x20🔥';
                  console.log(Y("✓ Mode: " + v1930 + " Streaming (" + v1929.totalCount + " numbers)"));
                } else {
                  if (v1856) console.log(Y("✓ Mode: 📱 SMS Bower (" + v1856.totalCount + " numbers)"));else v1857 ? console.log(Y('✓\x20Mode:\x20⚡\x20Zenex\x20(' + v1857.totalCount + " numbers)")) : (console.log(Y('✓\x20Loaded\x20' + v1873.length + " targets")), v1873.length === 0x0 && (console.error(R("\n  ✗ No targets found in: " + v1865 + '\x0a')), process.exit(0x1)));
                }
              }
            }
          }
        }
      }
    }
    if (v1874.length === 0x0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v1874.length + " (checking live...)"));
    console.log(C("✓ Threads:  " + v1866)), console.log(C("✓ API:      " + v1875)), console.log(C('✓\x20Browser:\x20\x20' + v1868)), console.log(C("✓ Password: " + (v1870 ? v1870 : "Auto-generate") + '\x0a'));
    const v1876 = !!(v1867 && v1867.trim());
    if (v1874.length > 0x0) {
      const v1931 = v1874.length;
      v1874 = await filterLiveProxies(v1874, 0x14), v1874.length === 0x0 && (console.error(R('\x0a\x20\x20✗\x20All\x20' + v1931 + " proxies are DEAD — no live proxies found.")), console.error(R("    Check your proxy file: " + v1867)), console.error(R("    Replace with working proxies and try again.\n")), process.exit(0x1));
    } else v1876 && (console.error(R("\n  ✗ Proxy file given but contains no valid proxies: " + v1867)), console.error(R("    Format: host:port  or  host:port:user:pass  (one per line)\n")), process.exit(0x1));
    fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, ''), fs.appendFileSync(DEBUG_FILE, "\n\n══════════ NEW RUN: " + new Date().toISOString() + " ══════════\n");
    const v1877 = v1854 || v1855 || v1856 || v1857 || v1858 || v1859 || v1860 || v1861 || v1862 || v1863 ? (v1854 || v1855 || v1856 || v1857 || v1858 || v1859 || v1860 || v1861 || v1862 || v1863).totalCount : v1873.length,
      v1878 = new Dashboard(v1877);
    let v1879 = [],
      v1880 = [],
      v1881 = 0x0,
      v1882 = false;
    const v1883 = new Map();
    let v1884 = [];
    if (v1858) for (const v1932 of v1858.accounts) {
      for (let v1933 = 0x1; v1933 <= v1858.accountsPerEmail; v1933++) {
        const v1934 = {
          ...v1932
        };
        v1934.instance = v1933, v1934.totalInstances = v1858.accountsPerEmail, v1934.target = v1932.email, v1934.isOutlook = true, v1884.push(v1934);
      }
    }
    if (v1862) {
      const v1935 = v1862;
      console.log(Y("\n  [Mail.cx] Streaming " + v1935.totalCount + " temporary accounts (Region: " + (v1935.nameRegion || 'US') + ',\x2010/sec\x20rate\x20limit)...')), (async () => {
        let v1936 = 0x0;
        try {
          const v1937 = await mailcxGetDomains(v1935.apiKey);
          console.log(B("  [Mail.cx] Active domains: " + v1937.join(',\x20')));
          for (let v1938 = 0x0; v1938 < v1935.totalCount; v1938++) {
            const v1939 = v1937[Math.floor(Math.random() * v1937.length)] || "9k3r.com",
              v1940 = mailcxCreateAccount(v1939, v1935.nameRegion || 'US');
            v1936++;
            const v1941 = {};
            v1941.email = v1940.email, v1941.domain = v1940.domain, v1941.apiKey = v1935.apiKey, v1941.isMailcx = true;
            const v1942 = v1941;
            if (v1880.length > 0x0) v1880.shift()(v1942);else v1879.push(v1942);
            v1938 % 0xa === 0x0 && v1938 > 0x0 ? await new Promise(v1943 => setTimeout(v1943, 0x3e8)) : await new Promise(v1944 => setTimeout(v1944, 0x64));
          }
        } catch (v1945) {
          console.error(R("\n  [Mail.cx] Streaming error: " + v1945.message + '\x0a'));
        } finally {
          v1882 = true;
          while (v1880.length > 0x0) v1880.shift()(null);
        }
      })();
    } else {
      if (v1859) {
        const v1946 = v1859;
        console.log(Y("\n  [Mailsink] Streaming " + v1946.totalCount + " temporary inboxes...")), (async () => {
          let v1947 = 0x0,
            v1948 = 0x0,
            v1949 = '';
          try {
            for (let v1950 = 0x0; v1950 < v1946.totalCount; v1950++) {
              try {
                const v1951 = await mailsinkCreateInbox(v1946.apiKey);
                v1947++, v1948 = 0x0;
                const v1952 = {};
                v1952.email = v1951.address, v1952.inboxId = v1951.id, v1952.isMailsink = true, v1952.apiKey = v1946.apiKey;
                const v1953 = v1952;
                if (v1880.length > 0x0) v1880.shift()(v1953);else v1879.push(v1953);
              } catch (v1954) {
                v1949 = v1954.message, v1948++;
                if (v1948 >= 0x5 && v1947 === 0x0) {
                  console.error(R("\n  [Mailsink] ✗ Aborting: " + v1949 + '\x0a'));
                  break;
                }
                await new Promise(v1955 => setTimeout(v1955, 0x7d0));
              }
            }
          } finally {
            v1882 = true;
            while (v1880.length > 0x0) v1880.shift()(null);
          }
        })();
      } else {
        if (v1860) {
          const v1956 = v1860;
          console.log(Y("\n  [Temp.tf] Streaming " + v1956.totalCount + " temporary accounts (providers: " + v1956.providers + ")...")), (async () => {
            let v1957 = 0x0,
              v1958 = 0x0,
              v1959 = '';
            try {
              for (let v1960 = 0x0; v1960 < v1956.totalCount; v1960++) {
                try {
                  const v1961 = await temptfGetAccount(v1956.providers);
                  v1957++, v1958 = 0x0;
                  const v1962 = {};
                  v1962.email = v1961, v1962.isTemptf = true;
                  const v1963 = v1962;
                  if (v1880.length > 0x0) v1880.shift()(v1963);else v1879.push(v1963);
                } catch (v1964) {
                  v1959 = v1964.message, v1958++;
                  if (v1958 >= 0x5 && v1957 === 0x0) {
                    console.error(R('\x0a\x20\x20[Temp.tf]\x20✗\x20Aborting:\x20' + v1959 + '\x0a'));
                    break;
                  }
                  await new Promise(v1965 => setTimeout(v1965, 0x7d0));
                }
              }
            } finally {
              v1882 = true;
              while (v1880.length > 0x0) v1880.shift()(null);
            }
          })();
        } else {
          if (v1861) {
            const v1966 = v1861;
            console.log(Y("\n  [Mail.tm] Streaming " + v1966.totalCount + '\x20temporary\x20accounts...')), (async () => {
              let v1967 = 0x0,
                v1968 = 0x0,
                v1969 = '';
              try {
                const v1970 = v1966.domains && v1966.domains.length > 0x0 ? v1966.domains : await mailtmGetDomains();
                for (let v1971 = 0x0; v1971 < v1966.totalCount; v1971++) {
                  try {
                    const v1972 = v1970[Math.floor(Math.random() * v1970.length)],
                      v1973 = await mailtmCreateAccount(v1972);
                    v1967++, v1968 = 0x0;
                    const v1974 = {};
                    v1974.email = v1973.address, v1974.token = v1973.token, v1974.password = v1973.password, v1974.isMailtm = true;
                    const v1975 = v1974;
                    if (v1880.length > 0x0) v1880.shift()(v1975);else v1879.push(v1975);
                  } catch (v1976) {
                    v1969 = v1976.message, v1968++;
                    if (v1968 >= 0x5 && v1967 === 0x0) {
                      console.error(R("\n  [Mail.tm] ✗ Aborting: " + v1969 + '\x0a'));
                      break;
                    }
                    await new Promise(v1977 => setTimeout(v1977, 0x7d0));
                  }
                }
              } finally {
                v1882 = true;
                while (v1880.length > 0x0) v1880.shift()(null);
              }
            })();
          } else {
            if (v1863) {
              const v1978 = v1863;
              console.log(Y("\n  [Random Tempmail] Streaming " + v1978.totalCount + " mixed temporary accounts (Mail.cx / Temp.tf / Mail.tm / Mailsink, Region: " + (v1978.nameRegion || 'RANDOM') + ")...")), (async () => {
                let v1979 = 0x0,
                  v1980 = 0x0,
                  v1981 = [],
                  v1982 = [];
                try {
                  const v1983 = v1978.apiKey || (fs.existsSync(MAILCX_KEY_FILE) ? fs.readFileSync(MAILCX_KEY_FILE, "utf8").trim() : ''),
                    v1984 = v1978.mailsinkKey || (fs.existsSync(MAILSINK_KEY_FILE) ? fs.readFileSync(MAILSINK_KEY_FILE, "utf8").trim() : '');
                  try {
                    v1981 = await mailcxGetDomains(v1983);
                  } catch (v1986) {
                    v1981 = ['9k3r.com', "ddker.com"];
                  }
                  try {
                    v1982 = await mailtmGetDomains();
                  } catch (v1987) {
                    v1982 = [];
                  }
                  const v1985 = ["mailcx", "temptf"];
                  if (v1982.length > 0x0) v1985.push('mailtm');
                  if (v1984) v1985.push("mailsink");
                  for (let v1988 = 0x0; v1988 < v1978.totalCount; v1988++) {
                    try {
                      const v1989 = v1985[Math.floor(Math.random() * v1985.length)];
                      let v1990 = null;
                      if (v1989 === "mailcx") {
                        const v1991 = v1981[Math.floor(Math.random() * v1981.length)] || '9k3r.com',
                          v1992 = mailcxCreateAccount(v1991, v1978.nameRegion || 'RANDOM'),
                          v1993 = {};
                        v1993.email = v1992.email, v1993.domain = v1992.domain, v1993.apiKey = v1983, v1993.isMailcx = true, v1990 = v1993;
                      } else {
                        if (v1989 === 'temptf') {
                          const v1994 = await temptfGetAccount("gmail,outlook"),
                            v1995 = {};
                          v1995.email = v1994, v1995.isTemptf = true, v1990 = v1995;
                        } else {
                          if (v1989 === 'mailtm') {
                            const v1996 = v1982[Math.floor(Math.random() * v1982.length)],
                              v1997 = await mailtmCreateAccount(v1996),
                              v1998 = {};
                            v1998.email = v1997.address, v1998.token = v1997.token, v1998.password = v1997.password, v1998.isMailtm = true, v1990 = v1998;
                          } else {
                            if (v1989 === "mailsink") {
                              const v1999 = await mailsinkCreateInbox(v1984),
                                v2000 = {};
                              v2000.email = v1999.address, v2000.inboxId = v1999.id, v2000.isMailsink = true, v2000.apiKey = v1984, v1990 = v2000;
                            }
                          }
                        }
                      }
                      if (v1990) {
                        v1979++, v1980 = 0x0;
                        if (v1880.length > 0x0) v1880.shift()(v1990);else v1879.push(v1990);
                      }
                      await new Promise(v2001 => setTimeout(v2001, 0x96));
                    } catch (v2002) {
                      v1980++;
                      if (v1980 >= 0xa && v1979 === 0x0) {
                        console.error(R("\n  [Random Tempmail] ✗ Aborting: " + v2002.message + '\x0a'));
                        break;
                      }
                      await new Promise(v2003 => setTimeout(v2003, 0x3e8));
                    }
                  }
                } finally {
                  v1882 = true;
                  while (v1880.length > 0x0) v1880.shift()(null);
                }
              })();
            } else {
              if (v1854 || v1855) {
                const v2004 = v1854 || v1855,
                  v2005 = v1854 ? "NexaOTP" : v1855.provider === 'voltx' ? "Voltx ⚡" : "Stex 🔥";
                console.log(Y("\n  [" + v2005 + "] Streaming " + v2004.totalCount + " numbers (" + v2004.ranges.length + " range(s))...")), (async () => {
                  let v2006 = 0x0,
                    v2007 = '';
                  try {
                    for (let v2008 = 0x0; v2008 < v2004.totalCount; v2008++) {
                      try {
                        const v2009 = v2004.ranges[Math.floor(Math.random() * v2004.ranges.length)];
                        let v2010;
                        v1854 ? v2010 = await nexaLimiter.enqueue(() => nexaFetchNumber(v1854.apiKey, v2009, v1854.serverEndpoint)) : v2010 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v1855.apiKey, v2009, v1855.getPath)), v2010 && (v1881++, v2006 = 0x0, v1880.length > 0x0 ? v1880.shift()(v2010) : v1879.push(v2010));
                      } catch (v2011) {
                        v2007 = v2011.message;
                        if (v2011.message.includes("Insufficient balance")) {
                          console.error(R("\n  [" + v2005 + ']\x20✗\x20Insufficient\x20balance\x20—\x20aborting.\x0a'));
                          break;
                        }
                        if (v2011.message.includes('No\x20numbers\x20available')) continue;
                        v2006++;
                        if (v2006 >= 0x5 && v1881 === 0x0) {
                          console.error(R("\n  [" + v2005 + "] ✗ Aborting — 5 consecutive failures. Last error: " + v2007 + '\x0a'));
                          break;
                        }
                      }
                    }
                  } finally {
                    if (v1881 === 0x0) console.error(R('\x0a\x20\x20[' + v2005 + "] ✗ No numbers fetched. Last error: " + (v2007 || "Unknown") + '\x0a'));
                    v1882 = true;
                    while (v1880.length > 0x0) v1880.shift()(null);
                  }
                })();
              } else {
                if (v1856) {
                  const v2012 = v1856;
                  console.log(Y("\n  [SMS Bower] Streaming " + v2012.totalCount + " numbers (service: " + v2012.service + ", country: " + v2012.country + ")...")), (async () => {
                    let v2013 = 0x0,
                      v2014 = 0x0,
                      v2015 = '';
                    try {
                      for (let v2016 = 0x0; v2016 < v2012.totalCount; v2016++) {
                        try {
                          const {
                            activationId: v2017,
                            phoneNumber: v2018
                          } = await smsBowerFetchNumber(v2012.apiKey, v2012.service, v2012.country, v2012.maxPrice);
                          v1883.set(v2018, v2017), v2013++, v2014 = 0x0;
                          if (v1880.length > 0x0) v1880.shift()(v2018);else v1879.push(v2018);
                        } catch (v2019) {
                          v2015 = v2019.message, v2014++;
                          if (v2014 >= 0x5 && v2013 === 0x0) {
                            console.error(R("\n  [SMS Bower] ✗ Aborting: " + v2015 + '\x0a'));
                            break;
                          }
                          await new Promise(v2020 => setTimeout(v2020, 0x7d0));
                        }
                      }
                    } finally {
                      v1882 = true;
                      while (v1880.length > 0x0) v1880.shift()(null);
                    }
                  })();
                } else {
                  if (v1857) {
                    const v2021 = v1857;
                    console.log(Y("\n  [Zenex] Streaming " + v2021.totalCount + '\x20numbers\x20(' + v2021.ranges.length + '\x20range(s))...')), (async () => {
                      let v2022 = 0x0,
                        v2023 = 0x0,
                        v2024 = '';
                      try {
                        for (let v2025 = 0x0; v2025 < v2021.totalCount; v2025++) {
                          try {
                            const v2026 = v2021.ranges[Math.floor(Math.random() * v2021.ranges.length)],
                              v2027 = await zenexFetchNumber(v2021.apiKey, v2026);
                            v2022++, v2023 = 0x0;
                            if (v1880.length > 0x0) v1880.shift()(v2027);else v1879.push(v2027);
                          } catch (v2028) {
                            v2024 = v2028.message, v2023++;
                            if (v2023 >= 0x5 && v2022 === 0x0) {
                              console.error(R('\x0a\x20\x20[Zenex]\x20✗\x20Aborting:\x20' + v2024 + '\x0a'));
                              break;
                            }
                            await new Promise(v2029 => setTimeout(v2029, 0x7d0));
                          }
                        }
                      } finally {
                        v1882 = true;
                        while (v1880.length > 0x0) v1880.shift()(null);
                      }
                    })();
                  }
                }
              }
            }
          }
        }
      }
    }
    const v1885 = !!(v1854 || v1855 || v1856 || v1857 || v1858 || v1859 || v1860 || v1861 || v1862 || v1863),
      v1886 = v1885 ? async () => {
        if (v1858) {
          if (v1884.length > 0x0) return v1884.shift();
          if (v1858.filePath && fs.existsSync(v1858.filePath)) {
            const v2030 = parseOutlookFile(v1858.filePath);
            if (v2030.length > 0x0) {
              v1878.setStatus("Re-queuing " + v2030.length + " remaining accounts from " + path.basename(v1858.filePath) + "..."), await new Promise(v2031 => setTimeout(v2031, 0x7d0));
              for (const v2032 of v2030) {
                for (let v2033 = 0x1; v2033 <= (v1858.accountsPerEmail || 0x1); v2033++) {
                  const v2034 = {
                    ...v2032
                  };
                  v2034.instance = v2033, v2034.totalInstances = v1858.accountsPerEmail || 0x1, v2034.target = v2032.email, v2034.isOutlook = true, v1884.push(v2034);
                }
              }
              if (v1884.length > 0x0) return v1884.shift();
            }
          }
          return null;
        }
        if (v1879.length > 0x0) return v1879.shift();
        if (v1882) return null;
        return new Promise(v2035 => v1880.push(v2035));
      } : () => {
        if (v1873.length > 0x0) return v1873.splice(Math.floor(Math.random() * v1873.length), 0x1)[0x0];
        if (v1865 && fs.existsSync(v1865)) {
          const v2036 = fs.readFileSync(v1865, "utf8").split(/\r?\n/).map(v2037 => v2037.trim()).filter(v2038 => v2038.length > 0x5);
          if (v2036.length > 0x0) return v1873 = v2036, v1873.splice(Math.floor(Math.random() * v1873.length), 0x1)[0x0];
        }
        return null;
      },
      fn37 = () => v1874.length === 0x0 ? null : rotateSessionId(v1874[Math.floor(Math.random() * v1874.length)]);
    function fn38(v2039, v2040, v2041) {
      try {
        if (!v2041 || !fs.existsSync(v2041)) return;
        const v2042 = fs.readFileSync(v2041, "utf8"),
          v2043 = v2042.split(/\r?\n/),
          v2044 = v2043.filter(v2047 => {
            const v2048 = v2047.trim();
            if (!v2048) return false;
            if (v2048 === v2039) return false;
            if (v2040 && v2048 === v2040.trim()) return false;
            if (v2048.startsWith(v2039 + '|') || v2048.startsWith(v2039 + ':') || v2048 === v2039) return false;
            return true;
          }).join('\x0a');
        fs.writeFileSync(v2041, v2044);
        const v2045 = path.join(path.dirname(v2041), "used.txt"),
          v2046 = v2040 ? v2040.trim() : v2039.trim();
        fs.appendFileSync(v2045, v2046 + '\x0a');
      } catch (v2049) {
        debugLog(v2039, "remove-used-err", v2049.message);
      }
    }
    function fn39(v2050, v2051) {
      try {
        if (v1858 && v1858.filePath) fn38(v2050, v2051, v1858.filePath);else v1865 && fs.existsSync(v1865) && fn38(v2050, v2051, v1865);
      } catch (v2052) {}
    }
    async function fn40({
      cookie: v2053,
      proxy: v2054,
      uid: v2055,
      userAgent: v2056
    }) {
      const v2057 = v2056 || 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/124.0.0.0\x20Safari/537.36';
      if (v2055 && v2055 !== '0') try {
        const v2058 = {};
        v2058["User-Agent"] = v2057, v2058.Accept = '*/*', v2058["Accept-Language"] = "en-US,en;q=0.9", v2058.Origin = 'https://www.facebook.com', v2058.Referer = "https://www.facebook.com/";
        const v2059 = await sendRequest("https://graph.facebook.com/" + v2055 + "/picture?type=normal", "GET", v2058, null, v2054, 0x3a98, false),
          v2060 = typeof v2059.data === "string" ? v2059.data : JSON.stringify(v2059.data || {});
        debugLog(v2055, 'graph-live-check', {
          'status': v2059.status,
          'headers': v2059.headers,
          'body': v2060.substring(0x0, 0x12c)
        });
        if (v2059.status === 0x190 || v2060.includes("GraphMethodException") || v2060.includes("Unsupported get request")) {
          const v2061 = {};
          return v2061.isLive = false, v2061.status = "DEAD", v2061.reason = "Graph API: Profile does not exist or is disabled", v2061;
        }
      } catch (v2062) {
        debugLog(v2055, 'graph-live-err', v2062.message);
      }
      try {
        const v2063 = {};
        v2063["User-Agent"] = v2057, v2063.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8", v2063["Accept-Language"] = 'en-US,en;q=0.9', v2063.Cookie = v2053 || '', v2063["Sec-Fetch-Mode"] = "navigate", v2063["Sec-Fetch-Site"] = "none", v2063['Sec-Fetch-Dest'] = 'document';
        const v2064 = await sendRequest("https://www.facebook.com/", "GET", v2063, null, v2054, 0x4e20, true),
          v2065 = (v2064.finalUrl || v2064.redirect || '').toLowerCase(),
          v2066 = (v2064.redirectHops || []).map(v2069 => String(v2069).toLowerCase()).join('\x20'),
          v2067 = (typeof v2064.data === "string" ? v2064.data : '').toLowerCase();
        debugLog(v2055 || "status-check", "session-live-check", {
          'status': v2064.status,
          'finalUrl': v2065,
          'hops': v2066,
          'hasCheckpoint': v2065.includes("checkpoint") || v2066.includes("checkpoint") || v2067.includes('checkpoint') || v2067.includes("1501092823525282")
        });
        if (v2065.includes('/checkpoint/') || v2065.includes("1501092823525282") || v2065.includes('checkpoint.php') || v2066.includes('/checkpoint/') || v2066.includes("1501092823525282") || v2066.includes("checkpoint.php") || v2067.includes('/checkpoint/') || v2067.includes('1501092823525282') || v2067.includes("id=\"checkpointsubmitbutton\"") || v2067.includes("checkpoint_title") || v2067.includes('comet_checkpoint') || v2067.includes("dntcheckpoint") || v2067.includes("potvrďte") || v2067.includes("potvrdte") || v2067.includes("confirm you are human") || v2067.includes("confirm your identity") || v2067.includes("pokračovat") || v2067.includes("pokracovat")) {
          const v2070 = {};
          return v2070.isLive = false, v2070.status = "CHECKPOINT", v2070.reason = "Facebook Checkpoint: 1501092823525282 (Identity/Human verification required)", v2070;
        }
        if (v2065.includes("login.php") || v2066.includes('login.php') || v2067.includes("login_form") || !v2053.includes("c_user") && !v2067.includes("c_user")) {
          const v2071 = {};
          return v2071.isLive = false, v2071.status = "DEAD", v2071.reason = 'Session\x20expired\x20/\x20Logged\x20out', v2071;
        }
        try {
          const v2072 = {};
          v2072["User-Agent"] = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36", v2072.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", v2072["Accept-Language"] = "en-US,en;q=0.9", v2072.Cookie = v2053 || '';
          const v2073 = await sendRequest("https://mbasic.facebook.com/home.php", 'GET', v2072, null, v2054, 0x3a98, false),
            v2074 = (v2073.redirect || v2073.headers?.["location"] || '').toLowerCase(),
            v2075 = (typeof v2073.data === "string" ? v2073.data : '').toLowerCase();
          if (v2074.includes('checkpoint') || v2074.includes("1501092823525282") || v2075.includes("checkpoint") || v2075.includes("1501092823525282")) {
            const v2076 = {};
            return v2076.isLive = false, v2076.status = "CHECKPOINT", v2076.reason = 'Mobile\x20Checkpoint\x20detected', v2076;
          }
          if (v2074.includes("login.php") || v2075.includes("login_form")) {
            const v2077 = {};
            return v2077.isLive = false, v2077.status = "DEAD", v2077.reason = "Mobile Session dead", v2077;
          }
        } catch (v2078) {}
        const v2068 = {};
        return v2068.isLive = true, v2068.status = "LIVE", v2068.reason = "Active & Verified", v2068;
      } catch (v2079) {
        debugLog(v2055, "session-check-err", v2079.message);
        const v2080 = {};
        return v2080.isLive = false, v2080.status = 'CHECKPOINT', v2080.reason = 'Verification\x20error:\x20' + v2079.message, v2080;
      }
    }
    async function fn41({
      target: v2081,
      otpCode: v2082,
      fullCookie: v2083,
      currentProxy: v2084,
      userId: v2085,
      fbDtsg: v2086,
      lsd: v2087,
      clientObj: v2088,
      password: v2089,
      rawSourceLine: v2090,
      metaInfo: v2091,
      workerId: v2092,
      providerName: v2093
    }) {
      v1878.setStatus("Worker " + v2092 + ": 🔑 " + v2093 + " OTP " + v2082 + " — confirming...");
      const v2094 = path.resolve(__dirname);
      try {
        const v2095 = {};
        v2095.phone = v2081, v2095.otp = v2082, v2095.cookie = v2083, v2095.proxy = v2084, v2095.uid = v2085, v2095.fallbackDtsg = v2086, v2095.fallbackLsd = v2087, v2095.client = v2088;
        const v2096 = await confirmAccount(v2095);
        if (v2096.success && v2096.uid && v2096.uid !== '0') {
          const v2097 = v2096.uid;
          let v2098 = v2096.newCookie || v2083;
          v1878.setStatus("Worker " + v2092 + ": 🔍 Validating Live Status for " + v2081 + "...");
          const v2099 = {};
          v2099.cookie = v2098, v2099.proxy = v2084, v2099.uid = v2097, v2099.userAgent = v2088?.["userAgent"];
          const v2100 = await fn40(v2099);
          if (!v2100.isLive) {
            v1878.addLog("Account " + v2081 + '\x20(UID:\x20' + v2097 + ") is " + v2100.status, 'dead', v2091);
            if (v2100.status === "CHECKPOINT") {
              const v2101 = path.join(v2094, "checkpoint.txt");
              fs.appendFileSync(v2101, v2097 + '|' + (v2089 || "N/A") + '|' + v2098 + '|' + v2100.status + '|' + v2081 + '\x0a'), fn39(v2081, v2090);
            }
          } else {
            v1878.addLog('Account\x20' + v2081 + " (UID: " + v2097 + ") is LIVE & ACTIVE!", "live", v2091);
            const v2102 = path.join(v2094, "confirmed.txt");
            fs.appendFileSync(v2102, v2097 + '|' + (v2089 || 'N/A') + '|' + v2098 + '\x0a'), fn39(v2081, v2090);
            try {
              const v2103 = require("xlsx"),
                v2104 = path.join(v2094, "confirmed.xlsx");
              let v2105, v2106;
              fs.existsSync(v2104) ? (v2105 = v2103.readFile(v2104), v2106 = v2105.Sheets[v2105.SheetNames[0x0]]) : (v2105 = v2103.utils.book_new(), v2106 = v2103.utils.aoa_to_sheet([['Email', "UID", "Password", 'Cookie']]), v2103.utils.book_append_sheet(v2105, v2106, "Confirmed"));
              const v2107 = v2103.utils.decode_range(v2106["!ref"] || 'A1'),
                v2108 = v2107.e.r + 0x1,
                v2109 = {};
              v2109.r = v2108, v2109.c = 0x0;
              const v2110 = {};
              v2110.origin = v2109, v2103.utils.sheet_add_aoa(v2106, [[v2081, v2097, v2089 || "N/A", v2098]], v2110);
              const v2111 = {};
              v2111.r = 0x0, v2111.c = 0x0;
              const v2112 = {};
              v2112.r = v2108, v2112.c = 0x3;
              const v2113 = {};
              v2113.s = v2111, v2113.e = v2112, v2106['!ref'] = v2103.utils.encode_range(v2113), v2103.writeFile(v2105, v2104);
            } catch (v2114) {
              debugLog(v2081, "excel-write-err", v2114.message);
            }
          }
        } else {
          v1878.addLog("⚠️ " + v2093 + " confirm failed " + v2081 + ':\x20' + cleanErrMsg(v2096.error || "Invalid OTP"), "error", v2091);
          const v2115 = path.join(v2094, 'confirm_failed.txt');
          fs.appendFileSync(v2115, v2081 + '|' + v2082 + '|' + (v2096.error || 'Failed') + '\x0a');
          const v2116 = path.join(v2094, "failed.txt");
          fs.appendFileSync(v2116, v2081 + '|' + (v2089 || "N/A") + '|' + v2082 + '\x0a');
        }
      } catch (v2117) {
        v1878.addLog('⚠️\x20' + v2093 + " confirm error " + v2081 + ':\x20' + cleanErrMsg(v2117.message), "error", v2091);
        const v2118 = path.join(v2094, 'confirm_failed.txt');
        fs.appendFileSync(v2118, v2081 + '|' + v2082 + '|' + v2117.message + '\x0a');
        const v2119 = path.join(v2094, "failed.txt");
        fs.appendFileSync(v2119, v2081 + '|' + (v2089 || "N/A") + '|' + v2082 + '\x0a');
      }
    }
    async function fn42(v2120) {
      while (true) {
        const v2121 = await v1886();
        if (!v2121) break;
        const v2122 = typeof v2121 === "object" ? v2121.target || v2121.email : v2121,
          v2123 = typeof v2121 === "object" && v2121.isOutlook,
          v2124 = typeof v2121 === "object" && v2121.isMailcx,
          v2125 = typeof v2121 === "object" && v2121.isMailsink,
          v2126 = typeof v2121 === "object" && v2121.isTemptf,
          v2127 = typeof v2121 === "object" && v2121.isMailtm,
          v2128 = v2123 || v2124 || v2125 || v2126 || v2127 || typeof v2122 === "string" && v2122.includes('@'),
          v2129 = v2123 ? v2121 : null,
          v2130 = v2123 ? v2121.rawLine || v2121.email + '|' + v2121.pass + '|' + v2121.refreshToken + '|' + (v2121.clientId || '') : typeof v2121 === "object" ? v2121.email : v2121,
          v2131 = path.resolve(__dirname);
        let v2132 = fn37();
        const v2133 = v2132 ? await getProxyCountry(v2132.original || v2132.host + ':' + v2132.port) : "Direct";
        let v2134;
        if (v2128) v2134 = getGeoFromCountry(v2133);else {
          const v2140 = v2122.replace(/\D/g, '');
          v2134 = getCountryFromPhone(v2140);
        }
        const v2135 = v2134.lang.split(',')[0x0];
        let v2136 = v2134.name || v2134.iso;
        try {
          const v2141 = {};
          v2141.type = "region", v2136 = new Intl.DisplayNames(['en'], v2141).of(v2134.iso) || v2136;
        } catch (v2142) {}
        const v2137 = '[' + v2135 + "] Proxy: " + v2133 + '\x20|\x20' + v2136,
          v2138 = v2128 ? 0x1 : v1869;
        let v2139 = false;
        for (let v2143 = 0x1; v2143 <= v2138; v2143++) {
          let v2144 = 0x0,
            v2145 = false;
          while (v2144 < 0x3 && !v2145) {
            v2144++;
            try {
              const v2146 = getRandomClient(v1868, "desktop"),
                v2147 = await createAccount(v2122, {
                  'onStatus': v2148 => v1878.setStatus("Worker " + v2120 + '\x20[' + v2143 + '/' + v2138 + "] [WWW]: " + v2148),
                  'proxy': v2132,
                  'workerId': v2120,
                  'browserPref': v1868,
                  'customPassword': v1870,
                  'deviceType': "desktop",
                  'customGeo': v2134
                });
              if (v2147.success) {
                v2145 = true, v2139 = true, v1878.successful++;
                if (v2143 === 0x1) v1878.processed++;
                v2143 === 0x1 && !v2128 && !v1855?.["autoConfirm"] && !v1856?.["autoConfirm"] && !v1857?.["autoConfirm"] && fn39(v2122, v2130);
                const v2149 = v2147.cookieMap || {},
                  v2150 = Object.entries(v2149).map(([v2154, v2155]) => v2154 + '=' + v2155).join(';\x20'),
                  v2151 = v2147.userId ? '|UID:' + v2147.userId : '',
                  v2152 = v2123 ? "OUTLOOK_EMAIL" : v2124 ? "MAILCX_EMAIL" : v2125 ? "MAILSINK_EMAIL" : v2126 ? "TEMPTF_EMAIL" : v2127 ? "MAILTM_EMAIL" : 'PHONE',
                  v2153 = v2146?.["name"] || v1868;
                fs.appendFileSync(SUCCESSFUL_FILE, v2147.phone + '|' + (v2147.password || 'N/A') + '|' + v2150 + v2151 + "|Method:" + v2152 + "|Browser:" + v2153 + '|Proxy:' + v2133 + '|Country:' + v2136 + "|Language:" + v2135 + '\x0a'), v1878.addLog("Triggered OTP for " + v2147.phone + " [Send " + v2143 + '/' + v2138 + ']', 'success', v2137);
                if (v2123 && v2129) {
                  v1878.setStatus("Worker " + v2120 + ": ⏳ Polling Outlook OTP for " + v2122 + '\x20(' + v2129.instance + '/' + v2129.totalInstances + ")...");
                  const v2156 = {};
                  v2156.email = v2129.email, v2156.pass = v2129.pass, v2156.refreshToken = v2129.refreshToken, v2156.clientId = v2129.clientId || "9e5f94bc-e8a4-4e73-b8be-63364c29d753", v2156.timeoutMs = 0xea60;
                  const v2157 = await fetchOutlookOtp(v2156);
                  if (v2157) {
                    const v2158 = {};
                    v2158.target = v2122, v2158.otpCode = v2157, v2158.fullCookie = v2150, v2158.currentProxy = v2132, v2158.userId = v2147.userId, v2158.fbDtsg = v2147.fbDtsg, v2158.lsd = v2147.lsd, v2158.clientObj = v2146, v2158.password = v2147.password || v2129?.["pass"], v2158.rawSourceLine = v2130, v2158.metaInfo = v2137, v2158.workerId = v2120, v2158.providerName = 'Outlook', await fn41(v2158);
                  } else {
                    v1878.addLog("No OTP received in 60s for " + v2122, "skip", v2137);
                    const v2159 = path.join(v2131, "otp_failed.txt");
                    fs.appendFileSync(v2159, v2130 + '\x0a');
                  }
                } else {
                  if (v2124 && v2121.apiKey) {
                    v1878.setStatus("Worker " + v2120 + ": ⏳ Polling Mail.cx OTP for " + v2122 + "...");
                    const v2160 = await mailcxPollOtp(v2121.apiKey, v2122, 0x15f90);
                    if (v2160) {
                      const v2161 = {};
                      v2161.target = v2122, v2161.otpCode = v2160, v2161.fullCookie = v2150, v2161.currentProxy = v2132, v2161.userId = v2147.userId, v2161.fbDtsg = v2147.fbDtsg, v2161.lsd = v2147.lsd, v2161.clientObj = v2146, v2161.password = v2147.password, v2161.rawSourceLine = v2130, v2161.metaInfo = v2137, v2161.workerId = v2120, v2161.providerName = "Mail.cx", await fn41(v2161);
                    } else {
                      v1878.addLog("No OTP received in 90s for " + v2122, "skip", v2137);
                      const v2162 = path.join(v2131, "otp_failed.txt");
                      fs.appendFileSync(v2162, v2130 + '\x0a');
                    }
                  } else {
                    if (v2125 && v2121.inboxId) {
                      v1878.setStatus("Worker " + v2120 + ": ⏳ Polling Mailsink OTP for " + v2122 + "...");
                      const v2163 = await mailsinkPollOtp(v2121.apiKey, v2121.inboxId, 0xea60);
                      if (v2163) {
                        const v2164 = {};
                        v2164.target = v2122, v2164.otpCode = v2163, v2164.fullCookie = v2150, v2164.currentProxy = v2132, v2164.userId = v2147.userId, v2164.fbDtsg = v2147.fbDtsg, v2164.lsd = v2147.lsd, v2164.clientObj = v2146, v2164.password = v2147.password, v2164.rawSourceLine = v2130, v2164.metaInfo = v2137, v2164.workerId = v2120, v2164.providerName = "Mailsink", await fn41(v2164);
                      } else {
                        v1878.addLog("No OTP received in 60s for " + v2122, "skip", v2137);
                        const v2165 = path.join(v2131, "otp_failed.txt");
                        fs.appendFileSync(v2165, v2130 + '\x0a');
                      }
                    } else {
                      if (v2126) {
                        v1878.setStatus("Worker " + v2120 + ": ⏳ Polling Temp.tf OTP for " + v2122 + '...');
                        const v2166 = await temptfPollOtp(v2122, 0x15f90);
                        if (v2166) {
                          const v2167 = {};
                          v2167.target = v2122, v2167.otpCode = v2166, v2167.fullCookie = v2150, v2167.currentProxy = v2132, v2167.userId = v2147.userId, v2167.fbDtsg = v2147.fbDtsg, v2167.lsd = v2147.lsd, v2167.clientObj = v2146, v2167.password = v2147.password, v2167.rawSourceLine = v2130, v2167.metaInfo = v2137, v2167.workerId = v2120, v2167.providerName = "Temp.tf", await fn41(v2167);
                        } else {
                          v1878.addLog("No OTP received in 90s for " + v2122, "skip", v2137);
                          const v2168 = path.join(v2131, "otp_failed.txt");
                          fs.appendFileSync(v2168, v2130 + '\x0a');
                        }
                      } else {
                        if (v2127 && v2121.token) {
                          v1878.setStatus("Worker " + v2120 + ": ⏳ Polling Mail.tm OTP for " + v2122 + "...");
                          const v2169 = await mailtmPollOtp(v2121.token, 0x15f90, v2121.host);
                          if (v2169) {
                            const v2170 = {};
                            v2170.target = v2122, v2170.otpCode = v2169, v2170.fullCookie = v2150, v2170.currentProxy = v2132, v2170.userId = v2147.userId, v2170.fbDtsg = v2147.fbDtsg, v2170.lsd = v2147.lsd, v2170.clientObj = v2146, v2170.password = v2147.password || v2121.password, v2170.rawSourceLine = v2130, v2170.metaInfo = v2137, v2170.workerId = v2120, v2170.providerName = "Mail.tm", await fn41(v2170);
                          } else {
                            v1878.addLog("No OTP received in 90s for " + v2122, "skip", v2137);
                            const v2171 = path.join(v2131, "otp_failed.txt");
                            fs.appendFileSync(v2171, v2130 + '\x0a');
                          }
                        }
                      }
                    }
                  }
                }
                if (v1855 && v1855.autoConfirm && v1855.otpPath) {
                  const v2172 = Date.now();
                  v1878.setStatus("Worker " + v2120 + ": ⏳ Waiting OTP for " + v2147.phone + "...");
                  const v2173 = await twoOoPollOtp(v1855.apiKey, v1855.otpPath, v2147.phone, v2172, 0x1f40);
                  if (v2173) {
                    const v2174 = {};
                    v2174.target = v2147.phone, v2174.otpCode = v2173, v2174.fullCookie = v2150, v2174.currentProxy = v2132, v2174.userId = v2147.userId, v2174.fbDtsg = v2147.fbDtsg, v2174.lsd = v2147.lsd, v2174.clientObj = v2146, v2174.password = v2147.password, v2174.rawSourceLine = v2130, v2174.metaInfo = v2137, v2174.workerId = v2120, v2174.providerName = "Voltx/Stex", await fn41(v2174);
                  }
                }
                if (v1856 && v1856.autoConfirm) {
                  const v2175 = v1883.get(v2147.phone?.["replace"](/[^0-9]/g, ''));
                  if (v2175) {
                    v1878.setStatus('Worker\x20' + v2120 + ": ⏳ SMS Bower — waiting OTP for " + v2147.phone + "...");
                    const v2176 = await smsBowerPollOtp(v1856.apiKey, v2175, 0xdbba0);
                    if (v2176) {
                      await smsBowerSetStatus(v1856.apiKey, v2175, 0x6);
                      const v2177 = {};
                      v2177.target = v2147.phone, v2177.otpCode = v2176, v2177.fullCookie = v2150, v2177.currentProxy = v2132, v2177.userId = v2147.userId, v2177.fbDtsg = v2147.fbDtsg, v2177.lsd = v2147.lsd, v2177.clientObj = v2146, v2177.password = v2147.password, v2177.rawSourceLine = v2130, v2177.metaInfo = v2137, v2177.workerId = v2120, v2177.providerName = "SMS Bower", await fn41(v2177);
                    } else await smsBowerSetStatus(v1856.apiKey, v2175, 0x8);
                  }
                }
                if (v1857 && v1857.autoConfirm) {
                  v1878.setStatus("Worker " + v2120 + ": ⏳ Zenex — waiting OTP for " + v2147.phone + '...');
                  const v2178 = await zenexPollOtp(v1857.apiKey, v2147.phone, 0xdbba0);
                  if (v2178) {
                    const v2179 = {};
                    v2179.target = v2147.phone, v2179.otpCode = v2178, v2179.fullCookie = v2150, v2179.currentProxy = v2132, v2179.userId = v2147.userId, v2179.fbDtsg = v2147.fbDtsg, v2179.lsd = v2147.lsd, v2179.clientObj = v2146, v2179.password = v2147.password, v2179.rawSourceLine = v2130, v2179.metaInfo = v2137, v2179.workerId = v2120, v2179.providerName = 'Zenex', await fn41(v2179);
                  }
                }
              } else {
                const v2180 = /EPROTO|ECONNRESET|socket|TLS|disconnected|packet length|hang up|timeout|ETIMEDOUT|routines/i.test(v2147.message || '');
                if (v2180 && v2144 < 0x3) {
                  v2132 = fn37() || rotateSessionId(v2132), v1878.addLog("Network drop on " + (v2147.phone || v2122) + ". Rotating proxy...", "skip", v2137);
                  continue;
                }
                v2145 = true;
                if (v2143 === v2138 || v2143 === 0x1) {
                  v1878.failed++;
                  if (v2143 === 0x1) v1878.processed++;
                  fs.appendFileSync(FAILED_FILE, (v2147.phone || v2122) + '|' + v2147.message + '\x0a'), v1878.addLog((v2147.phone || v2122) + " → " + cleanErrMsg(v2147.message), "error", v2137);
                }
                break;
              }
            } catch (v2181) {
              const v2182 = v2181.message || '';
              if (v2181.noRetry || v2181.alreadyRegistered) {
                v2145 = true, v1878.failed++, v1878.processed++, fs.appendFileSync(FAILED_FILE, v2122 + "|already_registered\n"), v1878.addLog(v2122 + " → Already registered", 'error', v2137);
                break;
              } else {
                if (v2182.includes("timeout") || v2182.includes("socket") || v2182.includes("Proxy") || v2182.includes("proxy") || v2182.includes("EPROTO") || v2182.includes("ECONNRESET") || v2182.includes("hang up") || v2182.includes("TLS") || v2182.includes('disconnected') || v2182.includes("packet length") || v2182.includes("ECONNREFUSED") || v2182.includes("ETIMEDOUT") || v2182.includes('routines')) v2132 = fn37() || rotateSessionId(v2132), v1878.addLog("Network reset on " + v2122 + ". Rotating proxy...", "skip", v2137), v2144 >= 0x2 && (v2145 = true, !v2139 && (v1878.failed++, v1878.processed++, fs.appendFileSync(FAILED_FILE, v2122 + '|' + v2182 + '\x0a'), v1878.addLog(v2122 + '\x20→\x20' + cleanErrMsg(v2182), 'error', v2137)));else {
                  v2145 = true;
                  !v2139 && (v1878.failed++, v1878.processed++, fs.appendFileSync(FAILED_FILE, v2122 + '|' + v2182 + '\x0a'), v1878.addLog(v2122 + " → " + cleanErrMsg(v2182), "error", v2137));
                  break;
                }
              }
            }
          }
          if (!v2139 && v2145) break;
        }
      }
    }
    const v1887 = v1854 || v1855 || v1856 || v1857 || v1858 || v1859 || v1860 || v1861 || v1862 || v1863 ? (v1854 || v1855 || v1856 || v1857 || v1858 || v1859 || v1860 || v1861 || v1862 || v1863).totalCount : Array.isArray(v1873) ? v1873.length : v1858 ? v1884.length : 0x32,
      v1888 = Math.min(v1866, Math.max(0x1, v1887)),
      v1889 = [],
      v1890 = setInterval(() => v1878.render(), 0x1f4);
    for (let v2183 = 0x0; v2183 < v1888; v2183++) v1889.push(fn42(v2183));
    await Promise.all(v1889), clearInterval(v1890), v1878.render(), v1878.stop(), process.exit(0x0);
  }
  start().catch(v2184 => {
    console.error(R("\n  ✗ Fatal error: " + v2184.message + '\x0a'));
    process.exit(0x1);
  });
}