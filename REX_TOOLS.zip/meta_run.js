const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v63) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v64 = {};
      v64.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v64), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v65) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent"),
  v1 = {};
v1.keepAlive = true, v1.maxSockets = 0xc8, v1.timeout = 0x186a0;
const keepAliveAgent = new https.Agent(v1);
class NexaRateLimiter {
  constructor(v66) {
    this.delayMs = v66, this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v67) {
    return new Promise((v68, v69) => {
      this.queue.push(async () => {
        try {
          v68(await v67());
        } catch (v70) {
          v69(v70);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      const v71 = this.queue.shift();
      await v71(), await new Promise(v72 => setTimeout(v72, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  TWOOO_HOST = "api.2oo9.cloud",
  TWOOO_VOLTX_GET = "/MXS47FLFX0U/tnevs/@public/api/getnum",
  TWOOO_VOLTX_CONSOLE = "/MXS47FLFX0U/tnevs/@public/api/console",
  TWOOO_STEX_GET = "/MXS47FLFX0U/tness/@public/api/getnum",
  TWOOO_STEX_CONSOLE = "/MXS47FLFX0U/tness/@public/api/console",
  SMSBOWER_HOST = "smsbower.page",
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v73) {
  return new Promise((v74, v75) => {
    const v76 = {};
    v76.hostname = SMSBOWER_HOST, v76.port = 0x1bb, v76.path = "/stubs/handler_api.php?" + v73, v76.method = "GET", v76.headers = {};
    v76.headers.Accept = "text/plain", v76.headers.Connection = "close";
    const v77 = v76,
      v78 = https.request(v77, v79 => {
        {
          let v80 = '';
          v79.on("data", v81 => v80 += v81), v79.on("end", () => v74(v80.trim()));
        }
      });
    v78.on("error", v82 => v75(new Error("SmsBower net: " + v82.message)));
    v78.setTimeout(15000, () => {
      v78.destroy();
      v75(new Error("SmsBower timeout"));
    }), v78.end();
  });
}
function smsBowerFetchNumber(v83, v84, v85, v86) {
  let v87 = "api_key=" + encodeURIComponent(v83) + "&action=getNumber&service=" + encodeURIComponent(v84 || 'fb');
  if (v85 && String(v85).trim() !== '0' && String(v85).trim() !== '') {
    v87 += "&country=" + encodeURIComponent(v85);
  }
  return v86 && parseFloat(v86) > 0 && (v87 += "&maxPrice=" + encodeURIComponent(v86)), smsBowerRequest(v87).then(v88 => {
    {
      if (v88.startsWith("ACCESS_NUMBER:")) {
        {
          const v89 = v88.split(':');
          return {
            'activationId': v89[1],
            'phoneNumber': v89[2].replace(/[^0-9]/g, '')
          };
        }
      }
      throw new Error("SmsBower: " + v88);
    }
  });
}
const ZENEX_HOST = "api.zenexnetwork.com",
  ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v90, v91) {
  return new Promise((v92, v93) => {
    const v94 = {};
    v94.range = v91, v94.is_national = false, v94.remove_plus = false;
    const v95 = JSON.stringify(v94);
    const v96 = {
        'hostname': ZENEX_HOST,
        'port': 0x1bb,
        'path': "/v1/getnum",
        'method': "POST",
        'headers': {
          'mapikey': v90,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v95)
        }
      },
      v97 = https.request(v96, v98 => {
        {
          let v99 = '';
          v98.on("data", v100 => v99 += v100), v98.on("end", () => {
            try {
              {
                const v101 = JSON.parse(v99);
                if (v101?.["meta"]?.["code"] === 200 && v101?.["data"]?.["full_number"]) v92(v101.data.full_number.replace(/[^0-9]/g, ''));else v93(new Error(v101?.["message"] || "Zenex: no number"));
              }
            } catch (v102) {
              v93(new Error("Zenex: invalid JSON"));
            }
          });
        }
      });
    v97.on("error", v103 => v93(new Error("Zenex net: " + v103.message))), v97.setTimeout(15000, () => {
      v97.destroy(), v93(new Error("Zenex timeout"));
    }), v97.write(v95), v97.end();
  });
}
function nexaFetchNumber(v104, v105, v106) {
  return new Promise((v107, v108) => {
    {
      const v109 = {};
      v109.range = v105, v109.format = "normal";
      const v110 = JSON.stringify(v109),
        v111 = {
          'hostname': "nexaotpservice.com",
          'port': 0x50,
          'path': v106 || "/api/v1/numbers/get",
          'method': "POST",
          'headers': {
            'X-API-Key': v104,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v110)
          }
        },
        v112 = http.request(v111, v113 => {
          {
            let v114 = '';
            v113.on("data", v115 => v114 += v115), v113.on("end", () => {
              try {
                const v116 = JSON.parse(v114);
                if (v116.success && v116.number) v107(v116.number.replace(/[^0-9]/g, ''));else {
                  v108(new Error(v116.error || "NexaOTP: No number returned"));
                }
              } catch (v117) {
                v108(new Error("NexaOTP: Invalid response"));
              }
            });
          }
        });
      v112.on("error", v118 => v108(new Error("NexaOTP network: " + v118.message))), v112.setTimeout(10000, () => {
        v112.destroy();
        v108(new Error("NexaOTP: Timeout"));
      }), v112.write(v110), v112.end();
    }
  });
}
const twoOoLimiter = new NexaRateLimiter(500);
function stripRid(v119) {
  return v119.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v120, v121, v122) {
  return new Promise((v123, v124) => {
    const v125 = stripRid(v121),
      v126 = {};
    v126.rid = v125;
    const v127 = JSON.stringify(v126);
    const v128 = {
        'hostname': TWOOO_HOST,
        'port': 0x1bb,
        'path': v122,
        'method': "POST",
        'headers': {
          'mauthapi': v120,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v127)
        }
      },
      v129 = https.request(v128, v130 => {
        {
          let v131 = '';
          v130.on("data", v132 => v131 += v132), v130.on("end", () => {
            try {
              {
                const v133 = JSON.parse(v131);
                if (v133?.["meta"]?.["code"] === 200 && v133?.["data"]?.["no_plus_number"]) v123(v133.data.no_plus_number);else v124(new Error(v133?.["message"] || v133?.["meta"]?.["status"] || "2oo9: No number"));
              }
            } catch (v134) {
              v124(new Error("2oo9: Invalid JSON"));
            }
          });
        }
      });
    v129.on("error", v135 => v124(new Error("2oo9 network: " + v135.message)));
    v129.setTimeout(10000, () => {
      v129.destroy();
      v124(new Error("2oo9: Timeout"));
    }), v129.write(v127), v129.end();
  });
}
function twoOoFetchConsole(v136, v137) {
  return new Promise((v138, v139) => {
    const v140 = {};
    v140.mauthapi = v136;
    const v141 = {};
    v141.hostname = TWOOO_HOST;
    v141.port = 0x1bb;
    v141.path = v137, v141.method = "GET";
    v141.headers = v140;
    const v142 = v141,
      v143 = https.request(v142, v144 => {
        {
          let v145 = '';
          v144.on("data", v146 => v145 += v146), v144.on("end", () => {
            try {
              {
                const v147 = JSON.parse(v145);
                if (v147?.["meta"]?.["code"] === 200 && Array.isArray(v147?.["data"]?.["hits"])) v138(v147.data.hits);else v139(new Error(v147?.["message"] || "Console fetch failed"));
              }
            } catch (v148) {
              v139(new Error("Console: Invalid JSON"));
            }
          });
        }
      });
    v143.on("error", v149 => v139(new Error("Console network: " + v149.message)));
    v143.setTimeout(10000, () => {
      v143.destroy();
      v139(new Error("Console timeout"));
    }), v143.end();
  });
}
function parseTwoOoRangeSelection(v150, v151) {
  const v152 = new Set();
  const v153 = v150.split(/[\s,]+/).filter(v154 => v154);
  for (const v155 of v153) {
    const v156 = v155.match(/^(\d+)-(\d+)$/);
    if (v156) {
      for (let v157 = +v156[1]; v157 <= +v156[2]; v157++) {
        if (v157 >= 1 && v157 <= v151) v152.add(v157 - 1);
      }
    } else {
      {
        const v158 = parseInt(v155);
        if (!isNaN(v158) && v158 >= 1 && v158 <= v151) v152.add(v158 - 1);
      }
    }
  }
  return [...v152].sort((v159, v160) => v159 - v160);
}
async function autoRangeFinderFor2Oo(v161, v162, v163, v164) {
  const v165 = {};
  v165.facebook = ["facebook", 'fb'], v165.instagram = ["instagram", 'ig'];
  v165.meta = ["meta"], v165.all = ["facebook", 'fb', "instagram", 'ig', "meta"];
  const v166 = v165,
    v167 = {};
  v167.facebook = "📘 Facebook";
  v167.instagram = "📸 Instagram", v167.meta = "🌐 Meta", v167.all = "📦 All (FB+IG+Meta)";
  const v168 = v167;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v169 = [];
  try {
    v169 = await twoOoFetchConsole(v161, v162);
  } catch (v178) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v178.message + '\x0a')), null;
  }
  const v170 = v169.slice(0, 100);
  if (v170.length === 0) {
    return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  }
  const v171 = await v163("Filter by app:", [{
      'name': "📘 Facebook",
      'value': "facebook"
    }, {
      'name': "📸 Instagram",
      'value': "instagram"
    }, {
      'name': "🌐 Meta",
      'value': "meta"
    }, {
      'name': "📦 All (FB+IG+Meta)",
      'value': "all"
    }]),
    v172 = v166[v171],
    v173 = v170.filter(v179 => {
      const v180 = (v179.sid || '').toLowerCase(),
        v181 = (v179.message || '').toLowerCase();
      return v172.some(v182 => v180.includes(v182) || v181.includes(v182));
    });
  if (v173.length === 0) return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  const v174 = {},
    v175 = {};
  for (const v183 of v173) {
    {
      const v184 = v183.range || '';
      if (!v184) continue;
      v174[v184] = (v174[v184] || 0) + 1;
      const v185 = {};
      v185.facebook = 0x0, v185.instagram = 0x0, v185.meta = 0x0, v175[v184] = v175[v184] || v185;
      if (v166.facebook.some(v186 => (v183.sid || '').toLowerCase().includes(v186) || (v183.message || '').toLowerCase().includes(v186))) v175[v184].facebook++;
      if (v166.instagram.some(v187 => (v183.sid || '').toLowerCase().includes(v187) || (v183.message || '').toLowerCase().includes(v187))) v175[v184].instagram++;
      if (v166.meta.some(v188 => (v183.sid || '').toLowerCase().includes(v188) || (v183.message || '').toLowerCase().includes(v188))) v175[v184].meta++;
    }
  }
  const v176 = Object.entries(v174).sort((v189, v190) => v190[1] - v189[1]).slice(0, 5);
  if (v176.length === 0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v177 = await v163("Range Finder mode:", [{
    'name': "⚡ Auto detect & send (#1 range)",
    'value': "auto"
  }, {
    'name': "📊 Show top 5 & select",
    'value': "select"
  }]);
  if (v177 === "auto") {
    {
      const [v191, v192] = v176[0],
        v193 = v175[v191] || {},
        v194 = [];
      if (v193.facebook) v194.push("📘FB(" + v193.facebook + ')');
      if (v193.instagram) v194.push("📸IG(" + v193.instagram + ')');
      if (v193.meta) v194.push("🌐Meta(" + v193.meta + ')');
      return console.log(chalk.green("\n  ✓ Auto Range: " + v191 + "  (" + v192 + " hits)  " + v194.join('\x20') + '\x0a')), [v191];
    }
  } else {
    {
      console.log(chalk.cyan("\n  App: " + v168[v171] + "  |  Scanned: " + v173.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(22))), v176.forEach(([v198, v199], v200) => {
        {
          const v201 = v175[v198] || {},
            v202 = [];
          if (v201.facebook) v202.push("📘FB(" + v201.facebook + ')');
          if (v201.instagram) v202.push("📸IG(" + v201.instagram + ')');
          if (v201.meta) v202.push("🌐Meta(" + v201.meta + ')');
          console.log(chalk.cyan('\x20\x20' + String(v200 + 1).padEnd(3) + '\x20') + chalk.green(v198.padEnd(16)) + chalk.yellow(String(v199).padEnd(5)) + chalk.gray('█'.repeat(Math.min(v199, 12)) + '\x20\x20') + (v202.join('\x20') || chalk.gray('?')));
        }
      }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
      const v195 = await v164("Select ranges:", ''),
        v196 = parseTwoOoRangeSelection(v195, v176.length);
      if (v196.length === 0) {
        return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
      }
      const v197 = v196.map(v203 => v176[v203][0]);
      return console.log(chalk.green("\n  ✓ Selected: " + v197.join(',\x20') + '\x0a')), v197;
    }
  }
}
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt",
  DEBUG_FILE = "debug.txt";
function debugLog(v204, v205, v206) {}
const B = chalk.hex("#4267B2"),
  C = chalk.hex("#1877F2"),
  Y = chalk.hex("#FFD700"),
  W = chalk.white,
  G = chalk.gray;
(function () {
  const fn3 = function () {
    {
      let v208;
      try {
        v208 = Function('return (function() {}.constructor("return this")( ));')();
      } catch (v209) {
        v208 = window;
      }
      return v208;
    }
  };
  const v207 = fn3();
  v207.setInterval(fn2, 3500);
})();
const R = chalk.hex("#FF6B6B"),
  DIM = chalk.hex("#555555");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(C("   ____                                      _  ___              "));
    console.log(C("  / ___|  ___ _ __ __ _ _ __   ___ _ __     | |/ (_)_ __   __ _  "));
    console.log(C("  \\___ \\ / __| '__/ _` | '_ \\ / _ \\ '__|    | ' <| | '_ \\ / _` | "));
    console.log(C("   ___) | (__| | | (_| | |_) |  __/ |       | . \\| | | | | (_| | "));
    console.log(C("  |____/ \\___|_|  \\__,_| .__/ \\___|_|       |_|\\_\\_|_| |_|\\__, | "));
    console.log(C("                       |_|                                |___/  \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Tool      : ") + C("REX — Meta                   ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Version   : ") + Y("V7.0.2                       ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
function sleep(v210) {
  return new Promise(v211 => setTimeout(v211, v210));
}
function normalizePhoneNumber(v212) {
  let v213 = v212.replace(/\D/g, '');
  return !v213.startsWith('+') && (v213 = '+' + v213), v213;
}
const uuid = () => crypto.randomUUID();
let _displayNames;
try {
  const v214 = {};
  v214.type = "region", _displayNames = new Intl.DisplayNames(['en'], v214);
} catch (v215) {
  const v216 = {};
  v216.of = v217 => v217, _displayNames = v216;
}
function genQplJoinId() {
  return crypto.randomBytes(9).toString("hex").substring(0, 17);
}
function genSessionId() {
  const fn4 = () => crypto.randomBytes(3).toString("hex");
  return fn4() + ':' + fn4() + ':' + fn4();
}
const DIAL_MAP = [["1868", 'TT', "en-TT,en;q=0.9"], ["1876", 'JM', "en-JM,en;q=0.9"], ["1809", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["1829", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["1849", 'DO', "es-DO,es;q=0.9,en;q=0.8"], ["880", 'BD', "bn-BD,bn;q=0.9,en;q=0.8"], ["855", 'KH', "km-KH,km;q=0.9,en;q=0.8"], ["856", 'LA', "lo-LA,lo;q=0.9,en;q=0.8"], ["228", 'TG', "fr-TG,fr;q=0.9,en;q=0.8"], ["229", 'BJ', "fr-BJ,fr;q=0.9,en;q=0.8"], ["233", 'GH', "en-GH,en;q=0.9"], ["234", 'NG', "en-NG,en;q=0.9"], ["237", 'CM', "fr-CM,fr;q=0.9,en;q=0.8"], ["243", 'CD', "fr-CD,fr;q=0.9"], ["254", 'KE', "sw-KE,sw;q=0.9,en;q=0.8"], ["255", 'TZ', "sw-TZ,sw;q=0.9,en;q=0.8"], ["256", 'UG', "en-UG,en;q=0.9"], ["260", 'ZM', "en-ZM,en;q=0.9"], ["263", 'ZW', "en-ZW,en;q=0.9"], ["212", 'MA', "ar-MA,ar;q=0.9,fr;q=0.8"], ["213", 'DZ', "ar-DZ,ar;q=0.9,fr;q=0.8"], ["216", 'TN', "ar-TN,ar;q=0.9,fr;q=0.8"], ["218", 'LY', "ar-LY,ar;q=0.9,en;q=0.8"], ["220", 'GM', "en-GM,en;q=0.9"], ["221", 'SN', "fr-SN,fr;q=0.9"], ["222", 'MR', "ar-MR,ar;q=0.9,fr;q=0.8"], ["223", 'ML', "fr-ML,fr;q=0.9"], ["224", 'GN', "fr-GN,fr;q=0.9"], ["225", 'CI', "fr-CI,fr;q=0.9"], ["226", 'BF', "fr-BF,fr;q=0.9"], ["227", 'NE', "fr-NE,fr;q=0.9"], ["230", 'MU', "en-MU,en;q=0.9,fr;q=0.8"], ["231", 'LR', "en-LR,en;q=0.9"], ["232", 'SL', "en-SL,en;q=0.9"], ["235", 'TD', "fr-TD,fr;q=0.9,ar;q=0.8"], ["236", 'CF', "fr-CF,fr;q=0.9"], ["238", 'CV', "pt-CV,pt;q=0.9"], ["239", 'ST', "pt-ST,pt;q=0.9"], ["240", 'GQ', "es-GQ,es;q=0.9"], ["241", 'GA', "fr-GA,fr;q=0.9"], ["242", 'CG', "fr-CG,fr;q=0.9"], ["244", 'AO', "pt-AO,pt;q=0.9"], ["245", 'GW', "pt-GW,pt;q=0.9"], ["246", 'IO', "en-IO,en;q=0.9"], ["247", 'AC', "en-AC,en;q=0.9"], ["248", 'SC', "en-SC,en;q=0.9,fr;q=0.8"], ["249", 'SD', "ar-SD,ar;q=0.9,en;q=0.8"], ["250", 'RW', "rw-RW,rw;q=0.9,en;q=0.8,fr;q=0.7"], ["251", 'ET', "am-ET,am;q=0.9,en;q=0.8"], ["252", 'SO', "so-SO,so;q=0.9,ar;q=0.8,en;q=0.7"], ["253", 'DJ', "fr-DJ,fr;q=0.9,ar;q=0.8"], ["257", 'BI', "fr-BI,fr;q=0.9,rn;q=0.8"], ["258", 'MZ', "pt-MZ,pt;q=0.9"], ["261", 'MG', "mg-MG,mg;q=0.9,fr;q=0.8"], ["262", 'RE', "fr-RE,fr;q=0.9"], ["264", 'NA', "en-NA,en;q=0.9"], ["265", 'MW', "en-MW,en;q=0.9"], ["266", 'LS', "en-LS,en;q=0.9"], ["267", 'BW', "en-BW,en;q=0.9"], ["268", 'SZ', "en-SZ,en;q=0.9"], ["269", 'KM', "fr-KM,fr;q=0.9,ar;q=0.8"], ["966", 'SA', "ar-SA,ar;q=0.9,en;q=0.8"], ["971", 'AE', "ar-AE,ar;q=0.9,en;q=0.8"], ["973", 'BH', "ar-BH,ar;q=0.9,en;q=0.8"], ["974", 'QA', "ar-QA,ar;q=0.9,en;q=0.8"], ["968", 'OM', "ar-OM,ar;q=0.9,en;q=0.8"], ["965", 'KW', "ar-KW,ar;q=0.9,en;q=0.8"], ["964", 'IQ', "ar-IQ,ar;q=0.9,en;q=0.8"], ["963", 'SY', "ar-SY,ar;q=0.9,en;q=0.8"], ["962", 'JO', "ar-JO,ar;q=0.9,en;q=0.8"], ["961", 'LB', "ar-LB,ar;q=0.9,en;q=0.8,fr;q=0.7"], ["967", 'YE', "ar-YE,ar;q=0.9,en;q=0.8"], ["970", 'PS', "ar-PS,ar;q=0.9,en;q=0.8"], ["972", 'IL', "he-IL,he;q=0.9,en;q=0.8"], ["992", 'TJ', "tg-TJ,tg;q=0.9,ru;q=0.8"], ["993", 'TM', "tk-TM,tk;q=0.9,ru;q=0.8"], ["994", 'AZ', "az-AZ,az;q=0.9,ru;q=0.8"], ["995", 'GE', "ka-GE,ka;q=0.9,en;q=0.8"], ["996", 'KG', "ky-KG,ky;q=0.9,ru;q=0.8"], ["998", 'UZ', "uz-UZ,uz;q=0.9,ru;q=0.8"], ["977", 'NP', "ne-NP,ne;q=0.9,en;q=0.8"], ["975", 'BT', "dz-BT,dz;q=0.9,en;q=0.8"], ["959", 'MM', "my-MM,my;q=0.9,en;q=0.8"], ["670", 'TL', "pt-TL,pt;q=0.9,en;q=0.8"], ["673", 'BN', "ms-BN,ms;q=0.9,en;q=0.8"], ["676", 'TO', "en-TO,en;q=0.9"], ["677", 'SB', "en-SB,en;q=0.9"], ["678", 'VU', "en-VU,en;q=0.9,fr;q=0.8"], ["679", 'FJ', "en-FJ,en;q=0.9"], ["680", 'PW', "en-PW,en;q=0.9"], ["591", 'BO', "es-BO,es;q=0.9,en;q=0.8"], ["592", 'GY', "en-GY,en;q=0.9"], ["593", 'EC', "es-EC,es;q=0.9,en;q=0.8"], ["594", 'GF', "fr-GF,fr;q=0.9"], ["595", 'PY', "es-PY,es;q=0.9,en;q=0.8"], ["596", 'MQ', "fr-MQ,fr;q=0.9"], ["597", 'SR', "nl-SR,nl;q=0.9,en;q=0.8"], ["598", 'UY', "es-UY,es;q=0.9,en;q=0.8"], ["387", 'BA', "bs-BA,bs;q=0.9,hr;q=0.8,en;q=0.7"], ["385", 'HR', "hr-HR,hr;q=0.9,en;q=0.8"], ["386", 'SI', "sl-SI,sl;q=0.9,en;q=0.8"], ["389", 'MK', "mk-MK,mk;q=0.9,en;q=0.8"], ["381", 'RS', "sr-RS,sr;q=0.9,en;q=0.8"], ["382", 'ME', "sr-ME,sr;q=0.9,en;q=0.8"], ["383", 'XK', "sq-XK,sq;q=0.9,sr;q=0.8,en;q=0.7"], ["355", 'AL', "sq-AL,sq;q=0.9,en;q=0.8"], ["356", 'MT', "mt-MT,mt;q=0.9,en;q=0.8"], ["357", 'CY', "el-CY,el;q=0.9,en;q=0.8"], ["358", 'FI', "fi-FI,fi;q=0.9,sv;q=0.8,en;q=0.7"], ["359", 'BG', "bg-BG,bg;q=0.9,en;q=0.8"], ["370", 'LT', "lt-LT,lt;q=0.9,en;q=0.8"], ["371", 'LV', "lv-LV,lv;q=0.9,en;q=0.8"], ["372", 'EE', "et-EE,et;q=0.9,en;q=0.8"], ["373", 'MD', "ro-MD,ro;q=0.9,ru;q=0.8,en;q=0.7"], ["374", 'AM', "hy-AM,hy;q=0.9,en;q=0.8"], ["375", 'BY', "be-BY,be;q=0.9,ru;q=0.8,en;q=0.7"], ["376", 'AD', "ca-AD,ca;q=0.9,es;q=0.8,en;q=0.7"], ["377", 'MC', "fr-MC,fr;q=0.9,en;q=0.8"], ["378", 'SM', "it-SM,it;q=0.9,en;q=0.8"], ["380", 'UA', "uk-UA,uk;q=0.9,ru;q=0.8,en;q=0.7"], ["420", 'CZ', "cs-CZ,cs;q=0.9,en;q=0.8"], ["421", 'SK', "sk-SK,sk;q=0.9,en;q=0.8"], ["423", 'LI', "de-LI,de;q=0.9,en;q=0.8"], ['20', 'EG', "ar-EG,ar;q=0.9,en;q=0.8"], ['27', 'ZA', "en-ZA,en;q=0.9"], ['30', 'GR', "el-GR,el;q=0.9,en;q=0.8"], ['31', 'NL', "nl-NL,nl;q=0.9,en;q=0.8"], ['32', 'BE', "nl-BE,nl;q=0.9,fr;q=0.8,en;q=0.7"], ['33', 'FR', "fr-FR,fr;q=0.9,en;q=0.8"], ['34', 'ES', "es-ES,es;q=0.9,en;q=0.8"], ['36', 'HU', "hu-HU,hu;q=0.9,en;q=0.8"], ['39', 'IT', "it-IT,it;q=0.9,en;q=0.8"], ['40', 'RO', "ro-RO,ro;q=0.9,en;q=0.8"], ['41', 'CH', "de-CH,de;q=0.9,fr;q=0.8,en;q=0.7"], ['43', 'AT', "de-AT,de;q=0.9,en;q=0.8"], ['44', 'GB', "en-GB,en;q=0.9"], ['45', 'DK', "da-DK,da;q=0.9,en;q=0.8"], ['46', 'SE', "sv-SE,sv;q=0.9,en;q=0.8"], ['47', 'NO', "nb-NO,nb;q=0.9,en;q=0.8"], ['48', 'PL', "pl-PL,pl;q=0.9,en;q=0.8"], ['49', 'DE', "de-DE,de;q=0.9,en;q=0.8"], ['51', 'PE', "es-PE,es;q=0.9,en;q=0.8"], ['52', 'MX', "es-MX,es;q=0.9,en;q=0.8"], ['53', 'CU', "es-CU,es;q=0.9"], ['54', 'AR', "es-AR,es;q=0.9,en;q=0.8"], ['55', 'BR', "pt-BR,pt;q=0.9,en;q=0.8"], ['56', 'CL', "es-CL,es;q=0.9,en;q=0.8"], ['57', 'CO', "es-CO,es;q=0.9,en;q=0.8"], ['58', 'VE', "es-VE,es;q=0.9,en;q=0.8"], ['60', 'MY', "ms-MY,ms;q=0.9,en;q=0.8"], ['61', 'AU', "en-AU,en;q=0.9"], ['62', 'ID', "id-ID,id;q=0.9,en;q=0.8"], ['63', 'PH', "en-PH,en;q=0.9,fil;q=0.8"], ['64', 'NZ', "en-NZ,en;q=0.9"], ['65', 'SG', "en-SG,en;q=0.9,zh;q=0.8"], ['66', 'TH', "th-TH,th;q=0.9,en;q=0.8"], ['81', 'JP', "ja-JP,ja;q=0.9,en;q=0.8"], ['82', 'KR', "ko-KR,ko;q=0.9,en;q=0.8"], ['84', 'VN', "vi-VN,vi;q=0.9,en;q=0.8"], ['86', 'CN', "zh-CN,zh;q=0.9,en;q=0.8"], ['90', 'TR', "tr-TR,tr;q=0.9,en;q=0.8"], ['91', 'IN', "hi-IN,hi;q=0.9,en;q=0.8"], ['92', 'PK', "ur-PK,ur;q=0.9,en;q=0.8"], ['93', 'AF', "ps-AF,ps;q=0.9,en;q=0.8"], ['94', 'LK', "si-LK,si;q=0.9,en;q=0.8"], ['95', 'MM', "my-MM,my;q=0.9,en;q=0.8"], ['98', 'IR', "fa-IR,fa;q=0.9,en;q=0.8"], ['1', 'US', "en-US,en;q=0.9"], ['7', 'RU', "ru-RU,ru;q=0.9,en;q=0.8"]],
  v2 = {};
v2.US = 0x12c, v2.TT = 0xf0, v2.JM = 0x12c, v2.DO = 0xf0, v2.BD = -360, v2.KH = -420, v2.LA = -420, v2.TG = 0x0, v2.BJ = -60, v2.GH = 0x0, v2.NG = -60, v2.CM = -60, v2.CD = -60, v2.KE = -180, v2.TZ = -180, v2.UG = -180, v2.ZM = -120, v2.ZW = -120, v2.MA = -60, v2.DZ = -60, v2.TN = -60, v2.LY = -120, v2.GM = 0x0, v2.SN = 0x0, v2.MR = 0x0, v2.ML = 0x0, v2.GN = 0x0, v2.CI = 0x0, v2.BF = 0x0, v2.NE = -60, v2.MU = -240, v2.LR = 0x0, v2.SL = 0x0, v2.TD = -60, v2.CF = -60, v2.CV = 0x3c, v2.ST = 0x0, v2.GQ = -60, v2.GA = -60, v2.CG = -60, v2.AO = -60, v2.GW = 0x0, v2.IO = -360, v2.AC = 0x0, v2.SC = -240, v2.SD = -120, v2.RW = -120, v2.ET = -180, v2.SO = -180, v2.DJ = -180, v2.BI = -120, v2.MZ = -120, v2.MG = -180, v2.RE = -240, v2.NA = -120, v2.MW = -120, v2.LS = -120, v2.BW = -120, v2.SZ = -120, v2.KM = -180, v2.SA = -180, v2.AE = -240, v2.BH = -180, v2.QA = -180, v2.OM = -240, v2.KW = -180, v2.IQ = -180, v2.SY = -180, v2.JO = -180, v2.LB = -120, v2.YE = -180, v2.PS = -120, v2.IL = -120, v2.TJ = -300, v2.TM = -300, v2.AZ = -240, v2.GE = -240, v2.KG = -360, v2.UZ = -300, v2.NP = -345, v2.BT = -360, v2.MM = -390, v2.TL = -540, v2.BN = -480, v2.TO = -780, v2.SB = -660, v2.VU = -660, v2.FJ = -720, v2.PW = -540, v2.BO = 0xf0, v2.GY = 0xf0, v2.EC = 0x12c, v2.GF = 0xb4, v2.PY = 0xf0, v2.MQ = 0xf0, v2.SR = 0xb4, v2.UY = 0xb4, v2.EG = -120, v2.ZA = -120, v2.GR = -120, v2.NL = -60, v2.BE = -60, v2.FR = -60, v2.ES = -60, v2.HU = -60, v2.IT = -60, v2.RO = -120, v2.CH = -60, v2.AT = -60, v2.GB = 0x0, v2.DK = -60, v2.SE = -60, v2.NO = -60, v2.PL = -60, v2.DE = -60, v2.PE = 0x12c, v2.MX = 0x168, v2.CU = 0xf0, v2.AR = 0xb4, v2.BR = 0xb4, v2.CL = 0xf0, v2.CO = 0x12c, v2.VE = 0xf0, v2.MY = -480, v2.AU = -600, v2.ID = -420, v2.PH = -480, v2.NZ = -720, v2.SG = -480, v2.TH = -420, v2.JP = -540, v2.KR = -540, v2.VN = -420, v2.CN = -480, v2.TR = -180, v2.IN = -330, v2.PK = -300, v2.AF = -270, v2.LK = -330, v2.IR = -210, v2.RU = -180, v2.BA = -60, v2.HR = -60, v2.SI = -60, v2.MK = -60, v2.RS = -60, v2.ME = -60, v2.XK = -60, v2.AL = -60, v2.MT = -60, v2.CY = -120, v2.FI = -120, v2.BG = -120, v2.LT = -120, v2.LV = -120, v2.EE = -120, v2.MD = -120, v2.AM = -240, v2.BY = -180, v2.AD = -60, v2.MC = -60, v2.SM = -60, v2.UA = -120, v2.CZ = -60, v2.SK = -60, v2.LI = -60;
function fn1() {
  const v218 = ['CMvZCa', 'uMr4sq', 'CgvYqW', 'BMuTtG', 'mtrFnW', 'C3LsCa', 'sw1TBW', 'AhfKDW', 'EK1nCG', 'seHXrq', 'z2fzza', 'mJyZ', 'zu11qW', 's053Ea', 'DNfPAG', 'AYCGDa', 'vg9Wyq', 'zxiGjW', 'yNP3Eq', 'zguTta', 's1v0DW', 'zxjU', 'BMrZia', 'AuHUvG', 'u0TZrq', 'rMnkDq', 'tYXWDa', 'Df91CG', 'Ahr0Ca', 'ywfOAW', 'lYbCxW', 'AKfTuW', 'vezrzG', 'ieXPyW', 'CMnzEa', 'ignVBG', 'DfznAG', 'ihWGia', 'twf0Da', 'yxrLuW', 'CKnVtW', 'Awq7ia', 'D0rABa', 'yw5Kzq', 'rujpBG', 'sw5ZDa', 'sMPoCa', 's2v5oG', 'AxmGyW', 'lxnPBq', 'C3rWEG', 'wuPbuW', 'vIXSDG', 'ys5JBW', 'Dw5Kia', 'vMH4ua', 'qMPgzW', 'rvPisa', 'ANvvzG', 'qNDVyq', 'rwDuvW', 'zu9IAG', 'uKLArq', 'v2LUza', 'D29YAW', 'mhWXmG', 'mteSnG', 'r2XV', 'sNDnuW', 'rMLkzW', 'ru5VqG', 'A2TrDa', 'zf9WCG', 'q2XHCG', 'oIboBW', 'qxztyG', 'sLHXBa', 'tvLOsa', 's1vrqW', 'tM8Sia', 'yxrLCG', 'ELfswq', 'mZaW', 'zw4Tsq', 'ufnOBG', 'shLeBW', 'lJaI', 'lwfKDG', 'Cvvtwa', 'shDpDW', 'CMzcBG', 'AfPfsG', 'CwjRAW', 'iezPBa', 'ELDotG', 'mg0k', 'zM9Yia', 'zNiTra', 'yNjVDa', 'BgXFAq', 'CYbpBG', 'BMDqDa', 'uK9ysq', 'sufMBq', 'AxjTyq', 'lJKSCG', 'DfbMva', 'werAAW', 'vMXRuG', 'DhH0', 'Evz6ta', 'uM1dDG', 'igjSBW', 'mtLfmG', 'mtm3lG', 'zxrUDq', 'CM0TDG', 'wLffAG', 'DMvFCa', 'CNvLkq', 'rennzW', 'vvP0BW', 'yurPDq', 'vhDUtG', 'EMnOva', 'AeXyAa', 'runu', 'zMKTrG', 'C2v0uW', 'BMHsyW', 'DwSTvq', 'Euf1AG', 'x2LUDa', 'xcTCkW', 'nJm4nq', 'wIXLBG', 'wuL0Ea', 'sePOAW', 'ieHuva', 'mJyY', 'odu2', 'Awq9mq', 'AhPUyW', 'B3L0BG', 'BwCTtq', 'u1bxDa', 'mtDFmG', 'A0jkvG', 'Cg10Cq', 'v1vxCG', 'wIX1EG', 'uursua', 't3bdBa', 'tcXLBG', 'EfLSCa', 'Efv2qq', 'svrNAG', 'vwHAzq', 'BMWTtG', 's2v5Ca', 'D2PUyW', 'yxrLia', 'EgLZDa', 'ChjVCa', 'EuLdBq', 'iJe1lG', 'u2H2va', 'BMWTqG', 'mtuUnG', 'vsXYDq', 'tKrpAW', 'ANH5za', '8j+tSsbnBW', 'EujTuG', 't2f2CG', 'B2XUDW', '4Pwq4Pwq4Pwq4PwD', 'Aw1LBW', 'ignSzq', 'AwnLlq', 'BKH2yq', 'mer0DW', 'BMf2Aq', 'mJeY', 'xsbwzq', 't2TUAG', 'FcaGia', 'B3HPzq', 'zw4TsG', 'Bwvtzq', 'AwqGsG', 'ywHpuq', 'ywnL', 'EMvUzq', 'nJC0ntC2ohPZzvrtzG', 'q2fyrq', 'nIiSia', 'EMvQDG', 'ihWGka', 'BMiTtG', 'xsdINjmG', 'xsbqyq', 'ihjLza', 'yMrvza', 'DuTRsq', 'nI1JBW', 'kefUza', 'C1Lgva', 'ANrZrW', 'uLnblq', 'BuLYuG', 'mtvFnq', 'BNb1Da', 'C1foyG', 'r2fYEq', 'zv9VzG', 'igHHCW', 'zgf5', 'mI4Zna', 'A1HgzW', 'odzp', 'BNrLCG', 'zw55ua', 'yxrHxq', 'vcXTDa', 'tsXLBG', 'CwPbuq', 'tu9csq', 'zw93uG', 'ifnPBa', 'vc1nBW', 'DgvxCG', 'y29YCW', 'tKDHBW', 'icaGgW', 'zw91Da', 'mtmSmq', 'mtqSnG', 'zxPYCq', 'zMTLBW', 'BgjJuG', 'u0TvtW', 'zNfAtq', 'BgvuyW', 'l2THza', 'zv9Zzq', 'Dxr4uW', 'ALzyCG', 'ExvJBW', 't2rtCa', 'q2zpuq', 'ltmPcG', 'tfbTva', 'Eg1SoW', 'BM90Aa', 'ntbDoG', 'uNrSvW', 'B3bLpq', 'DvzXsG', 'zgv0zq', 'yM1UDa', 'lunPBq', 'y0L4EG', 'zerusG', 'v1nfuG', 'AwzyCW', 'uYXZCG', 'mJy4', 'CNLuvG', 'Bg9Jyq', 'sxvwAa', 'BMTkzG', 'B24TBa', 'AwP1vW', 'r3L4rW', 'y2TVkq', 'vYXWDa', 'vKHPAW', 'mtuY', 'CNzPyW', 'quDMwa', 'mJy5', 'jNjLza', 'uKjisW', 'Bw5VCa', 'D0jtuW', 'Bv9Xzq', 'AMeTsG', 'otKY', 'w2jPCG', 'vgLsqG', 'tcXLCW', 'zw1L', 'scXHCG', 'BhrgtW', 'AM9PBG', 'mtGUmG', 'B2DSzq', 'u2TNqW', 'wfbJDG', 'zxi9ma', 'zcbMCG', 'wNfbBG', 'mJu2', 'vKu0vW', 'ntKZ', 'svfmzq', 'uhvfuq', 'qw92BG', 'qvDxBa', 'sLr2Dq', 'u19dsa', 'A3HUqq', 'DJG5AW', 'ru92rW', 'q1qGtG', 'C3nmzG', 'CwDSrG', 'mZG1', 'x251Bq', 'CefPEq', '8j+oSIbsyq', 'mZG3', 'qNn2BG', 'zfLWyW', 'mJiX', 'DJTXpq', 'B21PDq', 'zMXlCW', 'wMztrW', 'ihrOAq', 'vgTeBG', 'ifTKzq', 'Eurhwq', 'Dwvjsq', 'BNvTyG', 'rwjjCa', 'DgHVza', 'vhjPzW', 'zfjzDa', 'twf4ia', 'z3rlEq', 'vM1HrW', 'BMrVBq', 'Cgf0Aa', 'CNrHBa', 'sKzLrq', 'q3Dkwa', 'BhLdBW', 'mtqUoa', 'uMDOta', 's2vLrW', 'q1znrW', 'FcbLyW', 'y3vLqq', 'AgHwzG', 'DeTsCa', 'Awq6ia', 'A09XAW', 'ssblzq', 'uMv1CW', 'uLHoza', 'BMCGDa', 'CMv1CW', 'r2DxtG', 'EfzZBW', 'BNq9zG', 's2rWAW', 'zcbjva', 'y296Aa', 'vfDAwq', 'ssXZBa', 'CMvJDa', 'yNjHxW', 'ELrXzW', 'zs1WCG', 'DxLTza', 'ucuZqq', 'zMjFBW', 'ywrZ', 'weDnDW', 'zgvYAq', 'yxv0Aa', 's09ita', '8j+hUVcFH7GGrw4', 'Bu9MEG', 'zKHlCa', 'jNnOBW', 'wfPlsW', 'swPjuq', 'yw1Lpq', 'icHlsa', 'z3r2BG', 'ywjYyq', 'BsbtDa', 'shDesG', 'y3b1la', 'nIbcAq', 'u0HbmG', 'neLxvq', 'DgfNvW', 'zYbYzq', 'zxjYBW', 'ieLUDG', 'wu1fCa', 'zw5XDq', 'D29hEq', 'DcbYyq', 'A05KCa', 'ELnLDa', 'yw5Jzq', 'u2vZCW', 'CIbhmW', 'B3H5oG', 'EgXIEG', 'qw5fCa', 'mJq2', 'DhntEq', 'zu9Rza', 'CuLXDW', 'C2vY', 'jMv2zq', 'Ev09', 'ueHivW', 'yxiTqq', 'ieHxsq', 'w1nfva', '4Pwq4Pwq4Pwq4PwJ', 'ywLSyq', 'DermDW', 'whHlvG', 'r0nhDq', 'uhrwsa', 'q1DItW', 'ndiW', 'x0eGqG', 'r0HjsG', 'rurpvq', 'vvjdrq', 'vNrJDq', 'icaJia', 'CMq9', 'u0STvG', 'zMfSCW', 'idePlG', 'qKz6vq', 'Agr5Eq', 'sLjozW', 'yM1Nqq', 'wvLOCW', 'AgHVuq', 'BKDjzG', 'mZGW', 'DwfSAq', 'q1LdsW', 'qtPfqW', 'r3beDW', 'zxi6Ca', 'yMrYwG', 'DLDVta', 'zwn2wq', 'D3Lpva', 'mJfgnW', 'x3nLBG', 'ywnJzq', 'B2fHyW', 'jgrPCW', 'tLLxua', 'qLj0yG', 'rc9kyq', 'lxnLCW', 'DxG7ia', 'Ew49', 'Dg9tDa', 'mtGUnq', 'DMr0qq', 'zsbnyq', 'mdeYmW', 'ueD1rq', 'CM9VvG', 'iZaWrG', 'EhKGqq', 'ELbpvW', 'icbCxW', 'D1jSCq', 'DLPJBW', 'BwfW', 'Bwf4', 'qtiWlq', 'rgLmwa', 'CY1fuW', 'CgfYCW', 'BNrLzW', 'Aw9Uia', 'x2nTCW', 'BMuXmW', 'BuPNDW', 'mMCWmG', 'BgLLBG', 'se9nzW', 'rhL5CW', 'mtDFna', 't1bhuG', 'AwW7Cq', 'zNHHtq', 'uNvPvq', 'tfzsDW', 'te9syq', 'yxPhrq', 'rwfhwG', 's0HMtq', 'mZeYjG', 'BMzV', 'AwrLCG', 'whzHsW', 'tejnsW', 'wgHXCG', 'lcbYyq', 'wMXQBa', 'AwvZrG', 'C2uMCG', 'v21KuG', 'CvD6Ba', 'DxjLCG', 'zMLN', 'lxnJCG', 'DMfsqq', 'oe9vma', 'ienptq', 'tejcsq', 'CguGjW', 'z2LZDa', 'CMvZBW', 'A1Lhyq', 'kee7qG', 'D0zXvq', 'DxnLCG', 'zxqGzG', 'Aw5HBa', 'r0nRCa', 'kc4UlG', 'qxmZBW', 'oti4qG', 'yIKGlq', 'lwnVCG', 'mJaWlq', 'A20TsW', 'A290DG', 'wwD2va', 'Aw5LEG', 'Dgr4uG', 'y2vZtq', 'BMvKia', 's3jrta', 'zxnZAq', 'B3jRoG', 'AwncvG', 'rhP3rG', 'tuPRBG', 'qwvWsq', 'yKTpDa', 'zNiTuG', 'BxjUAa', 'ttPCuW', 'CNmGDW', 'weDdnW', 'rMfPBa', 'C0nprG', 'zMTWsW', 'C2HHmG', 'rMfZDa', 'qti1nG', 'z2f0zq', 'rxjPyW', 'BhrztG', 'y1nNwq', 'qK1Ata', 'BwfbsW', 'D2jsrq', 'CgfNzq', 'rMLYsa', 'Aw9Z', 'wxb2wG', 'wKTbva', 'DufJta', 'x2LTCa', 'rNv4CW', 'zxLtEq', 'ihjLyW', 'ALHQqW', 'DxLeyq', 'rwTRAG', 'yNbXsG', 'q293Bq', 'ruvTvq', 'wfH3rq', 'DwXSwq', 'AguGiW', 'EMvfDq', 'u3zhwa', 'wMTLva', 'C29YDa', 'otK2', 'suLYza', 'BxnoCG', 'sefdsa', 'C2LVBG', 'sKn0tG', 'mJfcnW', 'tsX0AW', 'pI9Kzq', 'FgnVDq', 'A1vQyG', 'sM9hwa', 'sKngsa', 'CMvZCW', 'u3L0Da', 'EuDOAq', 'lJvDoG', 'rxDmyW', 'zcbYyq', 'xYbCia', 'CuXRCG', 'ifjftq', 'Cvflza', 'sxDwEq', 'AwXLza', '4P6ug1SZ', 'rfjICW', 'yxiTra', 'mJu4', 'txfXyq', 'D1HAzG', 'BNrMjG', 'CMfUza', 'ALjPuW', 'CuXZzq', 'ntK3', 'g1SYsW', 's3rtBa', 'zwqGCW', 'q1Lhtq', 'ic5FxW', 'CNmGyq', 's2f2zq', 'CfzvtW', 'y0LHBq', 'wMTyDG', 'mJi2', 'DgrQyG', 'rwn4sG', 'EwPdDa', 'DxndBW', 'Ag8GiG', 'vvritW', 'B2qGmG', 'wZmVna', 'yvfksW', 'wxP6uG', 'idi6ia', 'rw50zq', 'tcXOzq', 'w2rLzG', 'D2L0Aa', 'twnMAq', 'DwfSBa', 'DNPJra', 'BgXHlW', 'zNLiqW', 'mtHFmG', 'mtuGka', 'Ec13DW', 'zwqGDa', 'zsbqyq', 'zwvKia', 'yv9HyW', 'rM91BG', 'AureAG', 'wMPRyG', 'sMvWCq', 'qu5drq', 'tcXZCq', 'wvLtvq', 'DwuPlG', 'mf06', 'iZu1nq', 'zMTxDG', 'ue1vua', 'wZmXBq', 'qsX1AW', 'v0LqqW', 'wwvZ', 'DNj4vW', 'ltfjDW', 'uIXMyq', 'B3j0zq', 'vhnTva', 'sxLLzq', 'o3y9iG', 'lw5LDa', 'te9fzq', 'zxiGyG', 'ALPREq', 'CcbdAa', 'lwH3Aq', 'lIbfEa', 'B29NBa', 'ug9JzG', 'CeTiEG', 'DguGCW', 'ze5fwG', 'nJGW', 'zxmTvq', 'BNqGyG', 'ievYCG', 'sxr2vG', 'DevOsq', 'B3jPzW', 'CwHyEq', 'EwvZ', 'lM5LEa', 'lcbKzq', 'icbqBa', 'ifrOCG', 'vw5Krq', 'uYXLCW', 'yw5PCW', 'CxDbtG', 'C2vZ', 'rMHABa', 'BM9FCa', 'DNrryG', 'lIbuyq', 'D3nLCG', 'EKPJsq', 'CIbttq', 'zMT4Ba', 'ywXSzq', 'zw4Tvq', 'DKHdvW', 'BIbVCG', 'yM4TqG', 'nJeZna', 've1mla', 'quHeqq', 'CePvqq', 'vMDNrq', 'EuLvrW', 'Dw4GBW', 'qsXHCG', 'AY1JBW', 'yufvDW', 'wKTcAW', 'Es91BG', 'ie1dmq', 'mtuX', 's0zjvq', 'mtGYmq', 'ChbZ', 'Aw1Lia', 'rvmGrG', 'CM9Wzq', 'wfvgtq', 'BNrFzG', 'yKLmtG', 'C25PAa', 'zgnzra', 'zcaOBG', 'qvjsCG', 'C2L6qq', 'Awq9', 'A0T6sW', 'tLD2qW', 'CMvKia', 'zvnVBW', 'CNCTuG', 'pvWNqW', 'DNHMsa', 'wMTZqW', 'wNnRuW', 'r1rorq', 'y2uTyG', 'B0LhEa', 'ywqGAW', 'A1LnCG', 'zsboBW', 'vvjYCq', 'nsaOnq', 'DxHWDG', 'BJy0oW', 'iK5VDa', 'Ae1VzG', 'DgvZDa', 'suXAta', 'CNrxCW', 'vgHVBq', 'uIXRBW', 'uersEG', 'tM8GBG', 'EuTesG', 'rxv2DG', 'Fhr5Ca', 'x18GxW', 's2DXva', 'Cgf5Ba', 'r0r0wa', 'zcbpva', 'B3iGAq', 'Ag9Uzq', 'BYbIyq', 'qxbWBa', 'yMfKia', 'wuTVCa', 'BMD0za', 'DI9UDq', 'zxLZoG', 'A2LSBa', 'DKz0Dq', 'DMvKia', 'u0HwEG', 'uu94qW', 'zePnrG', 'ntK0', 'DxrOzq', 'uvzeqG', 'zw5WvG', 'x2nSAq', 's0v4AG', 'C295sG', 'BNnLia', 'B25LxW', 'z2uVDW', 'vvHAsa', 'ihnLBG', 'ueXfva', 'swrdDW', 'qM1Mra', 'mtyYna', 'B2XK', 'jNjLzW', 'Bs9VAq', 'z2LUlW', 'rgLYzq', 'BIbWAq', 'Du1Nwq', 'sK1LEa', 'igrPCG', 'zM9BzG', 'x2zVCG', 'z2TRrG', 'oYbxAq', 'icbtsW', 'otG0na', 'qxvQDa', 'luC3mq', 'yxjRzq', 'mtC2lG', 'D0H6sq', 'rcbiqq', 'oIbnzq', 'ihnLCG', 'DLDoyG', 'r21UDq', 'yuvOtG', 'Au9szG', 'zNiTsW', 'Dg1SkW', 'jYb0BW', 're9cia', 'yMfUza', 'zxiGCG', 'ntKY', 'C3eTqq', 'mcbnua', 'BMv3xW', 'wvzxCW', 'zw50CG', 'y29UCW', 'xsboDq', 'BLnVra', 'Cwfcua', 'zwDYBW', 'wLjODW', 'Bunssq', 'BerVrG', 'q015qG', 'vwX0CG', 'Aw50zq', 'ueHptG', 'rwDzyW', 'CMv5', 'qurPrG', 'v0X2ua', 'zNjVBq', 'C3DPDa', 'nty6va', 'y2LeBa', 'v0v0BG', 'sKjqvW', 'ifnLCG', 'wfryCa', 'rfjgCa', 'ywqGtq', '8j+tUcbjBG', 'Dd0LmG', 'zLbKuG', 'v0rKBW', 'AgL0ia', 'uuzysW', 'yw0Gia', 'BL9OBW', 'wNr5qG', 'zcbMBW', 'yvDwCa', 'BIbMyq', 'zeLMzq', 'BxbLCG', 'ChPvEG', 'j0Hlta', 'rsXKzq', 'sLDLvW', 'lwjVBW', 'wNfNqq', 'v1zgtG', 'CNPeyG', '4PQHie1L', 'wgPptG', 'zg9I', 'zMfTAq', 'lNr4Da', 'z0zvBG', 'lYO7Cq', 'vMfsCa', 'CuXxDq', 'zMLUzq', 'jMzPCG', 'cIaG4PYx', 'wu5Vra', 'zwDPCW', 'BJTXpq', 's1rPuW', 'Ag92qq', 'Agv6sW', 'u29Pqq', 'u0eTqq', 'rw5SDG', 'BKHrqG', 'BgX5', 'vLnmvG', 'AxjLza', 'y1veyq', 'u2L1Bq', 'icHfCG', 'yxiTsG', 'EsbHCa', 'yur2uW', 'teLLDW', 'D1bqBW', 'zNvjBG', 'veHnqG', 'EdOGBG', 'Aw5MBa', 'CMf5', 'DKLusq', 'nxWWFa', 'ucaO', 'AxLHrW', 'CNr5ia', 'rMXeBa', 'u0TjtG', 'BgPUuG', 'DxbpvW', 'B2XVCG', 'Cwjirq', 'ufjZwG', 'sMziza', 'CeH5rG', 'idi2mq', 'B19Tyq', 'y3jLza', 'zujZra', 'jMrLDG', 'wLzjBa', 'C0rMsa', 'rxjYBW', 'vcbovq', 'uMT3wG', 're9OCG', 'CgfKuW', 'CNnPBW', 'mJm3', 'CuPHwG', 'C3rHBq', 'y2HHAq', 'ENLJtW', 'CMfUzW', 't0zTBq', 'DxncDa', 'uYXLBG', 'sLzSBa', 'Ewv4yG', 'rYbtrq', 'zMTzAa', 'zwq6ia', 'icHezq', 'zuLWAG', 'l2H0Bq', 'sMfTzq', '8j+tSsbbDq', 'psz3yq', 'vwDWtG', 'icGJmq', 'wuf4ua', 'B21Tyq', 'igjHBa', 'CMv0Dq', 'A3fLtq', 'mJy3', 's29sra', 'DgvFCG', 'qLbYqq', 'ienVDq', 't3PyqG', 'ie1dmG', 'l2v0yW', 'jMLZzG', 'zwXkBG', 'B3C9BG', 'vLPhAa', 'EcdIMQe', 'ExDNqW', 'twfRzq', 'ntKX', 'qvjhrq', 'tvvcsG', 'mtvFmq', 'ucb3Aa', 'zNi7Cq', 'oc1tsa', 'mJyW', 'AgLAuG', 'yw9Mwq', 'icHcyq', 'zMfSBa', 'kfDPBG', 'mJuY', 'q0TAzW', 'rYXTzW', 'BwSTtq', 'zw49jG', 'u3HltW', 'jL9FAa', 'tsXTEq', 'vKnwuG', 'q3bXtG', 'veLIyq', 'EgHKAW', 'y3viAa', 'teLdia', 'x3jLBG', 'tefRsa', 'EsbMCG', 'wuLozW', 'teLYqq', 'AKvgAa', 'mZvLD2HOq3a', 'rgfUAq', 'y3nPpq', 'yvnNsq', 'uMLJAa', 'DMjbAG', 'v1bguW', 'Dgviyq', 'BMfSAq', 'wfDgEq', 'AxzcCW', 'BcXHCa', 'zwn0', 's1fjBW', 'tfzyva', 'oc4XmG', 'C1Lbrq', 'mtqUnG', 'tw5qsq', 'mxHVmG', 'rLDjCq', 'vgf5Ba', 'wNrUyq', 'D1DjsG', 'CIbAzq', 'CNnVBG', 'BwnPvG', 'zu91Ba', 'DhKV', 'Agvlwq', 'vMH3wG', 'otC0', 'tJbzBq', 'CIbhmG', 'lcbICG', 'tg9mDW', 'z2X0zG', 'x2rPCW', 'A0nxCa', 'quLuxW', 'u1bPua', 'zwfHtG', 'mZGY', 'DK1pDa', 'tgjfyG', 'CYbVCG', 'ywXZzq', 'r3vxCa', 'B2T5Aa', 'CNmTyW', 'CwjNwa', 'zuXivW', 'Be1bvW', 'vJCUma', 'BuDwra', 'tg9kza', 'C3CTva', 'ic1fCG', 'BuDQyW', 'jMrHDa', 'vhLWzq', 'tIX2Aq', 'BLDsvq', 'BwfPBG', 'DMKTvG', 'BLLYrq', 'v3HVzW', 'AdTXpq', 'CMDLDa', 'rg9yzq', 'v3DJCG', 'FgrVyG', 'yMrMBW', 'z2v0BG', 'Aw9U', 'wMLezq', '4Pwq4Pwq4Pwx', 'B21Lia', 'yxv0BW', 't19tuW', 'lJaU', '4Psa4Psa4Psa4Psy', 'tK9Fqq', 'B3Lkta', 'vgjVzG', 'mtqSmq', 'De9ryW', 'y3qGCG', 'iokUNIbB', 'C3yTuW', 'BKrLyG', 'AvLKwq', 'As9JAa', 'twfgBa', 'mNW2Fa', 'wZeVna', 'AYWKBq', 'qwXPDG', 'CNnOzq', 'FhbHCW', 'ptmZjG', 'EMvYBW', 'ig1HBG', 'zKTkrG', 'oIbcyq', 't3jOyW', 'DM9SDa', 'AeXfvG', 's0T2zq', 'A2vUCW', 't1zcDa', 'C0fjsG', 'BYbPBG', 'zKj3Bq', 'v2Tgrq', 'Bhjhtq', 'vhvOra', 'BwDXva', 'ncbcAq', 'C3nMDq', 't1rArW', 'CKfJDa', 'otK0', 'vwz4ta', 's0POEa', 'B250yq', 'CMvZDq', 'yxjNDG', 'AwXLlW', 'uM1rAG', 'qwvLrG', 'BMqGAq', 'qwTkva', 'BhH0Cq', 'mZC3', 'ndu2nW', 'ywn0xW', 'ocWXmq', 'jMPHEG', 'tvHNAq', 'tumXmG', 's2LTmW', 'zxnOia', 'wevJBa', 'zKTzCa', 'lI4Ukq', 'B3rOzq', 'rsXLCW', 's0Dowa', 'zw1HAq', 'B2zFyG', 'k01LDa', 'AgTHCa', 't0zZyW', 'BwfWAq', 'rZb6sW', 'y1rbvG', 'ierPBq', 'C2v0uG', 'mtLimq', 'BKX4sW', 'DKf3mG', 'tffjuG', 'AYC6', 'mtyUmq', 'C3rVBq', 'sKXgyq', 'igHPDa', 'm29VmG', 'quLyDG', 'B1CZCq', 'tLHYqG', 'uLnZzW', '4PYp77Ipicbf', 'DKvNuG', 'DMf5zq', 'zhDPqW', 'sgHwsq', 'igLUDG', 'DhKGnG', 'v2jXAq', 'C21ZyG', 'Dhj1zq', 'ifnnuW', 'Aenysq', 'CM4GDa', 'x2LKpq', 'uMXMEq', 'mJmX', 'vLHtyG', 'zsWGyG', 'D29Yza', 'Dxjiqq', 'u3rKsq', 'BMqTBG', 'rhrRAG', 't2Lxsa', 'tfrYyG', 'Bwf4uW', 'zwrFyq', 'vMTgEq', 'DgHLCG', 'sKD3sG', 'DMTtrG', 'CNzbyG', 'rvHdrq', 'B3aG4OAs', 'rLjmuG', 'v3fnqq', 'vufuwq', 'DerOtG', 'Cg9mqG', 'yxbfwG', 'B3iTza', 'wMXSrG', 'CLvfEa', 'q3HKmW', 'Bca4ia', 'CLzxCG', 'zwjlAq', 'y2C9rq', 'CxDZua', 'mtrFma', 'zK5UCa', 'AwfTCW', 'Dg8Gzq', 'zgvYia', 'uKvwtG', 'rsXZDG', 'r2fYyW', 'EMXPyG', 'ntK2', 'qLruza', 'vK9KtG', 'y2vFCW', 'lsb1CW', 'B3CGDa', 'CKv3Eq', 'vwDuuG', 'zxmTqG', 'vcXWDa', 'BIbMAq', 'D3D3lG', 'x25HBq', 'AezxrG', 'tI9bia', 'zsbPDa', 'vufJyG', 'shnhEq', 'z1nlDG', 'rNfWtG', 'ifbYBW', 'yJ10CG', 'AwPHwa', 'AgL0CW', '8j+tMezcka', 'tLzmsG', 'igzPBa', 'ieHLBa', 'zNiTtG', 'iejHyW', 'jMzIxW', 'Dxz3Ea', 'reTdBW', 'thfRBW', 'ywnOAq', 'DhCYrq', 'jL9FCW', 'mJy0', 'vhHQta', 'B3rxrW', 'DNnSyW', 'ucXQyq', 'x198xW', 'Fdv8mG', 'mLP3CG', 'zwzHDq', 'BhqTBq', 'j19FFa', 'wsXHCG', 'veP1wa', 'AKPfAG', 'zwqGBW', 'D1b0BG', 'ienVBG', 'C3rFBG', 'zxi9', 'ndvywa', 'ndy2', 'iJT2pq', 'v1reAa', 'sgvYBG', 'y2f0yW', 'C2LTtW', 'BcbKzq', 'EMnzwG', 's0Pkua', 'zNHYsa', 'DNDnzW', 'ueXWBq', 'z0LyzW', 'CuvlDW', 'BfnJDG', 'EhHyuW', 'weTPva', 'lMnVBq', 't0ngCW', 'zxi7ia', 'C2vAqq', 'twLJAa', 'zw50ia', 'rLHlra', 'uKzOAq', 'twLJCG', 'AvbOBW', 'Dc1HDG', 'BMuXmG', '4PYtifrH', 'BxqTtq', 'EfbwyW', 'q25buG', 'BxPUBG', 'mtrFoa', 'jMfJyW', 'ExPbqG', 'ts1tsa', 'B2DpzW', 'Ev9WBW', 'zwn0Aq', 'B25hrq', 'yxiTwq', 'sM5TBW', 'uKrxqq', 'C29U', 'yNL0zq', 'DMfPBa', 'nK8XrG', 'vtDqyW', 'x2fWCa', 'Cvburq', 'Bg9JAW', 'lJaUma', 'zMTvsG', 'tMvorq', 'C2WTuW', 'yMfJAW', 'B3bWzq', 'BYbUDq', 'iePttW', 'zw5LCG', 'sIX0zW', 'r2n6wa', 'zwzHyq', 'icH0Eq', 'y2uGvW', 'cIaGrq', '4OYO77Ipicbd', 'rMDgsG', 'y2fAva', 's1nSsa', 'vfn0sG', 'q1qGuG', 'zw5KCW', 'Chj4Da', 'qwDLBG', 'zc4BwW', 'zvfbCa', 'AgvKqq', 'icHFkq', 'C3rVCa', 'zM1ivW', 'luvora', 'DwLUzG', 'CwjguG', 'igTLEq', 'zxiGmW', 'DuPmua', 'sIXMCG', 'Ctbyvq', 'zxmTra', 'qMzfyG', 'zxvxDq', 'mJqZ', 'mtmWnq', 'DMvYCW', 'AhCYsa', 'rhPkCa', 'mtCUnG', 'D0zhCW', '4PQHifPL', 'igfUBW', 'wKznCW', 'zxHPDa', 'CxjJqq', 'A1jSua', 'C0zsuq', 'r0DqCa', 'rLLTEa', 'luC2mq', 'CgHVBG', 'y3nNBq', 'ierpqG', 'ChjVzG', 'qsXLBG', 'DgHLia', 'r2Xfzq', 't2PLrW', 'jL9FAG', 'rcXPza', 'wZmZBq', 'yxWYlG', 'y2fSBa', 'ExjJDG', 'CKfbDW', 'AhKTqq', 'mtuYmG', 'ihWGFa', 'Eg91Da', 'C29Szq', 'DevUBG', 'BfzQrq', 'CNuTuG', 'Ag9Tzq', 'D2PfAa', 'y1PUsq', 'wfPQzW', 'zgDmDa', 'uIXUBa', 'icbsyq', 'icHxAq', 'EMfWuG', 'swnXzq', 'DMvUDa', 'zurRtq', 'CMHQrq', 'y2vFBW', 'uhjVyW', 'svj2zW', 'AMXsDa', 'A25rAW', 'zwfKia', 'zxiGza', 'tevFnq', 'uKPuEG', 'ruDjuW', 'shrrua', 'yw51zG', 'qvnNyq', 'zxmTua', 'D1n0zq', 'Bca4', 'uhjVEa', 'y3qTtW', 'tKTxrq', 'ns4Wia', 'sePltq', 'serPrG', 'vLzsDG', 'mJm5', 'mZGZ', 'suvZBq', 'Bgf5tG', 'z2LU', 'icaG', 'xsbqCG', 'mJqUna', 'x2nVza', 'u05btG', 'zw50zq', 'AxH3', 'ze9uua', 'DeLAra', 'B0Tovq', 'mKmXrG', 'twfJAa', 'DKvnCq', 'uK5HBW', 'B1TYzq', 'rJG4', 'v2HosG', 'AtbXnG', 'Bencqq', 'qYXLBG', 'Dg9juW', 'EM9Yra', 'BfvPqG', 'txf4wq', 'Cwz1AG', 'q2LWqW', 'ChqTqW', 'BeruuW', 'C29Tzq', 'mtyZ', 'EsbLCG', 'ihvZzq', 'sKnIAq', 'B1ruEa', 'sMv6sq', 'BIbtAq', 'q2nWuW', 'sfjfqq', 'z2fbqq', 'cLTtrq', 'CxDlBa', 'ntu1', 'Ecb0Aq', 'Bhr6wq', 'Axn0', 'AMveDG', 'BMnVBG', 's3PAsq', 't3fdqG', 'ihWG', 'vfvqxq', 'zLf1yG', 'AgfZ', 'xsbzBW', 'rKDrBa', 'AY1KBW', 'jtjgyq', 'Aw5NCW', 'BK1sua', 'Dg8MCG', 'ie51Bq', 'nJC4', 'zNHmAG', 'Ehrqva', 'uxrfBa', 'qwPPBq', 'D3rYzW', 'rhz4EG', 'C2uMBa', 'C2vJDq', 'y2vuEa', 'otCZ', 'DvPezG', 'DcaTrG', 'rvbrta', 'wfrvEq', 'C1vSCW', 'BMDPzG', 'z2v0ua', 'CZTXpq', 'CwfWva', 'mZC1', 'qxn5sq', 'zunjta', 'CMuP', 'iIWGiG', 't1vfva', 'EsKGwW', 'DhK9', 'nJr1CG', 'CuzryW', 'D0fKwq', 'qvP0sG', 'ne5tta', 'ls0ktq', 'D1jXwG', 'EundDa', 'B3jPEG', 's1rHvG', 'EKXfAq', 'B21cEq', 'AwnLxW', 'D29fCW', 'thvwDq', 'C0H6Aa', 'yMXdCG', 'qKfgCW', 'lxPblq', 'EgXSvW', 'BvPZDa', 'C3nFDa', 'ywDYyq', 'B21vvq', 'DgLTzq', 'wgf5vW', 'Bsbttq', 'CxDjEG', 'vw1ZDW', 'xYXFFa', 'shrItq', 'Dg9Rzq', 'A21bvq', 'mMuWtq', 'AhLfAq', 'sej0rW', 'uIXLBa', 'tfP3rW', 'icDIyq', 'Dw50ia', 'ie5LDa', 'v0LpqG', 'zsaODa', 'zxjFDa', 'wgfIBa', 'txvODG', 'wvzVsG', 'ruzUzq', 'u291CG', 'iezPCG', 'vu1crq', 'BxDSrq', 'AwXL', 'CMLJzq', 'ywTHCW', 'DxnLqW', 'AY4UlG', 'yxbWBa', 'qwPlAa', 'C2rAwq', 'AxndAa', 'vgLTBW', 'DffYEq', 'D2f0zq', 'jL9FCG', 'y3LHBG', 'vvvhqq', 'zNiTva', 'mJjenG', 'EMDWsG', 'oty2', 'sKXwEa', 'zhPHqG', 'oLWNjW', 'CMqGlq', 'ssXKzq', 'y0XLzq', 'zejksa', 'z1P1qG', 'y0rYBa', 'icdILia', 'Bff4BG', 'BuvLqG', 'otCW', 'A3rNyW', 'zxrOBW', 'qMHjCa', 'D2LKDa', 'zuX0wG', 'zwnRlq', 'AgLUzq', 'mtGUmW', 'y2TZlq', 'DNvMBW', 'seuTrq', 'mwT1rq', 'zvnLBG', 'Dtb0qW', 'EMnOzq', 'q1qGva', 'CgjqyW', 'qLL0Ba', 'zwn0kq', 'zMLNDq', 'B3jRuq', 'ienYzq', 'zgvZDa', 'CgvYyq', 'tw96Aq', 'zxrJAa', 'CfjqvG', 'CgWTua', 'y2nVDq', 'BIaGia', 'zxqP', 's3Lktq', 'C2rPyW', 'rZn5ma', 'AxDdyq', 'r28Gsa', 'zKzurG', 'vwn4yG', 'zgf0zq', 'sxfnyq', 'C3vIBq', 'DhiTva', 'ANLlAq', 'mtLgnW', 'CMvXDq', 'A2PsDG', 'otu5', 'C3mVqa', 's05frW', 'ANHKqq', 'Bev5zG', 'yuziCq', 'Axq9zG', 'EufOvq', 'DhLWzq', 'uwDxta', 'lI4k', 'otyZntrkv1fZBvu', 'mtK6ua', 'DK12sa', 'mZC0', 'mJiZ', 'tuXArW', 'Es1HzW', 'AwfSBG', 'r1rHtG', 'v2vzAa', 'CKHWyq', 'DhjHyW', 'wcKGBW', 'q09JEG', 'DgvKxW', 'wfHykq', 'y3nY', 'rKneAW', 'tfnZDq', 'CM8TuG', 'rxjTEq', 'ndiX', 'qxfiua', 'rsXUBa', 'AhrXwa', 'A3Pgwa', 'vvrRuq', 'vfjbva', 'Aw9UlW', 'AhnKCa', 'y015vG', 'ANvYAq', 'l3bSyq', 'C29bua', 'C1bZvG', 'C2LUzW', 'vMv6ua', 'r1HYAG', 'zwDFBG', 'ie1VyG', 'g1SYsG', 'v1f5yW', 'zujVyq', 'Dwnyza', '8j+uPsbbDq', 'BgXSDq', 'iokaLca1', 'txvtua', 'CMXvBW', 'sK9qCW', 'thjlva', 'tIXHCG', 'r2LyqW', 'BunKrq', 'mJq3', 'q2LTsq', 'zuLmAW', 'uw1xEq', 'Df9HDq', 'EfbjDW', 'BwLU', 'BxHmEa', 'txDvzq', 'CeDfCW', 'DhbVta', 'rIXWCW', 'zw5JCG', 'CM90yq', 'DwWUDa', 'BNPWAW', 'uMvSyq', 'nta1', 'txv0yq', 'igXLyq', 'ywDdDq', 'ru16BW', 'u0XIvG', 'mZa1xW', 'B0n4CW', 'w2HHCW', 'mtq4', 'vsXODq', 'rgnutq', 'yxrLxW', 'xsdINjCG', 't1fswa', 'D3bLCa', 'ifnJyq', 'twveBG', 'B3iGDa', 'mJuW', 'uMnjAq', 'AfH3Ba', 'ywXSia', 'nhWXmq', 'BhKP', 'CMLJDa', 'seXJCW', 'zNiTrG', 'weDmyW', 'mL9qCG', 'idiGnq', 'Dxb0Aq', 'vfHJDG', 'CwXptW', 'BLjHAG', 'iefqsq', 'DgGTva', 'CMqTmq', 'zKfzEG', 'yvHLCG', 'qsuYrG', 'DcaMia', 'z1Hbzq', 'zxj4tq', 'uwLlsG', 'vJiZmG', 'lw9Mlq', 'B3nVzG', 'EenjyG', 'EhKUlG', 'luHbuG', 'A3v4rW', 'xhWGFa', 'mIaOna', 'yurrDG', 'ANjkqq', 'DgHYzq', 'ChjVyW', 'AePeDW', 'q3PMva', 's2LYAq', 'ExPmua', 'C29Jtq', 'mJq4', 'zY4UlG', 'ucbSAq', 'DxjYzq', 'zw50lq', 'DLzXBq', 'C2LN', 'mJm2', 'ls0Tlq', 'AgDzAq', 'Dw50xW', 'sfroAW', 'Fg1LDa', 'ntyWtq', 'vw1stq', 'DwzOwG', 'AKjrvq', 'tYXYBW', 'AxzYtq', 'z3bJ', 'zw4TwG', 'DuTQAW', 'zs9HCa', 'v1jItq', 'y2vZCW', 'l3rUzq', 'BvPhyG', 'Bs9HCa', 'iJi0iG', 'yw1PBa', 'rhrora', 'sg93ia', 'BwCSja', 'D0rYDa', 'mtHFma', 'CNvQwG', 'vwH3wG', 'uu9dva', 'A28TsW', 'tMfnBa', 'ihzHBa', 'q29Kzq', 'y291BG', 'lw9YAq', 'CIbMDq', '8j+tIIbtAa', 'B3rWCW', 'l3yXlW', 'yMvYia', 'B3zcEa', 'Bu1xDW', 'uK9sCW', 'mtG3nG', 'B0HPAa', 'ntu0nW', 'uMLhDq', 'B25FAG', 'jMnHyq', 'zxnZpW', 'uMfRuW', 'jM5HBq', 'zsaO', 'ntGX', 'u2f2zq', 'sunMvG', 's2v5ia', 'reHflq', 'A0PRCq', 'yMLKpq', 'u1rvvG', 'q0T3BW', 'rvrjtq', 'A0nNzG', 'zM91BG', 'tLPMua', 'B0nVBG', 'rvbjua', 'Bs9SBW', 'thr0Eq', 'y29UBG', 'qMjJtq', 'ksdIHPiG', 'vvPhsa', 'lxnHDG', 'Bg9NAq', 'whrRzq', 'qK1etq', 'zY4k', 'reDyCG', 'x3zLCG', 'EgvTta', 'Df90Aq', 'zvnNyq', 'yMjnCG', 'C2v0Da', 'BM5Lza', 'rcXIBG', 'C3rHCG', 'icGXma', 'oIbnAq', 't0HwwG', 'vfP4wq', 'q1qGqG', 'zgmVpW', 'qIXLBG', 'Aw8GrW', 'yw1gqq', 'CfrbBG', 'ideSmW', 'wNP6Eq', 'C3eTwa', 'AhvfDa', 'qNLWyq', 'suj1Aa', 'A2fHyq', 'AMvODW', 'swHvBG', 'x3n1Bq', 'rfDgsG', 'ihG2na', 'tNPwAW', 'BhjVqq', 'yxzPzG', 'nJCW', 'CKnIBa', 'CwWTCG', 'BKv5CW', 'BMqTzW', 'DgfSBa', 'Dgf0Dq', 'icHtDa', 'uefosG', 'C2vYiq', 'wxbYyq', 'CcaRia', 's1LozG', 'CNLWDa', 'BxKTtq', 'zhbY', 'zxqGyW', 'vg9Pyq', 'iefIBW', 'qundrq', 'rMXLzG', 'mJmW', 'Eu1ZDG', 'Aw5JBa', 'BM93', 'ide6ia', 'A3jYDq', 'ANjusa', 'CvLUzG', 'DgvYzG', 'wL8Kxq', 'lM1LDa', 'A2v5pq', 'DfbbsW', 'wwreyG', 'zw5K', 'Exb0zq', 'tfbRAq', 'EwXMzq', 'mJqUma', 'A3PZDq', 'qMXPBG', 'zxmTtq', 'x2LUzG', 'qKXbqW', 'wgrAwG', 'mJC5mtq4rwXNwKXV', 'AhCYBG', 'yxOTqq', 'DcaOCa', 'rw9hDG', 't1f2sG', 'yxnLza', 'zhOTqG', 'icaVia', 'oIbjBG', 'AKDYzG', 'ExbLpq', 't1PqAa', 'CNfAvq', 'EhnQwG', 'zu5uqG', 'rxD4AG', 'zfLnDG', 'z3jHCa', 'wMvUzq', 's3PHsq', 'v2jyDq', 'v1DSzq', 'zu9gBG', 'yKTevG', 'zMvWza', 'ChvYva', 'swLMBq', 'rs1jra', 'zKXTBq', 'thfIzW', 'zwnRia', 'wvj3tq', 'C3r4yW', 'tu1hDW', 'zMLYBq', 'mtvFnG', 'q1bwrW', 'C3qGzq', 'BvbSAq', 'lxjLCW', 'yw9qzW', 'DKDIrG', 'mtq3', 'sgDXvW', 'ELzfua', 'ndPuta', 'mtHbmW', 'D2DIva', 't04GCG', 'ucbJBW', 'ELrVvq', 'v3zYEq', 'x2f2yq', 'zw5JAq', 'ser6rW', 'yxiTsW', 'r0HetG', 'xsbuzq', 'quvtxW', 'teHqzG', 'v2LUmW', 'qYXLCW', 'uK9xuW', 'tvro', 'uKTiuG', 'zuvQDa', 'uLLPva', 'AvbHza', 'rgXXqW', 'C0jtsW', 'zxi/', 'tNbYuq', 'CIbPBG', 'CM94Eq', 'Bw9UDa', 'ptaUnW', 'Aw5FDa', 'CM1PDa', 'ywXeAq', 'ELnIsW', 'wNL1sG', 'BgP5za', 'BxzOzW', 'qMnhAG', 'zgvSzq', 'l3bPBG', 'EMf1tq', 'tvvJwG', 'CNvjyG', 'y2SNia', 'ntm3lG', 'BgjnrG', 'uhzfsG', 'CMvNsq', 'ChbfuW', 'whLUwG', 'Aw4ZmG', 'yxL5qG', 'mM0G', 'g1Ti', 'CMf0BW', 't2fAAq', 'r2vdDW', 'B0fYza', 'zxjfBG', 'yxvSDa', 'nI5iwq', 'zYbbyW', 'psaOrW', 'zsaTqW', 'B3DzzG', 'AwTLia', 'zwL2zq', 'B0LPsa', 'Dg9FzG', 'su5hia', 'CgnJsG', 'D0nouq', 'z0PbAa', 'CgKPoG', 'nteYoq', 'yxiTsq', 'x2vUyW', 'icOOpW', 'Ae9ftq', 'C291CG', 'rNPJrq', 'B1Lpta', 'ChjVzW', 'zv9ZDa', 'BwuMzq', 'CM5LDa', 'uMrwqG', 'zwDgyG', 'qw5Kzq', 'ieDLBG', 'q21ovW', 'qMfUza', 'sKnQtW', 'CvDtDa', 'BfLTvq', 'uMvruG', 'Bwf4vq', 'nty6rq', 'CMvHyW', 'v1j5AW', 's0vzlq', 'zwqGCa', 'AhjVBq', 'D0nKtq', 'EunVBG', 'svrTBG', 'DKfUwa', 'x191CW', 'DgvY', 'lw9Wzq', 'DgH5', 'ugL4zq', 'BhDKEq', 'ysaGia', 'w0vsuG', 'B21LlW', 'yxnZDW', 'r0vu', 'DgvJDa', 'Au9tia', 'tLnHvW', 'DcaO', 'igjHyW', 'CIaOCa', 'BKDJEq', 'sMfZBW', 'uLn2AW', 'wfn0tW', 'nNWXmq', 'tYXZBW', 'B24G', 'tK1Jtq', 'seHXDW', 'uYbgsq', 'Aw9Ulq', 'odKHqa', 'whLsuG', 'v2L0Aa', 'sw52yq', 'wvjKqq', 'zMrTqq', 'nxWZFa', 'BwXtsa', 'r25IAW', 'CvfUza', 'lgLTyq', 'pszNBW', 'BIbpva', 'ihnHDG', 'm1jlqW', 'jNfWBa', 'z3LLDG', 'thDLsG', 't0LeCG', 'yuvAqG', 'C25nsq', 'BgvUDa', 'mtGWoq', 'Aw5PDa', 'u3viDq', 'DhKGzG', 'mJbena', 'BNrNAW', 'Cc9Zzq', 'zhPZsq', 'jg1Nia', 'u2PMDG', 'wK5bBW', 'A01MqG', 'DNbjwG', 'y2XPzq', 'CM1HDa', 'DMvIsa', 'wgLfCq', 'CM9Tia', 'u3jxsa', 'AxLJta', 'yMvYCW', 'mJmXmG', 'tsbHCG', 'BgfZDa', 'Be1wsW', 'igj5ia', 'zYbSBW', 'DgL2zq', 'qKTNtG', 'z2v0uW', 'BMXVyq', 'BNrYEq', 'sg1mDq', 'BMv4', 'DhbTzq', 'ywn0Dq', 'mJyWnZy5ovLesfPtyG', 'zcbRzq', 'ug9zDG', 'DMXlBG', 'mhz3vq', 'Axn0CG', 'BMCUia', 'ChrOvG', 'mf9Ymq', 'vwLRCW', 'B2fKuG', 'sgvNvq', 's1PKsG', 'uKDutq', 'vNnUqG', 'y2uUyW', 'u0vmrq', 'nsbcAq', 'zxmPia', 'r2TeuG', 'zKnhBG', 'tcXUBa', 'tg9NAq', 'DMHICG', 'BNrPBG', 'Exn1rq', 'rhL4rq', 'uNLHBG', 'q2D0tW', 's0jjCq', 'ze9TqW', 'CgLLza', 'v2Tvsq', 'keXPBG', 'wIXZDW', 'ruqGlW', 'wLb2ua', 'y3jHCa', 'icDFia', 'ufDuzW', 'C29SDq', 'vLbdrW', 'ns4XlG', 'Cw1xCG', 'q1jUuG', 've5vqG', 'q0nXtG', 't1zfra', 'u0LPwq', 'mdLXAq', 'DgG9', 'ncaOna', 'otyY', 'uxrWDW', 'rMLSzq', 'rhfbvW', 'ue9mwq', 'qK1cDa', 'yMfUBG', 'AxjLyW', 'Cu9Zza', 'psiXna', 'u09o', 'D2vYia', 'C3iTuG', 'rNHHvG', 'psbHBG', 't1bFtG', 'vuX1AG', 'qsXSBW', 'ns4Xoa', 'mJe2', 'oKeTqG', 'BuDetG', 'ks4Gqq', 'uLP1ta', 'uwL5EG', 'C2nYAa', 'x3bYBW', 'EM9LCW', 'Dc1Pza', 'q2HYBW', 'y1bhvW', 'AxjpqG', 'DgvUyq', 'sLjRyW', 'zxnZzG', 'yxiTtq', 'seeZoa', 'ywDLBG', 'BLvWtG', 'mJuX', 'uNDqyG', 'B3n0lG', 'rKDWBG', 'sw5sDW', 'Dg0Mza', 'B3H5ia', 'xYbFxW', 'BwXQCW', 'v2PpEG', 'y3rFCa', 'qNHzuq', 'zKHIsW', 'B25ZBW', 'AhKNia', 'tfvkwG', 'tgfHvW', 't3HXzG', 'v2TUvW', 'uNz2Eq', 'DfvNyq', 'Au9RAq', 'zxrHia', 'y2HPBa', 'CM8Ttq', 'AeHKvW', 'zurUtG', 'uhbjwq', 'EfzPuG', 'CMfWxW', 'sK1ivq', 'B0virW', 'CMKGka', 'BgvFAq', 'Bwj3yq', 'Au91rG', 'zgH1sq', 'mtyUmW', 'B1jjwq', 'C2vZCW', 'DgLUDq', 'iYqL', 'C2vIsa', 'otyZ', 'zhLU', 'CenfsW', 'zhbfCa', 'uwP3BW', 'Agv3', 'tK1UuG', 'zxiGmG', 'mZC4', 'DNmVqa', 'yLviuG', 'jMnVza', '4PYxievY', 'oeCXra', 'mtq5', 'Ew91CG', 'AgfWAq', 'Atb4vq', 'ucbqyq', 'wsXIzq', 'ugHVBG', 'zgXgyq', 'z2LUzW', 'Dd10CG', 'igDLDa', 'zwvKzq', 'yM9YDa', 'zw4TqG', 'qMLkqq', 'ntuX', 't3ruEa', 'icGOja', 't2fMqq', 'u2LSzq', 'Bwf0yW', 'CM9qqG', 'qw9Iua', 'z1fvra', 'zuTtqW', 'rNr5CG', 'rej2Ba', 'BwvYtG', 'Ewj3CG', 'ieLUDa', 'tuT3AW', 'x3jLCq', 'q1Hvsa', 'ntzFrW', 'r1HnAa', 'uIXHCG', 'vhrQyW', 'r0ztsG', 'ruXUCG', 'mJaGva', 'BMCGva', 'zMf1Ba', 'rYXLBG', 'u3vJyW', 'CIbJDq', 'qvPwwa', 'BMfVDa', 'y05eBq', 'Ff98xa', 'vwXrsW', 'x19ZCa', 'mLz3qq', 'y1jHvq', 's3vbCG', 'BgvKia', 'ndq0Ca', 'BKPIua', 'A3r2CW', 'sfrnta', 'zMfPBa', 'v29erq', 'zM9YBq', 'z3LSma', 'wKL1tq', 'mZu4', 'z0TdDW', 'zgrTEq', 'lJeUlG', 'ENLZCW', 'l2fWAq', 'Bhq6ia', 'lMfPlW', 'ndyZoti5nKTHBg9Isq', 'BguGua', 'zgPoyq', 'sKvszW', 'BgvNCG', 'l01yuW', 'lw5VDa', 'tLLMCa', 's3Hbsq', 'Aw9Usq', 'mtuUmG', 'CNjVCG', 'mtCUnq', 'BxjPtq', 'ufrZva', 'u3L6Eq', 'BMvJDa', 'ueTJDa', 'qwjVCG', 'uhDUzG', 'zszZAW', 'D2z6sq', 'zYbmAq', 'khnJyq', 'qwrYzq', 'mJq5', 'y29UyW', 'wM1YCq', 'ELrRra', 'AwqGmG', 'rhbhrG', 'DxrMoa', 'pszSyq', 'Eu8Yrq', 'ysKGwW', 'tsXMCG', 'C3rLBG', 'vfjwsG', 'BM9UyW', 'sg1WBW', 'yxbPsW', 'uLHXqq', 's21Uta', 'thblsW', 'zxnOAq', 'CMvNxW', 'CxLwva', 'A0Xqsq', 'zMv0yW', 'zgvMyq', 'C0Xzvq', 'BsbWCG', 'y2HHCG', 'mJbdnG', 'q0rirq', 's3DktW', 'BguP', 'oLaTmW', 'v09UtW', 'C1r6yq', 'BgWGFa', 'Dc5Tzq', 'BMXxCq', 'nJC2', 'shvdAq', 'uhHKBa', 'y3bywq', 'Bwu9', 'Bercva', 'u21PDa', 'vhbtyW', 'C1jpyq', 'A0XesG', 'A3DWCq', 'zxHPCW', 'D2fYzq', 'mtqUnW', 'ENnOyG', 'C2n6qG', 'vhjL', 'CJTXpq', 'ChjPyW', 'r0n4DW', 'thHerq', 'y2GTCa', 'AhjLyq', 'y29Tzq', 'BMDLxW', 'yMCTqG', 'yxzLza', 'uKvhsq', 'uuHAsW', 'EwDxEq', 'vuTVyW', 'CYzPza', 'mJfdnG', 'ANvHrq', 'z250DW', 'Bw9YDa', 'tvb6sq', 'wMPXEG', 't3Pwwq', 'ywr5ia', 'A3L3vW', '8j+AGcbnzq', 'mJi3', 'BNnLoG', 'zxHWAq', 'sgLHyq', 'DdOGma', 'D3GYAq', 'mJGWsq', 'Bg9tDW', 'AhuTsa', 'mte3oa', 'ntCZotaWD1vqugHu', 'zcbVBG', 'vKPwEG', 'Aw5Npq', 'zYWGDW', 'xYWGFa', 'DhvYzq', 'BgWGlq', 'B0LZCW', 'BuDWva', 'sw9NEq', 'CMLUzW', 'C3vJyW', 'AwfSCW', 'tKHRyq', 'CZOG', 'Dg9Y', 'u3btEG', 'A2eTrW', 'yvPJtG', 'uMvPzW', 'wvrbyW', 'whjgza', 'q2ztBW', 'Axn0kq', 'Bg8Tta', 'uLfhsq', 'y0PtAq', 'keDLDa', 'zfvcrW', 'Chjdsa', 'oty1', 'rsXHCG', 'Bg93xW', 't1n2BG', 'Dxv3Ea', 'wMvxEG', 'yMuTqG', 'CYbgAq', 'CNjqvq', 'weLgza', 'wsXLCW', 'igzYBW', 't2zYuq', 'veHlAG', '4PscifVIGki', 'vNn6vW', 'ChjduW', 'AvnOwG', 'DhK9jG', 'vhPSzW', 'zKHpza', 'qwXowq', 'zNiTuW', 'lJKSyq', 'wujmrq', 'AwDFBW', 'sK5MDG', 'DgvYia', 't3jHBG', 'tevova', 'DZjirq', 'C3nFyq', 'BNvTCW', 'As9LBa', 'yLD6Da', 'os4Xna', 'vwTAsa', 'AwTNta', 'DhjPBq', 'mNbfmG', 'CxbiEa', 'yKPRuG', 'CMr5EG', 'D3bIzW', 'C1n4rG', 'C2DIAG', 'qw1rzG', 'tLD0zG', 'AMLNCa', 'BNqVCW', 't21juG', 'ifbvqG', 'rNDKAG', 'rwXutG', 'BMTtEq', 'y2vjra', 'AwvZlG', 'iezPBG', 'yMXWpq', 'r0HOua', 'qM93wa', 'BLPPra', 'vsXLBG', 'CgXHDa', 'y2rUBa', '4Psa4Psa4Psa4Psa', 'ChD1EG', 'DcbLCG', 'DhvZia', 'mtzFmq', 'swfKAG', 'EurTCa', 'B25Lia', 'vgDssa', 'z2PZyG', 'EvnbAW', 'Cej6rG', 'BYbsyq', 'z2jwta', 'wu1rEa', 'AwvUDa', 'Awz5', 'phWGFa', 'AxvTia', 'q09otG', 'icGVCa', 'rYXMCG', 'CNzLCG', 'z25PEG', 'yMnquW', 'quniqq', 'tfnFqq', 'oIaWxq', 'C3rLEa', 'rw5pzG', 'v3bquG', 'B1fgyW', 'Exn3Ca', 'EwvSBa', 'D2Xvnq', 'qITjrW', 'yujurq', 'EKL2sW', 'BgH6vq', 'uMvZCa', 'AuL0ua', 'wvfdra', 'qvPPtW', 'C3bWAa', 'zgvZAW', 'vYXLBG', 'Dc81mW', 'rgvMyq', 'ANDZwG', 'y0z1EG', 'qsXICW', 'yIWGAq', 'jMnVBG', 'u1rbva', 'otC1', 'rM53DW', 'AY1Wyq', 'Aenfrq', 'Dcbjua', 'CMvNDq', 'Bg93lG', 'CMLK', 'BMfKra', 'A0LSza', 'C2nUvq', 'zeLYzW', 'CurwAq', 'sffovG', 'zMXVBW', 'qLvvtG', 'BMPXsW', 'B3iGka', 'DhjRDW', 'vKPqvW', 'EwvHCG', 'EvPdCa', 's1vqDq', 'AxrZia', 'rgv2Aq', '4QYf77IpiejH', 'CI4Grq', 'tNDxvq', 'DLn0Da', 'qwrKzq', 'Dw5RBG', 'C3rKAq', 'wLPeCq', 'yK9WyG', 'sxDWDa', 'u2HvyW', 'q0jHyG', 'yxrJAa', 'CKHNwa', 'D0XtEq', 'ihn1yW', 'zcbYzq', 'v0vQuG', 'ALP6Aa', 'wLf0Bq', 'Be1Jsa', 'vJuG4Ocu', 'AwzdrG', 'ufrNvG', 'r2v0lq', 'DMfSAq', 'reLiyq', 'AxqTuW', 'werivq', 'zeT6AW', 'mgPxma', 'Ec1MyG', 'CNvJDa', 'sgXcDq', 'wwTJuW', 'AwqLmG', 'wMzkCa', 't3zVBG', 'rxDUwa', 'yNmVAa', 'ief1Da', 'B2qGmq', 'BfbZta', 'DMHfAa', 'EMLUzW', 'ywXS', 'A0TWEq', 'uMvTBW', 'cIaGgW', 'CgKVzW', 'ru9sua', 'kg1HCa', 'BwLpqq', 'tgzhCW', 'ifvWza', 'uxrKqW', 'DwX0oG', 'BwLACq', 'zwXLyW', 'Aw5LCW', 'mtG2oa', 'Bw5YuW', 'BMX1Eq', 'B3bkzq', 'ww5vtG', 'B3jTyq', 'AMvqDW', 'ExbIDW', 'rMf0yq', 'qMPTEq', 'BgXwEG', 't0XVBG', 'o0e9qG', 'uIXOCG', 'C3rYyq', 'AwDPyG', 'z3PPCa', 'u3LgvG', 'uw9uqq', 'tIXMCG', 'q3bYuG', 'zLDYtq', 'DxbKyq', 'icbdAa', 'BhP2vW', 'ufbTBa', '4Pwq4Pwq4Pwq4Pwq', 'AY1WCG', 'zwqG4OAs', 'ANrTqG', 'vuXJDa', 'BM9YBq', 'BguTzG', 'AxjZDa', 'rsaGia', 'ywDL', 'uJGWyq', 'DgCTva', 'C2f2zq', 'x18Pia', 'zsbMCG', 'CML0', '8j+mKcbbDq', 'Dxj6BW', 'wIXHCG', 'sePdwq', 'tMLZyW', 'Bw1MCq', 'q3DQqW', 'thDqqq', 't0z0uG', 'uhjLBq', 'zeTdEq', 'zxzLBG', 'Aw9Upq', 'vvfOBW', 'iKnOCG', 'y2L5Ca', 'DgLUzW', 'mtzFmW', 'vg9Via', 'C0LyyW', 'zcboua', 'CMvY', 'x3XCxW', 'zw5VzG', 'FcaNia', 'u3j6Dq', 'qwvLtW', 'yLDcDa', 'q1bimG', 's0vsuG', 'x2nOzq', 'B25FzG', 'z3jVDq', 'xsdWN5seia', 'mJyX', 'uIbttW', 'wwDkqG', 'B3DZia', 'y2SUlG', 'uhLwwa', 'zgLNzq', 'mJbFua', 'AwvZ', 'vM9Kyq', 'mJmZ', 'icHTyq', 'AwfdrW', 'zvniEq', 'twv0yq', 'mtvFmG', 'twfYDa', 'lcaIrW', 'B3iGza', 'CMvHza', 'tK1zwa', 'D0zqAW', 'A2v5CW', 'mJm0', 'Cxfjzq', 'seLIsa', 'ns4XnW', 'wNnNzW', 'CdmVzW', 'Dg8Gza', 'vunUAa', 'ALfhvW', 'sYXZCq', 's2v2Aq', 'Ag9ZDa', 'zK5ttq', 'CIbYyq', 'zsbUBW', 'tgzeza', 'Df9MBa', 'zvf2va', 'AxrPBG', 'uNvZyq', 'zxmTvG', 'uMvNAq', 'lMfPjq', 'q291BG', 'DfXdCG', 'CgP3tW', 'Bu1Avq', 'icD8jW', 's2XyDa', 'r0DXqG', 'Ae9VtW', 'nIaOnq', 'q1jhwG', 'DurWBq', 'nguWEq', 'uvLesW', 'pue/qG', 'z01sBG', 'BKjYAq', 'vKPxra', 'ks4Grq', 'x3nVDq', 'zwvUlq', 'rwn4Dq', 'CgLWzq', 'lIbqBa', 'BwXRrq', 'mZu1', 'rxjYoG', 'C0XoyG', 'ChqTqq', 'uYXHCG', 'ptaUoa', 'Ehz1tW', 'A3KTsW', 'zw4Ttq', 'icaGxW', 'zgfYAW', 'A0n4yq', 'B1fOsq', 'y3DKwa', 'Aw5MBW', 'mtLhnW', 'A1zJBa', 's3jqAG', 'vw5RBG', 'wvr2BG', 'BfPKrq', 'zw4Tva', 'C2uGCG', 'quPcra', 'AYK6', 'u1rfuG', 'ywjSzq', 'icyGCW', 'BYKGvG', 'D1v4sG', 'zMfJzq', 'zxf1Aq', 'suHwta', 'CNbeuq', 'DhKGnW', 'v29YAW', 'zsbhmq', 'BgLUzq', 'zLPOza', 'BwvZCW', 'whLSqG', 'CKDUwq', 'yxnZoG', 'igzLDa', 'BMuXna', 'q0PlyW', 'uLrKsG', 'rfH6Ca', 'AdbUBW', 'BL9VDa', 'lti1nG', 'mZCY', 'z05nqG', 'ntK1', 'D2f3', 'C0PUBq', 'zLK9cG', 'uKuG4Ocu', 'BLvSAq', 'yLrkvq', 'rg5LwG', 'z1vQwq', 'rvHbia', 'Bs4UlG', 'CNfNvW', 'CunfDa', 'AxjTzq', 'C29Yia', 'zM5msa', 'zMjgAq', 'tM8GAa', 'vxjAsa', 'x3XFFa', 'y29TBq', 'q2zvnW', 'zhzItq', 'zxmTrq', 'mZG5', 'CM95', 'B25PyW', 'v3fXtq', 'rgXluG', 'weTZCW', 'zhrOia', 'As9SBW', 's2zuza', 'mJi1', 'ue9tva', 'khj1BG', 'icPCka', 'twLqsW', 'Bw9IAq', 'DhLJuG', 'rezdwq', 'uffxqq', 'u01XtG', '4PYp77Ipien1', '4PYtifrO', 'AhPhwa', 'A21xrW', 'ihvUza', 'zxnLBG', 'yKf2uW', 'vwfIDa', 'qvbQBW', 'B3nwzq', 'C3HgEa', 'ELbjwa', 'ywvS', 'zgvIDq', 'ru1ruq', 'zxqTqW', 'CKLTsa', 'DufxsW', 'uM1uta', 'uwvyyW', 't1DSsG', 'ruLIua', 'txrwCG', 'vg90yq', 'DhjPBG', 'Axr5ia', 'vMTXuG', 'kg5VBG', 'BMTZzW', 'EuvUvW', 'zxvL', 'BMHZCa', 'ihrVia', 'thvxqW', 'zvrjsW', 'wgj4uq', 'cIaGqq', 'qJzc', 'z3jPDa', 'z0XoBG', 'q3PqCq', 'v0Lgsq', 'y3jLyq', 'Agv4', 'oty3', 'lxjLzW', 'ieDqvq', 'B2jQzq', 'uIXLCW', 'DMvY', 'oty0', 'C2fsvG', 'rYXREq', 'yxPVnW', 'tYXUyG', 'kYKRkq', 'pszHyW', 'oIbuAq', 'ELLICG', 'EhLVAa', 'wfeTra', 'zwzzzG', 'DLLhtG', 'EKTvBW', 'DgvZ', 'CM9NCG', 'Dw5SAq', 'uxbZEa', 'zNvtua', 'Bg9N', 'nZyZoa', 'EM1zCW', 'vhjXua', 'vcXPDa', '4PYtienV', 'qwjPtW', 'jMfSBa', 'DNLvqG', 'ntaWkq', 'zNnLDa', 'zv9JAa', 'x0jHCW', 'De9JEa', 'DMjRDG', 'ihjLCW', 'vvriuG', 'BM8GnG', 'sLbMCa', 'zLL5zq', 'AuvTrq', 'tMLcsW', 'mtGYoq', 'yNLVtq', 'ntq3mG', 'lvjtqq', 'AeHArG', 'B2nRzq', 'AK9bqq', 'lHTBma', 'wLDOsq', 'tMjwsW', 'Dcb1Ca', 's3fxvW', 'ucbtzq', 'y0XNzG', 'wgHcDa', 'zcbZzq', 'mJi5', 'zsbhzq', 'z19PBG', 'EevLBG', 'q01FuW', 'zxnWBW', 'EKXLBG', 'C2vUDa', 'tevFta', 'DxjPBG', 'BM5LyW', 'uhrpBa', 'l2nHBa', 'zhvzAW', 'tNf3uW', 'BNDgta', 'uKvuuG', 'zhjHzW', 'rMPkza', 'AwXHyG', 'D2DvBa', 'EdOGAq', 'mtqUma', 'oc1JBW', 'rfrTAG', 'C2v0Dq', 'CMvK', 'tvfJtW', 'C3q6Ca', 'mtHimq', 'Dg95Cq', 'rwv5yG', 'zvj4tq', 'scXRBq', 'whzksq', 'zxjFyq', 'C2uGAq', 'tKrouq', 'v0z5CW', 'DvbkuW', 'teXftG', 'ELLABG', 'v3f5CW', 'EenXCG', 'sxzbAW', 'zMXgDW', 'qMngrW', 'wMfOyW', 'AxbgDG', 'rg1wsW', 'sgLtAq', 'Ae5yDq', 'rfjbnq', 'BMWTuW', 'Cg9YDa', 'Dfjmyq', 'wZqVna', 'z2v0CW', 'DxiGsa', 'uIX0CG', 'lI4UcG', 'q1rjvG', 'ywD4ua', 'DLHkvG', 'DZrJzW', 'iZqYnG', 'jMrWCG', 'icdILAdILza', 'zhbVAq', 'zw47Cq', 'C3vICW', '4PYxie5V', 'zwzNAa', 'mZu5mW', 'svLvqq', 'zxmP', 'vLbuta', 'zxjSEq', 'twHLwq', 'Aw9UCW', 'jNnVDq', 'ienHyW', 'mI4XmG', 'CfrOuW', 'ufPfrq', 'tYXLCW', 'EhKGzG', 's3vqwG', 'zeTxzq', 'vhPvDa', 'CeLOzW', 'DejrDa', 'DMXssG', 'AgfowG', 'AwrDpq', 'quDWrq', 'CKrLCW', 'DMfkBG', 'C3nNsq', 'BMr3Aq', 'q1qGua', 'CL9Tzq', 'vw9JCa', 'yNj4tq', 'ntiYnW', 'mtaGva', 'zxrLyW', 'zcbkuW', 'mtaUma', 'C3qGDa', 'qNrsCW', 'rhvpqW', 'otC3', 'B3DFBG', 'qLjZCW', 'ENHrsq', 'CML0Eq', 'kcGOlG', 'usXMCG', 'x3vYAq', 'yxLIEq', 'sgLMEa', 'r2rYAW', 'y05kAG', 'BwvDpq', 'zwnRxW', 'AwPRBa', 'zxnZzq', 'FdD8oq', 'jL9FyW', 'B3H5lq', '4P2miev4', 'zwn1CG', 'yxrPBW', 'AxrPDG', 'vw9ZCq', 'icdILzRILza', 'DgHKyq', 'B2fSCW', 'BNrPyW', 'xYrDwW', 'ANP6tW', 'u0HbmW', 'r2fkza', 'twv0Aa', 'z1HPzW', 'ufb1zq', 'tfne', 'C3rLCG', 'rJq1', 'v2rqta', 'Fcb8lW', 'C3rPBG', 'CgfKrq', 'EhDryq', 'ierPCW', 'qufXtq', 'BKPYqG', 'yMLYDa', 'x3LVDq', 'BMDLCW', 'rNjIAa', 'CNjfvW', 'EMPZEG', 'jMLZxW', 'zeDIAG', 'Cg5fCG', 'sNnrtG', 'v2XMsW', 'rxbKvG', 'zMLYCW', 'yLvhCW', 'odq6rq', 'ucbbua', 'ieeOqG', 'ugPgyG', 'sKzdDW', 'rLj6uq', 'tIa9pq', 'Bhq6nq', 't1DlDW', 'qxvfAG', 'sgrKnW', 'zLfpsa', 'me9mDW', 'terxwq', 't2PVDW', 'zfH2uq', 'zeHRqq', 'vYXHCG', 'q29UBG', 'tM9Ulq', 'uwrpAq', 'uhrgrG', 'zw5JBW', 'DgfTCa', 'z0PMqG', 'DfPOvq', 's1rfAW', 'mJy1', 'C21ZqG', 'yxqGka', 'DLHuzW', 'qvbjla', 'EM83Dq', 'AujMDW', 'DxnL', 'BMqGka', 'x2LKxq', 'zxjFAW', 'AKTStW', 't2DpzW', 'BcbuAq', 'CgvYia', 'AxrLBa', 'y2vFBG', 'vfaG', 'veXtxW', 'wgTAsG', 'yxnFEq', 'mYbcAq', 'ChqTqG', 'x3jLzW', 's1LJDa', 'C29J', 'BgL0Eq', 'AxreqG', 'A2XTEG', 'zwfZzq', 'rcbHCW', 'sKPLDa', 'As9Ryq', 'u0TfEG', 'B01ftW', 'zxrLlG', 'wg1UEq', '8j+mKcbnzq', 'rwvzzq', 'Aw1Asq', 'uvrStG', 'yKrxta', 'Aw9fBG', 'v0LeoG', 'ter6Bq', 'zsbWzq', 'n0iY', 'wgTpyW', 'E30UyW', 'sgXSqG', 'lcaIqW', 'uLrNCa', 'wLHvBW', 'BwvVDq', 't1n0CG', 'tfvhEa', 'zxjZ', 'rM9Asq', 'tdOGsq', 'CM1PCq', 't3r0qW', 'qNLZzq', 'ifXFxW', 'DMuTyW', 'quPpDW', 'AuXTBq', 'AurxAa', 'BMDFza', 'v3Pqyq', 'drTBsW', 'u3rTtq', 'zeTeua', 'rvnFmG', 'rxHZBG', 'DxD0ua', 'mtuUmq', 'wdi1nq', 'BhnK', 'BNrFyW', 'u00TuW', 'yMvvuW', 'AufPBG', 'B25Uzq', 'BNDdCa', 'D2LUmW', 'C2vUCW', 'zuzqua', 'zsbgAq', 'B1jMBG', 'qMn6yq', 'cIaGwW', 'tKvfAq', 'DwuMyW', 'id0Gka', 'ywvvvW', 'C3bSAq', 'vvnFqW', 'Dg8GuG', 'tg9Wzq', 'zxjZrG', 'BhPwsa', 'swXJra', 'usXHCG', 'Eu1Z', 'ie9UBa', 'yNzsBa', 'Ef9Rzq', 'reXzBa', 'zw5Kzq', 'zs4UlG', 'A0fJwa', 'seDjsa', 'zcb0Aa', 'x19Fia', 'BMrLBG', 'ssXMCG', 'uLbmyq', 'r1PdvW', 'uuzZuW', 'mxWYFa', 'oI8V', 'wIXHEG', 'sfbrzG', 'zg93CW', 'u3Litq', 'rfDbuG', 't3zJDq', 'uMj2tW', 'igzIxq', 'zs1VzG', 'yvjKAq', 'AKP0CG', 'wNLjDq', 'BNbvDW', 'CMLHBa', 'tIX6Aa', 'Eg5LDa', 'Dc4k', 'pwH0Da', 'ihjHBG', 'vujMAW', 'ELPmDG', 'tw9VCG', 'zLvsBq', 'zKPcsq', 'wMr1Aa', 'D0LgyG', 'A0jJzG', 'CLn1Bq', 'rKDPDq', 'CvrNtq', 'wKvAta', 'qxfMvG', 'AKjWEa', 'BMCGqW', 'zguTqW', 'ig5LDa', 'uLr0Ea', 'zeP1sq', 'AwzPyW', 'lJKSEG', 'uuzPuW', 'vufcBW', 'C2vJlq', 'zwDYAq', 'zxH0ia', 'BNzHBa', 'ExrqzG', 'CMnLxW', 'CKz4sq', 'icaGFa', 'ucbMBW', 'ieLelG', 'AgvHza', 'tM5LEG', 'z3LpqW', 'Avm2Cq', 'rNGYvq', 'y29UDa', 'DwnJzq', 'DNHwrq', 'x2nYzq', 'C2nLsq', 'mJi0', 'DdOG', 'BZfUrq', 'BMvS', 'q3PNDa', 'CMXLBG', 'ywnJBW', 'AwrerW', 'BNrFDa', 'Bfnksq', 'icaG4Pwr', 'EejqAq', 'x29MxW', 'lxrPBq', 'zszWyq', 'sYXKyq', 'vxL6Ea', 'x2v2zq', 'uez3DW', 'BhnLjG', 'u3rLDG', 'C1Dkwq', 'BMzPCG', 'mJiY', 'DwKWAW', 'tevpwq', 'x1XFFa', 'xsbgzq', 'ywjJza', 'qxLACG', 'reTivW', 'tcXWDa', 'uNrLDq', 'rgf2Aq', 'B2LKvG', 'vxLeBG', 'BNrHyW', 'BgvJDa', '4Psu4Psa4Psa4Psa', 'tgvUzW', 'sfjysq', 'rv9ovq', 'zKHWsq', 'BMCGBa', 'mtrFmG', 'r0LivW', 'wLvXvG', 'CLL1qW', 'thn2Bq', 'tIXTCW', 'rNjlyW', 'Aw53qq', 'lwLZlq', 'ys9JAa', 'Ev9Jnq', 'AMf6BW', 'y2eTqq', 'EgTAuW', 'zM9Yrq', 'CMvNtq', 'mZu3', 'B3jbyW', 'FcaUia', 'mtb8mW', 'C01lDa', 'uwLbAq', 'tNruEq', 'DeLmuG', 'tLrotW', 'sw9Twa', 'zhPAtq', 'vxjP', 'rxLSAa', 'DMLoBW', 'qK1gvq', 'zwX5ia', 'ru91BG', 'uwDduG', 'yvDjCW', 'yuLxBa', 'rfLoCW', 'n0yY', 'zeTmva', 'mc4WiG', 'tgnrBa', 'mc44', 'uM9KCG', 'Au1OEa', 'zgfezG', 'EeDYrW', 'CIbRzq', 'ELD3qq', 'oteXqG', 'Bcbtzq', 'q2HIBW', 'mZC2', 'y2HLza', 'sMvMzG', 'wZiVna', 'mJy2', 'DcbWzq', 'y3LJEq', 'C2K9', 'mtCUmG', 'odG4', 'zgvS', 'ifDOyq', 'yw5KBa', 'mc4YFa', 'B0jTEq', 'Dg8GCG', 'BhnUCq', 'tuP5Aq', 'BMfSia', 'yxj0Eq', 'yMLSAq', 'mtqUmG', 'qLnqEa', 'wZmYBq', 'z2uOCW', 'nJa1lG', 'vYXYDW', 'C2fTzq', 'vLjHAW', 'C29Jlq', 'ywrKta', 'x19FlW', 'z2rOAG', 'B3nuyq', 'CZOVlW', 'q0Dzyq', 'wxj6Ea', 'DhKGoa', 'BMv4ia', 'CM9YoG', 'yMXVyW', 'yNH6wa', 'u1nFtG', 'C2uGuW', 'tNfcrq', 'BwvUDa', 'qvrzBa', 'EMftzW', 'EgPXyq', 'lxjLCq', 'xsdIMQdVUi8G', 't043Da', 'y3HwCW', 'jMrPCW', 'wcXLCW', 'BMrZ', 'B29trW', 'D3HRAW', 'DfbPrW', 'zxiGka', 'AenUCW', 'z1HuuW', 'zcbZyq', 'ufLPtW', 'FhrZoG', '8j+sUYbezq', 'BxvlCW', 'A3nKuq', 'zererW', 'DLbVta', 'qKfnvW', 'uK9gsq', 't3zYCW', 'EefRsW', 't1DArG', 'ks4Gvq', 'scXKzq', 'kYKRja', 'Bs8/DW', 'EfvNDG', 'v3HOsG', 'uhb6tq', 'mZjFta', 'ihbYBW', 'u1njtW', 'icPCkq', 'C3i9', 'y2TLza', 'wvv0qG', 'sgfYza', 'ig1Vza', 'r0P2qG', 'zM9Uzq', 'CMvZlG', 'Aw4GBa', 'rgLZCa', 'zY4GmG', 'v2D2yq', 'shfKBq', 'zxnZ', 'Be51Bq', 's0j0zW', 'sfvXsW', '8j+tPIbbBa', 'rxLuDa', 'B3jKpq', 'lI4U', 'r015rW', 'Dg9Wlq', 'u3ztBq', 'A3HmEG', 'C2z1Ba', 'Dw1Izq', 'yML1vG', 'Dgv4Da', 'BdLVna', 'lsbJAa', 'Euvbsq', 'mJqX', 'BMDLia', 'u3yX', 'uu1bta', 'zxj2zq', 'CYbRzq', 'zw4Tqq', 'q29UDa', 'jMnZAq', 'AwnHDa', 'y3mTqW', 'wKHSwG', 'zYaG4OAs', 'vxLXsa', 'ExLjCa', 'yLPpEG', 'if9Fia', 'seLgCW', 'q1zcuG', 'B1rpCa', 'z3vqrW', 'scXLBG', 'sg9bAq', '4Pwq4Pwq4Pwq4Pwx', 'lJiGia', 'i0zdqq', 'tKDtuW', 'ufv6uq', 'yMfZzq', 'zY4Gna', 'r09ZAa', 'B0LbuW', 'zguUAG', 'BujcqW', 'uIXMCG', 'y2vhCG', 'ifvoqq', 'DLb4sa', 'zLvMrW', 'icHLlG', 'CIaNyG', 'zgvUCW', 'B3iOiG', 'tM5Rsq', 'AwXLia', 'CMfkza', 'ig5VDa', 't1fUsa', 'CwzyCq', 'zM5TDW', 'Buz1rq', 'sMXRAG', 'igvYCG', 'AvHZEa', 'BhnqqG', 'teXctG', 'qu5Tsa', 'B2D5Da', 'uLPeta', 'DhvOrq', 'ChqTrW', 'CeDsEa', 'A3m9zG', 'sKnKvq', 'j2jHyW', 'zwWTrW', 'yMvY', 'Cwjzta', 'BwXLvq', 'B2fK', 'sgPpCq', 'B2vZDa', 'otKZ', 'mJeZ', 'BKrtqq', 'DeDwsG', 'mJu3', 'CdOGsq', 'AwPzwG', 'rLGWvq', 'BZjrDW', 'Ehjdza', 'veTOrq', 'oIb0lG', 'BMuXnq', '4PQHief1', 'xt1Myq', 'uKnRCa', 'BNrZ', 'Cen0uW', 'mJmWna', 'CxbSxW', 'DfPYBa', 'BgqGBG', 'mJu1', 'mtvFnW', 'u0eTqW', 'C2PtrW', 't1rqia', 'BMLK', 'r3rPrG', 'ruDkBG', 'z2vYzq', 'B25mBW', 'vM1oCa', 'zxqTrq', 'ruDvwa', 'AYbMyq', 'zsbnmG', 'rLruCW', 'tu1MwG', 'BMfTzq', 'twH4tq', 'x3WGFa', 'sYXTAW', 'AM9PyW', 'CwvJsa', 'AM9rAq', 'rsXLDa', 'lwLUlW', 'CMqG4PQH', 'v1HLvW', 'mZK5mq', 'uIXLBG', 'ys1Zyq', 't0WGia', 'Aw5N', 'qMnkqq', 'vujTva', 'q3H0vW', 'zM9Yzq', 'kev4Da', 'Bw1uBa', 'DMHtsa', 'q1zJvW', 'A2fKyq', 'BuP4Cq', 'CKrqAa', 'B1TWyW', 'C2XPyW', 'D1nYBW', 'B2nVnq', 'zhmGka', 'Dw5KoG', 'y2LLCW', 'CIbUDq', 'mtHFnq', 's3fwAa', 'surVsq', 'uKvPCW', 'Axr5lG', 'rgL0Aa', 'ANbkzq', 'mZCW', 'AKzpsq', 'DcaTia', 'D3rZva', 'ntqZjG', 'DxOTvq', 'DhLwuq', 'tYXLBG', 'z2uP', 'v2LSBa', 'r2vJAW', 'sKPpta', 'B3DU', 'BMvhDq', 'oe8WEa', 'wxfmDG', 'Cw1ywG', 'uLnxCq', 'BM9Uzq', 'uLn4sa', 'uevxBa', 'zMDKyG', 'DhvZpq', 'zsbUDq', 'nZiWia', 'yuzjua', 'BhfkwG', 'sNrIDG', 'mtG4lG', 'AhLyta', 'B2qGoG', 'yw0Trq', 'zNzUtG', 'tujfuG', 'DKP4sW', 'uM13Aa', 'ChmTqq', 'sMfJAW', 'r290ia', 'tej3qW', 'ipcFLku', 'otK4', 'vwTtCa', 's3bvsa', 'yxiTva', 'CMfQtq', 'r2fqAa', 'sKTJtq', 'mJi4', 'BenVDq', 'uLPfDq', 's2jMza', 'uuXJCW', 'uvPSqG', 'yxDnBW', 'vw5Svq', 'u25HCa', 'lwLK', 'jMnVDq', 'AwnLBG', 'A1rPzq', 'zszZBW', 'pxrYDq', 'BNn0yq', 'Dc82ma', 'v0jPqq', 'iJGI', 'wYjvuW', 'CI1Zyq', 'x2fNzq', 'DK5VEa', 'DKzZsG', 't1jDia', 'nhWZFa', 'v1nVCq', 'CgLUxW', 'yvrLAW', 'y3rYBa', 'zgvUDa', 'uuvSuq', 'rcXJyq', 'i0zgnG', 'D2m2ma', 'mY4Znq', 'AuXqAa', 'DwftqW', 'vurrvG', 'zun0qW', 'BcbYzq', 'qMXirW', 'ufjfzW', 'tgTfAG', 'zYbZzq', 'sLPJCW', 'vgTqDa', 'uNvrtG', 'Au56CG', 'A0a0', 'B24GnG', 'igDVia', 'BhL4Aq', 'CM9Pza', 'DhPwvq', 'qKXUtq', 'zsbSyq', 'BvLQDq', 'ihXFkq', 'u2nOuW', 'r0nnxW', 'mtHFmq', 'v2n6Dq', 'BsbwBW', 'yNjVDW', 'BLPtEG', 'DcbZBW', 'icdILzeG', 'tcXMCG', 'Bu1bvq', 'sw9tAG', 'CgXHEq', 'BI1vuW', 'zNzfua', 'qvjiDa', 'zgeTra', 'mtCUmq', 'AwnLia', 'zM1mua', 'yY9JCa', 'ChmLmW', 'x18Gxa', 'D2vY', 'BgLezq', 'yw5Kia', 'Dg8GCW', 'x2jPCG', 'zxjPsq', 'mtuUnW', 'DML4sa', 'BNnLxW', 'DwTjBa', 'vezNsW', 'B1DWrW', 'D1nzsq', 'ruPzva', 'uwHIsW', 'quKYna', 'Dhj5', 'BNrhAa', 'AJfWma', 'C1vnwq', 'DgfUDa', 'wKDOuG', 'uKnICq', 'Eg1Sla', 'BMLUzW', 'z2v0tG', 'Aw1LCW', 'icb8ia', 'v1HhvG', 'AhbosG', 'yxiTua', 'CxrzDG', 'Cwv3wa', 'q0rfrG', 'ChqTuW', 'wwTUrG', 'yw5KCG', 'yxjLza', 'rxDoCW', 'yMf0Da', 'yKXSzW', 'zLfusW', 'uMfUzW', 'A2CUmG', 'rMvLza', 'A3fIuG', 'z2v0', 'iefJyW', 'ywn0lq', 'Bsbozq', 'AvDjqG', 'mtLcnW', 'EfHXBa', 'ruDjtW', 'Cgf1CW', 'iZG4oa', 'EhDZsG', 'B2LhBa', '8j+tMcbgyq', 'zM9BCa', 'DgvYBG', 'q0TftW', 'u3rLEa', 'lNbHzW', 'q293qG', 'ucbUBW', 'svP1Aa', 'pwzHBa', 'm3W1Fa', 'qxPcvW', 'mZG2', 'B3bLBG', 'revcvq', 'zguTqq', 'oKvdra', 'vKnuuW', 'mtq2', 'DKDxta', 'v05xqG', 'tNzzzq', 'zs1pDq', 't09QyG', 'zMXZrq', 'qKXYDa', 'pszJBW', 'C3Dsuq', 'BMCUlG', 'vMvYAq', 'igzHAq', 'mtaWia', 'uNztyq', 'CMqGkW', 'vujmsq', 'uxfhyW', 'q3PPEa', 'ywXFCa', 'zgv2Aq', 'zxjUyq', 'x3bVAq', 'zgqGyq', 'xsbhBW', 'AMXAua', 'AwjvvG', 'B1v6ua', 'zsb8ia', 'Bhr4ia', 'EhK6', 'CKjxvW', 'uMvMCG', 'u3rIvG', 'BxbdCq', 'rsXMCG', 'zKv6zq', 'sKvrva', 'BMDLoG', 'CMvKzq', 'z3vUEG', 'CxvLDq', 'tMfrCW', 'y2vUCW', 'zxiGmq', 'yxnZqa', 'C3CTsW', 'lwnVBG', 'q0fQqG', 'zv09jG', 'B3v0lG', 'yxiTuq', 'AxjXyG', 'rcaGia', 'lxzLCG', 'vvnVAG', 'svbrrG', 'De50zW', 'kdjVBW', 'Dfn4wG', 'AMvwqG', 'ChjvBq', 'yu16uW', 'iLDPBG', 'CYbHBG', 'EfHhqq', 'mJuUma', 'FhbYBW', 'CMvTBW', 'z01lta', 'DgvKkq', 'yxLSBW', 'rY1vsq', 'yxH5zq', 'yxnL', 'DxjTyG', 'BMv4yq', 'thbwzW', 'lJKSAa', 'q29luq', 'sMLSwa', 'A2nZsW', 'BeThra', 'BNDUoa', 'D1jqDW', 'A19UDa', 'yxjNAq', 'AgLNAa', 's3jtva', 'zw1WDa', 'ndDgta', 'yxrMBW', 'Bxz2ta', 'BhvZxW', 'z2LUlq', 'zw4TvG', 'vxDptq', 'CKrUCq', 'rYXIzW', 'CNPmEa', 'zfviCG', 'zw4TuW', 'B24Goa', 'DcbMBW', 'v3jrCa', 'ntyTuW', 'nZaW', 'qwrvwa', 'B2DPyW', 'te5Qva', 'z3bZvG', 'ELvWtG', 'mtG0oq', 'twf5Bq', 'Efv3wq', 'vcXSDa', 'zw4GBa', 'Dg5QuG', 'mJqUmG', 'AKPSzG', 'ywqGzG', 'ie5Via', 'zKzltW', 'Ae9Vua', 'ywnRjW', 'mtHgnW', 'q3vluG', 'B2q9uW', 'BJ0MAa', 'C2v0sq', 'AwqGCa', 'ihn1CG', 'ig9Uia', 'CYaO', 'Dw5Klq', 'mtyUmG', 'BYbWCG', 'sM9ZAa', 'mI9Nzq', 'wNLWvW', 'DKLetW', 'otu3nW', 'tuvusa', 'EuvyzW', 'svr1CW', 'Bg1LBq', 'u1nmxW', 'tgHPtq', 'wMvsAG', 'vMXSrG', 'EcbUzq', 'vIXWDa', 'qurovG', 'Ee9M', 'CMvMzq', 'tLjfuW', 'B1jHta', 'EvvUsq', 'tMv4yq', 'B24Gka', 'x2TLEq', 'BMLZEq', 'DwPkCq', 'ihrHCG', 'mZrywa', 'lMnSBW', 'zMzPyW', 'x19FFa', 'swDuqq', 'mJe4', 'AxmTrW', 'Bgv2zq', 'C3n3BW', 'BwvKAq', 'tfDhBa', 'r0fPvq', 'EgnUsW', 'sKPryW', 'tKveCW', 'B20GCW', 'qsbutW', 'igfYzW', 'zgvSyq', 'uKzjCq', 'ChPwtq', 'DxjSAq', 'zwjWla', 'z2DfBW', 'C25VuW', 'AxfdEa', 'B25Jzq', 'v1D4sa', 'zMXVDW', 'ic8GxW', 'tK9uia', 's2LmAq', 'CeDPBG', 'BM94BW', 'ELH3yq', 'EKzRBq', 'B2z1Ca', 't1PQzW', 'yxbPxW', 'B3rW', 'DxrOyq', 'wwLeva', 'A29wvW', 'oJa6', 'DML2BW', 'CYaGqq', 'DgSTva', 's2PQrG', 'wxveza', 'Dg9mBW', 'zhvXCW', 'A1HSAW', 'yujnsq', 'BhvZ', 'rvbstW', 'q29UzG', 'Fdr8ma', 'zw50pq', 'reTdwG', 'twvKAq', 'uxnZtq', 'lJKSzG', 'DwHVCa', 'tLfRDW', 'zgrbDa', 'uMLUEG', 'nhWXFa', 'vxzPzW', 'CLrJvW', 'jMHHCW', 'CM91Da', 'Dc1Yzq', 'zhHnBW', 'DNjKrW', 'CMvKAq', 'yKvhuW', 'yxrVCG', 'uKnfrq', 'ig9Yia', 'CfbxzW', 'tuzzBW', 'B091ra', 'vwjdrG', 'C2H5sq', 'Dg8G', 'BgLKia', 'rxPXuG', 't0Xzmq', 's2TRra', 'Dtb6rq', 'zNiTqW', 'sgzXEq', 'y2vIBW', 'uuTywG', 'Cc4k', 'C2vUza', 'ANLZEG', 'zgftzW', 'Dw5Kzq', 'yxiTuW', 'zevbAq', 'sNPvBq', 'sIXLBG', 'lJKSCW', 'nxuWnG', 'rNvPuq', 'Bg93pq', 'wNrAra', 'sMLota', 'CevTza', 'jg1Iia', 'wuneBW', 'Exb0BW', 'q1rZrG', 'tfHIEG', 's0n6Eq', 'uvzNzG', 'zMjFza', 'uvvttG', 'rxzLBG', 'oIbgCG', 'mZCX', 'mtGUmq', 'ndG1wa', 'Bu1yvG', 'zdOG', 'DJ0I', 'uufnEG', 'g1SZsG', 'zwrLEG', 'CMvUza', 'vg14vW', 'DezICW', 'ExHTqG', 'tKHzwa', 'C3znqG', 'r2rbvG', 'vMPntG', 'ztrvyq', 'v0Ddtq', 'zgvUyW', 'D05Irq', 'EhHIDa', 'yvfYyG', 'DMLJzq', 'yxngsa', 't3vrBG', 'zwn0zq', 'BxmUia', 'ltbYyq', 'mJaW', 'zw4Tta', 'mJiW', 'z1zJuW', 'shPZtG', 'ENn0za', 'y2XVCW', 'svzvCa', 'ugnHta', 'B2LK', 'B2XLoG', 'sgLzvW', 'EMGTqW', 'BMuXnG', 'DfrPBq', 'ksbbCa', 'CKLKoW', 'z0DuDW', 'BNvSBa', 'uvvAtq', 'AKXPta', 'u01tia', 'Bf9Pza', 'ssXMAq', 'uhz0Cq', 'icdILztILza', 'runptG', 'vwvMDq', 'se5etG', 'BMv3', 'tuDRwa', 'Av9Rzq', 'wMvTzq', 'icHiva', 'ywrZia', 'EvHdvq', 'Cg11sW', 'BgjHDG', 'u0LKzW', 'tLHlEG', 'q0rxwG', 'EvLcDG', 'B3aGnq', 'wfPstG', 't19uta', 'svrPyW', 'DwXKxW', 'tejHBq', 'wvb0DW', 'yxjLia', 'vcXKEG', 'o3e9ma', 'yNmTqG', 'sYX1CG', 'lw9WDa', 'AgLZiG', 'wsXTCW', 't3nsDa', 'BNrT', 'CYbSBW', 'uMvZzq', 'q2r0AW', 'Cfv4vW', 'CKDVqG', 'Dg9W', 'zvHAEq', 'DwuP', 'igXPAW', 'C3bkuq', 'uuTNyG', 'zxj0Aq', 'mJu4oa', 'v2LSCW', 'BYbSBW', 'qsXMCG', 'u092Ca', 'B3mTDG', 'vvzgza', 'C2uMyW', 'AYb0BW', 'sKrxtq', 'ide5mq', 'z1vjCa', 'r3PAvW', 't1bruG', 'C3rOEq', 'y2GGzG', 'qw94BG', 'CwnTAG', 'qvj5vq', 'B2zPBa', 'wNjpua', 'C2HPzG', 'xsbtDa', 'BwfUDq', 'mtLdnq', 'uLrUza', 'y1Hwuq', 'rvbHuG', 'qvzuuG', 's2PpzG', 'D2vbuq', 'u0zQtG', 'CxvPCG', 'ihLVDq', 'mJmXmq', 'zxr1CG', 'rxDQEq', 'zMLJyq', 'mtzFmG', 'CwnRsq', 'AwLOEa', 'mtDFnq', 'ifnLBa', 'wuDwrq', 'B1TKzq', 'rsXRyq', 'wfvKqW', 'DgvNCG', 'zgfYza', 'r2HqAW', 'Axn0zq', 'BwL1Bq', 'DfPhAW', 'vNrLvq', 'CgKUCa', 'EeDrzq', 'qxflwa', 'thjrtW', 'otG2mG', 'wuTTsa', 'CMvNAq', 'C29JAq', 'AwnL', '8j+tUeLhka', 'ywqG4OAs', 'ChjVEa', 'uxb6rG', 'xsbtzq', 'yw5Kyq', 'ywrLza', 'zMTOvW', 'EfzRCa', 'BuHYrq', 'ks5tzq', 'qMnuzW', 'Bw9Kzq', 'u3flrq', 'BgvKoG', 'rxb3ta', 'ntqZ', 'vgPPsG', 'vvbHrG', 'BwjLCG', 'CMvQzq', 'u3f2Ba', 'AwTLEq', 'B24V', 'B25Zzq', 'y2j6uW', 'AhrLsq', 'kfjLCW', 'A0zhzq', 'DffXEa', 'uNDiBq', 'ifrPBq', 'q2Phta', 'ks4UlG', 'x3rVAW', 'ig9Uzq', 'uxPyDa', 'Cg13uW', 'ihzLCG', 'rvbSta', 'zgLZCa', 'ALvQCW', 'tvHADa', 'qM5UyW', 's3nfAW', 'A2vSEq', 'qMrSAq', 'CIboDq', 'DLfqEa', 'Euzhwq', 'seXvwG', 'x2nVBG', 'rMrJCa', 'ugTIvW', 'Dhj5ia', 'DwrLCW', 'zs5NlG', 'jM50yq', 'mJq1', 'zw5ZBW', 'suPxsa', 'D2nPAG', 'DhrStq', 'u3rHBG', 'rvmXmG', 'otCY', 'igv4Aq', 'oc1hqW', 'mYaOna', 'yxbLCG', 'sgnAAq', 'icaG4PYx', 'Dw1jDG', 'DcbKzq', 'B2LUDa', 'rMnmzG', 'suftCG', 'CgvUza', 'sfLYCa', 'tuz2Ca', 'q2TjvW', 'CNfhta', 'jM1HEa', 'mc41', 'uuTWsq', 'C3rYAq', 'nZf3mq', 'CfHYDW', 'lMPZBW', 'BhmV', '8j+tSsbttq', 'BNriAq', 'vezJDa', 'idqWnW', 'DwXHDa', 'BM8GnW', 'Aw5Ozq', 'ndiZ', 'FgXHBG', 'CMHovq', 'zxy9', 'rLHzzW', 'EfLkyq', 'rtvtma', 'BL9Yzq', 'ifjLCW', 'sLnptG', 'B2vktq', 'C2rIua', 'ignOzq', 'BNm9Da', 'zw5Klq', 'mZu2', 'EMG4ma', 'qNnAra', 'ie5uia', 'AxnFyW', 'CY1WCG', 'Evn5BG', 'C3rHBa', 'y2nLCW', 'y0H4BW', 'wMDnCq', 'AgTmwq', 'wunSrq', 'icdINjCG', 'Egjeua', 'AfrvBa', 'vM9SDa', 'xYbFia', 'ww1Qta', 'mdK5DW', 'BIbJBW', 'yK9ywa', 'CMTLDa', 'luffuW', 'DhjvDW', 'Bwf0ia', 'D1vuCq', 'tu5JAa', 'Bg90uG', 'yNLvvG', 'yvvrzW', 'zgLYzq', 'DgLVBG', 'tKHwDW', 'iev4Aq', 'x3WGia', 'z2XPCW', 'DK5zsq', 'u0HAEq', 'mJjdmq', 'yuPeCG', 'mI4WlG', 'tfjczG', 'iMLpuW', 'wNL4sa', 'zgLUzW', 'scX0Aa', 'zMvLza', 'mJbcoa', 'w2XHCW', 'yMLSzq', 'DvPnvq', 'EsbJBW', 'rcXYBW', 'EKXPsG', 'zsbbmq', 'DxrOxW', 'CgHHuG', 'B21WBa', 'DNjhvG', 'igf2yq', 'DMfSDq', 'Ahz2CG', 'rNvhwq', 'zuzPBa', 'rgvryq', 'veLnia', 'tKPksa', 'uvrwtW', 'mc44la', 'r3z3Bq', 'CI1Uyq', 'zNjSxW', 'zY50Ea', 'txbosa', 'zw4TrG', 'Dgu9', 'suTVzW', 'su4Gua', 'AvfkyW', 'BNnVBa', 'yLHArW', 'CIdWN5Qakq', 'wfbruG', 'u2nJva', 'zuTRBa', 'zg9JDq', 'CKzVDa', 'rviGua', 'r2T6tW', 'zwDmza', 'DuDLDa', 'Dhj1BG', 'C3vWCa', 'r2jTyG', 'C3P0sa', 'igzVCG', 'sfjwAq', 'ngTnmq', 'ywLSDq', 'AK1Xvq', 'mc4Xnq', 'ze5Xuq', 'k0zUnW', 'Egfpva', 'AhPozq', 'Aw9UAq', 'wKjrEG', 'Cha6ia', 'wgjSuW', 'Bhbjza', 'icdINjmG', 'nMeWyq', 'DKLHCq', 'qK5mqq', '4Pwq4PwDcG', 'rhfzsa', 'EcbRzq', 'q2nxuG', 'Cwvjqq', 'yNvgtG', 'v3j6wa', 'zeDSuW', 'zxC0yG', 'B2WGia', 've1VzW', 'zMfJDa', 'q0frqq', 'tsXPDa', 'CMzHBa', 'CMv2', 'CgXLvW', 'CfvkBW', 'CgfZCW', 'ibTBoq', 'q1bvia', 'Bwv0Aa', 'qvLrsW', 'x3zHBa', 'AYa9ia', 'CvvTtW', 'vcXLBG', 'Aw9UlG', 'zK11EG', 'y3b1CW', 'rgG3sG', 'twvuCa', 'D3DMCW', 'EeHRyq', 'qK5Tva', 'BNrSEq', 'vcXHBq', 'nJCZ', 'xsbgAq', 'u0SG4Ocu', 'jL9Fza', 'rhnprG', 'menfyG', 'jL9Fyq', 'Aw5ovG', 'ywDHza', 'y3qP', 'C3Howq', 'uwzJDa', 'zenHAW', 'BgXPBG', 'zxi9jG', 'mJm4', 'vKvpBa', 'utCY', 'r3vArG', 'AguTsq', 'Chjjsa', 'qKPfqG', 'CMvSzq', 'AxzLia', 'DurfwG', 'A1zvra', 'rwvOrG', 'CuHtta', 'jNbPyW', 'yNzXuW', 'C2PZCa', 'ndq5', 'zKjPqG', 'CNnzAa', 'y2vVBG', 'yvDgCa', 'turdsG', 'y3vZDa', 'tKfrDW', 'thr4ta', 'A0jOAa', 'wLLVAq', 'C3bPBG', 'lxnJAa', 'wcKSia', 'B2LKia', 'B3j0', 'B3v0', 'reXlCq', 'ywj6ua', 'g1SWBq', 'qwLoAW', 'ENzgAq', 'rsXZCG', 'ruvQDa', 'CfbxrW', 'zxmTqW', 'BNj3tG', 'vennqG', 'suzvEq', 'xsdINiuG', 'zxjZia', 'nxW0Fa', 'odu1', 'z0Lqsa', 'icbqCG', 'wIXJCW', 'C3DfzG', 'ysbbyW', 'ie1fva', 'BgrACG', 'CgvovG', 'Dhb1Da', 'ienOCG', 'qLjisG', 'BfLOqW', 'z25UsG', 'mM9Voq', 'zNvSia', 'vgfrCG', 'Ew1SsG', 'rgf6sW', 'AxHxsa', 'vg9OyW', 'vZbABW', 'A3reDq', 'C2vYDG', 'BMuGka', 'zKXADq', 'Aw9cua', 'icboBW', 'AwX2yW', 'AK5vAq', 'AMn0vW', 'EgvxAq', 'sM9Uzq', 'D2DHCG', 'EwzlrG', 'vxnLia', 'wMvpuq', 'DLrUyq', 'swTrwa', 'BgvK', 'wvHSvG', 'z1fWuW', 'Dw1LBG', 'muO0Cq', 's0XntG', 'rufUsa', 'AvPjyq', 't1mG', 'vtbiqW', 'yxiTta', 'ANjyzW', 'BhnKpq', 'yMPLyW', 'AxnbyG', 'zw4TrW', 'D2HPDa', 'lwzVCG', 'B3j0xW', 'tNvTyG', 'BfLMDq', 'u3rduW', 'uhbhwq', 'B3j0Aq', 'D2PjCG', 'Ee1ssW', 'yxPSsa', 'As9NCG', 'zwfY', '8j+AQYboBW', 'C25TrW', 'rvCWta', 'rhH6Eq', 'kI8Q', 'rwLTvG', 'ywfmrq', 'BYbNBW', 'DgHFCa', 'mhWYFa', 'BL9Pza', 't1vfBq', 'yxHKDa', 'vgr3BW', 'DLvqza', 'mKXNBq', 'qNPsAq', 't05irW', 'C3rKBW', 'CfjMvq', 'DuXgDG', 'wMrUvG', 'n1aGka', 'r293ta', 'rLj5rq', 'DwHSwG', 'CMLMEq', 'mxW2Fa', 'rLr5sW', 'EMH1Dq', 'y2fHxW', 'z0flCa', 'y2nZvq', '4QYf77IpieDV', 'tvLzqG', 'BNbTia', 'B3DUqW', 'ChvIBa', 'uuvUvq', 'seuTuG', 'lwDWCW', 'CxfesG', 'wKHXua', 'C2STuW', 'tM91Aq', 'EeXWtq', 'wKroEa', 'tNfYBW', 'B3iG', 'pYbBza', 'yvzota', 'ChqTtq', 'ndaW', 'B1DbCa', 'thyZ', 'zw4Uia', 'EhndDG', 'B3rSEa', 'u216Aq', 'wK9Wqq', 'rLbonG', 'B1fYAG', 'ig5Via', 'B0PZCW', 'rur1yW', 'AgKTsq', 'B2XLia', 'whPbzq', 'y3PnyW', 'suHYva', 'C3nPBW', 'q3jbtW', 'mLOGka', 'twnLwq', 'yxbPlG', 'vKfywG', 'AwD1zq', 'ExvVDW', 'lIbbyG', 'nsbjBq', 'Dgv2za', 'tYXHCG', 'B2XLua', 'zK9VEG', 'zNjWyq', 'Df9WBW', 'BguGqW', 'A2v5Ca', 'svHpsW', 'Eu1Vza', 'AvDjuW', 'yuHczq', 'B3qGzW', 'AwPKrW', 'l3nJCG', 'AxPhvq', 'EMXjDG', 'DgfJDa', 'x2LKxW', 'veHmua', 'BhLhsG', 'CYKGia', 'B1fnsW', 'qNjVDW', 'mJuZ', 't0zuvW', 'vvjSzG', 'x2PVAq', 'vM9SDq', 'igfUza', 'mJu0mW', 'zYbHyW', 'C28TuW', 'zxiG', 'Dw50lG', 'vcXKzq', 'EhPkCa', 'Aw9UxW', 'CMzoCW', 'Bw9sva', 'rhbSwq', 'DcbUzq', 'zw5Zzq', 'zK9twa', 'r0v3ra', 'rYXHCG', 'AhiTsa', 'uvnLDW', 'ifDPBG', 'y3rLza', 'mtCUna', 'nJC3', 'AwqTsq', 'jMzVyq', 'wMXSyq', 'u3yXxW', 'BxHiva', 'ysdILiiG', 'weDwsa', 'zwfurW', 'tsXOEq', 'zMLSDa', 'Dg5TuG', 'DLHSzq', 'Dcb0BW', 'uen5tG', 'FgjYBW', 'B2vPvG', 'zLbvwa', 'DKzdua', 'v0XUzG', 'refmEa', 'tuTpCG', 'C29JAW', 'mtHhoa', 'v3jPDa', 'ywDLlW', 'Bxntvq', 'zxqTsq', 'thzADG', 'BNrTjG', 'A0XtDa', 'DMjMuW', 'ndi5', 'q2HYAq', 'suHJzq', 'AxrLuW', 'EenVBG', 'BMDVrG', 'v3HAtq', 'qxzwza', 'y3rPBW', 'qLPOyq', 'A2n4za', 'tuzWCW', 'DKDcza', 'DgvTua', 'CfLqrW', 'tvf5zW', 'C2LK', 'thP0Aa', 'EKrJuW', 'wu5Hvq', 'zYaGia', 'z3jHEq', 'mJqW', 'vhCXsq', 'otm4qG', 'zNLPBG', 'vu5vCW', 'zwqGka', 'zcbHCa', 's0XTrG', 'u25suW', 'u1jZyW', 'whvHua', 'shnHzG', 'qwDoAa', 'B05Rra', 'seHQuq', 'z3b1', 'Avbzra', 'ifnLCW', 'BsbAzq', 'zwXVDq', 'wMTqqG', 'rsXZDW', 'zfPkAG', 'qwnJBW', 'BwfUEq', 'zvbItq', 'AhnP', 'rwP4vW', 'jNrVCW', 'EhfHEq', 'whnwvW', 'iokuGIa', 'Bwf4ua', 'uKP3Cq', 'ndqYmJK1mfDVterAyW', 'D1HHyq', 'C2uMAq', 'D2DWCa', 'yuLyuG', 'jsdILiiG', 'B2XAwG', 'wvDeDG', 'suz2CW', 'rhvxrW', 'vw5gCW', 'zguTra', 'yMLdCG', 'yKznDG', 'wevqwa', 'rKLAsG', 'suXxzW', 'uYbcBW', 'igzVDq', 'AhzJsW', 't1rqoG', 'DtTXpq', 'zMLSzq', 'wZm2Bq', 'A3fpvW', 'BNnLza', 'luvYCG', 'oNbVCG', 'i0zgna', 'AgvKlG', 'uhjoqG', 'u2vUDa', 'zcbIzq', 'EMvvtG', 'B1r6qq', 'BxmTqG', 'suD2vW', 'mtDFmq', 'igfKza', 'r3zetG', 'B3vW', 'B29VyW', 'mdiW', 'uhjPyW', 'zs1Yzq', 'mY9Nzq', 'txP5rG', 'EgL0Aq', 'Cerdtq', 'zwPnyG', 'yxjKDW', 'zMXHzW', 'Cg9PBG', 'vvPVvq', 'DxjLia', 'svnprq', 'DgnOAq', 'B3vUDa', 'B3DFDq', 'rIXMCG', 'y29TCa', 'qwXYzq', 'AcaOzq', 'yvLMtG', 'luC1nW', 'mJjbmW', 'C3rHBG', 'DenYuq', 'vwv0Bq', 'Ew5J', 'rgvSzq', 'u00Tqq', 'u0LirG', 'zwWTqW', 'ihrOCG', 'zcbHBG', 'lIbbza', 'jNDHDa', 'otCX', 'AM5Ruq', 'vtzdmG', 'BLvtCG', 'zvDwrG', 'u2PfCG', 'tK9ilq', 'DgHFyW', 'wfLqyq', 'ucb0BW', 'txLVwG', 'serxra', 'zt0MCa', 's2HjAa', 'mJjgnW', 'AwmVyq', 't1n2tW', 'zwfqyG', 'mgz4DW', 'yMTpvG', 'tIXOAq', 'y21lEq', 'mtHFmW', 'zLbsua', 'uMr2uG', '8j+mKe1LDa', 'ys1MDq', 'vM9fDa', 'twzyyq', 'u0vsvG', 'AgvJAW', 'BLDRtG', 'sMT6sa', 'ihnLyW', 'DMnVtW', 'rdGYsq', 'luC3oa', 'iJeWlG', 'idbDoG', 'CxfOua', 'p0fFqG', 'FdH8mq', 'Cgn4rG', '4Psa4Psa4Psa4Psq', 'uNL0rW', 'mc05yq', 'rvHbDW', 'AvP4CW', 'vujdDG', 'Agvlvq', 'BMqGiG', 'wuXAyG', 'Aw5Nia', 'yxiTrq', 'BMDLpq', 'AdK5yq', 'mZCUmW', 'EKv1Dq', 'AwrJxW', 'y1fZCa', 'zNiTrW', 'A3rqzW', 'EgvK', 'zw50xW', 'CYb1BG', 'CNv6CW', 'Dhj1yW', 'tw9UvG', 'CMvTzq', 'yvnWDW', 'senItW', 'wwvZla', 'AgDzva', 'Axq9Da', 'sgjewG', 'Dvfrua', 'Aw5Kzq', 'y2HHBa', 'swvlDG', 'ExHkDa', 'tNnHCq', 'yxrLza', 'ksbBza', 'B20Gta', 'ywLSzq', 'zxjZlG', 'jNrOAq', 'qvqMva', 'xsbuBW', 'z2jZBW', 'BNrPyq', 'vvnFvW', 't3HqAW', '4PYtieXV', 'vgLTzq', 'ugXcBq', 'AxbFEa', 'wenMrW', 'q2vUzG', 'Aw1HzW', 'yM9Sza', 'mtGUma', 'B3jMzq', 'iKfUza', 'zNjRtq', 'BhyTta', 'iZe4nW', 'mJa2oq', 'cIaG4PYt', 'CgTLzq', 'z0fUtq', 'AxnbCG', 'BgX5iq', 'Cg9UCW', 'DxjLCW', 'zLfczq', 'zsi7DG', 's3nrBG', 'r29VzW', 'icaO', 'A2n4Aa', 'zwfKCW', 'rfPbva', 'DMuGCW', 'vKzPCq', 'yxjPlW', 'EfnrDG', 'BgTUzG', 'oty4', 'kcKG', 'rKrvqq', 'vwvtzW', 'CMnLpq', 'BL9MBa', 'yvjkBW', 'zeLwBa', 'icdILze', 'wIXWDa', 'A2LUzW', 'BgvUzW', 'z2HgCq', 'Du5Vyq', 'tKCT', 'sMHJDa', 'z2HkwG', 'uLH5ua', 'C09pwq', 'pszWAa', 'sejsza', 'C1fisa', 'B1fxsW', 'D0jfsq', 'BfPbrG', 'u2vSzq', 'r29UEG', 'uZa3nW', 'AuzlCG', 'BhzL', 'xsdWN5Qaia', 'wNnRtG', 'DKv4Cq', 'rhDIsW', 'BxPPsG', 'zxnZBW', 'Dgj2rG', 'vwD2rq', 'vMDZvG', 'CxnlDG', 'igrVDW', 'nJC5', 'zxjyEa', 'ys1TBW', 'yI1Yzq', 'rw1yuG', 'CMvYDa', 'zxjZAq', 'Fdn8nW', 'EgLLCW', 'isbqBa', 'Aw5WDq', 'mZGX', 'wenfta', 'Be9mCW', 'qu5lsq', 'q1rNEq', 'sNH1BW', 'u1bRvW', 'CfDevq', 'kdS7kq', 'y29WEq', 'yxLcsW', 'tLG5', 'DhnxAq', 'qvD6Ea', 'FcaOxW', 'mY4ZmG', 'B3v0Aa', 'tg1gEq', 'sgnrra', 'rMLSDa', 'BMCSkG', 'qwLNCG', 'l3zLCG', 's2P5zW', 'zw50Ba', 'DhjLyq', 'BMv0DW', 'DNbzqG', 'qxrUEq', 'vxz3sW', 'D2PRqW', 'DfjTva', 'z2z0Dq', 'ifn0yq', 'x18Via', 'BwDguG', 'u3LUyW', 'Axnuva', 'q3fbra', 'Dxn0BW', 'ohWYFa', 'icb8xW', 'CMvZzq', 'B0nKuq', 'zw1NsG', 'q3zqva', 'z0nPta', 'mJqY', 'wuPWCa', 'C2KTta', 'z0LcuG', 'zxnOqW', 'yMvVDW', 'tgfcCG', 'Au1Uza', 'osXPBq', 'u1vwqW', 'ntaGva', 'ywXPza', 'BwvKia', 'otK1', 'ufvuEG', 'uMT6vq', 'Cw9LrW', 'Dg8GzW', 'ywPmrW', 'CgLSrq', 'z2H0', 'AxDbtW', 'BuL6rG', 'zwrFzq', 'CM9Yia', 'tw9IAq', 'C3nHzW', 'wxzSwq', 'uhjV', 'surYDW', 'EM9U', 'tKXysG', 'BeHdBW', 'ntK4', 'zcaOCa', 'ifjLzW', 'CM9MAq', 'zw4Tua', 'mLOGqG', 'ntHNAG', 'DxjJzq', 'nNu1vq', 'uw5eEq', 'rNroDG', 'A21qCG', 'pwnVza', 'BhrvyG', 'yuPTzG', 'qM5dra', 'ica6ia', 'jM9WDa', 'AwDsrq', 'B3DLCG', 'Au91yG', 'sfLqwq', 'mJqUmW', 'EMPjra', 'Aha/', 'BNrDpq', 'yNrpAW', 't3nMuq', 'zu5ZCW', 'Aw5NlG', 'EMrluq', 'm3WYFa', 'wfGPia', 'ihrYEq', 'zxbpyq', 'qIXHCG', 'B2TLBG', 'tLbMtW', 'iJK5iG', 'qvrjtW', 'EK5iBW', 'tcWGBa', 'zMXHDa', 'DgHLBG', 'EKeTwG', 'CK1hvq', 'CIzZzq', 't0LtAq', 'tM9qCG', 'qM93zq', 'B2nLCW', 'r0XwEq', 'sxDIEG', 'EfrIuW', 's0Hutq', 'i0zgra', 'Bc1VDa', 'sxviqG', 'mJu0', 's2nKCG', 'yxn0xW', 'DwDtuq', 'A2Djzq', 'ucdIHPiG', 'xcaVia', 'y2vYDa', 'thPQAa', 'q1zzsW', 'x2TPBG', 'z0LRvq', 'Es50Ea', 'BuLvzW', 'mtuUna', 'ywjzyq', 'yufuDW', 'qwfJBW', 'CeTtwG', 'yxv2AW', 'C2DLDG', 'lwrLDG', 'CNHhuG', 'zg93BG', 'D2vYqW', 'yxbOCq', 'CgnQsq', 'BI94Aa', 'CNrPCW', 'vfjpBa', 'DZ0X', 'nY4ZnG', 'ChvZAa', 'DLzWqq', 'DZbdvq', 'werrEa', 'y2HPBG', 'y2GTDq', 'q0rtqq', 'AMnLAW', 'zNvUyW', 'Cg1IBa', 'EeDpva', 'ihWGsa', 'tfLLra', 'BcbLCG', 'Bsi7DG', 'rgvWzq', 'ENDtsG', 'pt09ia', 'CMvWzq', 'yxiTqG', 'wM13CW', 'CMvZDa', 'u1nmia', 'nZvHBW', 'ig9Mia', 'zxjZlW', 'vNfLwG', 'BMjIAa', 'Dw5RjG', 'zMeTsq', 'DKfvsG', 'zxDota', 'ChfuqW', 'DwLK', 'swXPyq', 'BwTLyG', 'weDKvq', 'l3n0Dq', 'z1nABW', 'vtjSDW', 'CMfT', 'zwqUDa', 'EuL2sa', 'A2P2AW', 'v2HjEG', 'mJqUmq', 'BwfYEq', 'EePWAW', 'qw9ivW', 'C19IBW', 'BhqTta', 'Axb0AG', 'z2LoBG', 'AuDdBG', 'mJffmG', 'mJmY', 'AgveqG', 'q29UCW', 'Dg9vCa', 'DuzSBG', 'Aw1jBG', 'DK9Nza', 'D25Uzq', 'ifrVAW', 'CgKVyW', 'zxGGka', 'zf9HyW', 'B2LKyW', 'BfbdsG', 'ywnO', 'EeXyqq', 'BMrPBG', 'qwnJzq', 'swvwDW', 'svr1AG', 'CevKzW', 'ywXLEG', 'DxrOlG', 'BMfS', 'AgfIBa', 'wePHvG', 'Axr5', 'pteMxW', 'DMH2uq', 'y29Kzq', 'C2SGlq', 'A3bVAq', 'tgHNDq', 'vgHYzq', 'swTYqW', 'ndCZoa', 'y29Yzq', 'y3qGqW', 'vfDQva', 'qvbjia', 'B2PzqG', 'lxf1yq', 'Cg9W', 'yLnhDa', 'uMHPBG', 'mtrFnG', 'C2Pzsa', 'BKjcCa', 'y29UzG', 'Dg9gAq', 'mZCZ', 'rvrADW', 'ue51rW', 'zxqGAa', 'CMvWBa', 'mtHcoq', 'sMjbsG', 'wxroDG', 'ANDnzq', 'nYbqCG', 'u2fMyq', 'ywfRwG', 'Fdf8mq', 'zNPquq', 'BMrVDW', 'jMfJDa', 'yMvYxq', 'C2uGyW', 'ChqTva', 'zMLSBa', 'vg5xza', 'Ehq/', 'CNn0xW', 'BgWTDG', 'zu1oBG', 'oNbHCW', 'yxbWxW', 'DhDVtW', 'zvn5BG', 'zszZyW', 'tKHRvq', 'vJiZmq', 'BKj4Eq', 'Cg93zq', 'Dg90yq', 'Aw5Nsq', 'EsbeCG', 'BwnAsa', 'zxPVBG', 'DunKsa', 'DK9qrW', 'zKjwvW', 'v2fzCW', 'zxmTrW', 'q0nrza', 'A0Duzq', 'x2aGFa', 'tI9b', 'DcaODa', 'EKrfwG', 'zMDuAq', 'DMXjzW', 'Acbtyq', 'DMvYAq', 'Aw50pq', 'Du5HAq', 'uNnssG', 'tNPrtW', 'r1D1rq', 'AxnFBG', 'CIbqCG', 'Ct0WlG', 'mJq0', 'wdy4nW', 'C2vSzq', 'r3vmzq', 'u0jzua', 'Evzira', 'zxn0', 'uNHWwq', 'mJjcoa', 'A2vLCa', 'B0Puyq', 'jNn0yq', 'y3H3BG', 'C2T0BW', 'CeP2DW', 'zM9BAq', 'quj0Dq', 'tfPKBG', 'ywrK', 'sevYDW', 'yxrOoG', 'rcbPBG', 'A2H4sq', 'ys1WBa', 'zM1NEa', 'v0Leia', 'zunwvG', 'z2LUia', 'sZjxBq', 'su9oia', 'BLPzzW', 'DhnN', 'ie9uua', 'EgjYrG', 'zwv5yW', 'CxftvW', 'AxnHCW', 'sNLLvq', 'wNLJAW', 'Ewv5za', 'sLbQvq', 'yxrO', 'Axj0Aa', 'C2v0lq', 'BvrRAa', 'rKfuqq', 'C3rLCa', 'BMnLia', 'y1rfrW', 'CM4Gka', 'rMnMAG', 'Aw51zq', 'DfjdzW', 'luvdra', 'zxmTqq', 'zsbdAa', 'AxbtEq', 'AK1VCW', 'zxjNBW', 'zxj2Aq', 'tuL6zW', 'rerNrq', 'BIa5ma', 'rcXHCG', 'zNDwCa', 'tvbfBa', 'uLvjvq', 'D2HPBa', 'vMrkEq', 'D1n4ta', 'suXf', 'DMLKzq', 'uxvHBa', 'tZbNyq', 'tgnUBG', 'ig51Bq', 'ie1LDa', 'ucXUzq', 'uKfYvG', 'vvbDia', 'qYXMCG', 'yvzWsW', 'B3iGsq', 'mtvFna', 'n3HLvq', 'yxv5CW', 'zg5mra', 'uhzqza', 'C3nLCW', 'BwfPBa', 'l21HyW', 'iokaLcbH', 'yM9KEq', 'DMfS', 'mtuUnq', 'zwqGAW', 'ihrPBq', 'CMKVnq', 'icbmyq', 'sM9OBG', 'uhLjuW', 'ChrqEa', 'qYblrq', 'ugzfyW', 'CMvHCW', 'seD2Ba', 'tw9RBG', 'DxH0tq', 'ywfLrG', 'zgvMBa', 'yxiTtW', 'ieXHCW', 'zxLOEq', 'igLUCW', 'BuLAsG', 'kgv4Aq', 'se15Bq', 'sYXZAq', 'rw9MrW', 'D3jxAW', 'y2HLyW', 'zw1PDa', 'zxjLia', 'AxvTiG', 'ChjLyG', 'B2fuDG', 'ohf3AW', 'pszMAq', 'ie1qmG', 'AxqTsq', 'sNvwEa', 'usXLCW', 'shfmrG', 'DwX0kq', 'ieLu', 'cIaG4Pwu', 'sw5ZDq', 'uM9Nzq', 'Dg9gwG', 'txbOwq', '8j+tGsbmBW', 't05VDG', 'CvriwG', 'wgHLqW', 'ihWGmq', 'CNzsEq', 'wwn6Dq', 'icGVzW', 'A3fkza', 'CxDItq', 'DYbRzq', 'u21ZqG', 'ywn0Aq', 'z2DLCG', 'DMvmAq', 'mZu0', 'AhfosG', 'C2vHCG', 'zNbxyW', 'DwH3rq', 'lwrHDa', 'ELnMAa', 'Bwv0yq', 'zM5vvG', 'DwHwEq', 'Dw1yDa', 'Df9Uyq', 'DMvYia', 'sMXizG', 'CMvyBW', 'Du9KCW', 'CMrFCa', 'pszPzW', 'z3jLzq', 'AxqGua', 'CKn2Da', 'ExP1Aq', 'BwnzAa', 'q29VAW', 'mJu2lq', 'ANDyvW', 'zY4GzG', '8j+uJsbbDq', 'oxCXsG', 'rKzhDW', 'ihT9', 'BgfUzW', 'y1b6ua', 'AwPXAW', '8j+hQVcFH7GGu3a', 'sYXZAW', 'EezMzG', 'lw5VBG', 'yLf4za', 'EwrwtG', 'tgzqAW', 'r0DYtq', 'v1L2ra', 'EsbKCG', 'C1r5qG', 'ANnWpq', 'sLP6AG', 'BNqGCW', 'y3b1', 'uK5hAq', 'nI4Zmq', 'BcaOrG', 'EhzOrG', 'zMvMDW', 'yv9HCa', 'vNnTEG', 'zK5oCa', 'u2vYDG', 'rLriyG', 'zgfICG', 'zgz5vG', 's256ra', 'BIbxAq', 'C2v0va', 'v3nhqq', 'Aw9ezG', 'Bca3ia', 'jgnWDq', 'CxjZDa', 'tMvtwG', 'C2jdBG', 'vvLxDG', 'lujfrW', 'i1bxra', 'yNvPBa', 'wwrntW', 'uKryDa', 'zgDUDW', 'r1znua', 'AhHvBG', 'A2v5', 'r2HACa', 'yK5hCW', 'x3WGjW', 'v2HeBG', 'odGW', 'wgHiwG', 'BM53va', 'zNvSBa', 'B3rZDa', 'ww54zG', 'r1LoCq', 'EMvTvq', 'ogH3BG', 'u1DLsW', 'v0Pitq', 'yM9VDa', 'ugTWzW', 'tsXHCG', 'BwuVCW', 'icGWia', 'uKPcqW', 'C1zwyG', 'BgLJBW', 'CIbUzq', 'yM9VAW', 'DKvXDa', 'sLzdDG', 'wuTsrG', 'C3mVAq', 'CgvPAW', 'BNPPza', 'rKDKCW', 'BguGrG', 'z296uG', 'qvfTzW', 'y2vFAq', 'DKrvza', 'igLUia', 'B3rQvW', 'r0X3EG', 'D3jPDa', 'FdL8mq', 'mtuW', 'zw4TtG', 'oc4XmW', 'BNrSzq', 'DxjPCW', 'uvHhra', 'quv5Ea', 'x0jstW', 'mZiZnG', 'uIXWDa', 'qNjPyq', 'y3j5Ca', 'mc4XmW', 'B2LKxW', 'DwzYsG', 'AYbWCG', 'suLxtW', 'CMTXsq', 'ALDbrW', 'CMqTmG', 'ue13za', 'y2uTCG', 'mtu1rG', 'mxn3yq', 'yw5Nia', 'zxbLBG', 'A1jvrq', 'vhLgtq', 'qw5KCG', 'yxr1CW', 'CM9Tzq', 'Dxnuwq', 'zgf0yq', 'rxHPDa', 'suvpzW', 'uMDNzG', 'BxmTtq', 'twfSAq', 'qvjfxa', 'z2H6Da', 'tfnqyG', 'CM9Yqq', 'C3nPBG', 'BMvK', 'ksGGkq', 'EsbMBW', 'vsXLCW', 'y3jPCa', 'z19LBG', 'Aw5ZDa', 'ywXSxW', 'mti4xW', 'otyX', 'wsXLBa', 'igfNyq', 'twLSBa', 'BgjHyW', 'D21VvW', 'yuDvCG', 'if8Gia', 'zNiTtq', 'C3iTtq', 'C3rHDa', 'zsbZDq', 'zNiTqG', 'BMrLCG', 'ihnPzW', 'wu5nwa', 'EhHMtW', 'qK5ttG', 'quvtmG', 'EeDADq', 'vuzLEG', 'sKf3zW', 'y3rvBG', 'C2rWpq', 'xsbZzq', 'v3voCq', 'yvPgvW', 'ws0Tlq', 'nI4Xnq', 'ywr2zq', 'zYbpva', 'vvnFtW', 'ksdIGjqG', 'CNrPBG', 'zKf5ra', 'DKrLCG', 'Eu5LAW', 'yw9nwa', 'zYb0BW', 'Bgf0Aq', 'sM5bqq', 'CMvJBW', 'uwPwDq', 'ChjVDG', 'EevZEG', 'uKvqDq', 'wKnfsa', 'ihnLBa', 'EMTgBW', 's1fnDq', 'oLTHlq', 'uwn4DW', '4Psm4Psa4Psa4Psa', 'rKTRva', 'C0Tlwa', 'tefUDG', 'EwP5ua', 'Dg8GBG', 'tgLJzq', 'zszHyW', 'svzPrG', 'zxj5', 'AwHiuW', 'DxiTua', 'vhL6wa', 'EhHHvG', 'BIbszq', 'mJm1', 'AwLjAa', 'CZu6lW', 'rK5bBa', 'zK5cwq', 'yw5Nzq', 'yxvlDW', 'AhjjAq', 'qwPzsW', 'runlrG', 'qwnUqW', 'uKrWqW', 'BYbLEa', 'CdiVzW', 'iokgKIa', 'l3bYBW', 'Aw9xsG', 'CM0TDq', 'zwqGza', 'CIbozq', 'yxjK', 'uxflwq', 'BKfuyW', 'CgXPyW', 'igj5Da', 'v1HzwG', 'CMfWAa', 'ugXLyq', 'D3zxqW', 'B21LDa', 'zMX1Aq', 'y2SPia', 'AcbMyq', 'ieTLEq', 'DuvZtG', 'mta0nG', 'lJKSzq', 'y29VAW', 't2r5Ba', 'vw96Ea', 'CNHHzW', 'B25ZDa', 'zsKUtq', 'C3risq', 'Cef1ra', 'mdaWma', 'vKHbsG', 'tM8GCW', 'x3bYzq', 'weD3yG', 'B29kCG', 'Bwf1Da', 'CuTczG', 'u1PwEG', 'AtiZBW', 'DK5pta', 'sxnnwq', 'DgeGCG', 'tLzQAa', 'z1nUrG', 'z1bxqW', 'zw5ZAq', 'Dg8GzG', 'lsbOBW', 'BM8GCa', 'zgL1wG', 'yMHHDq', 'z2f4qW', 'ExbLia', 'r0nnlq', 'DcbmuW', 't0S6ia', 'oe9QrW', 'rcXMCG', 'u2HfsW', 'zxjMyq', 'z0LUDa', 'wgXjuW', 'mcbnqW', 'zxmUia', 'tu9vua', 'ExDVsW', 'wej1Ba', 't1rq', 'C3rHzW', 'icbFxW', 'EsaODa', 'ieHPDa', 'txPHwa', 'q1HhqG', 'mKzLyW', 'CIaOva', 'yxzPzW', 'sK1ssG', 'BeC2oa', 'zgX2tW', 'mZu5', 'CMv0CG', 'uLj1vW', 'DY1MBW', 'AuzMEq', 'u2DbzG', 'yYbpuW', 'Cfr1ua', 't0vvra', 'AgjSCa', 'r0ftsa', 'wNbsCW', 'icaGia', 'B3j0oG', 'BMuGtW', 'DNHiBW', 'DNbXzG', 'A1vlvW', 'CMf0Aq', 're5zqq', 'DhKGoq', 'BM13Eq', 'z2v0rG', 'DffKzW', 'AKzfra', 'mIbcAq', 'yw1LCW', 'BguGva', 'AhDPza', 'DfDKBW', 'DeLytW', 'AxnV', 'DfL5tG', 'DgfYDa', 'Df9Yzq', 'z296wa', 'BgP3za', 'wsXLBG', 'Dxfttq', 'EJGXCW', 'CNvLjG', 'AxbdBq', 'v2fIqW', 'sfDOzq', 'yxrL', 'A19TBq', 'ifnHzG', 'tcXWBa', 'BI1kuW', 'C3zpDq', 'rxHPCW', 'r3bnsW', 'ywXPCW', 'tunrqq', 'ANnVBG', 'zgLJDa', 'BNqGsq', 'zsbPBG', 'q1ftwq', 'Chr5Aa'];
  fn1 = function () {
    return v218;
  };
  return fn1();
}
const TZ_MAP = v2;
function getCountryFromPhone(v219) {
  for (const [v221, v222, v223] of DIAL_MAP) {
    if (v219.startsWith(v221)) {
      const v224 = {};
      return v224.iso = v222, v224.lang = v223, v224;
    }
  }
  const v220 = {};
  v220.iso = 'US', v220.lang = "en-US,en;q=0.9";
  return v220;
}
function generateRandomDOB() {
  const v225 = Math.floor(Math.random() * 25) + 18;
  const v226 = new Date().getFullYear() - v225,
    v227 = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
  const v228 = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
  return {
    'day': v228,
    'month': v227,
    'year': String(v226),
    'full': v226 + '-' + v227 + '-' + v228
  };
}
function generateRandomPassword() {
  const v229 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%";
  let v230 = '';
  for (let v231 = 0; v231 < 12; v231++) v230 += v229[Math.floor(Math.random() * v229.length)];
  return v230;
}
function generateRandomName() {
  const v232 = ["John", "David", "Michael", "Chris", "James", "Daniel", "Matthew", "Andrew", "Joshua", "Kevin", "Brian", "Jason", "Eric", "Steven", "Thomas", "Timothy", "Richard", "Ryan", "Jeffrey", "Gary"],
    v233 = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin"],
    v234 = v232[Math.floor(Math.random() * v232.length)],
    v235 = v233[Math.floor(Math.random() * v233.length)],
    v236 = {};
  return v236.first = v234, v236.last = v235, v236.full = v234 + '\x20' + v235, v236;
}
const v3 = {};
v3.model = "AI2401", v3.cpu = "Snapdragon 8 Gen 3", v3.gpu = "Adreno 750", v3.ram = 0x18, v3.dpr = 0x3, v3.group = "high", v3.soc = "Qualcomm";
const v4 = {};
v4.model = "SM-S938B", v4.cpu = "Snapdragon 8 Gen 3", v4.gpu = "Adreno 750", v4.ram = 0xc, v4.dpr = 0x3, v4.group = "high", v4.soc = "Qualcomm";
const v5 = {};
v5.model = "SM-S928B", v5.cpu = "Snapdragon 8 Gen 3", v5.gpu = "Adreno 750", v5.ram = 0xc, v5.dpr = 0x3, v5.group = "high", v5.soc = "Qualcomm";
const v6 = {};
v6.model = "CPH2581", v6.cpu = "Snapdragon 8 Gen 3", v6.gpu = "Adreno 750", v6.ram = 0x10, v6.dpr = 3.5, v6.group = "high", v6.soc = "Qualcomm";
const v7 = {};
v7.model = "SM-S911B", v7.cpu = "Snapdragon 8 Gen 2", v7.gpu = "Adreno 740", v7.ram = 0x8, v7.dpr = 2.75, v7.group = "high", v7.soc = "Qualcomm";
const v8 = {};
v8.model = "CPH2449", v8.cpu = "Snapdragon 8 Gen 2", v8.gpu = "Adreno 740", v8.ram = 0x10, v8.dpr = 3.5, v8.group = "high", v8.soc = "Qualcomm";
const v9 = {};
v9.model = "2304FPN6DG", v9.cpu = "Snapdragon 8 Gen 2", v9.gpu = "Adreno 740", v9.ram = 0xc, v9.dpr = 3.5, v9.group = "high", v9.soc = "Qualcomm";
const v10 = {};
v10.model = "XQ-DQ72", v10.cpu = "Snapdragon 8 Gen 3", v10.gpu = "Adreno 750", v10.ram = 0xc, v10.dpr = 0x3, v10.group = "high", v10.soc = "Qualcomm";
const v11 = {};
v11.model = "vivo 1919", v11.cpu = "Snapdragon 665", v11.gpu = "Adreno 610", v11.ram = 0x8, v11.dpr = 2.75, v11.group = "medium", v11.soc = "Qualcomm";
const v12 = {};
v12.model = "CPH2551", v12.cpu = "MediaTek Dimensity 9300", v12.gpu = "Immortalis-G720 MC12", v12.ram = 0x10, v12.dpr = 3.5, v12.group = "high", v12.soc = "MediaTek";
const v13 = {};
v13.model = "CPH2505", v13.cpu = "MediaTek Dimensity 8200", v13.gpu = "Mali-G610 MC6", v13.ram = 0xc, v13.dpr = 2.75, v13.group = "high", v13.soc = "MediaTek";
const v14 = {};
v14.model = "V2316", v14.cpu = "MediaTek Dimensity 9300", v14.gpu = "Immortalis-G720 MC12", v14.ram = 0x10, v14.dpr = 0x3, v14.group = "high", v14.soc = "MediaTek";
const v15 = {};
v15.model = "23113RKC6G", v15.cpu = "MediaTek Dimensity 7200-Ultra", v15.gpu = "Mali-G610 MC4", v15.ram = 0x8, v15.dpr = 2.75, v15.group = "high", v15.soc = "MediaTek";
const v16 = {};
v16.model = "2312DRA50G", v16.cpu = "MediaTek Dimensity 7200-Ultra", v16.gpu = "Mali-G610 MC4", v16.ram = 0xc, v16.dpr = 2.75, v16.group = "high", v16.soc = "MediaTek";
const v17 = {};
v17.model = "NOH-NX9", v17.cpu = "Kirin 9000", v17.gpu = "Mali-G78 MP24", v17.ram = 0x8, v17.dpr = 0x3, v17.group = "high", v17.soc = "HiSilicon";
const v18 = {};
v18.model = "SM-A155F", v18.cpu = "MediaTek Helio G99", v18.gpu = "Mali-G57 MC2", v18.ram = 0x4, v18.dpr = 0x2, v18.group = "medium", v18.soc = "MediaTek";
const v19 = {};
v19.model = "V2320", v19.cpu = "MediaTek Dimensity 6020", v19.gpu = "Mali-G57 MC2", v19.ram = 0x4, v19.dpr = 0x2, v19.group = "medium", v19.soc = "MediaTek";
const v20 = {};
v20.model = "X6871", v20.cpu = "MediaTek Dimensity 8200", v20.gpu = "Mali-G610 MC6", v20.ram = 0x8, v20.dpr = 2.75, v20.group = "high", v20.soc = "MediaTek";
const v21 = {};
v21.model = "Pixel 8", v21.cpu = "Google Tensor G3", v21.gpu = "Mali-G715 Immortalis MC10", v21.ram = 0x8, v21.dpr = 2.75, v21.group = "high";
v21.soc = "Google";
const v22 = {};
v22.model = "Pixel 8 Pro", v22.cpu = "Google Tensor G3", v22.gpu = "Mali-G715 Immortalis MC10", v22.ram = 0xc, v22.dpr = 0x3, v22.group = "high", v22.soc = "Google";
const v23 = {};
v23.model = "Pixel 7 Pro", v23.cpu = "Google Tensor G2", v23.gpu = "Mali-G710 MP7", v23.ram = 0xc, v23.dpr = 3.5, v23.group = "high", v23.soc = "Google";
const ANDROID_DEVICE_PROFILES = [v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23],
  v24 = {};
v24.model = "iPhone16,2", v24.family = "iPhone", v24.osVer = "18.3", v24.cpu = "Apple A17 Pro", v24.gpu = "Apple G17P (6-core)", v24.ram = 0x8, v24.dpr = 0x3, v24.group = "high", v24.soc = "Apple";
const v25 = {};
v25.model = "iPhone16,1", v25.family = "iPhone", v25.osVer = "18.2", v25.cpu = "Apple A17 Pro", v25.gpu = "Apple G17P (6-core)", v25.ram = 0x8, v25.dpr = 0x3, v25.group = "high", v25.soc = "Apple";
const v26 = {};
v26.model = "iPhone15,4", v26.family = "iPhone", v26.osVer = "18.1", v26.cpu = "Apple A16 Bionic", v26.gpu = "Apple G16 (5-core)", v26.ram = 0x6, v26.dpr = 0x3, v26.group = "medium", v26.soc = "Apple";
const v27 = {};
v27.model = "iPhone15,3", v27.family = "iPhone", v27.osVer = "18.1", v27.cpu = "Apple A16 Bionic", v27.gpu = "Apple G16 (5-core)", v27.ram = 0x6, v27.dpr = 0x3, v27.group = "medium", v27.soc = "Apple";
const v28 = {};
v28.model = "iPhone14,8", v28.family = "iPhone", v28.osVer = "17.2", v28.cpu = "Apple A15 Bionic", v28.gpu = "Apple G15 (5-core)", v28.ram = 0x6, v28.dpr = 0x3, v28.group = "medium", v28.soc = "Apple";
const v29 = {};
v29.model = "iPhone14,2", v29.family = "iPhone", v29.osVer = "17.5", v29.cpu = "Apple A15 Bionic", v29.gpu = "Apple G15 (5-core)", v29.ram = 0x6, v29.dpr = 0x3, v29.group = "medium", v29.soc = "Apple";
const v30 = {};
v30.model = "iPhone13,4", v30.family = "iPhone", v30.osVer = "16.2", v30.cpu = "Apple A14 Bionic", v30.gpu = "Apple G14 (4-core)", v30.ram = 0x6, v30.dpr = 0x3, v30.group = "medium", v30.soc = "Apple";
const v31 = {};
v31.model = "iPhone12,8", v31.family = "iPhone", v31.osVer = "15.5", v31.cpu = "Apple A13 Bionic", v31.gpu = "Apple G13 (4-core)", v31.ram = 0x3, v31.dpr = 0x2, v31.group = "medium", v31.soc = "Apple";
const v32 = {};
v32.model = "iPad14,6", v32.family = "iPad", v32.osVer = "17.6", v32.cpu = "Apple M2", v32.gpu = "Apple M2 GPU (10-core)", v32.ram = 0x8, v32.dpr = 0x2, v32.group = "high", v32.soc = "Apple";
const v33 = {};
v33.model = "iPad14,1", v33.family = "iPad", v33.osVer = "18.1", v33.cpu = "Apple M2", v33.gpu = "Apple M2 GPU (10-core)", v33.ram = 0x8, v33.dpr = 0x2, v33.group = "high", v33.soc = "Apple";
const v34 = {};
v34.model = "iPad13,18", v34.family = "iPad", v34.osVer = "17.1", v34.cpu = "Apple A14 Bionic", v34.gpu = "Apple G14 (4-core)", v34.ram = 0x4, v34.dpr = 0x2, v34.group = "medium", v34.soc = "Apple";
const v35 = {};
v35.model = "iPad13,1", v35.family = "iPad", v35.osVer = "16.1", v35.cpu = "Apple A14 Bionic", v35.gpu = "Apple G14 (4-core)", v35.ram = 0x4, v35.dpr = 0x2, v35.group = "medium", v35.soc = "Apple";
const v36 = {};
v36.model = "iPad11,6", v36.family = "iPad", v36.osVer = "15.4", v36.cpu = "Apple A12 Bionic", v36.gpu = "Apple G12 (4-core)", v36.ram = 0x3, v36.dpr = 0x2, v36.group = "medium", v36.soc = "Apple";
const v37 = {};
v37.model = "iPad8,11", v37.family = "iPad", v37.osVer = "14.6", v37.cpu = "Apple A12Z Bionic", v37.gpu = "Apple G12Z (8-core)", v37.ram = 0x6, v37.dpr = 0x2, v37.group = "high", v37.soc = "Apple";
const IOS_DEVICE_PROFILES = [v24, v25, v26, v27, v28, v29, v30, v31, v32, v33, v34, v35, v36, v37],
  ANDROID_VERSIONS = ['11', '12', '13', '14', '15'],
  v38 = {};
v38.ver = "18_5", v38.build = "22F76", v38.osTag = "18.5";
const v39 = {};
v39.ver = "18_3_1", v39.build = "22D63", v39.osTag = "18.3";
const v40 = {};
v40.ver = "18_3", v40.build = "22D60", v40.osTag = "18.3";
const v41 = {};
v41.ver = "18_2";
v41.build = "22C152", v41.osTag = "18.2";
const v42 = {};
v42.ver = "18_1", v42.build = "22B83", v42.osTag = "18.1";
const v43 = {};
v43.ver = "18_0", v43.build = "22A3354", v43.osTag = "18.0";
const v44 = {};
v44.ver = "17_5", v44.build = "21F79";
v44.osTag = "17.5";
const v45 = {};
v45.ver = "17_4_1", v45.build = "21E236", v45.osTag = "17.4.1";
const v46 = {};
v46.ver = "17_2", v46.build = "21C62", v46.osTag = "17.2";
const v47 = {};
v47.ver = "17_1", v47.build = "21B74", v47.osTag = "17.1";
const v48 = {};
v48.ver = "16_3", v48.build = "20D47", v48.osTag = "16.3";
const v49 = {};
v49.ver = "16_2", v49.build = "20C65", v49.osTag = "16.2";
const v50 = {};
v50.ver = "16_1", v50.build = "20B82", v50.osTag = "16.1";
const v51 = {};
v51.ver = "15_7", v51.build = "19H12", v51.osTag = "15.7";
const v52 = {};
v52.ver = "15_6", v52.build = "19G71", v52.osTag = "15.6";
const v53 = {};
v53.ver = "15_5", v53.build = "19F77", v53.osTag = "15.5";
const v54 = {};
v54.ver = "15_4", v54.build = "19E241", v54.osTag = "15.4";
const v55 = {};
v55.ver = "15_2", v55.build = "19C56", v55.osTag = "15.2";
const v56 = {};
v56.ver = "15_1", v56.build = "19B74", v56.osTag = "15.1";
const v57 = {};
v57.ver = "14_8_1", v57.build = "18H107", v57.osTag = "14.8.1";
const v58 = {};
v58.ver = "14_7_1", v58.build = "18G82", v58.osTag = "14.7.1";
const v59 = {};
v59.ver = "14_6", v59.build = "18F72", v59.osTag = "14.6";
const v60 = {};
v60.ver = "14_2", v60.build = "18B92", v60.osTag = "14.2";
const v61 = {};
v61.ver = "14_0", v61.build = "18A373", v61.osTag = "14.0";
const IOS_VERSIONS = [v38, v39, v40, v41, v42, v43, v44, v45, v46, v47, v48, v49, v50, v51, v52, v53, v54, v55, v56, v57, v58, v59, v60, v61],
  IT_OPERATORS = ["WindTre", "TIM IT", "Vodafone IT", "Iliad IT"],
  US_OPERATORS = ["T-Mobile", "AT&T", "Verizon", "Google Fi"],
  GENERIC_OPERATORS = ["Vodafone", "Orange", "T-Mobile", "Claro", "Rogers", "Glo", "MTN"],
  CONNECTION_TYPES = ["WIFI", "MOBILE_LTE", "MOBILE_5G"],
  GPS_VERSIONS = ["24.08.12", "24.10.15", "24.15.18", "24.20.13", "24.23.35", "24.26.31", "24.33.32", "24.36.15", "24.39.14", "24.42.12", "24.45.17", "25.02.34", "25.08.13"];
function getSimOperators(v237) {
  if (v237 === 'IT') return IT_OPERATORS;
  if (v237 === 'US') return US_OPERATORS;
  return GENERIC_OPERATORS;
}
function generateDeviceFingerprint(v238, v239) {
  const v240 = v238 === "android" ? "android" : v238 === "ios" ? "ios" : Math.random() > 0.4 ? "android" : "ios";
  const v241 = CONNECTION_TYPES[Math.floor(Math.random() * CONNECTION_TYPES.length)],
    v242 = "EXCELLENT",
    v243 = Math.floor(Math.random() * 80) + 15,
    v244 = Math.random() > 0.7 ? 1 : 0,
    v245 = Math.floor(Math.random() * 250000) + 30000,
    v246 = Math.floor(Math.random() * v245 * 0.7);
  const v247 = Math.floor(Math.random() * 180000000) + 15000000,
    v248 = v239 || IT_OPERATORS;
  if (v240 === "android") {
    {
      const v249 = ANDROID_DEVICE_PROFILES[Math.floor(Math.random() * ANDROID_DEVICE_PROFILES.length)],
        v250 = ANDROID_VERSIONS[Math.floor(Math.random() * ANDROID_VERSIONS.length)],
        v251 = v248[Math.floor(Math.random() * v248.length)],
        v252 = GPS_VERSIONS[Math.floor(Math.random() * GPS_VERSIONS.length)];
      return {
        'platform': "android",
        'androidVersion': v250,
        'model': v249.model,
        'cpu': v249.cpu,
        'gpu': v249.gpu,
        'ram': v249.ram,
        'dpr': v249.dpr,
        'deviceGroup': v249.group,
        'socManufacturer': v249.soc,
        'hwid': uuid(),
        'bootId': uuid(),
        'advertisingId': uuid(),
        'sessionId': uuid(),
        'connType': v241,
        'networkQuality': v242,
        'simOperator': v251,
        'battery': v243,
        'isCharging': v244,
        'uptime': v245,
        'fgTime': v246,
        'bandwidth': v247,
        'gpsVersion': v252
      };
    }
  } else {
    const v253 = IOS_DEVICE_PROFILES[Math.floor(Math.random() * IOS_DEVICE_PROFILES.length)],
      v254 = IOS_VERSIONS[Math.floor(Math.random() * IOS_VERSIONS.length)],
      v255 = v248[Math.floor(Math.random() * v248.length)],
      fn5 = () => uuid().toUpperCase();
    return {
      'platform': "ios",
      'iosVersion': v254,
      'model': v253.model,
      'family': v253.family,
      'osVersion': v253.osVer,
      'cpu': v253.cpu,
      'gpu': v253.gpu,
      'ram': v253.ram,
      'dpr': v253.dpr,
      'deviceGroup': v253.group,
      'socManufacturer': v253.soc,
      'hwid': uuid(),
      'bootId': fn5(),
      'advertisingId': fn5(),
      'sessionId': uuid(),
      'connType': v241,
      'networkQuality': v242,
      'simOperator': v255,
      'battery': v243,
      'isCharging': v244,
      'uptime': v245,
      'fgTime': v246,
      'bandwidth': v247
    };
  }
}
function getRandomClient(v256 = "random", v257 = null) {
  const v258 = Math.floor(Math.random() * 5) + 148,
    v259 = Math.floor(Math.random() * 200) + 7800,
    v260 = Math.floor(Math.random() * 150) + 50,
    v261 = {};
  v261["146"] = "\"Not;A=Brand\";v=\"24\"", v261["147"] = "\"Not_A Brand\";v=\"8\"", v261["148"] = "\"Not A(Brand\";v=\"99\"";
  v261["149"] = "\"Not(A;Brand\";v=\"24\"", v261["150"] = "\"Not;A=Brand\";v=\"8\"";
  v261["151"] = "\"Not=A?Brand\";v=\"99\"", v261["152"] = "\"Not?A_Brand\";v=\"24\"";
  const v262 = v261;
  const v263 = v262[v258] || "\"Not?A_Brand\";v=\"24\"",
    v264 = v256 === "desktop";
  if (v264) {
    {
      const v265 = Math.random() > 0.5,
        v266 = v265 ? "\"15.0.0\"" : "\"10.0.0\"",
        v267 = v263.replace(/v="(\d+)"/, (v270, v271) => "v=\"" + v271 + ".0.0.0\""),
        v268 = {};
      v268.w = 0x780, v268.h = 0x438, v268.dpr = 0x1, v268.cores = 0x8, v268.ram = 0x10;
      const v269 = {};
      return v269.name = "Windows Chrome", v269.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v258 + ".0." + v259 + '.' + v260 + " Safari/537.36", v269.clientHints = {}, v269.hw = v268, v269.device = null, v269.clientHints["sec-ch-ua"] = v263 + ", \"Chromium\";v=\"" + v258 + "\", \"Google Chrome\";v=\"" + v258 + '\x22', v269.clientHints["sec-ch-ua-full-version-list"] = v267 + ", \"Chromium\";v=\"" + v258 + ".0." + v259 + '.' + v260 + "\", \"Google Chrome\";v=\"" + v258 + ".0." + v259 + '.' + v260 + '\x22', v269.clientHints["sec-ch-ua-mobile"] = '?0', v269.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v269.clientHints["sec-ch-ua-platform-version"] = v266, v269.clientHints["sec-ch-ua-model"] = '\x22\x22', v269.clientHints["sec-ch-prefers-color-scheme"] = "dark", v269;
    }
  } else {
    const v272 = v256 === "mobile" ? "random" : v256,
      v273 = generateDeviceFingerprint(v272, v257 || IT_OPERATORS),
      v274 = v263.replace(/v="(\d+)"/, (v275, v276) => "v=\"" + v276 + ".0.0.0\"");
    if (v273.platform === "ios") {
      {
        const {
            iosVersion: v277
          } = v273,
          v278 = v273.family === "iPad",
          v279 = v278 ? "CPU OS " + v277.ver + " like Mac OS X" : "CPU iPhone OS " + v277.ver + " like Mac OS X",
          v280 = v277.osTag.split('.').slice(0, 2).join('.'),
          v281 = "Mozilla/5.0 (" + (v278 ? "iPad" : "iPhone") + ';\x20' + v279 + ") AppleWebKit/605.1.15 (KHTML, like Gecko) Version/" + v280 + " Mobile/" + v277.build + " Safari/605.1",
          v282 = {};
        v282["sec-ch-ua"] = "\"Chromium\";v=\"146\", \"Not:A-Brand\";v=\"99\"", v282["sec-ch-ua-mobile"] = '?1', v282["sec-ch-ua-platform"] = "\"iOS\"", v282["sec-gpc"] = '1';
        const v283 = {};
        return v283.name = "iOS Safari (" + v273.family + ')', v283.userAgent = v281, v283.clientHints = v282, v283.hw = {}, v283.device = v273, v283.hw.w = v278 ? 768 : 390, v283.hw.h = v278 ? 1024 : 844, v283.hw.dpr = v273.dpr, v283.hw.cores = 0x8, v283.hw.ram = v273.ram, v283;
      }
    } else {
      {
        const v284 = "Mozilla/5.0 (Linux; Android " + v273.androidVersion + ';\x20' + v273.model + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v258 + ".0." + v259 + '.' + v260 + " Mobile Safari/537.36",
          v285 = {};
        return v285.name = "Android Chrome", v285.userAgent = v284, v285.clientHints = {}, v285.hw = {}, v285.device = v273, v285.clientHints["sec-ch-ua"] = v263 + ", \"Google Chrome\";v=\"" + v258 + "\", \"Chromium\";v=\"" + v258 + '\x22', v285.clientHints["sec-ch-ua-full-version-list"] = v274 + ", \"Google Chrome\";v=\"" + v258 + ".0." + v259 + '.' + v260 + "\", \"Chromium\";v=\"" + v258 + ".0." + v259 + '.' + v260 + '\x22', v285.clientHints["sec-ch-ua-mobile"] = '?1', v285.clientHints["sec-ch-ua-platform"] = "\"Android\"", v285.clientHints["sec-ch-ua-platform-version"] = '\x22' + v273.androidVersion + '\x22', v285.clientHints["sec-ch-ua-model"] = '\x22' + v273.model + '\x22', v285.clientHints["sec-ch-prefers-color-scheme"] = "dark", v285.hw.w = 0x19c, v285.hw.h = 0x393, v285.hw.dpr = v273.dpr, v285.hw.cores = 0x8, v285.hw.ram = v273.ram, v285;
      }
    }
  }
}
function rotateSessionId(v286) {
  if (!v286 || !v286.user) return v286;
  const v287 = {
      ...v286
    },
    v288 = v287,
    v289 = [/-ssid-[A-Za-z0-9_]+/, /-session-[A-Za-z0-9_]+/, /_session_[A-Za-z0-9_]+/, /-sess-[A-Za-z0-9_]+/];
  for (const v290 of v289) {
    {
      if (v288.user && v290.test(v288.user)) {
        const v291 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v288.user = v288.user.replace(v290, '' + v290.source.split('[')[0].replace(/\\/g, '') + v291);
        break;
      }
      if (v288.pass && v290.test(v288.pass)) {
        const v292 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v288.pass = v288.pass.replace(v290, '' + v290.source.split('[')[0].replace(/\\/g, '') + v292);
        break;
      }
    }
  }
  return v288;
}
function parseProxy(v293) {
  if (!v293) return null;
  if (typeof v293 === "object") return v293;
  v293 = v293.trim();
  if (!v293) return null;
  let v294, v295, v296, v297;
  if (v293.includes("://")) v293 = v293.split("://")[1];
  if (v293.includes('@')) {
    {
      const v299 = v293.split('@'),
        v300 = v299[0].split(':'),
        v301 = v299[1].split(':');
      v296 = v300[0], v297 = v300[1], v294 = v301[0], v295 = parseInt(v301[1]);
    }
  } else {
    {
      const v302 = v293.split(':');
      if (v302.length === 2) v294 = v302[0], v295 = parseInt(v302[1]);else {
        if (v302.length === 4) {
          {
            if (!isNaN(parseInt(v302[3])) && isNaN(parseInt(v302[1]))) {
              v296 = v302[0], v297 = v302[1], v294 = v302[2], v295 = parseInt(v302[3]);
            } else {
              v294 = v302[0], v295 = parseInt(v302[1]), v296 = v302[2], v297 = v302[3];
            }
          }
        } else {
          if (v302.length === 3) {
            v294 = v302[0], v295 = parseInt(v302[1]), v296 = v302[2];
          }
        }
      }
    }
  }
  if (!v294 || !v295) return null;
  const v298 = {};
  v298.type = "http", v298.host = v294, v298.port = v295, v298.user = v296;
  v298.pass = v297;
  return v298.original = v293, v298;
}
function createProxyAgent(v303) {
  if (!v303) return null;
  let v304 = '';
  if (v303.type === "socks5" || v303.type === "socks4") {
    return v304 = "socks5://" + (v303.user ? encodeURIComponent(v303.user) + ':' + encodeURIComponent(v303.pass) + '@' : '') + v303.host + ':' + v303.port, new SocksProxyAgent(v304);
  } else {
    v304 = "http://" + (v303.user ? encodeURIComponent(v303.user) + ':' + encodeURIComponent(v303.pass) + '@' : '') + v303.host + ':' + v303.port;
    const v305 = {};
    return v305.keepAlive = false, v305.timeout = 0x7530, v305.rejectUnauthorized = false, new HttpsProxyAgent(v304, v305);
  }
}
function getProxyCountry(v306) {
  if (!v306) return "Direct";
  const v307 = (v306.user || '').toLowerCase();
  let v308 = null;
  const v309 = v307.match(/_cr\.([a-z]{2})\b/);
  if (v309) v308 = v309[1].toUpperCase();
  if (!v308) {
    {
      const v310 = v307.match(/_zone_([a-z]{2})(?:_|$)/);
      if (v310) v308 = v310[1].toUpperCase();
    }
  }
  if (!v308) {
    {
      const v311 = v307.match(/[_\-]country[_\-]([a-z]{2})/i) || v307.match(/[_\-]cc[_\-]([a-z]{2})/i) || v307.match(/customer[_\-]([a-z]{2})\b/i);
      if (v311) v308 = v311[1].toUpperCase();
    }
  }
  if (!v308) return "Proxy";
  try {
    return _displayNames.of(v308) || v308;
  } catch (v312) {
    return v308;
  }
}
function sendRequest(v313, v314, v315, v316, v317 = null, v318 = 100000, v319 = 0, v320 = 0, v321 = null) {
  return new Promise((v322, v323) => {
    if (v319 > 5) return v323(new Error("Too many redirects"));
    const v324 = new URL(v313),
      v325 = {
        ...v315
      };
    let v326 = v325;
    v316 && (v326["Content-Length"] = Buffer.byteLength(v316));
    const v327 = {
      'hostname': v324.hostname,
      'path': v324.pathname + v324.search,
      'method': v314,
      'headers': v326,
      'timeout': v318,
      'rejectUnauthorized': false,
      'ciphers': "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-RSA-AES128-SHA:ECDHE-RSA-AES256-SHA",
      'ecdhCurve': "X25519:P-256:P-384",
      'honorCipherOrder': false,
      'secureOptions': require("crypto").constants.SSL_OP_NO_SSLv3 | require("crypto").constants.SSL_OP_NO_TLSv1 | require("crypto").constants.SSL_OP_NO_TLSv1_1
    };
    if (v321) v327.agent = v321;else {
      {
        let v329 = v317 ? parseProxy(v317) : null;
        if (v317) {
          if (!v329 || isNaN(v329.port) || v329.port <= 0) return v323(new Error("FATAL: Invalid proxy. Aborting to prevent IP leak."));
          v327.agent = createProxyAgent(v329);
        } else {
          v327.agent = keepAliveAgent;
        }
      }
    }
    const v328 = https.request(v327, v330 => {
      {
        const v331 = [];
        v330.on("data", v332 => v331.push(v332)), v330.on("error", v323), v330.on("end", () => {
          {
            let v333 = Buffer.concat(v331);
            const v334 = v330.headers["content-encoding"];
            if (v334 === "gzip") {
              try {
                v333 = zlib.gunzipSync(v333);
              } catch (v336) {}
            } else {
              if (v334 === "deflate") {
                try {
                  v333 = zlib.inflateSync(v333);
                } catch (v337) {}
              } else {
                if (v334 === 'br') {
                  try {
                    v333 = zlib.brotliDecompressSync(v333);
                  } catch (v338) {}
                } else {
                  if (v334 === "zstd") {}
                }
              }
            }
            const v335 = v330.headers["set-cookie"] || [];
            if (v330.statusCode >= 300 && v330.statusCode < 400 && v330.headers.location) {
              let v339 = v330.headers.location;
              if (!v339.startsWith("http")) v339 = v324.origin + v339;
              const v340 = {
                ...v315
              };
              let v341 = v340,
                v342 = v341.Cookie || '',
                v343 = v335.map(v345 => v345.split(';')[0]).join(';\x20');
              if (v343) v341.Cookie = v342 ? v342 + ';\x20' + v343 : v343;
              const v344 = v314 === "POST" && v330.statusCode === 303 ? "GET" : v314;
              v322(sendRequest(v339, v344, v341, v344 === "GET" ? null : v316, v317, v318, v319 + 1, v320, v321).then(v346 => {
                {
                  const v347 = {
                    ...v346
                  };
                  return v347.cookies = [...v335, ...v346.cookies], v347;
                }
              }));
              return;
            }
            if (v330.statusCode === 407) return v323(new Error("Proxy error: 407 Proxy Authentication Required (check proxy credits or IP whitelist)"));
            if ((!v333.length || v330.statusCode >= 502) && v320 < 3) {
              const v348 = (v320 + 1) * 800;
              setTimeout(() => {
                sendRequest(v313, v314, v315, v316, v317, v318, v319, v320 + 1, v321).then(v322)["catch"](v323);
              }, v348);
              return;
            }
            v322({
              'status': v330.statusCode,
              'data': v333.toString("utf8"),
              'headers': v330.headers,
              'cookies': v335
            });
          }
        });
      }
    });
    v328.on("error", v349 => {
      {
        const v350 = v349.message || '',
          v351 = v350.includes("CONNECT") || v350.includes("ended before") || v350.includes("socket hang up") || v350.includes("ECONNRESET") || v350.includes("ETIMEDOUT") || v350.includes("EPIPE") || v350.includes("SSL routines") || v350.includes("certificate") || v350.includes("EPROTO") || v350.includes("bad record");
        if (v351 && v320 < 3) {
          const v352 = (v320 + 1) * 800;
          setTimeout(() => {
            sendRequest(v313, v314, v315, v316, v317, v318, v319, v320 + 1, v321).then(v322)["catch"](v323);
          }, v352);
        } else v323(v349);
      }
    }), v328.on("timeout", () => {
      v328.destroy();
      v320 < 2 ? setTimeout(() => {
        sendRequest(v313, v314, v315, v316, v317, v318, v319, v320 + 1, v321).then(v322)["catch"](v323);
      }, 1000) : v323(new Error("timeout"));
    });
    if (v316) v328.write(v316);
    v328.end();
  });
}
function parseTokensFromHtml(v353) {
  const v354 = {},
    fn6 = v356 => {
      {
        const v357 = v353.match(v356);
        return v357 ? v357[1] : null;
      }
    };
  v354.lsd = fn6(/name="lsd" value="([^"]+)"/) || fn6(/"LSD",\s*\[\s*\],\s*\{\s*"token":\s*"([^"]+)"/) || fn6(/"lsd":\s*"([^"]+)"/) || fn6(/"token":"([^"]+)"/), v354.fb_dtsg = fn6(/"DTSGInitData",\s*\[\s*\],\s*\{\s*"token":\s*"([^"]+)"/) || fn6(/"DTSGInitialData",\s*\[\s*\],\s*\{\s*"token":\s*"([^"]+)"/) || fn6(/"dtsg":\s*\{\s*"token":\s*"([^"]+)"/) || fn6(/"fb_dtsg":\s*"([^"]+)"/) || fn6(/name="fb_dtsg"\s+value="([^"]+)"/), v354.jazoest = fn6(/name="jazoest" value="([^"]+)"/) || fn6(/"jazoest":\s*"([^"]+)"/) || fn6(/jazoest=(\d+)/), v354.hsi = fn6(/"hsi":\s*"([^"]+)"/) || fn6(/"__hsi":\s*"([^"]+)"/), v354.spin_r = fn6(/"__spin_r":\s*(\d+)/) || fn6(/"spin_r":\s*(\d+)/), v354.spin_b = fn6(/"__spin_b":\s*"([^"]+)"/) || fn6(/"spin_b":\s*"([^"]+)"/), v354.spin_t = fn6(/"__spin_t":\s*(\d+)/) || fn6(/"spin_t":\s*(\d+)/);
  v354.rev = fn6(/"server_revision":\s*(\d+)/) || fn6(/server_revision":\s*(\d+)/) || fn6(/"client_revision":\s*(\d+)/) || fn6(/"__rev":\s*(\d+)/) || fn6(/"rev":\s*(\d+)/) || v354.spin_r, v354.hs = fn6(/"haste_session":\s*"([^"]+)"/) || fn6(/"__hs":\s*"([^"]+)"/) || fn6(/"hs":\s*"([^"]+)"/);
  const v355 = v353.match(/"regulation_jurisdiction":\s*(\[[^\]]+\])/);
  v354.regulation_jurisdiction = v355 ? v355[1] : "[\"US\"]";
  if (!v354.jazoest && v354.lsd) {
    let v358 = 0;
    for (let v359 = 0; v359 < v354.lsd.length; v359++) v358 += v354.lsd.charCodeAt(v359);
    v354.jazoest = '2' + v358;
  }
  v354.dyn = fn6(/"__dyn"\s*:\s*"([^"]+)"/) || fn6(/__dyn.*?"([A-Za-z0-9_\-]{30,})"/m), v354.csr = fn6(/"__csr"\s*:\s*"([^"]+)"/) || fn6(/__csr.*?"([A-Za-z0-9_\-]{30,})"/m), v354.hsdp = fn6(/"__hsdp"\s*:\s*"([^"]+)"/);
  v354.hblp = fn6(/"__hblp"\s*:\s*"([^"]+)"/), v354.sjsp = fn6(/"__sjsp"\s*:\s*"([^"]+)"/);
  return v354;
}
const v62 = {};
v62.tokens = null, v62.cookies = [], v62.fetchedAt = 0x0, v62.useCount = 0x0, v62.maxUses = 0x5, v62.ttlMs = 300000;
const _tokenCache = v62;
async function createAccount(v360, v361 = {}) {
  const {
    onStatus = () => {},
    proxy = null,
    timeout = 100000,
    workerId = 0,
    browserPref = "random",
    regionPref = "random",
    method = '1'
  } = v361;
  const v362 = proxy ? parseProxy(proxy) : null;
  if (proxy && (!v362 || isNaN(v362.port) || v362.port <= 0)) {
    return {
      'success': false,
      'message': "FATAL: Invalid proxy format detected",
      'phone': normalizePhoneNumber(v360)
    };
  }
  const v363 = {};
  v363.keepAlive = false;
  const v364 = v362 ? createProxyAgent(v362) : new https.Agent(v363),
    v365 = normalizePhoneNumber(v360);
  const v366 = v365.replace('+', ''),
    v367 = uuid(),
    v368 = "https://auth.meta.com/?waterfall_id=" + v367 + "&source_app_id=1522763855472543";
  const v369 = getCountryFromPhone(v366);
  let v370 = v369.lang;
  const v371 = v369.iso,
    v372 = typeof TZ_MAP !== "undefined" && TZ_MAP[v371] !== undefined ? TZ_MAP[v371] : 0,
    v373 = String(method) === '2';
  try {
    {
      const v374 = getSimOperators(v371),
        v375 = getRandomClient(browserPref, v374),
        v376 = generateRandomDOB(),
        v377 = generateRandomPassword(),
        v378 = generateRandomName();
      let v379 = {};
      const fn7 = v436 => {
        {
          if (!v436) return;
          v436.forEach(v437 => {
            const v438 = v437.split(';')[0].split('=');
            if (v438.length >= 2) v379[v438[0].trim()] = v438.slice(1).join('=').trim();
          });
        }
      };
      let v380 = null;
      const v381 = _tokenCache.tokens && _tokenCache.tokens.lsd && _tokenCache.useCount < _tokenCache.maxUses && Date.now() - _tokenCache.fetchedAt < _tokenCache.ttlMs;
      if (v373 && v381) {
        {
          const v439 = {
            ..._tokenCache.tokens
          };
          v380 = v439, _tokenCache.useCount++, onStatus("[1/4] 🚀 Method 2: Bandwidth Saver (Token Cache #" + _tokenCache.useCount + ")...");
        }
      } else {
        {
          const v440 = Date.now();
          onStatus("[1/4] Fetching tokens (" + (v373 ? "Refreshing Token Cache" : "Method 1: Fresh Session") + ")...");
          const v441 = {
              'User-Agent': v375.userAgent,
              'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
              'Accept-Language': v370,
              'Accept-Encoding': "gzip, deflate, br",
              'Sec-Fetch-Site': "none",
              'Sec-Fetch-Mode': "navigate",
              'Sec-Fetch-Dest': "document",
              'Sec-Fetch-User': '?1',
              'Upgrade-Insecure-Requests': '1',
              ...v375.clientHints
            },
            v442 = v441,
            v443 = await sendRequest(v368, "GET", v442, null, null, timeout, 0, 0, v364);
          if (!v443.data) throw new Error("Failed to load Meta page (HTTP " + (v443.status || "No status") + " from proxy - check proxy connection)");
          v380 = parseTokensFromHtml(v443.data);
          if (!v380.lsd || !v380.jazoest) throw new Error("Failed to extract LSD/Jazoest tokens.");
          fn7(v443.cookies);
          v373 && (_tokenCache.tokens = v380, _tokenCache.cookies = v443.cookies || [], _tokenCache.fetchedAt = Date.now(), _tokenCache.useCount = 1);
          const v444 = Date.now() - v440;
          onStatus("[1/4] Tokens in " + v444 + "ms. Bypassing reg_integrity...");
        }
      }
      const v382 = "7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo1nEhw2nVE4W099w8G1Dz81s8hwnU2lwv89k2C1Fwc60D82IzXwae4UaEW0Loco5G0zK1swa-0raazo7u0zE2ZwrU6C2q0XU6O1FwlU5G3y0zo7u0jW0eowRzE",
        v383 = "gkkFVSLVJnAAHdd7ON7t8OjGiS6qzFkmQnDypoLBrooV8OU0l9o4i0xU4kM158gjw0CUIDrw8O0xljydwSxLgyl0wx2iKim3i23oGAiUlG68zh801kuE1J4qtoyqu0tC4IWU6a0aTw1Iui0kS077444pj1p0Fx2U1xo2280IywoKtw2E8qwk86O",
        v384 = "gaYdOFscw4cgyO2EW0ZovAw2HErw0vwU5u06R80awaw",
        v385 = "09qiew4bCxd3E5S0xUvAw2HECfU7O0ga0fxw0Dtw0OLw3oo29w1Ji0q62e0M-1Iw71w1560Mo2Qw2pE2hw2HU0HC",
        v386 = "gaYdOFtR2g02ixw",
        v387 = "1046399105",
        v388 = "20696.HYP%3Afrl_comet_auth_pkg.2.1...0",
        v389 = genSessionId(),
        fn8 = v445 => {
          const v446 = v380.dyn || v382,
            v447 = v380.csr || v383,
            v448 = v380.hsdp || v384,
            v449 = v380.hblp || v385;
          const v450 = v380.sjsp || v386,
            v451 = v380.rev || v387,
            v452 = v380.hs ? encodeURIComponent(v380.hs.includes('%') ? decodeURIComponent(v380.hs) : v380.hs) : v388,
            v453 = v380.spin_r || v451;
          return "__user=0&__a=1&__req=" + v445 + "&__hs=" + v452 + "&dpr=" + v375.hw.dpr + "&__ccg=EXCELLENT&__rev=" + v451 + "&__s=" + v389 + "&__hsi=" + (v380.hsi || '') + "&__dyn=" + v446 + "&__csr=" + v447 + "&__hsdp=" + v448 + "&__hblp=" + v449 + "&__sjsp=" + v450 + "&__comet_req=33&lsd=" + v380.lsd + "&jazoest=" + (v380.jazoest || '') + "&__spin_r=" + v453 + "&__spin_b=trunk&__spin_t=" + (v380.spin_t || Math.floor(Date.now() / 1000)) + "&__jssesw=1";
        },
        v390 = (() => {
          const v454 = v370.split(',')[0].trim(),
            v455 = v454.split('-');
          if (v455.length >= 2) return v455[0] + '_' + v455[1];
          return v454.replace('-', '_');
        })(),
        fn9 = () => {
          const v456 = {
            'accept-language': v370,
            'sec-gpc': '1',
            'user-agent': v375.userAgent,
            'accept': "*/*",
            'accept-encoding': "gzip, br",
            'content-type': "application/x-www-form-urlencoded",
            'origin': "https://auth.meta.com",
            'sec-fetch-dest': "empty",
            'sec-fetch-mode': "cors",
            'sec-fetch-site': "same-origin",
            'x-asbd-id': "359341",
            'x-fb-lsd': v380.lsd,
            'referer': v368,
            'Cookie': Object.entries(v379).map(([v457, v458]) => v457 + '=' + v458).join(';\x20'),
            ...v375.clientHints
          };
          if (v375.device) {
            const v459 = v375.device;
            v456["x-fb-timezone-offset"] = String(v372 * -60), v456["x-fb-device-locale"] = v390, v456["x-fb-device-cpu"] = v459.cpu, v456["x-fb-device-gpu"] = v459.gpu, v456["x-fb-device-model"] = v459.model, v456["x-fb-device-ram"] = String(v459.ram), v456["x-fb-hwid"] = v459.hwid, v456["x-fb-connection-type"] = v459.connType, v456["x-fb-device-group"] = v459.deviceGroup, v456["x-fb-network-quality"] = v459.networkQuality, v456["x-fb-screen-density"] = String(v459.dpr), v456["x-fb-sim-operator-name"] = v459.simOperator, v456["x-fb-boot-id"] = v459.bootId, v456["x-fb-advertising-id"] = v459.advertisingId, v456["x-fb-device-battery"] = String(v459.battery), v456["x-fb-is-charging"] = String(v459.isCharging), v456["x-fb-device-uptime"] = String(v459.uptime), v456["x-fb-session-id"] = v459.sessionId, v456["x-fb-foreground-time"] = String(v459.fgTime), v456["x-fb-screen-state"] = '1', v456["x-fb-data-saver"] = '0', v456["x-fb-notifications"] = '1', v456["x-fb-connection-bandwidth"] = String(v459.bandwidth), v456["x-fb-device-soc-manufacturer"] = v459.socManufacturer;
            v459.platform === "android" && v459.gpsVersion && (v456["x-fb-gps-version"] = v459.gpsVersion);
            if (v459.platform === "ios") {
              v456["x-fb-device-family"] = v459.family, v456["x-fb-device-os-version"] = v459.osVersion;
            }
          }
          return v456;
        };
      onStatus("[2/4] Verifying phone number...");
      const v391 = Array(24).fill(0).map(() => "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(Math.floor(Math.random() * 62))).join(''),
        v392 = new Date().toISOString().split('T')[0],
        v393 = "account_reg_info[birthday]=" + v392 + "&account_reg_info[device_id]=&account_reg_info[first_name]=&account_reg_info[has_youth_consent]=false&account_reg_info[is_bootstrap_flow]=false&account_reg_info[last_name]=&account_reg_info[pc_rendering_data]=&account_reg_info[phone_number]=" + v366 + "&account_reg_info[registration_flow_id]=&allow_unconfirmed_email=false&check_for_pre_registration_restrictions=true&check_mma_account=true&contact_point=" + v366 + "&contact_point_type=PHONE_NUMBER&reg_integrity=&check_ntm_qe=true&skip_xapp_checks=false&caa_event_flow=&csi=" + v391 + "&event_client_time=" + (Date.now() / 1000).toFixed(3) + "&waterfall_id=" + v367 + "&source_app_id=1522763855472543&qpl_join_id=" + genQplJoinId() + '&' + fn8('k');
      debugLog(v366, "check-contact-req", {
        'url': "https://auth.meta.com/api/check-contact-point-availability/",
        'method': "POST",
        'headers': fn9(),
        'payload': v393
      });
      const v394 = await sendRequest("https://auth.meta.com/api/check-contact-point-availability/", "POST", fn9(), v393, null, timeout, 0, 0, v364),
        v395 = {};
      v395.status = v394.status, v395.headers = v394.headers, v395.body = v394.data, debugLog(v366, "check-contact-res", v395);
      if (v394.status !== 200) throw new Error("Invalid response: " + v394.status);
      fn7(v394.cookies);
      let v396 = '',
        v397 = '',
        v398 = null;
      try {
        {
          const v460 = JSON.parse(v394.data.replace("for (;;);", ''));
          if (v460.error === 3571123 || v460.error === 3571188) v398 = v460.error, onStatus("[2/4] Number has existing account (" + (v460.error === 3571123 ? "registered" : "pending") + ") → switching to reset flow...");else {
            if (v460.error) throw new Error(v460.errorDescription || v460.errorSummary || "Verification failed");else {
              {
                if (v460.payload && v460.payload.is_contact_point_available === false) throw new Error(v460.payload.error_message || "Phone number not available");
                const v461 = v460.payload && (v460.payload.regIntegrity || v460.payload.reg_integrity);
                v461 && (v396 = encodeURIComponent(v461), onStatus("[2/4] ✅ Got reg_integrity from server (pure API, no browser!)"));
                if (v460.payload && v460.payload.restrictions && v460.payload.restrictions.restriction_data && v460.payload.restrictions.restriction_data.account_reg_info) {
                  v397 = v460.payload.restrictions.restriction_data.account_reg_info.device_id || '';
                }
              }
            }
          }
        }
      } catch (v462) {
        {
          if (!(v462 instanceof SyntaxError)) throw v462;
        }
      }
      if (v398) {
        onStatus("[3/4] Sending login OTP to existing account...");
        const v463 = "contact_point=%2B" + v366 + "&caa_event_flow=ntf&csi=" + v391 + "&source_app_id=1522763855472543&waterfall_id=" + v367 + "&qpl_join_id=&" + fn8('r');
        debugLog(v366, "send-nonce-req", {
          'url': "https://auth.meta.com/api/login-email-otp/send-nonce/",
          'method': "POST",
          'headers': fn9(),
          'payload': v463
        });
        const v464 = await sendRequest("https://auth.meta.com/api/login-email-otp/send-nonce/", "POST", fn9(), v463, null, timeout, 0, 0, v364),
          v465 = {};
        v465.status = v464.status, v465.headers = v464.headers, v465.body = v464.data, debugLog(v366, "send-nonce-res", v465), fn7(v464.cookies);
        let v466 = false,
          v467 = '';
        try {
          {
            const v468 = JSON.parse(v464.data.replace("for (;;);", ''));
            if (v468.error) {
              onStatus("[4/4] send-nonce error " + v468.error + ':\x20' + (v468.errorDescription || v468.errorSummary || "unknown")), v467 = v468.errorDescription || v468.errorSummary || "Error " + v468.error;
            } else {
              if (v468.payload && (v468.payload.nonce_sent === true || v468.payload.nonceSent === true)) v466 = true, v467 = "Login OTP confirmed (nonce_sent=true)", onStatus("[4/4] ✅ " + v467);else {
                if (v468.payload && Object.keys(v468.payload).length > 0) v466 = true, v467 = "Login OTP likely sent (payload keys: " + Object.keys(v468.payload).join(',\x20') + ')', onStatus("[4/4] ✅ " + v467);else {
                  v467 = "Silent block on login OTP → " + JSON.stringify(v468).substring(0, 200), onStatus("[4/4] ⚠️ " + v467);
                }
              }
            }
          }
        } catch (v469) {
          v467 = "Non-JSON response from send-nonce (" + (v464.data || '').length + " bytes)", onStatus("[4/4] ⚠️ " + v467);
        }
        if (v466) {
          for (let v470 = 0; v470 < (v361.resends || 0); v470++) {
            {
              await new Promise(v475 => setTimeout(v475, 2000));
              if (v361.onLog) v361.onLog("Resending OTP to +" + v366 + '\x20(' + (v470 + 1) + '/' + v361.resends + ')', "retry");
              onStatus("[4/4] 🔄 Resending OTP (" + (v470 + 1) + '/' + v361.resends + ")...");
              let v471 = (parseInt('r', 36) + v470 + 1).toString(36),
                v472 = "contact_point=%2B" + v366 + "&caa_event_flow=ntf&csi=" + v391 + "&source_app_id=1522763855472543&waterfall_id=" + v367 + "&qpl_join_id=" + genQplJoinId() + '&' + fn8(v471);
              debugLog(v366, "resend-nonce-req", {
                'url': "https://auth.meta.com/api/login-email-otp/send-nonce/",
                'method': "POST",
                'headers': fn9(),
                'payload': v472
              });
              let v473 = await sendRequest("https://auth.meta.com/api/login-email-otp/send-nonce/", "POST", fn9(), v472, null, timeout, 0, 0, v364);
              const v474 = {};
              v474.status = v473.status, v474.headers = v473.headers, v474.body = v473.data, debugLog(v366, "resend-nonce-res", v474), fn7(v473.cookies);
            }
          }
          return {
            'success': true,
            'message': "Login OTP Sent successfully",
            'phone': v365,
            'type': "login_otp",
            'password': "N/A (existing)",
            'dob': v376,
            'browser': v375.name,
            'lang': v370.substring(0, 5),
            'proxy': proxy || "direct"
          };
        } else throw new Error("Already Registered (Existing Meta Account - Login OTP not permitted)");
      }
      onStatus("[3/4] Password + DOB check...");
      const v399 = "akash99ak",
        v400 = "#PWD_BROWSER:0:" + Math.floor(Date.now() / 1000) + ':' + v399,
        v401 = "contact_point=" + encodeURIComponent(v365) + "&date_of_birth=" + v376.full + "&name=&password=" + encodeURIComponent(v400) + "&contact_pointless_account=false&qpl_join_id=" + genQplJoinId() + '&' + fn8('q');
      debugLog(v366, "check-password-1-req", {
        'url': "https://auth.meta.com/api/check-password/",
        'method': "POST",
        'headers': fn9(),
        'payload': v401
      });
      const v402 = await sendRequest("https://auth.meta.com/api/check-password/", "POST", fn9(), v401, null, timeout, 0, 0, v364),
        v403 = {};
      v403.status = v402.status, v403.headers = v402.headers, v403.body = v402.data, debugLog(v366, "check-password-1-res", v403), fn7(v402.cookies);
      const v404 = "caa_event_flow=ntm&date_of_birth=" + v376.full + "&first_name=&has_youth_consent=false&isf=false&last_name=&phone_number=" + encodeURIComponent(v365) + "&qpl_join_id=" + genQplJoinId() + "&reg_integrity=" + v396 + "&source_app_id=1522763855472543&" + fn8('s');
      debugLog(v366, "check-dob-req", {
        'url': "https://auth.meta.com/api/check-date-of-birth/",
        'method': "POST",
        'headers': fn9(),
        'payload': v404
      });
      const v405 = await sendRequest("https://auth.meta.com/api/check-date-of-birth/", "POST", fn9(), v404, null, timeout, 0, 0, v364),
        v406 = {};
      v406.status = v405.status, v406.headers = v405.headers, v406.body = v405.data, debugLog(v366, "check-dob-res", v406), fn7(v405.cookies);
      try {
        {
          const v476 = JSON.parse(v405.data.replace("for (;;);", ''));
          if (v476.error) throw new Error(v476.errorDescription || v476.errorSummary || "DOB check failed");
          v476.payload && v476.payload.regIntegrity && (v396 = encodeURIComponent(v476.payload.regIntegrity), onStatus("[3/4] Got updated regIntegrity from DOB check..."));
        }
      } catch (v477) {
        if (!(v477 instanceof SyntaxError)) throw v477;
      }
      const v407 = "date_of_birth=" + v376.full + '&' + fn8('t'),
        v408 = await sendRequest("https://auth.meta.com/api/eligible-for-default-marketing-opt-in/", "POST", fn9(), v407, null, timeout, 0, 0, v364);
      fn7(v408.cookies);
      const v409 = "contact_point=" + encodeURIComponent(v365) + "&date_of_birth=" + v376.full + "&name=&password=" + encodeURIComponent(v400) + "&contact_pointless_account=false&qpl_join_id=" + genQplJoinId() + '&' + fn8('u');
      debugLog(v366, "check-password-2-req", {
        'url': "https://auth.meta.com/api/check-password/",
        'method': "POST",
        'headers': fn9(),
        'payload': v409
      });
      const v410 = await sendRequest("https://auth.meta.com/api/check-password/", "POST", fn9(), v409, null, timeout, 0, 0, v364),
        v411 = {};
      v411.status = v410.status, v411.headers = v410.headers, v411.body = v410.data, debugLog(v366, "check-password-2-res", v411), fn7(v410.cookies);
      const v412 = "date_of_birth=" + v376.full + '&' + fn8('y'),
        v413 = await sendRequest("https://auth.meta.com/api/eligible-for-default-marketing-opt-in/", "POST", fn9(), v412, null, timeout, 0, 0, v364);
      fn7(v413.cookies);
      const v414 = v378.first.toLowerCase() + '_' + v378.last.toLowerCase() + '_' + Math.floor(Math.random() * 9999),
        v415 = v378.first;
      onStatus("[4/4] Finalizing profile to dispatch SMS...");
      const v416 = "client_consent_timestamp=" + Math.floor(Date.now() / 1000) + "&display_name=" + encodeURIComponent(v415) + "&foa_import_source_name=&foa_import_source_obid=&nta_disclosures_summary_cms_id=&picture_source=&tos_cms_id=957798449862312&username=" + v414 + "&caa_event_flow=ntm&csi=" + v391 + "&source_app_id=1522763855472543&waterfall_id=" + v367 + "&is_submit=false&" + fn8('12');
      debugLog(v366, "check-profile-pre-req", {
        'url': "https://auth.meta.com/api/kadabra/check_profile/",
        'method': "POST",
        'headers': fn9(),
        'payload': v416
      });
      const v417 = await sendRequest("https://auth.meta.com/api/kadabra/check_profile/", "POST", fn9(), v416, null, timeout, 0, 0, v364),
        v418 = {};
      v418.status = v417.status, v418.headers = v417.headers, v418.body = v417.data, debugLog(v366, "check-profile-pre-res", v418), fn7(v417.cookies);
      const v419 = "client_consent_timestamp=" + Math.floor(Date.now() / 1000) + "&display_name=" + encodeURIComponent(v415) + "&foa_import_source_name=&foa_import_source_obid=&nta_disclosures_summary_cms_id=&picture_source=&tos_cms_id=957798449862312&username=" + v414 + "&caa_event_flow=ntm&csi=" + v391 + "&source_app_id=1522763855472543&waterfall_id=" + v367 + "&is_submit=true&" + fn8('15');
      debugLog(v366, "check-profile-req", {
        'url': "https://auth.meta.com/api/kadabra/check_profile/",
        'method': "POST",
        'headers': fn9(),
        'payload': v419
      });
      const v420 = await sendRequest("https://auth.meta.com/api/kadabra/check_profile/", "POST", fn9(), v419, null, timeout, 0, 0, v364),
        v421 = {};
      v421.status = v420.status, v421.headers = v420.headers, v421.body = v420.data, debugLog(v366, "check-profile-res", v421), fn7(v420.cookies);
      const v422 = {
          'csrf_token': crypto.randomBytes(32).toString("base64url"),
          'redirect_to': "https://www.meta.ai/oidc/callback",
          'waterfall_id': v367
        },
        v423 = Buffer.from(JSON.stringify(v422)).toString("base64"),
        v424 = crypto.randomBytes(32).toString("base64url");
      let v425 = 'US';
      try {
        v425 = JSON.parse(v380.regulation_jurisdiction)[0];
      } catch (v478) {}
      const v426 = encodeURIComponent("https://auth.meta.com/oidc/?app_id=1522763855472543&redirect_uri=https%3A%2F%2Fauth.meta.ai%2Fecto&response_type=code&scope=openid%2Blinking&state=" + v423 + "&waterfall_id=" + v367 + "&code_challenge=" + v424 + "&code_challenge_method=S256"),
        v427 = v371 && v371 !== 'US' ? v371 : v425,
        v428 = encodeURIComponent(JSON.stringify([v427])),
        v429 = "client_consent_timestamp=" + Math.floor(Date.now() / 1000) + "&display_name=" + encodeURIComponent(v415) + "&foa_import_source_name=&foa_import_source_obid=&nta_disclosures_summary_cms_id=&picture_source=&tos_cms_id=957798449862312&username=" + v414 + "&consent_version=&contact_point=" + encodeURIComponent(v365) + "&contact_point_type=PHONE_NUMBER&csi=" + v391 + "&date_of_birth=" + v376.full + "&device_id=" + v397 + "&fb_encrypted_access_token=&fb_oidc_access_token=&first_name=&google_id_token=&has_youth_consent=false&ig_encrypted_access_token=&ig_encrypted_auth_header=&ig_oidc_access_token=&last_name=&opt_into_marketing=false&password=" + encodeURIComponent(v400) + "&redirect_uri=" + v426 + "&reg_integrity=" + v396 + "&should_save_credentials=true&source_app_id=1522763855472543&third_party_age_verification_id=&waterfall_id=" + v367 + "&caa_event_flow=ntm&entry_point=login_home&event_client_time=" + (Date.now() / 1000).toFixed(3) + "&is_kadabra_zero=false&reg_navigation_flow_name=new_to_family_c50_r1&regulation_jurisdiction=" + v428 + "&qpl_join_id=" + genQplJoinId() + '&' + fn8('16');
      debugLog(v366, "register-save-req", {
        'url': "https://auth.meta.com/login/device-based/kadabra-register-save-credentials/",
        'method': "POST",
        'headers': fn9(),
        'payload': v429
      });
      const v430 = await sendRequest("https://auth.meta.com/login/device-based/kadabra-register-save-credentials/", "POST", fn9(), v429, null, timeout, 0, 0, v364),
        v431 = {};
      v431.status = v430.status, v431.headers = v430.headers, v431.body = v430.data, debugLog(v366, "register-save-res", v431), fn7(v430.cookies);
      try {
        {
          const v479 = (v430.data || '').replace("for (;;);", ''),
            v480 = v479.match(/"dtsgToken":"([^"]+)"/),
            v481 = v479.match(/"dtsgAsyncGetToken":"([^"]+)"/);
          if (v480) v380.fb_dtsg = v480[1];
          if (v481 && !v380.fb_dtsg) v380.fb_dtsg = v481[1];
        }
      } catch (v482) {}
      if (v430.status !== 200) throw new Error("Meta API failed with HTTP " + v430.status);
      const v432 = v430.data || '';
      let v433 = false,
        v434 = '';
      try {
        {
          const v483 = JSON.parse(v432.replace("for (;;);", ''));
          if (v483.error) {
            throw new Error(v483.errorDescription || v483.errorSummary || "Registration blocked (Error " + v483.error + ')');
          }
          if (v483.payload && v483.payload.error_message) {
            throw new Error(v483.payload.error_message);
          }
          if (v483.payload) {
            if (v483.payload.account_id || v483.payload.uid || v483.payload.social_profile_id) v433 = true, v434 = "Registration confirmed (account_id: " + (v483.payload.account_id || v483.payload.uid) + ')';else {
              if (v483.payload.redirect_uri || v483.payload.redirectUri || v483.payload.redirect) v433 = true, v434 = "Registration confirmed (redirect received)";else {
                if (v483.payload.nonce_sent === true || v483.payload.nonceSent === true) v433 = true, v434 = "OTP confirmed (nonce_sent=true)";else {
                  if (v483.payload.session_id || v483.payload.sessionId || v483.payload.confirmation_code) v433 = true, v434 = "Registration confirmed (session created)";else {
                    const v484 = Object.keys(v483.payload);
                    if (v484.length > 0 && !v483.payload.error_message) v433 = true, v434 = "Registration likely succeeded (payload keys: " + v484.join(',\x20') + ')';else throw new Error("Silent block: Meta returned empty/unrecognized payload → " + JSON.stringify(v483.payload).substring(0, 200));
                  }
                }
              }
            }
          } else {
            if (v483.redirect_uri || v483.redirectUri) v433 = true, v434 = "Registration confirmed (top-level redirect)";else {
              throw new Error("Silent block: Meta returned no payload → " + JSON.stringify(v483).substring(0, 300));
            }
          }
        }
      } catch (v485) {
        {
          if (v485 instanceof SyntaxError) {
            {
              if (v432.includes("checkpoint") || v432.includes("security_check")) throw new Error("Account hit checkpoint/security block");else {
                if (v432.includes("auth.meta.com/oidc") || v432.includes("confirmation") || v432.includes("verify")) {
                  v433 = true, v434 = "Registration confirmed (HTML redirect to verification)";
                } else {
                  throw new Error("Silent block: Non-JSON response (" + v432.length + " bytes) → " + v432.substring(0, 200));
                }
              }
            }
          } else {
            throw v485;
          }
        }
      }
      if (!v433) throw new Error("Registration failed: no confirmation signal from Meta");
      let v435 = Math.max(0, v361.resends || 0);
      for (let v486 = 0; v486 < v435; v486++) {
        await new Promise(v494 => setTimeout(v494, 3000));
        if (v361.onLog) v361.onLog("Resending OTP to " + v365 + '\x20(' + (v486 + 1) + '/' + v435 + ')', "retry");
        onStatus("[4/4] 🔄 Resending OTP (" + (v486 + 1) + '/' + v435 + ")...");
        const v487 = v380.fb_dtsg || v379.fb_dtsg || '',
          v488 = {};
        v488.sensitive_string_value = v365;
        const v489 = JSON.stringify({
            'input': {
              'contact_point': v488,
              'contact_point_type': "PHONE_NUMBER",
              'event_flow': "ntm",
              'rl_client_session_id': v391,
              'source_app_id': 0x568f216aea79f,
              'waterfall_id': v367,
              'actor_id': '0',
              'client_mutation_id': String(v486 + 1)
            }
          }),
          v490 = new URLSearchParams({
            'av': '0',
            '__user': '0',
            '__a': '1',
            '__req': (parseInt('1j', 36) + v486).toString(36),
            '__hs': decodeURIComponent(v380.hs || v388),
            'dpr': '1',
            '__ccg': "EXCELLENT",
            '__rev': v380.rev || v387,
            '__s': v389,
            '__hsi': v380.hsi || '',
            '__dyn': v380.dyn || v382,
            '__csr': v380.csr || v383,
            '__hsdp': v380.hsdp || v384,
            '__hblp': v380.hblp || v385,
            '__sjsp': v380.sjsp || v386,
            '__comet_req': '33',
            'fb_dtsg': v487,
            'jazoest': v380.jazoest || '',
            'lsd': v380.lsd,
            '__spin_r': v380.spin_r || v380.rev || v387,
            '__spin_b': "trunk",
            '__spin_t': v380.spin_t || String(Math.floor(Date.now() / 1000)),
            '__jssesw': '1',
            'fb_api_caller_class': "RelayModern",
            'fb_api_req_friendly_name': "FRLResendOTPMutation",
            'server_timestamps': "true",
            'variables': v489,
            'doc_id': "25885129117818218"
          }).toString(),
          v491 = {
            ...fn9(),
            'x-fb-friendly-name': "FRLResendOTPMutation"
          };
        let v492 = await sendRequest("https://auth.meta.com/api/graphql/", "POST", v491, v490, null, timeout, 0, 0, v364);
        const v493 = {};
        v493.status = v492.status, v493.body = v492.data, debugLog(v366, "resend-graphql-res", v493), fn7(v492.cookies);
      }
      return onStatus("[4/4] ✅ " + v434), {
        'success': true,
        'message': v434,
        'phone': v365,
        'type': "registration",
        'password': v377,
        'dob': v376,
        'browser': v375.name,
        'lang': v370.substring(0, 5),
        'proxy': proxy || "direct"
      };
    }
  } catch (v495) {
    {
      if (v373 && (v495.message.includes("token") || v495.message.includes("LSD") || v495.message.includes("400") || v495.message.includes("jazoest"))) {
        _tokenCache.tokens = null;
      }
      const v496 = {};
      return v496.success = false, v496.message = "Failed: " + v495.message, v496.phone = v365, v496;
    }
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v497) {
      {
        this.totalNumbers = v497;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v498, v499, v500 = '') {
      let v501 = '';
      const v502 = v498.match(/\d{8,}/);
      const v503 = v502 ? v502[0] : '',
        v504 = v500 ? chalk.gray('\x20' + v500) : '';
      if (v499 === "success") v501 = chalk.hex("#00FF88")("REX — Meta │ OTP Sent → ") + chalk.hex("#FCAF45").bold(v503 || v498) + v504;else {
        if (v499 === "error" || v499 === "failed") {
          let v505 = v498.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
          if (v505.toLowerCase().includes("proxy")) v501 = chalk.hex("#FF4466")("REX — Meta │ Proxy Drop → ") + chalk.hex("#888888")(v505) + v504;else {
            v501 = chalk.hex("#FF4466")("REX — Meta │ Failed → ") + chalk.hex("#FCAF45").bold(v503) + v504 + chalk.hex("#888888")('\x20(' + v505 + ')');
          }
        } else {
          if (v499 === "retry") {
            {
              let v506 = v498.includes('(') ? v498.substring(v498.indexOf('(')) : '';
              v501 = chalk.hex("#FCAF45")("REX — Meta │ Resending  → ") + chalk.hex("#FCAF45").bold(v503) + v504 + chalk.hex("#888888")('\x20' + v506);
            }
          } else {
            return;
          }
        }
      }
      process.stdout.write("\r[K" + v501 + '\x0a');
      this.render();
    }
    ["setStatus"](v507) {}
    ["update"]() {}
    ["render"]() {
      const v508 = (this.processed / Math.max(this.totalNumbers, 1) * 100).toFixed(1);
      const v509 = '\x20\x20' + W.bold("REX-V5") + " ⮞ [" + this.processed + '/' + this.totalNumbers + ']\x20' + v508 + "% │ " + B("OK: " + this.successful) + " │ " + R("Err: " + this.failed);
      process.stdout.write("\r[K" + v509);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v510 = Math.floor((Date.now() - this.startTime) / 1000),
        v511 = Math.floor(v510 / 60),
        v512 = v510 % 60,
        v513 = v511 + 'm\x20' + v512 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  REX V5                                    ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v513.padEnd(6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v514, v515) {
    return new Promise(v516 => {
      {
        let v517 = 0;
        process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
        if (process.stdin.isTTY) process.stdin.setRawMode(true);
        const fn10 = () => {
          process.stdout.write("[2J[H"), printHeader(), console.log("   [33m" + v514 + "[0m\n"), v515.forEach((v518, v519) => {
            v519 === v517 ? console.log("   [36m➔[32m " + v518.name + "[0m") : console.log("     [90m" + v518.name + "[0m");
          });
        };
        fn10();
        const fn11 = (v520, v521) => {
          {
            v521.ctrl && v521.name === 'c' && process.exit(0);
            if (v521.name === 'up') v517 = (v517 - 1 + v515.length) % v515.length, fn10();else {
              if (v521.name === "down") v517 = (v517 + 1) % v515.length, fn10();else {
                if (v521.name === "return") {
                  process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn11), v516(v515[v517].value);
                }
              }
            }
          }
        };
        process.stdin.on("keypress", fn11);
      }
    });
  }
  async function promptText(v522, v523) {
    return new Promise(v524 => {
      {
        process.stdout.write("   [33m" + v522 + "[0m ");
        let v525 = '';
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.resume();
        const fn12 = v526 => {
          const v527 = v526.toString();
          if (v527.includes('\x0a') || v527.includes('\x0d')) {
            process.stdin.removeListener("data", fn12), v525 += v527.split(/[\r\n]/)[0];
            let v528 = v525.trim();
            if (v528.startsWith('\x22') && v528.endsWith('\x22')) v528 = v528.slice(1, -1);else v528.startsWith('\x27') && v528.endsWith('\x27') && (v528 = v528.slice(1, -1));
            v524(v528 || v523);
          } else v525 += v527;
        };
        process.stdin.on("data", fn12);
      }
    });
  }
  async function interactiveWizard() {
    let v529 = 1,
      v530 = "file",
      v531 = "numbers.txt",
      v532 = null,
      v533 = null,
      v534 = null,
      v535 = null,
      v536 = "none";
    let v537 = 20;
    let v538 = "random";
    let v539 = "random",
      v540 = 0,
      v541 = '1',
      v542 = '',
      v543 = [],
      v544 = 50;
    let v545 = "/api/v1/numbers/get";
    const v546 = path.join(__dirname, ".nexa_api_key");
    while (true) {
      process.stdout.write("[2J[H"), printHeader();
      if (v529 === 1) {
        {
          const v547 = await selectOption("SELECT NUMBER SOURCE", [{
            'name': "📁 Load from file",
            'value': "file"
          }, {
            'name': "🌐 Auto fetch from NexaOTP Panel",
            'value': "nexa"
          }, {
            'name': "⚡ Auto fetch from Voltx (2oo9)",
            'value': "voltx"
          }, {
            'name': "🔥 Auto fetch from Stex (2oo9)",
            'value': "stex"
          }, {
            'name': "📱 Auto fetch from SMS Bower",
            'value': "smsbower"
          }, {
            'name': "⚡ Auto fetch from Zenex",
            'value': "zenex"
          }, {
            'name': "❌ Exit Program",
            'value': "exit"
          }]);
          if (v547 === "exit") process.exit(0);
          v530 = v547, v529 = 2;
        }
      } else {
        if (v529 === 2) {
          if (v530 === "file") {
            const v548 = await selectOption("SELECT TARGET NUMBERS FILE", [{
              'name': "✏️ Custom File Path",
              'value': "custom"
            }, {
              'name': "⬅️ Go Back to Number Source",
              'value': "back"
            }]);
            if (v548 === "back") {
              v529 = 1;
              continue;
            }
            if (v548 === "custom") {
              {
                const v549 = await promptText("Enter Numbers File Path:", "numbers.txt");
                if (v549.toLowerCase() === "back") continue;
                v531 = v549;
              }
            } else v531 = v548;
            if (!fs.existsSync(v531)) fs.writeFileSync(v531, '');
            v532 = null, v529 = 3;
          } else {
            if (v530 === "voltx" || v530 === "stex") {
              const v550 = v530 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
                v551 = v530 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
                v552 = v530 === "voltx" ? TWOOO_VOLTX_GET : TWOOO_STEX_GET,
                v553 = v530 === "voltx" ? TWOOO_VOLTX_CONSOLE : TWOOO_STEX_CONSOLE;
              let v554 = '',
                v555 = [],
                v556 = 50,
                v557 = false,
                v558 = 1;
              while (v558 <= 3 && !v557) {
                process.stdout.write("[2J[H"), printHeader();
                if (v558 === 1) {
                  {
                    if (fs.existsSync(v551)) {
                      {
                        v554 = fs.readFileSync(v551, "utf8").trim();
                        const v559 = await selectOption(v550 + " key found (" + v554.substring(0, 10) + "...)", [{
                          'name': "Use saved key",
                          'value': "use"
                        }, {
                          'name': "Enter new key",
                          'value': "new"
                        }, {
                          'name': "Remove saved key",
                          'value': "remove"
                        }, {
                          'name': "⬅️ Back",
                          'value': "back"
                        }]);
                        if (v559 === "back") {
                          v557 = true;
                          break;
                        }
                        if (v559 === "remove") {
                          fs.existsSync(v551) && fs.unlinkSync(v551), v554 = '';
                        } else v559 === "new" && (v554 = '');
                      }
                    }
                    if (!v554) {
                      {
                        const v560 = await promptText("Enter " + v550 + " API Key (mauthapi):", '');
                        if (v560.toLowerCase() === "back") {
                          v557 = true;
                          break;
                        }
                        v554 = v560;
                        const v561 = {};
                        v561.name = 'No', v561.value = 'no';
                        const v562 = await selectOption("Save key?", [{
                          'name': "Yes",
                          'value': "yes"
                        }, v561]);
                        if (v562 === "yes" && v554) fs.writeFileSync(v551, v554, "utf8");
                      }
                    }
                    if (v554) v558 = 2;
                  }
                } else {
                  if (v558 === 2) {
                    {
                      const v563 = await selectOption("How to select ranges?", [{
                        'name': "🔍 Auto Range Finder (scan console)",
                        'value': "auto"
                      }, {
                        'name': "✏️  Enter manually",
                        'value': "manual"
                      }, {
                        'name': "⬅️ Back",
                        'value': "back"
                      }]);
                      if (v563 === "back") {
                        {
                          v558 = 1;
                          continue;
                        }
                      }
                      if (v563 === "auto") {
                        {
                          const v564 = await autoRangeFinderFor2Oo(v554, v553, selectOption, promptText);
                          v564 && v564.length > 0 && (v555 = v564, v558 = 3);
                        }
                      } else {
                        v555 = [];
                        let v565 = true;
                        while (v565) {
                          {
                            const v566 = await promptText("Enter range #" + (v555.length + 1) + " (e.g. 26134XXX) or 'back':", '');
                            if (v566.toLowerCase() === "back") {
                              {
                                if (v555.length === 0) break;else {
                                  v555.pop();
                                  continue;
                                }
                              }
                            }
                            if (v566) v555.push(v566);
                            const v567 = {};
                            v567.name = 'No', v567.value = 'no';
                            const v568 = await selectOption("Added " + v555.length + ". Add another?", [{
                              'name': "Yes",
                              'value': "yes"
                            }, v567]);
                            if (v568 === 'no') v565 = false;
                          }
                        }
                        if (v555.length > 0) v558 = 3;
                      }
                    }
                  } else {
                    if (v558 === 3) {
                      const v569 = await promptText("How many numbers? [default:50]:", '50');
                      if (v569.toLowerCase() === "back") {
                        {
                          v558 = 2;
                          continue;
                        }
                      }
                      v556 = parseInt(v569) || 50;
                      const v570 = {};
                      v570.provider = v530, v570.apiKey = v554, v570.getPath = v552, v570.consolePath = v553, v570.ranges = v555, v570.totalCount = v556, v533 = v570, v532 = null, v558 = 4;
                    }
                  }
                }
              }
              if (v557) {
                v529 = 1;
                continue;
              }
              v529 = 3;
            } else {
              if (v530 === "smsbower") {
                let v571 = '',
                  v572 = 'fb',
                  v573 = '0',
                  v574 = "0.5",
                  v575 = 50,
                  v576 = 1,
                  v577 = false;
                while (v576 <= 4 && !v577) {
                  {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v576 === 1) {
                      {
                        if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                          v571 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                          const v578 = await selectOption("SMS Bower key found (" + v571.substring(0, 10) + "...)", [{
                            'name': "Use saved key",
                            'value': "use"
                          }, {
                            'name': "Enter new key",
                            'value': "new"
                          }, {
                            'name': "Remove saved key",
                            'value': "remove"
                          }, {
                            'name': "⬅️ Back",
                            'value': "back"
                          }]);
                          if (v578 === "back") {
                            {
                              v577 = true;
                              break;
                            }
                          }
                          if (v578 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v571 = '';else {
                            if (v578 === "new") v571 = '';
                          }
                        }
                        if (!v571) {
                          v571 = await promptText("Enter SMS Bower API Key:", '');
                          if (v571.toLowerCase() === "back") {
                            v577 = true;
                            break;
                          }
                          const v579 = {};
                          v579.name = 'No', v579.value = 'no';
                          const v580 = await selectOption("Save key?", [{
                            'name': "Yes",
                            'value': "yes"
                          }, v579]);
                          if (v580 === "yes" && v571) fs.writeFileSync(SMSBOWER_KEY_FILE, v571, "utf8");
                        }
                        if (v571) v576 = 2;
                      }
                    } else {
                      if (v576 === 2) {
                        {
                          v572 = await promptText("Service code (e.g. fb, ig, wa) [default: fb]:", 'fb');
                          if (v572.toLowerCase() === "back") {
                            {
                              v576 = 1;
                              continue;
                            }
                          }
                          v572 = v572 || 'fb', v576 = 3;
                        }
                      } else {
                        if (v576 === 3) {
                          v573 = await promptText("Country code (0 = any) [default: 0]:", '0');
                          if (v573.toLowerCase() === "back") {
                            v576 = 2;
                            continue;
                          }
                          v573 = v573 || '0';
                          const v581 = await promptText("Max price per number [default: 0.5]:", "0.5");
                          v574 = v581 || "0.5", v576 = 4;
                        } else {
                          if (v576 === 4) {
                            const v582 = await promptText("How many numbers? [default: 50]:", '50');
                            if (v582.toLowerCase() === "back") {
                              v576 = 3;
                              continue;
                            }
                            v575 = parseInt(v582) || 50;
                            const v583 = {};
                            v583.apiKey = v571, v583.service = v572, v583.country = v573, v583.maxPrice = v574, v583.totalCount = v575, v534 = v583, v532 = null, v533 = null, v535 = null, v576 = 5;
                          }
                        }
                      }
                    }
                  }
                }
                if (v577) {
                  v529 = 1;
                  continue;
                }
                v529 = 3;
              } else {
                if (v530 === "zenex") {
                  {
                    let v584 = '',
                      v585 = [],
                      v586 = 50,
                      v587 = 1,
                      v588 = false;
                    while (v587 <= 3 && !v588) {
                      {
                        process.stdout.write("[2J[H"), printHeader();
                        if (v587 === 1) {
                          {
                            if (fs.existsSync(ZENEX_KEY_FILE)) {
                              {
                                v584 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                                const v589 = await selectOption("Zenex key found (" + v584.substring(0, 10) + "...)", [{
                                  'name': "Use saved key",
                                  'value': "use"
                                }, {
                                  'name': "Enter new key",
                                  'value': "new"
                                }, {
                                  'name': "Remove saved key",
                                  'value': "remove"
                                }, {
                                  'name': "⬅️ Back",
                                  'value': "back"
                                }]);
                                if (v589 === "back") {
                                  {
                                    v588 = true;
                                    break;
                                  }
                                }
                                if (v589 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v584 = '';else {
                                  if (v589 === "new") v584 = '';
                                }
                              }
                            }
                            if (!v584) {
                              v584 = await promptText("Enter Zenex API Key (mapikey):", '');
                              if (v584.toLowerCase() === "back") {
                                v588 = true;
                                break;
                              }
                              const v590 = {};
                              v590.name = 'No', v590.value = 'no';
                              const v591 = await selectOption("Save key?", [{
                                'name': "Yes",
                                'value': "yes"
                              }, v590]);
                              if (v591 === "yes" && v584) fs.writeFileSync(ZENEX_KEY_FILE, v584, "utf8");
                            }
                            if (v584) v587 = 2;
                          }
                        } else {
                          if (v587 === 2) {
                            {
                              v585 = [];
                              let v592 = true;
                              while (v592) {
                                const v593 = await promptText("Enter range #" + (v585.length + 1) + " (e.g. 4473845XXX) or 'back':", '');
                                if (v593.toLowerCase() === "back") {
                                  {
                                    if (v585.length === 0) {
                                      {
                                        v588 = true;
                                        break;
                                      }
                                    } else {
                                      v585.pop();
                                      continue;
                                    }
                                  }
                                }
                                if (v593) v585.push(v593);
                                const v594 = {};
                                v594.name = 'No', v594.value = 'no';
                                const v595 = await selectOption("Added " + v585.length + ". Add another?", [{
                                  'name': "Yes",
                                  'value': "yes"
                                }, v594]);
                                if (v595 === 'no') v592 = false;
                              }
                              if (v585.length > 0) v587 = 3;
                            }
                          } else {
                            if (v587 === 3) {
                              {
                                const v596 = await promptText("How many numbers? [default: 50]:", '50');
                                if (v596.toLowerCase() === "back") {
                                  v587 = 2;
                                  continue;
                                }
                                v586 = parseInt(v596) || 50;
                                const v597 = {};
                                v597.apiKey = v584, v597.ranges = v585, v597.totalCount = v586, v535 = v597, v532 = null, v533 = null, v534 = null, v587 = 4;
                              }
                            }
                          }
                        }
                      }
                    }
                    if (v588) {
                      {
                        v529 = 1;
                        continue;
                      }
                    }
                    v529 = 3;
                  }
                } else {
                  let v598 = 1,
                    v599 = false;
                  while (v598 <= 4 && !v599) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v598 === 1) {
                      {
                        if (fs.existsSync(v546)) {
                          {
                            const v600 = fs.readFileSync(v546, "utf8").trim(),
                              v601 = await selectOption("Found saved API Key (..." + v600.slice(-4) + "). Use it?", [{
                                'name': "Yes, use saved key",
                                'value': "yes"
                              }, {
                                'name': "No, enter new key",
                                'value': 'no'
                              }, {
                                'name': "Delete saved key",
                                'value': "delete"
                              }, {
                                'name': "⬅️ Go Back to Number Source",
                                'value': "back"
                              }]);
                            if (v601 === "back") {
                              v599 = true;
                              break;
                            }
                            if (v601 === "yes") v542 = v600;else {
                              if (v601 === "delete") {
                                if (fs.existsSync(v546)) fs.unlinkSync(v546);
                                v542 = '';
                              }
                            }
                          }
                        }
                        if (!v542) {
                          {
                            const v602 = await promptText("Enter NexaOTP API Key (type 'back' to go back):", '');
                            if (v602.toLowerCase() === "back") {
                              v599 = true;
                              break;
                            }
                            v542 = v602;
                            const v603 = {};
                            v603.name = 'No', v603.value = 'no';
                            const v604 = await selectOption("Save this key for future use?", [{
                              'name': "Yes, save it",
                              'value': "yes"
                            }, v603]);
                            v604 === "yes" && v542 && fs.writeFileSync(v546, v542, "utf8");
                          }
                        }
                        if (v542) v598 = 2;
                      }
                    } else {
                      if (v598 === 2) {
                        v543 = [];
                        let v605 = true;
                        while (v605) {
                          const v606 = await promptText("Enter range #" + (v543.length + 1) + " (e.g. 21624485XXX) or type 'back':", '');
                          if (v606.toLowerCase() === "back") {
                            {
                              if (v543.length === 0) {
                                v598 = 1;
                                break;
                              } else {
                                v543.pop();
                                continue;
                              }
                            }
                          }
                          if (v606) v543.push(v606);
                          const v607 = await selectOption("Added " + v543.length + " range(s). Add another?", [{
                            'name': "Yes, add another range",
                            'value': "yes"
                          }, {
                            'name': "No, proceed to next step",
                            'value': 'no'
                          }, {
                            'name': "⬅️ Go Back to API Key",
                            'value': "back"
                          }]);
                          if (v607 === "back") {
                            v598 = 1;
                            break;
                          }
                          if (v607 === 'no') v605 = false;
                        }
                        if (v543.length > 0) v598 = 3;
                      } else {
                        if (v598 === 3) {
                          const v608 = await promptText("How many numbers to process? (type 'back' to go back) [default: 50]:", '50');
                          if (v608.toLowerCase() === "back") {
                            {
                              v598 = 2;
                              continue;
                            }
                          }
                          v544 = parseInt(v608) || 50, v598 = 4;
                        } else {
                          if (v598 === 4) {
                            const v609 = await selectOption("SELECT NEXA SERVER", [{
                              'name': "Server 1 (/get)",
                              'value': "/api/v1/numbers/get"
                            }, {
                              'name': "Server 2 (/p2/get)",
                              'value': "/api/v1/numbers/p2/get"
                            }, {
                              'name': "Server 3 (/p3/get)",
                              'value': "/api/v1/numbers/p3/get"
                            }, {
                              'name': "⬅️ Go Back to Count Input",
                              'value': "back"
                            }]);
                            if (v609 === "back") {
                              v598 = 3;
                              continue;
                            }
                            v545 = v609;
                            const v610 = {};
                            v610.apiKey = v542, v610.ranges = v543, v610.totalCount = v544, v610.serverEndpoint = v545, v532 = v610, v598 = 5;
                          }
                        }
                      }
                    }
                  }
                  if (v599) {
                    v529 = 1;
                    continue;
                  }
                  v529 = 3;
                }
              }
            }
          }
        } else {
          if (v529 === 3) {
            const v611 = await selectOption("SELECT PROXIES FILE", [{
              'name': "✏️ Custom File Path",
              'value': "custom"
            }, {
              'name': "🚫 None (Direct Connection)",
              'value': "none"
            }, {
              'name': "⬅️ Go Back to Numbers Selection",
              'value': "back"
            }]);
            if (v611 === "back") {
              v529 = 2;
              continue;
            }
            if (v611 === "custom") {
              {
                const v612 = await promptText("Enter Proxies File Path:", "proxies.txt");
                if (v612.toLowerCase() === "back") continue;
                v536 = v612;
              }
            } else v611 === "none" ? v536 = '' : v536 = v611;
            v529 = 4;
          } else {
            if (v529 === 4) {
              const v613 = await selectOption("SELECT THREADS", [{
                'name': "10 Threads",
                'value': 0xa
              }, {
                'name': "20 Threads (Default)",
                'value': 0x14
              }, {
                'name': "50 Threads (Fast)",
                'value': 0x32
              }, {
                'name': "100 Threads (Extreme)",
                'value': 0x64
              }, {
                'name': "⌨️  Custom...",
                'value': -1
              }, {
                'name': "⬅️ Go Back to Proxies Selection",
                'value': "back"
              }]);
              if (v613 === "back") {
                v529 = 3;
                continue;
              }
              if (v613 === -1) {
                const v614 = await promptText("Enter custom thread count (type 'back' to go back):", '20');
                if (v614.toLowerCase() === "back") continue;
                v537 = parseInt(v614) || 20;
              } else {
                v537 = v613;
              }
              v529 = 5;
            } else {
              if (v529 === 5) {
                {
                  const v615 = await selectOption("SELECT REGION", [{
                    'name': "🎲 Random",
                    'value': "random"
                  }, {
                    'name': "🇺🇸 English (en-US)",
                    'value': "en-US"
                  }, {
                    'name': "🇪🇸 Spanish (es-ES)",
                    'value': "es-ES"
                  }, {
                    'name': "⬅️ Go Back to Threads Selection",
                    'value': "back"
                  }]);
                  if (v615 === "back") {
                    v529 = 4;
                    continue;
                  }
                  v538 = v615, v529 = 6;
                }
              } else {
                if (v529 === 6) {
                  {
                    const v616 = await selectOption("SELECT BROWSER PROFILE", [{
                      'name': "🎲 Random (Desktop + Mobile)",
                      'value': "random"
                    }, {
                      'name': "📱 Mobile Chrome (Android Only)",
                      'value': "mobile"
                    }, {
                      'name': "💻 Desktop Chrome (Windows Only)",
                      'value': "desktop"
                    }, {
                      'name': "⬅️ Go Back to Region Selection",
                      'value': "back"
                    }]);
                    if (v616 === "back") {
                      {
                        v529 = 5;
                        continue;
                      }
                    }
                    v539 = v616, v529 = 7;
                  }
                } else {
                  if (v529 === 7) {
                    {
                      const v617 = await promptText("Enter number of OTP resends per number (type 'back' to go back) [default: 0]:", '0');
                      if (v617.toLowerCase() === "back") {
                        {
                          v529 = 6;
                          continue;
                        }
                      }
                      v540 = parseInt(v617) || 0, v529 = 8;
                    }
                  } else {
                    if (v529 === 8) {
                      {
                        const v618 = await selectOption("SELECT REGISTRATION METHOD", [{
                          'name': "⚡ Method 1: Standard ",
                          'value': '1'
                        }, {
                          'name': "🚀 Method 2: Bandwidth Saver ",
                          'value': '2'
                        }, {
                          'name': "⬅️ Go Back to OTP Resends",
                          'value': "back"
                        }]);
                        if (v618 === "back") {
                          {
                            v529 = 7;
                            continue;
                          }
                        }
                        v541 = v618, v529 = 9;
                      }
                    } else {
                      if (v529 === 9) {
                        break;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return process.stdin.pause(), {
      'numbersFile': v531,
      'threads': String(v537),
      'proxiesFile': v536,
      'region': v538,
      'browser': v539,
      'resends': String(v540),
      'regMethod': v541,
      'nexaConfig': v532,
      'twoOoConfig': v533,
      'smsBowerConfig': v534,
      'zenexConfig': v535
    };
  }
  function generateHWID() {
    const v619 = require('os');
    const v620 = v619.platform();
    try {
      if (v620 === "win32") {
        {
          const v621 = execSync('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
            'stdio': "pipe",
            'timeout': 0x3a98
          }).toString().trim();
          if (!v621) throw new Error("No hardware data");
          const v622 = crypto.createHash("sha256").update(v621).digest("hex").toUpperCase();
          return "SKING-" + v622.substring(0, 8) + '-' + v622.substring(8, 12) + '-' + v622.substring(12, 16);
        }
      } else {
        {
          let v623 = [];
          try {
            {
              const v626 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
                'stdio': "pipe",
                'timeout': 0x1388
              }).toString().trim();
              if (v626 && v626 !== "null") v623.push('A:' + v626);
            }
          } catch (v627) {}
          try {
            if (fs.existsSync("/proc/cpuinfo")) {
              const v628 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                v629 = v628.match(/Serial\s*:\s*(\S+)/i),
                v630 = v628.match(/Hardware\s*:\s*(.+)/i);
              if (v629 && v629[1] !== "0000000000000000") v623.push('S:' + v629[1].trim());
              if (v630) v623.push('H:' + v630[1].trim());
            }
          } catch (v631) {}
          try {
            {
              if (fs.existsSync("/etc/machine-id")) {
                const v632 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                if (v632) v623.push('M:' + v632);
              }
            }
          } catch (v633) {}
          try {
            const v634 = v619.cpus(),
              v635 = v634 && v634.length > 0 ? v634[0].model : "UnknownCPU",
              v636 = v619.totalmem(),
              v637 = v619.release(),
              v638 = v619.hostname();
            v623.push('F:' + v635 + '|' + v636 + '|' + v637 + '|' + v638);
          } catch (v639) {}
          const v624 = v623.join('||'),
            v625 = crypto.createHash("sha256").update(v624).digest("hex").toUpperCase();
          return "ANKING-" + v625.substring(0, 8) + '-' + v625.substring(8, 12) + '-' + v625.substring(12, 16);
        }
      }
    } catch (v640) {
      return '';
    }
  }
  function verifyServerSignature(v641, v642) {
    if (!v642) return false;
    const v643 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v641, "utf8"), v643, Buffer.from(v642, "base64"));
    } catch (v644) {
      return false;
    }
  }
  async function start() {
    const v645 = generateHWID();
    !v645 && (console.error(R("\n  ✗ Could not generate Hardware ID.")), console.error(R("  ✗ Please run on Windows or provide HWID as argument.\n")), process.exit(1));
    const v646 = generateHWID();
    if (v646 !== v645) {
      console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1);
    }
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Tool      : ") + C("Meta Account Creator         ") + W('│')), console.log(W("│ [•] Your HWID : ") + Y(v645.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v647 = false,
      v648 = "Licensed";
    const v649 = Date.now();
    try {
      {
        const v664 = "188.137.176.163",
          v665 = require("http"),
          v666 = await new Promise((v667, v668) => {
            {
              const v669 = {};
              v669.hwid = v645, v669.app_id = "meta", v669.version = "2.0.2", v669.timestamp = v649;
              const v670 = JSON.stringify(v669),
                v671 = {
                  'hostname': v664,
                  'port': 0xec1,
                  'path': "/api/verify",
                  'method': "POST",
                  'headers': {
                    'Content-Type': "application/json",
                    'Content-Length': Buffer.byteLength(v670)
                  },
                  'timeout': 0x2710
                },
                v672 = v665.request(v671, v673 => {
                  {
                    let v674 = '';
                    v673.on("data", v675 => v674 += v675), v673.on("end", () => {
                      try {
                        v667(JSON.parse(v674));
                      } catch (v676) {
                        v668(v676);
                      }
                    });
                  }
                });
              v672.on("error", v668), v672.on("timeout", function () {
                this.destroy(), v668(new Error("Timeout"));
              }), v672.write(v670), v672.end();
            }
          });
        if (v666) {
          v666.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v666.status === "banned" || v666.status === "expired" || !v666.sig) {
            {
              await new Promise(v680 => setTimeout(v680, 2000));
              let v679 = String(v666.reason || "NOT REGISTERED");
              if (!v666.reason && !v666.sig) v679 = "NOT REGISTERED / REMOVED";
              console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — META TOOL     ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v645.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v679.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
            }
          }
          const v677 = v645 + "|meta|2.0.2|" + v649;
          !verifyServerSignature(v677, v666.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
          v647 = true;
          let v678 = v666.token;
          if (!v678) {
            console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1);
          }
          setInterval(() => {
            !v678 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
            const v681 = {};
            v681.hwid = v645;
            v681.app_id = "meta";
            v681.token = v678;
            const v682 = JSON.stringify(v681),
              v683 = {
                'hostname': v664,
                'port': 0xec1,
                'path': "/api/ping",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v682)
                },
                'timeout': 0x1388
              },
              v684 = v665.request(v683, v685 => {
                let v686 = '';
                v685.on("data", v687 => v686 += v687), v685.on("end", () => {
                  try {
                    const v688 = JSON.parse(v686);
                    v688.status === 'ok' && v688.token ? v678 = v688.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                  } catch (v689) {
                    console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                  }
                });
              });
            v684.on("error", () => {
              console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
              process.exit(1);
            }), v684.on("timeout", function () {
              this.destroy(), console.error(R("\n  ✗ License Server timeout. Exiting...\n")), process.exit(1);
            }), v684.write(v682);
            v684.end();
          }, 45000);
        }
      }
    } catch (v690) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    !v647 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    const v650 = process.argv.slice(2).filter(v691 => !v691.startsWith('--'));
    let v651 = v650,
      v652 = null,
      v653 = null,
      v654 = null,
      v655 = null,
      v656 = '1';
    if (v651.length === 0) {
      const v692 = await interactiveWizard();
      v651 = [v692.numbersFile, v692.threads, v692.proxiesFile, v692.region, v692.browser, "SKING-UI-HARDWARE-ID", v692.resends, v692.regMethod], v656 = v692.regMethod || '1', v652 = v692.nexaConfig, v653 = v692.twoOoConfig || null, v654 = v692.smsBowerConfig || null, v655 = v692.zenexConfig || null;
    } else v656 = v651[7] || '1';
    v651 = v651.map(v693 => {
      if (typeof v693 === "string") {
        if (v693.startsWith('\x22') && v693.endsWith('\x22')) return v693.slice(1, -1);
        if (v693.startsWith('\x27') && v693.endsWith('\x27')) return v693.slice(1, -1);
      }
      return v693;
    });
    let v657 = path.resolve(v651[0] || "numbers.txt"),
      v658 = parseInt(v651[1]) || 20,
      v659 = v651[2] !== undefined ? v651[2] : "proxies.txt";
    if (v659.toLowerCase() === "none" || v659 === "false") v659 = '';
    let v660 = v651[3] || "random";
    let v661 = v651[4] || "random",
      v662 = parseInt(v651[6]) || 0;
    if (v651[7]) v656 = v651[7];
    v659 && !v659.includes(':') && !path.isAbsolute(v659) && (v659 = path.resolve(v659));
    printHeader(), console.log(B("  ✓ License: " + v648) + G(" | HWID: " + v645)), console.log(C("  ✓ Method : " + (v656 === '2' ? "Method 2 (Bandwidth Saver 🚀)" : "Method 1 (Standard ⚡)")));
    let v663 = true;
    while (v663) {
      let v694 = [];
      if (!v652 && !v653 && !v654 && !v655) {
        !fs.existsSync(v657) && (console.error(R("✗ Error: Numbers file not found: " + v657)), process.exit(1));
        v694 = fs.readFileSync(v657, "utf8").split(/\r?\n/).map(v715 => v715.trim()).filter(v716 => v716 && v716.replace(/\D/g, '').length >= 7);
        if (v694.length === 0) {
          console.error(R("✗ No valid phone numbers found in file")), process.exit(1);
        }
      }
      let v695 = [];
      v659 && fs.existsSync(v659) && (v695 = fs.readFileSync(v659, "utf8").split('\x0a').map(v717 => v717.trim()).filter(v718 => v718.length > 0));
      let v696 = [];
      for (const v719 of v695) {
        {
          const v720 = parseProxy(v719);
          if (!v720) {
            {
              console.error(R("\n  ✗ Invalid proxy format detected: \"" + v719 + '\x22'));
              console.error(R("  Please use one of the supported formats:"));
              console.error(R("    - host:port"));
              console.error(R("    - user:pass@host:port"));
              console.error(R("    - host:port:user:pass"));
              console.error(R("    - user:pass:host:port\n"));
              process.exit(1);
            }
          }
          v696.push(v720);
        }
      }
      const v697 = v652 || v653 || v654 || v655;
      if (v697) {
        {
          const v721 = v652 ? "NexaOTP" : v653 ? v653.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v654 ? "📱 SMS Bower" : "⚡ Zenex";
          console.log(C("✓ Target  : " + v721 + " API (" + v697.totalCount + " numbers)"));
        }
      } else {
        console.log(Y("✓ Loaded " + v694.length + " targets"));
      }
      if (v696.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v696.length));
      console.log(C("✓ Threads: " + v658 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, ''), fs.writeFileSync(DEBUG_FILE, "=== DEBUG SESSION ===\n");
      const v698 = new Dashboard(v697 ? v697.totalCount : v694.length);
      let v699 = [],
        v700 = [],
        v701 = 0,
        v702 = false;
      if (v652 || v653) {
        const v722 = v652 ? "NexaOTP" : v653.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥";
        (async () => {
          {
            let v723 = 0,
              v724 = '';
            try {
              for (let v725 = 0; v725 < v697.totalCount; v725++) {
                try {
                  const v726 = v697.ranges[Math.floor(Math.random() * v697.ranges.length)];
                  let v727;
                  v652 ? v727 = await nexaLimiter.enqueue(() => nexaFetchNumber(v652.apiKey, v726, v652.serverEndpoint)) : v727 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v653.apiKey, v726, v653.getPath));
                  if (v727) {
                    {
                      v701++, v723 = 0;
                      if (v700.length > 0) {
                        v700.shift()(v727);
                      } else v699.push(v727);
                    }
                  }
                } catch (v728) {
                  v724 = v728.message, v723++;
                  if (v728.message.includes("Insufficient balance")) {
                    {
                      console.error(R("\n  [" + v722 + "] ✗ Insufficient balance — aborting.\n"));
                      break;
                    }
                  }
                  if (v728.message.includes("No numbers available")) continue;
                  if (v723 >= 5 && v701 === 0) {
                    {
                      console.error(R("\n  [" + v722 + "] ✗ Aborting — 5 consecutive fetch failures.")), console.error(R("  Last error: " + v724)), console.error(R("  Check your API key, range format (e.g. 26134XXX), and internet connection.\n"));
                      break;
                    }
                  }
                }
              }
            } finally {
              if (v701 === 0) console.error(R("\n  [" + v722 + "] ✗ No numbers were fetched. Last error: " + (v724 || "Unknown") + '\x0a'));else {
                console.log(G("\n  [" + v722 + "] ✓ Feeder done — " + v701 + " numbers fetched.\n"));
              }
              v702 = true;
              while (v700.length > 0) v700.shift()(null);
            }
          }
        })();
      } else {
        if (v654) {
          {
            const v729 = v654;
            (async () => {
              let v730 = 0;
              try {
                for (let v731 = 0; v731 < v729.totalCount; v731++) {
                  try {
                    const {
                      activationId: v732,
                      phoneNumber: v733
                    } = await smsBowerFetchNumber(v729.apiKey, v729.service, v729.country, v729.maxPrice);
                    v701++, v730 = 0;
                    if (v700.length > 0) v700.shift()(v733);else v699.push(v733);
                  } catch (v734) {
                    {
                      v730++;
                      if (v730 >= 5 && v701 === 0) break;
                      await new Promise(v735 => setTimeout(v735, 2000));
                    }
                  }
                }
              } finally {
                {
                  v702 = true;
                  while (v700.length > 0) v700.shift()(null);
                }
              }
            })();
          }
        } else {
          if (v655) {
            {
              const v736 = v655;
              (async () => {
                let v737 = 0;
                try {
                  for (let v738 = 0; v738 < v736.totalCount; v738++) {
                    try {
                      const v739 = v736.ranges[Math.floor(Math.random() * v736.ranges.length)],
                        v740 = await zenexFetchNumber(v736.apiKey, v739);
                      v701++, v737 = 0;
                      if (v700.length > 0) v700.shift()(v740);else v699.push(v740);
                    } catch (v741) {
                      v737++;
                      if (v737 >= 5 && v701 === 0) break;
                      await new Promise(v742 => setTimeout(v742, 2000));
                    }
                  }
                } finally {
                  v702 = true;
                  while (v700.length > 0) v700.shift()(null);
                }
              })();
            }
          }
        }
      }
      const v703 = !!(v652 || v653 || v654 || v655),
        v704 = v703 ? () => {
          {
            if (v699.length > 0) return Promise.resolve(v699.shift());
            if (v702) return Promise.resolve(null);
            return new Promise(v743 => v700.push(v743));
          }
        } : (() => {
          {
            let v744 = null;
            const fn15 = () => {
              {
                if (v744) clearTimeout(v744);
                v744 = setTimeout(() => {
                  try {
                    fs.writeFileSync(v657, v694.join('\x0a'), "utf8");
                  } catch (v745) {}
                }, 50);
              }
            };
            return () => {
              {
                if (v694.length === 0) return Promise.resolve(null);
                const v746 = Math.floor(Math.random() * v694.length),
                  v747 = v694.splice(v746, 1)[0];
                return fn15(), Promise.resolve(v747);
              }
            };
          }
        })();
      let v705 = 0;
      const fn13 = () => {
          if (v696.length === 0) return null;
          const v748 = v696[v705 % v696.length];
          v705++;
          return rotateSessionId(v748);
        },
        v706 = new Set(),
        v707 = {};
      v707.flags = 'a';
      const v708 = fs.createWriteStream(SUCCESSFUL_FILE, v707),
        v709 = {};
      v709.flags = 'a';
      const v710 = fs.createWriteStream(FAILED_FILE, v709),
        v711 = v703 ? Math.min(v658, v697.totalCount) : Math.min(v658, v694.length),
        v712 = [],
        v713 = setInterval(() => v698.render(), 500);
      async function fn14(v749) {
        while (true) {
          {
            const v750 = await v704();
            if (!v750) break;
            const v751 = normalizePhoneNumber(v750).replace('+', ''),
              v752 = getCountryFromPhone(v751),
              v753 = v752.iso,
              v754 = v752.lang.split(',')[0];
            let v755 = v753;
            try {
              v755 = _displayNames.of(v753) || v753;
            } catch (v760) {}
            let v756 = 0;
            const v757 = v696.length > 0 ? 3 : 1;
            let v758 = null;
            while (v756 < v757) {
              {
                v756++;
                const v761 = fn13(),
                  v762 = v761 ? await getProxyCountry(v761) : "Direct",
                  v763 = '[' + v754 + "] Proxy: " + v762 + " | " + v755;
                try {
                  {
                    const v764 = await createAccount(v750, {
                      'onStatus': v765 => v698.setStatus("Worker " + v749 + ':\x20' + v765),
                      'onLog': (v766, v767) => v698.addLog(v766, v767, v763),
                      'proxy': v761,
                      'workerId': v749,
                      'browserPref': v661,
                      'regionPref': v660,
                      'resends': v662,
                      'method': v656
                    });
                    if (v764.success) {
                      {
                        v698.successful++, v698.processed++, v706.add(v750.trim());
                        const v768 = v764.dob ? v764.dob.month + '/' + v764.dob.day + '/' + v764.dob.year : "N/A",
                          v769 = v761 ? v761.host + ':' + v761.port : "direct",
                          v770 = new Date().toISOString().replace('T', '\x20').substring(0, 19);
                        v708.write('' + v764.phone + ("|pass:" + (v764.password || "N/A")) + ("|dob:" + v768) + ("|type:" + (v764.type || "registration")) + ("|browser:" + (v764.browser || "unknown")) + ("|lang:" + (v764.lang || "N/A")) + ("|proxy:" + (v764.proxy || v769)) + ("|country:" + v755) + ("|ts:" + v770 + '\x0a')), v698.addLog("Triggered OTP for " + v764.phone, "success", v763), v758 = v764;
                        break;
                      }
                    } else {
                      const v771 = v764.message && (v764.message.includes("CONNECT") || v764.message.includes("ended before") || v764.message.includes("socket hang up") || v764.message.includes("ECONNRESET") || v764.message.includes("ETIMEDOUT"));
                      if (v771 && v756 < v757) {
                        v698.addLog("Proxy dropped on " + v750 + '\x20(' + v756 + '/' + v757 + ") — rotating proxy...", "retry", v763), await sleep(1000);
                        continue;
                      }
                      v698.failed++, v698.processed++, v710.write(v764.phone + '|' + v764.message + '\x0a');
                      !v764.message.includes("429") && v698.addLog("Failed on " + v764.phone + ':\x20' + v764.message, "error", v763);
                      v758 = v764;
                      break;
                    }
                  }
                } catch (v772) {
                  const v773 = v772.message && (v772.message.includes("CONNECT") || v772.message.includes("ended before") || v772.message.includes("socket hang up") || v772.message.includes("ECONNRESET") || v772.message.includes("ETIMEDOUT") || v772.message.includes("SSL routines") || v772.message.includes("certificate") || v772.message.includes("EPROTO") || v772.message.includes("bad record"));
                  if (v773 && v756 < v757) {
                    v698.addLog("Proxy dropped on " + v750 + '\x20(' + v756 + '/' + v757 + ") — rotating proxy...", "retry", v763), await sleep(1000);
                    continue;
                  }
                  v698.failed++, v698.processed++, v710.write(v750 + '|' + v772.message + '\x0a');
                  !v772.message.includes("429") && v698.addLog("Fatal error on " + v750 + ':\x20' + v772.message, "error", v763);
                  break;
                }
              }
            }
            const v759 = Math.floor(Math.random() * 3000) + 1500;
            await sleep(v759);
          }
        }
      }
      for (let v774 = 0; v774 < v711; v774++) {
        v712.push(fn14(v774));
      }
      await Promise.all(v712), clearInterval(v713), await new Promise(v775 => v708.end(v775)), await new Promise(v776 => v710.end(v776)), v698.render(), v698.stop();
      const v714 = await selectOption("Processing Complete. What next?", [{
        'name': "Reuse successful numbers (" + SUCCESSFUL_FILE + ')',
        'value': "reuse"
      }, {
        'name': "Go Home (Restart)",
        'value': "home"
      }, {
        'name': "Exit",
        'value': "exit"
      }]);
      if (v714 === "reuse") {
        {
          if (fs.existsSync(SUCCESSFUL_FILE)) {
            {
              let v777 = fs.readFileSync(SUCCESSFUL_FILE, "utf8").split('\x0a').map(v778 => v778.split('|')[0].trim()).filter(v779 => v779.length > 5);
              fs.writeFileSync(v657, v777.join('\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), console.log("\n  [32m✓ Copied " + v777.length + " successful numbers to " + v657 + " and cleared " + SUCCESSFUL_FILE + ".[0m\n");
            }
          } else console.log("\n  [31m✗ No successful numbers found.[0m\n"), v663 = false;
        }
      } else {
        if (v714 === "home") {
          {
            const v780 = await interactiveWizard();
            v651 = [v780.numbersFile, v780.threads, v780.proxiesFile, v780.region, v780.browser, "SKING-UI-HARDWARE-ID", v780.resends], v652 = v780.nexaConfig, v657 = path.resolve(v651[0] || "numbers.txt"), v658 = parseInt(v651[1]) || 20, v659 = v651[2] !== undefined ? v651[2] : "proxies.txt";
            if (v659.toLowerCase() === "none" || v659 === "false") v659 = '';
          }
        } else v663 = false;
      }
    }
  }
  start()["catch"](v781 => {
    console.error(R("Fatal error: " + v781.message));
    process.exit(1);
  });
}
function fn2(v782) {
  function fn16(v783) {
    {
      fn16(++v783);
    }
  }
  try {
    {
      if (v782) return fn16;else {
        fn16(0);
      }
    }
  } catch (v784) {}
}